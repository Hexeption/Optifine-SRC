package net.minecraftforge.common.model;

import javax.vecmath.Matrix4f;
import net.minecraft.util.Direction;

public interface ITransformation {
    Matrix4f getMatrixVec();

    Direction rotateTransform(Direction var1);

    int rotate(Direction var1, int var2);
}
