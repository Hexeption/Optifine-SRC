package net.minecraftforge.common.model;

import java.util.Optional;
import javax.vecmath.Matrix4f;
import net.minecraft.client.renderer.model.ModelRotation;
import net.minecraft.util.Direction;
import org.apache.commons.lang3.NotImplementedException;

public class TRSRTransformation implements IModelState, ITransformation {
    public TRSRTransformation(Matrix4f matrix) {
        throw new NotImplementedException("Forge dummy class");
    }

    public Matrix4f getMatrix() {
        throw new NotImplementedException("Forge dummy class");
    }

    public static TRSRTransformation from(ModelRotation rotation) {
        throw new NotImplementedException("Forge dummy class");
    }

    public static TRSRTransformation identity() {
        throw new NotImplementedException("Forge dummy class");
    }

    @Override
    public Optional<TRSRTransformation> apply(Optional<? extends IModelPart> part) {
        throw new NotImplementedException("Forge dummy class");
    }

    @Override
    public Matrix4f getMatrixVec() {
        throw new NotImplementedException("Forge dummy class");
    }

    @Override
    public Direction rotateTransform(Direction facing) {
        throw new NotImplementedException("Forge dummy class");
    }

    @Override
    public int rotate(Direction facing, int vertexIndex) {
        throw new NotImplementedException("Forge dummy class");
    }
}
