package net.minecraftforge.client.extensions;

import java.util.List;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BlockModelPart;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.model.data.ModelData;

public interface IForgeBlockModelPart {
    private BlockModelPart getBakedModel() {
        return (BlockModelPart)this;
    }

    default List<BakedQuad> getQuads(Direction side, ModelData data, RenderType renderType) {
        throw new UnsupportedOperationException();
    }

    default boolean useAmbientOcclusion(BlockState state) {
        return this.getBakedModel().useAmbientOcclusion();
    }

    default boolean useAmbientOcclusion(BlockState state, RenderType renderType) {
        return this.getBakedModel().useAmbientOcclusion();
    }
}
