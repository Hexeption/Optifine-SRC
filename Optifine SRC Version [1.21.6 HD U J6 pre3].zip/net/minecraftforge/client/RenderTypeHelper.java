package net.minecraftforge.client;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

public class RenderTypeHelper {
    public static RenderType getEntityRenderType(ChunkSectionLayer rt) {
        throw new UnsupportedOperationException();
    }
}
