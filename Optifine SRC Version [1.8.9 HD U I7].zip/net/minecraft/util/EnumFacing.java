package net.minecraft.util;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterators;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public enum EnumFacing implements IStringSerializable {
    DOWN("DOWN", 0, 0, 1, -1, "down", EnumFacing.AxisDirection.NEGATIVE, EnumFacing.Axis.Y, new Vec3i(0, -1, 0)),
    UP("UP", 1, 1, 0, -1, "up", EnumFacing.AxisDirection.POSITIVE, EnumFacing.Axis.Y, new Vec3i(0, 1, 0)),
    NORTH("NORTH", 2, 2, 3, 2, "north", EnumFacing.AxisDirection.NEGATIVE, EnumFacing.Axis.Z, new Vec3i(0, 0, -1)),
    SOUTH("SOUTH", 3, 3, 2, 0, "south", EnumFacing.AxisDirection.POSITIVE, EnumFacing.Axis.Z, new Vec3i(0, 0, 1)),
    WEST("WEST", 4, 4, 5, 1, "west", EnumFacing.AxisDirection.NEGATIVE, EnumFacing.Axis.X, new Vec3i(-1, 0, 0)),
    EAST("EAST", 5, 5, 4, 3, "east", EnumFacing.AxisDirection.POSITIVE, EnumFacing.Axis.X, new Vec3i(1, 0, 0));

    private final int index;
    private final int opposite;
    private final int horizontalIndex;
    private final String name;
    private final EnumFacing.Axis axis;
    private final EnumFacing.AxisDirection axisDirection;
    private final Vec3i directionVec;
    public static final EnumFacing[] VALUES = new EnumFacing[6];
    private static final EnumFacing[] HORIZONTALS = new EnumFacing[4];
    private static final Map<String, EnumFacing> NAME_LOOKUP = Maps.newHashMap();
    private static final EnumFacing[] $VALUES = new EnumFacing[]{DOWN, UP, NORTH, SOUTH, WEST, EAST};
    private static final String __OBFID = "CL_00001201";

    EnumFacing(
        String p_i46016_1_,
        int p_i46016_2_,
        int indexIn,
        int oppositeIn,
        int horizontalIndexIn,
        String nameIn,
        EnumFacing.AxisDirection axisDirectionIn,
        EnumFacing.Axis axisIn,
        Vec3i directionVecIn
    ) {
        this.index = indexIn;
        this.horizontalIndex = horizontalIndexIn;
        this.opposite = oppositeIn;
        this.name = nameIn;
        this.axis = axisIn;
        this.axisDirection = axisDirectionIn;
        this.directionVec = directionVecIn;
    }

    public int getIndex() {
        return this.index;
    }

    public int getHorizontalIndex() {
        return this.horizontalIndex;
    }

    public EnumFacing.AxisDirection getAxisDirection() {
        return this.axisDirection;
    }

    public EnumFacing getOpposite() {
        return VALUES[this.opposite];
    }

    public EnumFacing rotateAround(EnumFacing.Axis axis) {
        switch (EnumFacing$1.field_179515_a[axis.ordinal()]) {
            case 1:
                if (this != WEST && this != EAST) {
                    return this.rotateX();
                }

                return this;
            case 2:
                if (this != UP && this != DOWN) {
                    return this.rotateY();
                }

                return this;
            case 3:
                if (this != NORTH && this != SOUTH) {
                    return this.rotateZ();
                }

                return this;
            default:
                throw new IllegalStateException("Unable to get CW facing for axis " + axis);
        }
    }

    public EnumFacing rotateY() {
        switch (EnumFacing$1.field_179513_b[this.ordinal()]) {
            case 1:
                return EAST;
            case 2:
                return SOUTH;
            case 3:
                return WEST;
            case 4:
                return NORTH;
            default:
                throw new IllegalStateException("Unable to get Y-rotated facing of " + this);
        }
    }

    private EnumFacing rotateX() {
        switch (EnumFacing$1.field_179513_b[this.ordinal()]) {
            case 1:
                return DOWN;
            case 2:
            case 4:
            default:
                throw new IllegalStateException("Unable to get X-rotated facing of " + this);
            case 3:
                return UP;
            case 5:
                return NORTH;
            case 6:
                return SOUTH;
        }
    }

    private EnumFacing rotateZ() {
        switch (EnumFacing$1.field_179513_b[this.ordinal()]) {
            case 2:
                return DOWN;
            case 3:
            default:
                throw new IllegalStateException("Unable to get Z-rotated facing of " + this);
            case 4:
                return UP;
            case 5:
                return EAST;
            case 6:
                return WEST;
        }
    }

    public EnumFacing rotateYCCW() {
        switch (EnumFacing$1.field_179513_b[this.ordinal()]) {
            case 1:
                return WEST;
            case 2:
                return NORTH;
            case 3:
                return EAST;
            case 4:
                return SOUTH;
            default:
                throw new IllegalStateException("Unable to get CCW facing of " + this);
        }
    }

    public int getFrontOffsetX() {
        return this.axis == EnumFacing.Axis.X ? this.axisDirection.getOffset() : 0;
    }

    public int getFrontOffsetY() {
        return this.axis == EnumFacing.Axis.Y ? this.axisDirection.getOffset() : 0;
    }

    public int getFrontOffsetZ() {
        return this.axis == EnumFacing.Axis.Z ? this.axisDirection.getOffset() : 0;
    }

    public String getName2() {
        return this.name;
    }

    public EnumFacing.Axis getAxis() {
        return this.axis;
    }

    public static EnumFacing byName(String name) {
        return name == null ? null : NAME_LOOKUP.get(name.toLowerCase());
    }

    public static EnumFacing getFront(int index) {
        return VALUES[MathHelper.abs_int(index % VALUES.length)];
    }

    public static EnumFacing getHorizontal(int p_176731_0_) {
        return HORIZONTALS[MathHelper.abs_int(p_176731_0_ % HORIZONTALS.length)];
    }

    public static EnumFacing fromAngle(double angle) {
        return getHorizontal(MathHelper.floor_double(angle / 90.0 + 0.5) & 3);
    }

    public static EnumFacing random(Random rand) {
        return values()[rand.nextInt(values().length)];
    }

    public static EnumFacing getFacingFromVector(float p_176737_0_, float p_176737_1_, float p_176737_2_) {
        EnumFacing enumfacing = NORTH;
        float f = Float.MIN_VALUE;

        for (EnumFacing enumfacing1 : values()) {
            float f1 = p_176737_0_ * enumfacing1.directionVec.getX()
                + p_176737_1_ * enumfacing1.directionVec.getY()
                + p_176737_2_ * enumfacing1.directionVec.getZ();
            if (f1 > f) {
                f = f1;
                enumfacing = enumfacing1;
            }
        }

        return enumfacing;
    }

    @Override
    public String toString() {
        return this.name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    public static EnumFacing getFacingFromAxis(EnumFacing.AxisDirection p_500005_0_, EnumFacing.Axis p_500005_1_) {
        for (EnumFacing enumfacing : values()) {
            if (enumfacing.getAxisDirection() == p_500005_0_ && enumfacing.getAxis() == p_500005_1_) {
                return enumfacing;
            }
        }

        throw new IllegalArgumentException("No such direction: " + p_500005_0_ + " " + p_500005_1_);
    }

    public Vec3i getDirectionVec() {
        return this.directionVec;
    }

    static {
        for (EnumFacing enumfacing : values()) {
            VALUES[enumfacing.index] = enumfacing;
            if (enumfacing.getAxis().isHorizontal()) {
                HORIZONTALS[enumfacing.horizontalIndex] = enumfacing;
            }

            NAME_LOOKUP.put(enumfacing.getName2().toLowerCase(), enumfacing);
        }
    }

    public enum Axis implements Predicate, IStringSerializable {
        X("X", 0, "x", EnumFacing.Plane.HORIZONTAL),
        Y("Y", 1, "y", EnumFacing.Plane.VERTICAL),
        Z("Z", 2, "z", EnumFacing.Plane.HORIZONTAL);

        private static final Map<String, EnumFacing.Axis> NAME_LOOKUP = Maps.newHashMap();
        private final String name;
        private final EnumFacing.Plane plane;
        private static final EnumFacing.Axis[] $VALUES = new EnumFacing.Axis[]{X, Y, Z};
        private static final String __OBFID = "CL_00002321";

        Axis(String p_i46015_1_, int p_i46015_2_, String name, EnumFacing.Plane plane) {
            this.name = name;
            this.plane = plane;
        }

        public static EnumFacing.Axis byName(String name) {
            return name == null ? null : NAME_LOOKUP.get(name.toLowerCase());
        }

        public String getName2() {
            return this.name;
        }

        public boolean isVertical() {
            return this.plane == EnumFacing.Plane.VERTICAL;
        }

        public boolean isHorizontal() {
            return this.plane == EnumFacing.Plane.HORIZONTAL;
        }

        @Override
        public String toString() {
            return this.name;
        }

        public boolean apply(Object facing) {

            return this.apply((EnumFacing) facing);

        }


        public boolean apply(EnumFacing facing) {
            return facing != null && facing.getAxis() == this;
        }

        public EnumFacing.Plane getPlane() {
            return this.plane;
        }

        @Override
        public String getName() {
            return this.name;
        }

        static {
            for (EnumFacing.Axis enumfacing$axis : values()) {
                NAME_LOOKUP.put(enumfacing$axis.getName2().toLowerCase(), enumfacing$axis);
            }
        }
    }

    public enum AxisDirection {
        POSITIVE("POSITIVE", 0, 1, "Towards positive"),
        NEGATIVE("NEGATIVE", 1, -1, "Towards negative");

        private final int offset;
        private final String description;
        private static final EnumFacing.AxisDirection[] $VALUES = new EnumFacing.AxisDirection[]{POSITIVE, NEGATIVE};
        private static final String __OBFID = "CL_00002320";

        AxisDirection(String p_i46014_1_, int p_i46014_2_, int offset, String description) {
            this.offset = offset;
            this.description = description;
        }

        public int getOffset() {
            return this.offset;
        }

        @Override
        public String toString() {
            return this.description;
        }
    }

    public enum Plane implements Predicate, Iterable {
        HORIZONTAL("HORIZONTAL", 0),
        VERTICAL("VERTICAL", 1);

        private static final EnumFacing.Plane[] $VALUES = new EnumFacing.Plane[]{HORIZONTAL, VERTICAL};
        private static final String __OBFID = "CL_00002319";

        Plane(String p_i46013_1_, int p_i46013_2_) {
        }

        public EnumFacing[] facings() {
            switch (EnumFacing$1.field_179514_c[this.ordinal()]) {
                case 1:
                    return new EnumFacing[]{EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST};
                case 2:
                    return new EnumFacing[]{EnumFacing.UP, EnumFacing.DOWN};
                default:
                    throw new Error("Someone's been tampering with the universe!");
            }
        }

        public EnumFacing random(Random rand) {
            EnumFacing[] aenumfacing = this.facings();
            return aenumfacing[rand.nextInt(aenumfacing.length)];
        }

        public boolean apply(Object facing) {

            return this.apply((EnumFacing) facing);

        }


        public boolean apply(EnumFacing facing) {
            return facing != null && facing.getAxis().getPlane() == this;
        }

        @Override
        public Iterator<EnumFacing> iterator() {
            return Iterators.forArray(this.facings());
        }
    }
}
