package net.minecraftforge.client.extensions;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.block.model.BakedQuad;

public interface IForgeVertexConsumer {
    VertexFormat getVertexFormat();

    default void putBulkData(
        PoseStack.Pose matrixStack, BakedQuad bakedQuad, float red, float green, float blue, int lightmapCoord, int overlayColor, boolean readExistingColor
    ) {
    }
}
