package net.minecraft.network;

import com.google.common.base.Charsets;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.ByteBufProcessor;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.GatheringByteChannel;
import java.nio.channels.ScatteringByteChannel;
import java.nio.charset.Charset;
import java.util.UUID;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTSizeTracker;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IChatComponent;

public class PacketBuffer extends ByteBuf {
    private final ByteBuf buf;

    public PacketBuffer(ByteBuf wrapped) {
        this.buf = wrapped;
    }

    public static int getVarIntSize(int input) {
        for (int i = 1; i < 5; i++) {
            if ((input & -1 << i * 7) == 0) {
                return i;
            }
        }

        return 5;
    }

    public void writeByteArray(byte[] array) {
        this.writeVarIntToBuffer(array.length);
        this.writeBytes(array);
    }

    public byte[] readByteArray() {
        byte[] abyte = new byte[this.readVarIntFromBuffer()];
        this.readBytes(abyte);
        return abyte;
    }

    public BlockPos readBlockPos() {
        return BlockPos.fromLong(this.readLong());
    }

    public void writeBlockPos(BlockPos pos) {
        this.writeLong(pos.toLong());
    }

    public IChatComponent readChatComponent() throws IOException {
        return IChatComponent.Serializer.jsonToComponent(this.readStringFromBuffer(Short.MAX_VALUE));
    }

    public void writeChatComponent(IChatComponent component) throws IOException {
        this.writeString(IChatComponent.Serializer.componentToJson(component));
    }

    public <T extends Enum<T>> T readEnumValue(Class<T> enumClass) {
        return enumClass.getEnumConstants()[this.readVarIntFromBuffer()];
    }

    public void writeEnumValue(Enum<?> value) {
        this.writeVarIntToBuffer(value.ordinal());
    }

    public int readVarIntFromBuffer() {
        int i = 0;
        int j = 0;

        byte b0;
        do {
            b0 = this.readByte();
            i |= (b0 & 127) << j++ * 7;
            if (j > 5) {
                throw new RuntimeException("VarInt too big");
            }
        } while ((b0 & 128) == 128);

        return i;
    }

    public long readVarLong() {
        long i = 0L;
        int j = 0;

        byte b0;
        do {
            b0 = this.readByte();
            i |= (long)(b0 & 127) << j++ * 7;
            if (j > 10) {
                throw new RuntimeException("VarLong too big");
            }
        } while ((b0 & 128) == 128);

        return i;
    }

    public void writeUuid(UUID uuid) {
        this.writeLong(uuid.getMostSignificantBits());
        this.writeLong(uuid.getLeastSignificantBits());
    }

    public UUID readUuid() {
        return new UUID(this.readLong(), this.readLong());
    }

    public void writeVarIntToBuffer(int input) {
        while ((input & -128) != 0) {
            this.writeByte(input & 127 | 128);
            input >>>= 7;
        }

        this.writeByte(input);
    }

    public void writeVarLong(long value) {
        while ((value & -128L) != 0L) {
            this.writeByte((int)(value & 127L) | 128);
            value >>>= 7;
        }

        this.writeByte((int)value);
    }

    public void writeNBTTagCompoundToBuffer(NBTTagCompound nbt) {
        if (nbt == null) {
            this.writeByte(0);
        } else {
            try {
                CompressedStreamTools.write(nbt, new ByteBufOutputStream(this));
            } catch (IOException ioexception) {
                throw new EncoderException(ioexception);
            }
        }
    }

    public NBTTagCompound readNBTTagCompoundFromBuffer() throws IOException {
        int i = this.readerIndex();
        byte b0 = this.readByte();
        if (b0 == 0) {
            return null;
        }

        this.readerIndex(i);
        return CompressedStreamTools.read(new ByteBufInputStream(this), new NBTSizeTracker(2097152L));
    }

    public void writeItemStackToBuffer(ItemStack stack) {
        if (stack == null) {
            this.writeShort(-1);
        } else {
            this.writeShort(Item.getIdFromItem(stack.getItem()));
            this.writeByte(stack.stackSize);
            this.writeShort(stack.getMetadata());
            NBTTagCompound nbttagcompound = null;
            if (stack.getItem().isDamageable() || stack.getItem().getShareTag()) {
                nbttagcompound = stack.getTagCompound();
            }

            this.writeNBTTagCompoundToBuffer(nbttagcompound);
        }
    }

    public ItemStack readItemStackFromBuffer() throws IOException {
        ItemStack itemstack = null;
        int i = this.readShort();
        if (i >= 0) {
            int j = this.readByte();
            int k = this.readShort();
            itemstack = new ItemStack(Item.getItemById(i), j, k);
            itemstack.setTagCompound(this.readNBTTagCompoundFromBuffer());
        }

        return itemstack;
    }

    public String readStringFromBuffer(int maxLength) {
        int i = this.readVarIntFromBuffer();
        if (i > maxLength * 4) {
            throw new DecoderException("The received encoded string buffer length is longer than maximum allowed (" + i + " > " + maxLength * 4 + ")");
        } else if (i < 0) {
            throw new DecoderException("The received encoded string buffer length is less than zero! Weird string!");
        } else {
            String s = new String(this.readBytes(i).array(), Charsets.UTF_8);
            if (s.length() > maxLength) {
                throw new DecoderException("The received string length is longer than maximum allowed (" + i + " > " + maxLength + ")");
            } else {
                return s;
            }
        }
    }

    public PacketBuffer writeString(String string) {
        byte[] abyte = string.getBytes(Charsets.UTF_8);
        if (abyte.length > Short.MAX_VALUE) {
            throw new EncoderException("String too big (was " + string.length() + " bytes encoded, max " + Short.MAX_VALUE + ")");
        }

        this.writeVarIntToBuffer(abyte.length);
        this.writeBytes(abyte);
        return this;
    }

    @Override
    public int capacity() {
        return this.buf.capacity();
    }

    @Override
    public ByteBuf capacity(int p_1) {
        return this.buf.capacity(p_1);
    }

    @Override
    public int maxCapacity() {
        return this.buf.maxCapacity();
    }

    @Override
    public ByteBufAllocator alloc() {
        return this.buf.alloc();
    }

    @Override
    public ByteOrder order() {
        return this.buf.order();
    }

    @Override
    public ByteBuf order(ByteOrder p_1) {
        return this.buf.order(p_1);
    }

    @Override
    public ByteBuf unwrap() {
        return this.buf.unwrap();
    }

    @Override
    public boolean isDirect() {
        return this.buf.isDirect();
    }

    @Override
    public int readerIndex() {
        return this.buf.readerIndex();
    }

    @Override
    public ByteBuf readerIndex(int p_1) {
        return this.buf.readerIndex(p_1);
    }

    @Override
    public int writerIndex() {
        return this.buf.writerIndex();
    }

    @Override
    public ByteBuf writerIndex(int p_1) {
        return this.buf.writerIndex(p_1);
    }

    @Override
    public ByteBuf setIndex(int p_1, int p_2) {
        return this.buf.setIndex(p_1, p_2);
    }

    @Override
    public int readableBytes() {
        return this.buf.readableBytes();
    }

    @Override
    public int writableBytes() {
        return this.buf.writableBytes();
    }

    @Override
    public int maxWritableBytes() {
        return this.buf.maxWritableBytes();
    }

    @Override
    public boolean isReadable() {
        return this.buf.isReadable();
    }

    @Override
    public boolean isReadable(int p_1) {
        return this.buf.isReadable(p_1);
    }

    @Override
    public boolean isWritable() {
        return this.buf.isWritable();
    }

    @Override
    public boolean isWritable(int p_1) {
        return this.buf.isWritable(p_1);
    }

    @Override
    public ByteBuf clear() {
        return this.buf.clear();
    }

    @Override
    public ByteBuf markReaderIndex() {
        return this.buf.markReaderIndex();
    }

    @Override
    public ByteBuf resetReaderIndex() {
        return this.buf.resetReaderIndex();
    }

    @Override
    public ByteBuf markWriterIndex() {
        return this.buf.markWriterIndex();
    }

    @Override
    public ByteBuf resetWriterIndex() {
        return this.buf.resetWriterIndex();
    }

    @Override
    public ByteBuf discardReadBytes() {
        return this.buf.discardReadBytes();
    }

    @Override
    public ByteBuf discardSomeReadBytes() {
        return this.buf.discardSomeReadBytes();
    }

    @Override
    public ByteBuf ensureWritable(int p_1) {
        return this.buf.ensureWritable(p_1);
    }

    @Override
    public int ensureWritable(int p_1, boolean p_2) {
        return this.buf.ensureWritable(p_1, p_2);
    }

    @Override
    public boolean getBoolean(int p_1) {
        return this.buf.getBoolean(p_1);
    }

    @Override
    public byte getByte(int p_1) {
        return this.buf.getByte(p_1);
    }

    @Override
    public short getUnsignedByte(int p_1) {
        return this.buf.getUnsignedByte(p_1);
    }

    @Override
    public short getShort(int p_1) {
        return this.buf.getShort(p_1);
    }

    @Override
    public int getUnsignedShort(int p_1) {
        return this.buf.getUnsignedShort(p_1);
    }

    @Override
    public int getMedium(int p_1) {
        return this.buf.getMedium(p_1);
    }

    @Override
    public int getUnsignedMedium(int p_1) {
        return this.buf.getUnsignedMedium(p_1);
    }

    @Override
    public int getInt(int p_1) {
        return this.buf.getInt(p_1);
    }

    @Override
    public long getUnsignedInt(int p_1) {
        return this.buf.getUnsignedInt(p_1);
    }

    @Override
    public long getLong(int p_1) {
        return this.buf.getLong(p_1);
    }

    @Override
    public char getChar(int p_1) {
        return this.buf.getChar(p_1);
    }

    @Override
    public float getFloat(int p_1) {
        return this.buf.getFloat(p_1);
    }

    @Override
    public double getDouble(int p_1) {
        return this.buf.getDouble(p_1);
    }

    @Override
    public ByteBuf getBytes(int p_1, ByteBuf p_2) {
        return this.buf.getBytes(p_1, p_2);
    }

    @Override
    public ByteBuf getBytes(int p_1, ByteBuf p_2, int p_3) {
        return this.buf.getBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf getBytes(int p_1, ByteBuf p_2, int p_3, int p_4) {
        return this.buf.getBytes(p_1, p_2, p_3, p_4);
    }

    @Override
    public ByteBuf getBytes(int p_1, byte[] p_2) {
        return this.buf.getBytes(p_1, p_2);
    }

    @Override
    public ByteBuf getBytes(int p_1, byte[] p_2, int p_3, int p_4) {
        return this.buf.getBytes(p_1, p_2, p_3, p_4);
    }

    @Override
    public ByteBuf getBytes(int p_1, ByteBuffer p_2) {
        return this.buf.getBytes(p_1, p_2);
    }

    @Override
    public ByteBuf getBytes(int p_1, OutputStream p_2, int p_3) throws IOException {
        return this.buf.getBytes(p_1, p_2, p_3);
    }

    @Override
    public int getBytes(int p_1, GatheringByteChannel p_2, int p_3) throws IOException {
        return this.buf.getBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf setBoolean(int p_1, boolean p_2) {
        return this.buf.setBoolean(p_1, p_2);
    }

    @Override
    public ByteBuf setByte(int p_1, int p_2) {
        return this.buf.setByte(p_1, p_2);
    }

    @Override
    public ByteBuf setShort(int p_1, int p_2) {
        return this.buf.setShort(p_1, p_2);
    }

    @Override
    public ByteBuf setMedium(int p_1, int p_2) {
        return this.buf.setMedium(p_1, p_2);
    }

    @Override
    public ByteBuf setInt(int p_1, int p_2) {
        return this.buf.setInt(p_1, p_2);
    }

    @Override
    public ByteBuf setLong(int p_1, long p_2) {
        return this.buf.setLong(p_1, p_2);
    }

    @Override
    public ByteBuf setChar(int p_1, int p_2) {
        return this.buf.setChar(p_1, p_2);
    }

    @Override
    public ByteBuf setFloat(int p_1, float p_2) {
        return this.buf.setFloat(p_1, p_2);
    }

    @Override
    public ByteBuf setDouble(int p_1, double p_2) {
        return this.buf.setDouble(p_1, p_2);
    }

    @Override
    public ByteBuf setBytes(int p_1, ByteBuf p_2) {
        return this.buf.setBytes(p_1, p_2);
    }

    @Override
    public ByteBuf setBytes(int p_1, ByteBuf p_2, int p_3) {
        return this.buf.setBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf setBytes(int p_1, ByteBuf p_2, int p_3, int p_4) {
        return this.buf.setBytes(p_1, p_2, p_3, p_4);
    }

    @Override
    public ByteBuf setBytes(int p_1, byte[] p_2) {
        return this.buf.setBytes(p_1, p_2);
    }

    @Override
    public ByteBuf setBytes(int p_1, byte[] p_2, int p_3, int p_4) {
        return this.buf.setBytes(p_1, p_2, p_3, p_4);
    }

    @Override
    public ByteBuf setBytes(int p_1, ByteBuffer p_2) {
        return this.buf.setBytes(p_1, p_2);
    }

    @Override
    public int setBytes(int p_1, InputStream p_2, int p_3) throws IOException {
        return this.buf.setBytes(p_1, p_2, p_3);
    }

    @Override
    public int setBytes(int p_1, ScatteringByteChannel p_2, int p_3) throws IOException {
        return this.buf.setBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf setZero(int p_1, int p_2) {
        return this.buf.setZero(p_1, p_2);
    }

    @Override
    public boolean readBoolean() {
        return this.buf.readBoolean();
    }

    @Override
    public byte readByte() {
        return this.buf.readByte();
    }

    @Override
    public short readUnsignedByte() {
        return this.buf.readUnsignedByte();
    }

    @Override
    public short readShort() {
        return this.buf.readShort();
    }

    @Override
    public int readUnsignedShort() {
        return this.buf.readUnsignedShort();
    }

    @Override
    public int readMedium() {
        return this.buf.readMedium();
    }

    @Override
    public int readUnsignedMedium() {
        return this.buf.readUnsignedMedium();
    }

    @Override
    public int readInt() {
        return this.buf.readInt();
    }

    @Override
    public long readUnsignedInt() {
        return this.buf.readUnsignedInt();
    }

    @Override
    public long readLong() {
        return this.buf.readLong();
    }

    @Override
    public char readChar() {
        return this.buf.readChar();
    }

    @Override
    public float readFloat() {
        return this.buf.readFloat();
    }

    @Override
    public double readDouble() {
        return this.buf.readDouble();
    }

    @Override
    public ByteBuf readBytes(int p_1) {
        return this.buf.readBytes(p_1);
    }

    @Override
    public ByteBuf readSlice(int p_1) {
        return this.buf.readSlice(p_1);
    }

    @Override
    public ByteBuf readBytes(ByteBuf p_1) {
        return this.buf.readBytes(p_1);
    }

    @Override
    public ByteBuf readBytes(ByteBuf p_1, int p_2) {
        return this.buf.readBytes(p_1, p_2);
    }

    @Override
    public ByteBuf readBytes(ByteBuf p_1, int p_2, int p_3) {
        return this.buf.readBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf readBytes(byte[] p_1) {
        return this.buf.readBytes(p_1);
    }

    @Override
    public ByteBuf readBytes(byte[] p_1, int p_2, int p_3) {
        return this.buf.readBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf readBytes(ByteBuffer p_1) {
        return this.buf.readBytes(p_1);
    }

    @Override
    public ByteBuf readBytes(OutputStream p_1, int p_2) throws IOException {
        return this.buf.readBytes(p_1, p_2);
    }

    @Override
    public int readBytes(GatheringByteChannel p_1, int p_2) throws IOException {
        return this.buf.readBytes(p_1, p_2);
    }

    @Override
    public ByteBuf skipBytes(int p_1) {
        return this.buf.skipBytes(p_1);
    }

    @Override
    public ByteBuf writeBoolean(boolean p_1) {
        return this.buf.writeBoolean(p_1);
    }

    @Override
    public ByteBuf writeByte(int p_1) {
        return this.buf.writeByte(p_1);
    }

    @Override
    public ByteBuf writeShort(int p_1) {
        return this.buf.writeShort(p_1);
    }

    @Override
    public ByteBuf writeMedium(int p_1) {
        return this.buf.writeMedium(p_1);
    }

    @Override
    public ByteBuf writeInt(int p_1) {
        return this.buf.writeInt(p_1);
    }

    @Override
    public ByteBuf writeLong(long p_1) {
        return this.buf.writeLong(p_1);
    }

    @Override
    public ByteBuf writeChar(int p_1) {
        return this.buf.writeChar(p_1);
    }

    @Override
    public ByteBuf writeFloat(float p_1) {
        return this.buf.writeFloat(p_1);
    }

    @Override
    public ByteBuf writeDouble(double p_1) {
        return this.buf.writeDouble(p_1);
    }

    @Override
    public ByteBuf writeBytes(ByteBuf p_1) {
        return this.buf.writeBytes(p_1);
    }

    @Override
    public ByteBuf writeBytes(ByteBuf p_1, int p_2) {
        return this.buf.writeBytes(p_1, p_2);
    }

    @Override
    public ByteBuf writeBytes(ByteBuf p_1, int p_2, int p_3) {
        return this.buf.writeBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf writeBytes(byte[] p_1) {
        return this.buf.writeBytes(p_1);
    }

    @Override
    public ByteBuf writeBytes(byte[] p_1, int p_2, int p_3) {
        return this.buf.writeBytes(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf writeBytes(ByteBuffer p_1) {
        return this.buf.writeBytes(p_1);
    }

    @Override
    public int writeBytes(InputStream p_1, int p_2) throws IOException {
        return this.buf.writeBytes(p_1, p_2);
    }

    @Override
    public int writeBytes(ScatteringByteChannel p_1, int p_2) throws IOException {
        return this.buf.writeBytes(p_1, p_2);
    }

    @Override
    public ByteBuf writeZero(int p_1) {
        return this.buf.writeZero(p_1);
    }

    @Override
    public int indexOf(int p_1, int p_2, byte p_3) {
        return this.buf.indexOf(p_1, p_2, p_3);
    }

    @Override
    public int bytesBefore(byte p_1) {
        return this.buf.bytesBefore(p_1);
    }

    @Override
    public int bytesBefore(int p_1, byte p_2) {
        return this.buf.bytesBefore(p_1, p_2);
    }

    @Override
    public int bytesBefore(int p_1, int p_2, byte p_3) {
        return this.buf.bytesBefore(p_1, p_2, p_3);
    }

    @Override
    public int forEachByte(ByteBufProcessor p_1) {
        return this.buf.forEachByte(p_1);
    }

    @Override
    public int forEachByte(int p_1, int p_2, ByteBufProcessor p_3) {
        return this.buf.forEachByte(p_1, p_2, p_3);
    }

    @Override
    public int forEachByteDesc(ByteBufProcessor p_1) {
        return this.buf.forEachByteDesc(p_1);
    }

    @Override
    public int forEachByteDesc(int p_1, int p_2, ByteBufProcessor p_3) {
        return this.buf.forEachByteDesc(p_1, p_2, p_3);
    }

    @Override
    public ByteBuf copy() {
        return this.buf.copy();
    }

    @Override
    public ByteBuf copy(int p_1, int p_2) {
        return this.buf.copy(p_1, p_2);
    }

    @Override
    public ByteBuf slice() {
        return this.buf.slice();
    }

    @Override
    public ByteBuf slice(int p_1, int p_2) {
        return this.buf.slice(p_1, p_2);
    }

    @Override
    public ByteBuf duplicate() {
        return this.buf.duplicate();
    }

    @Override
    public int nioBufferCount() {
        return this.buf.nioBufferCount();
    }

    @Override
    public ByteBuffer nioBuffer() {
        return this.buf.nioBuffer();
    }

    @Override
    public ByteBuffer nioBuffer(int p_1, int p_2) {
        return this.buf.nioBuffer(p_1, p_2);
    }

    @Override
    public ByteBuffer internalNioBuffer(int p_1, int p_2) {
        return this.buf.internalNioBuffer(p_1, p_2);
    }

    @Override
    public ByteBuffer[] nioBuffers() {
        return this.buf.nioBuffers();
    }

    @Override
    public ByteBuffer[] nioBuffers(int p_1, int p_2) {
        return this.buf.nioBuffers(p_1, p_2);
    }

    @Override
    public boolean hasArray() {
        return this.buf.hasArray();
    }

    @Override
    public byte[] array() {
        return this.buf.array();
    }

    @Override
    public int arrayOffset() {
        return this.buf.arrayOffset();
    }

    @Override
    public boolean hasMemoryAddress() {
        return this.buf.hasMemoryAddress();
    }

    @Override
    public long memoryAddress() {
        return this.buf.memoryAddress();
    }

    @Override
    public String toString(Charset p_1) {
        return this.buf.toString(p_1);
    }

    @Override
    public String toString(int p_1, int p_2, Charset p_3) {
        return this.buf.toString(p_1, p_2, p_3);
    }

    @Override
    public int hashCode() {
        return this.buf.hashCode();
    }

    @Override
    public boolean equals(Object p_1) {
        return this.buf.equals(p_1);
    }

    @Override
    public int compareTo(ByteBuf p_1) {
        return this.buf.compareTo(p_1);
    }

    @Override
    public String toString() {
        return this.buf.toString();
    }

    @Override
    public ByteBuf retain(int p_1) {
        return this.buf.retain(p_1);
    }

    @Override
    public ByteBuf retain() {
        return this.buf.retain();
    }

    @Override
    public int refCnt() {
        return this.buf.refCnt();
    }

    @Override
    public boolean release() {
        return this.buf.release();
    }

    @Override
    public boolean release(int p_1) {
        return this.buf.release(p_1);
    }
}
