package net.minecraft.entity.ai;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EntitySelectors;

public class EntityAINearestAttackableTarget<T extends EntityLivingBase> extends EntityAITarget {
    protected final Class<T> targetClass;
    private final int targetChance;
    protected final EntityAINearestAttackableTarget.Sorter theNearestAttackableTargetSorter;
    protected Predicate<? super T> targetEntitySelector;
    protected EntityLivingBase targetEntity;

    public EntityAINearestAttackableTarget(EntityCreature creature, Class<T> classTarget, boolean checkSight) {
        this(creature, classTarget, checkSight, false);
    }

    public EntityAINearestAttackableTarget(EntityCreature creature, Class<T> classTarget, boolean checkSight, boolean onlyNearby) {
        this(creature, classTarget, 10, checkSight, onlyNearby, null);
    }

    public EntityAINearestAttackableTarget(
        EntityCreature creature, Class<T> classTarget, int chance, boolean checkSight, boolean onlyNearby, final Predicate<? super T> targetSelector
    ) {
        super(creature, checkSight, onlyNearby);
        this.targetClass = classTarget;
        this.targetChance = chance;
        this.theNearestAttackableTargetSorter = new EntityAINearestAttackableTarget.Sorter(creature);
        this.setMutexBits(1);
        this.targetEntitySelector = new Predicate<T>() {
            public boolean apply(T p_1) {
                if (targetSelector != null && !targetSelector.apply(p_1)) {
                    return false;
                }

                if (p_1 instanceof EntityPlayer) {
                    double d0 = EntityAINearestAttackableTarget.this.getTargetDistance();
                    if (p_1.isSneaking()) {
                        d0 *= 0.8F;
                    }

                    if (p_1.isInvisible()) {
                        float f = ((EntityPlayer)p_1).getArmorVisibility();
                        if (f < 0.1F) {
                            f = 0.1F;
                        }

                        d0 *= 0.7F * f;
                    }

                    if (p_1.getDistanceToEntity(EntityAINearestAttackableTarget.this.taskOwner) > d0) {
                        return false;
                    }
                }

                return EntityAINearestAttackableTarget.this.isSuitableTarget(p_1, false);
            }
        };
    }

    @Override
    public boolean shouldExecute() {
        if (this.targetChance > 0 && this.taskOwner.getRNG().nextInt(this.targetChance) != 0) {
            return false;
        }

        double d0 = this.getTargetDistance();
        List<T> list = this.taskOwner
            .worldObj
            .getEntitiesWithinAABB(
                this.targetClass,
                this.taskOwner.getEntityBoundingBox().expand(d0, 4.0, d0),
                Predicates.and(this.targetEntitySelector, EntitySelectors.NOT_SPECTATING)
            );
        Collections.sort(list, this.theNearestAttackableTargetSorter);
        if (list.isEmpty()) {
            return false;
        }

        this.targetEntity = list.get(0);
        return true;
    }

    @Override
    public void startExecuting() {
        this.taskOwner.setAttackTarget(this.targetEntity);
        super.startExecuting();
    }

    public static class Sorter implements Comparator<Entity> {
        private final Entity theEntity;

        public Sorter(Entity theEntityIn) {
            this.theEntity = theEntityIn;
        }

        public int compare(Entity p_1, Entity p_2) {
            double d0 = this.theEntity.getDistanceSqToEntity(p_1);
            double d1 = this.theEntity.getDistanceSqToEntity(p_2);
            if (d0 < d1) {
                return -1;
            } else {
                return d0 > d1 ? 1 : 0;
            }
        }
    }
}
