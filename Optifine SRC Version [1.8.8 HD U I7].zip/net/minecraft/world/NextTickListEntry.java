package net.minecraft.world;

import net.minecraft.block.Block;
import net.minecraft.util.BlockPos;

public class NextTickListEntry implements Comparable<NextTickListEntry> {
    private static long nextTickEntryID;
    private final Block block;
    public final BlockPos position;
    public long scheduledTime;
    public int priority;
    private long tickEntryID;

    public NextTickListEntry(BlockPos p_i45745_1_, Block p_i45745_2_) {
        this.tickEntryID = nextTickEntryID++;
        this.position = p_i45745_1_;
        this.block = p_i45745_2_;
    }

    @Override
    public boolean equals(Object p_1) {
        if (!(p_1 instanceof NextTickListEntry)) {
            return false;
        }

        NextTickListEntry nextticklistentry = (NextTickListEntry)p_1;
        return this.position.equals(nextticklistentry.position) && Block.isEqualTo(this.block, nextticklistentry.block);
    }

    @Override
    public int hashCode() {
        return this.position.hashCode();
    }

    public NextTickListEntry setScheduledTime(long p_77176_1_) {
        this.scheduledTime = p_77176_1_;
        return this;
    }

    public void setPriority(int p_82753_1_) {
        this.priority = p_82753_1_;
    }

    public int compareTo(NextTickListEntry p_1) {
        if (this.scheduledTime < p_1.scheduledTime) {
            return -1;
        } else if (this.scheduledTime > p_1.scheduledTime) {
            return 1;
        } else if (this.priority != p_1.priority) {
            return this.priority - p_1.priority;
        } else if (this.tickEntryID < p_1.tickEntryID) {
            return -1;
        } else {
            return this.tickEntryID > p_1.tickEntryID ? 1 : 0;
        }
    }

    @Override
    public String toString() {
        return Block.getIdFromBlock(this.block) + ": " + this.position + ", " + this.scheduledTime + ", " + this.priority + ", " + this.tickEntryID;
    }

    public Block getBlock() {
        return this.block;
    }
}
