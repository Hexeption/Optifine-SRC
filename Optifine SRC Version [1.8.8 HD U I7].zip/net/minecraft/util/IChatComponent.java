package net.minecraft.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map.Entry;

public interface IChatComponent extends Iterable<IChatComponent> {
    IChatComponent setChatStyle(ChatStyle var1);

    ChatStyle getChatStyle();

    IChatComponent appendText(String var1);

    IChatComponent appendSibling(IChatComponent var1);

    String getUnformattedTextForChat();

    String getUnformattedText();

    String getFormattedText();

    List<IChatComponent> getSiblings();

    IChatComponent createCopy();

    class Serializer implements JsonDeserializer<IChatComponent>, JsonSerializer<IChatComponent> {
        private static final Gson GSON;

        public IChatComponent deserialize(JsonElement p_1, Type p_2, JsonDeserializationContext p_3) throws JsonParseException {
            if (p_1.isJsonPrimitive()) {
                return new ChatComponentText(p_1.getAsString());
            }

            if (!p_1.isJsonObject()) {
                if (p_1.isJsonArray()) {
                    JsonArray jsonarray1 = p_1.getAsJsonArray();
                    IChatComponent ichatcomponent1 = null;

                    for (JsonElement jsonelement : jsonarray1) {
                        IChatComponent ichatcomponent2 = this.deserialize(jsonelement, jsonelement.getClass(), p_3);
                        if (ichatcomponent1 == null) {
                            ichatcomponent1 = ichatcomponent2;
                        } else {
                            ichatcomponent1.appendSibling(ichatcomponent2);
                        }
                    }

                    return ichatcomponent1;
                } else {
                    throw new JsonParseException("Don't know how to turn " + p_1.toString() + " into a Component");
                }
            } else {
                JsonObject jsonobject = p_1.getAsJsonObject();
                IChatComponent ichatcomponent;
                if (jsonobject.has("text")) {
                    ichatcomponent = new ChatComponentText(jsonobject.get("text").getAsString());
                } else if (jsonobject.has("translate")) {
                    String s = jsonobject.get("translate").getAsString();
                    if (jsonobject.has("with")) {
                        JsonArray jsonarray = jsonobject.getAsJsonArray("with");
                        Object[] aobject = new Object[jsonarray.size()];

                        for (int i = 0; i < aobject.length; i++) {
                            aobject[i] = this.deserialize(jsonarray.get(i), p_2, p_3);
                            if (aobject[i] instanceof ChatComponentText) {
                                ChatComponentText chatcomponenttext = (ChatComponentText)aobject[i];
                                if (chatcomponenttext.getChatStyle().isEmpty() && chatcomponenttext.getSiblings().isEmpty()) {
                                    aobject[i] = chatcomponenttext.getChatComponentText_TextValue();
                                }
                            }
                        }

                        ichatcomponent = new ChatComponentTranslation(s, aobject);
                    } else {
                        ichatcomponent = new ChatComponentTranslation(s);
                    }
                } else if (jsonobject.has("score")) {
                    JsonObject jsonobject1 = jsonobject.getAsJsonObject("score");
                    if (!jsonobject1.has("name") || !jsonobject1.has("objective")) {
                        throw new JsonParseException("A score component needs a least a name and an objective");
                    }

                    ichatcomponent = new ChatComponentScore(JsonUtils.getString(jsonobject1, "name"), JsonUtils.getString(jsonobject1, "objective"));
                    if (jsonobject1.has("value")) {
                        ((ChatComponentScore)ichatcomponent).setValue(JsonUtils.getString(jsonobject1, "value"));
                    }
                } else {
                    if (!jsonobject.has("selector")) {
                        throw new JsonParseException("Don't know how to turn " + p_1.toString() + " into a Component");
                    }

                    ichatcomponent = new ChatComponentSelector(JsonUtils.getString(jsonobject, "selector"));
                }

                if (jsonobject.has("extra")) {
                    JsonArray jsonarray2 = jsonobject.getAsJsonArray("extra");
                    if (jsonarray2.size() <= 0) {
                        throw new JsonParseException("Unexpected empty array of components");
                    }

                    for (int j = 0; j < jsonarray2.size(); j++) {
                        ichatcomponent.appendSibling(this.deserialize(jsonarray2.get(j), p_2, p_3));
                    }
                }

                ichatcomponent.setChatStyle(p_3.deserialize(p_1, ChatStyle.class));
                return ichatcomponent;
            }
        }

        private void serializeChatStyle(ChatStyle style, JsonObject object, JsonSerializationContext ctx) {
            JsonElement jsonelement = ctx.serialize(style);
            if (jsonelement.isJsonObject()) {
                JsonObject jsonobject = (JsonObject)jsonelement;

                for (Entry<String, JsonElement> entry : jsonobject.entrySet()) {
                    object.add(entry.getKey(), entry.getValue());
                }
            }
        }

        public JsonElement serialize(IChatComponent p_1, Type p_2, JsonSerializationContext p_3) {
            if (p_1 instanceof ChatComponentText && p_1.getChatStyle().isEmpty() && p_1.getSiblings().isEmpty()) {
                return new JsonPrimitive(((ChatComponentText)p_1).getChatComponentText_TextValue());
            }

            JsonObject jsonobject = new JsonObject();
            if (!p_1.getChatStyle().isEmpty()) {
                this.serializeChatStyle(p_1.getChatStyle(), jsonobject, p_3);
            }

            if (!p_1.getSiblings().isEmpty()) {
                JsonArray jsonarray = new JsonArray();

                for (IChatComponent ichatcomponent : p_1.getSiblings()) {
                    jsonarray.add(this.serialize(ichatcomponent, ichatcomponent.getClass(), p_3));
                }

                jsonobject.add("extra", jsonarray);
            }

            if (p_1 instanceof ChatComponentText) {
                jsonobject.addProperty("text", ((ChatComponentText)p_1).getChatComponentText_TextValue());
            } else if (p_1 instanceof ChatComponentTranslation) {
                ChatComponentTranslation chatcomponenttranslation = (ChatComponentTranslation)p_1;
                jsonobject.addProperty("translate", chatcomponenttranslation.getKey());
                if (chatcomponenttranslation.getFormatArgs() != null && chatcomponenttranslation.getFormatArgs().length > 0) {
                    JsonArray jsonarray1 = new JsonArray();

                    for (Object object : chatcomponenttranslation.getFormatArgs()) {
                        if (object instanceof IChatComponent) {
                            jsonarray1.add(this.serialize((IChatComponent)object, object.getClass(), p_3));
                        } else {
                            jsonarray1.add(new JsonPrimitive(String.valueOf(object)));
                        }
                    }

                    jsonobject.add("with", jsonarray1);
                }
            } else if (p_1 instanceof ChatComponentScore) {
                ChatComponentScore chatcomponentscore = (ChatComponentScore)p_1;
                JsonObject jsonobject1 = new JsonObject();
                jsonobject1.addProperty("name", chatcomponentscore.getName());
                jsonobject1.addProperty("objective", chatcomponentscore.getObjective());
                jsonobject1.addProperty("value", chatcomponentscore.getUnformattedTextForChat());
                jsonobject.add("score", jsonobject1);
            } else {
                if (!(p_1 instanceof ChatComponentSelector)) {
                    throw new IllegalArgumentException("Don't know how to serialize " + p_1 + " as a Component");
                }

                ChatComponentSelector chatcomponentselector = (ChatComponentSelector)p_1;
                jsonobject.addProperty("selector", chatcomponentselector.getSelector());
            }

            return jsonobject;
        }

        public static String componentToJson(IChatComponent component) {
            return GSON.toJson(component);
        }

        public static IChatComponent jsonToComponent(String json) {
            return GSON.fromJson(json, IChatComponent.class);
        }

        static {
            GsonBuilder gsonbuilder = new GsonBuilder();
            gsonbuilder.registerTypeHierarchyAdapter(IChatComponent.class, new IChatComponent.Serializer());
            gsonbuilder.registerTypeHierarchyAdapter(ChatStyle.class, new ChatStyle.Serializer());
            gsonbuilder.registerTypeAdapterFactory(new EnumTypeAdapterFactory());
            GSON = gsonbuilder.create();
        }
    }
}
