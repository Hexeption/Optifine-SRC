package net.minecraft.util;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.Locale;
import java.util.Map;

public class EnumTypeAdapterFactory implements TypeAdapterFactory {
    @Override
    public <T> TypeAdapter<T> create(Gson p_1, TypeToken<T> p_2) {
        Class<T> oclass = (Class<T>)p_2.getRawType();
        if (!oclass.isEnum()) {
            return null;
        }

        final Map<String, T> map = Maps.newHashMap();

        for (T t : oclass.getEnumConstants()) {
            map.put(this.func_151232_a(t), t);
        }

        return new TypeAdapter<T>() {
            @Override
            public void write(JsonWriter p_1, T p_2x) throws IOException {
                if (p_2x == null) {
                    p_1.nullValue();
                } else {
                    p_1.value(EnumTypeAdapterFactory.this.func_151232_a(p_2x));
                }
            }

            @Override
            public T read(JsonReader p_1) throws IOException {
                if (p_1.peek() == JsonToken.NULL) {
                    p_1.nextNull();
                    return null;
                } else {
                    return map.get(p_1.nextString());
                }
            }
        };
    }

    private String func_151232_a(Object p_151232_1_) {
        return p_151232_1_ instanceof Enum ? ((Enum)p_151232_1_).name().toLowerCase(Locale.US) : p_151232_1_.toString().toLowerCase(Locale.US);
    }
}
