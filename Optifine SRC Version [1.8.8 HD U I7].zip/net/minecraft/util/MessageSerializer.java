package net.minecraft.util;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import java.io.IOException;
import net.minecraft.network.EnumPacketDirection;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.S0CPacketSpawnPlayer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class MessageSerializer extends MessageToByteEncoder<Packet> {
    private static final Logger logger = LogManager.getLogger();
    private static final Marker RECEIVED_PACKET_MARKER = MarkerManager.getMarker("PACKET_SENT", NetworkManager.logMarkerPackets);
    private final EnumPacketDirection direction;

    public MessageSerializer(EnumPacketDirection direction) {
        this.direction = direction;
    }

    protected void encode(ChannelHandlerContext p_1, Packet p_2, ByteBuf p_3) throws IOException, Exception {
        Integer integer = p_1.channel().attr(NetworkManager.attrKeyConnectionState).get().getPacketId(this.direction, p_2);
        if (logger.isDebugEnabled()) {
            logger.debug(
                RECEIVED_PACKET_MARKER, "OUT: [{}:{}] {}", p_1.channel().attr(NetworkManager.attrKeyConnectionState).get(), integer, p_2.getClass().getName()
            );
        }

        if (integer == null) {
            throw new IOException("Can't serialize unregistered packet");
        }

        PacketBuffer packetbuffer = new PacketBuffer(p_3);
        packetbuffer.writeVarIntToBuffer(integer);

        try {
            if (p_2 instanceof S0CPacketSpawnPlayer) {
                p_2 = p_2;
            }

            p_2.writePacketData(packetbuffer);
        } catch (Throwable throwable) {
            logger.error(throwable);
        }
    }
}
