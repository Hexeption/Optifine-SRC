package net.minecraft.util;

final class EnumFacing$1 {
    static final int[] field_179515_a;
    static final int[] field_179513_b;
    static final int[] field_179514_c = new int[EnumFacing.Plane.values().length];
    private static final String __OBFID = "CL_00002322";

    static {
        try {
            field_179514_c[EnumFacing.Plane.HORIZONTAL.ordinal()] = 1;
        } catch (NoSuchFieldError nosuchfielderror10) {
        }

        try {
            field_179514_c[EnumFacing.Plane.VERTICAL.ordinal()] = 2;
        } catch (NoSuchFieldError nosuchfielderror9) {
        }

        field_179513_b = new int[EnumFacing.values().length];

        try {
            field_179513_b[EnumFacing.NORTH.ordinal()] = 1;
        } catch (NoSuchFieldError nosuchfielderror8) {
        }

        try {
            field_179513_b[EnumFacing.EAST.ordinal()] = 2;
        } catch (NoSuchFieldError nosuchfielderror7) {
        }

        try {
            field_179513_b[EnumFacing.SOUTH.ordinal()] = 3;
        } catch (NoSuchFieldError nosuchfielderror6) {
        }

        try {
            field_179513_b[EnumFacing.WEST.ordinal()] = 4;
        } catch (NoSuchFieldError nosuchfielderror5) {
        }

        try {
            field_179513_b[EnumFacing.UP.ordinal()] = 5;
        } catch (NoSuchFieldError nosuchfielderror4) {
        }

        try {
            field_179513_b[EnumFacing.DOWN.ordinal()] = 6;
        } catch (NoSuchFieldError nosuchfielderror3) {
        }

        field_179515_a = new int[EnumFacing.Axis.values().length];

        try {
            field_179515_a[EnumFacing.Axis.X.ordinal()] = 1;
        } catch (NoSuchFieldError nosuchfielderror2) {
        }

        try {
            field_179515_a[EnumFacing.Axis.Y.ordinal()] = 2;
        } catch (NoSuchFieldError nosuchfielderror1) {
        }

        try {
            field_179515_a[EnumFacing.Axis.Z.ordinal()] = 3;
        } catch (NoSuchFieldError nosuchfielderror) {
        }
    }
}
