package net.minecraftforge.client.extensions.common;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.item.ItemStack;

public interface IClientItemExtensions {
    IClientItemExtensions DUMMY = new IClientItemExtensions() {};

    static IClientItemExtensions of(ItemStack itemStack) {
        return DUMMY;
    }

    default Font getFont(ItemStack stack, IClientItemExtensions.FontContext context) {
        return null;
    }

    default BlockEntityWithoutLevelRenderer getCustomRenderer() {
        return Minecraft.getInstance().getItemRenderer().getBlockEntityRenderer();
    }

    enum FontContext {
        ITEM_COUNT,
        TOOLTIP,
        SELECTED_ITEM_NAME;
    }
}
