package net.minecraft.util;

public class IntArray implements IIntArray {
    private final int[] array;

    public IntArray(int p_i50063_1_) {
        this.array = new int[p_i50063_1_];
    }

    @Override
    public int get(int index) {
        return this.array[index];
    }

    @Override
    public void set(int index, int value) {
        this.array[index] = value;
    }

    @Override
    public int size() {
        return this.array.length;
    }
}
