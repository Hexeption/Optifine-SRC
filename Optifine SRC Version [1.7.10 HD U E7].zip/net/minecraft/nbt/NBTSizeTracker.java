package net.minecraft.nbt;

public class NBTSizeTracker {
    public static final NBTSizeTracker INFINITE = new NBTSizeTracker(0L) {
        @Override
        public void addSpaceRead(long var1) {
        }
    };
    private final long spaceAllocated;
    private long spaceRead;

    public NBTSizeTracker(long var1) {
        this.spaceAllocated = var1;
    }

    public void addSpaceRead(long var1) {
        this.spaceRead += var1 / 8L;
        if (this.spaceRead > this.spaceAllocated) {
            throw new RuntimeException(
                "Tried to read NBT tag that was too big; tried to allocate: " + this.spaceRead + "bytes where max allowed: " + this.spaceAllocated
            );
        }
    }
}
