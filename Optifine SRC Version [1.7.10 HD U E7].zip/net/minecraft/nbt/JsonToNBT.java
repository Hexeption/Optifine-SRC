package net.minecraft.nbt;

import java.util.ArrayList;
import java.util.Stack;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class JsonToNBT {
    private static final Logger logger = LogManager.getLogger();

    public static NBTBase func_150315_a(String var0) throws NBTException {
        var0 = var0.trim();
        int i = func_150310_b(var0);
        if (i != 1) {
            throw new NBTException("Encountered multiple top tags, only one expected");
        }

        JsonToNBT.Any jsontonbt$any = null;
        if (var0.startsWith("{")) {
            jsontonbt$any = func_150316_a("tag", var0);
        } else {
            jsontonbt$any = func_150316_a(func_150313_b(var0, false), func_150311_c(var0, false));
        }

        return jsontonbt$any.func_150489_a();
    }

    static int func_150310_b(String var0) throws NBTException {
        int i = 0;
        boolean flag = false;
        Stack stack = new Stack();

        for (int j = 0; j < var0.length(); j++) {
            char c0 = var0.charAt(j);
            if (c0 == '"') {
                if (j > 0 && var0.charAt(j - 1) == '\\') {
                    if (!flag) {
                        throw new NBTException("Illegal use of \\\": " + var0);
                    }
                } else {
                    flag = !flag;
                }
            } else if (!flag) {
                if (c0 != '{' && c0 != '[') {
                    if (c0 == '}' && (stack.isEmpty() || (Character)stack.pop() != '{')) {
                        throw new NBTException("Unbalanced curly brackets {}: " + var0);
                    }

                    if (c0 == ']' && (stack.isEmpty() || (Character)stack.pop() != '[')) {
                        throw new NBTException("Unbalanced square brackets []: " + var0);
                    }
                } else {
                    if (stack.isEmpty()) {
                        i++;
                    }

                    stack.push(c0);
                }
            }
        }

        if (flag) {
            throw new NBTException("Unbalanced quotation: " + var0);
        } else if (!stack.isEmpty()) {
            throw new NBTException("Unbalanced brackets: " + var0);
        } else {
            return i == 0 && !var0.isEmpty() ? 1 : i;
        }
    }

    static JsonToNBT.Any func_150316_a(String var0, String var1) throws NBTException {
        var1 = var1.trim();
        func_150310_b(var1);
        if (var1.startsWith("{")) {
            if (!var1.endsWith("}")) {
                throw new NBTException("Unable to locate ending bracket for: " + var1);
            }

            var1 = var1.substring(1, var1.length() - 1);
            JsonToNBT.Compound jsontonbt$compound = new JsonToNBT.Compound(var0);

            while (var1.length() > 0) {
                String s3 = func_150314_a(var1, false);
                if (s3.length() > 0) {
                    String s4 = func_150313_b(s3, false);
                    String s5 = func_150311_c(s3, false);
                    jsontonbt$compound.field_150491_b.add(func_150316_a(s4, s5));
                    if (var1.length() < s3.length() + 1) {
                        break;
                    }

                    char c1 = var1.charAt(s3.length());
                    if (c1 != ',' && c1 != '{' && c1 != '}' && c1 != '[' && c1 != ']') {
                        throw new NBTException("Unexpected token '" + c1 + "' at: " + var1.substring(s3.length()));
                    }

                    var1 = var1.substring(s3.length() + 1);
                }
            }

            return jsontonbt$compound;
        } else {
            if (!var1.startsWith("[") || var1.matches("\\[[-\\d|,\\s]+\\]")) {
                return new JsonToNBT.Primitive(var0, var1);
            }

            if (!var1.endsWith("]")) {
                throw new NBTException("Unable to locate ending bracket for: " + var1);
            }

            var1 = var1.substring(1, var1.length() - 1);
            JsonToNBT.List jsontonbt$list = new JsonToNBT.List(var0);

            while (var1.length() > 0) {
                String s = func_150314_a(var1, true);
                if (s.length() > 0) {
                    String s1 = func_150313_b(s, true);
                    String s2 = func_150311_c(s, true);
                    jsontonbt$list.field_150492_b.add(func_150316_a(s1, s2));
                    if (var1.length() < s.length() + 1) {
                        break;
                    }

                    char c0 = var1.charAt(s.length());
                    if (c0 != ',' && c0 != '{' && c0 != '}' && c0 != '[' && c0 != ']') {
                        throw new NBTException("Unexpected token '" + c0 + "' at: " + var1.substring(s.length()));
                    }

                    var1 = var1.substring(s.length() + 1);
                } else {
                    logger.debug(var1);
                }
            }

            return jsontonbt$list;
        }
    }

    private static String func_150314_a(String var0, boolean var1) throws NBTException {
        int i = func_150312_a(var0, ':');
        if (i < 0 && !var1) {
            throw new NBTException("Unable to locate name/value separator for string: " + var0);
        }

        int j = func_150312_a(var0, ',');
        if (j >= 0 && j < i && !var1) {
            throw new NBTException("Name error at: " + var0);
        }

        if (var1 && (i < 0 || i > j)) {
            i = -1;
        }

        Stack stack = new Stack();
        int k = i + 1;
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        int l = 0;

        while (k < var0.length()) {
            char c0 = var0.charAt(k);
            if (c0 == '"') {
                if (k > 0 && var0.charAt(k - 1) == '\\') {
                    if (!flag) {
                        throw new NBTException("Illegal use of \\\": " + var0);
                    }
                } else {
                    flag = !flag;
                    if (flag && !flag2) {
                        flag1 = true;
                    }

                    if (!flag) {
                        l = k;
                    }
                }
            } else if (!flag) {
                if (c0 != '{' && c0 != '[') {
                    if (c0 == '}' && (stack.isEmpty() || (Character)stack.pop() != '{')) {
                        throw new NBTException("Unbalanced curly brackets {}: " + var0);
                    }

                    if (c0 == ']' && (stack.isEmpty() || (Character)stack.pop() != '[')) {
                        throw new NBTException("Unbalanced square brackets []: " + var0);
                    }

                    if (c0 == ',' && stack.isEmpty()) {
                        return var0.substring(0, k);
                    }
                } else {
                    stack.push(c0);
                }
            }

            if (!Character.isWhitespace(c0)) {
                if (!flag && flag1 && l != k) {
                    return var0.substring(0, l + 1);
                }

                flag2 = true;
            }

            k++;
        }

        return var0.substring(0, k);
    }

    private static String func_150313_b(String var0, boolean var1) throws NBTException {
        if (var1) {
            var0 = var0.trim();
            if (var0.startsWith("{") || var0.startsWith("[")) {
                return "";
            }
        }

        int i = var0.indexOf(58);
        if (i >= 0) {
            return var0.substring(0, i).trim();
        } else if (var1) {
            return "";
        } else {
            throw new NBTException("Unable to locate name/value separator for string: " + var0);
        }
    }

    private static String func_150311_c(String var0, boolean var1) throws NBTException {
        if (var1) {
            var0 = var0.trim();
            if (var0.startsWith("{") || var0.startsWith("[")) {
                return var0;
            }
        }

        int i = var0.indexOf(58);
        if (i >= 0) {
            return var0.substring(i + 1).trim();
        } else if (var1) {
            return var0;
        } else {
            throw new NBTException("Unable to locate name/value separator for string: " + var0);
        }
    }

    private static int func_150312_a(String var0, char var1) {
        int i = 0;
        boolean flag = false;

        while (i < var0.length()) {
            char c0 = var0.charAt(i);
            if (c0 == '"') {
                if (i <= 0 || var0.charAt(i - 1) != '\\') {
                    flag = !flag;
                }
            } else if (!flag) {
                if (c0 == var1) {
                    return i;
                }

                if (c0 == '{' || c0 == '[') {
                    return -1;
                }
            }

            i++;
        }

        return -1;
    }

    abstract static class Any {
        protected String field_150490_a;

        public abstract NBTBase func_150489_a();
    }

    static class Compound extends JsonToNBT.Any {
        protected ArrayList field_150491_b = new ArrayList();

        public Compound(String var1) {
            this.field_150490_a = var1;
        }

        @Override
        public NBTBase func_150489_a() {
            NBTTagCompound nbttagcompound = new NBTTagCompound();

            for (JsonToNBT.Any jsontonbt$any : (Iterable<JsonToNBT.Any>) (Iterable) this.field_150491_b) {
                nbttagcompound.setTag(jsontonbt$any.field_150490_a, jsontonbt$any.func_150489_a());
            }

            return nbttagcompound;
        }
    }

    static class List extends JsonToNBT.Any {
        protected ArrayList field_150492_b = new ArrayList();

        public List(String var1) {
            this.field_150490_a = var1;
        }

        @Override
        public NBTBase func_150489_a() {
            NBTTagList nbttaglist = new NBTTagList();

            for (JsonToNBT.Any jsontonbt$any : (Iterable<JsonToNBT.Any>) (Iterable) this.field_150492_b) {
                nbttaglist.appendTag(jsontonbt$any.func_150489_a());
            }

            return nbttaglist;
        }
    }

    static class Primitive extends JsonToNBT.Any {
        protected String field_150493_b;

        public Primitive(String var1, String var2) {
            this.field_150490_a = var1;
            this.field_150493_b = var2;
        }

        @Override
        public NBTBase func_150489_a() {
            try {
                if (this.field_150493_b.matches("[-+]?[0-9]*\\.?[0-9]+[d|D]")) {
                    return new NBTTagDouble(Double.parseDouble(this.field_150493_b.substring(0, this.field_150493_b.length() - 1)));
                }

                if (this.field_150493_b.matches("[-+]?[0-9]*\\.?[0-9]+[f|F]")) {
                    return new NBTTagFloat(Float.parseFloat(this.field_150493_b.substring(0, this.field_150493_b.length() - 1)));
                }

                if (this.field_150493_b.matches("[-+]?[0-9]+[b|B]")) {
                    return new NBTTagByte(Byte.parseByte(this.field_150493_b.substring(0, this.field_150493_b.length() - 1)));
                }

                if (this.field_150493_b.matches("[-+]?[0-9]+[l|L]")) {
                    return new NBTTagLong(Long.parseLong(this.field_150493_b.substring(0, this.field_150493_b.length() - 1)));
                }

                if (this.field_150493_b.matches("[-+]?[0-9]+[s|S]")) {
                    return new NBTTagShort(Short.parseShort(this.field_150493_b.substring(0, this.field_150493_b.length() - 1)));
                }

                if (this.field_150493_b.matches("[-+]?[0-9]+")) {
                    return new NBTTagInt(Integer.parseInt(this.field_150493_b.substring(0, this.field_150493_b.length())));
                }

                if (this.field_150493_b.matches("[-+]?[0-9]*\\.?[0-9]+")) {
                    return new NBTTagDouble(Double.parseDouble(this.field_150493_b.substring(0, this.field_150493_b.length())));
                }

                if (this.field_150493_b.equalsIgnoreCase("true") || this.field_150493_b.equalsIgnoreCase("false")) {
                    return new NBTTagByte((byte)(Boolean.parseBoolean(this.field_150493_b) ? 1 : 0));
                }

                if (this.field_150493_b.startsWith("[") && this.field_150493_b.endsWith("]")) {
                    if (this.field_150493_b.length() > 2) {
                        String s = this.field_150493_b.substring(1, this.field_150493_b.length() - 1);
                        String[] astring = s.split(",");

                        try {
                            if (astring.length <= 1) {
                                return new NBTTagIntArray(new int[]{Integer.parseInt(s.trim())});
                            }

                            int[] aint = new int[astring.length];

                            for (int i = 0; i < astring.length; i++) {
                                aint[i] = Integer.parseInt(astring[i].trim());
                            }

                            return new NBTTagIntArray(aint);
                        } catch (NumberFormatException numberformatexception) {
                            return new NBTTagString(this.field_150493_b);
                        }
                    } else {
                        return new NBTTagIntArray();
                    }
                } else {
                    if (this.field_150493_b.startsWith("\"") && this.field_150493_b.endsWith("\"") && this.field_150493_b.length() > 2) {
                        this.field_150493_b = this.field_150493_b.substring(1, this.field_150493_b.length() - 1);
                    }

                    this.field_150493_b = this.field_150493_b.replaceAll("\\\\\"", "\"");
                    return new NBTTagString(this.field_150493_b);
                }
            } catch (NumberFormatException numberformatexception1) {
                this.field_150493_b = this.field_150493_b.replaceAll("\\\\\"", "\"");
                return new NBTTagString(this.field_150493_b);
            }
        }
    }
}
