package net.minecraft.nbt;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.util.UUID;
import net.minecraft.util.StringUtils;

public final class NBTUtil {
    public static GameProfile readGameProfileFromNBT(NBTTagCompound var0) {
        String s = null;
        String s1 = null;
        if (var0.hasKey("Name", 8)) {
            s = var0.getString("Name");
        }

        if (var0.hasKey("Id", 8)) {
            s1 = var0.getString("Id");
        }

        if (StringUtils.isNullOrEmpty(s) && StringUtils.isNullOrEmpty(s1)) {
            return null;
        }

        UUID uuid;
        try {
            uuid = UUID.fromString(s1);
        } catch (Throwable throwable) {
            uuid = null;
        }

        GameProfile gameprofile = new GameProfile(uuid, s);
        if (var0.hasKey("Properties", 10)) {
            NBTTagCompound nbttagcompound = var0.getCompoundTag("Properties");

            for (String s2 : (Iterable<String>) (Iterable) nbttagcompound.getKeySet()) {
                NBTTagList nbttaglist = nbttagcompound.getTagList(s2, 10);

                for (int i = 0; i < nbttaglist.tagCount(); i++) {
                    NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
                    String s3 = nbttagcompound1.getString("Value");
                    if (nbttagcompound1.hasKey("Signature", 8)) {
                        gameprofile.getProperties().put(s2, new Property(s2, s3, nbttagcompound1.getString("Signature")));
                    } else {
                        gameprofile.getProperties().put(s2, new Property(s2, s3));
                    }
                }
            }
        }

        return gameprofile;
    }

    public static void writeGameProfileToNBT(NBTTagCompound var0, GameProfile var1) {
        if (!StringUtils.isNullOrEmpty(var1.getName())) {
            var0.setString("Name", var1.getName());
        }

        if (var1.getId() != null) {
            var0.setString("Id", var1.getId().toString());
        }

        if (!var1.getProperties().isEmpty()) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();

            for (String s : var1.getProperties().keySet()) {
                NBTTagList nbttaglist = new NBTTagList();

                for (Property property : var1.getProperties().get(s)) {
                    NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                    nbttagcompound1.setString("Value", property.getValue());
                    if (property.hasSignature()) {
                        nbttagcompound1.setString("Signature", property.getSignature());
                    }

                    nbttaglist.appendTag(nbttagcompound1);
                }

                nbttagcompound.setTag(s, nbttaglist);
            }

            var0.setTag("Properties", nbttagcompound);
        }
    }
}
