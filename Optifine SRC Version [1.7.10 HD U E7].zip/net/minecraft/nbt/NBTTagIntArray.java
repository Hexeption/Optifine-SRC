package net.minecraft.nbt;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

public class NBTTagIntArray extends NBTBase {
    private int[] intArray;

    NBTTagIntArray() {
    }

    public NBTTagIntArray(int[] var1) {
        this.intArray = var1;
    }

    @Override
    void write(DataOutput var1) throws IOException {
        var1.writeInt(this.intArray.length);

        for (int i = 0; i < this.intArray.length; i++) {
            var1.writeInt(this.intArray[i]);
        }
    }

    @Override
    void read(DataInput var1, int var2, NBTSizeTracker var3) throws IOException {
        int i = var1.readInt();
        var3.addSpaceRead(32 * i);
        this.intArray = new int[i];

        for (int j = 0; j < i; j++) {
            this.intArray[j] = var1.readInt();
        }
    }

    @Override
    public byte getId() {
        return 11;
    }

    @Override
    public String toString() {
        String s = "[";

        for (int i : this.intArray) {
            s = s + i + ",";
        }

        return s + "]";
    }

    @Override
    public NBTBase copy() {
        int[] aint = new int[this.intArray.length];
        System.arraycopy(this.intArray, 0, aint, 0, this.intArray.length);
        return new NBTTagIntArray(aint);
    }

    @Override
    public boolean equals(Object var1) {
        return super.equals(var1) ? Arrays.equals(this.intArray, ((NBTTagIntArray)var1).intArray) : false;
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ Arrays.hashCode(this.intArray);
    }

    public int[] getIntArray() {
        return this.intArray;
    }
}
