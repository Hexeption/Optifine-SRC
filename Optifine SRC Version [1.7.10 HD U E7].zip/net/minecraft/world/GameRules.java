package net.minecraft.world;

import java.util.TreeMap;
import net.minecraft.nbt.NBTTagCompound;

public class GameRules {
    private TreeMap theGameRules = new TreeMap();
    private static final String __OBFID = "CL_00000136";

    public GameRules() {
        this.addGameRule("doFireTick", "true");
        this.addGameRule("mobGriefing", "true");
        this.addGameRule("keepInventory", "false");
        this.addGameRule("doMobSpawning", "true");
        this.addGameRule("doMobLoot", "true");
        this.addGameRule("doTileDrops", "true");
        this.addGameRule("commandBlockOutput", "true");
        this.addGameRule("naturalRegeneration", "true");
        this.addGameRule("doDaylightCycle", "true");
    }

    public void addGameRule(String par1Str, String par2Str) {
        this.theGameRules.put(par1Str, new GameRules.Value(par2Str));
    }

    public void setOrCreateGameRule(String par1Str, String par2Str) {
        GameRules.Value gamerules$value = (GameRules.Value)this.theGameRules.get(par1Str);
        if (gamerules$value != null) {
            gamerules$value.setValue(par2Str);
        } else {
            this.addGameRule(par1Str, par2Str);
        }
    }

    public String getGameRuleStringValue(String par1Str) {
        GameRules.Value gamerules$value = (GameRules.Value)this.theGameRules.get(par1Str);
        return gamerules$value != null ? gamerules$value.getGameRuleStringValue() : "";
    }

    public boolean getGameRuleBooleanValue(String par1Str) {
        GameRules.Value gamerules$value = (GameRules.Value)this.theGameRules.get(par1Str);
        return gamerules$value != null ? gamerules$value.getGameRuleBooleanValue() : false;
    }

    public NBTTagCompound writeGameRulesToNBT() {
        NBTTagCompound nbttagcompound = new NBTTagCompound();

        for (String s : (Iterable<String>) (Iterable) this.theGameRules.keySet()) {
            GameRules.Value gamerules$value = (GameRules.Value)this.theGameRules.get(s);
            nbttagcompound.setString(s, gamerules$value.getGameRuleStringValue());
        }

        return nbttagcompound;
    }

    public void readGameRulesFromNBT(NBTTagCompound par1NBTTagCompound) {
        for (String s : (Iterable<String>) (Iterable) par1NBTTagCompound.getKeySet()) {
            String s1 = par1NBTTagCompound.getString(s);
            this.setOrCreateGameRule(s, s1);
        }
    }

    public String[] getRules() {
        return ((String[]) this.theGameRules.keySet().toArray(new String[0]));
    }

    public boolean hasRule(String par1Str) {
        return this.theGameRules.containsKey(par1Str);
    }

    static class Value {
        private String valueString;
        private boolean valueBoolean;
        private int valueInteger;
        private double valueDouble;
        private static final String __OBFID = "CL_00000137";

        public Value(String par1Str) {
            this.setValue(par1Str);
        }

        public void setValue(String par1Str) {
            this.valueString = par1Str;
            if (par1Str != null) {
                if (par1Str.equals("false")) {
                    this.valueBoolean = false;
                    return;
                }

                if (par1Str.equals("true")) {
                    this.valueBoolean = true;
                    return;
                }
            }

            this.valueBoolean = Boolean.parseBoolean(par1Str);

            try {
                this.valueInteger = Integer.parseInt(par1Str);
            } catch (NumberFormatException numberformatexception1) {
            }

            try {
                this.valueDouble = Double.parseDouble(par1Str);
            } catch (NumberFormatException numberformatexception) {
            }
        }

        public String getGameRuleStringValue() {
            return this.valueString;
        }

        public boolean getGameRuleBooleanValue() {
            return this.valueBoolean;
        }
    }
}
