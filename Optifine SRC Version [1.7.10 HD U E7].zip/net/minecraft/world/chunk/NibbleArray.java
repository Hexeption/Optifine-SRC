package net.minecraft.world.chunk;

public class NibbleArray {
    public final byte[] data;
    private final int depthBits;
    private final int depthBitsPlusFour;

    public NibbleArray(int var1, int var2) {
        this.data = new byte[var1 >> 1];
        this.depthBits = var2;
        this.depthBitsPlusFour = var2 + 4;
    }

    public NibbleArray(byte[] var1, int var2) {
        this.data = var1;
        this.depthBits = var2;
        this.depthBitsPlusFour = var2 + 4;
    }

    public int get(int var1, int var2, int var3) {
        int i = var2 << this.depthBitsPlusFour | var3 << this.depthBits | var1;
        int j = i >> 1;
        int k = i & 1;
        return k == 0 ? this.data[j] & 15 : this.data[j] >> 4 & 15;
    }

    public void set(int var1, int var2, int var3, int var4) {
        int i = var2 << this.depthBitsPlusFour | var3 << this.depthBits | var1;
        int j = i >> 1;
        int k = i & 1;
        if (k == 0) {
            this.data[j] = (byte)(this.data[j] & 240 | var4 & 15);
        } else {
            this.data[j] = (byte)(this.data[j] & 15 | (var4 & 15) << 4);
        }
    }
}
