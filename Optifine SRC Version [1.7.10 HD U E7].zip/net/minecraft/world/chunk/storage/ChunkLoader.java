package net.minecraft.world.chunk.storage;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.chunk.NibbleArray;

public class ChunkLoader {
    public static ChunkLoader.AnvilConverterData load(NBTTagCompound var0) {
        int i = var0.getInteger("xPos");
        int j = var0.getInteger("zPos");
        ChunkLoader.AnvilConverterData chunkloader$anvilconverterdata = new ChunkLoader.AnvilConverterData(i, j);
        chunkloader$anvilconverterdata.blocks = var0.getByteArray("Blocks");
        chunkloader$anvilconverterdata.data = new NibbleArrayReader(var0.getByteArray("Data"), 7);
        chunkloader$anvilconverterdata.skyLight = new NibbleArrayReader(var0.getByteArray("SkyLight"), 7);
        chunkloader$anvilconverterdata.blockLight = new NibbleArrayReader(var0.getByteArray("BlockLight"), 7);
        chunkloader$anvilconverterdata.heightmap = var0.getByteArray("HeightMap");
        chunkloader$anvilconverterdata.terrainPopulated = var0.getBoolean("TerrainPopulated");
        chunkloader$anvilconverterdata.entities = var0.getTagList("Entities", 10);
        chunkloader$anvilconverterdata.field_151564_i = var0.getTagList("TileEntities", 10);
        chunkloader$anvilconverterdata.field_151563_j = var0.getTagList("TileTicks", 10);

        try {
            chunkloader$anvilconverterdata.lastUpdated = var0.getLong("LastUpdate");
        } catch (ClassCastException classcastexception) {
            chunkloader$anvilconverterdata.lastUpdated = var0.getInteger("LastUpdate");
        }

        return chunkloader$anvilconverterdata;
    }

    public static void convertToAnvilFormat(ChunkLoader.AnvilConverterData var0, NBTTagCompound var1, WorldChunkManager var2) {
        var1.setInteger("xPos", var0.x);
        var1.setInteger("zPos", var0.z);
        var1.setLong("LastUpdate", var0.lastUpdated);
        int[] aint = new int[var0.heightmap.length];

        for (int i = 0; i < var0.heightmap.length; i++) {
            aint[i] = var0.heightmap[i];
        }

        var1.setIntArray("HeightMap", aint);
        var1.setBoolean("TerrainPopulated", var0.terrainPopulated);
        NBTTagList nbttaglist = new NBTTagList();

        for (int j = 0; j < 8; j++) {
            boolean flag = true;

            for (int k = 0; k < 16 && flag; k++) {
                for (int l = 0; l < 16 && flag; l++) {
                    for (int i1 = 0; i1 < 16; i1++) {
                        int j1 = k << 11 | i1 << 7 | l + (j << 4);
                        byte b0 = var0.blocks[j1];
                        if (b0 != 0) {
                            flag = false;
                            break;
                        }
                    }
                }
            }

            if (!flag) {
                byte[] abyte1 = new byte[4096];
                NibbleArray nibblearray = new NibbleArray(abyte1.length, 4);
                NibbleArray nibblearray1 = new NibbleArray(abyte1.length, 4);
                NibbleArray nibblearray2 = new NibbleArray(abyte1.length, 4);

                for (int l2 = 0; l2 < 16; l2++) {
                    for (int k1 = 0; k1 < 16; k1++) {
                        for (int l1 = 0; l1 < 16; l1++) {
                            int i2 = l2 << 11 | l1 << 7 | k1 + (j << 4);
                            byte b1 = var0.blocks[i2];
                            abyte1[k1 << 8 | l1 << 4 | l2] = (byte)(b1 & 0xFF);
                            nibblearray.set(l2, k1, l1, var0.data.get(l2, k1 + (j << 4), l1));
                            nibblearray1.set(l2, k1, l1, var0.skyLight.get(l2, k1 + (j << 4), l1));
                            nibblearray2.set(l2, k1, l1, var0.blockLight.get(l2, k1 + (j << 4), l1));
                        }
                    }
                }

                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Y", (byte)(j & 0xFF));
                nbttagcompound.setByteArray("Blocks", abyte1);
                nbttagcompound.setByteArray("Data", nibblearray.data);
                nbttagcompound.setByteArray("SkyLight", nibblearray1.data);
                nbttagcompound.setByteArray("BlockLight", nibblearray2.data);
                nbttaglist.appendTag(nbttagcompound);
            }
        }

        var1.setTag("Sections", nbttaglist);
        byte[] abyte = new byte[256];

        for (int j2 = 0; j2 < 16; j2++) {
            for (int k2 = 0; k2 < 16; k2++) {
                abyte[k2 << 4 | j2] = (byte)(var2.getBiomeGenAt(var0.x << 4 | j2, var0.z << 4 | k2).biomeID & 0xFF);
            }
        }

        var1.setByteArray("Biomes", abyte);
        var1.setTag("Entities", var0.entities);
        var1.setTag("TileEntities", var0.field_151564_i);
        if (var0.field_151563_j != null) {
            var1.setTag("TileTicks", var0.field_151563_j);
        }
    }

    public static class AnvilConverterData {
        public long lastUpdated;
        public boolean terrainPopulated;
        public byte[] heightmap;
        public NibbleArrayReader blockLight;
        public NibbleArrayReader skyLight;
        public NibbleArrayReader data;
        public byte[] blocks;
        public NBTTagList entities;
        public NBTTagList field_151564_i;
        public NBTTagList field_151563_j;
        public final int x;
        public final int z;

        public AnvilConverterData(int var1, int var2) {
            this.x = var1;
            this.z = var2;
        }
    }
}
