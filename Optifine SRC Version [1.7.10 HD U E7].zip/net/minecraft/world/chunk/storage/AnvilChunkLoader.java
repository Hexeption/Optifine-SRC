package net.minecraft.world.chunk.storage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.MinecraftException;
import net.minecraft.world.NextTickListEntry;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.NibbleArray;
import net.minecraft.world.storage.IThreadedFileIO;
import net.minecraft.world.storage.ThreadedFileIOBase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AnvilChunkLoader implements IChunkLoader, IThreadedFileIO {
    private static final Logger logger = LogManager.getLogger();
    private List chunksToRemove = new ArrayList();
    private Set pendingAnvilChunksCoordinates = new HashSet();
    private Object syncLockObject = new Object();
    private final File chunkSaveLocation;

    public AnvilChunkLoader(File var1) {
        this.chunkSaveLocation = var1;
    }

    @Override
    public Chunk loadChunk(World var1, int var2, int var3) throws IOException {
        NBTTagCompound nbttagcompound = null;
        ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(var2, var3);
        synchronized (this.syncLockObject) {
            if (this.pendingAnvilChunksCoordinates.contains(chunkcoordintpair)) {
                for (int i = 0; i < this.chunksToRemove.size(); i++) {
                    if (((AnvilChunkLoader.PendingChunk)this.chunksToRemove.get(i)).chunkCoordinate.equals(chunkcoordintpair)) {
                        nbttagcompound = ((AnvilChunkLoader.PendingChunk)this.chunksToRemove.get(i)).nbtTags;
                        break;
                    }
                }
            }
        }

        if (nbttagcompound == null) {
            DataInputStream datainputstream = RegionFileCache.getChunkInputStream(this.chunkSaveLocation, var2, var3);
            if (datainputstream == null) {
                return null;
            }

            nbttagcompound = CompressedStreamTools.read(datainputstream);
        }

        return this.checkedReadChunkFromNBT(var1, var2, var3, nbttagcompound);
    }

    protected Chunk checkedReadChunkFromNBT(World var1, int var2, int var3, NBTTagCompound var4) {
        if (!var4.hasKey("Level", 10)) {
            logger.error("Chunk file at " + var2 + "," + var3 + " is missing level data, skipping");
            return null;
        }

        if (!var4.getCompoundTag("Level").hasKey("Sections", 9)) {
            logger.error("Chunk file at " + var2 + "," + var3 + " is missing block data, skipping");
            return null;
        }

        Chunk chunk = this.readChunkFromNBT(var1, var4.getCompoundTag("Level"));
        if (!chunk.isAtLocation(var2, var3)) {
            logger.error(
                "Chunk file at "
                    + var2
                    + ","
                    + var3
                    + " is in the wrong location; relocating. (Expected "
                    + var2
                    + ", "
                    + var3
                    + ", got "
                    + chunk.xPosition
                    + ", "
                    + chunk.zPosition
                    + ")"
            );
            var4.setInteger("xPos", var2);
            var4.setInteger("zPos", var3);
            chunk = this.readChunkFromNBT(var1, var4.getCompoundTag("Level"));
        }

        return chunk;
    }

    @Override
    public void saveChunk(World var1, Chunk var2) throws IOException, MinecraftException {
        var1.checkSessionLock();

        try {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            nbttagcompound.setTag("Level", nbttagcompound1);
            this.writeChunkToNBT(var2, var1, nbttagcompound1);
            this.addChunkToPending(var2.getChunkCoordIntPair(), nbttagcompound);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    protected void addChunkToPending(ChunkCoordIntPair var1, NBTTagCompound var2) {
        synchronized (this.syncLockObject) {
            if (this.pendingAnvilChunksCoordinates.contains(var1)) {
                for (int i = 0; i < this.chunksToRemove.size(); i++) {
                    if (((AnvilChunkLoader.PendingChunk)this.chunksToRemove.get(i)).chunkCoordinate.equals(var1)) {
                        this.chunksToRemove.set(i, new AnvilChunkLoader.PendingChunk(var1, var2));
                        return;
                    }
                }
            }

            this.chunksToRemove.add(new AnvilChunkLoader.PendingChunk(var1, var2));
            this.pendingAnvilChunksCoordinates.add(var1);
            ThreadedFileIOBase.threadedIOInstance.queueIO(this);
        }
    }

    @Override
    public boolean writeNextIO() {
        AnvilChunkLoader.PendingChunk anvilchunkloader$pendingchunk = null;
        synchronized (this.syncLockObject) {
            if (this.chunksToRemove.isEmpty()) {
                return false;
            }

            anvilchunkloader$pendingchunk = (AnvilChunkLoader.PendingChunk)this.chunksToRemove.remove(0);
            this.pendingAnvilChunksCoordinates.remove(anvilchunkloader$pendingchunk.chunkCoordinate);
        }

        if (anvilchunkloader$pendingchunk != null) {
            try {
                this.writeChunkNBTTags(anvilchunkloader$pendingchunk);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

        return true;
    }

    private void writeChunkNBTTags(AnvilChunkLoader.PendingChunk var1) throws IOException {
        DataOutputStream dataoutputstream = RegionFileCache.getChunkOutputStream(
            this.chunkSaveLocation, var1.chunkCoordinate.chunkXPos, var1.chunkCoordinate.chunkZPos
        );
        CompressedStreamTools.write(var1.nbtTags, dataoutputstream);
        dataoutputstream.close();
    }

    @Override
    public void saveExtraChunkData(World var1, Chunk var2) {
    }

    @Override
    public void chunkTick() {
    }

    @Override
    public void saveExtraData() {
        while (this.writeNextIO()) {
        }
    }

    private void writeChunkToNBT(Chunk var1, World var2, NBTTagCompound var3) {
        var3.setByte("V", (byte)1);
        var3.setInteger("xPos", var1.xPosition);
        var3.setInteger("zPos", var1.zPosition);
        var3.setLong("LastUpdate", var2.getTotalWorldTime());
        var3.setIntArray("HeightMap", var1.heightMap);
        var3.setBoolean("TerrainPopulated", var1.isTerrainPopulated);
        var3.setBoolean("LightPopulated", var1.isLightPopulated);
        var3.setLong("InhabitedTime", var1.inhabitedTime);
        ExtendedBlockStorage[] aextendedblockstorage = var1.getBlockStorageArray();
        NBTTagList nbttaglist = new NBTTagList();
        boolean flag = !var2.provider.hasNoSky;

        for (ExtendedBlockStorage extendedblockstorage : aextendedblockstorage) {
            if (extendedblockstorage != null) {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Y", (byte)(extendedblockstorage.getYLocation() >> 4 & 0xFF));
                nbttagcompound.setByteArray("Blocks", extendedblockstorage.getBlockLSBArray());
                if (extendedblockstorage.getBlockMSBArray() != null) {
                    nbttagcompound.setByteArray("Add", extendedblockstorage.getBlockMSBArray().data);
                }

                nbttagcompound.setByteArray("Data", extendedblockstorage.getMetadataArray().data);
                nbttagcompound.setByteArray("BlockLight", extendedblockstorage.getBlocklightArray().data);
                if (flag) {
                    nbttagcompound.setByteArray("SkyLight", extendedblockstorage.getSkylightArray().data);
                } else {
                    nbttagcompound.setByteArray("SkyLight", new byte[extendedblockstorage.getBlocklightArray().data.length]);
                }

                nbttaglist.appendTag(nbttagcompound);
            }
        }

        var3.setTag("Sections", nbttaglist);
        var3.setByteArray("Biomes", var1.getBiomeArray());
        var1.hasEntities = false;
        NBTTagList nbttaglist2 = new NBTTagList();

        for (int i = 0; i < var1.entityLists.length; i++) {
            for (Entity entity : (Iterable<Entity>) (Iterable) var1.entityLists[i]) {
                NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                if (entity.writeToNBTOptional(nbttagcompound2)) {
                    var1.hasEntities = true;
                    nbttaglist2.appendTag(nbttagcompound2);
                }
            }
        }

        var3.setTag("Entities", nbttaglist2);
        NBTTagList nbttaglist3 = new NBTTagList();

        for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) var1.chunkTileEntityMap.values()) {
            NBTTagCompound nbttagcompound3 = new NBTTagCompound();
            tileentity.writeToNBT(nbttagcompound3);
            nbttaglist3.appendTag(nbttagcompound3);
        }

        var3.setTag("TileEntities", nbttaglist3);
        List list = var2.getPendingBlockUpdates(var1, false);
        if (list != null) {
            long j = var2.getTotalWorldTime();
            NBTTagList nbttaglist1 = new NBTTagList();

            for (NextTickListEntry nextticklistentry : (Iterable<NextTickListEntry>) (Iterable) list) {
                NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.setInteger("i", Block.getIdFromBlock(nextticklistentry.func_151351_a()));
                nbttagcompound1.setInteger("x", nextticklistentry.xCoord);
                nbttagcompound1.setInteger("y", nextticklistentry.yCoord);
                nbttagcompound1.setInteger("z", nextticklistentry.zCoord);
                nbttagcompound1.setInteger("t", (int)(nextticklistentry.scheduledTime - j));
                nbttagcompound1.setInteger("p", nextticklistentry.priority);
                nbttaglist1.appendTag(nbttagcompound1);
            }

            var3.setTag("TileTicks", nbttaglist1);
        }
    }

    private Chunk readChunkFromNBT(World var1, NBTTagCompound var2) {
        int i = var2.getInteger("xPos");
        int j = var2.getInteger("zPos");
        Chunk chunk = new Chunk(var1, i, j);
        chunk.heightMap = var2.getIntArray("HeightMap");
        chunk.isTerrainPopulated = var2.getBoolean("TerrainPopulated");
        chunk.isLightPopulated = var2.getBoolean("LightPopulated");
        chunk.inhabitedTime = var2.getLong("InhabitedTime");
        NBTTagList nbttaglist = var2.getTagList("Sections", 10);
        byte b0 = 16;
        ExtendedBlockStorage[] aextendedblockstorage = new ExtendedBlockStorage[b0];
        boolean flag = !var1.provider.hasNoSky;

        for (int k = 0; k < nbttaglist.tagCount(); k++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(k);
            byte b1 = nbttagcompound.getByte("Y");
            ExtendedBlockStorage extendedblockstorage = new ExtendedBlockStorage(b1 << 4, flag);
            extendedblockstorage.setBlockLSBArray(nbttagcompound.getByteArray("Blocks"));
            if (nbttagcompound.hasKey("Add", 7)) {
                extendedblockstorage.setBlockMSBArray(new NibbleArray(nbttagcompound.getByteArray("Add"), 4));
            }

            extendedblockstorage.setBlockMetadataArray(new NibbleArray(nbttagcompound.getByteArray("Data"), 4));
            extendedblockstorage.setBlocklightArray(new NibbleArray(nbttagcompound.getByteArray("BlockLight"), 4));
            if (flag) {
                extendedblockstorage.setSkylightArray(new NibbleArray(nbttagcompound.getByteArray("SkyLight"), 4));
            }

            extendedblockstorage.removeInvalidBlocks();
            aextendedblockstorage[b1] = extendedblockstorage;
        }

        chunk.setStorageArrays(aextendedblockstorage);
        if (var2.hasKey("Biomes", 7)) {
            chunk.setBiomeArray(var2.getByteArray("Biomes"));
        }

        NBTTagList nbttaglist1 = var2.getTagList("Entities", 10);
        if (nbttaglist1 != null) {
            for (int l = 0; l < nbttaglist1.tagCount(); l++) {
                NBTTagCompound nbttagcompound2 = nbttaglist1.getCompoundTagAt(l);
                Entity entity2 = EntityList.createEntityFromNBT(nbttagcompound2, var1);
                chunk.hasEntities = true;
                if (entity2 != null) {
                    chunk.addEntity(entity2);
                    Entity entity = entity2;

                    for (NBTTagCompound nbttagcompound1 = nbttagcompound2;
                        nbttagcompound1.hasKey("Riding", 10);
                        nbttagcompound1 = nbttagcompound1.getCompoundTag("Riding")
                    ) {
                        Entity entity1 = EntityList.createEntityFromNBT(nbttagcompound1.getCompoundTag("Riding"), var1);
                        if (entity1 != null) {
                            chunk.addEntity(entity1);
                            entity.mountEntity(entity1);
                        }

                        entity = entity1;
                    }
                }
            }
        }

        NBTTagList nbttaglist2 = var2.getTagList("TileEntities", 10);
        if (nbttaglist2 != null) {
            for (int i1 = 0; i1 < nbttaglist2.tagCount(); i1++) {
                NBTTagCompound nbttagcompound3 = nbttaglist2.getCompoundTagAt(i1);
                TileEntity tileentity = TileEntity.createAndLoadEntity(nbttagcompound3);
                if (tileentity != null) {
                    chunk.addTileEntity(tileentity);
                }
            }
        }

        if (var2.hasKey("TileTicks", 9)) {
            NBTTagList nbttaglist3 = var2.getTagList("TileTicks", 10);
            if (nbttaglist3 != null) {
                for (int j1 = 0; j1 < nbttaglist3.tagCount(); j1++) {
                    NBTTagCompound nbttagcompound4 = nbttaglist3.getCompoundTagAt(j1);
                    var1.func_147446_b(
                        nbttagcompound4.getInteger("x"),
                        nbttagcompound4.getInteger("y"),
                        nbttagcompound4.getInteger("z"),
                        Block.getBlockById(nbttagcompound4.getInteger("i")),
                        nbttagcompound4.getInteger("t"),
                        nbttagcompound4.getInteger("p")
                    );
                }
            }
        }

        return chunk;
    }

    static class PendingChunk {
        public final ChunkCoordIntPair chunkCoordinate;
        public final NBTTagCompound nbtTags;

        public PendingChunk(ChunkCoordIntPair var1, NBTTagCompound var2) {
            this.chunkCoordinate = var1;
            this.nbtTags = var2;
        }
    }
}
