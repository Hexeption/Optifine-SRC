package net.minecraft.world;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.enchantment.EnchantmentProtection;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class Explosion {
    public boolean isFlaming;
    public boolean isSmoking = true;
    private int field_77289_h = 16;
    private Random explosionRNG = new Random();
    private World worldObj;
    public double explosionX;
    public double explosionY;
    public double explosionZ;
    public Entity exploder;
    public float explosionSize;
    public List affectedBlockPositions = new ArrayList();
    private Map field_77288_k = new HashMap();

    public Explosion(World var1, Entity var2, double var3, double var5, double var7, float var9) {
        this.worldObj = var1;
        this.exploder = var2;
        this.explosionSize = var9;
        this.explosionX = var3;
        this.explosionY = var5;
        this.explosionZ = var7;
    }

    public void doExplosionA() {
        float f = this.explosionSize;
        HashSet hashset = new HashSet();

        for (int i = 0; i < this.field_77289_h; i++) {
            for (int j = 0; j < this.field_77289_h; j++) {
                for (int k = 0; k < this.field_77289_h; k++) {
                    if (i == 0 || i == this.field_77289_h - 1 || j == 0 || j == this.field_77289_h - 1 || k == 0 || k == this.field_77289_h - 1) {
                        double d0 = i / (this.field_77289_h - 1.0F) * 2.0F - 1.0F;
                        double d1 = j / (this.field_77289_h - 1.0F) * 2.0F - 1.0F;
                        double d2 = k / (this.field_77289_h - 1.0F) * 2.0F - 1.0F;
                        double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
                        d0 /= d3;
                        d1 /= d3;
                        d2 /= d3;
                        float f1 = this.explosionSize * (0.7F + this.worldObj.rand.nextFloat() * 0.6F);
                        double d5 = this.explosionX;
                        double d6 = this.explosionY;
                        double d7 = this.explosionZ;

                        for (float f2 = 0.3F; f1 > 0.0F; f1 -= f2 * (12.0F / 16.0F)) {
                            int j1 = MathHelper.floor_double(d5);
                            int k1 = MathHelper.floor_double(d6);
                            int l1 = MathHelper.floor_double(d7);
                            Block block = this.worldObj.getBlock(j1, k1, l1);
                            if (block.getMaterial() != Material.air) {
                                float f3 = this.exploder != null
                                    ? this.exploder.getExplosionResistance(this, this.worldObj, j1, k1, l1, block)
                                    : block.getExplosionResistance(this.exploder);
                                f1 -= (f3 + 0.3F) * f2;
                            }

                            if (f1 > 0.0F && (this.exploder == null || this.exploder.func_145774_a(this, this.worldObj, j1, k1, l1, block, f1))) {
                                hashset.add(new ChunkPosition(j1, k1, l1));
                            }

                            d5 += d0 * f2;
                            d6 += d1 * f2;
                            d7 += d2 * f2;
                        }
                    }
                }
            }
        }

        this.affectedBlockPositions.addAll(hashset);
        this.explosionSize *= 2.0F;
        int i2 = MathHelper.floor_double(this.explosionX - this.explosionSize - 1.0);
        int j2 = MathHelper.floor_double(this.explosionX + this.explosionSize + 1.0);
        int k2 = MathHelper.floor_double(this.explosionY - this.explosionSize - 1.0);
        int l2 = MathHelper.floor_double(this.explosionY + this.explosionSize + 1.0);
        int l = MathHelper.floor_double(this.explosionZ - this.explosionSize - 1.0);
        int i3 = MathHelper.floor_double(this.explosionZ + this.explosionSize + 1.0);
        List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this.exploder, AxisAlignedBB.getBoundingBox(i2, k2, l, j2, l2, i3));
        Vec3 vec3 = Vec3.createVectorHelper(this.explosionX, this.explosionY, this.explosionZ);

        for (int i1 = 0; i1 < list.size(); i1++) {
            Entity entity = (Entity)list.get(i1);
            double d4 = entity.getDistance(this.explosionX, this.explosionY, this.explosionZ) / this.explosionSize;
            if (d4 <= 1.0) {
                double d9 = entity.posX - this.explosionX;
                double d10 = entity.posY + entity.getEyeHeight() - this.explosionY;
                double d11 = entity.posZ - this.explosionZ;
                double d12 = MathHelper.sqrt_double(d9 * d9 + d10 * d10 + d11 * d11);
                if (d12 != 0.0) {
                    d9 /= d12;
                    d10 /= d12;
                    d11 /= d12;
                    double d13 = this.worldObj.getBlockDensity(vec3, entity.boundingBox);
                    double d14 = (1.0 - d4) * d13;
                    entity.attackEntityFrom(DamageSource.setExplosionSource(this), (int)((d14 * d14 + d14) / 2.0 * 8.0 * this.explosionSize + 1.0));
                    double d8 = EnchantmentProtection.func_92092_a(entity, d14);
                    entity.motionX += d9 * d8;
                    entity.motionY += d10 * d8;
                    entity.motionZ += d11 * d8;
                    if (entity instanceof EntityPlayer) {
                        this.field_77288_k.put((EntityPlayer)entity, Vec3.createVectorHelper(d9 * d14, d10 * d14, d11 * d14));
                    }
                }
            }
        }

        this.explosionSize = f;
    }

    public void doExplosionB(boolean var1) {
        this.worldObj
            .playSoundEffect(
                this.explosionX,
                this.explosionY,
                this.explosionZ,
                "random.explode",
                4.0F,
                (1.0F + (this.worldObj.rand.nextFloat() - this.worldObj.rand.nextFloat()) * 0.2F) * 0.7F
            );
        if (!(this.explosionSize < 2.0F) && this.isSmoking) {
            this.worldObj.spawnParticle("hugeexplosion", this.explosionX, this.explosionY, this.explosionZ, 1.0, 0.0, 0.0);
        } else {
            this.worldObj.spawnParticle("largeexplode", this.explosionX, this.explosionY, this.explosionZ, 1.0, 0.0, 0.0);
        }

        if (this.isSmoking) {
            for (ChunkPosition chunkposition : (Iterable<ChunkPosition>) (Iterable) this.affectedBlockPositions) {
                int i = chunkposition.chunkPosX;
                int j = chunkposition.chunkPosY;
                int k = chunkposition.chunkPosZ;
                Block block = this.worldObj.getBlock(i, j, k);
                if (var1) {
                    double d0 = i + this.worldObj.rand.nextFloat();
                    double d1 = j + this.worldObj.rand.nextFloat();
                    double d2 = k + this.worldObj.rand.nextFloat();
                    double d3 = d0 - this.explosionX;
                    double d4 = d1 - this.explosionY;
                    double d5 = d2 - this.explosionZ;
                    double d6 = MathHelper.sqrt_double(d3 * d3 + d4 * d4 + d5 * d5);
                    d3 /= d6;
                    d4 /= d6;
                    d5 /= d6;
                    double d7 = 0.5 / (d6 / this.explosionSize + 0.1);
                    d7 *= this.worldObj.rand.nextFloat() * this.worldObj.rand.nextFloat() + 0.3F;
                    d3 *= d7;
                    d4 *= d7;
                    d5 *= d7;
                    this.worldObj
                        .spawnParticle(
                            "explode", (d0 + this.explosionX * 1.0) / 2.0, (d1 + this.explosionY * 1.0) / 2.0, (d2 + this.explosionZ * 1.0) / 2.0, d3, d4, d5
                        );
                    this.worldObj.spawnParticle("smoke", d0, d1, d2, d3, d4, d5);
                }

                if (block.getMaterial() != Material.air) {
                    if (block.canDropFromExplosion(this)) {
                        block.dropBlockAsItemWithChance(this.worldObj, i, j, k, this.worldObj.getBlockMetadata(i, j, k), 1.0F / this.explosionSize, 0);
                    }

                    this.worldObj.setBlock(i, j, k, Blocks.air, 0, 3);
                    block.onBlockDestroyedByExplosion(this.worldObj, i, j, k, this);
                }
            }
        }

        if (this.isFlaming) {
            for (ChunkPosition chunkposition1 : (Iterable<ChunkPosition>) (Iterable) this.affectedBlockPositions) {
                int l = chunkposition1.chunkPosX;
                int i1 = chunkposition1.chunkPosY;
                int j1 = chunkposition1.chunkPosZ;
                Block block1 = this.worldObj.getBlock(l, i1, j1);
                Block block2 = this.worldObj.getBlock(l, i1 - 1, j1);
                if (block1.getMaterial() == Material.air && block2.isFullBlock() && this.explosionRNG.nextInt(3) == 0) {
                    this.worldObj.setBlock(l, i1, j1, Blocks.fire);
                }
            }
        }
    }

    public Map func_77277_b() {
        return this.field_77288_k;
    }

    public EntityLivingBase getExplosivePlacedBy() {
        if (this.exploder == null) {
            return null;
        } else if (this.exploder instanceof EntityTNTPrimed) {
            return ((EntityTNTPrimed)this.exploder).getTntPlacedBy();
        } else {
            return this.exploder instanceof EntityLivingBase ? (EntityLivingBase)this.exploder : null;
        }
    }
}
