package net.minecraft.world;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.play.server.S25PacketBlockBreakAnim;
import net.minecraft.network.play.server.S28PacketEffect;
import net.minecraft.network.play.server.S29PacketSoundEffect;
import net.minecraft.server.MinecraftServer;

public class WorldManager implements IWorldAccess {
    private MinecraftServer mcServer;
    private WorldServer theWorldServer;

    public WorldManager(MinecraftServer var1, WorldServer var2) {
        this.mcServer = var1;
        this.theWorldServer = var2;
    }

    @Override
    public void spawnParticle(String var1, double var2, double var4, double var6, double var8, double var10, double var12) {
    }

    @Override
    public void onEntityCreate(Entity var1) {
        this.theWorldServer.getEntityTracker().trackEntity(var1);
    }

    @Override
    public void onEntityDestroy(Entity var1) {
        this.theWorldServer.getEntityTracker().untrackEntity(var1);
    }

    @Override
    public void playSound(String var1, double var2, double var4, double var6, float var8, float var9) {
        this.mcServer
            .getConfigurationManager()
            .sendToAllNear(
                var2,
                var4,
                var6,
                var8 > 1.0F ? 16.0F * var8 : 16.0,
                this.theWorldServer.provider.dimensionId,
                new S29PacketSoundEffect(var1, var2, var4, var6, var8, var9)
            );
    }

    @Override
    public void playSoundToNearExcept(EntityPlayer var1, String var2, double var3, double var5, double var7, float var9, float var10) {
        this.mcServer
            .getConfigurationManager()
            .sendToAllNearExcept(
                var1,
                var3,
                var5,
                var7,
                var9 > 1.0F ? 16.0F * var9 : 16.0,
                this.theWorldServer.provider.dimensionId,
                new S29PacketSoundEffect(var2, var3, var5, var7, var9, var10)
            );
    }

    @Override
    public void markBlockRangeForRenderUpdate(int var1, int var2, int var3, int var4, int var5, int var6) {
    }

    @Override
    public void markBlockForUpdate(int var1, int var2, int var3) {
        this.theWorldServer.getPlayerManager().markBlockForUpdate(var1, var2, var3);
    }

    @Override
    public void markBlockForRenderUpdate(int var1, int var2, int var3) {
    }

    @Override
    public void playRecord(String var1, int var2, int var3, int var4) {
    }

    @Override
    public void playAuxSFX(EntityPlayer var1, int var2, int var3, int var4, int var5, int var6) {
        this.mcServer
            .getConfigurationManager()
            .sendToAllNearExcept(
                var1, var3, var4, var5, 64.0, this.theWorldServer.provider.dimensionId, new S28PacketEffect(var2, var3, var4, var5, var6, false)
            );
    }

    @Override
    public void broadcastSound(int var1, int var2, int var3, int var4, int var5) {
        this.mcServer.getConfigurationManager().sendPacketToAllPlayers(new S28PacketEffect(var1, var2, var3, var4, var5, true));
    }

    @Override
    public void destroyBlockPartially(int var1, int var2, int var3, int var4, int var5) {
        for (EntityPlayerMP entityplayermp : (Iterable<EntityPlayerMP>) (Iterable) this.mcServer.getConfigurationManager().playerEntityList) {
            if (entityplayermp != null && entityplayermp.worldObj == this.theWorldServer && entityplayermp.getEntityId() != var1) {
                double d0 = var2 - entityplayermp.posX;
                double d1 = var3 - entityplayermp.posY;
                double d2 = var4 - entityplayermp.posZ;
                if (d0 * d0 + d1 * d1 + d2 * d2 < 1024.0) {
                    entityplayermp.playerNetServerHandler.sendPacket(new S25PacketBlockBreakAnim(var1, var2, var3, var4, var5));
                }
            }
        }
    }

    @Override
    public void onStaticEntitiesChanged() {
    }
}
