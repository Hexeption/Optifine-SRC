package net.minecraft.world;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.Direction;
import net.minecraft.util.LongHashMap;
import net.minecraft.util.MathHelper;

public class Teleporter {
    private final WorldServer worldServerInstance;
    private final Random random;
    private final LongHashMap destinationCoordinateCache = new LongHashMap();
    private final List destinationCoordinateKeys = new ArrayList();

    public Teleporter(WorldServer var1) {
        this.worldServerInstance = var1;
        this.random = new Random(var1.getSeed());
    }

    public void placeInPortal(Entity var1, double var2, double var4, double var6, float var8) {
        if (this.worldServerInstance.provider.dimensionId != 1) {
            if (!this.placeInExistingPortal(var1, var2, var4, var6, var8)) {
                this.makePortal(var1);
                this.placeInExistingPortal(var1, var2, var4, var6, var8);
            }
        } else {
            int i = MathHelper.floor_double(var1.posX);
            int j = MathHelper.floor_double(var1.posY) - 1;
            int k = MathHelper.floor_double(var1.posZ);
            byte b0 = 1;
            byte b1 = 0;

            for (int l = -2; l <= 2; l++) {
                for (int i1 = -2; i1 <= 2; i1++) {
                    for (int j1 = -1; j1 < 3; j1++) {
                        int k1 = i + i1 * b0 + l * b1;
                        int l1 = j + j1;
                        int i2 = k + i1 * b1 - l * b0;
                        boolean flag = j1 < 0;
                        this.worldServerInstance.setBlock(k1, l1, i2, flag ? Blocks.obsidian : Blocks.air);
                    }
                }
            }

            var1.setLocationAndAngles(i, j, k, var1.rotationYaw, 0.0F);
            var1.motionX = var1.motionY = var1.motionZ = 0.0;
        }
    }

    public boolean placeInExistingPortal(Entity var1, double var2, double var4, double var6, float var8) {
        short short1 = 128;
        double d0 = -1.0;
        int i = 0;
        int j = 0;
        int k = 0;
        int l = MathHelper.floor_double(var1.posX);
        int i1 = MathHelper.floor_double(var1.posZ);
        long j1 = ChunkCoordIntPair.chunkXZ2Int(l, i1);
        boolean flag = true;
        if (this.destinationCoordinateCache.containsItem(j1)) {
            Teleporter.PortalPosition teleporter$portalposition = (Teleporter.PortalPosition)this.destinationCoordinateCache.getValueByKey(j1);
            d0 = 0.0;
            i = teleporter$portalposition.posX;
            j = teleporter$portalposition.posY;
            k = teleporter$portalposition.posZ;
            teleporter$portalposition.lastUpdateTime = this.worldServerInstance.getTotalWorldTime();
            flag = false;
        } else {
            for (int l3 = l - short1; l3 <= l + short1; l3++) {
                double d1 = l3 + 0.5 - var1.posX;

                for (int l1 = i1 - short1; l1 <= i1 + short1; l1++) {
                    double d2 = l1 + 0.5 - var1.posZ;

                    for (int i2 = this.worldServerInstance.getActualHeight() - 1; i2 >= 0; i2--) {
                        if (this.worldServerInstance.getBlock(l3, i2, l1) == Blocks.portal) {
                            while (this.worldServerInstance.getBlock(l3, i2 - 1, l1) == Blocks.portal) {
                                i2--;
                            }

                            double d4 = i2 + 0.5 - var1.posY;
                            double d5 = d1 * d1 + d4 * d4 + d2 * d2;
                            if (d0 < 0.0 || d5 < d0) {
                                d0 = d5;
                                i = l3;
                                j = i2;
                                k = l1;
                            }
                        }
                    }
                }
            }
        }

        if (d0 >= 0.0) {
            int i4 = i;
            int j4 = j;
            int k1 = k;
            if (flag) {
                this.destinationCoordinateCache.add(j1, new Teleporter.PortalPosition(i4, j4, k1, this.worldServerInstance.getTotalWorldTime()));
                this.destinationCoordinateKeys.add(j1);
            }

            double d8 = i4 + 0.5;
            double d3 = j4 + 0.5;
            double d9 = k1 + 0.5;
            int k4 = -1;
            if (this.worldServerInstance.getBlock(i4 - 1, j4, k1) == Blocks.portal) {
                k4 = 2;
            }

            if (this.worldServerInstance.getBlock(i4 + 1, j4, k1) == Blocks.portal) {
                k4 = 0;
            }

            if (this.worldServerInstance.getBlock(i4, j4, k1 - 1) == Blocks.portal) {
                k4 = 3;
            }

            if (this.worldServerInstance.getBlock(i4, j4, k1 + 1) == Blocks.portal) {
                k4 = 1;
            }

            int j2 = var1.getTeleportDirection();
            if (k4 > -1) {
                int k2 = Direction.rotateLeft[k4];
                int l2 = Direction.offsetX[k4];
                int i3 = Direction.offsetZ[k4];
                int j3 = Direction.offsetX[k2];
                int k3 = Direction.offsetZ[k2];
                boolean flag1 = !this.worldServerInstance.isAirBlock(i4 + l2 + j3, j4, k1 + i3 + k3)
                    || !this.worldServerInstance.isAirBlock(i4 + l2 + j3, j4 + 1, k1 + i3 + k3);
                boolean flag2 = !this.worldServerInstance.isAirBlock(i4 + l2, j4, k1 + i3) || !this.worldServerInstance.isAirBlock(i4 + l2, j4 + 1, k1 + i3);
                if (flag1 && flag2) {
                    k4 = Direction.rotateOpposite[k4];
                    k2 = Direction.rotateOpposite[k2];
                    l2 = Direction.offsetX[k4];
                    i3 = Direction.offsetZ[k4];
                    j3 = Direction.offsetX[k2];
                    k3 = Direction.offsetZ[k2];
                    i4 -= j3;
                    d8 -= j3;
                    k1 -= k3;
                    d9 -= k3;
                    flag1 = !this.worldServerInstance.isAirBlock(i4 + l2 + j3, j4, k1 + i3 + k3)
                        || !this.worldServerInstance.isAirBlock(i4 + l2 + j3, j4 + 1, k1 + i3 + k3);
                    flag2 = !this.worldServerInstance.isAirBlock(i4 + l2, j4, k1 + i3) || !this.worldServerInstance.isAirBlock(i4 + l2, j4 + 1, k1 + i3);
                }

                float f = 0.5F;
                float f1 = 0.5F;
                if (!flag1 && flag2) {
                    f = 1.0F;
                } else if (flag1 && !flag2) {
                    f = 0.0F;
                } else if (flag1 && flag2) {
                    f1 = 0.0F;
                }

                d8 += j3 * f + f1 * l2;
                d9 += k3 * f + f1 * i3;
                float f2 = 0.0F;
                float f3 = 0.0F;
                float f4 = 0.0F;
                float f5 = 0.0F;
                if (k4 == j2) {
                    f2 = 1.0F;
                    f3 = 1.0F;
                } else if (k4 == Direction.rotateOpposite[j2]) {
                    f2 = -1.0F;
                    f3 = -1.0F;
                } else if (k4 == Direction.enderEyeMetaToDirection[j2]) {
                    f4 = 1.0F;
                    f5 = -1.0F;
                } else {
                    f4 = -1.0F;
                    f5 = 1.0F;
                }

                double d6 = var1.motionX;
                double d7 = var1.motionZ;
                var1.motionX = d6 * f2 + d7 * f5;
                var1.motionZ = d6 * f4 + d7 * f3;
                var1.rotationYaw = var8 - j2 * 90 + k4 * 90;
            } else {
                var1.motionX = var1.motionY = var1.motionZ = 0.0;
            }

            var1.setLocationAndAngles(d8, d3, d9, var1.rotationYaw, var1.rotationPitch);
            return true;
        } else {
            return false;
        }
    }

    public boolean makePortal(Entity var1) {
        byte b0 = 16;
        double d0 = -1.0;
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posY);
        int k = MathHelper.floor_double(var1.posZ);
        int l = i;
        int i1 = j;
        int j1 = k;
        int k1 = 0;
        int l1 = this.random.nextInt(4);

        for (int i2 = i - b0; i2 <= i + b0; i2++) {
            double d1 = i2 + 0.5 - var1.posX;

            for (int k2 = k - b0; k2 <= k + b0; k2++) {
                double d2 = k2 + 0.5 - var1.posZ;

                label299:
                for (int i3 = this.worldServerInstance.getActualHeight() - 1; i3 >= 0; i3--) {
                    if (this.worldServerInstance.isAirBlock(i2, i3, k2)) {
                        while (i3 > 0 && this.worldServerInstance.isAirBlock(i2, i3 - 1, k2)) {
                            i3--;
                        }

                        for (int j3 = l1; j3 < l1 + 4; j3++) {
                            int k3 = j3 % 2;
                            int l3 = 1 - k3;
                            if (j3 % 4 >= 2) {
                                k3 = -k3;
                                l3 = -l3;
                            }

                            for (int i4 = 0; i4 < 3; i4++) {
                                for (int j4 = 0; j4 < 4; j4++) {
                                    for (int k4 = -1; k4 < 4; k4++) {
                                        int l4 = i2 + (j4 - 1) * k3 + i4 * l3;
                                        int i5 = i3 + k4;
                                        int j5 = k2 + (j4 - 1) * l3 - i4 * k3;
                                        if (k4 < 0 && !this.worldServerInstance.getBlock(l4, i5, j5).getMaterial().isSolid()
                                            || k4 >= 0 && !this.worldServerInstance.isAirBlock(l4, i5, j5)) {
                                            continue label299;
                                        }
                                    }
                                }
                            }

                            double d5 = i3 + 0.5 - var1.posY;
                            double d7 = d1 * d1 + d5 * d5 + d2 * d2;
                            if (d0 < 0.0 || d7 < d0) {
                                d0 = d7;
                                l = i2;
                                i1 = i3;
                                j1 = k2;
                                k1 = j3 % 4;
                            }
                        }
                    }
                }
            }
        }

        if (d0 < 0.0) {
            for (int k5 = i - b0; k5 <= i + b0; k5++) {
                double d3 = k5 + 0.5 - var1.posX;

                for (int j6 = k - b0; j6 <= k + b0; j6++) {
                    double d4 = j6 + 0.5 - var1.posZ;

                    label236:
                    for (int i7 = this.worldServerInstance.getActualHeight() - 1; i7 >= 0; i7--) {
                        if (this.worldServerInstance.isAirBlock(k5, i7, j6)) {
                            while (i7 > 0 && this.worldServerInstance.isAirBlock(k5, i7 - 1, j6)) {
                                i7--;
                            }

                            for (int l7 = l1; l7 < l1 + 2; l7++) {
                                int l8 = l7 % 2;
                                int l9 = 1 - l8;

                                for (int l10 = 0; l10 < 4; l10++) {
                                    for (int l11 = -1; l11 < 4; l11++) {
                                        int l12 = k5 + (l10 - 1) * l8;
                                        int i13 = i7 + l11;
                                        int j13 = j6 + (l10 - 1) * l9;
                                        if (l11 < 0 && !this.worldServerInstance.getBlock(l12, i13, j13).getMaterial().isSolid()
                                            || l11 >= 0 && !this.worldServerInstance.isAirBlock(l12, i13, j13)) {
                                            continue label236;
                                        }
                                    }
                                }

                                double d6 = i7 + 0.5 - var1.posY;
                                double d8 = d3 * d3 + d6 * d6 + d4 * d4;
                                if (d0 < 0.0 || d8 < d0) {
                                    d0 = d8;
                                    l = k5;
                                    i1 = i7;
                                    j1 = j6;
                                    k1 = l7 % 2;
                                }
                            }
                        }
                    }
                }
            }
        }

        int l5 = k1;
        int i6 = l;
        int j2 = i1;
        int k6 = j1;
        int l6 = l5 % 2;
        int l2 = 1 - l6;
        if (l5 % 4 >= 2) {
            l6 = -l6;
            l2 = -l2;
        }

        if (d0 < 0.0) {
            if (i1 < 70) {
                i1 = 70;
            }

            if (i1 > this.worldServerInstance.getActualHeight() - 10) {
                i1 = this.worldServerInstance.getActualHeight() - 10;
            }

            j2 = i1;

            for (int j7 = -1; j7 <= 1; j7++) {
                for (int i8 = 1; i8 < 3; i8++) {
                    for (int i9 = -1; i9 < 3; i9++) {
                        int i10 = i6 + (i8 - 1) * l6 + j7 * l2;
                        int i11 = j2 + i9;
                        int i12 = k6 + (i8 - 1) * l2 - j7 * l6;
                        boolean flag = i9 < 0;
                        this.worldServerInstance.setBlock(i10, i11, i12, flag ? Blocks.obsidian : Blocks.air);
                    }
                }
            }
        }

        for (int k7 = 0; k7 < 4; k7++) {
            for (int j8 = 0; j8 < 4; j8++) {
                for (int j9 = -1; j9 < 4; j9++) {
                    int j10 = i6 + (j8 - 1) * l6;
                    int j11 = j2 + j9;
                    int j12 = k6 + (j8 - 1) * l2;
                    boolean flag1 = j8 == 0 || j8 == 3 || j9 == -1 || j9 == 3;
                    this.worldServerInstance.setBlock(j10, j11, j12, flag1 ? Blocks.obsidian : Blocks.portal, 0, 2);
                }
            }

            for (int k8 = 0; k8 < 4; k8++) {
                for (int k9 = -1; k9 < 4; k9++) {
                    int k10 = i6 + (k8 - 1) * l6;
                    int k11 = j2 + k9;
                    int k12 = k6 + (k8 - 1) * l2;
                    this.worldServerInstance.notifyBlocksOfNeighborChange(k10, k11, k12, this.worldServerInstance.getBlock(k10, k11, k12));
                }
            }
        }

        return true;
    }

    public void removeStalePortalLocations(long var1) {
        if (var1 % 100L == 0L) {
            Iterator iterator = this.destinationCoordinateKeys.iterator();
            long i = var1 - 600L;

            while (iterator.hasNext()) {
                Long olong = (Long)iterator.next();
                Teleporter.PortalPosition teleporter$portalposition = (Teleporter.PortalPosition)this.destinationCoordinateCache.getValueByKey(olong);
                if (teleporter$portalposition == null || teleporter$portalposition.lastUpdateTime < i) {
                    iterator.remove();
                    this.destinationCoordinateCache.remove(olong);
                }
            }
        }
    }

    public class PortalPosition extends ChunkCoordinates {
        public long lastUpdateTime;

        public PortalPosition(int var2, int var3, int var4, long var5) {
            super(var2, var3, var4);
            this.lastUpdateTime = var5;
        }
    }
}
