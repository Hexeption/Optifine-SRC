package net.minecraft.world;

public class ChunkCoordIntPair {
    public final int chunkXPos;
    public final int chunkZPos;
    private static final String __OBFID = "CL_00000133";
    private int cachedHashCode = 0;

    public ChunkCoordIntPair(int par1, int par2) {
        this.chunkXPos = par1;
        this.chunkZPos = par2;
    }

    public static long chunkXZ2Int(int par0, int par1) {
        return par0 & 4294967295L | (par1 & 4294967295L) << 32;
    }

    @Override
    public int hashCode() {
        if (this.cachedHashCode == 0) {
            int i = 1664525 * this.chunkXPos + 1013904223;
            int j = 1664525 * (this.chunkZPos ^ -559038737) + 1013904223;
            this.cachedHashCode = i ^ j;
        }

        return this.cachedHashCode;
    }

    @Override
    public boolean equals(Object par1Obj) {
        if (this == par1Obj) {
            return true;
        }

        if (!(par1Obj instanceof ChunkCoordIntPair)) {
            return false;
        }

        ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)par1Obj;
        return this.chunkXPos == chunkcoordintpair.chunkXPos && this.chunkZPos == chunkcoordintpair.chunkZPos;
    }

    public int getCenterXPos() {
        return (this.chunkXPos << 4) + 8;
    }

    public int getCenterZPosition() {
        return (this.chunkZPos << 4) + 8;
    }

    public ChunkPosition func_151349_a(int p_151349_1_) {
        return new ChunkPosition(this.getCenterXPos(), p_151349_1_, this.getCenterZPosition());
    }

    @Override
    public String toString() {
        return "[" + this.chunkXPos + ", " + this.chunkZPos + "]";
    }
}
