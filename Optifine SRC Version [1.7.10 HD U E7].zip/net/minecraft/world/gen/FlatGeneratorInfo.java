package net.minecraft.world.gen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.biome.BiomeGenBase;

public class FlatGeneratorInfo {
    private final List flatLayers = new ArrayList();
    private final Map worldFeatures = new HashMap();
    private int biomeToUse;

    public int getBiome() {
        return this.biomeToUse;
    }

    public void setBiome(int var1) {
        this.biomeToUse = var1;
    }

    public Map getWorldFeatures() {
        return this.worldFeatures;
    }

    public List getFlatLayers() {
        return this.flatLayers;
    }

    public void func_82645_d() {
        int i = 0;

        for (FlatLayerInfo flatlayerinfo : (Iterable<FlatLayerInfo>) (Iterable) this.flatLayers) {
            flatlayerinfo.setMinY(i);
            i += flatlayerinfo.getLayerCount();
        }
    }

    @Override
    public String toString() {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(2);
        stringbuilder.append(";");

        for (int i = 0; i < this.flatLayers.size(); i++) {
            if (i > 0) {
                stringbuilder.append(",");
            }

            stringbuilder.append(((FlatLayerInfo)this.flatLayers.get(i)).toString());
        }

        stringbuilder.append(";");
        stringbuilder.append(this.biomeToUse);
        if (!this.worldFeatures.isEmpty()) {
            stringbuilder.append(";");
            int k = 0;

            for (Entry entry : (Iterable<Entry>) (Iterable) this.worldFeatures.entrySet()) {
                if (k++ > 0) {
                    stringbuilder.append(",");
                }

                stringbuilder.append(((String)entry.getKey()).toLowerCase());
                Map map = (Map)entry.getValue();
                if (!map.isEmpty()) {
                    stringbuilder.append("(");
                    int j = 0;

                    for (Entry entry1 : (Iterable<Entry>) (Iterable) map.entrySet()) {
                        if (j++ > 0) {
                            stringbuilder.append(" ");
                        }

                        stringbuilder.append((String)entry1.getKey());
                        stringbuilder.append("=");
                        stringbuilder.append((String)entry1.getValue());
                    }

                    stringbuilder.append(")");
                }
            }
        } else {
            stringbuilder.append(";");
        }

        return stringbuilder.toString();
    }

    private static FlatLayerInfo func_82646_a(String var0, int var1) {
        String[] astring = var0.split("x", 2);
        int i = 1;
        int k = 0;
        if (astring.length == 2) {
            try {
                i = Integer.parseInt(astring[0]);
                if (var1 + i >= 256) {
                    i = 256 - var1;
                }

                if (i < 0) {
                    i = 0;
                }
            } catch (Throwable throwable) {
                return null;
            }
        }

        int j;
        try {
            String s = astring[astring.length - 1];
            astring = s.split(":", 2);
            j = Integer.parseInt(astring[0]);
            if (astring.length > 1) {
                k = Integer.parseInt(astring[1]);
            }

            if (Block.getBlockById(j) == Blocks.air) {
                j = 0;
                k = 0;
            }

            if (k < 0 || k > 15) {
                k = 0;
            }
        } catch (Throwable throwable1) {
            return null;
        }

        FlatLayerInfo flatlayerinfo = new FlatLayerInfo(i, Block.getBlockById(j), k);
        flatlayerinfo.setMinY(var1);
        return flatlayerinfo;
    }

    private static List func_82652_b(String var0) {
        if (var0 != null && var0.length() >= 1) {
            ArrayList arraylist = new ArrayList();
            String[] astring = var0.split(",");
            int i = 0;

            for (String s : astring) {
                FlatLayerInfo flatlayerinfo = func_82646_a(s, i);
                if (flatlayerinfo == null) {
                    return null;
                }

                arraylist.add(flatlayerinfo);
                i += flatlayerinfo.getLayerCount();
            }

            return arraylist;
        } else {
            return null;
        }
    }

    public static FlatGeneratorInfo createFlatGeneratorFromString(String var0) {
        if (var0 == null) {
            return getDefaultFlatGenerator();
        }

        String[] astring = var0.split(";", -1);
        int i = astring.length == 1 ? 0 : MathHelper.parseIntWithDefault(astring[0], 0);
        if (i >= 0 && i <= 2) {
            FlatGeneratorInfo flatgeneratorinfo = new FlatGeneratorInfo();
            int j = astring.length == 1 ? 0 : 1;
            List list = func_82652_b(astring[j++]);
            if (list != null && !list.isEmpty()) {
                flatgeneratorinfo.getFlatLayers().addAll(list);
                flatgeneratorinfo.func_82645_d();
                int k = BiomeGenBase.plains.biomeID;
                if (i > 0 && astring.length > j) {
                    k = MathHelper.parseIntWithDefault(astring[j++], k);
                }

                flatgeneratorinfo.setBiome(k);
                if (i > 0 && astring.length > j) {
                    String[] astring1 = astring[j++].toLowerCase().split(",");

                    for (String s : astring1) {
                        String[] astring2 = s.split("\\(", 2);
                        HashMap hashmap = new HashMap();
                        if (astring2[0].length() > 0) {
                            flatgeneratorinfo.getWorldFeatures().put(astring2[0], hashmap);
                            if (astring2.length > 1 && astring2[1].endsWith(")") && astring2[1].length() > 1) {
                                String[] astring3 = astring2[1].substring(0, astring2[1].length() - 1).split(" ");

                                for (int l = 0; l < astring3.length; l++) {
                                    String[] astring4 = astring3[l].split("=", 2);
                                    if (astring4.length == 2) {
                                        hashmap.put(astring4[0], astring4[1]);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    flatgeneratorinfo.getWorldFeatures().put("village", new HashMap());
                }

                return flatgeneratorinfo;
            } else {
                return getDefaultFlatGenerator();
            }
        } else {
            return getDefaultFlatGenerator();
        }
    }

    public static FlatGeneratorInfo getDefaultFlatGenerator() {
        FlatGeneratorInfo flatgeneratorinfo = new FlatGeneratorInfo();
        flatgeneratorinfo.setBiome(BiomeGenBase.plains.biomeID);
        flatgeneratorinfo.getFlatLayers().add(new FlatLayerInfo(1, Blocks.bedrock));
        flatgeneratorinfo.getFlatLayers().add(new FlatLayerInfo(2, Blocks.dirt));
        flatgeneratorinfo.getFlatLayers().add(new FlatLayerInfo(1, Blocks.grass));
        flatgeneratorinfo.func_82645_d();
        flatgeneratorinfo.getWorldFeatures().put("village", new HashMap());
        return flatgeneratorinfo;
    }
}
