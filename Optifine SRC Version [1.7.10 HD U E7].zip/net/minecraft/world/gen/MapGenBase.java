package net.minecraft.world.gen;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;

public class MapGenBase {
    protected int range = 8;
    protected Random rand = new Random();
    protected World worldObj;

    public void generate(IChunkProvider var1, World var2, int var3, int var4, Block[] var5) {
        int i = this.range;
        this.worldObj = var2;
        this.rand.setSeed(var2.getSeed());
        long j = this.rand.nextLong();
        long k = this.rand.nextLong();

        for (int l = var3 - i; l <= var3 + i; l++) {
            for (int i1 = var4 - i; i1 <= var4 + i; i1++) {
                long j1 = l * j;
                long k1 = i1 * k;
                this.rand.setSeed(j1 ^ k1 ^ var2.getSeed());
                this.func_151538_a(var2, l, i1, var3, var4, var5);
            }
        }
    }

    protected void func_151538_a(World var1, int var2, int var3, int var4, int var5, Block[] var6) {
    }
}
