package net.minecraft.world.gen;

import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.MathHelper;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.SpawnerAnimals;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenDungeons;
import net.minecraft.world.gen.feature.WorldGenLakes;
import net.minecraft.world.gen.structure.MapGenMineshaft;
import net.minecraft.world.gen.structure.MapGenScatteredFeature;
import net.minecraft.world.gen.structure.MapGenStronghold;
import net.minecraft.world.gen.structure.MapGenVillage;

public class ChunkProviderGenerate implements IChunkProvider {
    private Random rand;
    private NoiseGeneratorOctaves field_147431_j;
    private NoiseGeneratorOctaves field_147432_k;
    private NoiseGeneratorOctaves field_147429_l;
    private NoiseGeneratorPerlin field_147430_m;
    public NoiseGeneratorOctaves noiseGen5;
    public NoiseGeneratorOctaves noiseGen6;
    public NoiseGeneratorOctaves mobSpawnerNoise;
    private World worldObj;
    private final boolean mapFeaturesEnabled;
    private WorldType field_147435_p;
    private final double[] field_147434_q;
    private final float[] parabolicField;
    private double[] stoneNoise = new double[256];
    private MapGenBase caveGenerator = new MapGenCaves();
    private MapGenStronghold strongholdGenerator = new MapGenStronghold();
    private MapGenVillage villageGenerator = new MapGenVillage();
    private MapGenMineshaft mineshaftGenerator = new MapGenMineshaft();
    private MapGenScatteredFeature scatteredFeatureGenerator = new MapGenScatteredFeature();
    private MapGenBase ravineGenerator = new MapGenRavine();
    private BiomeGenBase[] biomesForGeneration;
    double[] field_147427_d;
    double[] field_147428_e;
    double[] field_147425_f;
    double[] field_147426_g;
    int[][] field_73219_j = new int[32][32];

    public ChunkProviderGenerate(World var1, long var2, boolean var4) {
        this.worldObj = var1;
        this.mapFeaturesEnabled = var4;
        this.field_147435_p = var1.getWorldInfo().getTerrainType();
        this.rand = new Random(var2);
        this.field_147431_j = new NoiseGeneratorOctaves(this.rand, 16);
        this.field_147432_k = new NoiseGeneratorOctaves(this.rand, 16);
        this.field_147429_l = new NoiseGeneratorOctaves(this.rand, 8);
        this.field_147430_m = new NoiseGeneratorPerlin(this.rand, 4);
        this.noiseGen5 = new NoiseGeneratorOctaves(this.rand, 10);
        this.noiseGen6 = new NoiseGeneratorOctaves(this.rand, 16);
        this.mobSpawnerNoise = new NoiseGeneratorOctaves(this.rand, 8);
        this.field_147434_q = new double[825];
        this.parabolicField = new float[25];

        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                float f = 10.0F / MathHelper.sqrt_float(i * i + j * j + 0.2F);
                this.parabolicField[i + 2 + (j + 2) * 5] = f;
            }
        }
    }

    public void func_147424_a(int var1, int var2, Block[] var3) {
        byte b0 = 63;
        this.biomesForGeneration = this.worldObj.getWorldChunkManager().getBiomesForGeneration(this.biomesForGeneration, var1 * 4 - 2, var2 * 4 - 2, 10, 10);
        this.func_147423_a(var1 * 4, 0, var2 * 4);

        for (int i = 0; i < 4; i++) {
            int j = i * 5;
            int k = (i + 1) * 5;

            for (int l = 0; l < 4; l++) {
                int i1 = (j + l) * 33;
                int j1 = (j + l + 1) * 33;
                int k1 = (k + l) * 33;
                int l1 = (k + l + 1) * 33;

                for (int i2 = 0; i2 < 32; i2++) {
                    double d0 = 0.125;
                    double d1 = this.field_147434_q[i1 + i2];
                    double d2 = this.field_147434_q[j1 + i2];
                    double d3 = this.field_147434_q[k1 + i2];
                    double d4 = this.field_147434_q[l1 + i2];
                    double d5 = (this.field_147434_q[i1 + i2 + 1] - d1) * d0;
                    double d6 = (this.field_147434_q[j1 + i2 + 1] - d2) * d0;
                    double d7 = (this.field_147434_q[k1 + i2 + 1] - d3) * d0;
                    double d8 = (this.field_147434_q[l1 + i2 + 1] - d4) * d0;

                    for (int j2 = 0; j2 < 8; j2++) {
                        double d9 = 0.25;
                        double d10 = d1;
                        double d11 = d2;
                        double d12 = (d3 - d1) * d9;
                        double d13 = (d4 - d2) * d9;

                        for (int k2 = 0; k2 < 4; k2++) {
                            int l2 = k2 + i * 4 << 12 | 0 + l * 4 << 8 | i2 * 8 + j2;
                            short short1 = 256;
                            l2 -= short1;
                            double d14 = 0.25;
                            double d15 = d10;
                            double d16 = (d11 - d10) * d14;
                            d15 -= d16;

                            for (int i3 = 0; i3 < 4; i3++) {
                                d15 += d16;
                                if (d15 > 0.0) {
                                    l2 += short1;
                                    var3[l2] = Blocks.stone;
                                } else if (i2 * 8 + j2 < b0) {
                                    l2 += short1;
                                    var3[l2] = Blocks.water;
                                } else {
                                    l2 += short1;
                                    var3[l2] = null;
                                }
                            }

                            d10 += d12;
                            d11 += d13;
                        }

                        d1 += d5;
                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                    }
                }
            }
        }
    }

    public void replaceBlocksForBiome(int var1, int var2, Block[] var3, byte[] var4, BiomeGenBase[] var5) {
        double d0 = 1.0 / 32.0;
        this.stoneNoise = this.field_147430_m.func_151599_a(this.stoneNoise, var1 * 16, var2 * 16, 16, 16, d0 * 2.0, d0 * 2.0, 1.0);

        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                BiomeGenBase biomegenbase = var5[j + i * 16];
                biomegenbase.genTerrainBlocks(this.worldObj, this.rand, var3, var4, var1 * 16 + i, var2 * 16 + j, this.stoneNoise[j + i * 16]);
            }
        }
    }

    @Override
    public Chunk loadChunk(int var1, int var2) {
        return this.provideChunk(var1, var2);
    }

    @Override
    public Chunk provideChunk(int var1, int var2) {
        this.rand.setSeed(var1 * 341873128712L + var2 * 132897987541L);
        Block[] ablock = new Block[65536];
        byte[] abyte = new byte[65536];
        this.func_147424_a(var1, var2, ablock);
        this.biomesForGeneration = this.worldObj.getWorldChunkManager().loadBlockGeneratorData(this.biomesForGeneration, var1 * 16, var2 * 16, 16, 16);
        this.replaceBlocksForBiome(var1, var2, ablock, abyte, this.biomesForGeneration);
        this.caveGenerator.generate(this, this.worldObj, var1, var2, ablock);
        this.ravineGenerator.generate(this, this.worldObj, var1, var2, ablock);
        if (this.mapFeaturesEnabled) {
            this.mineshaftGenerator.generate(this, this.worldObj, var1, var2, ablock);
            this.villageGenerator.generate(this, this.worldObj, var1, var2, ablock);
            this.strongholdGenerator.generate(this, this.worldObj, var1, var2, ablock);
            this.scatteredFeatureGenerator.generate(this, this.worldObj, var1, var2, ablock);
        }

        Chunk chunk = new Chunk(this.worldObj, ablock, abyte, var1, var2);
        byte[] abyte1 = chunk.getBiomeArray();

        for (int i = 0; i < abyte1.length; i++) {
            abyte1[i] = (byte)this.biomesForGeneration[i].biomeID;
        }

        chunk.generateSkylightMap();
        return chunk;
    }

    private void func_147423_a(int var1, int var2, int var3) {
        double d0 = 684.412;
        double d1 = 684.412;
        double d2 = 512.0;
        double d3 = 512.0;
        this.field_147426_g = this.noiseGen6.generateNoiseOctaves(this.field_147426_g, var1, var3, 5, 5, 200.0, 200.0, 0.5);
        this.field_147427_d = this.field_147429_l
            .generateNoiseOctaves(this.field_147427_d, var1, var2, var3, 5, 33, 5, 8.555150000000001, 4.277575000000001, 8.555150000000001);
        this.field_147428_e = this.field_147431_j.generateNoiseOctaves(this.field_147428_e, var1, var2, var3, 5, 33, 5, 684.412, 684.412, 684.412);
        this.field_147425_f = this.field_147432_k.generateNoiseOctaves(this.field_147425_f, var1, var2, var3, 5, 33, 5, 684.412, 684.412, 684.412);
        boolean flag = false;
        int i = 0;
        int j = 0;
        double d4 = 8.5;

        for (int k = 0; k < 5; k++) {
            for (int l = 0; l < 5; l++) {
                float f = 0.0F;
                float f1 = 0.0F;
                float f2 = 0.0F;
                byte b0 = 2;
                BiomeGenBase biomegenbase = this.biomesForGeneration[k + 2 + (l + 2) * 10];

                for (int i1 = -b0; i1 <= b0; i1++) {
                    for (int j1 = -b0; j1 <= b0; j1++) {
                        BiomeGenBase biomegenbase1 = this.biomesForGeneration[k + i1 + 2 + (l + j1 + 2) * 10];
                        float f3 = biomegenbase1.minHeight;
                        float f4 = biomegenbase1.maxHeight;
                        if (this.field_147435_p == WorldType.AMPLIFIED && f3 > 0.0F) {
                            f3 = 1.0F + f3 * 2.0F;
                            f4 = 1.0F + f4 * 4.0F;
                        }

                        float f5 = this.parabolicField[i1 + 2 + (j1 + 2) * 5] / (f3 + 2.0F);
                        if (biomegenbase1.minHeight > biomegenbase.minHeight) {
                            f5 /= 2.0F;
                        }

                        f += f4 * f5;
                        f1 += f3 * f5;
                        f2 += f5;
                    }
                }

                f /= f2;
                f1 /= f2;
                f = f * 0.9F + 0.1F;
                f1 = (f1 * 4.0F - 1.0F) / 8.0F;
                double d12 = this.field_147426_g[j] / 8000.0;
                if (d12 < 0.0) {
                    d12 = -d12 * 0.3;
                }

                d12 = d12 * 3.0 - 2.0;
                if (d12 < 0.0) {
                    d12 /= 2.0;
                    if (d12 < -1.0) {
                        d12 = -1.0;
                    }

                    d12 /= 1.4;
                    d12 /= 2.0;
                } else {
                    if (d12 > 1.0) {
                        d12 = 1.0;
                    }

                    d12 /= 8.0;
                }

                j++;
                double d13 = f1;
                double d14 = f;
                d13 += d12 * 0.2;
                d13 = d13 * 8.5 / 8.0;
                double d5 = 8.5 + d13 * 4.0;

                for (int k1 = 0; k1 < 33; k1++) {
                    double d6 = (k1 - d5) * 12.0 * 128.0 / 256.0 / d14;
                    if (d6 < 0.0) {
                        d6 *= 4.0;
                    }

                    double d7 = this.field_147428_e[i] / 512.0;
                    double d8 = this.field_147425_f[i] / 512.0;
                    double d9 = (this.field_147427_d[i] / 10.0 + 1.0) / 2.0;
                    double d10 = MathHelper.denormalizeClamp(d7, d8, d9) - d6;
                    if (k1 > 29) {
                        double d11 = (k1 - 29) / 3.0F;
                        d10 = d10 * (1.0 - d11) + -10.0 * d11;
                    }

                    this.field_147434_q[i] = d10;
                    i++;
                }
            }
        }
    }

    @Override
    public boolean chunkExists(int var1, int var2) {
        return true;
    }

    @Override
    public void populate(IChunkProvider var1, int var2, int var3) {
        BlockFalling.fallInstantly = true;
        int i = var2 * 16;
        int j = var3 * 16;
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(i + 16, j + 16);
        this.rand.setSeed(this.worldObj.getSeed());
        long k = this.rand.nextLong() / 2L * 2L + 1L;
        long l = this.rand.nextLong() / 2L * 2L + 1L;
        this.rand.setSeed(var2 * k + var3 * l ^ this.worldObj.getSeed());
        boolean flag = false;
        if (this.mapFeaturesEnabled) {
            this.mineshaftGenerator.generateStructuresInChunk(this.worldObj, this.rand, var2, var3);
            flag = this.villageGenerator.generateStructuresInChunk(this.worldObj, this.rand, var2, var3);
            this.strongholdGenerator.generateStructuresInChunk(this.worldObj, this.rand, var2, var3);
            this.scatteredFeatureGenerator.generateStructuresInChunk(this.worldObj, this.rand, var2, var3);
        }

        if (biomegenbase != BiomeGenBase.desert && biomegenbase != BiomeGenBase.desertHills && !flag && this.rand.nextInt(4) == 0) {
            int i1 = i + this.rand.nextInt(16) + 8;
            int j1 = this.rand.nextInt(256);
            int k1 = j + this.rand.nextInt(16) + 8;
            new WorldGenLakes(Blocks.water).generate(this.worldObj, this.rand, i1, j1, k1);
        }

        if (!flag && this.rand.nextInt(8) == 0) {
            int i2 = i + this.rand.nextInt(16) + 8;
            int l2 = this.rand.nextInt(this.rand.nextInt(248) + 8);
            int k3 = j + this.rand.nextInt(16) + 8;
            if (l2 < 63 || this.rand.nextInt(10) == 0) {
                new WorldGenLakes(Blocks.lava).generate(this.worldObj, this.rand, i2, l2, k3);
            }
        }

        for (int j2 = 0; j2 < 8; j2++) {
            int i3 = i + this.rand.nextInt(16) + 8;
            int l3 = this.rand.nextInt(256);
            int l1 = j + this.rand.nextInt(16) + 8;
            new WorldGenDungeons().generate(this.worldObj, this.rand, i3, l3, l1);
        }

        biomegenbase.decorate(this.worldObj, this.rand, i, j);
        SpawnerAnimals.performWorldGenSpawning(this.worldObj, biomegenbase, i + 8, j + 8, 16, 16, this.rand);
        i += 8;
        j += 8;

        for (int k2 = 0; k2 < 16; k2++) {
            for (int j3 = 0; j3 < 16; j3++) {
                int i4 = this.worldObj.getPrecipitationHeight(i + k2, j + j3);
                if (this.worldObj.isBlockFreezable(k2 + i, i4 - 1, j3 + j)) {
                    this.worldObj.setBlock(k2 + i, i4 - 1, j3 + j, Blocks.ice, 0, 2);
                }

                if (this.worldObj.canSnowAt(k2 + i, i4, j3 + j, true)) {
                    this.worldObj.setBlock(k2 + i, i4, j3 + j, Blocks.snow_layer, 0, 2);
                }
            }
        }

        BlockFalling.fallInstantly = false;
    }

    @Override
    public boolean saveChunks(boolean var1, IProgressUpdate var2) {
        return true;
    }

    @Override
    public void saveExtraData() {
    }

    @Override
    public boolean unloadQueuedChunks() {
        return false;
    }

    @Override
    public boolean canSave() {
        return true;
    }

    @Override
    public String makeString() {
        return "RandomLevelSource";
    }

    @Override
    public List getPossibleCreatures(EnumCreatureType var1, int var2, int var3, int var4) {
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(var2, var4);
        return var1 == EnumCreatureType.monster && this.scatteredFeatureGenerator.func_143030_a(var2, var3, var4)
            ? this.scatteredFeatureGenerator.getScatteredFeatureSpawnList()
            : biomegenbase.getSpawnableList(var1);
    }

    @Override
    public ChunkPosition findClosestStructure(World var1, String var2, int var3, int var4, int var5) {
        return "Stronghold".equals(var2) && this.strongholdGenerator != null ? this.strongholdGenerator.getNearestInstance(var1, var3, var4, var5) : null;
    }

    @Override
    public int getLoadedChunkCount() {
        return 0;
    }

    @Override
    public void recreateStructures(int var1, int var2) {
        if (this.mapFeaturesEnabled) {
            this.mineshaftGenerator.generate(this, this.worldObj, var1, var2, null);
            this.villageGenerator.generate(this, this.worldObj, var1, var2, null);
            this.strongholdGenerator.generate(this, this.worldObj, var1, var2, null);
            this.scatteredFeatureGenerator.generate(this, this.worldObj, var1, var2, null);
        }
    }
}
