package net.minecraft.world.gen;

import java.util.Random;

public class NoiseGeneratorImproved extends NoiseGenerator {
    private int[] permutations = new int[512];
    public double xCoord;
    public double yCoord;
    public double zCoord;
    private static final double[] field_152381_e = new double[]{1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, -1.0, 0.0};
    private static final double[] field_152382_f = new double[]{1.0, 1.0, -1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0};
    private static final double[] field_152383_g = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 0.0, 1.0, 0.0, -1.0};
    private static final double[] field_152384_h = new double[]{1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, -1.0, 0.0};
    private static final double[] field_152385_i = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 0.0, 1.0, 0.0, -1.0};

    public NoiseGeneratorImproved() {
        this(new Random());
    }

    public NoiseGeneratorImproved(Random var1) {
        this.xCoord = var1.nextDouble() * 256.0;
        this.yCoord = var1.nextDouble() * 256.0;
        this.zCoord = var1.nextDouble() * 256.0;
        int i = 0;

        while (i < 256) {
            this.permutations[i] = i++;
        }

        for (int l = 0; l < 256; l++) {
            int j = var1.nextInt(256 - l) + l;
            int k = this.permutations[l];
            this.permutations[l] = this.permutations[j];
            this.permutations[j] = k;
            this.permutations[l + 256] = this.permutations[l];
        }
    }

    public final double lerp(double var1, double var3, double var5) {
        return var3 + var1 * (var5 - var3);
    }

    public final double func_76309_a(int var1, double var2, double var4) {
        int i = var1 & 15;
        return field_152384_h[i] * var2 + field_152385_i[i] * var4;
    }

    public final double grad(int var1, double var2, double var4, double var6) {
        int i = var1 & 15;
        return field_152381_e[i] * var2 + field_152382_f[i] * var4 + field_152383_g[i] * var6;
    }

    public void populateNoiseArray(
        double[] var1, double var2, double var4, double var6, int var8, int var9, int var10, double var11, double var13, double var15, double var17
    ) {
        if (var9 == 1) {
            int i5 = 0;
            int j5 = 0;
            int j = 0;
            int k5 = 0;
            double d14 = 0.0;
            double d15 = 0.0;
            int l5 = 0;
            double d16 = 1.0 / var17;

            for (int j2 = 0; j2 < var8; j2++) {
                double d17 = var2 + j2 * var11 + this.xCoord;
                int i6 = (int)d17;
                if (d17 < i6) {
                    i6--;
                }

                int k2 = i6 & 0xFF;
                d17 -= i6;
                double d18 = d17 * d17 * d17 * (d17 * (d17 * 6.0 - 15.0) + 10.0);

                for (int j6 = 0; j6 < var10; j6++) {
                    double d19 = var6 + j6 * var15 + this.zCoord;
                    int k6 = (int)d19;
                    if (d19 < k6) {
                        k6--;
                    }

                    int l6 = k6 & 0xFF;
                    d19 -= k6;
                    double d20 = d19 * d19 * d19 * (d19 * (d19 * 6.0 - 15.0) + 10.0);
                    i5 = this.permutations[k2] + 0;
                    j5 = this.permutations[i5] + l6;
                    j = this.permutations[k2 + 1] + 0;
                    k5 = this.permutations[j] + l6;
                    d14 = this.lerp(d18, this.func_76309_a(this.permutations[j5], d17, d19), this.grad(this.permutations[k5], d17 - 1.0, 0.0, d19));
                    d15 = this.lerp(
                        d18, this.grad(this.permutations[j5 + 1], d17, 0.0, d19 - 1.0), this.grad(this.permutations[k5 + 1], d17 - 1.0, 0.0, d19 - 1.0)
                    );
                    double d21 = this.lerp(d20, d14, d15);
                    var1[l5++] += d21 * d16;
                }
            }
        } else {
            int i = 0;
            double d0 = 1.0 / var17;
            int k = -1;
            int l = 0;
            int i1 = 0;
            int j1 = 0;
            int k1 = 0;
            int l1 = 0;
            int i2 = 0;
            double d1 = 0.0;
            double d2 = 0.0;
            double d3 = 0.0;
            double d4 = 0.0;

            for (int l2 = 0; l2 < var8; l2++) {
                double d5 = var2 + l2 * var11 + this.xCoord;
                int i3 = (int)d5;
                if (d5 < i3) {
                    i3--;
                }

                int j3 = i3 & 0xFF;
                d5 -= i3;
                double d6 = d5 * d5 * d5 * (d5 * (d5 * 6.0 - 15.0) + 10.0);

                for (int k3 = 0; k3 < var10; k3++) {
                    double d7 = var6 + k3 * var15 + this.zCoord;
                    int l3 = (int)d7;
                    if (d7 < l3) {
                        l3--;
                    }

                    int i4 = l3 & 0xFF;
                    d7 -= l3;
                    double d8 = d7 * d7 * d7 * (d7 * (d7 * 6.0 - 15.0) + 10.0);

                    for (int j4 = 0; j4 < var9; j4++) {
                        double d9 = var4 + j4 * var13 + this.yCoord;
                        int k4 = (int)d9;
                        if (d9 < k4) {
                            k4--;
                        }

                        int l4 = k4 & 0xFF;
                        d9 -= k4;
                        double d10 = d9 * d9 * d9 * (d9 * (d9 * 6.0 - 15.0) + 10.0);
                        if (j4 == 0 || l4 != k) {
                            k = l4;
                            l = this.permutations[j3] + l4;
                            i1 = this.permutations[l] + i4;
                            j1 = this.permutations[l + 1] + i4;
                            k1 = this.permutations[j3 + 1] + l4;
                            l1 = this.permutations[k1] + i4;
                            i2 = this.permutations[k1 + 1] + i4;
                            d1 = this.lerp(d6, this.grad(this.permutations[i1], d5, d9, d7), this.grad(this.permutations[l1], d5 - 1.0, d9, d7));
                            d2 = this.lerp(d6, this.grad(this.permutations[j1], d5, d9 - 1.0, d7), this.grad(this.permutations[i2], d5 - 1.0, d9 - 1.0, d7));
                            d3 = this.lerp(
                                d6, this.grad(this.permutations[i1 + 1], d5, d9, d7 - 1.0), this.grad(this.permutations[l1 + 1], d5 - 1.0, d9, d7 - 1.0)
                            );
                            d4 = this.lerp(
                                d6,
                                this.grad(this.permutations[j1 + 1], d5, d9 - 1.0, d7 - 1.0),
                                this.grad(this.permutations[i2 + 1], d5 - 1.0, d9 - 1.0, d7 - 1.0)
                            );
                        }

                        double d11 = this.lerp(d10, d1, d2);
                        double d12 = this.lerp(d10, d3, d4);
                        double d13 = this.lerp(d8, d11, d12);
                        var1[i++] += d13 * d0;
                    }
                }
            }
        }
    }
}
