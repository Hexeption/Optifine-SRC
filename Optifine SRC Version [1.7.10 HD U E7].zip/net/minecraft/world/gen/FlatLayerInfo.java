package net.minecraft.world.gen;

import net.minecraft.block.Block;

public class FlatLayerInfo {
    private Block field_151537_a;
    private int layerCount = 1;
    private int layerFillBlockMeta;
    private int layerMinimumY;

    public FlatLayerInfo(int var1, Block var2) {
        this.layerCount = var1;
        this.field_151537_a = var2;
    }

    public FlatLayerInfo(int var1, Block var2, int var3) {
        this(var1, var2);
        this.layerFillBlockMeta = var3;
    }

    public int getLayerCount() {
        return this.layerCount;
    }

    public Block func_151536_b() {
        return this.field_151537_a;
    }

    public int getFillBlockMeta() {
        return this.layerFillBlockMeta;
    }

    public int getMinY() {
        return this.layerMinimumY;
    }

    public void setMinY(int var1) {
        this.layerMinimumY = var1;
    }

    @Override
    public String toString() {
        String s = Integer.toString(Block.getIdFromBlock(this.field_151537_a));
        if (this.layerCount > 1) {
            s = this.layerCount + "x" + s;
        }

        if (this.layerFillBlockMeta > 0) {
            s = s + ":" + this.layerFillBlockMeta;
        }

        return s;
    }
}
