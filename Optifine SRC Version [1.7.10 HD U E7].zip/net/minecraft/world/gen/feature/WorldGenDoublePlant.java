package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenDoublePlant extends WorldGenerator {
    private int field_150549_a;

    public void func_150548_a(int var1) {
        this.field_150549_a = var1;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        boolean flag = false;

        for (int i = 0; i < 64; i++) {
            int j = var3 + var2.nextInt(8) - var2.nextInt(8);
            int k = var4 + var2.nextInt(4) - var2.nextInt(4);
            int l = var5 + var2.nextInt(8) - var2.nextInt(8);
            if (var1.isAirBlock(j, k, l) && (!var1.provider.hasNoSky || k < 254) && Blocks.double_plant.canPlaceBlockAt(var1, j, k, l)) {
                Blocks.double_plant.func_149889_c(var1, j, k, l, this.field_150549_a, 2);
                flag = true;
            }
        }

        return flag;
    }
}
