package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenBlockBlob extends WorldGenerator {
    private Block field_150545_a;
    private int field_150544_b;

    public WorldGenBlockBlob(Block var1, int var2) {
        super(false);
        this.field_150545_a = var1;
        this.field_150544_b = var2;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        while (var4 > 3) {
            if (!var1.isAirBlock(var3, var4 - 1, var5)) {
                Block block = var1.getBlock(var3, var4 - 1, var5);
                if (block == Blocks.grass || block == Blocks.dirt || block == Blocks.stone) {
                    break;
                }
            }

            var4--;
        }

        if (var4 <= 3) {
            return false;
        }

        int l1 = this.field_150544_b;

        for (int i = 0; l1 >= 0 && i < 3; i++) {
            int j = l1 + var2.nextInt(2);
            int k = l1 + var2.nextInt(2);
            int l = l1 + var2.nextInt(2);
            float f = (j + k + l) * 0.333F + 0.5F;

            for (int i1 = var3 - j; i1 <= var3 + j; i1++) {
                for (int j1 = var5 - l; j1 <= var5 + l; j1++) {
                    for (int k1 = var4 - k; k1 <= var4 + k; k1++) {
                        float f1 = i1 - var3;
                        float f2 = j1 - var5;
                        float f3 = k1 - var4;
                        if (!(f1 * f1 + f2 * f2 + f3 * f3 > f * f)) {
                            var1.setBlock(i1, k1, j1, this.field_150545_a, 0, 4);
                        }
                    }
                }
            }

            var3 += -(l1 + 1) + var2.nextInt(2 + l1 * 2);
            var5 += -(l1 + 1) + var2.nextInt(2 + l1 * 2);
            var4 += 0 - var2.nextInt(2);
        }

        return true;
    }
}
