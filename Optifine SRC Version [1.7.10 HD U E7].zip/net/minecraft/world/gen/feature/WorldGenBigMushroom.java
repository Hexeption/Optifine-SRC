package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenBigMushroom extends WorldGenerator {
    private int mushroomType = -1;

    public WorldGenBigMushroom(int var1) {
        super(true);
        this.mushroomType = var1;
    }

    public WorldGenBigMushroom() {
        super(false);
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = var2.nextInt(2);
        if (this.mushroomType >= 0) {
            i = this.mushroomType;
        }

        int j = var2.nextInt(3) + 4;
        boolean flag = true;
        if (var4 >= 1 && var4 + j + 1 < 256) {
            for (int k = var4; k <= var4 + 1 + j; k++) {
                byte b0 = 3;
                if (k <= var4 + 3) {
                    b0 = 0;
                }

                for (int l = var3 - b0; l <= var3 + b0 && flag; l++) {
                    for (int i1 = var5 - b0; i1 <= var5 + b0 && flag; i1++) {
                        if (k >= 0 && k < 256) {
                            Block block = var1.getBlock(l, k, i1);
                            if (block.getMaterial() != Material.air && block.getMaterial() != Material.leaves) {
                                flag = false;
                            }
                        } else {
                            flag = false;
                        }
                    }
                }
            }

            if (!flag) {
                return false;
            }

            Block block1 = var1.getBlock(var3, var4 - 1, var5);
            if (block1 != Blocks.dirt && block1 != Blocks.grass && block1 != Blocks.mycelium) {
                return false;
            }

            int l1 = var4 + j;
            if (i == 1) {
                l1 = var4 + j - 3;
            }

            for (int i2 = l1; i2 <= var4 + j; i2++) {
                int k2 = 1;
                if (i2 < var4 + j) {
                    k2++;
                }

                if (i == 0) {
                    k2 = 3;
                }

                for (int l2 = var3 - k2; l2 <= var3 + k2; l2++) {
                    for (int j1 = var5 - k2; j1 <= var5 + k2; j1++) {
                        int k1 = 5;
                        if (l2 == var3 - k2) {
                            k1--;
                        }

                        if (l2 == var3 + k2) {
                            k1++;
                        }

                        if (j1 == var5 - k2) {
                            k1 -= 3;
                        }

                        if (j1 == var5 + k2) {
                            k1 += 3;
                        }

                        if (i == 0 || i2 < var4 + j) {
                            if ((l2 == var3 - k2 || l2 == var3 + k2) && (j1 == var5 - k2 || j1 == var5 + k2)) {
                                continue;
                            }

                            if (l2 == var3 - (k2 - 1) && j1 == var5 - k2) {
                                k1 = 1;
                            }

                            if (l2 == var3 - k2 && j1 == var5 - (k2 - 1)) {
                                k1 = 1;
                            }

                            if (l2 == var3 + (k2 - 1) && j1 == var5 - k2) {
                                k1 = 3;
                            }

                            if (l2 == var3 + k2 && j1 == var5 - (k2 - 1)) {
                                k1 = 3;
                            }

                            if (l2 == var3 - (k2 - 1) && j1 == var5 + k2) {
                                k1 = 7;
                            }

                            if (l2 == var3 - k2 && j1 == var5 + (k2 - 1)) {
                                k1 = 7;
                            }

                            if (l2 == var3 + (k2 - 1) && j1 == var5 + k2) {
                                k1 = 9;
                            }

                            if (l2 == var3 + k2 && j1 == var5 + (k2 - 1)) {
                                k1 = 9;
                            }
                        }

                        if (k1 == 5 && i2 < var4 + j) {
                            k1 = 0;
                        }

                        if ((k1 != 0 || var4 >= var4 + j - 1) && !var1.getBlock(l2, i2, j1).isFullBlock()) {
                            this.setBlockAndNotifyAdequately(var1, l2, i2, j1, Block.getBlockById(Block.getIdFromBlock(Blocks.brown_mushroom_block) + i), k1);
                        }
                    }
                }
            }

            for (int j2 = 0; j2 < j; j2++) {
                Block block2 = var1.getBlock(var3, var4 + j2, var5);
                if (!block2.isFullBlock()) {
                    this.setBlockAndNotifyAdequately(var1, var3, var4 + j2, var5, Block.getBlockById(Block.getIdFromBlock(Blocks.brown_mushroom_block) + i), 10);
                }
            }

            return true;
        } else {
            return false;
        }
    }
}
