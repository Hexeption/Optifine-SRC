package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.world.World;

public class WorldGenDeadBush extends WorldGenerator {
    private Block field_150547_a;

    public WorldGenDeadBush(Block var1) {
        this.field_150547_a = var1;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        while (true) {
            Block block = var1.getBlock(var3, var4, var5);
            if (block.getMaterial() != Material.air && block.getMaterial() != Material.leaves || var4 <= 0) {
                for (int i = 0; i < 4; i++) {
                    int j = var3 + var2.nextInt(8) - var2.nextInt(8);
                    int k = var4 + var2.nextInt(4) - var2.nextInt(4);
                    int l = var5 + var2.nextInt(8) - var2.nextInt(8);
                    if (var1.isAirBlock(j, k, l) && this.field_150547_a.canBlockStay(var1, j, k, l)) {
                        var1.setBlock(j, k, l, this.field_150547_a, 0, 2);
                    }
                }

                return true;
            }

            var4--;
        }
    }
}
