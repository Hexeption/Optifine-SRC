package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class WorldGenIceSpike extends WorldGenerator {
    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        while (var1.isAirBlock(var3, var4, var5) && var4 > 2) {
            var4--;
        }

        if (var1.getBlock(var3, var4, var5) != Blocks.snow) {
            return false;
        }

        var4 += var2.nextInt(4);
        int i = var2.nextInt(4) + 7;
        int j = i / 4 + var2.nextInt(2);
        if (j > 1 && var2.nextInt(60) == 0) {
            var4 += 10 + var2.nextInt(30);
        }

        for (int k = 0; k < i; k++) {
            float f = (1.0F - (float)k / i) * j;
            int l = MathHelper.ceiling_float_int(f);

            for (int i1 = -l; i1 <= l; i1++) {
                float f1 = MathHelper.abs_int(i1) - 0.25F;

                for (int j1 = -l; j1 <= l; j1++) {
                    float f2 = MathHelper.abs_int(j1) - 0.25F;
                    if ((i1 == 0 && j1 == 0 || !(f1 * f1 + f2 * f2 > f * f))
                        && (i1 != -l && i1 != l && j1 != -l && j1 != l || !(var2.nextFloat() > 12.0F / 16.0F))) {
                        Block block = var1.getBlock(var3 + i1, var4 + k, var5 + j1);
                        if (block.getMaterial() == Material.air || block == Blocks.dirt || block == Blocks.snow || block == Blocks.ice) {
                            this.func_150515_a(var1, var3 + i1, var4 + k, var5 + j1, Blocks.packed_ice);
                        }

                        if (k != 0 && l > 1) {
                            block = var1.getBlock(var3 + i1, var4 - k, var5 + j1);
                            if (block.getMaterial() == Material.air || block == Blocks.dirt || block == Blocks.snow || block == Blocks.ice) {
                                this.func_150515_a(var1, var3 + i1, var4 - k, var5 + j1, Blocks.packed_ice);
                            }
                        }
                    }
                }
            }
        }

        int k1 = j - 1;
        if (k1 < 0) {
            k1 = 0;
        } else if (k1 > 1) {
            k1 = 1;
        }

        for (int l1 = -k1; l1 <= k1; l1++) {
            for (int i2 = -k1; i2 <= k1; i2++) {
                int j2 = var4 - 1;
                int k2 = 50;
                if (Math.abs(l1) == 1 && Math.abs(i2) == 1) {
                    k2 = var2.nextInt(5);
                }

                while (j2 > 50) {
                    Block block1 = var1.getBlock(var3 + l1, j2, var5 + i2);
                    if (block1.getMaterial() != Material.air
                        && block1 != Blocks.dirt
                        && block1 != Blocks.snow
                        && block1 != Blocks.ice
                        && block1 != Blocks.packed_ice) {
                        break;
                    }

                    this.func_150515_a(var1, var3 + l1, j2, var5 + i2, Blocks.packed_ice);
                    j2--;
                    if (--k2 <= 0) {
                        j2 -= var2.nextInt(5) + 1;
                        k2 = var2.nextInt(5);
                    }
                }
            }
        }

        return true;
    }
}
