package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenTaiga1 extends WorldGenAbstractTree {
    public WorldGenTaiga1() {
        super(false);
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = var2.nextInt(5) + 7;
        int j = i - var2.nextInt(2) - 3;
        int k = i - j;
        int l = 1 + var2.nextInt(k + 1);
        boolean flag = true;
        if (var4 >= 1 && var4 + i + 1 <= 256) {
            for (int i1 = var4; i1 <= var4 + 1 + i && flag; i1++) {
                int j1 = 1;
                if (i1 - var4 < j) {
                    j1 = 0;
                } else {
                    j1 = l;
                }

                for (int k1 = var3 - j1; k1 <= var3 + j1 && flag; k1++) {
                    for (int l1 = var5 - j1; l1 <= var5 + j1 && flag; l1++) {
                        if (i1 >= 0 && i1 < 256) {
                            Block block = var1.getBlock(k1, i1, l1);
                            if (!this.func_150523_a(block)) {
                                flag = false;
                            }
                        } else {
                            flag = false;
                        }
                    }
                }
            }

            if (!flag) {
                return false;
            }

            Block block1 = var1.getBlock(var3, var4 - 1, var5);
            if ((block1 == Blocks.grass || block1 == Blocks.dirt) && var4 < 256 - i - 1) {
                this.func_150515_a(var1, var3, var4 - 1, var5, Blocks.dirt);
                int k2 = 0;

                for (int l2 = var4 + i; l2 >= var4 + j; l2--) {
                    for (int j3 = var3 - k2; j3 <= var3 + k2; j3++) {
                        int k3 = j3 - var3;

                        for (int i2 = var5 - k2; i2 <= var5 + k2; i2++) {
                            int j2 = i2 - var5;
                            if ((Math.abs(k3) != k2 || Math.abs(j2) != k2 || k2 <= 0) && !var1.getBlock(j3, l2, i2).isFullBlock()) {
                                this.setBlockAndNotifyAdequately(var1, j3, l2, i2, Blocks.leaves, 1);
                            }
                        }
                    }

                    if (k2 >= 1 && l2 == var4 + j + 1) {
                        k2--;
                    } else if (k2 < l) {
                        k2++;
                    }
                }

                for (int i3 = 0; i3 < i - 1; i3++) {
                    Block block2 = var1.getBlock(var3, var4 + i3, var5);
                    if (block2.getMaterial() == Material.air || block2.getMaterial() == Material.leaves) {
                        this.setBlockAndNotifyAdequately(var1, var3, var4 + i3, var5, Blocks.log, 1);
                    }
                }

                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
