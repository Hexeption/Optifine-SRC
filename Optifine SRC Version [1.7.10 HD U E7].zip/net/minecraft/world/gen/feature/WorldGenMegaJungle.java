package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class WorldGenMegaJungle extends WorldGenHugeTrees {
    public WorldGenMegaJungle(boolean var1, int var2, int var3, int var4, int var5) {
        super(var1, var2, var3, var4, var5);
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = this.func_150533_a(var2);
        if (!this.func_150537_a(var1, var2, var3, var4, var5, i)) {
            return false;
        }

        this.func_150543_c(var1, var3, var5, var4 + i, 2, var2);

        for (int j = var4 + i - 2 - var2.nextInt(4); j > var4 + i / 2; j -= 2 + var2.nextInt(4)) {
            float f = var2.nextFloat() * (float)Math.PI * 2.0F;
            int k = var3 + (int)(0.5F + MathHelper.cos(f) * 4.0F);
            int l = var5 + (int)(0.5F + MathHelper.sin(f) * 4.0F);

            for (int i1 = 0; i1 < 5; i1++) {
                k = var3 + (int)(1.5F + MathHelper.cos(f) * i1);
                l = var5 + (int)(1.5F + MathHelper.sin(f) * i1);
                this.setBlockAndNotifyAdequately(var1, k, j - 3 + i1 / 2, l, Blocks.log, this.woodMetadata);
            }

            int j2 = 1 + var2.nextInt(2);
            int j1 = j;

            for (int k1 = j1 - j2; k1 <= j1; k1++) {
                int l1 = k1 - j1;
                this.func_150534_b(var1, k, k1, l, 1 - l1, var2);
            }
        }

        for (int i2 = 0; i2 < i; i2++) {
            Block block = var1.getBlock(var3, var4 + i2, var5);
            if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                this.setBlockAndNotifyAdequately(var1, var3, var4 + i2, var5, Blocks.log, this.woodMetadata);
                if (i2 > 0) {
                    if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 - 1, var4 + i2, var5)) {
                        this.setBlockAndNotifyAdequately(var1, var3 - 1, var4 + i2, var5, Blocks.vine, 8);
                    }

                    if (var2.nextInt(3) > 0 && var1.isAirBlock(var3, var4 + i2, var5 - 1)) {
                        this.setBlockAndNotifyAdequately(var1, var3, var4 + i2, var5 - 1, Blocks.vine, 1);
                    }
                }
            }

            if (i2 < i - 1) {
                block = var1.getBlock(var3 + 1, var4 + i2, var5);
                if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                    this.setBlockAndNotifyAdequately(var1, var3 + 1, var4 + i2, var5, Blocks.log, this.woodMetadata);
                    if (i2 > 0) {
                        if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 + 2, var4 + i2, var5)) {
                            this.setBlockAndNotifyAdequately(var1, var3 + 2, var4 + i2, var5, Blocks.vine, 2);
                        }

                        if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 + 1, var4 + i2, var5 - 1)) {
                            this.setBlockAndNotifyAdequately(var1, var3 + 1, var4 + i2, var5 - 1, Blocks.vine, 1);
                        }
                    }
                }

                block = var1.getBlock(var3 + 1, var4 + i2, var5 + 1);
                if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                    this.setBlockAndNotifyAdequately(var1, var3 + 1, var4 + i2, var5 + 1, Blocks.log, this.woodMetadata);
                    if (i2 > 0) {
                        if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 + 2, var4 + i2, var5 + 1)) {
                            this.setBlockAndNotifyAdequately(var1, var3 + 2, var4 + i2, var5 + 1, Blocks.vine, 2);
                        }

                        if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 + 1, var4 + i2, var5 + 2)) {
                            this.setBlockAndNotifyAdequately(var1, var3 + 1, var4 + i2, var5 + 2, Blocks.vine, 4);
                        }
                    }
                }

                block = var1.getBlock(var3, var4 + i2, var5 + 1);
                if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                    this.setBlockAndNotifyAdequately(var1, var3, var4 + i2, var5 + 1, Blocks.log, this.woodMetadata);
                    if (i2 > 0) {
                        if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 - 1, var4 + i2, var5 + 1)) {
                            this.setBlockAndNotifyAdequately(var1, var3 - 1, var4 + i2, var5 + 1, Blocks.vine, 8);
                        }

                        if (var2.nextInt(3) > 0 && var1.isAirBlock(var3, var4 + i2, var5 + 2)) {
                            this.setBlockAndNotifyAdequately(var1, var3, var4 + i2, var5 + 2, Blocks.vine, 4);
                        }
                    }
                }
            }
        }

        return true;
    }

    private void func_150543_c(World var1, int var2, int var3, int var4, int var5, Random var6) {
        byte b0 = 2;

        for (int i = var4 - b0; i <= var4; i++) {
            int j = i - var4;
            this.func_150535_a(var1, var2, i, var3, var5 + 1 - j, var6);
        }
    }
}
