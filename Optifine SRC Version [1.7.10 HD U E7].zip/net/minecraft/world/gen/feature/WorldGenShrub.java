package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenShrub extends WorldGenTrees {
    private int field_150528_a;
    private int field_150527_b;

    public WorldGenShrub(int var1, int var2) {
        super(false);
        this.field_150527_b = var1;
        this.field_150528_a = var2;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        while (true) {
            Block block = var1.getBlock(var3, var4, var5);
            if (block.getMaterial() != Material.air && block.getMaterial() != Material.leaves || var4 <= 0) {
                Block block1 = var1.getBlock(var3, var4, var5);
                if (block1 == Blocks.dirt || block1 == Blocks.grass) {
                    this.setBlockAndNotifyAdequately(var1, var3, ++var4, var5, Blocks.log, this.field_150527_b);

                    for (int i = var4; i <= var4 + 2; i++) {
                        int j = i - var4;
                        int k = 2 - j;

                        for (int l = var3 - k; l <= var3 + k; l++) {
                            int i1 = l - var3;

                            for (int j1 = var5 - k; j1 <= var5 + k; j1++) {
                                int k1 = j1 - var5;
                                if ((Math.abs(i1) != k || Math.abs(k1) != k || var2.nextInt(2) != 0) && !var1.getBlock(l, i, j1).isFullBlock()) {
                                    this.setBlockAndNotifyAdequately(var1, l, i, j1, Blocks.leaves, this.field_150528_a);
                                }
                            }
                        }
                    }
                }

                return true;
            }

            var4--;
        }
    }
}
