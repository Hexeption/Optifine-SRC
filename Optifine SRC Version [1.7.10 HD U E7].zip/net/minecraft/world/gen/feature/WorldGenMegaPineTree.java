package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class WorldGenMegaPineTree extends WorldGenHugeTrees {
    private boolean field_150542_e;

    public WorldGenMegaPineTree(boolean var1, boolean var2) {
        super(var1, 13, 15, 1, 1);
        this.field_150542_e = var2;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = this.func_150533_a(var2);
        if (!this.func_150537_a(var1, var2, var3, var4, var5, i)) {
            return false;
        }

        this.func_150541_c(var1, var3, var5, var4 + i, 0, var2);

        for (int j = 0; j < i; j++) {
            Block block = var1.getBlock(var3, var4 + j, var5);
            if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                this.setBlockAndNotifyAdequately(var1, var3, var4 + j, var5, Blocks.log, this.woodMetadata);
            }

            if (j < i - 1) {
                block = var1.getBlock(var3 + 1, var4 + j, var5);
                if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                    this.setBlockAndNotifyAdequately(var1, var3 + 1, var4 + j, var5, Blocks.log, this.woodMetadata);
                }

                block = var1.getBlock(var3 + 1, var4 + j, var5 + 1);
                if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                    this.setBlockAndNotifyAdequately(var1, var3 + 1, var4 + j, var5 + 1, Blocks.log, this.woodMetadata);
                }

                block = var1.getBlock(var3, var4 + j, var5 + 1);
                if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
                    this.setBlockAndNotifyAdequately(var1, var3, var4 + j, var5 + 1, Blocks.log, this.woodMetadata);
                }
            }
        }

        return true;
    }

    private void func_150541_c(World var1, int var2, int var3, int var4, int var5, Random var6) {
        int i = var6.nextInt(5);
        if (this.field_150542_e) {
            i += this.baseHeight;
        } else {
            i += 3;
        }

        int j = 0;

        for (int k = var4 - i; k <= var4; k++) {
            int l = var4 - k;
            int i1 = var5 + MathHelper.floor_float((float)l / i * 3.5F);
            this.func_150535_a(var1, var2, k, var3, i1 + (l > 0 && i1 == j && (k & 1) == 0 ? 1 : 0), var6);
            j = i1;
        }
    }

    @Override
    public void func_150524_b(World var1, Random var2, int var3, int var4, int var5) {
        this.func_150539_c(var1, var2, var3 - 1, var4, var5 - 1);
        this.func_150539_c(var1, var2, var3 + 2, var4, var5 - 1);
        this.func_150539_c(var1, var2, var3 - 1, var4, var5 + 2);
        this.func_150539_c(var1, var2, var3 + 2, var4, var5 + 2);

        for (int i = 0; i < 5; i++) {
            int j = var2.nextInt(64);
            int k = j % 8;
            int l = j / 8;
            if (k == 0 || k == 7 || l == 0 || l == 7) {
                this.func_150539_c(var1, var2, var3 - 3 + k, var4, var5 - 3 + l);
            }
        }
    }

    private void func_150539_c(World var1, Random var2, int var3, int var4, int var5) {
        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                if (Math.abs(i) != 2 || Math.abs(j) != 2) {
                    this.func_150540_a(var1, var3 + i, var4, var5 + j);
                }
            }
        }
    }

    private void func_150540_a(World var1, int var2, int var3, int var4) {
        for (int i = var3 + 2; i >= var3 - 3; i--) {
            Block block = var1.getBlock(var2, i, var4);
            if (block == Blocks.grass || block == Blocks.dirt) {
                this.setBlockAndNotifyAdequately(var1, var2, i, var4, Blocks.dirt, 2);
                break;
            }

            if (block.getMaterial() != Material.air && i < var3) {
                break;
            }
        }
    }
}
