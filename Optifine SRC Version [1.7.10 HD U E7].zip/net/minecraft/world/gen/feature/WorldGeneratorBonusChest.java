package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraft.world.World;

public class WorldGeneratorBonusChest extends WorldGenerator {
    private final WeightedRandomChestContent[] theBonusChestGenerator;
    private final int itemsToGenerateInBonusChest;

    public WorldGeneratorBonusChest(WeightedRandomChestContent[] var1, int var2) {
        this.theBonusChestGenerator = var1;
        this.itemsToGenerateInBonusChest = var2;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        while (true) {
            Block block = var1.getBlock(var3, var4, var5);
            if (block.getMaterial() != Material.air && block.getMaterial() != Material.leaves || var4 <= 1) {
                if (var4 < 1) {
                    return false;
                }

                var4++;

                for (int i = 0; i < 4; i++) {
                    int j = var3 + var2.nextInt(4) - var2.nextInt(4);
                    int k = var4 + var2.nextInt(3) - var2.nextInt(3);
                    int l = var5 + var2.nextInt(4) - var2.nextInt(4);
                    if (var1.isAirBlock(j, k, l) && World.doesBlockHaveSolidTopSurface(var1, j, k - 1, l)) {
                        var1.setBlock(j, k, l, Blocks.chest, 0, 2);
                        TileEntityChest tileentitychest = (TileEntityChest)var1.getTileEntity(j, k, l);
                        if (tileentitychest != null && tileentitychest != null) {
                            WeightedRandomChestContent.generateChestContents(
                                var2, this.theBonusChestGenerator, tileentitychest, this.itemsToGenerateInBonusChest
                            );
                        }

                        if (var1.isAirBlock(j - 1, k, l) && World.doesBlockHaveSolidTopSurface(var1, j - 1, k - 1, l)) {
                            var1.setBlock(j - 1, k, l, Blocks.torch, 0, 2);
                        }

                        if (var1.isAirBlock(j + 1, k, l) && World.doesBlockHaveSolidTopSurface(var1, j - 1, k - 1, l)) {
                            var1.setBlock(j + 1, k, l, Blocks.torch, 0, 2);
                        }

                        if (var1.isAirBlock(j, k, l - 1) && World.doesBlockHaveSolidTopSurface(var1, j - 1, k - 1, l)) {
                            var1.setBlock(j, k, l - 1, Blocks.torch, 0, 2);
                        }

                        if (var1.isAirBlock(j, k, l + 1) && World.doesBlockHaveSolidTopSurface(var1, j - 1, k - 1, l)) {
                            var1.setBlock(j, k, l + 1, Blocks.torch, 0, 2);
                        }

                        return true;
                    }
                }

                return false;
            }

            var4--;
        }
    }
}
