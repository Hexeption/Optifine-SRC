package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;

public class WorldGenFlowers extends WorldGenerator {
    private Block field_150552_a;
    private int field_150551_b;

    public WorldGenFlowers(Block var1) {
        this.field_150552_a = var1;
    }

    public void func_150550_a(Block var1, int var2) {
        this.field_150552_a = var1;
        this.field_150551_b = var2;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        for (int i = 0; i < 64; i++) {
            int j = var3 + var2.nextInt(8) - var2.nextInt(8);
            int k = var4 + var2.nextInt(4) - var2.nextInt(4);
            int l = var5 + var2.nextInt(8) - var2.nextInt(8);
            if (var1.isAirBlock(j, k, l) && (!var1.provider.hasNoSky || k < 255) && this.field_150552_a.canBlockStay(var1, j, k, l)) {
                var1.setBlock(j, k, l, this.field_150552_a, this.field_150551_b, 2);
            }
        }

        return true;
    }
}
