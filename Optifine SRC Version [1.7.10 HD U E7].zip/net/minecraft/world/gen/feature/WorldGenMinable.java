package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class WorldGenMinable extends WorldGenerator {
    private Block field_150519_a;
    private int numberOfBlocks;
    private Block field_150518_c;

    public WorldGenMinable(Block var1, int var2) {
        this(var1, var2, Blocks.stone);
    }

    public WorldGenMinable(Block var1, int var2, Block var3) {
        this.field_150519_a = var1;
        this.numberOfBlocks = var2;
        this.field_150518_c = var3;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        float f = var2.nextFloat() * (float)Math.PI;
        double d0 = var3 + 8 + MathHelper.sin(f) * this.numberOfBlocks / 8.0F;
        double d1 = var3 + 8 - MathHelper.sin(f) * this.numberOfBlocks / 8.0F;
        double d2 = var5 + 8 + MathHelper.cos(f) * this.numberOfBlocks / 8.0F;
        double d3 = var5 + 8 - MathHelper.cos(f) * this.numberOfBlocks / 8.0F;
        double d4 = var4 + var2.nextInt(3) - 2;
        double d5 = var4 + var2.nextInt(3) - 2;

        for (int i = 0; i <= this.numberOfBlocks; i++) {
            double d6 = d0 + (d1 - d0) * i / this.numberOfBlocks;
            double d7 = d4 + (d5 - d4) * i / this.numberOfBlocks;
            double d8 = d2 + (d3 - d2) * i / this.numberOfBlocks;
            double d9 = var2.nextDouble() * this.numberOfBlocks / 16.0;
            double d10 = (MathHelper.sin(i * (float)Math.PI / this.numberOfBlocks) + 1.0F) * d9 + 1.0;
            double d11 = (MathHelper.sin(i * (float)Math.PI / this.numberOfBlocks) + 1.0F) * d9 + 1.0;
            int j = MathHelper.floor_double(d6 - d10 / 2.0);
            int k = MathHelper.floor_double(d7 - d11 / 2.0);
            int l = MathHelper.floor_double(d8 - d10 / 2.0);
            int i1 = MathHelper.floor_double(d6 + d10 / 2.0);
            int j1 = MathHelper.floor_double(d7 + d11 / 2.0);
            int k1 = MathHelper.floor_double(d8 + d10 / 2.0);

            for (int l1 = j; l1 <= i1; l1++) {
                double d12 = (l1 + 0.5 - d6) / (d10 / 2.0);
                if (d12 * d12 < 1.0) {
                    for (int i2 = k; i2 <= j1; i2++) {
                        double d13 = (i2 + 0.5 - d7) / (d11 / 2.0);
                        if (d12 * d12 + d13 * d13 < 1.0) {
                            for (int j2 = l; j2 <= k1; j2++) {
                                double d14 = (j2 + 0.5 - d8) / (d10 / 2.0);
                                if (d12 * d12 + d13 * d13 + d14 * d14 < 1.0 && var1.getBlock(l1, i2, j2) == this.field_150518_c) {
                                    var1.setBlock(l1, i2, j2, this.field_150519_a, 0, 2);
                                }
                            }
                        }
                    }
                }
            }
        }

        return true;
    }
}
