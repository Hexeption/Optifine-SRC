package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraft.world.World;

public class WorldGenDungeons extends WorldGenerator {
    private static final WeightedRandomChestContent[] field_111189_a = new WeightedRandomChestContent[]{
        new WeightedRandomChestContent(Items.saddle, 0, 1, 1, 10),
        new WeightedRandomChestContent(Items.iron_ingot, 0, 1, 4, 10),
        new WeightedRandomChestContent(Items.bread, 0, 1, 1, 10),
        new WeightedRandomChestContent(Items.wheat, 0, 1, 4, 10),
        new WeightedRandomChestContent(Items.gunpowder, 0, 1, 4, 10),
        new WeightedRandomChestContent(Items.string, 0, 1, 4, 10),
        new WeightedRandomChestContent(Items.bucket, 0, 1, 1, 10),
        new WeightedRandomChestContent(Items.golden_apple, 0, 1, 1, 1),
        new WeightedRandomChestContent(Items.redstone, 0, 1, 4, 10),
        new WeightedRandomChestContent(Items.record_13, 0, 1, 1, 10),
        new WeightedRandomChestContent(Items.record_cat, 0, 1, 1, 10),
        new WeightedRandomChestContent(Items.name_tag, 0, 1, 1, 10),
        new WeightedRandomChestContent(Items.golden_horse_armor, 0, 1, 1, 2),
        new WeightedRandomChestContent(Items.iron_horse_armor, 0, 1, 1, 5),
        new WeightedRandomChestContent(Items.diamond_horse_armor, 0, 1, 1, 1)
    };

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        byte b0 = 3;
        int i = var2.nextInt(2) + 2;
        int j = var2.nextInt(2) + 2;
        int k = 0;

        for (int l = var3 - i - 1; l <= var3 + i + 1; l++) {
            for (int i1 = var4 - 1; i1 <= var4 + b0 + 1; i1++) {
                for (int j1 = var5 - j - 1; j1 <= var5 + j + 1; j1++) {
                    Material material = var1.getBlock(l, i1, j1).getMaterial();
                    if (i1 == var4 - 1 && !material.isSolid()) {
                        return false;
                    }

                    if (i1 == var4 + b0 + 1 && !material.isSolid()) {
                        return false;
                    }

                    if ((l == var3 - i - 1 || l == var3 + i + 1 || j1 == var5 - j - 1 || j1 == var5 + j + 1)
                        && i1 == var4
                        && var1.isAirBlock(l, i1, j1)
                        && var1.isAirBlock(l, i1 + 1, j1)) {
                        k++;
                    }
                }
            }
        }

        if (k >= 1 && k <= 5) {
            for (int i2 = var3 - i - 1; i2 <= var3 + i + 1; i2++) {
                for (int k2 = var4 + b0; k2 >= var4 - 1; k2--) {
                    for (int i3 = var5 - j - 1; i3 <= var5 + j + 1; i3++) {
                        if (i2 != var3 - i - 1 && k2 != var4 - 1 && i3 != var5 - j - 1 && i2 != var3 + i + 1 && k2 != var4 + b0 + 1 && i3 != var5 + j + 1) {
                            var1.setBlockToAir(i2, k2, i3);
                        } else if (k2 >= 0 && !var1.getBlock(i2, k2 - 1, i3).getMaterial().isSolid()) {
                            var1.setBlockToAir(i2, k2, i3);
                        } else if (var1.getBlock(i2, k2, i3).getMaterial().isSolid()) {
                            if (k2 == var4 - 1 && var2.nextInt(4) != 0) {
                                var1.setBlock(i2, k2, i3, Blocks.mossy_cobblestone, 0, 2);
                            } else {
                                var1.setBlock(i2, k2, i3, Blocks.cobblestone, 0, 2);
                            }
                        }
                    }
                }
            }

            for (int j2 = 0; j2 < 2; j2++) {
                for (int l2 = 0; l2 < 3; l2++) {
                    int j3 = var3 + var2.nextInt(i * 2 + 1) - i;
                    int k3 = var4;
                    int k1 = var5 + var2.nextInt(j * 2 + 1) - j;
                    if (var1.isAirBlock(j3, k3, k1)) {
                        int l1 = 0;
                        if (var1.getBlock(j3 - 1, k3, k1).getMaterial().isSolid()) {
                            l1++;
                        }

                        if (var1.getBlock(j3 + 1, k3, k1).getMaterial().isSolid()) {
                            l1++;
                        }

                        if (var1.getBlock(j3, k3, k1 - 1).getMaterial().isSolid()) {
                            l1++;
                        }

                        if (var1.getBlock(j3, k3, k1 + 1).getMaterial().isSolid()) {
                            l1++;
                        }

                        if (l1 == 1) {
                            var1.setBlock(j3, k3, k1, Blocks.chest, 0, 2);
                            WeightedRandomChestContent[] aweightedrandomchestcontent = WeightedRandomChestContent.func_92080_a(
                                field_111189_a, Items.enchanted_book.func_92114_b(var2)
                            );
                            TileEntityChest tileentitychest = (TileEntityChest)var1.getTileEntity(j3, k3, k1);
                            if (tileentitychest != null) {
                                WeightedRandomChestContent.generateChestContents(var2, aweightedrandomchestcontent, tileentitychest, 8);
                            }
                            break;
                        }
                    }
                }
            }

            var1.setBlock(var3, var4, var5, Blocks.mob_spawner, 0, 2);
            TileEntityMobSpawner tileentitymobspawner = (TileEntityMobSpawner)var1.getTileEntity(var3, var4, var5);
            if (tileentitymobspawner != null) {
                tileentitymobspawner.func_145881_a().setEntityName(this.pickMobSpawner(var2));
            } else {
                System.err.println("Failed to fetch mob spawner entity at (" + var3 + ", " + var4 + ", " + var5 + ")");
            }

            return true;
        } else {
            return false;
        }
    }

    private String pickMobSpawner(Random var1) {
        int i = var1.nextInt(4);
        if (i == 0) {
            return "Skeleton";
        } else if (i == 1) {
            return "Zombie";
        } else if (i == 2) {
            return "Zombie";
        } else {
            return i == 3 ? "Spider" : "";
        }
    }
}
