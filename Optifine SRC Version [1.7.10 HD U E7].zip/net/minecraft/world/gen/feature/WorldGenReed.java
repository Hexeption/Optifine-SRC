package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenReed extends WorldGenerator {
    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        for (int i = 0; i < 20; i++) {
            int j = var3 + var2.nextInt(4) - var2.nextInt(4);
            int k = var4;
            int l = var5 + var2.nextInt(4) - var2.nextInt(4);
            if (var1.isAirBlock(j, k, l)
                && (
                    var1.getBlock(j - 1, k - 1, l).getMaterial() == Material.water
                        || var1.getBlock(j + 1, k - 1, l).getMaterial() == Material.water
                        || var1.getBlock(j, k - 1, l - 1).getMaterial() == Material.water
                        || var1.getBlock(j, k - 1, l + 1).getMaterial() == Material.water
                )) {
                int i1 = 2 + var2.nextInt(var2.nextInt(3) + 1);

                for (int j1 = 0; j1 < i1; j1++) {
                    if (Blocks.reeds.canBlockStay(var1, j, k + j1, l)) {
                        var1.setBlock(j, k + j1, l, Blocks.reeds, 0, 2);
                    }
                }
            }
        }

        return true;
    }
}
