package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class WorldGenBigTree extends WorldGenAbstractTree {
    static final byte[] otherCoordPairs = new byte[]{2, 0, 0, 1, 2, 1};
    Random rand = new Random();
    World worldObj;
    int[] basePos = new int[]{0, 0, 0};
    int heightLimit;
    int height;
    double heightAttenuation = 0.618;
    double branchDensity = 1.0;
    double branchSlope = 0.381;
    double scaleWidth = 1.0;
    double leafDensity = 1.0;
    int trunkSize = 1;
    int heightLimitLimit = 12;
    int leafDistanceLimit = 4;
    int[][] leafNodes;

    public WorldGenBigTree(boolean var1) {
        super(var1);
    }

    void generateLeafNodeList() {
        this.height = (int)(this.heightLimit * this.heightAttenuation);
        if (this.height >= this.heightLimit) {
            this.height = this.heightLimit - 1;
        }

        int i = (int)(1.382 + Math.pow(this.leafDensity * this.heightLimit / 13.0, 2.0));
        if (i < 1) {
            i = 1;
        }

        int[][] aint = new int[i * this.heightLimit][4];
        int j = this.basePos[1] + this.heightLimit - this.leafDistanceLimit;
        int k = 1;
        int l = this.basePos[1] + this.height;
        int i1 = j - this.basePos[1];
        aint[0][0] = this.basePos[0];
        aint[0][1] = j;
        aint[0][2] = this.basePos[2];
        aint[0][3] = l;
        j--;

        while (i1 >= 0) {
            int j1 = 0;
            float f = this.layerSize(i1);
            if (f < 0.0F) {
                j--;
                i1--;
            } else {
                double d0 = 0.5;

                while (j1 < i) {
                    double d1 = this.scaleWidth * (f * (this.rand.nextFloat() + 0.328));
                    double d2 = this.rand.nextFloat() * 2.0 * 3.14159;
                    int k1 = MathHelper.floor_double(d1 * Math.sin(d2) + this.basePos[0] + d0);
                    int l1 = MathHelper.floor_double(d1 * Math.cos(d2) + this.basePos[2] + d0);
                    int[] aint1 = new int[]{k1, j, l1};
                    int[] aint2 = new int[]{k1, j + this.leafDistanceLimit, l1};
                    if (this.checkBlockLine(aint1, aint2) == -1) {
                        int[] aint3 = new int[]{this.basePos[0], this.basePos[1], this.basePos[2]};
                        double d3 = Math.sqrt(Math.pow(Math.abs(this.basePos[0] - aint1[0]), 2.0) + Math.pow(Math.abs(this.basePos[2] - aint1[2]), 2.0));
                        double d4 = d3 * this.branchSlope;
                        if (aint1[1] - d4 > l) {
                            aint3[1] = l;
                        } else {
                            aint3[1] = (int)(aint1[1] - d4);
                        }

                        if (this.checkBlockLine(aint3, aint1) == -1) {
                            aint[k][0] = k1;
                            aint[k][1] = j;
                            aint[k][2] = l1;
                            aint[k][3] = aint3[1];
                            k++;
                        }
                    }

                    j1++;
                }

                j--;
                i1--;
            }
        }

        this.leafNodes = new int[k][4];
        System.arraycopy(aint, 0, this.leafNodes, 0, k);
    }

    void func_150529_a(int var1, int var2, int var3, float var4, byte var5, Block var6) {
        int i = (int)(var4 + 0.618);
        byte b0 = otherCoordPairs[var5];
        byte b1 = otherCoordPairs[var5 + 3];
        int[] aint = new int[]{var1, var2, var3};
        int[] aint1 = new int[]{0, 0, 0};
        int j = -i;
        int k = -i;

        for (aint1[var5] = aint[var5]; j <= i; j++) {
            aint1[b0] = aint[b0] + j;
            k = -i;

            while (k <= i) {
                double d0 = Math.pow(Math.abs(j) + 0.5, 2.0) + Math.pow(Math.abs(k) + 0.5, 2.0);
                if (d0 > var4 * var4) {
                    k++;
                } else {
                    aint1[b1] = aint[b1] + k;
                    Block block = this.worldObj.getBlock(aint1[0], aint1[1], aint1[2]);
                    if (block.getMaterial() != Material.air && block.getMaterial() != Material.leaves) {
                        k++;
                    } else {
                        this.setBlockAndNotifyAdequately(this.worldObj, aint1[0], aint1[1], aint1[2], var6, 0);
                        k++;
                    }
                }
            }
        }
    }

    float layerSize(int var1) {
        if (var1 < this.heightLimit * 0.3) {
            return -1.618F;
        }

        float f = this.heightLimit / 2.0F;
        float f1 = this.heightLimit / 2.0F - var1;
        float f2;
        if (f1 == 0.0F) {
            f2 = f;
        } else if (Math.abs(f1) >= f) {
            f2 = 0.0F;
        } else {
            f2 = (float)Math.sqrt(Math.pow(Math.abs(f), 2.0) - Math.pow(Math.abs(f1), 2.0));
        }

        return f2 * 0.5F;
    }

    float leafSize(int var1) {
        if (var1 < 0 || var1 >= this.leafDistanceLimit) {
            return -1.0F;
        } else {
            return var1 != 0 && var1 != this.leafDistanceLimit - 1 ? 3.0F : 2.0F;
        }
    }

    void generateLeafNode(int var1, int var2, int var3) {
        int i = var2;

        for (int j = var2 + this.leafDistanceLimit; i < j; i++) {
            float f = this.leafSize(i - var2);
            this.func_150529_a(var1, i, var3, f, (byte)1, Blocks.leaves);
        }
    }

    void func_150530_a(int[] var1, int[] var2, Block var3) {
        int[] aint = new int[]{0, 0, 0};
        byte b0 = 0;
        byte b1 = 0;

        while (b0 < 3) {
            aint[b0] = var2[b0] - var1[b0];
            if (Math.abs(aint[b0]) > Math.abs(aint[b1])) {
                b1 = b0;
            }

            b0++;
        }

        if (aint[b1] != 0) {
            byte b2 = otherCoordPairs[b1];
            byte b3 = otherCoordPairs[b1 + 3];
            byte b4;
            if (aint[b1] > 0) {
                b4 = 1;
            } else {
                b4 = -1;
            }

            double d0 = (double)aint[b2] / aint[b1];
            double d1 = (double)aint[b3] / aint[b1];
            int[] aint1 = new int[]{0, 0, 0};
            byte b5 = 0;

            for (int i = aint[b1] + b4; b5 != i; b5 += b4) {
                aint1[b1] = MathHelper.floor_double(var1[b1] + b5 + 0.5);
                aint1[b2] = MathHelper.floor_double(var1[b2] + b5 * d0 + 0.5);
                aint1[b3] = MathHelper.floor_double(var1[b3] + b5 * d1 + 0.5);
                byte b6 = 0;
                int j = Math.abs(aint1[0] - var1[0]);
                int k = Math.abs(aint1[2] - var1[2]);
                int l = Math.max(j, k);
                if (l > 0) {
                    if (j == l) {
                        b6 = 4;
                    } else if (k == l) {
                        b6 = 8;
                    }
                }

                this.setBlockAndNotifyAdequately(this.worldObj, aint1[0], aint1[1], aint1[2], var3, b6);
            }
        }
    }

    void generateLeaves() {
        int i = 0;

        for (int j = this.leafNodes.length; i < j; i++) {
            int k = this.leafNodes[i][0];
            int l = this.leafNodes[i][1];
            int i1 = this.leafNodes[i][2];
            this.generateLeafNode(k, l, i1);
        }
    }

    boolean leafNodeNeedsBase(int var1) {
        return !(var1 < this.heightLimit * 0.2);
    }

    void generateTrunk() {
        int i = this.basePos[0];
        int j = this.basePos[1];
        int k = this.basePos[1] + this.height;
        int l = this.basePos[2];
        int[] aint = new int[]{i, j, l};
        int[] aint1 = new int[]{i, k, l};
        this.func_150530_a(aint, aint1, Blocks.log);
        if (this.trunkSize == 2) {
            aint[0]++;
            aint1[0]++;
            this.func_150530_a(aint, aint1, Blocks.log);
            aint[2]++;
            aint1[2]++;
            this.func_150530_a(aint, aint1, Blocks.log);
            aint[0] += -1;
            aint1[0] += -1;
            this.func_150530_a(aint, aint1, Blocks.log);
        }
    }

    void generateLeafNodeBases() {
        int i = 0;
        int j = this.leafNodes.length;
        int[] aint = new int[]{this.basePos[0], this.basePos[1], this.basePos[2]};

        while (i < j) {
            int[] aint1 = this.leafNodes[i];
            int[] aint2 = new int[]{aint1[0], aint1[1], aint1[2]};
            aint[1] = aint1[3];
            int k = aint[1] - this.basePos[1];
            if (this.leafNodeNeedsBase(k)) {
                this.func_150530_a(aint, aint2, Blocks.log);
            }

            i++;
        }
    }

    int checkBlockLine(int[] var1, int[] var2) {
        int[] aint = new int[]{0, 0, 0};
        byte b0 = 0;
        byte b1 = 0;

        while (b0 < 3) {
            aint[b0] = var2[b0] - var1[b0];
            if (Math.abs(aint[b0]) > Math.abs(aint[b1])) {
                b1 = b0;
            }

            b0++;
        }

        if (aint[b1] == 0) {
            return -1;
        }

        byte b2 = otherCoordPairs[b1];
        byte b3 = otherCoordPairs[b1 + 3];
        byte b4;
        if (aint[b1] > 0) {
            b4 = 1;
        } else {
            b4 = -1;
        }

        double d0 = (double)aint[b2] / aint[b1];
        double d1 = (double)aint[b3] / aint[b1];
        int[] aint1 = new int[]{0, 0, 0};
        byte b5 = 0;

        int i;
        for (i = aint[b1] + b4; b5 != i; b5 += b4) {
            aint1[b1] = var1[b1] + b5;
            aint1[b2] = MathHelper.floor_double(var1[b2] + b5 * d0);
            aint1[b3] = MathHelper.floor_double(var1[b3] + b5 * d1);
            Block block = this.worldObj.getBlock(aint1[0], aint1[1], aint1[2]);
            if (!this.func_150523_a(block)) {
                break;
            }
        }

        return b5 == i ? -1 : Math.abs(b5);
    }

    boolean validTreeLocation() {
        int[] aint = new int[]{this.basePos[0], this.basePos[1], this.basePos[2]};
        int[] aint1 = new int[]{this.basePos[0], this.basePos[1] + this.heightLimit - 1, this.basePos[2]};
        Block block = this.worldObj.getBlock(this.basePos[0], this.basePos[1] - 1, this.basePos[2]);
        if (block != Blocks.dirt && block != Blocks.grass && block != Blocks.farmland) {
            return false;
        }

        int i = this.checkBlockLine(aint, aint1);
        if (i == -1) {
            return true;
        }

        if (i < 6) {
            return false;
        }

        this.heightLimit = i;
        return true;
    }

    @Override
    public void setScale(double var1, double var3, double var5) {
        this.heightLimitLimit = (int)(var1 * 12.0);
        if (var1 > 0.5) {
            this.leafDistanceLimit = 5;
        }

        this.scaleWidth = var3;
        this.leafDensity = var5;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        this.worldObj = var1;
        long i = var2.nextLong();
        this.rand.setSeed(i);
        this.basePos[0] = var3;
        this.basePos[1] = var4;
        this.basePos[2] = var5;
        if (this.heightLimit == 0) {
            this.heightLimit = 5 + this.rand.nextInt(this.heightLimitLimit);
        }

        if (!this.validTreeLocation()) {
            return false;
        }

        this.generateLeafNodeList();
        this.generateLeaves();
        this.generateTrunk();
        this.generateLeafNodeBases();
        return true;
    }
}
