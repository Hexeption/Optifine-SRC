package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.Direction;
import net.minecraft.world.World;

public class WorldGenSavannaTree extends WorldGenAbstractTree {
    public WorldGenSavannaTree(boolean var1) {
        super(var1);
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = var2.nextInt(3) + var2.nextInt(3) + 5;
        boolean flag = true;
        if (var4 >= 1 && var4 + i + 1 <= 256) {
            for (int j = var4; j <= var4 + 1 + i; j++) {
                byte b0 = 1;
                if (j == var4) {
                    b0 = 0;
                }

                if (j >= var4 + 1 + i - 2) {
                    b0 = 2;
                }

                for (int k = var3 - b0; k <= var3 + b0 && flag; k++) {
                    for (int l = var5 - b0; l <= var5 + b0 && flag; l++) {
                        if (j >= 0 && j < 256) {
                            Block block = var1.getBlock(k, j, l);
                            if (!this.func_150523_a(block)) {
                                flag = false;
                            }
                        } else {
                            flag = false;
                        }
                    }
                }
            }

            if (!flag) {
                return false;
            }

            Block block3 = var1.getBlock(var3, var4 - 1, var5);
            if ((block3 == Blocks.grass || block3 == Blocks.dirt) && var4 < 256 - i - 1) {
                this.func_150515_a(var1, var3, var4 - 1, var5, Blocks.dirt);
                int k2 = var2.nextInt(4);
                int l2 = i - var2.nextInt(4) - 1;
                int i3 = 3 - var2.nextInt(3);
                int j3 = var3;
                int i1 = var5;
                int j1 = 0;

                for (int k1 = 0; k1 < i; k1++) {
                    int l1 = var4 + k1;
                    if (k1 >= l2 && i3 > 0) {
                        j3 += Direction.offsetX[k2];
                        i1 += Direction.offsetZ[k2];
                        i3--;
                    }

                    Block block1 = var1.getBlock(j3, l1, i1);
                    if (block1.getMaterial() == Material.air || block1.getMaterial() == Material.leaves) {
                        this.setBlockAndNotifyAdequately(var1, j3, l1, i1, Blocks.log2, 0);
                        j1 = l1;
                    }
                }

                for (int k3 = -1; k3 <= 1; k3++) {
                    for (int j4 = -1; j4 <= 1; j4++) {
                        this.func_150525_a(var1, j3 + k3, j1 + 1, i1 + j4);
                    }
                }

                this.func_150525_a(var1, j3 + 2, j1 + 1, i1);
                this.func_150525_a(var1, j3 - 2, j1 + 1, i1);
                this.func_150525_a(var1, j3, j1 + 1, i1 + 2);
                this.func_150525_a(var1, j3, j1 + 1, i1 - 2);

                for (int l3 = -3; l3 <= 3; l3++) {
                    for (int k4 = -3; k4 <= 3; k4++) {
                        if (Math.abs(l3) != 3 || Math.abs(k4) != 3) {
                            this.func_150525_a(var1, j3 + l3, j1, i1 + k4);
                        }
                    }
                }

                j3 = var3;
                i1 = var5;
                int i4 = var2.nextInt(4);
                if (i4 != k2) {
                    int l4 = l2 - var2.nextInt(2) - 1;
                    int i5 = 1 + var2.nextInt(3);
                    j1 = 0;

                    for (int i2 = l4; i2 < i && i5 > 0; i5--) {
                        if (i2 >= 1) {
                            int j2 = var4 + i2;
                            j3 += Direction.offsetX[i4];
                            i1 += Direction.offsetZ[i4];
                            Block block2 = var1.getBlock(j3, j2, i1);
                            if (block2.getMaterial() == Material.air || block2.getMaterial() == Material.leaves) {
                                this.setBlockAndNotifyAdequately(var1, j3, j2, i1, Blocks.log2, 0);
                                j1 = j2;
                            }
                        }

                        i2++;
                    }

                    if (j1 > 0) {
                        for (int j5 = -1; j5 <= 1; j5++) {
                            for (int l5 = -1; l5 <= 1; l5++) {
                                this.func_150525_a(var1, j3 + j5, j1 + 1, i1 + l5);
                            }
                        }

                        for (int k5 = -2; k5 <= 2; k5++) {
                            for (int i6 = -2; i6 <= 2; i6++) {
                                if (Math.abs(k5) != 2 || Math.abs(i6) != 2) {
                                    this.func_150525_a(var1, j3 + k5, j1, i1 + i6);
                                }
                            }
                        }
                    }
                }

                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private void func_150525_a(World var1, int var2, int var3, int var4) {
        Block block = var1.getBlock(var2, var3, var4);
        if (block.getMaterial() == Material.air || block.getMaterial() == Material.leaves) {
            this.setBlockAndNotifyAdequately(var1, var2, var3, var4, Blocks.leaves2, 0);
        }
    }
}
