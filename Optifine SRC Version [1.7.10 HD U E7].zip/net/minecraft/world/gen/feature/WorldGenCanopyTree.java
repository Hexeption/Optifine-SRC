package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.Direction;
import net.minecraft.world.World;

public class WorldGenCanopyTree extends WorldGenAbstractTree {
    public WorldGenCanopyTree(boolean var1) {
        super(var1);
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = var2.nextInt(3) + var2.nextInt(2) + 6;
        boolean flag = true;
        if (var4 >= 1 && var4 + i + 1 <= 256) {
            for (int j = var4; j <= var4 + 1 + i; j++) {
                byte b0 = 1;
                if (j == var4) {
                    b0 = 0;
                }

                if (j >= var4 + 1 + i - 2) {
                    b0 = 2;
                }

                for (int k = var3 - b0; k <= var3 + b0 && flag; k++) {
                    for (int l = var5 - b0; l <= var5 + b0 && flag; l++) {
                        if (j >= 0 && j < 256) {
                            Block block = var1.getBlock(k, j, l);
                            if (!this.func_150523_a(block)) {
                                flag = false;
                            }
                        } else {
                            flag = false;
                        }
                    }
                }
            }

            if (!flag) {
                return false;
            }

            Block block2 = var1.getBlock(var3, var4 - 1, var5);
            if ((block2 == Blocks.grass || block2 == Blocks.dirt) && var4 < 256 - i - 1) {
                this.func_150515_a(var1, var3, var4 - 1, var5, Blocks.dirt);
                this.func_150515_a(var1, var3 + 1, var4 - 1, var5, Blocks.dirt);
                this.func_150515_a(var1, var3 + 1, var4 - 1, var5 + 1, Blocks.dirt);
                this.func_150515_a(var1, var3, var4 - 1, var5 + 1, Blocks.dirt);
                int k2 = var2.nextInt(4);
                int l2 = i - var2.nextInt(4);
                int i3 = 2 - var2.nextInt(3);
                int j3 = var3;
                int i1 = var5;
                int j1 = 0;

                for (int k1 = 0; k1 < i; k1++) {
                    int l1 = var4 + k1;
                    if (k1 >= l2 && i3 > 0) {
                        j3 += Direction.offsetX[k2];
                        i1 += Direction.offsetZ[k2];
                        i3--;
                    }

                    Block block1 = var1.getBlock(j3, l1, i1);
                    if (block1.getMaterial() == Material.air || block1.getMaterial() == Material.leaves) {
                        this.setBlockAndNotifyAdequately(var1, j3, l1, i1, Blocks.log2, 1);
                        this.setBlockAndNotifyAdequately(var1, j3 + 1, l1, i1, Blocks.log2, 1);
                        this.setBlockAndNotifyAdequately(var1, j3, l1, i1 + 1, Blocks.log2, 1);
                        this.setBlockAndNotifyAdequately(var1, j3 + 1, l1, i1 + 1, Blocks.log2, 1);
                        j1 = l1;
                    }
                }

                for (int k3 = -2; k3 <= 0; k3++) {
                    for (int j4 = -2; j4 <= 0; j4++) {
                        byte b1 = -1;
                        this.func_150526_a(var1, j3 + k3, j1 + b1, i1 + j4);
                        this.func_150526_a(var1, 1 + j3 - k3, j1 + b1, i1 + j4);
                        this.func_150526_a(var1, j3 + k3, j1 + b1, 1 + i1 - j4);
                        this.func_150526_a(var1, 1 + j3 - k3, j1 + b1, 1 + i1 - j4);
                        if ((k3 > -2 || j4 > -1) && (k3 != -1 || j4 != -2)) {
                            b1 = 1;
                            this.func_150526_a(var1, j3 + k3, j1 + b1, i1 + j4);
                            this.func_150526_a(var1, 1 + j3 - k3, j1 + b1, i1 + j4);
                            this.func_150526_a(var1, j3 + k3, j1 + b1, 1 + i1 - j4);
                            this.func_150526_a(var1, 1 + j3 - k3, j1 + b1, 1 + i1 - j4);
                        }
                    }
                }

                if (var2.nextBoolean()) {
                    this.func_150526_a(var1, j3, j1 + 2, i1);
                    this.func_150526_a(var1, j3 + 1, j1 + 2, i1);
                    this.func_150526_a(var1, j3 + 1, j1 + 2, i1 + 1);
                    this.func_150526_a(var1, j3, j1 + 2, i1 + 1);
                }

                for (int l3 = -3; l3 <= 4; l3++) {
                    for (int k4 = -3; k4 <= 4; k4++) {
                        if ((l3 != -3 || k4 != -3)
                            && (l3 != -3 || k4 != 4)
                            && (l3 != 4 || k4 != -3)
                            && (l3 != 4 || k4 != 4)
                            && (Math.abs(l3) < 3 || Math.abs(k4) < 3)) {
                            this.func_150526_a(var1, j3 + l3, j1, i1 + k4);
                        }
                    }
                }

                for (int i4 = -1; i4 <= 2; i4++) {
                    for (int l4 = -1; l4 <= 2; l4++) {
                        if ((i4 < 0 || i4 > 1 || l4 < 0 || l4 > 1) && var2.nextInt(3) <= 0) {
                            int i5 = var2.nextInt(3) + 2;

                            for (int i2 = 0; i2 < i5; i2++) {
                                this.setBlockAndNotifyAdequately(var1, var3 + i4, j1 - i2 - 1, var5 + l4, Blocks.log2, 1);
                            }

                            for (int j5 = -1; j5 <= 1; j5++) {
                                for (int j2 = -1; j2 <= 1; j2++) {
                                    this.func_150526_a(var1, j3 + i4 + j5, j1 - 0, i1 + l4 + j2);
                                }
                            }

                            for (int k5 = -2; k5 <= 2; k5++) {
                                for (int l5 = -2; l5 <= 2; l5++) {
                                    if (Math.abs(k5) != 2 || Math.abs(l5) != 2) {
                                        this.func_150526_a(var1, j3 + i4 + k5, j1 - 1, i1 + l4 + l5);
                                    }
                                }
                            }
                        }
                    }
                }

                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private void func_150526_a(World var1, int var2, int var3, int var4) {
        Block block = var1.getBlock(var2, var3, var4);
        if (block.getMaterial() == Material.air) {
            this.setBlockAndNotifyAdequately(var1, var2, var3, var4, Blocks.leaves2, 1);
        }
    }
}
