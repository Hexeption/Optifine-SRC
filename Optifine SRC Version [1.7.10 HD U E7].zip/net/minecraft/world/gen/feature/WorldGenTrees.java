package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.Direction;
import net.minecraft.world.World;

public class WorldGenTrees extends WorldGenAbstractTree {
    private final int minTreeHeight;
    private final boolean vinesGrow;
    private final int metaWood;
    private final int metaLeaves;

    public WorldGenTrees(boolean var1) {
        this(var1, 4, 0, 0, false);
    }

    public WorldGenTrees(boolean var1, int var2, int var3, int var4, boolean var5) {
        super(var1);
        this.minTreeHeight = var2;
        this.metaWood = var3;
        this.metaLeaves = var4;
        this.vinesGrow = var5;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = var2.nextInt(3) + this.minTreeHeight;
        boolean flag = true;
        if (var4 >= 1 && var4 + i + 1 <= 256) {
            for (int j = var4; j <= var4 + 1 + i; j++) {
                byte b0 = 1;
                if (j == var4) {
                    b0 = 0;
                }

                if (j >= var4 + 1 + i - 2) {
                    b0 = 2;
                }

                for (int k = var3 - b0; k <= var3 + b0 && flag; k++) {
                    for (int l = var5 - b0; l <= var5 + b0 && flag; l++) {
                        if (j >= 0 && j < 256) {
                            Block block = var1.getBlock(k, j, l);
                            if (!this.func_150523_a(block)) {
                                flag = false;
                            }
                        } else {
                            flag = false;
                        }
                    }
                }
            }

            if (!flag) {
                return false;
            }

            Block block2 = var1.getBlock(var3, var4 - 1, var5);
            if ((block2 == Blocks.grass || block2 == Blocks.dirt || block2 == Blocks.farmland) && var4 < 256 - i - 1) {
                this.func_150515_a(var1, var3, var4 - 1, var5, Blocks.dirt);
                byte b1 = 3;
                byte b2 = 0;

                for (int j2 = var4 - b1 + i; j2 <= var4 + i; j2++) {
                    int j3 = j2 - (var4 + i);
                    int i1 = b2 + 1 - j3 / 2;

                    for (int j1 = var3 - i1; j1 <= var3 + i1; j1++) {
                        int k1 = j1 - var3;

                        for (int l1 = var5 - i1; l1 <= var5 + i1; l1++) {
                            int i2 = l1 - var5;
                            if (Math.abs(k1) != i1 || Math.abs(i2) != i1 || var2.nextInt(2) != 0 && j3 != 0) {
                                Block block1 = var1.getBlock(j1, j2, l1);
                                if (block1.getMaterial() == Material.air || block1.getMaterial() == Material.leaves) {
                                    this.setBlockAndNotifyAdequately(var1, j1, j2, l1, Blocks.leaves, this.metaLeaves);
                                }
                            }
                        }
                    }
                }

                for (int k2 = 0; k2 < i; k2++) {
                    Block block3 = var1.getBlock(var3, var4 + k2, var5);
                    if (block3.getMaterial() == Material.air || block3.getMaterial() == Material.leaves) {
                        this.setBlockAndNotifyAdequately(var1, var3, var4 + k2, var5, Blocks.log, this.metaWood);
                        if (this.vinesGrow && k2 > 0) {
                            if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 - 1, var4 + k2, var5)) {
                                this.setBlockAndNotifyAdequately(var1, var3 - 1, var4 + k2, var5, Blocks.vine, 8);
                            }

                            if (var2.nextInt(3) > 0 && var1.isAirBlock(var3 + 1, var4 + k2, var5)) {
                                this.setBlockAndNotifyAdequately(var1, var3 + 1, var4 + k2, var5, Blocks.vine, 2);
                            }

                            if (var2.nextInt(3) > 0 && var1.isAirBlock(var3, var4 + k2, var5 - 1)) {
                                this.setBlockAndNotifyAdequately(var1, var3, var4 + k2, var5 - 1, Blocks.vine, 1);
                            }

                            if (var2.nextInt(3) > 0 && var1.isAirBlock(var3, var4 + k2, var5 + 1)) {
                                this.setBlockAndNotifyAdequately(var1, var3, var4 + k2, var5 + 1, Blocks.vine, 4);
                            }
                        }
                    }
                }

                if (this.vinesGrow) {
                    for (int l2 = var4 - 3 + i; l2 <= var4 + i; l2++) {
                        int k3 = l2 - (var4 + i);
                        int i4 = 2 - k3 / 2;

                        for (int k4 = var3 - i4; k4 <= var3 + i4; k4++) {
                            for (int l4 = var5 - i4; l4 <= var5 + i4; l4++) {
                                if (var1.getBlock(k4, l2, l4).getMaterial() == Material.leaves) {
                                    if (var2.nextInt(4) == 0 && var1.getBlock(k4 - 1, l2, l4).getMaterial() == Material.air) {
                                        this.growVines(var1, k4 - 1, l2, l4, 8);
                                    }

                                    if (var2.nextInt(4) == 0 && var1.getBlock(k4 + 1, l2, l4).getMaterial() == Material.air) {
                                        this.growVines(var1, k4 + 1, l2, l4, 2);
                                    }

                                    if (var2.nextInt(4) == 0 && var1.getBlock(k4, l2, l4 - 1).getMaterial() == Material.air) {
                                        this.growVines(var1, k4, l2, l4 - 1, 1);
                                    }

                                    if (var2.nextInt(4) == 0 && var1.getBlock(k4, l2, l4 + 1).getMaterial() == Material.air) {
                                        this.growVines(var1, k4, l2, l4 + 1, 4);
                                    }
                                }
                            }
                        }
                    }

                    if (var2.nextInt(5) == 0 && i > 5) {
                        for (int i3 = 0; i3 < 2; i3++) {
                            for (int l3 = 0; l3 < 4; l3++) {
                                if (var2.nextInt(4 - i3) == 0) {
                                    int j4 = var2.nextInt(3);
                                    this.setBlockAndNotifyAdequately(
                                        var1,
                                        var3 + Direction.offsetX[Direction.rotateOpposite[l3]],
                                        var4 + i - 5 + i3,
                                        var5 + Direction.offsetZ[Direction.rotateOpposite[l3]],
                                        Blocks.cocoa,
                                        j4 << 2 | l3
                                    );
                                }
                            }
                        }
                    }
                }

                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private void growVines(World var1, int var2, int var3, int var4, int var5) {
        this.setBlockAndNotifyAdequately(var1, var2, var3, var4, Blocks.vine, var5);

        for (int i = 4; var1.getBlock(var2, --var3, var4).getMaterial() == Material.air && i > 0; i--) {
            this.setBlockAndNotifyAdequately(var1, var2, var3, var4, Blocks.vine, var5);
        }
    }
}
