package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenCactus extends WorldGenerator {
    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        for (int i = 0; i < 10; i++) {
            int j = var3 + var2.nextInt(8) - var2.nextInt(8);
            int k = var4 + var2.nextInt(4) - var2.nextInt(4);
            int l = var5 + var2.nextInt(8) - var2.nextInt(8);
            if (var1.isAirBlock(j, k, l)) {
                int i1 = 1 + var2.nextInt(var2.nextInt(3) + 1);

                for (int j1 = 0; j1 < i1; j1++) {
                    if (Blocks.cactus.canBlockStay(var1, j, k + j1, l)) {
                        var1.setBlock(j, k + j1, l, Blocks.cactus, 0, 2);
                    }
                }
            }
        }

        return true;
    }
}
