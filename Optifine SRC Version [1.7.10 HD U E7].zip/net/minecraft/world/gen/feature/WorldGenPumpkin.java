package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenPumpkin extends WorldGenerator {
    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        for (int i = 0; i < 64; i++) {
            int j = var3 + var2.nextInt(8) - var2.nextInt(8);
            int k = var4 + var2.nextInt(4) - var2.nextInt(4);
            int l = var5 + var2.nextInt(8) - var2.nextInt(8);
            if (var1.isAirBlock(j, k, l) && var1.getBlock(j, k - 1, l) == Blocks.grass && Blocks.pumpkin.canPlaceBlockAt(var1, j, k, l)) {
                var1.setBlock(j, k, l, Blocks.pumpkin, var2.nextInt(4), 2);
            }
        }

        return true;
    }
}
