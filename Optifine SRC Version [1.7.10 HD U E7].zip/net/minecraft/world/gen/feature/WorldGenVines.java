package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.util.Direction;
import net.minecraft.util.Facing;
import net.minecraft.world.World;

public class WorldGenVines extends WorldGenerator {
    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        int i = var3;
        int j = var5;

        while (var4 < 128) {
            if (var1.isAirBlock(var3, var4, var5)) {
                for (int k = 2; k <= 5; k++) {
                    if (Blocks.vine.canPlaceBlockOnSide(var1, var3, var4, var5, k)) {
                        var1.setBlock(var3, var4, var5, Blocks.vine, 1 << Direction.facingToDirection[Facing.oppositeSide[k]], 2);
                        break;
                    }
                }
            } else {
                var3 = i + var2.nextInt(4) - var2.nextInt(4);
                var5 = j + var2.nextInt(4) - var2.nextInt(4);
            }

            var4++;
        }

        return true;
    }
}
