package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenIcePath extends WorldGenerator {
    private Block field_150555_a = Blocks.packed_ice;
    private int field_150554_b;

    public WorldGenIcePath(int var1) {
        this.field_150554_b = var1;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        while (var1.isAirBlock(var3, var4, var5) && var4 > 2) {
            var4--;
        }

        if (var1.getBlock(var3, var4, var5) != Blocks.snow) {
            return false;
        }

        int i = var2.nextInt(this.field_150554_b - 2) + 2;
        byte b0 = 1;

        for (int j = var3 - i; j <= var3 + i; j++) {
            for (int k = var5 - i; k <= var5 + i; k++) {
                int l = j - var3;
                int i1 = k - var5;
                if (l * l + i1 * i1 <= i * i) {
                    for (int j1 = var4 - b0; j1 <= var4 + b0; j1++) {
                        Block block = var1.getBlock(j, j1, k);
                        if (block == Blocks.dirt || block == Blocks.snow || block == Blocks.ice) {
                            var1.setBlock(j, j1, k, this.field_150555_a, 0, 2);
                        }
                    }
                }
            }
        }

        return true;
    }
}
