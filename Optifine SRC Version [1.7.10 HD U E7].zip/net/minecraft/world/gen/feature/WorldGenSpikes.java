package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenSpikes extends WorldGenerator {
    private Block field_150520_a;

    public WorldGenSpikes(Block var1) {
        this.field_150520_a = var1;
    }

    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        if (var1.isAirBlock(var3, var4, var5) && var1.getBlock(var3, var4 - 1, var5) == this.field_150520_a) {
            int i = var2.nextInt(32) + 6;
            int j = var2.nextInt(4) + 1;

            for (int k = var3 - j; k <= var3 + j; k++) {
                for (int l = var5 - j; l <= var5 + j; l++) {
                    int i1 = k - var3;
                    int j1 = l - var5;
                    if (i1 * i1 + j1 * j1 <= j * j + 1 && var1.getBlock(k, var4 - 1, l) != this.field_150520_a) {
                        return false;
                    }
                }
            }

            for (int l1 = var4; l1 < var4 + i && l1 < 256; l1++) {
                for (int i2 = var3 - j; i2 <= var3 + j; i2++) {
                    for (int j2 = var5 - j; j2 <= var5 + j; j2++) {
                        int k2 = i2 - var3;
                        int k1 = j2 - var5;
                        if (k2 * k2 + k1 * k1 <= j * j + 1) {
                            var1.setBlock(i2, l1, j2, Blocks.obsidian, 0, 2);
                        }
                    }
                }
            }

            EntityEnderCrystal entityendercrystal = new EntityEnderCrystal(var1);
            entityendercrystal.setLocationAndAngles(var3 + 0.5F, var4 + i, var5 + 0.5F, var2.nextFloat() * 360.0F, 0.0F);
            var1.spawnEntityInWorld(entityendercrystal);
            var1.setBlock(var3, var4 + i, var5, Blocks.bedrock, 0, 2);
            return true;
        } else {
            return false;
        }
    }
}
