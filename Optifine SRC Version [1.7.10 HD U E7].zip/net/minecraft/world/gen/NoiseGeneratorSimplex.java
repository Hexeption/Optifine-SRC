package net.minecraft.world.gen;

import java.util.Random;

public class NoiseGeneratorSimplex {
    private static int[][] field_151611_e = new int[][]{
        {1, 1, 0}, {-1, 1, 0}, {1, -1, 0}, {-1, -1, 0}, {1, 0, 1}, {-1, 0, 1}, {1, 0, -1}, {-1, 0, -1}, {0, 1, 1}, {0, -1, 1}, {0, 1, -1}, {0, -1, -1}
    };
    public static final double field_151614_a = Math.sqrt(3.0);
    private int[] field_151608_f = new int[512];
    public double field_151612_b;
    public double field_151613_c;
    public double field_151610_d;
    private static final double field_151609_g = 0.5 * (field_151614_a - 1.0);
    private static final double field_151615_h = (3.0 - field_151614_a) / 6.0;

    public NoiseGeneratorSimplex() {
        this(new Random());
    }

    public NoiseGeneratorSimplex(Random var1) {
        this.field_151612_b = var1.nextDouble() * 256.0;
        this.field_151613_c = var1.nextDouble() * 256.0;
        this.field_151610_d = var1.nextDouble() * 256.0;
        int i = 0;

        while (i < 256) {
            this.field_151608_f[i] = i++;
        }

        for (int l = 0; l < 256; l++) {
            int j = var1.nextInt(256 - l) + l;
            int k = this.field_151608_f[l];
            this.field_151608_f[l] = this.field_151608_f[j];
            this.field_151608_f[j] = k;
            this.field_151608_f[l + 256] = this.field_151608_f[l];
        }
    }

    private static int func_151607_a(double var0) {
        return var0 > 0.0 ? (int)var0 : (int)var0 - 1;
    }

    private static double func_151604_a(int[] var0, double var1, double var3) {
        return var0[0] * var1 + var0[1] * var3;
    }

    public double func_151605_a(double var1, double var3) {
        double d3 = 0.5 * (field_151614_a - 1.0);
        double d4 = (var1 + var3) * d3;
        int i = func_151607_a(var1 + d4);
        int j = func_151607_a(var3 + d4);
        double d5 = (3.0 - field_151614_a) / 6.0;
        double d6 = (i + j) * d5;
        double d7 = i - d6;
        double d8 = j - d6;
        double d9 = var1 - d7;
        double d10 = var3 - d8;
        byte b0;
        byte b1;
        if (d9 > d10) {
            b0 = 1;
            b1 = 0;
        } else {
            b0 = 0;
            b1 = 1;
        }

        double d11 = d9 - b0 + d5;
        double d12 = d10 - b1 + d5;
        double d13 = d9 - 1.0 + 2.0 * d5;
        double d14 = d10 - 1.0 + 2.0 * d5;
        int k = i & 0xFF;
        int l = j & 0xFF;
        int i1 = this.field_151608_f[k + this.field_151608_f[l]] % 12;
        int j1 = this.field_151608_f[k + b0 + this.field_151608_f[l + b1]] % 12;
        int k1 = this.field_151608_f[k + 1 + this.field_151608_f[l + 1]] % 12;
        double d15 = 0.5 - d9 * d9 - d10 * d10;
        double d0;
        if (d15 < 0.0) {
            d0 = 0.0;
        } else {
            d15 *= d15;
            d0 = d15 * d15 * func_151604_a(field_151611_e[i1], d9, d10);
        }

        double d16 = 0.5 - d11 * d11 - d12 * d12;
        double d1;
        if (d16 < 0.0) {
            d1 = 0.0;
        } else {
            d16 *= d16;
            d1 = d16 * d16 * func_151604_a(field_151611_e[j1], d11, d12);
        }

        double d17 = 0.5 - d13 * d13 - d14 * d14;
        double d2;
        if (d17 < 0.0) {
            d2 = 0.0;
        } else {
            d17 *= d17;
            d2 = d17 * d17 * func_151604_a(field_151611_e[k1], d13, d14);
        }

        return 70.0 * (d0 + d1 + d2);
    }

    public void func_151606_a(double[] var1, double var2, double var4, int var6, int var7, double var8, double var10, double var12) {
        int i = 0;

        for (int j = 0; j < var7; j++) {
            double d0 = (var4 + j) * var10 + this.field_151613_c;

            for (int k = 0; k < var6; k++) {
                double d1 = (var2 + k) * var8 + this.field_151612_b;
                double d5 = (d1 + d0) * field_151609_g;
                int l = func_151607_a(d1 + d5);
                int i1 = func_151607_a(d0 + d5);
                double d6 = (l + i1) * field_151615_h;
                double d7 = l - d6;
                double d8 = i1 - d6;
                double d9 = d1 - d7;
                double d10 = d0 - d8;
                byte b0;
                byte b1;
                if (d9 > d10) {
                    b0 = 1;
                    b1 = 0;
                } else {
                    b0 = 0;
                    b1 = 1;
                }

                double d11 = d9 - b0 + field_151615_h;
                double d12 = d10 - b1 + field_151615_h;
                double d13 = d9 - 1.0 + 2.0 * field_151615_h;
                double d14 = d10 - 1.0 + 2.0 * field_151615_h;
                int j1 = l & 0xFF;
                int k1 = i1 & 0xFF;
                int l1 = this.field_151608_f[j1 + this.field_151608_f[k1]] % 12;
                int i2 = this.field_151608_f[j1 + b0 + this.field_151608_f[k1 + b1]] % 12;
                int j2 = this.field_151608_f[j1 + 1 + this.field_151608_f[k1 + 1]] % 12;
                double d15 = 0.5 - d9 * d9 - d10 * d10;
                double d2;
                if (d15 < 0.0) {
                    d2 = 0.0;
                } else {
                    d15 *= d15;
                    d2 = d15 * d15 * func_151604_a(field_151611_e[l1], d9, d10);
                }

                double d16 = 0.5 - d11 * d11 - d12 * d12;
                double d3;
                if (d16 < 0.0) {
                    d3 = 0.0;
                } else {
                    d16 *= d16;
                    d3 = d16 * d16 * func_151604_a(field_151611_e[i2], d11, d12);
                }

                double d17 = 0.5 - d13 * d13 - d14 * d14;
                double d4;
                if (d17 < 0.0) {
                    d4 = 0.0;
                } else {
                    d17 *= d17;
                    d4 = d17 * d17 * func_151604_a(field_151611_e[j2], d13, d14);
                }

                var1[i++] += 70.0 * (d2 + d3 + d4) * var12;
            }
        }
    }
}
