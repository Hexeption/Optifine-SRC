package net.minecraft.world.gen.layer;

import java.util.concurrent.Callable;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.ReportedException;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;

public abstract class GenLayer {
    private long worldGenSeed;
    protected GenLayer parent;
    private long chunkSeed;
    protected long baseSeed;

    public static GenLayer[] initializeAllBiomeGenerators(long var0, WorldType var2) {
        boolean flag = false;
        GenLayer genlayer = new GenLayerIsland(1L);
        genlayer = new GenLayerFuzzyZoom(2000L, genlayer);
        genlayer = new GenLayerAddIsland(1L, genlayer);
        genlayer = new GenLayerZoom(2001L, genlayer);
        genlayer = new GenLayerAddIsland(2L, genlayer);
        genlayer = new GenLayerAddIsland(50L, genlayer);
        genlayer = new GenLayerAddIsland(70L, genlayer);
        genlayer = new GenLayerRemoveTooMuchOcean(2L, genlayer);
        genlayer = new GenLayerAddSnow(2L, genlayer);
        genlayer = new GenLayerAddIsland(3L, genlayer);
        genlayer = new GenLayerEdge(2L, genlayer, GenLayerEdge.Mode.COOL_WARM);
        genlayer = new GenLayerEdge(2L, genlayer, GenLayerEdge.Mode.HEAT_ICE);
        genlayer = new GenLayerEdge(3L, genlayer, GenLayerEdge.Mode.SPECIAL);
        genlayer = new GenLayerZoom(2002L, genlayer);
        genlayer = new GenLayerZoom(2003L, genlayer);
        genlayer = new GenLayerAddIsland(4L, genlayer);
        genlayer = new GenLayerAddMushroomIsland(5L, genlayer);
        genlayer = new GenLayerDeepOcean(4L, genlayer);
        genlayer = GenLayerZoom.magnify(1000L, genlayer, 0);
        byte b0 = 4;
        if (var2 == WorldType.LARGE_BIOMES) {
            b0 = 6;
        }

        if (flag) {
            b0 = 4;
        }

        GenLayer genlayer1 = genlayer;
        genlayer1 = GenLayerZoom.magnify(1000L, genlayer1, 0);
        genlayer1 = new GenLayerRiverInit(100L, genlayer1);
        GenLayer genlayerrivermix = genlayer;
        genlayerrivermix = new GenLayerBiome(200L, genlayerrivermix, var2);
        if (!flag) {
            genlayerrivermix = GenLayerZoom.magnify(1000L, genlayerrivermix, 2);
            genlayerrivermix = new GenLayerBiomeEdge(1000L, genlayerrivermix);
        }

        GenLayer genlayer2 = genlayer1;
        genlayer2 = GenLayerZoom.magnify(1000L, genlayer2, 2);
        genlayerrivermix = new GenLayerHills(1000L, genlayerrivermix, genlayer2);
        genlayer1 = GenLayerZoom.magnify(1000L, genlayer1, 2);
        genlayer1 = GenLayerZoom.magnify(1000L, genlayer1, b0);
        genlayer1 = new GenLayerRiver(1L, genlayer1);
        genlayer1 = new GenLayerSmooth(1000L, genlayer1);
        genlayerrivermix = new GenLayerRareBiome(1001L, genlayerrivermix);

        for (int i = 0; i < b0; i++) {
            genlayerrivermix = new GenLayerZoom(1000 + i, genlayerrivermix);
            if (i == 0) {
                genlayerrivermix = new GenLayerAddIsland(3L, genlayerrivermix);
            }

            if (i == 1) {
                genlayerrivermix = new GenLayerShore(1000L, genlayerrivermix);
            }
        }

        genlayerrivermix = new GenLayerSmooth(1000L, genlayerrivermix);
        genlayerrivermix = new GenLayerRiverMix(100L, genlayerrivermix, genlayer1);
        GenLayerRiverMix genlayerrivermix1 = ((GenLayerRiverMix) genlayerrivermix);
        GenLayerVoronoiZoom genlayervoronoizoom = new GenLayerVoronoiZoom(10L, genlayerrivermix);
        genlayerrivermix.initWorldGenSeed(var0);
        genlayervoronoizoom.initWorldGenSeed(var0);
        return new GenLayer[]{genlayerrivermix, genlayervoronoizoom, genlayerrivermix1};
    }

    public GenLayer(long var1) {
        this.baseSeed = var1;
        this.baseSeed = this.baseSeed * (this.baseSeed * 6364136223846793005L + 1442695040888963407L);
        this.baseSeed += var1;
        this.baseSeed = this.baseSeed * (this.baseSeed * 6364136223846793005L + 1442695040888963407L);
        this.baseSeed += var1;
        this.baseSeed = this.baseSeed * (this.baseSeed * 6364136223846793005L + 1442695040888963407L);
        this.baseSeed += var1;
    }

    public void initWorldGenSeed(long var1) {
        this.worldGenSeed = var1;
        if (this.parent != null) {
            this.parent.initWorldGenSeed(var1);
        }

        this.worldGenSeed = this.worldGenSeed * (this.worldGenSeed * 6364136223846793005L + 1442695040888963407L);
        this.worldGenSeed = this.worldGenSeed + this.baseSeed;
        this.worldGenSeed = this.worldGenSeed * (this.worldGenSeed * 6364136223846793005L + 1442695040888963407L);
        this.worldGenSeed = this.worldGenSeed + this.baseSeed;
        this.worldGenSeed = this.worldGenSeed * (this.worldGenSeed * 6364136223846793005L + 1442695040888963407L);
        this.worldGenSeed = this.worldGenSeed + this.baseSeed;
    }

    public void initChunkSeed(long var1, long var3) {
        this.chunkSeed = this.worldGenSeed;
        this.chunkSeed = this.chunkSeed * (this.chunkSeed * 6364136223846793005L + 1442695040888963407L);
        this.chunkSeed += var1;
        this.chunkSeed = this.chunkSeed * (this.chunkSeed * 6364136223846793005L + 1442695040888963407L);
        this.chunkSeed += var3;
        this.chunkSeed = this.chunkSeed * (this.chunkSeed * 6364136223846793005L + 1442695040888963407L);
        this.chunkSeed += var1;
        this.chunkSeed = this.chunkSeed * (this.chunkSeed * 6364136223846793005L + 1442695040888963407L);
        this.chunkSeed += var3;
    }

    protected int nextInt(int var1) {
        int i = (int)((this.chunkSeed >> 24) % var1);
        if (i < 0) {
            i += var1;
        }

        this.chunkSeed = this.chunkSeed * (this.chunkSeed * 6364136223846793005L + 1442695040888963407L);
        this.chunkSeed = this.chunkSeed + this.worldGenSeed;
        return i;
    }

    public abstract int[] getInts(int var1, int var2, int var3, int var4);

    protected static boolean biomesEqualOrMesaPlateau(final int var0, final int var1) {
        if (var0 == var1) {
            return true;
        }

        if (var0 != BiomeGenBase.mesaPlateau_F.biomeID && var0 != BiomeGenBase.mesaPlateau.biomeID) {
            try {
                return BiomeGenBase.getBiome(var0) != null && BiomeGenBase.getBiome(var1) != null
                    ? BiomeGenBase.getBiome(var0).isEqualTo(BiomeGenBase.getBiome(var1))
                    : false;
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Comparing biomes");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Biomes being compared");
                crashreportcategory.addCrashSection("Biome A ID", var0);
                crashreportcategory.addCrashSection("Biome B ID", var1);
                crashreportcategory.addCrashSectionCallable("Biome A", new Callable() {
                    public String call() {
                        return String.valueOf(BiomeGenBase.getBiome(var0));
                    }
                });
                crashreportcategory.addCrashSectionCallable("Biome B", new Callable() {
                    public String call() {
                        return String.valueOf(BiomeGenBase.getBiome(var1));
                    }
                });
                throw new ReportedException(crashreport);
            }
        } else {
            return var1 == BiomeGenBase.mesaPlateau_F.biomeID || var1 == BiomeGenBase.mesaPlateau.biomeID;
        }
    }

    protected static boolean isBiomeOceanic(int var0) {
        return var0 == BiomeGenBase.ocean.biomeID || var0 == BiomeGenBase.deepOcean.biomeID || var0 == BiomeGenBase.frozenOcean.biomeID;
    }

    protected int selectRandom(int... var1) {
        return var1[this.nextInt(var1.length)];
    }

    protected int selectModeOrRandom(int var1, int var2, int var3, int var4) {
        if (var2 == var3 && var3 == var4) {
            return var2;
        } else if (var1 == var2 && var1 == var3) {
            return var1;
        } else if (var1 == var2 && var1 == var4) {
            return var1;
        } else if (var1 == var3 && var1 == var4) {
            return var1;
        } else if (var1 == var2 && var3 != var4) {
            return var1;
        } else if (var1 == var3 && var2 != var4) {
            return var1;
        } else if (var1 == var4 && var2 != var3) {
            return var1;
        } else if (var2 == var3 && var1 != var4) {
            return var2;
        } else if (var2 == var4 && var1 != var3) {
            return var2;
        } else {
            return var3 == var4 && var1 != var2 ? var3 : this.selectRandom(var1, var2, var3, var4);
        }
    }
}
