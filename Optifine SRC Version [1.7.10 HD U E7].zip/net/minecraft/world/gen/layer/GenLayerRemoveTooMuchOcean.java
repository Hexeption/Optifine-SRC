package net.minecraft.world.gen.layer;

public class GenLayerRemoveTooMuchOcean extends GenLayer {
    public GenLayerRemoveTooMuchOcean(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = var3 + 2;
        int l = var4 + 2;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                int k1 = aint[j1 + 1 + (i1 + 1 - 1) * (var3 + 2)];
                int l1 = aint[j1 + 1 + 1 + (i1 + 1) * (var3 + 2)];
                int i2 = aint[j1 + 1 - 1 + (i1 + 1) * (var3 + 2)];
                int j2 = aint[j1 + 1 + (i1 + 1 + 1) * (var3 + 2)];
                int k2 = aint[j1 + 1 + (i1 + 1) * k];
                aint1[j1 + i1 * var3] = k2;
                this.initChunkSeed(j1 + var1, i1 + var2);
                if (k2 == 0 && k1 == 0 && l1 == 0 && i2 == 0 && j2 == 0 && this.nextInt(2) == 0) {
                    aint1[j1 + i1 * var3] = 1;
                }
            }
        }

        return aint1;
    }
}
