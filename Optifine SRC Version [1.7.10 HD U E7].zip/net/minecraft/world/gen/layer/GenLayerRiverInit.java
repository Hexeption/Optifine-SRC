package net.minecraft.world.gen.layer;

public class GenLayerRiverInit extends GenLayer {
    public GenLayerRiverInit(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int[] aint = this.parent.getInts(var1, var2, var3, var4);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var4; i++) {
            for (int j = 0; j < var3; j++) {
                this.initChunkSeed(j + var1, i + var2);
                aint1[j + i * var3] = aint[j + i * var3] > 0 ? this.nextInt(299999) + 2 : 0;
            }
        }

        return aint1;
    }
}
