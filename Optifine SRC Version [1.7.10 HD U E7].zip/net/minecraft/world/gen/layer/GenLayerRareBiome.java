package net.minecraft.world.gen.layer;

import net.minecraft.world.biome.BiomeGenBase;

public class GenLayerRareBiome extends GenLayer {
    public GenLayerRareBiome(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int[] aint = this.parent.getInts(var1 - 1, var2 - 1, var3 + 2, var4 + 2);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var4; i++) {
            for (int j = 0; j < var3; j++) {
                this.initChunkSeed(j + var1, i + var2);
                int k = aint[j + 1 + (i + 1) * (var3 + 2)];
                if (this.nextInt(57) == 0) {
                    if (k == BiomeGenBase.plains.biomeID) {
                        aint1[j + i * var3] = BiomeGenBase.plains.biomeID + 128;
                    } else {
                        aint1[j + i * var3] = k;
                    }
                } else {
                    aint1[j + i * var3] = k;
                }
            }
        }

        return aint1;
    }
}
