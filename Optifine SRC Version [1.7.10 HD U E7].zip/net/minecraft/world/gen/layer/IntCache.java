package net.minecraft.world.gen.layer;

import java.util.ArrayList;
import java.util.List;

public class IntCache {
    private static int intCacheSize = 256;
    private static List freeSmallArrays = new ArrayList();
    private static List inUseSmallArrays = new ArrayList();
    private static List freeLargeArrays = new ArrayList();
    private static List inUseLargeArrays = new ArrayList();

    public static synchronized int[] getIntCache(int var0) {
        if (var0 <= 256) {
            if (freeSmallArrays.isEmpty()) {
                int[] aint4 = new int[256];
                inUseSmallArrays.add(aint4);
                return aint4;
            } else {
                int[] aint3 = (int[])freeSmallArrays.remove(freeSmallArrays.size() - 1);
                inUseSmallArrays.add(aint3);
                return aint3;
            }
        } else if (var0 > intCacheSize) {
            intCacheSize = var0;
            freeLargeArrays.clear();
            inUseLargeArrays.clear();
            int[] aint2 = new int[intCacheSize];
            inUseLargeArrays.add(aint2);
            return aint2;
        } else if (freeLargeArrays.isEmpty()) {
            int[] aint1 = new int[intCacheSize];
            inUseLargeArrays.add(aint1);
            return aint1;
        } else {
            int[] aint = (int[])freeLargeArrays.remove(freeLargeArrays.size() - 1);
            inUseLargeArrays.add(aint);
            return aint;
        }
    }

    public static synchronized void resetIntCache() {
        if (!freeLargeArrays.isEmpty()) {
            freeLargeArrays.remove(freeLargeArrays.size() - 1);
        }

        if (!freeSmallArrays.isEmpty()) {
            freeSmallArrays.remove(freeSmallArrays.size() - 1);
        }

        freeLargeArrays.addAll(inUseLargeArrays);
        freeSmallArrays.addAll(inUseSmallArrays);
        inUseLargeArrays.clear();
        inUseSmallArrays.clear();
    }

    public static synchronized String getCacheSizes() {
        return "cache: "
            + freeLargeArrays.size()
            + ", tcache: "
            + freeSmallArrays.size()
            + ", allocated: "
            + inUseLargeArrays.size()
            + ", tallocated: "
            + inUseSmallArrays.size();
    }
}
