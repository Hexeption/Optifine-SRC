package net.minecraft.world.gen.layer;

public class GenLayerSmooth extends GenLayer {
    public GenLayerSmooth(long var1, GenLayer var3) {
        super(var1);
        super.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = var3 + 2;
        int l = var4 + 2;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                int k1 = aint[j1 + 0 + (i1 + 1) * k];
                int l1 = aint[j1 + 2 + (i1 + 1) * k];
                int i2 = aint[j1 + 1 + (i1 + 0) * k];
                int j2 = aint[j1 + 1 + (i1 + 2) * k];
                int k2 = aint[j1 + 1 + (i1 + 1) * k];
                if (k1 == l1 && i2 == j2) {
                    this.initChunkSeed(j1 + var1, i1 + var2);
                    if (this.nextInt(2) == 0) {
                        k2 = k1;
                    } else {
                        k2 = i2;
                    }
                } else {
                    if (k1 == l1) {
                        k2 = k1;
                    }

                    if (i2 == j2) {
                        k2 = i2;
                    }
                }

                aint1[j1 + i1 * var3] = k2;
            }
        }

        return aint1;
    }
}
