package net.minecraft.world.gen.layer;

import net.minecraft.world.biome.BiomeGenBase;

public class GenLayerDeepOcean extends GenLayer {
    public GenLayerDeepOcean(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = var3 + 2;
        int l = var4 + 2;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                int k1 = aint[j1 + 1 + (i1 + 1 - 1) * (var3 + 2)];
                int l1 = aint[j1 + 1 + 1 + (i1 + 1) * (var3 + 2)];
                int i2 = aint[j1 + 1 - 1 + (i1 + 1) * (var3 + 2)];
                int j2 = aint[j1 + 1 + (i1 + 1 + 1) * (var3 + 2)];
                int k2 = aint[j1 + 1 + (i1 + 1) * k];
                int l2 = 0;
                if (k1 == 0) {
                    l2++;
                }

                if (l1 == 0) {
                    l2++;
                }

                if (i2 == 0) {
                    l2++;
                }

                if (j2 == 0) {
                    l2++;
                }

                if (k2 == 0 && l2 > 3) {
                    aint1[j1 + i1 * var3] = BiomeGenBase.deepOcean.biomeID;
                } else {
                    aint1[j1 + i1 * var3] = k2;
                }
            }
        }

        return aint1;
    }
}
