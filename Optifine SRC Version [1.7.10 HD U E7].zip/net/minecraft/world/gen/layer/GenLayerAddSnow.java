package net.minecraft.world.gen.layer;

public class GenLayerAddSnow extends GenLayer {
    public GenLayerAddSnow(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = var3 + 2;
        int l = var4 + 2;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                int k1 = aint[j1 + 1 + (i1 + 1) * k];
                this.initChunkSeed(j1 + var1, i1 + var2);
                if (k1 == 0) {
                    aint1[j1 + i1 * var3] = 0;
                } else {
                    int l1 = this.nextInt(6);
                    byte b0;
                    if (l1 == 0) {
                        b0 = 4;
                    } else if (l1 <= 1) {
                        b0 = 3;
                    } else {
                        b0 = 1;
                    }

                    aint1[j1 + i1 * var3] = b0;
                }
            }
        }

        return aint1;
    }
}
