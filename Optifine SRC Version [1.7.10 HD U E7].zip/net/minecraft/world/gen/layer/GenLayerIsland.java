package net.minecraft.world.gen.layer;

public class GenLayerIsland extends GenLayer {
    public GenLayerIsland(long var1) {
        super(var1);
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int[] aint = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var4; i++) {
            for (int j = 0; j < var3; j++) {
                this.initChunkSeed(var1 + j, var2 + i);
                aint[j + i * var3] = this.nextInt(10) == 0 ? 1 : 0;
            }
        }

        if (var1 > -var3 && var1 <= 0 && var2 > -var4 && var2 <= 0) {
            aint[-var1 + -var2 * var3] = 1;
        }

        return aint;
    }
}
