package net.minecraft.world.gen.layer;

import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.BiomeGenJungle;
import net.minecraft.world.biome.BiomeGenMesa;

public class GenLayerShore extends GenLayer {
    public GenLayerShore(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int[] aint = this.parent.getInts(var1 - 1, var2 - 1, var3 + 2, var4 + 2);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var4; i++) {
            for (int j = 0; j < var3; j++) {
                this.initChunkSeed(j + var1, i + var2);
                int k = aint[j + 1 + (i + 1) * (var3 + 2)];
                BiomeGenBase biomegenbase = BiomeGenBase.getBiome(k);
                if (k == BiomeGenBase.mushroomIsland.biomeID) {
                    int l = aint[j + 1 + (i + 1 - 1) * (var3 + 2)];
                    int i1 = aint[j + 1 + 1 + (i + 1) * (var3 + 2)];
                    int j1 = aint[j + 1 - 1 + (i + 1) * (var3 + 2)];
                    int k1 = aint[j + 1 + (i + 1 + 1) * (var3 + 2)];
                    if (l != BiomeGenBase.ocean.biomeID
                        && i1 != BiomeGenBase.ocean.biomeID
                        && j1 != BiomeGenBase.ocean.biomeID
                        && k1 != BiomeGenBase.ocean.biomeID) {
                        aint1[j + i * var3] = k;
                    } else {
                        aint1[j + i * var3] = BiomeGenBase.mushroomIslandShore.biomeID;
                    }
                } else if (biomegenbase != null && biomegenbase.getBiomeClass() == BiomeGenJungle.class) {
                    int j2 = aint[j + 1 + (i + 1 - 1) * (var3 + 2)];
                    int i3 = aint[j + 1 + 1 + (i + 1) * (var3 + 2)];
                    int l3 = aint[j + 1 - 1 + (i + 1) * (var3 + 2)];
                    int k4 = aint[j + 1 + (i + 1 + 1) * (var3 + 2)];
                    if (!this.func_151631_c(j2) || !this.func_151631_c(i3) || !this.func_151631_c(l3) || !this.func_151631_c(k4)) {
                        aint1[j + i * var3] = BiomeGenBase.jungleEdge.biomeID;
                    } else if (!isBiomeOceanic(j2) && !isBiomeOceanic(i3) && !isBiomeOceanic(l3) && !isBiomeOceanic(k4)) {
                        aint1[j + i * var3] = k;
                    } else {
                        aint1[j + i * var3] = BiomeGenBase.beach.biomeID;
                    }
                } else if (k == BiomeGenBase.extremeHills.biomeID || k == BiomeGenBase.extremeHillsPlus.biomeID || k == BiomeGenBase.extremeHillsEdge.biomeID) {
                    this.func_151632_a(aint, aint1, j, i, var3, k, BiomeGenBase.stoneBeach.biomeID);
                } else if (biomegenbase != null && biomegenbase.func_150559_j()) {
                    this.func_151632_a(aint, aint1, j, i, var3, k, BiomeGenBase.coldBeach.biomeID);
                } else if (k == BiomeGenBase.mesa.biomeID || k == BiomeGenBase.mesaPlateau_F.biomeID) {
                    int i2 = aint[j + 1 + (i + 1 - 1) * (var3 + 2)];
                    int l2 = aint[j + 1 + 1 + (i + 1) * (var3 + 2)];
                    int k3 = aint[j + 1 - 1 + (i + 1) * (var3 + 2)];
                    int j4 = aint[j + 1 + (i + 1 + 1) * (var3 + 2)];
                    if (isBiomeOceanic(i2) || isBiomeOceanic(l2) || isBiomeOceanic(k3) || isBiomeOceanic(j4)) {
                        aint1[j + i * var3] = k;
                    } else if (this.func_151633_d(i2) && this.func_151633_d(l2) && this.func_151633_d(k3) && this.func_151633_d(j4)) {
                        aint1[j + i * var3] = k;
                    } else {
                        aint1[j + i * var3] = BiomeGenBase.desert.biomeID;
                    }
                } else if (k != BiomeGenBase.ocean.biomeID
                    && k != BiomeGenBase.deepOcean.biomeID
                    && k != BiomeGenBase.river.biomeID
                    && k != BiomeGenBase.swampland.biomeID) {
                    int l1 = aint[j + 1 + (i + 1 - 1) * (var3 + 2)];
                    int k2 = aint[j + 1 + 1 + (i + 1) * (var3 + 2)];
                    int j3 = aint[j + 1 - 1 + (i + 1) * (var3 + 2)];
                    int i4 = aint[j + 1 + (i + 1 + 1) * (var3 + 2)];
                    if (!isBiomeOceanic(l1) && !isBiomeOceanic(k2) && !isBiomeOceanic(j3) && !isBiomeOceanic(i4)) {
                        aint1[j + i * var3] = k;
                    } else {
                        aint1[j + i * var3] = BiomeGenBase.beach.biomeID;
                    }
                } else {
                    aint1[j + i * var3] = k;
                }
            }
        }

        return aint1;
    }

    private void func_151632_a(int[] var1, int[] var2, int var3, int var4, int var5, int var6, int var7) {
        if (isBiomeOceanic(var6)) {
            var2[var3 + var4 * var5] = var6;
        } else {
            int i = var1[var3 + 1 + (var4 + 1 - 1) * (var5 + 2)];
            int j = var1[var3 + 1 + 1 + (var4 + 1) * (var5 + 2)];
            int k = var1[var3 + 1 - 1 + (var4 + 1) * (var5 + 2)];
            int l = var1[var3 + 1 + (var4 + 1 + 1) * (var5 + 2)];
            if (!isBiomeOceanic(i) && !isBiomeOceanic(j) && !isBiomeOceanic(k) && !isBiomeOceanic(l)) {
                var2[var3 + var4 * var5] = var6;
            } else {
                var2[var3 + var4 * var5] = var7;
            }
        }
    }

    private boolean func_151631_c(int var1) {
        return BiomeGenBase.getBiome(var1) != null && BiomeGenBase.getBiome(var1).getBiomeClass() == BiomeGenJungle.class
            ? true
            : var1 == BiomeGenBase.jungleEdge.biomeID
                || var1 == BiomeGenBase.jungle.biomeID
                || var1 == BiomeGenBase.jungleHills.biomeID
                || var1 == BiomeGenBase.forest.biomeID
                || var1 == BiomeGenBase.taiga.biomeID
                || isBiomeOceanic(var1);
    }

    private boolean func_151633_d(int var1) {
        return BiomeGenBase.getBiome(var1) != null && BiomeGenBase.getBiome(var1) instanceof BiomeGenMesa;
    }
}
