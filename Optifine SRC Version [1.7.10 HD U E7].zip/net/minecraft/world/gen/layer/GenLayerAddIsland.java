package net.minecraft.world.gen.layer;

public class GenLayerAddIsland extends GenLayer {
    public GenLayerAddIsland(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = var3 + 2;
        int l = var4 + 2;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                int k1 = aint[j1 + 0 + (i1 + 0) * k];
                int l1 = aint[j1 + 2 + (i1 + 0) * k];
                int i2 = aint[j1 + 0 + (i1 + 2) * k];
                int j2 = aint[j1 + 2 + (i1 + 2) * k];
                int k2 = aint[j1 + 1 + (i1 + 1) * k];
                this.initChunkSeed(j1 + var1, i1 + var2);
                if (k2 != 0 || k1 == 0 && l1 == 0 && i2 == 0 && j2 == 0) {
                    if (k2 > 0 && (k1 == 0 || l1 == 0 || i2 == 0 || j2 == 0)) {
                        if (this.nextInt(5) == 0) {
                            if (k2 == 4) {
                                aint1[j1 + i1 * var3] = 4;
                            } else {
                                aint1[j1 + i1 * var3] = 0;
                            }
                        } else {
                            aint1[j1 + i1 * var3] = k2;
                        }
                    } else {
                        aint1[j1 + i1 * var3] = k2;
                    }
                } else {
                    int l2 = 1;
                    int i3 = 1;
                    if (k1 != 0 && this.nextInt(l2++) == 0) {
                        i3 = k1;
                    }

                    if (l1 != 0 && this.nextInt(l2++) == 0) {
                        i3 = l1;
                    }

                    if (i2 != 0 && this.nextInt(l2++) == 0) {
                        i3 = i2;
                    }

                    if (j2 != 0 && this.nextInt(l2++) == 0) {
                        i3 = j2;
                    }

                    if (this.nextInt(3) == 0) {
                        aint1[j1 + i1 * var3] = i3;
                    } else if (i3 == 4) {
                        aint1[j1 + i1 * var3] = 4;
                    } else {
                        aint1[j1 + i1 * var3] = 0;
                    }
                }
            }
        }

        return aint1;
    }
}
