package net.minecraft.world.gen.layer;

import net.minecraft.world.biome.BiomeGenBase;

public class GenLayerRiver extends GenLayer {
    public GenLayerRiver(long var1, GenLayer var3) {
        super(var1);
        super.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = var3 + 2;
        int l = var4 + 2;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                int k1 = this.func_151630_c(aint[j1 + 0 + (i1 + 1) * k]);
                int l1 = this.func_151630_c(aint[j1 + 2 + (i1 + 1) * k]);
                int i2 = this.func_151630_c(aint[j1 + 1 + (i1 + 0) * k]);
                int j2 = this.func_151630_c(aint[j1 + 1 + (i1 + 2) * k]);
                int k2 = this.func_151630_c(aint[j1 + 1 + (i1 + 1) * k]);
                if (k2 == k1 && k2 == i2 && k2 == l1 && k2 == j2) {
                    aint1[j1 + i1 * var3] = -1;
                } else {
                    aint1[j1 + i1 * var3] = BiomeGenBase.river.biomeID;
                }
            }
        }

        return aint1;
    }

    private int func_151630_c(int var1) {
        return var1 >= 2 ? 2 + (var1 & 1) : var1;
    }
}
