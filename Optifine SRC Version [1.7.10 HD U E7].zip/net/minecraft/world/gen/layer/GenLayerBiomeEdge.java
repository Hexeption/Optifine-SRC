package net.minecraft.world.gen.layer;

import net.minecraft.world.biome.BiomeGenBase;

public class GenLayerBiomeEdge extends GenLayer {
    public GenLayerBiomeEdge(long var1, GenLayer var3) {
        super(var1);
        this.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int[] aint = this.parent.getInts(var1 - 1, var2 - 1, var3 + 2, var4 + 2);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var4; i++) {
            for (int j = 0; j < var3; j++) {
                this.initChunkSeed(j + var1, i + var2);
                int k = aint[j + 1 + (i + 1) * (var3 + 2)];
                if (!this.replaceBiomeEdgeIfNecessary(aint, aint1, j, i, var3, k, BiomeGenBase.extremeHills.biomeID, BiomeGenBase.extremeHillsEdge.biomeID)
                    && !this.replaceBiomeEdge(aint, aint1, j, i, var3, k, BiomeGenBase.mesaPlateau_F.biomeID, BiomeGenBase.mesa.biomeID)
                    && !this.replaceBiomeEdge(aint, aint1, j, i, var3, k, BiomeGenBase.mesaPlateau.biomeID, BiomeGenBase.mesa.biomeID)
                    && !this.replaceBiomeEdge(aint, aint1, j, i, var3, k, BiomeGenBase.megaTaiga.biomeID, BiomeGenBase.taiga.biomeID)) {
                    if (k == BiomeGenBase.desert.biomeID) {
                        int l = aint[j + 1 + (i + 1 - 1) * (var3 + 2)];
                        int i1 = aint[j + 1 + 1 + (i + 1) * (var3 + 2)];
                        int j1 = aint[j + 1 - 1 + (i + 1) * (var3 + 2)];
                        int k1 = aint[j + 1 + (i + 1 + 1) * (var3 + 2)];
                        if (l != BiomeGenBase.icePlains.biomeID
                            && i1 != BiomeGenBase.icePlains.biomeID
                            && j1 != BiomeGenBase.icePlains.biomeID
                            && k1 != BiomeGenBase.icePlains.biomeID) {
                            aint1[j + i * var3] = k;
                        } else {
                            aint1[j + i * var3] = BiomeGenBase.extremeHillsPlus.biomeID;
                        }
                    } else if (k == BiomeGenBase.swampland.biomeID) {
                        int l1 = aint[j + 1 + (i + 1 - 1) * (var3 + 2)];
                        int i2 = aint[j + 1 + 1 + (i + 1) * (var3 + 2)];
                        int j2 = aint[j + 1 - 1 + (i + 1) * (var3 + 2)];
                        int k2 = aint[j + 1 + (i + 1 + 1) * (var3 + 2)];
                        if (l1 == BiomeGenBase.desert.biomeID
                            || i2 == BiomeGenBase.desert.biomeID
                            || j2 == BiomeGenBase.desert.biomeID
                            || k2 == BiomeGenBase.desert.biomeID
                            || l1 == BiomeGenBase.coldTaiga.biomeID
                            || i2 == BiomeGenBase.coldTaiga.biomeID
                            || j2 == BiomeGenBase.coldTaiga.biomeID
                            || k2 == BiomeGenBase.coldTaiga.biomeID
                            || l1 == BiomeGenBase.icePlains.biomeID
                            || i2 == BiomeGenBase.icePlains.biomeID
                            || j2 == BiomeGenBase.icePlains.biomeID
                            || k2 == BiomeGenBase.icePlains.biomeID) {
                            aint1[j + i * var3] = BiomeGenBase.plains.biomeID;
                        } else if (l1 != BiomeGenBase.jungle.biomeID
                            && k2 != BiomeGenBase.jungle.biomeID
                            && i2 != BiomeGenBase.jungle.biomeID
                            && j2 != BiomeGenBase.jungle.biomeID) {
                            aint1[j + i * var3] = k;
                        } else {
                            aint1[j + i * var3] = BiomeGenBase.jungleEdge.biomeID;
                        }
                    } else {
                        aint1[j + i * var3] = k;
                    }
                }
            }
        }

        return aint1;
    }

    private boolean replaceBiomeEdgeIfNecessary(int[] var1, int[] var2, int var3, int var4, int var5, int var6, int var7, int var8) {
        if (!biomesEqualOrMesaPlateau(var6, var7)) {
            return false;
        }

        int i = var1[var3 + 1 + (var4 + 1 - 1) * (var5 + 2)];
        int j = var1[var3 + 1 + 1 + (var4 + 1) * (var5 + 2)];
        int k = var1[var3 + 1 - 1 + (var4 + 1) * (var5 + 2)];
        int l = var1[var3 + 1 + (var4 + 1 + 1) * (var5 + 2)];
        if (this.canBiomesBeNeighbors(i, var7)
            && this.canBiomesBeNeighbors(j, var7)
            && this.canBiomesBeNeighbors(k, var7)
            && this.canBiomesBeNeighbors(l, var7)) {
            var2[var3 + var4 * var5] = var6;
        } else {
            var2[var3 + var4 * var5] = var8;
        }

        return true;
    }

    private boolean replaceBiomeEdge(int[] var1, int[] var2, int var3, int var4, int var5, int var6, int var7, int var8) {
        if (var6 != var7) {
            return false;
        }

        int i = var1[var3 + 1 + (var4 + 1 - 1) * (var5 + 2)];
        int j = var1[var3 + 1 + 1 + (var4 + 1) * (var5 + 2)];
        int k = var1[var3 + 1 - 1 + (var4 + 1) * (var5 + 2)];
        int l = var1[var3 + 1 + (var4 + 1 + 1) * (var5 + 2)];
        if (biomesEqualOrMesaPlateau(i, var7) && biomesEqualOrMesaPlateau(j, var7) && biomesEqualOrMesaPlateau(k, var7) && biomesEqualOrMesaPlateau(l, var7)) {
            var2[var3 + var4 * var5] = var6;
        } else {
            var2[var3 + var4 * var5] = var8;
        }

        return true;
    }

    private boolean canBiomesBeNeighbors(int var1, int var2) {
        if (biomesEqualOrMesaPlateau(var1, var2)) {
            return true;
        } else if (BiomeGenBase.getBiome(var1) != null && BiomeGenBase.getBiome(var2) != null) {
            BiomeGenBase.TempCategory biomegenbase$tempcategory = BiomeGenBase.getBiome(var1).getTempCategory();
            BiomeGenBase.TempCategory biomegenbase$tempcategory1 = BiomeGenBase.getBiome(var2).getTempCategory();
            return biomegenbase$tempcategory == biomegenbase$tempcategory1
                || biomegenbase$tempcategory == BiomeGenBase.TempCategory.MEDIUM
                || biomegenbase$tempcategory1 == BiomeGenBase.TempCategory.MEDIUM;
        } else {
            return false;
        }
    }
}
