package net.minecraft.world.gen.layer;

public class GenLayerEdge extends GenLayer {
    private final GenLayerEdge.Mode field_151627_c;

    public GenLayerEdge(long var1, GenLayer var3, GenLayerEdge.Mode var4) {
        super(var1);
        this.parent = var3;
        this.field_151627_c = var4;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        switch (this.field_151627_c) {
            case COOL_WARM:
            default:
                return this.getIntsCoolWarm(var1, var2, var3, var4);
            case HEAT_ICE:
                return this.getIntsHeatIce(var1, var2, var3, var4);
            case SPECIAL:
                return this.getIntsSpecial(var1, var2, var3, var4);
        }
    }

    private int[] getIntsCoolWarm(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = 1 + var3 + 1;
        int l = 1 + var4 + 1;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                this.initChunkSeed(j1 + var1, i1 + var2);
                int k1 = aint[j1 + 1 + (i1 + 1) * k];
                if (k1 == 1) {
                    int l1 = aint[j1 + 1 + (i1 + 1 - 1) * k];
                    int i2 = aint[j1 + 1 + 1 + (i1 + 1) * k];
                    int j2 = aint[j1 + 1 - 1 + (i1 + 1) * k];
                    int k2 = aint[j1 + 1 + (i1 + 1 + 1) * k];
                    boolean flag = l1 == 3 || i2 == 3 || j2 == 3 || k2 == 3;
                    boolean flag1 = l1 == 4 || i2 == 4 || j2 == 4 || k2 == 4;
                    if (flag || flag1) {
                        k1 = 2;
                    }
                }

                aint1[j1 + i1 * var3] = k1;
            }
        }

        return aint1;
    }

    private int[] getIntsHeatIce(int var1, int var2, int var3, int var4) {
        int i = var1 - 1;
        int j = var2 - 1;
        int k = 1 + var3 + 1;
        int l = 1 + var4 + 1;
        int[] aint = this.parent.getInts(i, j, k, l);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i1 = 0; i1 < var4; i1++) {
            for (int j1 = 0; j1 < var3; j1++) {
                int k1 = aint[j1 + 1 + (i1 + 1) * k];
                if (k1 == 4) {
                    int l1 = aint[j1 + 1 + (i1 + 1 - 1) * k];
                    int i2 = aint[j1 + 1 + 1 + (i1 + 1) * k];
                    int j2 = aint[j1 + 1 - 1 + (i1 + 1) * k];
                    int k2 = aint[j1 + 1 + (i1 + 1 + 1) * k];
                    boolean flag = l1 == 2 || i2 == 2 || j2 == 2 || k2 == 2;
                    boolean flag1 = l1 == 1 || i2 == 1 || j2 == 1 || k2 == 1;
                    if (flag1 || flag) {
                        k1 = 3;
                    }
                }

                aint1[j1 + i1 * var3] = k1;
            }
        }

        return aint1;
    }

    private int[] getIntsSpecial(int var1, int var2, int var3, int var4) {
        int[] aint = this.parent.getInts(var1, var2, var3, var4);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var4; i++) {
            for (int j = 0; j < var3; j++) {
                this.initChunkSeed(j + var1, i + var2);
                int k = aint[j + i * var3];
                if (k != 0 && this.nextInt(13) == 0) {
                    k |= 1 + this.nextInt(15) << 8 & 3840;
                }

                aint1[j + i * var3] = k;
            }
        }

        return aint1;
    }

    public enum Mode {
        COOL_WARM,
        HEAT_ICE,
        SPECIAL;
    }
}
