package net.minecraft.world.gen.layer;

public class GenLayerZoom extends GenLayer {
    public GenLayerZoom(long var1, GenLayer var3) {
        super(var1);
        super.parent = var3;
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int i = var1 >> 1;
        int j = var2 >> 1;
        int k = (var3 >> 1) + 2;
        int l = (var4 >> 1) + 2;
        int[] aint = this.parent.getInts(i, j, k, l);
        int i1 = k - 1 << 1;
        int j1 = l - 1 << 1;
        int[] aint1 = IntCache.getIntCache(i1 * j1);

        for (int k1 = 0; k1 < l - 1; k1++) {
            int l1 = (k1 << 1) * i1;
            int i2 = 0;
            int j2 = aint[i2 + 0 + (k1 + 0) * k];
            int k2 = aint[i2 + 0 + (k1 + 1) * k];

            while (i2 < k - 1) {
                this.initChunkSeed(i2 + i << 1, k1 + j << 1);
                int l2 = aint[i2 + 1 + (k1 + 0) * k];
                int i3 = aint[i2 + 1 + (k1 + 1) * k];
                aint1[l1] = j2;
                aint1[l1++ + i1] = this.selectRandom(j2, k2);
                aint1[l1] = this.selectRandom(j2, l2);
                aint1[l1++ + i1] = this.selectModeOrRandom(j2, l2, k2, i3);
                j2 = l2;
                k2 = i3;
                i2++;
            }
        }

        int[] aint2 = IntCache.getIntCache(var3 * var4);

        for (int j3 = 0; j3 < var4; j3++) {
            System.arraycopy(aint1, (j3 + (var2 & 1)) * i1 + (var1 & 1), aint2, j3 * var3, var3);
        }

        return aint2;
    }

    public static GenLayer magnify(long var0, GenLayer var2, int var3) {
        GenLayer genlayer = var2;

        for (int i = 0; i < var3; i++) {
            genlayer = new GenLayerZoom(var0 + i, genlayer);
        }

        return genlayer;
    }
}
