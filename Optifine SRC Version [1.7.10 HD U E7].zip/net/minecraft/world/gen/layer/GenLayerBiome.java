package net.minecraft.world.gen.layer;

import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;

public class GenLayerBiome extends GenLayer {
    private BiomeGenBase[] field_151623_c = new BiomeGenBase[]{
        BiomeGenBase.desert, BiomeGenBase.desert, BiomeGenBase.desert, BiomeGenBase.savanna, BiomeGenBase.savanna, BiomeGenBase.plains
    };
    private BiomeGenBase[] field_151621_d = new BiomeGenBase[]{
        BiomeGenBase.forest, BiomeGenBase.roofedForest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.birchForest, BiomeGenBase.swampland
    };
    private BiomeGenBase[] field_151622_e = new BiomeGenBase[]{BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.taiga, BiomeGenBase.plains};
    private BiomeGenBase[] field_151620_f = new BiomeGenBase[]{BiomeGenBase.icePlains, BiomeGenBase.icePlains, BiomeGenBase.icePlains, BiomeGenBase.coldTaiga};

    public GenLayerBiome(long var1, GenLayer var3, WorldType var4) {
        super(var1);
        this.parent = var3;
        if (var4 == WorldType.DEFAULT_1_1) {
            this.field_151623_c = new BiomeGenBase[]{
                BiomeGenBase.desert, BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.swampland, BiomeGenBase.plains, BiomeGenBase.taiga
            };
        }
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int[] aint = this.parent.getInts(var1, var2, var3, var4);
        int[] aint1 = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var4; i++) {
            for (int j = 0; j < var3; j++) {
                this.initChunkSeed(j + var1, i + var2);
                int k = aint[j + i * var3];
                int l = (k & 3840) >> 8;
                k &= -3841;
                if (isBiomeOceanic(k)) {
                    aint1[j + i * var3] = k;
                } else if (k == BiomeGenBase.mushroomIsland.biomeID) {
                    aint1[j + i * var3] = k;
                } else if (k == 1) {
                    if (l > 0) {
                        if (this.nextInt(3) == 0) {
                            aint1[j + i * var3] = BiomeGenBase.mesaPlateau.biomeID;
                        } else {
                            aint1[j + i * var3] = BiomeGenBase.mesaPlateau_F.biomeID;
                        }
                    } else {
                        aint1[j + i * var3] = this.field_151623_c[this.nextInt(this.field_151623_c.length)].biomeID;
                    }
                } else if (k == 2) {
                    if (l > 0) {
                        aint1[j + i * var3] = BiomeGenBase.jungle.biomeID;
                    } else {
                        aint1[j + i * var3] = this.field_151621_d[this.nextInt(this.field_151621_d.length)].biomeID;
                    }
                } else if (k == 3) {
                    if (l > 0) {
                        aint1[j + i * var3] = BiomeGenBase.megaTaiga.biomeID;
                    } else {
                        aint1[j + i * var3] = this.field_151622_e[this.nextInt(this.field_151622_e.length)].biomeID;
                    }
                } else if (k == 4) {
                    aint1[j + i * var3] = this.field_151620_f[this.nextInt(this.field_151620_f.length)].biomeID;
                } else {
                    aint1[j + i * var3] = BiomeGenBase.mushroomIsland.biomeID;
                }
            }
        }

        return aint1;
    }
}
