package net.minecraft.world.gen.layer;

import net.minecraft.world.biome.BiomeGenBase;

public class GenLayerRiverMix extends GenLayer {
    private GenLayer biomePatternGeneratorChain;
    private GenLayer riverPatternGeneratorChain;

    public GenLayerRiverMix(long var1, GenLayer var3, GenLayer var4) {
        super(var1);
        this.biomePatternGeneratorChain = var3;
        this.riverPatternGeneratorChain = var4;
    }

    @Override
    public void initWorldGenSeed(long var1) {
        this.biomePatternGeneratorChain.initWorldGenSeed(var1);
        this.riverPatternGeneratorChain.initWorldGenSeed(var1);
        super.initWorldGenSeed(var1);
    }

    @Override
    public int[] getInts(int var1, int var2, int var3, int var4) {
        int[] aint = this.biomePatternGeneratorChain.getInts(var1, var2, var3, var4);
        int[] aint1 = this.riverPatternGeneratorChain.getInts(var1, var2, var3, var4);
        int[] aint2 = IntCache.getIntCache(var3 * var4);

        for (int i = 0; i < var3 * var4; i++) {
            if (aint[i] == BiomeGenBase.ocean.biomeID || aint[i] == BiomeGenBase.deepOcean.biomeID) {
                aint2[i] = aint[i];
            } else if (aint1[i] == BiomeGenBase.river.biomeID) {
                if (aint[i] == BiomeGenBase.icePlains.biomeID) {
                    aint2[i] = BiomeGenBase.frozenRiver.biomeID;
                } else if (aint[i] != BiomeGenBase.mushroomIsland.biomeID && aint[i] != BiomeGenBase.mushroomIslandShore.biomeID) {
                    aint2[i] = aint1[i] & 0xFF;
                } else {
                    aint2[i] = BiomeGenBase.mushroomIslandShore.biomeID;
                }
            } else {
                aint2[i] = aint[i];
            }
        }

        return aint2;
    }
}
