package net.minecraft.world.gen;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class MapGenCaves extends MapGenBase {
    protected void func_151542_a(long var1, int var3, int var4, Block[] var5, double var6, double var8, double var10) {
        this.func_151541_a(var1, var3, var4, var5, var6, var8, var10, 1.0F + this.rand.nextFloat() * 6.0F, 0.0F, 0.0F, -1, -1, 0.5);
    }

    protected void func_151541_a(
        long var1,
        int var3,
        int var4,
        Block[] var5,
        double var6,
        double var8,
        double var10,
        float var12,
        float var13,
        float var14,
        int var15,
        int var16,
        double var17
    ) {
        double d0 = var3 * 16 + 8;
        double d1 = var4 * 16 + 8;
        float f = 0.0F;
        float f1 = 0.0F;
        Random random = new Random(var1);
        if (var16 <= 0) {
            int i = this.range * 16 - 16;
            var16 = i - random.nextInt(i / 4);
        }

        boolean flag2 = false;
        if (var15 == -1) {
            var15 = var16 / 2;
            flag2 = true;
        }

        int j = random.nextInt(var16 / 2) + var16 / 4;
        boolean flag = random.nextInt(6) == 0;

        while (var15 < var16) {
            double d2 = 1.5 + MathHelper.sin(var15 * (float)Math.PI / var16) * var12 * 1.0F;
            double d3 = d2 * var17;
            float f2 = MathHelper.cos(var14);
            float f3 = MathHelper.sin(var14);
            var6 += MathHelper.cos(var13) * f2;
            var8 += f3;
            var10 += MathHelper.sin(var13) * f2;
            if (flag) {
                var14 *= 0.92F;
            } else {
                var14 *= 0.7F;
            }

            var14 += f1 * 0.1F;
            var13 += f * 0.1F;
            f1 *= 0.9F;
            f *= 12.0F / 16.0F;
            f1 += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 2.0F;
            f += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 4.0F;
            if (!flag2 && var15 == j && var12 > 1.0F && var16 > 0) {
                this.func_151541_a(
                    random.nextLong(),
                    var3,
                    var4,
                    var5,
                    var6,
                    var8,
                    var10,
                    random.nextFloat() * 0.5F + 0.5F,
                    var13 - (float)Math.PI * 0.5F,
                    var14 / 3.0F,
                    var15,
                    var16,
                    1.0
                );
                this.func_151541_a(
                    random.nextLong(),
                    var3,
                    var4,
                    var5,
                    var6,
                    var8,
                    var10,
                    random.nextFloat() * 0.5F + 0.5F,
                    var13 + (float)Math.PI * 0.5F,
                    var14 / 3.0F,
                    var15,
                    var16,
                    1.0
                );
                return;
            }

            if (flag2 || random.nextInt(4) != 0) {
                double d4 = var6 - d0;
                double d5 = var10 - d1;
                double d6 = var16 - var15;
                double d7 = var12 + 2.0F + 16.0F;
                if (d4 * d4 + d5 * d5 - d6 * d6 > d7 * d7) {
                    return;
                }

                if (!(var6 < d0 - 16.0 - d2 * 2.0) && !(var10 < d1 - 16.0 - d2 * 2.0) && !(var6 > d0 + 16.0 + d2 * 2.0) && !(var10 > d1 + 16.0 + d2 * 2.0)) {
                    int l2 = MathHelper.floor_double(var6 - d2) - var3 * 16 - 1;
                    int k = MathHelper.floor_double(var6 + d2) - var3 * 16 + 1;
                    int i3 = MathHelper.floor_double(var8 - d3) - 1;
                    int l = MathHelper.floor_double(var8 + d3) + 1;
                    int j3 = MathHelper.floor_double(var10 - d2) - var4 * 16 - 1;
                    int i1 = MathHelper.floor_double(var10 + d2) - var4 * 16 + 1;
                    if (l2 < 0) {
                        l2 = 0;
                    }

                    if (k > 16) {
                        k = 16;
                    }

                    if (i3 < 1) {
                        i3 = 1;
                    }

                    if (l > 248) {
                        l = 248;
                    }

                    if (j3 < 0) {
                        j3 = 0;
                    }

                    if (i1 > 16) {
                        i1 = 16;
                    }

                    boolean flag3 = false;

                    for (int j1 = l2; !flag3 && j1 < k; j1++) {
                        for (int k1 = j3; !flag3 && k1 < i1; k1++) {
                            for (int l1 = l + 1; !flag3 && l1 >= i3 - 1; l1--) {
                                int i2 = (j1 * 16 + k1) * 256 + l1;
                                if (l1 >= 0 && l1 < 256) {
                                    Block block = var5[i2];
                                    if (block == Blocks.flowing_water || block == Blocks.water) {
                                        flag3 = true;
                                    }

                                    if (l1 != i3 - 1 && j1 != l2 && j1 != k - 1 && k1 != j3 && k1 != i1 - 1) {
                                        l1 = i3;
                                    }
                                }
                            }
                        }
                    }

                    if (!flag3) {
                        for (int k3 = l2; k3 < k; k3++) {
                            double d9 = (k3 + var3 * 16 + 0.5 - var6) / d2;

                            for (int l3 = j3; l3 < i1; l3++) {
                                double d10 = (l3 + var4 * 16 + 0.5 - var10) / d2;
                                int j2 = (k3 * 16 + l3) * 256 + l;
                                boolean flag1 = false;
                                if (d9 * d9 + d10 * d10 < 1.0) {
                                    for (int k2 = l - 1; k2 >= i3; k2--) {
                                        double d8 = (k2 + 0.5 - var8) / d3;
                                        if (d8 > -0.7 && d9 * d9 + d8 * d8 + d10 * d10 < 1.0) {
                                            Block block1 = var5[j2];
                                            if (block1 == Blocks.grass) {
                                                flag1 = true;
                                            }

                                            if (block1 == Blocks.stone || block1 == Blocks.dirt || block1 == Blocks.grass) {
                                                if (k2 < 10) {
                                                    var5[j2] = Blocks.lava;
                                                } else {
                                                    var5[j2] = null;
                                                    if (flag1 && var5[j2 - 1] == Blocks.dirt) {
                                                        var5[j2 - 1] = this.worldObj.getBiomeGenForCoords(k3 + var3 * 16, l3 + var4 * 16).topBlock;
                                                    }
                                                }
                                            }
                                        }

                                        j2--;
                                    }
                                }
                            }
                        }

                        if (flag2) {
                            break;
                        }
                    }
                }
            }

            var15++;
        }
    }

    @Override
    protected void func_151538_a(World var1, int var2, int var3, int var4, int var5, Block[] var6) {
        int i = this.rand.nextInt(this.rand.nextInt(this.rand.nextInt(15) + 1) + 1);
        if (this.rand.nextInt(7) != 0) {
            i = 0;
        }

        for (int j = 0; j < i; j++) {
            double d0 = var2 * 16 + this.rand.nextInt(16);
            double d1 = this.rand.nextInt(this.rand.nextInt(120) + 8);
            double d2 = var3 * 16 + this.rand.nextInt(16);
            int k = 1;
            if (this.rand.nextInt(4) == 0) {
                this.func_151542_a(this.rand.nextLong(), var4, var5, var6, d0, d1, d2);
                k += this.rand.nextInt(4);
            }

            for (int l = 0; l < k; l++) {
                float f = this.rand.nextFloat() * (float)Math.PI * 2.0F;
                float f1 = (this.rand.nextFloat() - 0.5F) * 2.0F / 8.0F;
                float f2 = this.rand.nextFloat() * 2.0F + this.rand.nextFloat();
                if (this.rand.nextInt(10) == 0) {
                    f2 *= this.rand.nextFloat() * this.rand.nextFloat() * 3.0F + 1.0F;
                }

                this.func_151541_a(this.rand.nextLong(), var4, var5, var6, d0, d1, d2, f2, f, f1, 0, 0, 1.0);
            }
        }
    }
}
