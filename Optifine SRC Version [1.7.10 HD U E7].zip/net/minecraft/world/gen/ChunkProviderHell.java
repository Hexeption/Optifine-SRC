package net.minecraft.world.gen;

import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenFire;
import net.minecraft.world.gen.feature.WorldGenFlowers;
import net.minecraft.world.gen.feature.WorldGenGlowStone1;
import net.minecraft.world.gen.feature.WorldGenGlowStone2;
import net.minecraft.world.gen.feature.WorldGenHellLava;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.structure.MapGenNetherBridge;

public class ChunkProviderHell implements IChunkProvider {
    private Random hellRNG;
    private NoiseGeneratorOctaves netherNoiseGen1;
    private NoiseGeneratorOctaves netherNoiseGen2;
    private NoiseGeneratorOctaves netherNoiseGen3;
    private NoiseGeneratorOctaves slowsandGravelNoiseGen;
    private NoiseGeneratorOctaves netherrackExculsivityNoiseGen;
    public NoiseGeneratorOctaves netherNoiseGen6;
    public NoiseGeneratorOctaves netherNoiseGen7;
    private World worldObj;
    private double[] noiseField;
    public MapGenNetherBridge genNetherBridge = new MapGenNetherBridge();
    private double[] slowsandNoise = new double[256];
    private double[] gravelNoise = new double[256];
    private double[] netherrackExclusivityNoise = new double[256];
    private MapGenBase netherCaveGenerator = new MapGenCavesHell();
    double[] noiseData1;
    double[] noiseData2;
    double[] noiseData3;
    double[] noiseData4;
    double[] noiseData5;

    public ChunkProviderHell(World var1, long var2) {
        this.worldObj = var1;
        this.hellRNG = new Random(var2);
        this.netherNoiseGen1 = new NoiseGeneratorOctaves(this.hellRNG, 16);
        this.netherNoiseGen2 = new NoiseGeneratorOctaves(this.hellRNG, 16);
        this.netherNoiseGen3 = new NoiseGeneratorOctaves(this.hellRNG, 8);
        this.slowsandGravelNoiseGen = new NoiseGeneratorOctaves(this.hellRNG, 4);
        this.netherrackExculsivityNoiseGen = new NoiseGeneratorOctaves(this.hellRNG, 4);
        this.netherNoiseGen6 = new NoiseGeneratorOctaves(this.hellRNG, 10);
        this.netherNoiseGen7 = new NoiseGeneratorOctaves(this.hellRNG, 16);
    }

    public void func_147419_a(int var1, int var2, Block[] var3) {
        byte b0 = 4;
        byte b1 = 32;
        int i = b0 + 1;
        byte b2 = 17;
        int j = b0 + 1;
        this.noiseField = this.initializeNoiseField(this.noiseField, var1 * b0, 0, var2 * b0, i, b2, j);

        for (int k = 0; k < b0; k++) {
            for (int l = 0; l < b0; l++) {
                for (int i1 = 0; i1 < 16; i1++) {
                    double d0 = 0.125;
                    double d1 = this.noiseField[((k + 0) * j + l + 0) * b2 + i1 + 0];
                    double d2 = this.noiseField[((k + 0) * j + l + 1) * b2 + i1 + 0];
                    double d3 = this.noiseField[((k + 1) * j + l + 0) * b2 + i1 + 0];
                    double d4 = this.noiseField[((k + 1) * j + l + 1) * b2 + i1 + 0];
                    double d5 = (this.noiseField[((k + 0) * j + l + 0) * b2 + i1 + 1] - d1) * d0;
                    double d6 = (this.noiseField[((k + 0) * j + l + 1) * b2 + i1 + 1] - d2) * d0;
                    double d7 = (this.noiseField[((k + 1) * j + l + 0) * b2 + i1 + 1] - d3) * d0;
                    double d8 = (this.noiseField[((k + 1) * j + l + 1) * b2 + i1 + 1] - d4) * d0;

                    for (int j1 = 0; j1 < 8; j1++) {
                        double d9 = 0.25;
                        double d10 = d1;
                        double d11 = d2;
                        double d12 = (d3 - d1) * d9;
                        double d13 = (d4 - d2) * d9;

                        for (int k1 = 0; k1 < 4; k1++) {
                            int l1 = k1 + k * 4 << 11 | 0 + l * 4 << 7 | i1 * 8 + j1;
                            short short1 = 128;
                            double d14 = 0.25;
                            double d15 = d10;
                            double d16 = (d11 - d10) * d14;

                            for (int i2 = 0; i2 < 4; i2++) {
                                Block block = null;
                                if (i1 * 8 + j1 < b1) {
                                    block = Blocks.lava;
                                }

                                if (d15 > 0.0) {
                                    block = Blocks.netherrack;
                                }

                                var3[l1] = block;
                                l1 += short1;
                                d15 += d16;
                            }

                            d10 += d12;
                            d11 += d13;
                        }

                        d1 += d5;
                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                    }
                }
            }
        }
    }

    public void func_147418_b(int var1, int var2, Block[] var3) {
        byte b0 = 64;
        double d0 = 1.0 / 32.0;
        this.slowsandNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.slowsandNoise, var1 * 16, var2 * 16, 0, 16, 16, 1, d0, d0, 1.0);
        this.gravelNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.gravelNoise, var1 * 16, 109, var2 * 16, 16, 1, 16, d0, 1.0, d0);
        this.netherrackExclusivityNoise = this.netherrackExculsivityNoiseGen
            .generateNoiseOctaves(this.netherrackExclusivityNoise, var1 * 16, var2 * 16, 0, 16, 16, 1, d0 * 2.0, d0 * 2.0, d0 * 2.0);

        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                boolean flag = this.slowsandNoise[i + j * 16] + this.hellRNG.nextDouble() * 0.2 > 0.0;
                boolean flag1 = this.gravelNoise[i + j * 16] + this.hellRNG.nextDouble() * 0.2 > 0.0;
                int k = (int)(this.netherrackExclusivityNoise[i + j * 16] / 3.0 + 3.0 + this.hellRNG.nextDouble() * 0.25);
                int l = -1;
                Block block = Blocks.netherrack;
                Block block1 = Blocks.netherrack;

                for (int i1 = 127; i1 >= 0; i1--) {
                    int j1 = (j * 16 + i) * 128 + i1;
                    if (i1 < 127 - this.hellRNG.nextInt(5) && i1 > 0 + this.hellRNG.nextInt(5)) {
                        Block block2 = var3[j1];
                        if (block2 == null || block2.getMaterial() == Material.air) {
                            l = -1;
                        } else if (block2 == Blocks.netherrack) {
                            if (l == -1) {
                                if (k <= 0) {
                                    block = null;
                                    block1 = Blocks.netherrack;
                                } else if (i1 >= b0 - 4 && i1 <= b0 + 1) {
                                    block = Blocks.netherrack;
                                    block1 = Blocks.netherrack;
                                    if (flag1) {
                                        block = Blocks.gravel;
                                        block1 = Blocks.netherrack;
                                    }

                                    if (flag) {
                                        block = Blocks.soul_sand;
                                        block1 = Blocks.soul_sand;
                                    }
                                }

                                if (i1 < b0 && (block == null || block.getMaterial() == Material.air)) {
                                    block = Blocks.lava;
                                }

                                l = k;
                                if (i1 >= b0 - 1) {
                                    var3[j1] = block;
                                } else {
                                    var3[j1] = block1;
                                }
                            } else if (l > 0) {
                                l--;
                                var3[j1] = block1;
                            }
                        }
                    } else {
                        var3[j1] = Blocks.bedrock;
                    }
                }
            }
        }
    }

    @Override
    public Chunk loadChunk(int var1, int var2) {
        return this.provideChunk(var1, var2);
    }

    @Override
    public Chunk provideChunk(int var1, int var2) {
        this.hellRNG.setSeed(var1 * 341873128712L + var2 * 132897987541L);
        Block[] ablock = new Block[-Short.MIN_VALUE];
        this.func_147419_a(var1, var2, ablock);
        this.func_147418_b(var1, var2, ablock);
        this.netherCaveGenerator.generate(this, this.worldObj, var1, var2, ablock);
        this.genNetherBridge.generate(this, this.worldObj, var1, var2, ablock);
        Chunk chunk = new Chunk(this.worldObj, ablock, var1, var2);
        BiomeGenBase[] abiomegenbase = this.worldObj.getWorldChunkManager().loadBlockGeneratorData(null, var1 * 16, var2 * 16, 16, 16);
        byte[] abyte = chunk.getBiomeArray();

        for (int i = 0; i < abyte.length; i++) {
            abyte[i] = (byte)abiomegenbase[i].biomeID;
        }

        chunk.resetRelightChecks();
        return chunk;
    }

    private double[] initializeNoiseField(double[] var1, int var2, int var3, int var4, int var5, int var6, int var7) {
        if (var1 == null) {
            var1 = new double[var5 * var6 * var7];
        }

        double d0 = 684.412;
        double d1 = 2053.236;
        this.noiseData4 = this.netherNoiseGen6.generateNoiseOctaves(this.noiseData4, var2, var3, var4, var5, 1, var7, 1.0, 0.0, 1.0);
        this.noiseData5 = this.netherNoiseGen7.generateNoiseOctaves(this.noiseData5, var2, var3, var4, var5, 1, var7, 100.0, 0.0, 100.0);
        this.noiseData1 = this.netherNoiseGen3.generateNoiseOctaves(this.noiseData1, var2, var3, var4, var5, var6, var7, d0 / 80.0, d1 / 60.0, d0 / 80.0);
        this.noiseData2 = this.netherNoiseGen1.generateNoiseOctaves(this.noiseData2, var2, var3, var4, var5, var6, var7, d0, d1, d0);
        this.noiseData3 = this.netherNoiseGen2.generateNoiseOctaves(this.noiseData3, var2, var3, var4, var5, var6, var7, d0, d1, d0);
        int i = 0;
        int j = 0;
        double[] adouble = new double[var6];

        for (int k = 0; k < var6; k++) {
            adouble[k] = Math.cos(k * Math.PI * 6.0 / var6) * 2.0;
            double d2 = k;
            if (k > var6 / 2) {
                d2 = var6 - 1 - k;
            }

            if (d2 < 4.0) {
                d2 = 4.0 - d2;
                adouble[k] -= d2 * d2 * d2 * 10.0;
            }
        }

        for (int i1 = 0; i1 < var5; i1++) {
            for (int j1 = 0; j1 < var7; j1++) {
                double d3 = (this.noiseData4[j] + 256.0) / 512.0;
                if (d3 > 1.0) {
                    d3 = 1.0;
                }

                double d4 = 0.0;
                double d5 = this.noiseData5[j] / 8000.0;
                if (d5 < 0.0) {
                    d5 = -d5;
                }

                d5 = d5 * 3.0 - 3.0;
                if (d5 < 0.0) {
                    d5 /= 2.0;
                    if (d5 < -1.0) {
                        d5 = -1.0;
                    }

                    d5 /= 1.4;
                    d5 /= 2.0;
                    d3 = 0.0;
                } else {
                    if (d5 > 1.0) {
                        d5 = 1.0;
                    }

                    d5 /= 6.0;
                }

                d3 += 0.5;
                d5 = d5 * var6 / 16.0;
                j++;

                for (int l = 0; l < var6; l++) {
                    double d6 = 0.0;
                    double d7 = adouble[l];
                    double d8 = this.noiseData2[i] / 512.0;
                    double d9 = this.noiseData3[i] / 512.0;
                    double d10 = (this.noiseData1[i] / 10.0 + 1.0) / 2.0;
                    if (d10 < 0.0) {
                        d6 = d8;
                    } else if (d10 > 1.0) {
                        d6 = d9;
                    } else {
                        d6 = d8 + (d9 - d8) * d10;
                    }

                    d6 -= d7;
                    if (l > var6 - 4) {
                        double d11 = (l - (var6 - 4)) / 3.0F;
                        d6 = d6 * (1.0 - d11) + -10.0 * d11;
                    }

                    if (l < d4) {
                        double d12 = (d4 - l) / 4.0;
                        if (d12 < 0.0) {
                            d12 = 0.0;
                        }

                        if (d12 > 1.0) {
                            d12 = 1.0;
                        }

                        d6 = d6 * (1.0 - d12) + -10.0 * d12;
                    }

                    var1[i] = d6;
                    i++;
                }
            }
        }

        return var1;
    }

    @Override
    public boolean chunkExists(int var1, int var2) {
        return true;
    }

    @Override
    public void populate(IChunkProvider var1, int var2, int var3) {
        BlockFalling.fallInstantly = true;
        int i = var2 * 16;
        int j = var3 * 16;
        this.genNetherBridge.generateStructuresInChunk(this.worldObj, this.hellRNG, var2, var3);

        for (int k = 0; k < 8; k++) {
            int l = i + this.hellRNG.nextInt(16) + 8;
            int i1 = this.hellRNG.nextInt(120) + 4;
            int j1 = j + this.hellRNG.nextInt(16) + 8;
            new WorldGenHellLava(Blocks.flowing_lava, false).generate(this.worldObj, this.hellRNG, l, i1, j1);
        }

        int i2 = this.hellRNG.nextInt(this.hellRNG.nextInt(10) + 1) + 1;

        for (int j2 = 0; j2 < i2; j2++) {
            int k3 = i + this.hellRNG.nextInt(16) + 8;
            int j5 = this.hellRNG.nextInt(120) + 4;
            int k1 = j + this.hellRNG.nextInt(16) + 8;
            new WorldGenFire().generate(this.worldObj, this.hellRNG, k3, j5, k1);
        }

        i2 = this.hellRNG.nextInt(this.hellRNG.nextInt(10) + 1);

        for (int k2 = 0; k2 < i2; k2++) {
            int l3 = i + this.hellRNG.nextInt(16) + 8;
            int k5 = this.hellRNG.nextInt(120) + 4;
            int i7 = j + this.hellRNG.nextInt(16) + 8;
            new WorldGenGlowStone1().generate(this.worldObj, this.hellRNG, l3, k5, i7);
        }

        for (int l2 = 0; l2 < 10; l2++) {
            int i4 = i + this.hellRNG.nextInt(16) + 8;
            int l5 = this.hellRNG.nextInt(128);
            int j7 = j + this.hellRNG.nextInt(16) + 8;
            new WorldGenGlowStone2().generate(this.worldObj, this.hellRNG, i4, l5, j7);
        }

        if (this.hellRNG.nextInt(1) == 0) {
            int i3 = i + this.hellRNG.nextInt(16) + 8;
            int j4 = this.hellRNG.nextInt(128);
            int i6 = j + this.hellRNG.nextInt(16) + 8;
            new WorldGenFlowers(Blocks.brown_mushroom).generate(this.worldObj, this.hellRNG, i3, j4, i6);
        }

        if (this.hellRNG.nextInt(1) == 0) {
            int j3 = i + this.hellRNG.nextInt(16) + 8;
            int k4 = this.hellRNG.nextInt(128);
            int j6 = j + this.hellRNG.nextInt(16) + 8;
            new WorldGenFlowers(Blocks.red_mushroom).generate(this.worldObj, this.hellRNG, j3, k4, j6);
        }

        WorldGenMinable worldgenminable = new WorldGenMinable(Blocks.quartz_ore, 13, Blocks.netherrack);

        for (int l4 = 0; l4 < 16; l4++) {
            int k6 = i + this.hellRNG.nextInt(16);
            int k7 = this.hellRNG.nextInt(108) + 10;
            int l1 = j + this.hellRNG.nextInt(16);
            worldgenminable.generate(this.worldObj, this.hellRNG, k6, k7, l1);
        }

        for (int i5 = 0; i5 < 16; i5++) {
            int l6 = i + this.hellRNG.nextInt(16);
            int l7 = this.hellRNG.nextInt(108) + 10;
            int i8 = j + this.hellRNG.nextInt(16);
            new WorldGenHellLava(Blocks.flowing_lava, true).generate(this.worldObj, this.hellRNG, l6, l7, i8);
        }

        BlockFalling.fallInstantly = false;
    }

    @Override
    public boolean saveChunks(boolean var1, IProgressUpdate var2) {
        return true;
    }

    @Override
    public void saveExtraData() {
    }

    @Override
    public boolean unloadQueuedChunks() {
        return false;
    }

    @Override
    public boolean canSave() {
        return true;
    }

    @Override
    public String makeString() {
        return "HellRandomLevelSource";
    }

    @Override
    public List getPossibleCreatures(EnumCreatureType var1, int var2, int var3, int var4) {
        if (var1 == EnumCreatureType.monster) {
            if (this.genNetherBridge.hasStructureAt(var2, var3, var4)) {
                return this.genNetherBridge.getSpawnList();
            }

            if (this.genNetherBridge.func_142038_b(var2, var3, var4) && this.worldObj.getBlock(var2, var3 - 1, var4) == Blocks.nether_brick) {
                return this.genNetherBridge.getSpawnList();
            }
        }

        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(var2, var4);
        return biomegenbase.getSpawnableList(var1);
    }

    @Override
    public ChunkPosition findClosestStructure(World var1, String var2, int var3, int var4, int var5) {
        return null;
    }

    @Override
    public int getLoadedChunkCount() {
        return 0;
    }

    @Override
    public void recreateStructures(int var1, int var2) {
        this.genNetherBridge.generate(this, this.worldObj, var1, var2, null);
    }
}
