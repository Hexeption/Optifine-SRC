package net.minecraft.world.gen;

import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.MathHelper;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;

public class ChunkProviderEnd implements IChunkProvider {
    private Random endRNG;
    private NoiseGeneratorOctaves noiseGen1;
    private NoiseGeneratorOctaves noiseGen2;
    private NoiseGeneratorOctaves noiseGen3;
    public NoiseGeneratorOctaves noiseGen4;
    public NoiseGeneratorOctaves noiseGen5;
    private World endWorld;
    private double[] densities;
    private BiomeGenBase[] biomesForGeneration;
    double[] noiseData1;
    double[] noiseData2;
    double[] noiseData3;
    double[] noiseData4;
    double[] noiseData5;
    int[][] field_73203_h = new int[32][32];

    public ChunkProviderEnd(World var1, long var2) {
        this.endWorld = var1;
        this.endRNG = new Random(var2);
        this.noiseGen1 = new NoiseGeneratorOctaves(this.endRNG, 16);
        this.noiseGen2 = new NoiseGeneratorOctaves(this.endRNG, 16);
        this.noiseGen3 = new NoiseGeneratorOctaves(this.endRNG, 8);
        this.noiseGen4 = new NoiseGeneratorOctaves(this.endRNG, 10);
        this.noiseGen5 = new NoiseGeneratorOctaves(this.endRNG, 16);
    }

    public void func_147420_a(int var1, int var2, Block[] var3, BiomeGenBase[] var4) {
        byte b0 = 2;
        int i = b0 + 1;
        byte b1 = 33;
        int j = b0 + 1;
        this.densities = this.initializeNoiseField(this.densities, var1 * b0, 0, var2 * b0, i, b1, j);

        for (int k = 0; k < b0; k++) {
            for (int l = 0; l < b0; l++) {
                for (int i1 = 0; i1 < 32; i1++) {
                    double d0 = 0.25;
                    double d1 = this.densities[((k + 0) * j + l + 0) * b1 + i1 + 0];
                    double d2 = this.densities[((k + 0) * j + l + 1) * b1 + i1 + 0];
                    double d3 = this.densities[((k + 1) * j + l + 0) * b1 + i1 + 0];
                    double d4 = this.densities[((k + 1) * j + l + 1) * b1 + i1 + 0];
                    double d5 = (this.densities[((k + 0) * j + l + 0) * b1 + i1 + 1] - d1) * d0;
                    double d6 = (this.densities[((k + 0) * j + l + 1) * b1 + i1 + 1] - d2) * d0;
                    double d7 = (this.densities[((k + 1) * j + l + 0) * b1 + i1 + 1] - d3) * d0;
                    double d8 = (this.densities[((k + 1) * j + l + 1) * b1 + i1 + 1] - d4) * d0;

                    for (int j1 = 0; j1 < 4; j1++) {
                        double d9 = 0.125;
                        double d10 = d1;
                        double d11 = d2;
                        double d12 = (d3 - d1) * d9;
                        double d13 = (d4 - d2) * d9;

                        for (int k1 = 0; k1 < 8; k1++) {
                            int l1 = k1 + k * 8 << 11 | 0 + l * 8 << 7 | i1 * 4 + j1;
                            short short1 = 128;
                            double d14 = 0.125;
                            double d15 = d10;
                            double d16 = (d11 - d10) * d14;

                            for (int i2 = 0; i2 < 8; i2++) {
                                Block block = null;
                                if (d15 > 0.0) {
                                    block = Blocks.end_stone;
                                }

                                var3[l1] = block;
                                l1 += short1;
                                d15 += d16;
                            }

                            d10 += d12;
                            d11 += d13;
                        }

                        d1 += d5;
                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                    }
                }
            }
        }
    }

    public void func_147421_b(int var1, int var2, Block[] var3, BiomeGenBase[] var4) {
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                byte b0 = 1;
                int k = -1;
                Block block = Blocks.end_stone;
                Block block1 = Blocks.end_stone;

                for (int l = 127; l >= 0; l--) {
                    int i1 = (j * 16 + i) * 128 + l;
                    Block block2 = var3[i1];
                    if (block2 == null || block2.getMaterial() == Material.air) {
                        k = -1;
                    } else if (block2 == Blocks.stone) {
                        if (k == -1) {
                            if (b0 <= 0) {
                                block = null;
                                block1 = Blocks.end_stone;
                            }

                            k = b0;
                            if (l >= 0) {
                                var3[i1] = block;
                            } else {
                                var3[i1] = block1;
                            }
                        } else if (k > 0) {
                            k--;
                            var3[i1] = block1;
                        }
                    }
                }
            }
        }
    }

    @Override
    public Chunk loadChunk(int var1, int var2) {
        return this.provideChunk(var1, var2);
    }

    @Override
    public Chunk provideChunk(int var1, int var2) {
        this.endRNG.setSeed(var1 * 341873128712L + var2 * 132897987541L);
        Block[] ablock = new Block[-Short.MIN_VALUE];
        this.biomesForGeneration = this.endWorld.getWorldChunkManager().loadBlockGeneratorData(this.biomesForGeneration, var1 * 16, var2 * 16, 16, 16);
        this.func_147420_a(var1, var2, ablock, this.biomesForGeneration);
        this.func_147421_b(var1, var2, ablock, this.biomesForGeneration);
        Chunk chunk = new Chunk(this.endWorld, ablock, var1, var2);
        byte[] abyte = chunk.getBiomeArray();

        for (int i = 0; i < abyte.length; i++) {
            abyte[i] = (byte)this.biomesForGeneration[i].biomeID;
        }

        chunk.generateSkylightMap();
        return chunk;
    }

    private double[] initializeNoiseField(double[] var1, int var2, int var3, int var4, int var5, int var6, int var7) {
        if (var1 == null) {
            var1 = new double[var5 * var6 * var7];
        }

        double d0 = 684.412;
        double d1 = 684.412;
        this.noiseData4 = this.noiseGen4.generateNoiseOctaves(this.noiseData4, var2, var4, var5, var7, 1.121, 1.121, 0.5);
        this.noiseData5 = this.noiseGen5.generateNoiseOctaves(this.noiseData5, var2, var4, var5, var7, 200.0, 200.0, 0.5);
        d0 *= 2.0;
        this.noiseData1 = this.noiseGen3.generateNoiseOctaves(this.noiseData1, var2, var3, var4, var5, var6, var7, d0 / 80.0, d1 / 160.0, d0 / 80.0);
        this.noiseData2 = this.noiseGen1.generateNoiseOctaves(this.noiseData2, var2, var3, var4, var5, var6, var7, d0, d1, d0);
        this.noiseData3 = this.noiseGen2.generateNoiseOctaves(this.noiseData3, var2, var3, var4, var5, var6, var7, d0, d1, d0);
        int i = 0;
        int j = 0;

        for (int k = 0; k < var5; k++) {
            for (int l = 0; l < var7; l++) {
                double d2 = (this.noiseData4[j] + 256.0) / 512.0;
                if (d2 > 1.0) {
                    d2 = 1.0;
                }

                double d3 = this.noiseData5[j] / 8000.0;
                if (d3 < 0.0) {
                    d3 = -d3 * 0.3;
                }

                d3 = d3 * 3.0 - 2.0;
                float f = (k + var2 - 0) / 1.0F;
                float f1 = (l + var4 - 0) / 1.0F;
                float f2 = 100.0F - MathHelper.sqrt_float(f * f + f1 * f1) * 8.0F;
                if (f2 > 80.0F) {
                    f2 = 80.0F;
                }

                if (f2 < -100.0F) {
                    f2 = -100.0F;
                }

                if (d3 > 1.0) {
                    d3 = 1.0;
                }

                d3 /= 8.0;
                d3 = 0.0;
                if (d2 < 0.0) {
                    d2 = 0.0;
                }

                d2 += 0.5;
                d3 = d3 * var6 / 16.0;
                j++;
                double d4 = var6 / 2.0;

                for (int i1 = 0; i1 < var6; i1++) {
                    double d5 = 0.0;
                    double d6 = (i1 - d4) * 8.0 / d2;
                    if (d6 < 0.0) {
                        d6 *= -1.0;
                    }

                    double d7 = this.noiseData2[i] / 512.0;
                    double d8 = this.noiseData3[i] / 512.0;
                    double d9 = (this.noiseData1[i] / 10.0 + 1.0) / 2.0;
                    if (d9 < 0.0) {
                        d5 = d7;
                    } else if (d9 > 1.0) {
                        d5 = d8;
                    } else {
                        d5 = d7 + (d8 - d7) * d9;
                    }

                    d5 -= 8.0;
                    d5 += f2;
                    byte b0 = 2;
                    if (i1 > var6 / 2 - b0) {
                        double d10 = (i1 - (var6 / 2 - b0)) / 64.0F;
                        if (d10 < 0.0) {
                            d10 = 0.0;
                        }

                        if (d10 > 1.0) {
                            d10 = 1.0;
                        }

                        d5 = d5 * (1.0 - d10) + -3000.0 * d10;
                    }

                    b0 = 8;
                    if (i1 < b0) {
                        double d11 = (b0 - i1) / (b0 - 1.0F);
                        d5 = d5 * (1.0 - d11) + -30.0 * d11;
                    }

                    var1[i] = d5;
                    i++;
                }
            }
        }

        return var1;
    }

    @Override
    public boolean chunkExists(int var1, int var2) {
        return true;
    }

    @Override
    public void populate(IChunkProvider var1, int var2, int var3) {
        BlockFalling.fallInstantly = true;
        int i = var2 * 16;
        int j = var3 * 16;
        BiomeGenBase biomegenbase = this.endWorld.getBiomeGenForCoords(i + 16, j + 16);
        biomegenbase.decorate(this.endWorld, this.endWorld.rand, i, j);
        BlockFalling.fallInstantly = false;
    }

    @Override
    public boolean saveChunks(boolean var1, IProgressUpdate var2) {
        return true;
    }

    @Override
    public void saveExtraData() {
    }

    @Override
    public boolean unloadQueuedChunks() {
        return false;
    }

    @Override
    public boolean canSave() {
        return true;
    }

    @Override
    public String makeString() {
        return "RandomLevelSource";
    }

    @Override
    public List getPossibleCreatures(EnumCreatureType var1, int var2, int var3, int var4) {
        BiomeGenBase biomegenbase = this.endWorld.getBiomeGenForCoords(var2, var4);
        return biomegenbase.getSpawnableList(var1);
    }

    @Override
    public ChunkPosition findClosestStructure(World var1, String var2, int var3, int var4, int var5) {
        return null;
    }

    @Override
    public int getLoadedChunkCount() {
        return 0;
    }

    @Override
    public void recreateStructures(int var1, int var2) {
    }
}
