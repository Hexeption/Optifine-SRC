package net.minecraft.world;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.util.WeightedRandom;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import optifine.Reflector;

public final class SpawnerAnimals {
    private HashMap eligibleChunksForSpawning = new HashMap();
    private static final String __OBFID = "CL_00000152";
    private Map mapSampleEntitiesByClass = new HashMap();
    private int lastPlayerChunkX = Integer.MAX_VALUE;
    private int lastPlayerChunkZ = Integer.MAX_VALUE;

    protected static ChunkPosition func_151350_a(World p_151350_0_, int p_151350_1_, int p_151350_2_) {
        Chunk chunk = p_151350_0_.getChunkFromChunkCoords(p_151350_1_, p_151350_2_);
        int i = p_151350_1_ * 16 + p_151350_0_.rand.nextInt(16);
        int j = p_151350_2_ * 16 + p_151350_0_.rand.nextInt(16);
        int k = p_151350_0_.rand.nextInt(chunk == null ? p_151350_0_.getActualHeight() : chunk.getTopFilledSegment() + 16 - 1);
        return new ChunkPosition(i, k, j);
    }

    public int findChunksForSpawning(WorldServer par1WorldServer, boolean par2, boolean par3, boolean par4) {
        if (!par2 && !par3) {
            return 0;
        }

        EntityPlayer entityplayer = null;
        if (par1WorldServer.playerEntities.size() == 1) {
            entityplayer = (EntityPlayer)par1WorldServer.playerEntities.get(0);
        }

        if (entityplayer == null
            || entityplayer.chunkCoordX != this.lastPlayerChunkX
            || entityplayer.chunkCoordZ != this.lastPlayerChunkZ
            || this.eligibleChunksForSpawning.size() <= 0) {
            this.eligibleChunksForSpawning.clear();

            for (int i = 0; i < par1WorldServer.playerEntities.size(); i++) {
                EntityPlayer entityplayer1 = (EntityPlayer)par1WorldServer.playerEntities.get(i);
                int k = MathHelper.floor_double(entityplayer1.posX / 16.0);
                int j = MathHelper.floor_double(entityplayer1.posZ / 16.0);
                byte b0 = 8;

                for (int l = -b0; l <= b0; l++) {
                    for (int i1 = -b0; i1 <= b0; i1++) {
                        boolean flag = l == -b0 || l == b0 || i1 == -b0 || i1 == b0;
                        ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(l + k, i1 + j);
                        if (!flag) {
                            this.eligibleChunksForSpawning.put(chunkcoordintpair, false);
                        } else if (!this.eligibleChunksForSpawning.containsKey(chunkcoordintpair)) {
                            this.eligibleChunksForSpawning.put(chunkcoordintpair, true);
                        }
                    }
                }
            }

            if (entityplayer != null) {
                this.lastPlayerChunkX = entityplayer.chunkCoordX;
                this.lastPlayerChunkZ = entityplayer.chunkCoordZ;
            }
        }

        int k3 = 0;
        ChunkCoordinates chunkcoordinates = par1WorldServer.getSpawnPoint();

        for (EnumCreatureType enumcreaturetype : EnumCreatureType.values()) {
            int l3 = 0;
            if (Reflector.ForgeWorld_countEntities.exists()) {
                l3 = Reflector.callInt(par1WorldServer, Reflector.ForgeWorld_countEntities, enumcreaturetype, true);
            } else {
                l3 = par1WorldServer.countEntities(enumcreaturetype.getCreatureClass());
            }

            if ((!enumcreaturetype.getPeacefulCreature() || par3)
                && (enumcreaturetype.getPeacefulCreature() || par2)
                && (!enumcreaturetype.getAnimal() || par4)
                && l3 <= enumcreaturetype.getMaxNumberOfCreature() * this.eligibleChunksForSpawning.size() / 256) {
                label165:
                for (ChunkCoordIntPair chunkcoordintpair1 : (Iterable<ChunkCoordIntPair>) (Iterable) this.eligibleChunksForSpawning.keySet()) {
                    if (!(Boolean)this.eligibleChunksForSpawning.get(chunkcoordintpair1)) {
                        Chunk chunk = par1WorldServer.getChunkFromChunkCoords(chunkcoordintpair1.chunkXPos, chunkcoordintpair1.chunkZPos);
                        int j1 = chunkcoordintpair1.chunkXPos * 16 + par1WorldServer.rand.nextInt(16);
                        int k1 = chunkcoordintpair1.chunkZPos * 16 + par1WorldServer.rand.nextInt(16);
                        int l1 = par1WorldServer.rand.nextInt(chunk == null ? par1WorldServer.getActualHeight() : chunk.getTopFilledSegment() + 16 - 1);
                        if (!par1WorldServer.getBlock(j1, l1, k1).isNormalCube()
                            && par1WorldServer.getBlock(j1, l1, k1).getMaterial() == enumcreaturetype.getCreatureMaterial()) {
                            int i2 = 0;

                            for (int j2 = 0; j2 < 3; j2++) {
                                int k2 = j1;
                                int l2 = l1;
                                int i3 = k1;
                                byte b1 = 6;
                                BiomeGenBase.SpawnListEntry biomegenbase$spawnlistentry = null;
                                IEntityLivingData ientitylivingdata = null;

                                for (int j3 = 0; j3 < 4; j3++) {
                                    k2 += par1WorldServer.rand.nextInt(b1) - par1WorldServer.rand.nextInt(b1);
                                    l2 += par1WorldServer.rand.nextInt(1) - par1WorldServer.rand.nextInt(1);
                                    i3 += par1WorldServer.rand.nextInt(b1) - par1WorldServer.rand.nextInt(b1);
                                    if (canCreatureTypeSpawnAtLocation(enumcreaturetype, par1WorldServer, k2, l2, i3)) {
                                        float f = k2 + 0.5F;
                                        float f1 = l2;
                                        float f2 = i3 + 0.5F;
                                        if (par1WorldServer.getClosestPlayer(f, f1, f2, 24.0) == null) {
                                            float f3 = f - chunkcoordinates.posX;
                                            float f4 = f1 - chunkcoordinates.posY;
                                            float f5 = f2 - chunkcoordinates.posZ;
                                            float f6 = f3 * f3 + f4 * f4 + f5 * f5;
                                            if (f6 >= 576.0F) {
                                                if (biomegenbase$spawnlistentry == null) {
                                                    biomegenbase$spawnlistentry = par1WorldServer.spawnRandomCreature(enumcreaturetype, k2, l2, i3);
                                                    if (biomegenbase$spawnlistentry == null) {
                                                        break;
                                                    }
                                                }

                                                EntityLiving entityliving;
                                                try {
                                                    entityliving = (EntityLiving)this.mapSampleEntitiesByClass.get(biomegenbase$spawnlistentry.entityClass);
                                                    if (entityliving == null) {
                                                        entityliving = (EntityLiving)biomegenbase$spawnlistentry.entityClass
                                                            .getConstructor(World.class)
                                                            .newInstance(par1WorldServer);
                                                        this.mapSampleEntitiesByClass.put(biomegenbase$spawnlistentry.entityClass, entityliving);
                                                    }
                                                } catch (Exception exception) {
                                                    exception.printStackTrace();
                                                    return k3;
                                                }

                                                entityliving.setLocationAndAngles(f, f1, f2, par1WorldServer.rand.nextFloat() * 360.0F, 0.0F);
                                                boolean flag1 = false;
                                                if (!Reflector.ForgeEventFactory_canEntitySpawn.exists()) {
                                                    flag1 = entityliving.getCanSpawnHere();
                                                } else {
                                                    Object object = Reflector.call(
                                                        Reflector.ForgeEventFactory_canEntitySpawn, entityliving, par1WorldServer, f, f1, f2
                                                    );
                                                    Object object1 = Reflector.getFieldValue(Reflector.Event_Result_ALLOW);
                                                    Object object2 = Reflector.getFieldValue(Reflector.Event_Result_DEFAULT);
                                                    flag1 = object == object1 || object == object2 && entityliving.getCanSpawnHere();
                                                }

                                                if (flag1) {
                                                    this.mapSampleEntitiesByClass.put(biomegenbase$spawnlistentry.entityClass, null);
                                                    i2++;
                                                    par1WorldServer.spawnEntityInWorld(entityliving);
                                                    ientitylivingdata = entityliving.onSpawnWithEgg(ientitylivingdata);
                                                    if (i2 >= entityliving.getMaxSpawnedInChunk()) {
                                                        continue label165;
                                                    }
                                                }

                                                k3 += i2;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return k3;
    }

    public static boolean canCreatureTypeSpawnAtLocation(EnumCreatureType par0EnumCreatureType, World par1World, int par2, int par3, int par4) {
        if (par0EnumCreatureType.getCreatureMaterial() == Material.water) {
            return par1World.getBlock(par2, par3, par4).getMaterial().isLiquid()
                && par1World.getBlock(par2, par3 - 1, par4).getMaterial().isLiquid()
                && !par1World.getBlock(par2, par3 + 1, par4).isNormalCube();
        }

        if (!World.doesBlockHaveSolidTopSurface(par1World, par2, par3 - 1, par4)) {
            return false;
        }

        Block block = par1World.getBlock(par2, par3 - 1, par4);
        return Reflector.ForgeBlock_canCreatureSpawn.exists()
                && !Reflector.callBoolean(block, Reflector.ForgeBlock_canCreatureSpawn, par0EnumCreatureType, par1World, par2, par3, par4)
            ? false
            : block != Blocks.bedrock
                && !par1World.getBlock(par2, par3, par4).isNormalCube()
                && !par1World.getBlock(par2, par3, par4).getMaterial().isLiquid()
                && !par1World.getBlock(par2, par3 + 1, par4).isNormalCube();
    }

    public static void performWorldGenSpawning(World par0World, BiomeGenBase par1BiomeGenBase, int par2, int par3, int par4, int par5, Random par6Random) {
        List list = par1BiomeGenBase.getSpawnableList(EnumCreatureType.creature);
        if (!list.isEmpty()) {
            while (par6Random.nextFloat() < par1BiomeGenBase.getSpawningChance()) {
                BiomeGenBase.SpawnListEntry biomegenbase$spawnlistentry = (BiomeGenBase.SpawnListEntry)WeightedRandom.getRandomItem(par0World.rand, list);
                IEntityLivingData ientitylivingdata = null;
                int i = biomegenbase$spawnlistentry.minGroupCount
                    + par6Random.nextInt(1 + biomegenbase$spawnlistentry.maxGroupCount - biomegenbase$spawnlistentry.minGroupCount);
                int j = par2 + par6Random.nextInt(par4);
                int k = par3 + par6Random.nextInt(par5);
                int l = j;
                int i1 = k;

                for (int j1 = 0; j1 < i; j1++) {
                    boolean flag = false;

                    for (int k1 = 0; !flag && k1 < 4; k1++) {
                        int l1 = par0World.getTopSolidOrLiquidBlock(j, k);
                        if (canCreatureTypeSpawnAtLocation(EnumCreatureType.creature, par0World, j, l1, k)) {
                            float f = j + 0.5F;
                            float f1 = l1;
                            float f2 = k + 0.5F;

                            EntityLiving entityliving;
                            try {
                                entityliving = (EntityLiving)biomegenbase$spawnlistentry.entityClass.getConstructor(World.class).newInstance(par0World);
                            } catch (Exception exception) {
                                exception.printStackTrace();
                                continue;
                            }

                            entityliving.setLocationAndAngles(f, f1, f2, par6Random.nextFloat() * 360.0F, 0.0F);
                            par0World.spawnEntityInWorld(entityliving);
                            ientitylivingdata = entityliving.onSpawnWithEgg(ientitylivingdata);
                            flag = true;
                        }

                        j += par6Random.nextInt(5) - par6Random.nextInt(5);

                        for (k += par6Random.nextInt(5) - par6Random.nextInt(5);
                            j < par2 || j >= par2 + par4 || k < par3 || k >= par3 + par4;
                            k = i1 + par6Random.nextInt(5) - par6Random.nextInt(5)
                        ) {
                            j = l + par6Random.nextInt(5) - par6Random.nextInt(5);
                        }
                    }
                }
            }
        }
    }
}
