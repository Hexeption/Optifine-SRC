package net.minecraft.world;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHopper;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.material.Material;
import net.minecraft.command.IEntitySelector;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathFinder;
import net.minecraft.profiler.Profiler;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.Direction;
import net.minecraft.util.Facing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ReportedException;
import net.minecraft.util.Vec3;
import net.minecraft.village.VillageCollection;
import net.minecraft.village.VillageSiege;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldInfo;

public abstract class World implements IBlockAccess {
    public boolean scheduledUpdatesAreImmediate;
    public List loadedEntityList = new ArrayList();
    protected List unloadedEntityList = new ArrayList();
    public List loadedTileEntityList = new ArrayList();
    private List addedTileEntityList = new ArrayList();
    private List tileEntitiesToBeRemoved = new ArrayList();
    public List playerEntities = new ArrayList();
    public List weatherEffects = new ArrayList();
    private long cloudColour = 16777215L;
    public int skylightSubtracted;
    protected int updateLCG = new Random().nextInt();
    protected final int DIST_HASH_MAGIC = 1013904223;
    protected float prevRainingStrength;
    protected float rainingStrength;
    protected float prevThunderingStrength;
    protected float thunderingStrength;
    public int lastLightningBolt;
    public EnumDifficulty difficultySetting;
    public Random rand = new Random();
    public final WorldProvider provider;
    protected List worldAccesses = new ArrayList();
    protected IChunkProvider chunkProvider;
    protected final ISaveHandler saveHandler;
    protected WorldInfo worldInfo;
    public boolean findingSpawnPoint;
    public MapStorage mapStorage;
    public final VillageCollection villageCollectionObj;
    protected final VillageSiege villageSiegeObj = new VillageSiege(this);
    public final Profiler theProfiler;
    private final Calendar theCalendar = Calendar.getInstance();
    protected Scoreboard worldScoreboard = new Scoreboard();
    public boolean isRemote;
    protected Set activeChunkSet = new HashSet();
    private int ambientTickCountdown = this.rand.nextInt(12000);
    protected boolean spawnHostileMobs = true;
    protected boolean spawnPeacefulMobs = true;
    private ArrayList collidingBoundingBoxes = new ArrayList();
    private boolean processingLoadedTiles;
    int[] lightUpdateBlockList = new int[-Short.MIN_VALUE];

    @Override
    public BiomeGenBase getBiomeGenForCoords(final int var1, final int var2) {
        if (this.blockExists(var1, 0, var2)) {
            Chunk chunk = this.getChunkFromBlockCoords(var1, var2);

            try {
                return chunk.getBiomeGenForWorldCoords(var1 & 15, var2 & 15, this.provider.worldChunkMgr);
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Getting biome");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Coordinates of biome request");
                crashreportcategory.addCrashSectionCallable("Location", new Callable() {
                    public String call() {
                        return CrashReportCategory.getLocationInfo(var1, 0, var2);
                    }
                });
                throw new ReportedException(crashreport);
            }
        } else {
            return this.provider.worldChunkMgr.getBiomeGenAt(var1, var2);
        }
    }

    public WorldChunkManager getWorldChunkManager() {
        return this.provider.worldChunkMgr;
    }

    public World(ISaveHandler var1, String var2, WorldProvider var3, WorldSettings var4, Profiler var5) {
        this.saveHandler = var1;
        this.theProfiler = var5;
        this.worldInfo = new WorldInfo(var4, var2);
        this.provider = var3;
        this.mapStorage = new MapStorage(var1);
        VillageCollection villagecollection = (VillageCollection)this.mapStorage.loadData(VillageCollection.class, "villages");
        if (villagecollection == null) {
            this.villageCollectionObj = new VillageCollection(this);
            this.mapStorage.setData("villages", this.villageCollectionObj);
        } else {
            this.villageCollectionObj = villagecollection;
            this.villageCollectionObj.func_82566_a(this);
        }

        var3.registerWorld(this);
        this.chunkProvider = this.createChunkProvider();
        this.calculateInitialSkylight();
        this.calculateInitialWeather();
    }

    public World(ISaveHandler var1, String var2, WorldSettings var3, WorldProvider var4, Profiler var5) {
        this.saveHandler = var1;
        this.theProfiler = var5;
        this.mapStorage = new MapStorage(var1);
        this.worldInfo = var1.loadWorldInfo();
        if (var4 != null) {
            this.provider = var4;
        } else if (this.worldInfo != null && this.worldInfo.getDimension() != 0) {
            this.provider = WorldProvider.getProviderForDimension(this.worldInfo.getDimension());
        } else {
            this.provider = WorldProvider.getProviderForDimension(0);
        }

        if (this.worldInfo == null) {
            this.worldInfo = new WorldInfo(var3, var2);
        } else {
            this.worldInfo.setWorldName(var2);
        }

        this.provider.registerWorld(this);
        this.chunkProvider = this.createChunkProvider();
        if (!this.worldInfo.isInitialized()) {
            try {
                this.initialize(var3);
            } catch (Throwable throwable1) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable1, "Exception initializing level");

                try {
                    this.addWorldInfoToCrashReport(crashreport);
                } catch (Throwable throwable) {
                }

                throw new ReportedException(crashreport);
            }

            this.worldInfo.setServerInitialized(true);
        }

        VillageCollection villagecollection = (VillageCollection)this.mapStorage.loadData(VillageCollection.class, "villages");
        if (villagecollection == null) {
            this.villageCollectionObj = new VillageCollection(this);
            this.mapStorage.setData("villages", this.villageCollectionObj);
        } else {
            this.villageCollectionObj = villagecollection;
            this.villageCollectionObj.func_82566_a(this);
        }

        this.calculateInitialSkylight();
        this.calculateInitialWeather();
    }

    protected abstract IChunkProvider createChunkProvider();

    protected void initialize(WorldSettings var1) {
        this.worldInfo.setServerInitialized(true);
    }

    public void setSpawnLocation() {
        this.setSpawnLocation(8, 64, 8);
    }

    public Block getTopBlock(int var1, int var2) {
        int i = 63;

        while (!this.isAirBlock(var1, i + 1, var2)) {
            i++;
        }

        return this.getBlock(var1, i, var2);
    }

    @Override
    public Block getBlock(int var1, int var2, int var3) {
        if (var1 >= -30000000 && var3 >= -30000000 && var1 < 30000000 && var3 < 30000000 && var2 >= 0 && var2 < 256) {
            Chunk chunk = null;

            try {
                chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
                return chunk.getBlock(var1 & 15, var2, var3 & 15);
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Exception getting block type in world");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Requested block coordinates");
                crashreportcategory.addCrashSection("Found chunk", chunk == null);
                crashreportcategory.addCrashSection("Location", CrashReportCategory.getLocationInfo(var1, var2, var3));
                throw new ReportedException(crashreport);
            }
        } else {
            return Blocks.air;
        }
    }

    @Override
    public boolean isAirBlock(int var1, int var2, int var3) {
        return this.getBlock(var1, var2, var3).getMaterial() == Material.air;
    }

    public boolean blockExists(int var1, int var2, int var3) {
        return var2 >= 0 && var2 < 256 ? this.chunkExists(var1 >> 4, var3 >> 4) : false;
    }

    public boolean doChunksNearChunkExist(int var1, int var2, int var3, int var4) {
        return this.checkChunksExist(var1 - var4, var2 - var4, var3 - var4, var1 + var4, var2 + var4, var3 + var4);
    }

    public boolean checkChunksExist(int var1, int var2, int var3, int var4, int var5, int var6) {
        if (var5 >= 0 && var2 < 256) {
            var1 >>= 4;
            var3 >>= 4;
            var4 >>= 4;
            var6 >>= 4;

            for (int i = var1; i <= var4; i++) {
                for (int j = var3; j <= var6; j++) {
                    if (!this.chunkExists(i, j)) {
                        return false;
                    }
                }
            }

            return true;
        } else {
            return false;
        }
    }

    protected boolean chunkExists(int var1, int var2) {
        return this.chunkProvider.chunkExists(var1, var2);
    }

    public Chunk getChunkFromBlockCoords(int var1, int var2) {
        return this.getChunkFromChunkCoords(var1 >> 4, var2 >> 4);
    }

    public Chunk getChunkFromChunkCoords(int var1, int var2) {
        return this.chunkProvider.provideChunk(var1, var2);
    }

    public boolean setBlock(int var1, int var2, int var3, Block var4, int var5, int var6) {
        if (var1 < -30000000 || var3 < -30000000 || var1 >= 30000000 || var3 >= 30000000) {
            return false;
        }

        if (var2 < 0) {
            return false;
        }

        if (var2 >= 256) {
            return false;
        }

        Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
        Block block = null;
        if ((var6 & 1) != 0) {
            block = chunk.getBlock(var1 & 15, var2, var3 & 15);
        }

        boolean flag = chunk.setBlockIDWithMetadata(var1 & 15, var2, var3 & 15, var4, var5);
        this.theProfiler.startSection("checkLight");
        this.updateAllLightTypes(var1, var2, var3);
        this.theProfiler.endSection();
        if (flag) {
            if ((var6 & 2) != 0 && (!this.isRemote || (var6 & 4) == 0) && chunk.func_150802_k()) {
                this.markBlockForUpdate(var1, var2, var3);
            }

            if (!this.isRemote && (var6 & 1) != 0) {
                this.notifyBlockChange(var1, var2, var3, block);
                if (var4.hasComparatorInputOverride()) {
                    this.updateNeighborsAboutBlockChange(var1, var2, var3, var4);
                }
            }
        }

        return flag;
    }

    @Override
    public int getBlockMetadata(int var1, int var2, int var3) {
        if (var1 < -30000000 || var3 < -30000000 || var1 >= 30000000 || var3 >= 30000000) {
            return 0;
        }

        if (var2 < 0) {
            return 0;
        }

        if (var2 >= 256) {
            return 0;
        }

        Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
        var1 &= 15;
        var3 &= 15;
        return chunk.getBlockMetadata(var1, var2, var3);
    }

    public boolean setBlockMetadataWithNotify(int var1, int var2, int var3, int var4, int var5) {
        if (var1 < -30000000 || var3 < -30000000 || var1 >= 30000000 || var3 >= 30000000) {
            return false;
        }

        if (var2 < 0) {
            return false;
        }

        if (var2 >= 256) {
            return false;
        }

        Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
        int i = var1 & 15;
        int j = var3 & 15;
        boolean flag = chunk.setBlockMetadata(i, var2, j, var4);
        if (flag) {
            Block block = chunk.getBlock(i, var2, j);
            if ((var5 & 2) != 0 && (!this.isRemote || (var5 & 4) == 0) && chunk.func_150802_k()) {
                this.markBlockForUpdate(var1, var2, var3);
            }

            if (!this.isRemote && (var5 & 1) != 0) {
                this.notifyBlockChange(var1, var2, var3, block);
                if (block.hasComparatorInputOverride()) {
                    this.updateNeighborsAboutBlockChange(var1, var2, var3, block);
                }
            }
        }

        return flag;
    }

    public boolean setBlockToAir(int var1, int var2, int var3) {
        return this.setBlock(var1, var2, var3, Blocks.air, 0, 3);
    }

    public boolean breakBlock(int var1, int var2, int var3, boolean var4) {
        Block block = this.getBlock(var1, var2, var3);
        if (block.getMaterial() == Material.air) {
            return false;
        }

        int i = this.getBlockMetadata(var1, var2, var3);
        this.playAuxSFX(2001, var1, var2, var3, Block.getIdFromBlock(block) + (i << 12));
        if (var4) {
            block.dropBlockAsItem(this, var1, var2, var3, i, 0);
        }

        return this.setBlock(var1, var2, var3, Blocks.air, 0, 3);
    }

    public boolean setBlock(int var1, int var2, int var3, Block var4) {
        return this.setBlock(var1, var2, var3, var4, 0, 3);
    }

    public void markBlockForUpdate(int var1, int var2, int var3) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).markBlockForUpdate(var1, var2, var3);
        }
    }

    public void notifyBlockChange(int var1, int var2, int var3, Block var4) {
        this.notifyBlocksOfNeighborChange(var1, var2, var3, var4);
    }

    public void markBlocksDirtyVertical(int var1, int var2, int var3, int var4) {
        if (var3 > var4) {
            int i = var4;
            var4 = var3;
            var3 = i;
        }

        if (!this.provider.hasNoSky) {
            for (int j = var3; j <= var4; j++) {
                this.updateLightByType(EnumSkyBlock.Sky, var1, j, var2);
            }
        }

        this.markBlockRangeForRenderUpdate(var1, var3, var2, var1, var4, var2);
    }

    public void markBlockRangeForRenderUpdate(int var1, int var2, int var3, int var4, int var5, int var6) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).markBlockRangeForRenderUpdate(var1, var2, var3, var4, var5, var6);
        }
    }

    public void notifyBlocksOfNeighborChange(int var1, int var2, int var3, Block var4) {
        this.notifyBlockOfNeighborChange(var1 - 1, var2, var3, var4);
        this.notifyBlockOfNeighborChange(var1 + 1, var2, var3, var4);
        this.notifyBlockOfNeighborChange(var1, var2 - 1, var3, var4);
        this.notifyBlockOfNeighborChange(var1, var2 + 1, var3, var4);
        this.notifyBlockOfNeighborChange(var1, var2, var3 - 1, var4);
        this.notifyBlockOfNeighborChange(var1, var2, var3 + 1, var4);
    }

    public void notifyBlocksOfNeighborChange(int var1, int var2, int var3, Block var4, int var5) {
        if (var5 != 4) {
            this.notifyBlockOfNeighborChange(var1 - 1, var2, var3, var4);
        }

        if (var5 != 5) {
            this.notifyBlockOfNeighborChange(var1 + 1, var2, var3, var4);
        }

        if (var5 != 0) {
            this.notifyBlockOfNeighborChange(var1, var2 - 1, var3, var4);
        }

        if (var5 != 1) {
            this.notifyBlockOfNeighborChange(var1, var2 + 1, var3, var4);
        }

        if (var5 != 2) {
            this.notifyBlockOfNeighborChange(var1, var2, var3 - 1, var4);
        }

        if (var5 != 3) {
            this.notifyBlockOfNeighborChange(var1, var2, var3 + 1, var4);
        }
    }

    public void notifyBlockOfNeighborChange(int var1, int var2, int var3, final Block var4) {
        if (!this.isRemote) {
            Block block = this.getBlock(var1, var2, var3);

            try {
                block.onNeighborBlockChange(this, var1, var2, var3, var4);
            } catch (Throwable throwable1) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable1, "Exception while updating neighbours");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being updated");

                int i;
                try {
                    i = this.getBlockMetadata(var1, var2, var3);
                } catch (Throwable throwable) {
                    i = -1;
                }

                crashreportcategory.addCrashSectionCallable(
                    "Source block type",
                    new Callable() {
                        public String call() {
                            try {
                                return String.format(
                                    "ID #%d (%s // %s)", Block.getIdFromBlock(var4), var4.getUnlocalizedName(), var4.getClass().getCanonicalName()
                                );
                            } catch (Throwable throwable2) {
                                return "ID #" + Block.getIdFromBlock(var4);
                            }
                        }
                    }
                );
                CrashReportCategory.addBlockInfo(crashreportcategory, var1, var2, var3, block, i);
                throw new ReportedException(crashreport);
            }
        }
    }

    public boolean isBlockTickScheduledThisTick(int var1, int var2, int var3, Block var4) {
        return false;
    }

    public boolean canBlockSeeTheSky(int var1, int var2, int var3) {
        return this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4).canBlockSeeTheSky(var1 & 15, var2, var3 & 15);
    }

    public int getFullBlockLightValue(int var1, int var2, int var3) {
        if (var2 < 0) {
            return 0;
        }

        if (var2 >= 256) {
            var2 = 255;
        }

        return this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4).getBlockLightValue(var1 & 15, var2, var3 & 15, 0);
    }

    public int getBlockLightValue(int var1, int var2, int var3) {
        return this.getBlockLightValue_do(var1, var2, var3, true);
    }

    public int getBlockLightValue_do(int var1, int var2, int var3, boolean var4) {
        if (var1 < -30000000 || var3 < -30000000 || var1 >= 30000000 || var3 >= 30000000) {
            return 15;
        }

        if (var4 && this.getBlock(var1, var2, var3).getUseNeighborBrightness()) {
            int i1 = this.getBlockLightValue_do(var1, var2 + 1, var3, false);
            int i = this.getBlockLightValue_do(var1 + 1, var2, var3, false);
            int j = this.getBlockLightValue_do(var1 - 1, var2, var3, false);
            int k = this.getBlockLightValue_do(var1, var2, var3 + 1, false);
            int l = this.getBlockLightValue_do(var1, var2, var3 - 1, false);
            if (i > i1) {
                i1 = i;
            }

            if (j > i1) {
                i1 = j;
            }

            if (k > i1) {
                i1 = k;
            }

            if (l > i1) {
                i1 = l;
            }

            return i1;
        } else {
            if (var2 < 0) {
                return 0;
            }

            if (var2 >= 256) {
                var2 = 255;
            }

            Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
            var1 &= 15;
            var3 &= 15;
            return chunk.getBlockLightValue(var1, var2, var3, this.skylightSubtracted);
        }
    }

    public int getHeightValue(int var1, int var2) {
        if (var1 >= -30000000 && var2 >= -30000000 && var1 < 30000000 && var2 < 30000000) {
            if (!this.chunkExists(var1 >> 4, var2 >> 4)) {
                return 0;
            }

            Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var2 >> 4);
            return chunk.getHeightValue(var1 & 15, var2 & 15);
        } else {
            return 64;
        }
    }

    public int getChunkHeightMapMinimum(int var1, int var2) {
        if (var1 >= -30000000 && var2 >= -30000000 && var1 < 30000000 && var2 < 30000000) {
            if (!this.chunkExists(var1 >> 4, var2 >> 4)) {
                return 0;
            }

            Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var2 >> 4);
            return chunk.heightMapMinimum;
        } else {
            return 64;
        }
    }

    public int getSkyBlockTypeBrightness(EnumSkyBlock var1, int var2, int var3, int var4) {
        if (this.provider.hasNoSky && var1 == EnumSkyBlock.Sky) {
            return 0;
        }

        if (var3 < 0) {
            var3 = 0;
        }

        if (var3 >= 256) {
            return var1.defaultLightValue;
        }

        if (var2 >= -30000000 && var4 >= -30000000 && var2 < 30000000 && var4 < 30000000) {
            int i = var2 >> 4;
            int j = var4 >> 4;
            if (!this.chunkExists(i, j)) {
                return var1.defaultLightValue;
            }

            if (this.getBlock(var2, var3, var4).getUseNeighborBrightness()) {
                int k1 = this.getSavedLightValue(var1, var2, var3 + 1, var4);
                int k = this.getSavedLightValue(var1, var2 + 1, var3, var4);
                int l = this.getSavedLightValue(var1, var2 - 1, var3, var4);
                int i1 = this.getSavedLightValue(var1, var2, var3, var4 + 1);
                int j1 = this.getSavedLightValue(var1, var2, var3, var4 - 1);
                if (k > k1) {
                    k1 = k;
                }

                if (l > k1) {
                    k1 = l;
                }

                if (i1 > k1) {
                    k1 = i1;
                }

                if (j1 > k1) {
                    k1 = j1;
                }

                return k1;
            } else {
                Chunk chunk = this.getChunkFromChunkCoords(i, j);
                return chunk.getSavedLightValue(var1, var2 & 15, var3, var4 & 15);
            }
        } else {
            return var1.defaultLightValue;
        }
    }

    public int getSavedLightValue(EnumSkyBlock var1, int var2, int var3, int var4) {
        if (var3 < 0) {
            var3 = 0;
        }

        if (var3 >= 256) {
            var3 = 255;
        }

        if (var2 >= -30000000 && var4 >= -30000000 && var2 < 30000000 && var4 < 30000000) {
            int i = var2 >> 4;
            int j = var4 >> 4;
            if (!this.chunkExists(i, j)) {
                return var1.defaultLightValue;
            }

            Chunk chunk = this.getChunkFromChunkCoords(i, j);
            return chunk.getSavedLightValue(var1, var2 & 15, var3, var4 & 15);
        } else {
            return var1.defaultLightValue;
        }
    }

    public void setLightValue(EnumSkyBlock var1, int var2, int var3, int var4, int var5) {
        if (var2 >= -30000000 && var4 >= -30000000 && var2 < 30000000 && var4 < 30000000) {
            if (var3 >= 0) {
                if (var3 < 256) {
                    if (this.chunkExists(var2 >> 4, var4 >> 4)) {
                        Chunk chunk = this.getChunkFromChunkCoords(var2 >> 4, var4 >> 4);
                        chunk.setLightValue(var1, var2 & 15, var3, var4 & 15, var5);

                        for (int i = 0; i < this.worldAccesses.size(); i++) {
                            ((IWorldAccess)this.worldAccesses.get(i)).markBlockForRenderUpdate(var2, var3, var4);
                        }
                    }
                }
            }
        }
    }

    public void markBlockForRenderUpdate(int var1, int var2, int var3) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).markBlockForRenderUpdate(var1, var2, var3);
        }
    }

    @Override
    public int getLightBrightnessForSkyBlocks(int var1, int var2, int var3, int var4) {
        int i = this.getSkyBlockTypeBrightness(EnumSkyBlock.Sky, var1, var2, var3);
        int j = this.getSkyBlockTypeBrightness(EnumSkyBlock.Block, var1, var2, var3);
        if (j < var4) {
            j = var4;
        }

        return i << 20 | j << 4;
    }

    public float getLightBrightness(int var1, int var2, int var3) {
        return this.provider.lightBrightnessTable[this.getBlockLightValue(var1, var2, var3)];
    }

    public boolean isDaytime() {
        return this.skylightSubtracted < 4;
    }

    public MovingObjectPosition rayTraceBlocks(Vec3 var1, Vec3 var2) {
        return this.rayTraceBlocks(var1, var2, false, false, false);
    }

    public MovingObjectPosition rayTraceBlocks(Vec3 var1, Vec3 var2, boolean var3) {
        return this.rayTraceBlocks(var1, var2, var3, false, false);
    }

    public MovingObjectPosition rayTraceBlocks(Vec3 var1, Vec3 var2, boolean var3, boolean var4, boolean var5) {
        if (Double.isNaN(var1.xCoord) || Double.isNaN(var1.yCoord) || Double.isNaN(var1.zCoord)) {
            return null;
        }

        if (!Double.isNaN(var2.xCoord) && !Double.isNaN(var2.yCoord) && !Double.isNaN(var2.zCoord)) {
            int i = MathHelper.floor_double(var2.xCoord);
            int j = MathHelper.floor_double(var2.yCoord);
            int k = MathHelper.floor_double(var2.zCoord);
            int l = MathHelper.floor_double(var1.xCoord);
            int i1 = MathHelper.floor_double(var1.yCoord);
            int j1 = MathHelper.floor_double(var1.zCoord);
            Block block = this.getBlock(l, i1, j1);
            int k1 = this.getBlockMetadata(l, i1, j1);
            if ((!var4 || block.getCollisionBoundingBoxFromPool(this, l, i1, j1) != null) && block.canStopRayTrace(k1, var3)) {
                MovingObjectPosition movingobjectposition = block.collisionRayTrace(this, l, i1, j1, var1, var2);
                if (movingobjectposition != null) {
                    return movingobjectposition;
                }
            }

            MovingObjectPosition movingobjectposition2 = null;
            k1 = 200;

            while (k1-- >= 0) {
                if (Double.isNaN(var1.xCoord) || Double.isNaN(var1.yCoord) || Double.isNaN(var1.zCoord)) {
                    return null;
                }

                if (l == i && i1 == j && j1 == k) {
                    return var5 ? movingobjectposition2 : null;
                }

                boolean flag2 = true;
                boolean flag = true;
                boolean flag1 = true;
                double d0 = 999.0;
                double d1 = 999.0;
                double d2 = 999.0;
                if (i > l) {
                    d0 = l + 1.0;
                } else if (i < l) {
                    d0 = l + 0.0;
                } else {
                    flag2 = false;
                }

                if (j > i1) {
                    d1 = i1 + 1.0;
                } else if (j < i1) {
                    d1 = i1 + 0.0;
                } else {
                    flag = false;
                }

                if (k > j1) {
                    d2 = j1 + 1.0;
                } else if (k < j1) {
                    d2 = j1 + 0.0;
                } else {
                    flag1 = false;
                }

                double d3 = 999.0;
                double d4 = 999.0;
                double d5 = 999.0;
                double d6 = var2.xCoord - var1.xCoord;
                double d7 = var2.yCoord - var1.yCoord;
                double d8 = var2.zCoord - var1.zCoord;
                if (flag2) {
                    d3 = (d0 - var1.xCoord) / d6;
                }

                if (flag) {
                    d4 = (d1 - var1.yCoord) / d7;
                }

                if (flag1) {
                    d5 = (d2 - var1.zCoord) / d8;
                }

                byte b0 = 0;
                if (d3 < d4 && d3 < d5) {
                    if (i > l) {
                        b0 = 4;
                    } else {
                        b0 = 5;
                    }

                    var1.xCoord = d0;
                    var1.yCoord += d7 * d3;
                    var1.zCoord += d8 * d3;
                } else if (d4 < d5) {
                    if (j > i1) {
                        b0 = 0;
                    } else {
                        b0 = 1;
                    }

                    var1.xCoord += d6 * d4;
                    var1.yCoord = d1;
                    var1.zCoord += d8 * d4;
                } else {
                    if (k > j1) {
                        b0 = 2;
                    } else {
                        b0 = 3;
                    }

                    var1.xCoord += d6 * d5;
                    var1.yCoord += d7 * d5;
                    var1.zCoord = d2;
                }

                Vec3 vec3 = Vec3.createVectorHelper(var1.xCoord, var1.yCoord, var1.zCoord);
                l = (int)(vec3.xCoord = MathHelper.floor_double(var1.xCoord));
                if (b0 == 5) {
                    l--;
                    vec3.xCoord++;
                }

                i1 = (int)(vec3.yCoord = MathHelper.floor_double(var1.yCoord));
                if (b0 == 1) {
                    i1--;
                    vec3.yCoord++;
                }

                j1 = (int)(vec3.zCoord = MathHelper.floor_double(var1.zCoord));
                if (b0 == 3) {
                    j1--;
                    vec3.zCoord++;
                }

                Block block1 = this.getBlock(l, i1, j1);
                int l1 = this.getBlockMetadata(l, i1, j1);
                if (!var4 || block1.getCollisionBoundingBoxFromPool(this, l, i1, j1) != null) {
                    if (block1.canStopRayTrace(l1, var3)) {
                        MovingObjectPosition movingobjectposition1 = block1.collisionRayTrace(this, l, i1, j1, var1, var2);
                        if (movingobjectposition1 != null) {
                            return movingobjectposition1;
                        }
                    } else {
                        movingobjectposition2 = new MovingObjectPosition(l, i1, j1, b0, var1, false);
                    }
                }
            }

            return var5 ? movingobjectposition2 : null;
        } else {
            return null;
        }
    }

    public void playSoundAtEntity(Entity var1, String var2, float var3, float var4) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playSound(var2, var1.posX, var1.posY - var1.yOffset, var1.posZ, var3, var4);
        }
    }

    public void playSoundToNearExcept(EntityPlayer var1, String var2, float var3, float var4) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playSoundToNearExcept(var1, var2, var1.posX, var1.posY - var1.yOffset, var1.posZ, var3, var4);
        }
    }

    public void playSoundEffect(double var1, double var3, double var5, String var7, float var8, float var9) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playSound(var7, var1, var3, var5, var8, var9);
        }
    }

    public void playSound(double var1, double var3, double var5, String var7, float var8, float var9, boolean var10) {
    }

    public void playRecord(String var1, int var2, int var3, int var4) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playRecord(var1, var2, var3, var4);
        }
    }

    public void spawnParticle(String var1, double var2, double var4, double var6, double var8, double var10, double var12) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).spawnParticle(var1, var2, var4, var6, var8, var10, var12);
        }
    }

    public boolean addWeatherEffect(Entity var1) {
        this.weatherEffects.add(var1);
        return true;
    }

    public boolean spawnEntityInWorld(Entity var1) {
        int i = MathHelper.floor_double(var1.posX / 16.0);
        int j = MathHelper.floor_double(var1.posZ / 16.0);
        boolean flag = var1.forceSpawn;
        if (var1 instanceof EntityPlayer) {
            flag = true;
        }

        if (!flag && !this.chunkExists(i, j)) {
            return false;
        }

        if (var1 instanceof EntityPlayer) {
            EntityPlayer entityplayer = (EntityPlayer)var1;
            this.playerEntities.add(entityplayer);
            this.updateAllPlayersSleepingFlag();
        }

        this.getChunkFromChunkCoords(i, j).addEntity(var1);
        this.loadedEntityList.add(var1);
        this.onEntityAdded(var1);
        return true;
    }

    protected void onEntityAdded(Entity var1) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).onEntityCreate(var1);
        }
    }

    protected void onEntityRemoved(Entity var1) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).onEntityDestroy(var1);
        }
    }

    public void removeEntity(Entity var1) {
        if (var1.riddenByEntity != null) {
            var1.riddenByEntity.mountEntity(null);
        }

        if (var1.ridingEntity != null) {
            var1.mountEntity(null);
        }

        var1.setDead();
        if (var1 instanceof EntityPlayer) {
            this.playerEntities.remove(var1);
            this.updateAllPlayersSleepingFlag();
            this.onEntityRemoved(var1);
        }
    }

    public void removePlayerEntityDangerously(Entity var1) {
        var1.setDead();
        if (var1 instanceof EntityPlayer) {
            this.playerEntities.remove(var1);
            this.updateAllPlayersSleepingFlag();
        }

        int i = var1.chunkCoordX;
        int j = var1.chunkCoordZ;
        if (var1.addedToChunk && this.chunkExists(i, j)) {
            this.getChunkFromChunkCoords(i, j).removeEntity(var1);
        }

        this.loadedEntityList.remove(var1);
        this.onEntityRemoved(var1);
    }

    public void addWorldAccess(IWorldAccess var1) {
        this.worldAccesses.add(var1);
    }

    public void removeWorldAccess(IWorldAccess var1) {
        this.worldAccesses.remove(var1);
    }

    public List getCollidingBoundingBoxes(Entity var1, AxisAlignedBB var2) {
        this.collidingBoundingBoxes.clear();
        int i = MathHelper.floor_double(var2.minX);
        int j = MathHelper.floor_double(var2.maxX + 1.0);
        int k = MathHelper.floor_double(var2.minY);
        int l = MathHelper.floor_double(var2.maxY + 1.0);
        int i1 = MathHelper.floor_double(var2.minZ);
        int j1 = MathHelper.floor_double(var2.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = i1; l1 < j1; l1++) {
                if (this.blockExists(k1, 64, l1)) {
                    for (int i2 = k - 1; i2 < l; i2++) {
                        Block block;
                        if (k1 >= -30000000 && k1 < 30000000 && l1 >= -30000000 && l1 < 30000000) {
                            block = this.getBlock(k1, i2, l1);
                        } else {
                            block = Blocks.stone;
                        }

                        block.addCollisionBoxesToList(this, k1, i2, l1, var2, this.collidingBoundingBoxes, var1);
                    }
                }
            }
        }

        double d0 = 0.25;
        List list = this.getEntitiesWithinAABBExcludingEntity(var1, var2.expand(d0, d0, d0));

        for (int j2 = 0; j2 < list.size(); j2++) {
            AxisAlignedBB axisalignedbb = ((Entity)list.get(j2)).getBoundingBox();
            if (axisalignedbb != null && axisalignedbb.intersectsWith(var2)) {
                this.collidingBoundingBoxes.add(axisalignedbb);
            }

            axisalignedbb = var1.getCollisionBox((Entity)list.get(j2));
            if (axisalignedbb != null && axisalignedbb.intersectsWith(var2)) {
                this.collidingBoundingBoxes.add(axisalignedbb);
            }
        }

        return this.collidingBoundingBoxes;
    }

    public List func_147461_a(AxisAlignedBB var1) {
        this.collidingBoundingBoxes.clear();
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = i1; l1 < j1; l1++) {
                if (this.blockExists(k1, 64, l1)) {
                    for (int i2 = k - 1; i2 < l; i2++) {
                        Block block;
                        if (k1 >= -30000000 && k1 < 30000000 && l1 >= -30000000 && l1 < 30000000) {
                            block = this.getBlock(k1, i2, l1);
                        } else {
                            block = Blocks.bedrock;
                        }

                        block.addCollisionBoxesToList(this, k1, i2, l1, var1, this.collidingBoundingBoxes, null);
                    }
                }
            }
        }

        return this.collidingBoundingBoxes;
    }

    public int calculateSkylightSubtracted(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = 1.0F - (MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.5F);
        if (f1 < 0.0F) {
            f1 = 0.0F;
        }

        if (f1 > 1.0F) {
            f1 = 1.0F;
        }

        f1 = 1.0F - f1;
        f1 = (float)(f1 * (1.0 - this.getRainStrength(var1) * 5.0F / 16.0));
        f1 = (float)(f1 * (1.0 - this.getWeightedThunderStrength(var1) * 5.0F / 16.0));
        f1 = 1.0F - f1;
        return (int)(f1 * 11.0F);
    }

    public float getSunBrightness(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = 1.0F - (MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.2F);
        if (f1 < 0.0F) {
            f1 = 0.0F;
        }

        if (f1 > 1.0F) {
            f1 = 1.0F;
        }

        f1 = 1.0F - f1;
        f1 = (float)(f1 * (1.0 - this.getRainStrength(var1) * 5.0F / 16.0));
        f1 = (float)(f1 * (1.0 - this.getWeightedThunderStrength(var1) * 5.0F / 16.0));
        return f1 * 0.8F + 0.2F;
    }

    public Vec3 getSkyColor(Entity var1, float var2) {
        float f = this.getCelestialAngle(var2);
        float f1 = MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.5F;
        if (f1 < 0.0F) {
            f1 = 0.0F;
        }

        if (f1 > 1.0F) {
            f1 = 1.0F;
        }

        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posY);
        int k = MathHelper.floor_double(var1.posZ);
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(i, k);
        float f2 = biomegenbase.getFloatTemperature(i, j, k);
        int l = biomegenbase.getSkyColorByTemp(f2);
        float f3 = (l >> 16 & 0xFF) / 255.0F;
        float f4 = (l >> 8 & 0xFF) / 255.0F;
        float f5 = (l & 0xFF) / 255.0F;
        f3 *= f1;
        f4 *= f1;
        f5 *= f1;
        float f6 = this.getRainStrength(var2);
        if (f6 > 0.0F) {
            float f7 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.6F;
            float f8 = 1.0F - f6 * (12.0F / 16.0F);
            f3 = f3 * f8 + f7 * (1.0F - f8);
            f4 = f4 * f8 + f7 * (1.0F - f8);
            f5 = f5 * f8 + f7 * (1.0F - f8);
        }

        float f10 = this.getWeightedThunderStrength(var2);
        if (f10 > 0.0F) {
            float f11 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.2F;
            float f9 = 1.0F - f10 * (12.0F / 16.0F);
            f3 = f3 * f9 + f11 * (1.0F - f9);
            f4 = f4 * f9 + f11 * (1.0F - f9);
            f5 = f5 * f9 + f11 * (1.0F - f9);
        }

        if (this.lastLightningBolt > 0) {
            float f12 = this.lastLightningBolt - var2;
            if (f12 > 1.0F) {
                f12 = 1.0F;
            }

            f12 *= 0.45F;
            f3 = f3 * (1.0F - f12) + 0.8F * f12;
            f4 = f4 * (1.0F - f12) + 0.8F * f12;
            f5 = f5 * (1.0F - f12) + 1.0F * f12;
        }

        return Vec3.createVectorHelper(f3, f4, f5);
    }

    public float getCelestialAngle(float var1) {
        return this.provider.calculateCelestialAngle(this.worldInfo.getWorldTime(), var1);
    }

    public int getMoonPhase() {
        return this.provider.getMoonPhase(this.worldInfo.getWorldTime());
    }

    public float getCurrentMoonPhaseFactor() {
        return WorldProvider.moonPhaseFactors[this.provider.getMoonPhase(this.worldInfo.getWorldTime())];
    }

    public float getCelestialAngleRadians(float var1) {
        float f = this.getCelestialAngle(var1);
        return f * (float)Math.PI * 2.0F;
    }

    public Vec3 getCloudColour(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.5F;
        if (f1 < 0.0F) {
            f1 = 0.0F;
        }

        if (f1 > 1.0F) {
            f1 = 1.0F;
        }

        float f2 = (float)(this.cloudColour >> 16 & 255L) / 255.0F;
        float f3 = (float)(this.cloudColour >> 8 & 255L) / 255.0F;
        float f4 = (float)(this.cloudColour & 255L) / 255.0F;
        float f5 = this.getRainStrength(var1);
        if (f5 > 0.0F) {
            float f6 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.6F;
            float f7 = 1.0F - f5 * 0.95F;
            f2 = f2 * f7 + f6 * (1.0F - f7);
            f3 = f3 * f7 + f6 * (1.0F - f7);
            f4 = f4 * f7 + f6 * (1.0F - f7);
        }

        f2 *= f1 * 0.9F + 0.1F;
        f3 *= f1 * 0.9F + 0.1F;
        f4 *= f1 * 0.85F + 0.15F;
        float f9 = this.getWeightedThunderStrength(var1);
        if (f9 > 0.0F) {
            float f10 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.2F;
            float f8 = 1.0F - f9 * 0.95F;
            f2 = f2 * f8 + f10 * (1.0F - f8);
            f3 = f3 * f8 + f10 * (1.0F - f8);
            f4 = f4 * f8 + f10 * (1.0F - f8);
        }

        return Vec3.createVectorHelper(f2, f3, f4);
    }

    public Vec3 getFogColor(float var1) {
        float f = this.getCelestialAngle(var1);
        return this.provider.getFogColor(f, var1);
    }

    public int getPrecipitationHeight(int var1, int var2) {
        return this.getChunkFromBlockCoords(var1, var2).getPrecipitationHeight(var1 & 15, var2 & 15);
    }

    public int getTopSolidOrLiquidBlock(int var1, int var2) {
        Chunk chunk = this.getChunkFromBlockCoords(var1, var2);
        int i = chunk.getTopFilledSegment() + 15;
        var1 &= 15;
        var2 &= 15;

        while (i > 0) {
            Block block = chunk.getBlock(var1, i, var2);
            if (block.getMaterial().blocksMovement() && block.getMaterial() != Material.leaves) {
                return i + 1;
            }

            i--;
        }

        return -1;
    }

    public float getStarBrightness(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = 1.0F - (MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.25F);
        if (f1 < 0.0F) {
            f1 = 0.0F;
        }

        if (f1 > 1.0F) {
            f1 = 1.0F;
        }

        return f1 * f1 * 0.5F;
    }

    public void scheduleBlockUpdate(int var1, int var2, int var3, Block var4, int var5) {
    }

    public void scheduleBlockUpdateWithPriority(int var1, int var2, int var3, Block var4, int var5, int var6) {
    }

    public void func_147446_b(int var1, int var2, int var3, Block var4, int var5, int var6) {
    }

    public void updateEntities() {
        this.theProfiler.startSection("entities");
        this.theProfiler.startSection("global");

        for (int i = 0; i < this.weatherEffects.size(); i++) {
            Entity entity = (Entity)this.weatherEffects.get(i);

            try {
                entity.ticksExisted++;
                entity.onUpdate();
            } catch (Throwable throwable2) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable2, "Ticking entity");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being ticked");
                if (entity == null) {
                    crashreportcategory.addCrashSection("Entity", "~~NULL~~");
                } else {
                    entity.addEntityCrashInfo(crashreportcategory);
                }

                throw new ReportedException(crashreport);
            }

            if (entity.isDead) {
                this.weatherEffects.remove(i--);
            }
        }

        this.theProfiler.endStartSection("remove");
        this.loadedEntityList.removeAll(this.unloadedEntityList);

        for (int k = 0; k < this.unloadedEntityList.size(); k++) {
            Entity entity1 = (Entity)this.unloadedEntityList.get(k);
            int j = entity1.chunkCoordX;
            int l1 = entity1.chunkCoordZ;
            if (entity1.addedToChunk && this.chunkExists(j, l1)) {
                this.getChunkFromChunkCoords(j, l1).removeEntity(entity1);
            }
        }

        for (int l = 0; l < this.unloadedEntityList.size(); l++) {
            this.onEntityRemoved((Entity)this.unloadedEntityList.get(l));
        }

        this.unloadedEntityList.clear();
        this.theProfiler.endStartSection("regular");

        for (int i1 = 0; i1 < this.loadedEntityList.size(); i1++) {
            Entity entity2 = (Entity)this.loadedEntityList.get(i1);
            if (entity2.ridingEntity != null) {
                if (!entity2.ridingEntity.isDead && entity2.ridingEntity.riddenByEntity == entity2) {
                    continue;
                }

                entity2.ridingEntity.riddenByEntity = null;
                entity2.ridingEntity = null;
            }

            this.theProfiler.startSection("tick");
            if (!entity2.isDead) {
                try {
                    this.updateEntity(entity2);
                } catch (Throwable throwable1) {
                    CrashReport crashreport1 = CrashReport.makeCrashReport(throwable1, "Ticking entity");
                    CrashReportCategory crashreportcategory1 = crashreport1.makeCategory("Entity being ticked");
                    entity2.addEntityCrashInfo(crashreportcategory1);
                    throw new ReportedException(crashreport1);
                }
            }

            this.theProfiler.endSection();
            this.theProfiler.startSection("remove");
            if (entity2.isDead) {
                int k1 = entity2.chunkCoordX;
                int i2 = entity2.chunkCoordZ;
                if (entity2.addedToChunk && this.chunkExists(k1, i2)) {
                    this.getChunkFromChunkCoords(k1, i2).removeEntity(entity2);
                }

                this.loadedEntityList.remove(i1--);
                this.onEntityRemoved(entity2);
            }

            this.theProfiler.endSection();
        }

        this.theProfiler.endStartSection("blockEntities");
        this.processingLoadedTiles = true;
        Iterator iterator = this.loadedTileEntityList.iterator();

        while (iterator.hasNext()) {
            TileEntity tileentity = (TileEntity)iterator.next();
            if (!tileentity.isInvalid() && tileentity.hasWorldObj() && this.blockExists(tileentity.xCoord, tileentity.yCoord, tileentity.zCoord)) {
                try {
                    tileentity.updateEntity();
                } catch (Throwable throwable) {
                    CrashReport crashreport2 = CrashReport.makeCrashReport(throwable, "Ticking block entity");
                    CrashReportCategory crashreportcategory2 = crashreport2.makeCategory("Block entity being ticked");
                    tileentity.addInfoToCrashReport(crashreportcategory2);
                    throw new ReportedException(crashreport2);
                }
            }

            if (tileentity.isInvalid()) {
                iterator.remove();
                if (this.chunkExists(tileentity.xCoord >> 4, tileentity.zCoord >> 4)) {
                    Chunk chunk = this.getChunkFromChunkCoords(tileentity.xCoord >> 4, tileentity.zCoord >> 4);
                    if (chunk != null) {
                        chunk.removeTileEntity(tileentity.xCoord & 15, tileentity.yCoord, tileentity.zCoord & 15);
                    }
                }
            }
        }

        this.processingLoadedTiles = false;
        if (!this.tileEntitiesToBeRemoved.isEmpty()) {
            this.loadedTileEntityList.removeAll(this.tileEntitiesToBeRemoved);
            this.tileEntitiesToBeRemoved.clear();
        }

        this.theProfiler.endStartSection("pendingBlockEntities");
        if (!this.addedTileEntityList.isEmpty()) {
            for (int j1 = 0; j1 < this.addedTileEntityList.size(); j1++) {
                TileEntity tileentity1 = (TileEntity)this.addedTileEntityList.get(j1);
                if (!tileentity1.isInvalid()) {
                    if (!this.loadedTileEntityList.contains(tileentity1)) {
                        this.loadedTileEntityList.add(tileentity1);
                    }

                    if (this.chunkExists(tileentity1.xCoord >> 4, tileentity1.zCoord >> 4)) {
                        Chunk chunk1 = this.getChunkFromChunkCoords(tileentity1.xCoord >> 4, tileentity1.zCoord >> 4);
                        if (chunk1 != null) {
                            chunk1.setBlockTileEntityInChunk(tileentity1.xCoord & 15, tileentity1.yCoord, tileentity1.zCoord & 15, tileentity1);
                        }
                    }

                    this.markBlockForUpdate(tileentity1.xCoord, tileentity1.yCoord, tileentity1.zCoord);
                }
            }

            this.addedTileEntityList.clear();
        }

        this.theProfiler.endSection();
        this.theProfiler.endSection();
    }

    public void func_147448_a(Collection var1) {
        if (this.processingLoadedTiles) {
            this.addedTileEntityList.addAll(var1);
        } else {
            this.loadedTileEntityList.addAll(var1);
        }
    }

    public void updateEntity(Entity var1) {
        this.updateEntityWithOptionalForce(var1, true);
    }

    public void updateEntityWithOptionalForce(Entity var1, boolean var2) {
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posZ);
        byte b0 = 32;
        if (!var2 || this.checkChunksExist(i - b0, 0, j - b0, i + b0, 0, j + b0)) {
            var1.lastTickPosX = var1.posX;
            var1.lastTickPosY = var1.posY;
            var1.lastTickPosZ = var1.posZ;
            var1.prevRotationYaw = var1.rotationYaw;
            var1.prevRotationPitch = var1.rotationPitch;
            if (var2 && var1.addedToChunk) {
                var1.ticksExisted++;
                if (var1.ridingEntity != null) {
                    var1.updateRidden();
                } else {
                    var1.onUpdate();
                }
            }

            this.theProfiler.startSection("chunkCheck");
            if (Double.isNaN(var1.posX) || Double.isInfinite(var1.posX)) {
                var1.posX = var1.lastTickPosX;
            }

            if (Double.isNaN(var1.posY) || Double.isInfinite(var1.posY)) {
                var1.posY = var1.lastTickPosY;
            }

            if (Double.isNaN(var1.posZ) || Double.isInfinite(var1.posZ)) {
                var1.posZ = var1.lastTickPosZ;
            }

            if (Double.isNaN(var1.rotationPitch) || Double.isInfinite(var1.rotationPitch)) {
                var1.rotationPitch = var1.prevRotationPitch;
            }

            if (Double.isNaN(var1.rotationYaw) || Double.isInfinite(var1.rotationYaw)) {
                var1.rotationYaw = var1.prevRotationYaw;
            }

            int k = MathHelper.floor_double(var1.posX / 16.0);
            int l = MathHelper.floor_double(var1.posY / 16.0);
            int i1 = MathHelper.floor_double(var1.posZ / 16.0);
            if (!var1.addedToChunk || var1.chunkCoordX != k || var1.chunkCoordY != l || var1.chunkCoordZ != i1) {
                if (var1.addedToChunk && this.chunkExists(var1.chunkCoordX, var1.chunkCoordZ)) {
                    this.getChunkFromChunkCoords(var1.chunkCoordX, var1.chunkCoordZ).removeEntityAtIndex(var1, var1.chunkCoordY);
                }

                if (this.chunkExists(k, i1)) {
                    var1.addedToChunk = true;
                    this.getChunkFromChunkCoords(k, i1).addEntity(var1);
                } else {
                    var1.addedToChunk = false;
                }
            }

            this.theProfiler.endSection();
            if (var2 && var1.addedToChunk && var1.riddenByEntity != null) {
                if (!var1.riddenByEntity.isDead && var1.riddenByEntity.ridingEntity == var1) {
                    this.updateEntity(var1.riddenByEntity);
                } else {
                    var1.riddenByEntity.ridingEntity = null;
                    var1.riddenByEntity = null;
                }
            }
        }
    }

    public boolean checkNoEntityCollision(AxisAlignedBB var1) {
        return this.checkNoEntityCollision(var1, null);
    }

    public boolean checkNoEntityCollision(AxisAlignedBB var1, Entity var2) {
        List list = this.getEntitiesWithinAABBExcludingEntity(null, var1);

        for (int i = 0; i < list.size(); i++) {
            Entity entity = (Entity)list.get(i);
            if (!entity.isDead && entity.preventEntitySpawning && entity != var2) {
                return false;
            }
        }

        return true;
    }

    public boolean checkBlockCollision(AxisAlignedBB var1) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);
        if (var1.minX < 0.0) {
            i--;
        }

        if (var1.minY < 0.0) {
            k--;
        }

        if (var1.minZ < 0.0) {
            i1--;
        }

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    Block block = this.getBlock(k1, l1, i2);
                    if (block.getMaterial() != Material.air) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean isAnyLiquid(AxisAlignedBB var1) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);
        if (var1.minX < 0.0) {
            i--;
        }

        if (var1.minY < 0.0) {
            k--;
        }

        if (var1.minZ < 0.0) {
            i1--;
        }

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    Block block = this.getBlock(k1, l1, i2);
                    if (block.getMaterial().isLiquid()) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean func_147470_e(AxisAlignedBB var1) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);
        if (this.checkChunksExist(i, k, i1, j, l, j1)) {
            for (int k1 = i; k1 < j; k1++) {
                for (int l1 = k; l1 < l; l1++) {
                    for (int i2 = i1; i2 < j1; i2++) {
                        Block block = this.getBlock(k1, l1, i2);
                        if (block == Blocks.fire || block == Blocks.flowing_lava || block == Blocks.lava) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public boolean handleMaterialAcceleration(AxisAlignedBB var1, Material var2, Entity var3) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);
        if (!this.checkChunksExist(i, k, i1, j, l, j1)) {
            return false;
        }

        boolean flag = false;
        Vec3 vec3 = Vec3.createVectorHelper(0.0, 0.0, 0.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    Block block = this.getBlock(k1, l1, i2);
                    if (block.getMaterial() == var2) {
                        double d0 = l1 + 1 - BlockLiquid.getLiquidHeightPercent(this.getBlockMetadata(k1, l1, i2));
                        if (l >= d0) {
                            flag = true;
                            block.modifyEntityVelocity(this, k1, l1, i2, var3, vec3);
                        }
                    }
                }
            }
        }

        if (vec3.lengthVector() > 0.0 && var3.isPushedByWater()) {
            vec3 = vec3.normalize();
            double d1 = 0.014;
            var3.motionX = var3.motionX + vec3.xCoord * d1;
            var3.motionY = var3.motionY + vec3.yCoord * d1;
            var3.motionZ = var3.motionZ + vec3.zCoord * d1;
        }

        return flag;
    }

    public boolean isMaterialInBB(AxisAlignedBB var1, Material var2) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    if (this.getBlock(k1, l1, i2).getMaterial() == var2) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean isAABBInMaterial(AxisAlignedBB var1, Material var2) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    Block block = this.getBlock(k1, l1, i2);
                    if (block.getMaterial() == var2) {
                        int j2 = this.getBlockMetadata(k1, l1, i2);
                        double d0 = l1 + 1;
                        if (j2 < 8) {
                            d0 = l1 + 1 - j2 / 8.0;
                        }

                        if (d0 >= var1.minY) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public Explosion createExplosion(Entity var1, double var2, double var4, double var6, float var8, boolean var9) {
        return this.newExplosion(var1, var2, var4, var6, var8, false, var9);
    }

    public Explosion newExplosion(Entity var1, double var2, double var4, double var6, float var8, boolean var9, boolean var10) {
        Explosion explosion = new Explosion(this, var1, var2, var4, var6, var8);
        explosion.isFlaming = var9;
        explosion.isSmoking = var10;
        explosion.doExplosionA();
        explosion.doExplosionB(true);
        return explosion;
    }

    public float getBlockDensity(Vec3 var1, AxisAlignedBB var2) {
        double d0 = 1.0 / ((var2.maxX - var2.minX) * 2.0 + 1.0);
        double d1 = 1.0 / ((var2.maxY - var2.minY) * 2.0 + 1.0);
        double d2 = 1.0 / ((var2.maxZ - var2.minZ) * 2.0 + 1.0);
        if (!(d0 < 0.0) && !(d1 < 0.0) && !(d2 < 0.0)) {
            int i = 0;
            int j = 0;

            for (float f = 0.0F; f <= 1.0F; f = (float)(f + d0)) {
                for (float f1 = 0.0F; f1 <= 1.0F; f1 = (float)(f1 + d1)) {
                    for (float f2 = 0.0F; f2 <= 1.0F; f2 = (float)(f2 + d2)) {
                        double d3 = var2.minX + (var2.maxX - var2.minX) * f;
                        double d4 = var2.minY + (var2.maxY - var2.minY) * f1;
                        double d5 = var2.minZ + (var2.maxZ - var2.minZ) * f2;
                        if (this.rayTraceBlocks(Vec3.createVectorHelper(d3, d4, d5), var1) == null) {
                            i++;
                        }

                        j++;
                    }
                }
            }

            return (float)i / j;
        } else {
            return 0.0F;
        }
    }

    public boolean extinguishFire(EntityPlayer var1, int var2, int var3, int var4, int var5) {
        if (var5 == 0) {
            var3--;
        }

        if (var5 == 1) {
            var3++;
        }

        if (var5 == 2) {
            var4--;
        }

        if (var5 == 3) {
            var4++;
        }

        if (var5 == 4) {
            var2--;
        }

        if (var5 == 5) {
            var2++;
        }

        if (this.getBlock(var2, var3, var4) == Blocks.fire) {
            this.playAuxSFXAtEntity(var1, 1004, var2, var3, var4, 0);
            this.setBlockToAir(var2, var3, var4);
            return true;
        } else {
            return false;
        }
    }

    public String getDebugLoadedEntities() {
        return "All: " + this.loadedEntityList.size();
    }

    public String getProviderName() {
        return this.chunkProvider.makeString();
    }

    @Override
    public TileEntity getTileEntity(int var1, int var2, int var3) {
        if (var2 >= 0 && var2 < 256) {
            TileEntity tileentity = null;
            if (this.processingLoadedTiles) {
                for (int i = 0; i < this.addedTileEntityList.size(); i++) {
                    TileEntity tileentity1 = (TileEntity)this.addedTileEntityList.get(i);
                    if (!tileentity1.isInvalid() && tileentity1.xCoord == var1 && tileentity1.yCoord == var2 && tileentity1.zCoord == var3) {
                        tileentity = tileentity1;
                        break;
                    }
                }
            }

            if (tileentity == null) {
                Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
                if (chunk != null) {
                    tileentity = chunk.getBlockTileEntityInChunk(var1 & 15, var2, var3 & 15);
                }
            }

            if (tileentity == null) {
                for (int j = 0; j < this.addedTileEntityList.size(); j++) {
                    TileEntity tileentity2 = (TileEntity)this.addedTileEntityList.get(j);
                    if (!tileentity2.isInvalid() && tileentity2.xCoord == var1 && tileentity2.yCoord == var2 && tileentity2.zCoord == var3) {
                        tileentity = tileentity2;
                        break;
                    }
                }
            }

            return tileentity;
        } else {
            return null;
        }
    }

    public void setTileEntity(int var1, int var2, int var3, TileEntity var4) {
        if (var4 != null && !var4.isInvalid()) {
            if (this.processingLoadedTiles) {
                var4.xCoord = var1;
                var4.yCoord = var2;
                var4.zCoord = var3;
                Iterator iterator = this.addedTileEntityList.iterator();

                while (iterator.hasNext()) {
                    TileEntity tileentity = (TileEntity)iterator.next();
                    if (tileentity.xCoord == var1 && tileentity.yCoord == var2 && tileentity.zCoord == var3) {
                        tileentity.invalidate();
                        iterator.remove();
                    }
                }

                this.addedTileEntityList.add(var4);
            } else {
                this.loadedTileEntityList.add(var4);
                Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
                if (chunk != null) {
                    chunk.setBlockTileEntityInChunk(var1 & 15, var2, var3 & 15, var4);
                }
            }
        }
    }

    public void removeTileEntity(int var1, int var2, int var3) {
        TileEntity tileentity = this.getTileEntity(var1, var2, var3);
        if (tileentity != null && this.processingLoadedTiles) {
            tileentity.invalidate();
            this.addedTileEntityList.remove(tileentity);
        } else {
            if (tileentity != null) {
                this.addedTileEntityList.remove(tileentity);
                this.loadedTileEntityList.remove(tileentity);
            }

            Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var3 >> 4);
            if (chunk != null) {
                chunk.removeTileEntity(var1 & 15, var2, var3 & 15);
            }
        }
    }

    public void markTileEntityForRemoval(TileEntity var1) {
        this.tileEntitiesToBeRemoved.add(var1);
    }

    public boolean isBlockFullCube(int var1, int var2, int var3) {
        AxisAlignedBB axisalignedbb = this.getBlock(var1, var2, var3).getCollisionBoundingBoxFromPool(this, var1, var2, var3);
        return axisalignedbb != null && axisalignedbb.getAverageEdgeLength() >= 1.0;
    }

    public static boolean doesBlockHaveSolidTopSurface(IBlockAccess var0, int var1, int var2, int var3) {
        Block block = var0.getBlock(var1, var2, var3);
        int i = var0.getBlockMetadata(var1, var2, var3);
        if (block.getMaterial().isOpaque() && block.renderAsNormalBlock()) {
            return true;
        } else if (block instanceof BlockStairs) {
            return (i & 4) == 4;
        } else if (block instanceof BlockSlab) {
            return (i & 8) == 8;
        } else if (block instanceof BlockHopper) {
            return true;
        } else {
            return block instanceof BlockSnow ? (i & 7) == 7 : false;
        }
    }

    public boolean isBlockNormalCubeDefault(int var1, int var2, int var3, boolean var4) {
        if (var1 >= -30000000 && var3 >= -30000000 && var1 < 30000000 && var3 < 30000000) {
            Chunk chunk = this.chunkProvider.provideChunk(var1 >> 4, var3 >> 4);
            if (chunk != null && !chunk.isEmpty()) {
                Block block = this.getBlock(var1, var2, var3);
                return block.getMaterial().isOpaque() && block.renderAsNormalBlock();
            } else {
                return var4;
            }
        } else {
            return var4;
        }
    }

    public void calculateInitialSkylight() {
        int i = this.calculateSkylightSubtracted(1.0F);
        if (i != this.skylightSubtracted) {
            this.skylightSubtracted = i;
        }
    }

    public void setAllowedSpawnTypes(boolean var1, boolean var2) {
        this.spawnHostileMobs = var1;
        this.spawnPeacefulMobs = var2;
    }

    public void tick() {
        this.updateWeather();
    }

    private void calculateInitialWeather() {
        if (this.worldInfo.isRaining()) {
            this.rainingStrength = 1.0F;
            if (this.worldInfo.isThundering()) {
                this.thunderingStrength = 1.0F;
            }
        }
    }

    protected void updateWeather() {
        if (!this.provider.hasNoSky) {
            if (!this.isRemote) {
                int i = this.worldInfo.getThunderTime();
                if (i <= 0) {
                    if (this.worldInfo.isThundering()) {
                        this.worldInfo.setThunderTime(this.rand.nextInt(12000) + 3600);
                    } else {
                        this.worldInfo.setThunderTime(this.rand.nextInt(168000) + 12000);
                    }
                } else {
                    this.worldInfo.setThunderTime(--i);
                    if (i <= 0) {
                        this.worldInfo.setThundering(!this.worldInfo.isThundering());
                    }
                }

                this.prevThunderingStrength = this.thunderingStrength;
                if (this.worldInfo.isThundering()) {
                    this.thunderingStrength = (float)(this.thunderingStrength + 0.01);
                } else {
                    this.thunderingStrength = (float)(this.thunderingStrength - 0.01);
                }

                this.thunderingStrength = MathHelper.clamp_float(this.thunderingStrength, 0.0F, 1.0F);
                int j = this.worldInfo.getRainTime();
                if (j <= 0) {
                    if (this.worldInfo.isRaining()) {
                        this.worldInfo.setRainTime(this.rand.nextInt(12000) + 12000);
                    } else {
                        this.worldInfo.setRainTime(this.rand.nextInt(168000) + 12000);
                    }
                } else {
                    this.worldInfo.setRainTime(--j);
                    if (j <= 0) {
                        this.worldInfo.setRaining(!this.worldInfo.isRaining());
                    }
                }

                this.prevRainingStrength = this.rainingStrength;
                if (this.worldInfo.isRaining()) {
                    this.rainingStrength = (float)(this.rainingStrength + 0.01);
                } else {
                    this.rainingStrength = (float)(this.rainingStrength - 0.01);
                }

                this.rainingStrength = MathHelper.clamp_float(this.rainingStrength, 0.0F, 1.0F);
            }
        }
    }

    protected void setActivePlayerChunksAndCheckLight() {
        this.activeChunkSet.clear();
        this.theProfiler.startSection("buildList");

        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer = (EntityPlayer)this.playerEntities.get(i);
            int j = MathHelper.floor_double(entityplayer.posX / 16.0);
            int k = MathHelper.floor_double(entityplayer.posZ / 16.0);
            int l = this.getRenderDistanceChunks();

            for (int i1 = -l; i1 <= l; i1++) {
                for (int j1 = -l; j1 <= l; j1++) {
                    this.activeChunkSet.add(new ChunkCoordIntPair(i1 + j, j1 + k));
                }
            }
        }

        this.theProfiler.endSection();
        if (this.ambientTickCountdown > 0) {
            this.ambientTickCountdown--;
        }

        this.theProfiler.startSection("playerCheckLight");
        if (!this.playerEntities.isEmpty()) {
            int k1 = this.rand.nextInt(this.playerEntities.size());
            EntityPlayer entityplayer1 = (EntityPlayer)this.playerEntities.get(k1);
            int l1 = MathHelper.floor_double(entityplayer1.posX) + this.rand.nextInt(11) - 5;
            int i2 = MathHelper.floor_double(entityplayer1.posY) + this.rand.nextInt(11) - 5;
            int j2 = MathHelper.floor_double(entityplayer1.posZ) + this.rand.nextInt(11) - 5;
            this.updateAllLightTypes(l1, i2, j2);
        }

        this.theProfiler.endSection();
    }

    protected abstract int getRenderDistanceChunks();

    protected void func_147467_a(int var1, int var2, Chunk var3) {
        this.theProfiler.endStartSection("moodSound");
        if (this.ambientTickCountdown == 0 && !this.isRemote) {
            this.updateLCG = this.updateLCG * 3 + 1013904223;
            int i = this.updateLCG >> 2;
            int j = i & 15;
            int k = i >> 8 & 15;
            int l = i >> 16 & 0xFF;
            Block block = var3.getBlock(j, l, k);
            j += var1;
            k += var2;
            if (block.getMaterial() == Material.air
                && this.getFullBlockLightValue(j, l, k) <= this.rand.nextInt(8)
                && this.getSavedLightValue(EnumSkyBlock.Sky, j, l, k) <= 0) {
                EntityPlayer entityplayer = this.getClosestPlayer(j + 0.5, l + 0.5, k + 0.5, 8.0);
                if (entityplayer != null && entityplayer.getDistanceSq(j + 0.5, l + 0.5, k + 0.5) > 4.0) {
                    this.playSoundEffect(j + 0.5, l + 0.5, k + 0.5, "ambient.cave.cave", 0.7F, 0.8F + this.rand.nextFloat() * 0.2F);
                    this.ambientTickCountdown = this.rand.nextInt(12000) + 6000;
                }
            }
        }

        this.theProfiler.endStartSection("checkLight");
        var3.enqueueRelightChecks();
    }

    protected void func_147456_g() {
        this.setActivePlayerChunksAndCheckLight();
    }

    public boolean isBlockFreezable(int var1, int var2, int var3) {
        return this.canBlockFreeze(var1, var2, var3, false);
    }

    public boolean isBlockFreezableNaturally(int var1, int var2, int var3) {
        return this.canBlockFreeze(var1, var2, var3, true);
    }

    public boolean canBlockFreeze(int var1, int var2, int var3, boolean var4) {
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1, var3);
        float f = biomegenbase.getFloatTemperature(var1, var2, var3);
        if (f > 0.15F) {
            return false;
        }

        if (var2 >= 0 && var2 < 256 && this.getSavedLightValue(EnumSkyBlock.Block, var1, var2, var3) < 10) {
            Block block = this.getBlock(var1, var2, var3);
            if ((block == Blocks.water || block == Blocks.flowing_water) && this.getBlockMetadata(var1, var2, var3) == 0) {
                if (!var4) {
                    return true;
                }

                boolean flag = true;
                if (flag && this.getBlock(var1 - 1, var2, var3).getMaterial() != Material.water) {
                    flag = false;
                }

                if (flag && this.getBlock(var1 + 1, var2, var3).getMaterial() != Material.water) {
                    flag = false;
                }

                if (flag && this.getBlock(var1, var2, var3 - 1).getMaterial() != Material.water) {
                    flag = false;
                }

                if (flag && this.getBlock(var1, var2, var3 + 1).getMaterial() != Material.water) {
                    flag = false;
                }

                if (!flag) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean canSnowAt(int var1, int var2, int var3, boolean var4) {
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1, var3);
        float f = biomegenbase.getFloatTemperature(var1, var2, var3);
        if (f > 0.15F) {
            return false;
        }

        if (!var4) {
            return true;
        }

        if (var2 >= 0 && var2 < 256 && this.getSavedLightValue(EnumSkyBlock.Block, var1, var2, var3) < 10) {
            Block block = this.getBlock(var1, var2, var3);
            if (block.getMaterial() == Material.air && Blocks.snow_layer.canPlaceBlockAt(this, var1, var2, var3)) {
                return true;
            }
        }

        return false;
    }

    public boolean updateAllLightTypes(int var1, int var2, int var3) {
        boolean flag = false;
        if (!this.provider.hasNoSky) {
            flag |= this.updateLightByType(EnumSkyBlock.Sky, var1, var2, var3);
        }

        return flag | this.updateLightByType(EnumSkyBlock.Block, var1, var2, var3);
    }

    private int computeLightValue(int var1, int var2, int var3, EnumSkyBlock var4) {
        if (var4 == EnumSkyBlock.Sky && this.canBlockSeeTheSky(var1, var2, var3)) {
            return 15;
        }

        Block block = this.getBlock(var1, var2, var3);
        int i = var4 == EnumSkyBlock.Sky ? 0 : block.getLightValue();
        int j = block.getLightOpacity();
        if (j >= 15 && block.getLightValue() > 0) {
            j = 1;
        }

        if (j < 1) {
            j = 1;
        }

        if (j >= 15) {
            return 0;
        }

        if (i >= 14) {
            return i;
        }

        for (int k = 0; k < 6; k++) {
            int l = var1 + Facing.offsetsXForSide[k];
            int i1 = var2 + Facing.offsetsYForSide[k];
            int j1 = var3 + Facing.offsetsZForSide[k];
            int k1 = this.getSavedLightValue(var4, l, i1, j1) - j;
            if (k1 > i) {
                i = k1;
            }

            if (i >= 14) {
                return i;
            }
        }

        return i;
    }

    public boolean updateLightByType(EnumSkyBlock var1, int var2, int var3, int var4) {
        if (!this.doChunksNearChunkExist(var2, var3, var4, 17)) {
            return false;
        }

        int i = 0;
        int j = 0;
        this.theProfiler.startSection("getBrightness");
        int k = this.getSavedLightValue(var1, var2, var3, var4);
        int l = this.computeLightValue(var2, var3, var4, var1);
        if (l > k) {
            this.lightUpdateBlockList[j++] = 133152;
        } else if (l < k) {
            this.lightUpdateBlockList[j++] = 133152 | k << 18;

            while (i < j) {
                int i1 = this.lightUpdateBlockList[i++];
                int j1 = (i1 & 63) - 32 + var2;
                int k1 = (i1 >> 6 & 63) - 32 + var3;
                int l1 = (i1 >> 12 & 63) - 32 + var4;
                int i2 = i1 >> 18 & 15;
                int j2 = this.getSavedLightValue(var1, j1, k1, l1);
                if (j2 == i2) {
                    this.setLightValue(var1, j1, k1, l1, 0);
                    if (i2 > 0) {
                        int k2 = MathHelper.abs_int(j1 - var2);
                        int l2 = MathHelper.abs_int(k1 - var3);
                        int i3 = MathHelper.abs_int(l1 - var4);
                        if (k2 + l2 + i3 < 17) {
                            for (int j3 = 0; j3 < 6; j3++) {
                                int k3 = j1 + Facing.offsetsXForSide[j3];
                                int l3 = k1 + Facing.offsetsYForSide[j3];
                                int i4 = l1 + Facing.offsetsZForSide[j3];
                                int j4 = Math.max(1, this.getBlock(k3, l3, i4).getLightOpacity());
                                j2 = this.getSavedLightValue(var1, k3, l3, i4);
                                if (j2 == i2 - j4 && j < this.lightUpdateBlockList.length) {
                                    this.lightUpdateBlockList[j++] = k3 - var2 + 32 | l3 - var3 + 32 << 6 | i4 - var4 + 32 << 12 | i2 - j4 << 18;
                                }
                            }
                        }
                    }
                }
            }

            i = 0;
        }

        this.theProfiler.endSection();
        this.theProfiler.startSection("checkedPosition < toCheckCount");

        while (i < j) {
            int k4 = this.lightUpdateBlockList[i++];
            int l4 = (k4 & 63) - 32 + var2;
            int i5 = (k4 >> 6 & 63) - 32 + var3;
            int j5 = (k4 >> 12 & 63) - 32 + var4;
            int k5 = this.getSavedLightValue(var1, l4, i5, j5);
            int l5 = this.computeLightValue(l4, i5, j5, var1);
            if (l5 != k5) {
                this.setLightValue(var1, l4, i5, j5, l5);
                if (l5 > k5) {
                    int i6 = Math.abs(l4 - var2);
                    int j6 = Math.abs(i5 - var3);
                    int k6 = Math.abs(j5 - var4);
                    boolean flag = j < this.lightUpdateBlockList.length - 6;
                    if (i6 + j6 + k6 < 17 && flag) {
                        if (this.getSavedLightValue(var1, l4 - 1, i5, j5) < l5) {
                            this.lightUpdateBlockList[j++] = l4 - 1 - var2 + 32 + (i5 - var3 + 32 << 6) + (j5 - var4 + 32 << 12);
                        }

                        if (this.getSavedLightValue(var1, l4 + 1, i5, j5) < l5) {
                            this.lightUpdateBlockList[j++] = l4 + 1 - var2 + 32 + (i5 - var3 + 32 << 6) + (j5 - var4 + 32 << 12);
                        }

                        if (this.getSavedLightValue(var1, l4, i5 - 1, j5) < l5) {
                            this.lightUpdateBlockList[j++] = l4 - var2 + 32 + (i5 - 1 - var3 + 32 << 6) + (j5 - var4 + 32 << 12);
                        }

                        if (this.getSavedLightValue(var1, l4, i5 + 1, j5) < l5) {
                            this.lightUpdateBlockList[j++] = l4 - var2 + 32 + (i5 + 1 - var3 + 32 << 6) + (j5 - var4 + 32 << 12);
                        }

                        if (this.getSavedLightValue(var1, l4, i5, j5 - 1) < l5) {
                            this.lightUpdateBlockList[j++] = l4 - var2 + 32 + (i5 - var3 + 32 << 6) + (j5 - 1 - var4 + 32 << 12);
                        }

                        if (this.getSavedLightValue(var1, l4, i5, j5 + 1) < l5) {
                            this.lightUpdateBlockList[j++] = l4 - var2 + 32 + (i5 - var3 + 32 << 6) + (j5 + 1 - var4 + 32 << 12);
                        }
                    }
                }
            }
        }

        this.theProfiler.endSection();
        return true;
    }

    public boolean tickUpdates(boolean var1) {
        return false;
    }

    public List getPendingBlockUpdates(Chunk var1, boolean var2) {
        return null;
    }

    public List getEntitiesWithinAABBExcludingEntity(Entity var1, AxisAlignedBB var2) {
        return this.getEntitiesWithinAABBExcludingEntity(var1, var2, null);
    }

    public List getEntitiesWithinAABBExcludingEntity(Entity var1, AxisAlignedBB var2, IEntitySelector var3) {
        ArrayList arraylist = new ArrayList();
        int i = MathHelper.floor_double((var2.minX - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxX + 2.0) / 16.0);
        int k = MathHelper.floor_double((var2.minZ - 2.0) / 16.0);
        int l = MathHelper.floor_double((var2.maxZ + 2.0) / 16.0);

        for (int i1 = i; i1 <= j; i1++) {
            for (int j1 = k; j1 <= l; j1++) {
                if (this.chunkExists(i1, j1)) {
                    this.getChunkFromChunkCoords(i1, j1).getEntitiesWithinAABBForEntity(var1, var2, arraylist, var3);
                }
            }
        }

        return arraylist;
    }

    public <T extends Entity> List<T> getEntitiesWithinAABB(Class<? extends T> var1, AxisAlignedBB var2) {
        return this.selectEntitiesWithinAABB(var1, var2, null);
    }

    public List selectEntitiesWithinAABB(Class var1, AxisAlignedBB var2, IEntitySelector var3) {
        int i = MathHelper.floor_double((var2.minX - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxX + 2.0) / 16.0);
        int k = MathHelper.floor_double((var2.minZ - 2.0) / 16.0);
        int l = MathHelper.floor_double((var2.maxZ + 2.0) / 16.0);
        ArrayList arraylist = new ArrayList();

        for (int i1 = i; i1 <= j; i1++) {
            for (int j1 = k; j1 <= l; j1++) {
                if (this.chunkExists(i1, j1)) {
                    this.getChunkFromChunkCoords(i1, j1).getEntitiesOfTypeWithinAAAB(var1, var2, arraylist, var3);
                }
            }
        }

        return arraylist;
    }

    public Entity findNearestEntityWithinAABB(Class var1, AxisAlignedBB var2, Entity var3) {
        List list = this.getEntitiesWithinAABB(var1, var2);
        Entity entity = null;
        double d0 = Double.MAX_VALUE;

        for (int i = 0; i < list.size(); i++) {
            Entity entity1 = (Entity)list.get(i);
            if (entity1 != var3) {
                double d1 = var3.getDistanceSqToEntity(entity1);
                if (!(d1 > d0)) {
                    entity = entity1;
                    d0 = d1;
                }
            }
        }

        return entity;
    }

    public abstract Entity getEntityByID(int var1);

    public List getLoadedEntityList() {
        return this.loadedEntityList;
    }

    public void markTileEntityChunkModified(int var1, int var2, int var3, TileEntity var4) {
        if (this.blockExists(var1, var2, var3)) {
            this.getChunkFromBlockCoords(var1, var3).setChunkModified();
        }
    }

    public int countEntities(Class var1) {
        int i = 0;

        for (int j = 0; j < this.loadedEntityList.size(); j++) {
            Entity entity = (Entity)this.loadedEntityList.get(j);
            if ((!(entity instanceof EntityLiving) || !((EntityLiving)entity).isNoDespawnRequired()) && var1.isAssignableFrom(entity.getClass())) {
                i++;
            }
        }

        return i;
    }

    public void addLoadedEntities(List var1) {
        this.loadedEntityList.addAll(var1);

        for (int i = 0; i < var1.size(); i++) {
            this.onEntityAdded((Entity)var1.get(i));
        }
    }

    public void unloadEntities(List var1) {
        this.unloadedEntityList.addAll(var1);
    }

    public boolean canPlaceEntityOnSide(Block var1, int var2, int var3, int var4, boolean var5, int var6, Entity var7, ItemStack var8) {
        Block block = this.getBlock(var2, var3, var4);
        AxisAlignedBB axisalignedbb = var5 ? null : var1.getCollisionBoundingBoxFromPool(this, var2, var3, var4);
        if (axisalignedbb != null && !this.checkNoEntityCollision(axisalignedbb, var7)) {
            return false;
        } else {
            return block.getMaterial() == Material.circuits && var1 == Blocks.anvil
                ? true
                : block.getMaterial().isReplaceable() && var1.canReplace(this, var2, var3, var4, var6, var8);
        }
    }

    public PathEntity getPathEntityToEntity(Entity var1, Entity var2, float var3, boolean var4, boolean var5, boolean var6, boolean var7) {
        this.theProfiler.startSection("pathfind");
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posY + 1.0);
        int k = MathHelper.floor_double(var1.posZ);
        int l = (int)(var3 + 16.0F);
        int i1 = i - l;
        int j1 = j - l;
        int k1 = k - l;
        int l1 = i + l;
        int i2 = j + l;
        int j2 = k + l;
        ChunkCache chunkcache = new ChunkCache(this, i1, j1, k1, l1, i2, j2, 0);
        PathEntity pathentity = new PathFinder(chunkcache, var4, var5, var6, var7).createEntityPathTo(var1, var2, var3);
        this.theProfiler.endSection();
        return pathentity;
    }

    public PathEntity getEntityPathToXYZ(Entity var1, int var2, int var3, int var4, float var5, boolean var6, boolean var7, boolean var8, boolean var9) {
        this.theProfiler.startSection("pathfind");
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posY);
        int k = MathHelper.floor_double(var1.posZ);
        int l = (int)(var5 + 8.0F);
        int i1 = i - l;
        int j1 = j - l;
        int k1 = k - l;
        int l1 = i + l;
        int i2 = j + l;
        int j2 = k + l;
        ChunkCache chunkcache = new ChunkCache(this, i1, j1, k1, l1, i2, j2, 0);
        PathEntity pathentity = new PathFinder(chunkcache, var6, var7, var8, var9).createEntityPathTo(var1, var2, var3, var4, var5);
        this.theProfiler.endSection();
        return pathentity;
    }

    @Override
    public int isBlockProvidingPowerTo(int var1, int var2, int var3, int var4) {
        return this.getBlock(var1, var2, var3).isProvidingStrongPower(this, var1, var2, var3, var4);
    }

    public int getBlockPowerInput(int var1, int var2, int var3) {
        int i = 0;
        i = Math.max(i, this.isBlockProvidingPowerTo(var1, var2 - 1, var3, 0));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.isBlockProvidingPowerTo(var1, var2 + 1, var3, 1));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.isBlockProvidingPowerTo(var1, var2, var3 - 1, 2));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.isBlockProvidingPowerTo(var1, var2, var3 + 1, 3));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.isBlockProvidingPowerTo(var1 - 1, var2, var3, 4));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.isBlockProvidingPowerTo(var1 + 1, var2, var3, 5));
        return i >= 15 ? i : i;
    }

    public boolean getIndirectPowerOutput(int var1, int var2, int var3, int var4) {
        return this.getIndirectPowerLevelTo(var1, var2, var3, var4) > 0;
    }

    public int getIndirectPowerLevelTo(int var1, int var2, int var3, int var4) {
        return this.getBlock(var1, var2, var3).isNormalCube()
            ? this.getBlockPowerInput(var1, var2, var3)
            : this.getBlock(var1, var2, var3).isProvidingWeakPower(this, var1, var2, var3, var4);
    }

    public boolean isBlockIndirectlyGettingPowered(int var1, int var2, int var3) {
        if (this.getIndirectPowerLevelTo(var1, var2 - 1, var3, 0) > 0) {
            return true;
        } else if (this.getIndirectPowerLevelTo(var1, var2 + 1, var3, 1) > 0) {
            return true;
        } else if (this.getIndirectPowerLevelTo(var1, var2, var3 - 1, 2) > 0) {
            return true;
        } else if (this.getIndirectPowerLevelTo(var1, var2, var3 + 1, 3) > 0) {
            return true;
        } else {
            return this.getIndirectPowerLevelTo(var1 - 1, var2, var3, 4) > 0 ? true : this.getIndirectPowerLevelTo(var1 + 1, var2, var3, 5) > 0;
        }
    }

    public int getStrongestIndirectPower(int var1, int var2, int var3) {
        int i = 0;

        for (int j = 0; j < 6; j++) {
            int k = this.getIndirectPowerLevelTo(var1 + Facing.offsetsXForSide[j], var2 + Facing.offsetsYForSide[j], var3 + Facing.offsetsZForSide[j], j);
            if (k >= 15) {
                return 15;
            }

            if (k > i) {
                i = k;
            }
        }

        return i;
    }

    public EntityPlayer getClosestPlayerToEntity(Entity var1, double var2) {
        return this.getClosestPlayer(var1.posX, var1.posY, var1.posZ, var2);
    }

    public EntityPlayer getClosestPlayer(double var1, double var3, double var5, double var7) {
        double d0 = -1.0;
        EntityPlayer entityplayer = null;

        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer1 = (EntityPlayer)this.playerEntities.get(i);
            double d1 = entityplayer1.getDistanceSq(var1, var3, var5);
            if ((var7 < 0.0 || d1 < var7 * var7) && (d0 == -1.0 || d1 < d0)) {
                d0 = d1;
                entityplayer = entityplayer1;
            }
        }

        return entityplayer;
    }

    public EntityPlayer getClosestVulnerablePlayerToEntity(Entity var1, double var2) {
        return this.getClosestVulnerablePlayer(var1.posX, var1.posY, var1.posZ, var2);
    }

    public EntityPlayer getClosestVulnerablePlayer(double var1, double var3, double var5, double var7) {
        double d0 = -1.0;
        EntityPlayer entityplayer = null;

        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer1 = (EntityPlayer)this.playerEntities.get(i);
            if (!entityplayer1.capabilities.disableDamage && entityplayer1.isEntityAlive()) {
                double d1 = entityplayer1.getDistanceSq(var1, var3, var5);
                double d2 = var7;
                if (entityplayer1.isSneaking()) {
                    d2 *= 0.8F;
                }

                if (entityplayer1.isInvisible()) {
                    float f = entityplayer1.getArmorVisibility();
                    if (f < 0.1F) {
                        f = 0.1F;
                    }

                    d2 *= 0.7F * f;
                }

                if ((var7 < 0.0 || d1 < d2 * d2) && (d0 == -1.0 || d1 < d0)) {
                    d0 = d1;
                    entityplayer = entityplayer1;
                }
            }
        }

        return entityplayer;
    }

    public EntityPlayer getPlayerEntityByName(String var1) {
        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer = (EntityPlayer)this.playerEntities.get(i);
            if (var1.equals(entityplayer.getCommandSenderName())) {
                return entityplayer;
            }
        }

        return null;
    }

    public EntityPlayer getPlayerEntityByUUID(UUID var1) {
        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer = (EntityPlayer)this.playerEntities.get(i);
            if (var1.equals(entityplayer.getUniqueID())) {
                return entityplayer;
            }
        }

        return null;
    }

    public void sendQuittingDisconnectingPacket() {
    }

    public void checkSessionLock() throws MinecraftException {
        this.saveHandler.checkSessionLock();
    }

    public void func_82738_a(long var1) {
        this.worldInfo.incrementTotalWorldTime(var1);
    }

    public long getSeed() {
        return this.worldInfo.getSeed();
    }

    public long getTotalWorldTime() {
        return this.worldInfo.getWorldTotalTime();
    }

    public long getWorldTime() {
        return this.worldInfo.getWorldTime();
    }

    public void setWorldTime(long var1) {
        this.worldInfo.setWorldTime(var1);
    }

    public ChunkCoordinates getSpawnPoint() {
        return new ChunkCoordinates(this.worldInfo.getSpawnX(), this.worldInfo.getSpawnY(), this.worldInfo.getSpawnZ());
    }

    public void setSpawnLocation(int var1, int var2, int var3) {
        this.worldInfo.setSpawnPosition(var1, var2, var3);
    }

    public void joinEntityInSurroundings(Entity var1) {
        int i = MathHelper.floor_double(var1.posX / 16.0);
        int j = MathHelper.floor_double(var1.posZ / 16.0);
        byte b0 = 2;

        for (int k = i - b0; k <= i + b0; k++) {
            for (int l = j - b0; l <= j + b0; l++) {
                this.getChunkFromChunkCoords(k, l);
            }
        }

        if (!this.loadedEntityList.contains(var1)) {
            this.loadedEntityList.add(var1);
        }
    }

    public boolean canMineBlock(EntityPlayer var1, int var2, int var3, int var4) {
        return true;
    }

    public void setEntityState(Entity var1, byte var2) {
    }

    public IChunkProvider getChunkProvider() {
        return this.chunkProvider;
    }

    public void addBlockEvent(int var1, int var2, int var3, Block var4, int var5, int var6) {
        var4.onBlockEventReceived(this, var1, var2, var3, var5, var6);
    }

    public ISaveHandler getSaveHandler() {
        return this.saveHandler;
    }

    public WorldInfo getWorldInfo() {
        return this.worldInfo;
    }

    public GameRules getGameRules() {
        return this.worldInfo.getGameRulesInstance();
    }

    public void updateAllPlayersSleepingFlag() {
    }

    public float getWeightedThunderStrength(float var1) {
        return (this.prevThunderingStrength + (this.thunderingStrength - this.prevThunderingStrength) * var1) * this.getRainStrength(var1);
    }

    public void setThunderStrength(float var1) {
        this.prevThunderingStrength = var1;
        this.thunderingStrength = var1;
    }

    public float getRainStrength(float var1) {
        return this.prevRainingStrength + (this.rainingStrength - this.prevRainingStrength) * var1;
    }

    public void setRainStrength(float var1) {
        this.prevRainingStrength = var1;
        this.rainingStrength = var1;
    }

    public boolean isThundering() {
        return this.getWeightedThunderStrength(1.0F) > 0.9;
    }

    public boolean isRaining() {
        return this.getRainStrength(1.0F) > 0.2;
    }

    public boolean isRainingAt(int var1, int var2, int var3) {
        if (!this.isRaining()) {
            return false;
        } else if (!this.canBlockSeeTheSky(var1, var2, var3)) {
            return false;
        } else if (this.getPrecipitationHeight(var1, var3) > var2) {
            return false;
        } else {
            BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1, var3);
            if (biomegenbase.getEnableSnow()) {
                return false;
            } else {
                return this.canSnowAt(var1, var2, var3, false) ? false : biomegenbase.canSpawnLightningBolt();
            }
        }
    }

    public boolean isBlockHighHumidity(int var1, int var2, int var3) {
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1, var3);
        return biomegenbase.isHighHumidity();
    }

    public void setItemData(String var1, WorldSavedData var2) {
        this.mapStorage.setData(var1, var2);
    }

    public WorldSavedData loadItemData(Class var1, String var2) {
        return this.mapStorage.loadData(var1, var2);
    }

    public int getUniqueDataId(String var1) {
        return this.mapStorage.getUniqueDataId(var1);
    }

    public void playBroadcastSound(int var1, int var2, int var3, int var4, int var5) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).broadcastSound(var1, var2, var3, var4, var5);
        }
    }

    public void playAuxSFX(int var1, int var2, int var3, int var4, int var5) {
        this.playAuxSFXAtEntity(null, var1, var2, var3, var4, var5);
    }

    public void playAuxSFXAtEntity(EntityPlayer var1, int var2, int var3, int var4, int var5, int var6) {
        try {
            for (int i = 0; i < this.worldAccesses.size(); i++) {
                ((IWorldAccess)this.worldAccesses.get(i)).playAuxSFX(var1, var2, var3, var4, var5, var6);
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Playing level event");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Level event being played");
            crashreportcategory.addCrashSection("Block coordinates", CrashReportCategory.getLocationInfo(var3, var4, var5));
            crashreportcategory.addCrashSection("Event source", var1);
            crashreportcategory.addCrashSection("Event type", var2);
            crashreportcategory.addCrashSection("Event data", var6);
            throw new ReportedException(crashreport);
        }
    }

    @Override
    public int getHeight() {
        return 256;
    }

    public int getActualHeight() {
        return this.provider.hasNoSky ? 128 : 256;
    }

    public Random setRandomSeed(int var1, int var2, int var3) {
        long i = var1 * 341873128712L + var2 * 132897987541L + this.getWorldInfo().getSeed() + var3;
        this.rand.setSeed(i);
        return this.rand;
    }

    public ChunkPosition findClosestStructure(String var1, int var2, int var3, int var4) {
        return this.getChunkProvider().findClosestStructure(this, var1, var2, var3, var4);
    }

    @Override
    public boolean extendedLevelsInChunkCache() {
        return false;
    }

    public double getHorizon() {
        return this.worldInfo.getTerrainType() == WorldType.FLAT ? 0.0 : 63.0;
    }

    public CrashReportCategory addWorldInfoToCrashReport(CrashReport var1) {
        CrashReportCategory crashreportcategory = var1.makeCategoryDepth("Affected level", 1);
        crashreportcategory.addCrashSection("Level name", this.worldInfo == null ? "????" : this.worldInfo.getWorldName());
        crashreportcategory.addCrashSectionCallable("All players", new Callable() {
            public String call() {
                return World.this.playerEntities.size() + " total; " + World.this.playerEntities.toString();
            }
        });
        crashreportcategory.addCrashSectionCallable("Chunk stats", new Callable() {
            public String call() {
                return World.this.chunkProvider.makeString();
            }
        });

        try {
            this.worldInfo.addToCrashReport(crashreportcategory);
        } catch (Throwable throwable) {
            crashreportcategory.addCrashSectionThrowable("Level Data Unobtainable", throwable);
        }

        return crashreportcategory;
    }

    public void destroyBlockInWorldPartially(int var1, int var2, int var3, int var4, int var5) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            IWorldAccess iworldaccess = (IWorldAccess)this.worldAccesses.get(i);
            iworldaccess.destroyBlockPartially(var1, var2, var3, var4, var5);
        }
    }

    public Calendar getCurrentDate() {
        if (this.getTotalWorldTime() % 600L == 0L) {
            this.theCalendar.setTimeInMillis(MinecraftServer.getCurrentTimeMillis());
        }

        return this.theCalendar;
    }

    public void makeFireworks(double var1, double var3, double var5, double var7, double var9, double var11, NBTTagCompound var13) {
    }

    public Scoreboard getScoreboard() {
        return this.worldScoreboard;
    }

    public void updateNeighborsAboutBlockChange(int var1, int var2, int var3, Block var4) {
        for (int i = 0; i < 4; i++) {
            int j = var1 + Direction.offsetX[i];
            int k = var3 + Direction.offsetZ[i];
            Block block = this.getBlock(j, var2, k);
            if (Blocks.unpowered_comparator.func_149907_e(block)) {
                block.onNeighborBlockChange(this, j, var2, k, var4);
            } else if (block.isNormalCube()) {
                j += Direction.offsetX[i];
                k += Direction.offsetZ[i];
                Block block1 = this.getBlock(j, var2, k);
                if (Blocks.unpowered_comparator.func_149907_e(block1)) {
                    block1.onNeighborBlockChange(this, j, var2, k, var4);
                }
            }
        }
    }

    public float getTensionFactorForBlock(double var1, double var3, double var5) {
        return this.func_147473_B(MathHelper.floor_double(var1), MathHelper.floor_double(var3), MathHelper.floor_double(var5));
    }

    public float func_147473_B(int var1, int var2, int var3) {
        float f = 0.0F;
        boolean flag = this.difficultySetting == EnumDifficulty.HARD;
        if (this.blockExists(var1, var2, var3)) {
            float f1 = this.getCurrentMoonPhaseFactor();
            f += MathHelper.clamp_float((float)this.getChunkFromBlockCoords(var1, var3).inhabitedTime / 3600000.0F, 0.0F, 1.0F) * (flag ? 1.0F : 12.0F / 16.0F);
            f += f1 * 0.25F;
        }

        if (this.difficultySetting == EnumDifficulty.EASY || this.difficultySetting == EnumDifficulty.PEACEFUL) {
            f *= this.difficultySetting.getDifficultyId() / 2.0F;
        }

        return MathHelper.clamp_float(f, 0.0F, flag ? 1.5F : 1.0F);
    }

    public void func_147450_X() {
        for (IWorldAccess iworldaccess : (Iterable<IWorldAccess>) (Iterable) this.worldAccesses) {
            iworldaccess.onStaticEntitiesChanged();
        }
    }
}
