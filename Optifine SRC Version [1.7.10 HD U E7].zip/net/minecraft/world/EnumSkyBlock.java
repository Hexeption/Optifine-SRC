package net.minecraft.world;

public enum EnumSkyBlock {
    Sky(15),
    Block(0);

    public final int defaultLightValue;

    EnumSkyBlock(int var3) {
        this.defaultLightValue = var3;
    }
}
