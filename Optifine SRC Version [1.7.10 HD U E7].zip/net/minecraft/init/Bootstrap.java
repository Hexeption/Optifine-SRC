package net.minecraft.init;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDispenser;
import net.minecraft.block.BlockFire;
import net.minecraft.block.material.Material;
import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import net.minecraft.dispenser.BehaviorProjectileDispense;
import net.minecraft.dispenser.IBehaviorDispenseItem;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.dispenser.IPosition;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemDye;
import net.minecraft.item.ItemMonsterPlacer;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class Bootstrap {
    private static boolean alreadyRegistered = false;

    static void registerDispenserBehaviors() {
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.arrow, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                EntityArrow entityarrow = new EntityArrow(var1, var2.getX(), var2.getY(), var2.getZ());
                entityarrow.canBePickedUp = 1;
                return entityarrow;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.egg, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                return new EntityEgg(var1, var2.getX(), var2.getY(), var2.getZ());
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.snowball, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                return new EntitySnowball(var1, var2.getX(), var2.getY(), var2.getZ());
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.experience_bottle, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                return new EntityExpBottle(var1, var2.getX(), var2.getY(), var2.getZ());
            }

            @Override
            protected float func_82498_a() {
                return super.func_82498_a() * 0.5F;
            }

            @Override
            protected float func_82500_b() {
                return super.func_82500_b() * 1.25F;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.potionitem, new IBehaviorDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150843_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispense(IBlockSource var1, final ItemStack var2) {
                return ItemPotion.isSplash(var2.getMetadata()) ? (new BehaviorProjectileDispense() {
                    @Override
                    protected IProjectile getProjectileEntity(World var1, IPosition var2x) {
                        return new EntityPotion(var1, var2x.getX(), var2x.getY(), var2x.getZ(), var2.copy());
                    }

                    @Override
                    protected float func_82498_a() {
                        return super.func_82498_a() * 0.5F;
                    }

                    @Override
                    protected float func_82500_b() {
                        return super.func_82500_b() * 1.25F;
                    }
                }).dispense(var1, var2) : this.field_150843_b.dispense(var1, var2);
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.spawn_egg, new BehaviorDefaultDispenseItem() {
            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                double d0 = var1.getX() + enumfacing.getFrontOffsetX();
                double d1 = var1.getYInt() + 0.2F;
                double d2 = var1.getZ() + enumfacing.getFrontOffsetZ();
                Entity entity = ItemMonsterPlacer.spawnCreature(var1.getWorld(), var2.getMetadata(), d0, d1, d2);
                if (entity instanceof EntityLivingBase && var2.hasDisplayName()) {
                    ((EntityLiving)entity).setCustomNameTag(var2.getDisplayName());
                }

                var2.splitStack(1);
                return var2;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.fireworks, new BehaviorDefaultDispenseItem() {
            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                double d0 = var1.getX() + enumfacing.getFrontOffsetX();
                double d1 = var1.getYInt() + 0.2F;
                double d2 = var1.getZ() + enumfacing.getFrontOffsetZ();
                EntityFireworkRocket entityfireworkrocket = new EntityFireworkRocket(var1.getWorld(), d0, d1, d2, var2);
                var1.getWorld().spawnEntityInWorld(entityfireworkrocket);
                var2.splitStack(1);
                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                var1.getWorld().playAuxSFX(1002, var1.getXInt(), var1.getYInt(), var1.getZInt(), 0);
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.fire_charge, new BehaviorDefaultDispenseItem() {
            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                IPosition iposition = BlockDispenser.getIPositionFromBlockSource(var1);
                double d0 = iposition.getX() + enumfacing.getFrontOffsetX() * 0.3F;
                double d1 = iposition.getY() + enumfacing.getFrontOffsetX() * 0.3F;
                double d2 = iposition.getZ() + enumfacing.getFrontOffsetZ() * 0.3F;
                World world = var1.getWorld();
                Random random = world.rand;
                double d3 = random.nextGaussian() * 0.05 + enumfacing.getFrontOffsetX();
                double d4 = random.nextGaussian() * 0.05 + enumfacing.getFrontOffsetY();
                double d5 = random.nextGaussian() * 0.05 + enumfacing.getFrontOffsetZ();
                world.spawnEntityInWorld(new EntitySmallFireball(world, d0, d1, d2, d3, d4, d5));
                var2.splitStack(1);
                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                var1.getWorld().playAuxSFX(1009, var1.getXInt(), var1.getYInt(), var1.getZInt(), 0);
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.boat, new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150842_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                World world = var1.getWorld();
                double d0 = var1.getX() + enumfacing.getFrontOffsetX() * 1.125F;
                double d1 = var1.getY() + enumfacing.getFrontOffsetY() * 1.125F;
                double d2 = var1.getZ() + enumfacing.getFrontOffsetZ() * 1.125F;
                int i = var1.getXInt() + enumfacing.getFrontOffsetX();
                int j = var1.getYInt() + enumfacing.getFrontOffsetY();
                int k = var1.getZInt() + enumfacing.getFrontOffsetZ();
                Material material = world.getBlock(i, j, k).getMaterial();
                double d3;
                if (Material.water.equals(material)) {
                    d3 = 1.0;
                } else {
                    if (!Material.air.equals(material) || !Material.water.equals(world.getBlock(i, j - 1, k).getMaterial())) {
                        return this.field_150842_b.dispense(var1, var2);
                    }

                    d3 = 0.0;
                }

                EntityBoat entityboat = new EntityBoat(world, d0, d1 + d3, d2);
                world.spawnEntityInWorld(entityboat);
                var2.splitStack(1);
                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                var1.getWorld().playAuxSFX(1000, var1.getXInt(), var1.getYInt(), var1.getZInt(), 0);
            }
        });
        BehaviorDefaultDispenseItem behaviordefaultdispenseitem = new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150841_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                ItemBucket itembucket = (ItemBucket)var2.getItem();
                int i = var1.getXInt();
                int j = var1.getYInt();
                int k = var1.getZInt();
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                if (itembucket.tryPlaceContainedLiquid(
                    var1.getWorld(), i + enumfacing.getFrontOffsetX(), j + enumfacing.getFrontOffsetY(), k + enumfacing.getFrontOffsetZ()
                )) {
                    var2.setItem(Items.bucket);
                    var2.stackSize = 1;
                    return var2;
                } else {
                    return this.field_150841_b.dispense(var1, var2);
                }
            }
        };
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.lava_bucket, behaviordefaultdispenseitem);
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.water_bucket, behaviordefaultdispenseitem);
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.bucket, new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150840_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                World world = var1.getWorld();
                int i = var1.getXInt() + enumfacing.getFrontOffsetX();
                int j = var1.getYInt() + enumfacing.getFrontOffsetY();
                int k = var1.getZInt() + enumfacing.getFrontOffsetZ();
                Material material = world.getBlock(i, j, k).getMaterial();
                int l = world.getBlockMetadata(i, j, k);
                Item item;
                if (Material.water.equals(material) && l == 0) {
                    item = Items.water_bucket;
                } else {
                    if (!Material.lava.equals(material) || l != 0) {
                        return super.dispenseStack(var1, var2);
                    }

                    item = Items.lava_bucket;
                }

                world.setBlockToAir(i, j, k);
                if (--var2.stackSize == 0) {
                    var2.setItem(item);
                    var2.stackSize = 1;
                } else if (((TileEntityDispenser)var1.getBlockTileEntity()).func_146019_a(new ItemStack(item)) < 0) {
                    this.field_150840_b.dispense(var1, new ItemStack(item));
                }

                return var2;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.flint_and_steel, new BehaviorDefaultDispenseItem() {
            private boolean field_150839_b = true;

            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                World world = var1.getWorld();
                int i = var1.getXInt() + enumfacing.getFrontOffsetX();
                int j = var1.getYInt() + enumfacing.getFrontOffsetY();
                int k = var1.getZInt() + enumfacing.getFrontOffsetZ();
                if (world.isAirBlock(i, j, k)) {
                    world.setBlock(i, j, k, Blocks.fire);
                    if (var2.attemptDamageItem(1, world.rand)) {
                        var2.stackSize = 0;
                    }
                } else if (world.getBlock(i, j, k) == Blocks.tnt) {
                    Blocks.tnt.onBlockDestroyedByPlayer(world, i, j, k, 1);
                    world.setBlockToAir(i, j, k);
                } else {
                    this.field_150839_b = false;
                }

                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                if (this.field_150839_b) {
                    var1.getWorld().playAuxSFX(1000, var1.getXInt(), var1.getYInt(), var1.getZInt(), 0);
                } else {
                    var1.getWorld().playAuxSFX(1001, var1.getXInt(), var1.getYInt(), var1.getZInt(), 0);
                }
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.dye, new BehaviorDefaultDispenseItem() {
            private boolean field_150838_b = true;

            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                if (var2.getMetadata() == 15) {
                    EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                    World world = var1.getWorld();
                    int i = var1.getXInt() + enumfacing.getFrontOffsetX();
                    int j = var1.getYInt() + enumfacing.getFrontOffsetY();
                    int k = var1.getZInt() + enumfacing.getFrontOffsetZ();
                    if (ItemDye.func_150919_a(var2, world, i, j, k)) {
                        if (!world.isRemote) {
                            world.playAuxSFX(2005, i, j, k, 0);
                        }
                    } else {
                        this.field_150838_b = false;
                    }

                    return var2;
                } else {
                    return super.dispenseStack(var1, var2);
                }
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                if (this.field_150838_b) {
                    var1.getWorld().playAuxSFX(1000, var1.getXInt(), var1.getYInt(), var1.getZInt(), 0);
                } else {
                    var1.getWorld().playAuxSFX(1001, var1.getXInt(), var1.getYInt(), var1.getZInt(), 0);
                }
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.getItemFromBlock(Blocks.tnt), new BehaviorDefaultDispenseItem() {
            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacingDirection(var1.getBlockMetadata());
                World world = var1.getWorld();
                int i = var1.getXInt() + enumfacing.getFrontOffsetX();
                int j = var1.getYInt() + enumfacing.getFrontOffsetY();
                int k = var1.getZInt() + enumfacing.getFrontOffsetZ();
                EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, i + 0.5F, j + 0.5F, k + 0.5F, null);
                world.spawnEntityInWorld(entitytntprimed);
                var2.stackSize--;
                return var2;
            }
        });
    }

    public static void register() {
        if (!alreadyRegistered) {
            alreadyRegistered = true;
            Block.registerBlocks();
            BlockFire.func_149843_e();
            Item.registerItems();
            StatList.func_151178_a();
            registerDispenserBehaviors();
        }
    }
}
