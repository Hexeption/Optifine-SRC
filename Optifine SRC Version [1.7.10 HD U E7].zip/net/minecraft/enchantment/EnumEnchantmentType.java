package net.minecraft.enchantment;

import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public enum EnumEnchantmentType {
    all,
    armor,
    armor_feet,
    armor_legs,
    armor_torso,
    armor_head,
    weapon,
    digger,
    fishing_rod,
    breakable,
    bow;

    public boolean canEnchantItem(Item var1) {
        if (this == all) {
            return true;
        }

        if (this == breakable && var1.isDamageable()) {
            return true;
        }

        if (var1 instanceof ItemArmor) {
            if (this == armor) {
                return true;
            } else {
                ItemArmor itemarmor = (ItemArmor)var1;
                if (itemarmor.armorType == 0) {
                    return this == armor_head;
                } else if (itemarmor.armorType == 2) {
                    return this == armor_legs;
                } else if (itemarmor.armorType == 1) {
                    return this == armor_torso;
                } else {
                    return itemarmor.armorType == 3 ? this == armor_feet : false;
                }
            }
        } else if (var1 instanceof ItemSword) {
            return this == weapon;
        } else if (var1 instanceof ItemTool) {
            return this == digger;
        } else if (var1 instanceof ItemBow) {
            return this == bow;
        } else {
            return var1 instanceof ItemFishingRod ? this == fishing_rod : false;
        }
    }
}
