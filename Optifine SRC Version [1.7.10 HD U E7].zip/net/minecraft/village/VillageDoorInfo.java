package net.minecraft.village;

public class VillageDoorInfo {
    public final int posX;
    public final int posY;
    public final int posZ;
    public final int insideDirectionX;
    public final int insideDirectionZ;
    public int lastActivityTimestamp;
    public boolean isDetachedFromVillageFlag;
    private int doorOpeningRestrictionCounter;

    public VillageDoorInfo(int var1, int var2, int var3, int var4, int var5, int var6) {
        this.posX = var1;
        this.posY = var2;
        this.posZ = var3;
        this.insideDirectionX = var4;
        this.insideDirectionZ = var5;
        this.lastActivityTimestamp = var6;
    }

    public int getDistanceSquared(int var1, int var2, int var3) {
        int i = var1 - this.posX;
        int j = var2 - this.posY;
        int k = var3 - this.posZ;
        return i * i + j * j + k * k;
    }

    public int getInsideDistanceSquare(int var1, int var2, int var3) {
        int i = var1 - this.posX - this.insideDirectionX;
        int j = var2 - this.posY;
        int k = var3 - this.posZ - this.insideDirectionZ;
        return i * i + j * j + k * k;
    }

    public int getInsidePosX() {
        return this.posX + this.insideDirectionX;
    }

    public int getInsidePosY() {
        return this.posY;
    }

    public int getInsidePosZ() {
        return this.posZ + this.insideDirectionZ;
    }

    public boolean isInside(int var1, int var2) {
        int i = var1 - this.posX;
        int j = var2 - this.posZ;
        return i * this.insideDirectionX + j * this.insideDirectionZ >= 0;
    }

    public void resetDoorOpeningRestrictionCounter() {
        this.doorOpeningRestrictionCounter = 0;
    }

    public void incrementDoorOpeningRestrictionCounter() {
        this.doorOpeningRestrictionCounter++;
    }

    public int getDoorOpeningRestrictionCounter() {
        return this.doorOpeningRestrictionCounter;
    }
}
