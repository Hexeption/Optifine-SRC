package net.minecraft.village;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class Village {
    private World worldObj;
    private final List villageDoorInfoList = new ArrayList();
    private final ChunkCoordinates centerHelper = new ChunkCoordinates(0, 0, 0);
    private final ChunkCoordinates center = new ChunkCoordinates(0, 0, 0);
    private int villageRadius;
    private int lastAddDoorTimestamp;
    private int tickCounter;
    private int numVillagers;
    private int noBreedTicks;
    private TreeMap playerReputation = new TreeMap();
    private List villageAgressors = new ArrayList();
    private int numIronGolems;

    public Village() {
    }

    public Village(World var1) {
        this.worldObj = var1;
    }

    public void func_82691_a(World var1) {
        this.worldObj = var1;
    }

    public void tick(int var1) {
        this.tickCounter = var1;
        this.removeDeadAndOutOfRangeDoors();
        this.removeDeadAndOldAgressors();
        if (var1 % 20 == 0) {
            this.updateNumVillagers();
        }

        if (var1 % 30 == 0) {
            this.updateNumIronGolems();
        }

        int i = this.numVillagers / 10;
        if (this.numIronGolems < i && this.villageDoorInfoList.size() > 20 && this.worldObj.rand.nextInt(7000) == 0) {
            Vec3 vec3 = this.tryGetIronGolemSpawningLocation(
                MathHelper.floor_float(this.center.posX), MathHelper.floor_float(this.center.posY), MathHelper.floor_float(this.center.posZ), 2, 4, 2
            );
            if (vec3 != null) {
                EntityIronGolem entityirongolem = new EntityIronGolem(this.worldObj);
                entityirongolem.setPosition(vec3.xCoord, vec3.yCoord, vec3.zCoord);
                this.worldObj.spawnEntityInWorld(entityirongolem);
                this.numIronGolems++;
            }
        }
    }

    private Vec3 tryGetIronGolemSpawningLocation(int var1, int var2, int var3, int var4, int var5, int var6) {
        for (int i = 0; i < 10; i++) {
            int j = var1 + this.worldObj.rand.nextInt(16) - 8;
            int k = var2 + this.worldObj.rand.nextInt(6) - 3;
            int l = var3 + this.worldObj.rand.nextInt(16) - 8;
            if (this.isInRange(j, k, l) && this.isValidIronGolemSpawningLocation(j, k, l, var4, var5, var6)) {
                return Vec3.createVectorHelper(j, k, l);
            }
        }

        return null;
    }

    private boolean isValidIronGolemSpawningLocation(int var1, int var2, int var3, int var4, int var5, int var6) {
        if (!World.doesBlockHaveSolidTopSurface(this.worldObj, var1, var2 - 1, var3)) {
            return false;
        }

        int i = var1 - var4 / 2;
        int j = var3 - var6 / 2;

        for (int k = i; k < i + var4; k++) {
            for (int l = var2; l < var2 + var5; l++) {
                for (int i1 = j; i1 < j + var6; i1++) {
                    if (this.worldObj.getBlock(k, l, i1).isNormalCube()) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private void updateNumIronGolems() {
        List list = this.worldObj
            .getEntitiesWithinAABB(
                EntityIronGolem.class,
                AxisAlignedBB.getBoundingBox(
                    this.center.posX - this.villageRadius,
                    this.center.posY - 4,
                    this.center.posZ - this.villageRadius,
                    this.center.posX + this.villageRadius,
                    this.center.posY + 4,
                    this.center.posZ + this.villageRadius
                )
            );
        this.numIronGolems = list.size();
    }

    private void updateNumVillagers() {
        List list = this.worldObj
            .getEntitiesWithinAABB(
                EntityVillager.class,
                AxisAlignedBB.getBoundingBox(
                    this.center.posX - this.villageRadius,
                    this.center.posY - 4,
                    this.center.posZ - this.villageRadius,
                    this.center.posX + this.villageRadius,
                    this.center.posY + 4,
                    this.center.posZ + this.villageRadius
                )
            );
        this.numVillagers = list.size();
        if (this.numVillagers == 0) {
            this.playerReputation.clear();
        }
    }

    public ChunkCoordinates getCenter() {
        return this.center;
    }

    public int getVillageRadius() {
        return this.villageRadius;
    }

    public int getNumVillageDoors() {
        return this.villageDoorInfoList.size();
    }

    public int getTicksSinceLastDoorAdding() {
        return this.tickCounter - this.lastAddDoorTimestamp;
    }

    public int getNumVillagers() {
        return this.numVillagers;
    }

    public boolean isInRange(int var1, int var2, int var3) {
        return this.center.getDistanceSquared(var1, var2, var3) < this.villageRadius * this.villageRadius;
    }

    public List getVillageDoorInfoList() {
        return this.villageDoorInfoList;
    }

    public VillageDoorInfo findNearestDoor(int var1, int var2, int var3) {
        VillageDoorInfo villagedoorinfo = null;
        int i = Integer.MAX_VALUE;

        for (VillageDoorInfo villagedoorinfo1 : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            int j = villagedoorinfo1.getDistanceSquared(var1, var2, var3);
            if (j < i) {
                villagedoorinfo = villagedoorinfo1;
                i = j;
            }
        }

        return villagedoorinfo;
    }

    public VillageDoorInfo findNearestDoorUnrestricted(int var1, int var2, int var3) {
        VillageDoorInfo villagedoorinfo = null;
        int i = Integer.MAX_VALUE;

        for (VillageDoorInfo villagedoorinfo1 : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            int j = villagedoorinfo1.getDistanceSquared(var1, var2, var3);
            if (j > 256) {
                j *= 1000;
            } else {
                j = villagedoorinfo1.getDoorOpeningRestrictionCounter();
            }

            if (j < i) {
                villagedoorinfo = villagedoorinfo1;
                i = j;
            }
        }

        return villagedoorinfo;
    }

    public VillageDoorInfo getVillageDoorAt(int var1, int var2, int var3) {
        if (this.center.getDistanceSquared(var1, var2, var3) > this.villageRadius * this.villageRadius) {
            return null;
        }

        for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            if (villagedoorinfo.posX == var1 && villagedoorinfo.posZ == var3 && Math.abs(villagedoorinfo.posY - var2) <= 1) {
                return villagedoorinfo;
            }
        }

        return null;
    }

    public void addVillageDoorInfo(VillageDoorInfo var1) {
        this.villageDoorInfoList.add(var1);
        this.centerHelper.posX = this.centerHelper.posX + var1.posX;
        this.centerHelper.posY = this.centerHelper.posY + var1.posY;
        this.centerHelper.posZ = this.centerHelper.posZ + var1.posZ;
        this.updateVillageRadiusAndCenter();
        this.lastAddDoorTimestamp = var1.lastActivityTimestamp;
    }

    public boolean isAnnihilated() {
        return this.villageDoorInfoList.isEmpty();
    }

    public void addOrRenewAgressor(EntityLivingBase var1) {
        for (Village.VillageAgressor village$villageagressor : (Iterable<Village.VillageAgressor>) (Iterable) this.villageAgressors) {
            if (village$villageagressor.agressor == var1) {
                village$villageagressor.agressionTime = this.tickCounter;
                return;
            }
        }

        this.villageAgressors.add(new Village.VillageAgressor(var1, this.tickCounter));
    }

    public EntityLivingBase findNearestVillageAggressor(EntityLivingBase var1) {
        double d0 = Double.MAX_VALUE;
        Village.VillageAgressor village$villageagressor = null;

        for (int i = 0; i < this.villageAgressors.size(); i++) {
            Village.VillageAgressor village$villageagressor1 = (Village.VillageAgressor)this.villageAgressors.get(i);
            double d1 = village$villageagressor1.agressor.getDistanceSqToEntity(var1);
            if (!(d1 > d0)) {
                village$villageagressor = village$villageagressor1;
                d0 = d1;
            }
        }

        return village$villageagressor != null ? village$villageagressor.agressor : null;
    }

    public EntityPlayer func_82685_c(EntityLivingBase var1) {
        double d0 = Double.MAX_VALUE;
        EntityPlayer entityplayer = null;

        for (String s : (Iterable<String>) (Iterable) this.playerReputation.keySet()) {
            if (this.isPlayerReputationTooLow(s)) {
                EntityPlayer entityplayer1 = this.worldObj.getPlayerEntityByName(s);
                if (entityplayer1 != null) {
                    double d1 = entityplayer1.getDistanceSqToEntity(var1);
                    if (!(d1 > d0)) {
                        entityplayer = entityplayer1;
                        d0 = d1;
                    }
                }
            }
        }

        return entityplayer;
    }

    private void removeDeadAndOldAgressors() {
        Iterator iterator = this.villageAgressors.iterator();

        while (iterator.hasNext()) {
            Village.VillageAgressor village$villageagressor = (Village.VillageAgressor)iterator.next();
            if (!village$villageagressor.agressor.isEntityAlive() || Math.abs(this.tickCounter - village$villageagressor.agressionTime) > 300) {
                iterator.remove();
            }
        }
    }

    private void removeDeadAndOutOfRangeDoors() {
        boolean flag = false;
        boolean flag1 = this.worldObj.rand.nextInt(50) == 0;
        Iterator iterator = this.villageDoorInfoList.iterator();

        while (iterator.hasNext()) {
            VillageDoorInfo villagedoorinfo = (VillageDoorInfo)iterator.next();
            if (flag1) {
                villagedoorinfo.resetDoorOpeningRestrictionCounter();
            }

            if (!this.isBlockDoor(villagedoorinfo.posX, villagedoorinfo.posY, villagedoorinfo.posZ)
                || Math.abs(this.tickCounter - villagedoorinfo.lastActivityTimestamp) > 1200) {
                this.centerHelper.posX = this.centerHelper.posX - villagedoorinfo.posX;
                this.centerHelper.posY = this.centerHelper.posY - villagedoorinfo.posY;
                this.centerHelper.posZ = this.centerHelper.posZ - villagedoorinfo.posZ;
                flag = true;
                villagedoorinfo.isDetachedFromVillageFlag = true;
                iterator.remove();
            }
        }

        if (flag) {
            this.updateVillageRadiusAndCenter();
        }
    }

    private boolean isBlockDoor(int var1, int var2, int var3) {
        return this.worldObj.getBlock(var1, var2, var3) == Blocks.wooden_door;
    }

    private void updateVillageRadiusAndCenter() {
        int i = this.villageDoorInfoList.size();
        if (i == 0) {
            this.center.set(0, 0, 0);
            this.villageRadius = 0;
        } else {
            this.center.set(this.centerHelper.posX / i, this.centerHelper.posY / i, this.centerHelper.posZ / i);
            int j = 0;

            for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
                j = Math.max(villagedoorinfo.getDistanceSquared(this.center.posX, this.center.posY, this.center.posZ), j);
            }

            this.villageRadius = Math.max(32, (int)Math.sqrt(j) + 1);
        }
    }

    public int getReputationForPlayer(String var1) {
        Integer integer = (Integer)this.playerReputation.get(var1);
        return integer != null ? integer : 0;
    }

    public int setReputationForPlayer(String var1, int var2) {
        int i = this.getReputationForPlayer(var1);
        int j = MathHelper.clamp_int(i + var2, -30, 10);
        this.playerReputation.put(var1, j);
        return j;
    }

    public boolean isPlayerReputationTooLow(String var1) {
        return this.getReputationForPlayer(var1) <= -15;
    }

    public void readVillageDataFromNBT(NBTTagCompound var1) {
        this.numVillagers = var1.getInteger("PopSize");
        this.villageRadius = var1.getInteger("Radius");
        this.numIronGolems = var1.getInteger("Golems");
        this.lastAddDoorTimestamp = var1.getInteger("Stable");
        this.tickCounter = var1.getInteger("Tick");
        this.noBreedTicks = var1.getInteger("MTick");
        this.center.posX = var1.getInteger("CX");
        this.center.posY = var1.getInteger("CY");
        this.center.posZ = var1.getInteger("CZ");
        this.centerHelper.posX = var1.getInteger("ACX");
        this.centerHelper.posY = var1.getInteger("ACY");
        this.centerHelper.posZ = var1.getInteger("ACZ");
        NBTTagList nbttaglist = var1.getTagList("Doors", 10);

        for (int i = 0; i < nbttaglist.tagCount(); i++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            VillageDoorInfo villagedoorinfo = new VillageDoorInfo(
                nbttagcompound.getInteger("X"),
                nbttagcompound.getInteger("Y"),
                nbttagcompound.getInteger("Z"),
                nbttagcompound.getInteger("IDX"),
                nbttagcompound.getInteger("IDZ"),
                nbttagcompound.getInteger("TS")
            );
            this.villageDoorInfoList.add(villagedoorinfo);
        }

        NBTTagList nbttaglist1 = var1.getTagList("Players", 10);

        for (int j = 0; j < nbttaglist1.tagCount(); j++) {
            NBTTagCompound nbttagcompound1 = nbttaglist1.getCompoundTagAt(j);
            this.playerReputation.put(nbttagcompound1.getString("Name"), nbttagcompound1.getInteger("S"));
        }
    }

    public void writeVillageDataToNBT(NBTTagCompound var1) {
        var1.setInteger("PopSize", this.numVillagers);
        var1.setInteger("Radius", this.villageRadius);
        var1.setInteger("Golems", this.numIronGolems);
        var1.setInteger("Stable", this.lastAddDoorTimestamp);
        var1.setInteger("Tick", this.tickCounter);
        var1.setInteger("MTick", this.noBreedTicks);
        var1.setInteger("CX", this.center.posX);
        var1.setInteger("CY", this.center.posY);
        var1.setInteger("CZ", this.center.posZ);
        var1.setInteger("ACX", this.centerHelper.posX);
        var1.setInteger("ACY", this.centerHelper.posY);
        var1.setInteger("ACZ", this.centerHelper.posZ);
        NBTTagList nbttaglist = new NBTTagList();

        for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            nbttagcompound.setInteger("X", villagedoorinfo.posX);
            nbttagcompound.setInteger("Y", villagedoorinfo.posY);
            nbttagcompound.setInteger("Z", villagedoorinfo.posZ);
            nbttagcompound.setInteger("IDX", villagedoorinfo.insideDirectionX);
            nbttagcompound.setInteger("IDZ", villagedoorinfo.insideDirectionZ);
            nbttagcompound.setInteger("TS", villagedoorinfo.lastActivityTimestamp);
            nbttaglist.appendTag(nbttagcompound);
        }

        var1.setTag("Doors", nbttaglist);
        NBTTagList nbttaglist1 = new NBTTagList();

        for (String s : (Iterable<String>) (Iterable) this.playerReputation.keySet()) {
            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            nbttagcompound1.setString("Name", s);
            nbttagcompound1.setInteger("S", (Integer)this.playerReputation.get(s));
            nbttaglist1.appendTag(nbttagcompound1);
        }

        var1.setTag("Players", nbttaglist1);
    }

    public void endMatingSeason() {
        this.noBreedTicks = this.tickCounter;
    }

    public boolean isMatingSeason() {
        return this.noBreedTicks == 0 || this.tickCounter - this.noBreedTicks >= 3600;
    }

    public void setDefaultPlayerReputation(int var1) {
        for (String s : (Iterable<String>) (Iterable) this.playerReputation.keySet()) {
            this.setReputationForPlayer(s, var1);
        }
    }

    class VillageAgressor {
        public EntityLivingBase agressor;
        public int agressionTime;

        VillageAgressor(EntityLivingBase var2, int var3) {
            this.agressor = var2;
            this.agressionTime = var3;
        }
    }
}
