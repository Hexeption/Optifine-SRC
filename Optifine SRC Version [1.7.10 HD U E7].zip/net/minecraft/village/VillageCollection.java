package net.minecraft.village;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.BlockDoor;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;

public class VillageCollection extends WorldSavedData {
    private World worldObj;
    private final List villagerPositionsList = new ArrayList();
    private final List newDoors = new ArrayList();
    private final List villageList = new ArrayList();
    private int tickCounter;

    public VillageCollection(String var1) {
        super(var1);
    }

    public VillageCollection(World var1) {
        super("villages");
        this.worldObj = var1;
        this.markDirty();
    }

    public void func_82566_a(World var1) {
        this.worldObj = var1;

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            village.func_82691_a(var1);
        }
    }

    public void addVillagerPosition(int var1, int var2, int var3) {
        if (this.villagerPositionsList.size() <= 64) {
            if (!this.isVillagerPositionPresent(var1, var2, var3)) {
                this.villagerPositionsList.add(new ChunkCoordinates(var1, var2, var3));
            }
        }
    }

    public void tick() {
        this.tickCounter++;

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            village.tick(this.tickCounter);
        }

        this.removeAnnihilatedVillages();
        this.dropOldestVillagerPosition();
        this.addNewDoorsToVillageOrCreateVillage();
        if (this.tickCounter % 400 == 0) {
            this.markDirty();
        }
    }

    private void removeAnnihilatedVillages() {
        Iterator iterator = this.villageList.iterator();

        while (iterator.hasNext()) {
            Village village = (Village)iterator.next();
            if (village.isAnnihilated()) {
                iterator.remove();
                this.markDirty();
            }
        }
    }

    public List getVillageList() {
        return this.villageList;
    }

    public Village findNearestVillage(int var1, int var2, int var3, int var4) {
        Village village = null;
        float f = Float.MAX_VALUE;

        for (Village village1 : (Iterable<Village>) (Iterable) this.villageList) {
            float f1 = village1.getCenter().getDistanceSquared(var1, var2, var3);
            if (!(f1 >= f)) {
                float f2 = var4 + village1.getVillageRadius();
                if (!(f1 > f2 * f2)) {
                    village = village1;
                    f = f1;
                }
            }
        }

        return village;
    }

    private void dropOldestVillagerPosition() {
        if (!this.villagerPositionsList.isEmpty()) {
            this.addUnassignedWoodenDoorsAroundToNewDoorsList((ChunkCoordinates)this.villagerPositionsList.remove(0));
        }
    }

    private void addNewDoorsToVillageOrCreateVillage() {
        for (int i = 0; i < this.newDoors.size(); i++) {
            VillageDoorInfo villagedoorinfo = (VillageDoorInfo)this.newDoors.get(i);
            boolean flag = false;

            for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
                int j = (int)village.getCenter().getDistanceSquared(villagedoorinfo.posX, villagedoorinfo.posY, villagedoorinfo.posZ);
                int k = 32 + village.getVillageRadius();
                if (j <= k * k) {
                    village.addVillageDoorInfo(villagedoorinfo);
                    flag = true;
                    break;
                }
            }

            if (!flag) {
                Village village1 = new Village(this.worldObj);
                village1.addVillageDoorInfo(villagedoorinfo);
                this.villageList.add(village1);
                this.markDirty();
            }
        }

        this.newDoors.clear();
    }

    private void addUnassignedWoodenDoorsAroundToNewDoorsList(ChunkCoordinates var1) {
        byte b0 = 16;
        byte b1 = 4;
        byte b2 = 16;

        for (int i = var1.posX - b0; i < var1.posX + b0; i++) {
            for (int j = var1.posY - b1; j < var1.posY + b1; j++) {
                for (int k = var1.posZ - b2; k < var1.posZ + b2; k++) {
                    if (this.isWoodenDoorAt(i, j, k)) {
                        VillageDoorInfo villagedoorinfo = this.getVillageDoorAt(i, j, k);
                        if (villagedoorinfo == null) {
                            this.addDoorToNewListIfAppropriate(i, j, k);
                        } else {
                            villagedoorinfo.lastActivityTimestamp = this.tickCounter;
                        }
                    }
                }
            }
        }
    }

    private VillageDoorInfo getVillageDoorAt(int var1, int var2, int var3) {
        for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.newDoors) {
            if (villagedoorinfo.posX == var1 && villagedoorinfo.posZ == var3 && Math.abs(villagedoorinfo.posY - var2) <= 1) {
                return villagedoorinfo;
            }
        }

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            VillageDoorInfo villagedoorinfo1 = village.getVillageDoorAt(var1, var2, var3);
            if (villagedoorinfo1 != null) {
                return villagedoorinfo1;
            }
        }

        return null;
    }

    private void addDoorToNewListIfAppropriate(int var1, int var2, int var3) {
        int i = ((BlockDoor)Blocks.wooden_door).func_150013_e(this.worldObj, var1, var2, var3);
        if (i != 0 && i != 2) {
            int l = 0;

            for (int j1 = -5; j1 < 0; j1++) {
                if (this.worldObj.canBlockSeeTheSky(var1, var2, var3 + j1)) {
                    l--;
                }
            }

            for (int k1 = 1; k1 <= 5; k1++) {
                if (this.worldObj.canBlockSeeTheSky(var1, var2, var3 + k1)) {
                    l++;
                }
            }

            if (l != 0) {
                this.newDoors.add(new VillageDoorInfo(var1, var2, var3, 0, l > 0 ? -2 : 2, this.tickCounter));
            }
        } else {
            int j = 0;

            for (int k = -5; k < 0; k++) {
                if (this.worldObj.canBlockSeeTheSky(var1 + k, var2, var3)) {
                    j--;
                }
            }

            for (int i1 = 1; i1 <= 5; i1++) {
                if (this.worldObj.canBlockSeeTheSky(var1 + i1, var2, var3)) {
                    j++;
                }
            }

            if (j != 0) {
                this.newDoors.add(new VillageDoorInfo(var1, var2, var3, j > 0 ? -2 : 2, 0, this.tickCounter));
            }
        }
    }

    private boolean isVillagerPositionPresent(int var1, int var2, int var3) {
        for (ChunkCoordinates chunkcoordinates : (Iterable<ChunkCoordinates>) (Iterable) this.villagerPositionsList) {
            if (chunkcoordinates.posX == var1 && chunkcoordinates.posY == var2 && chunkcoordinates.posZ == var3) {
                return true;
            }
        }

        return false;
    }

    private boolean isWoodenDoorAt(int var1, int var2, int var3) {
        return this.worldObj.getBlock(var1, var2, var3) == Blocks.wooden_door;
    }

    @Override
    public void readFromNBT(NBTTagCompound var1) {
        this.tickCounter = var1.getInteger("Tick");
        NBTTagList nbttaglist = var1.getTagList("Villages", 10);

        for (int i = 0; i < nbttaglist.tagCount(); i++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            Village village = new Village();
            village.readVillageDataFromNBT(nbttagcompound);
            this.villageList.add(village);
        }
    }

    @Override
    public void writeToNBT(NBTTagCompound var1) {
        var1.setInteger("Tick", this.tickCounter);
        NBTTagList nbttaglist = new NBTTagList();

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            village.writeVillageDataToNBT(nbttagcompound);
            nbttaglist.appendTag(nbttagcompound);
        }

        var1.setTag("Villages", nbttaglist);
    }
}
