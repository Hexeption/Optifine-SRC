package net.minecraft.network;

import com.google.common.collect.BiMap;
import com.google.common.collect.Queues;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.local.LocalChannel;
import io.netty.channel.local.LocalServerChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.TimeoutException;
import io.netty.util.AttributeKey;
import io.netty.util.concurrent.GenericFutureListener;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.util.Queue;
import javax.crypto.SecretKey;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.CryptManager;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MessageDeserializer;
import net.minecraft.util.MessageDeserializer2;
import net.minecraft.util.MessageSerializer;
import net.minecraft.util.MessageSerializer2;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class NetworkManager extends SimpleChannelInboundHandler {
    private static final Logger logger = LogManager.getLogger();
    public static final Marker logMarkerNetwork = MarkerManager.getMarker("NETWORK");
    public static final Marker logMarkerPackets = MarkerManager.getMarker("NETWORK_PACKETS", logMarkerNetwork);
    public static final Marker logMarkerStat = MarkerManager.getMarker("NETWORK_STAT", logMarkerNetwork);
    public static final AttributeKey attrKeyConnectionState = new AttributeKey("protocol");
    public static final AttributeKey attrKeyReceivable = new AttributeKey("receivable_packets");
    public static final AttributeKey attrKeySendable = new AttributeKey("sendable_packets");
    public static final NioEventLoopGroup eventLoops = new NioEventLoopGroup(
        0, new ThreadFactoryBuilder().setNameFormat("Netty Client IO #%d").setDaemon(true).build()
    );
    public static final NetworkStatistics STATISTICS = new NetworkStatistics();
    private final boolean isClientSide;
    private final Queue receivedPacketsQueue = Queues.newConcurrentLinkedQueue();
    private final Queue outboundPacketsQueue = Queues.newConcurrentLinkedQueue();
    private Channel channel;
    private SocketAddress socketAddress;
    private INetHandler packetListener;
    private EnumConnectionState connectionState;
    private IChatComponent terminationReason;
    private boolean isEncrypted;

    public NetworkManager(boolean var1) {
        this.isClientSide = var1;
    }

    @Override
    public void channelActive(ChannelHandlerContext var1) throws Exception {
        super.channelActive(var1);
        this.channel = var1.channel();
        this.socketAddress = this.channel.remoteAddress();
        this.setConnectionState(EnumConnectionState.HANDSHAKING);
    }

    public void setConnectionState(EnumConnectionState var1) {
        this.connectionState = ((EnumConnectionState) this.channel.attr(attrKeyConnectionState).getAndSet(var1));
        this.channel.attr(attrKeyReceivable).set(var1.func_150757_a(this.isClientSide));
        this.channel.attr(attrKeySendable).set(var1.func_150754_b(this.isClientSide));
        this.channel.config().setAutoRead(true);
        logger.debug("Enabled auto read");
    }

    @Override
    public void channelInactive(ChannelHandlerContext var1) {
        this.closeChannel(new ChatComponentTranslation("disconnect.endOfStream"));
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext var1, Throwable var2) {
        ChatComponentTranslation chatcomponenttranslation;
        if (var2 instanceof TimeoutException) {
            chatcomponenttranslation = new ChatComponentTranslation("disconnect.timeout");
        } else {
            chatcomponenttranslation = new ChatComponentTranslation("disconnect.genericReason", "Internal Exception: " + var2);
        }

        this.closeChannel(chatcomponenttranslation);
    }

    protected void channelRead0(ChannelHandlerContext var1, Packet var2) {
        if (this.channel.isOpen()) {
            if (var2.hasPriority()) {
                var2.processPacket(this.packetListener);
            } else {
                this.receivedPacketsQueue.add(var2);
            }
        }
    }

    public void setNetHandler(INetHandler var1) {
        Validate.notNull(var1, "packetListener");
        logger.debug("Set listener of {} to {}", this, var1);
        this.packetListener = var1;
    }

    public void scheduleOutboundPacket(Packet var1, GenericFutureListener... var2) {
        if (this.channel != null && this.channel.isOpen()) {
            this.flushOutboundQueue();
            this.dispatchPacket(var1, var2);
        } else {
            this.outboundPacketsQueue.add(new NetworkManager.InboundHandlerTuplePacketListener(var1, var2));
        }
    }

    private void dispatchPacket(final Packet var1, final GenericFutureListener[] var2) {
        final EnumConnectionState enumconnectionstate = EnumConnectionState.getFromPacket(var1);
        final EnumConnectionState enumconnectionstate1 = ((EnumConnectionState) this.channel.attr(attrKeyConnectionState).get());
        if (enumconnectionstate1 != enumconnectionstate) {
            logger.debug("Disabled auto read");
            this.channel.config().setAutoRead(false);
        }

        if (this.channel.eventLoop().inEventLoop()) {
            if (enumconnectionstate != enumconnectionstate1) {
                this.setConnectionState(enumconnectionstate);
            }

            this.channel.writeAndFlush(var1).addListeners(var2).addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
        } else {
            this.channel.eventLoop().execute(new Runnable() {
                @Override
                public void run() {
                    if (enumconnectionstate != enumconnectionstate1) {
                        NetworkManager.this.setConnectionState(enumconnectionstate);
                    }

                    NetworkManager.this.channel.writeAndFlush(var1).addListeners(var2).addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
                }
            });
        }
    }

    private void flushOutboundQueue() {
        if (this.channel != null && this.channel.isOpen()) {
            while (!this.outboundPacketsQueue.isEmpty()) {
                NetworkManager.InboundHandlerTuplePacketListener networkmanager$inboundhandlertuplepacketlistener = (NetworkManager.InboundHandlerTuplePacketListener)this.outboundPacketsQueue
                    .poll();
                this.dispatchPacket(networkmanager$inboundhandlertuplepacketlistener.packet, networkmanager$inboundhandlertuplepacketlistener.futureListeners);
            }
        }
    }

    public void processReceivedPackets() {
        this.flushOutboundQueue();
        EnumConnectionState enumconnectionstate = ((EnumConnectionState) this.channel.attr(attrKeyConnectionState).get());
        if (this.connectionState != enumconnectionstate) {
            if (this.connectionState != null) {
                this.packetListener.onConnectionStateTransition(this.connectionState, enumconnectionstate);
            }

            this.connectionState = enumconnectionstate;
        }

        if (this.packetListener != null) {
            for (int i = 1000; !this.receivedPacketsQueue.isEmpty() && i >= 0; i--) {
                Packet packet = (Packet)this.receivedPacketsQueue.poll();
                packet.processPacket(this.packetListener);
            }

            this.packetListener.onNetworkTick();
        }

        this.channel.flush();
    }

    public SocketAddress getRemoteAddress() {
        return this.socketAddress;
    }

    public void closeChannel(IChatComponent var1) {
        if (this.channel.isOpen()) {
            this.channel.close();
            this.terminationReason = var1;
        }
    }

    public boolean isLocalChannel() {
        return this.channel instanceof LocalChannel || this.channel instanceof LocalServerChannel;
    }

    public static NetworkManager provideLanClient(InetAddress var0, int var1) {
        final NetworkManager networkmanager = new NetworkManager(true);
        new Bootstrap()
            .group(eventLoops)
            .handler(
                new ChannelInitializer() {
                    @Override
                    protected void initChannel(Channel var1) {
                        try {
                            var1.config().setOption(ChannelOption.IP_TOS, 24);
                        } catch (ChannelException channelexception1) {
                        }

                        try {
                            var1.config().setOption(ChannelOption.TCP_NODELAY, false);
                        } catch (ChannelException channelexception) {
                        }

                        var1.pipeline()
                            .addLast("timeout", new ReadTimeoutHandler(20))
                            .addLast("splitter", new MessageDeserializer2())
                            .addLast("decoder", new MessageDeserializer(NetworkManager.STATISTICS))
                            .addLast("prepender", new MessageSerializer2())
                            .addLast("encoder", new MessageSerializer(NetworkManager.STATISTICS))
                            .addLast("packet_handler", networkmanager);
                    }
                }
            )
            .channel(NioSocketChannel.class)
            .connect(var0, var1)
            .syncUninterruptibly();
        return networkmanager;
    }

    public static NetworkManager provideLocalClient(SocketAddress var0) {
        final NetworkManager networkmanager = new NetworkManager(true);
        new Bootstrap().group(eventLoops).handler(new ChannelInitializer() {
            @Override
            protected void initChannel(Channel var1) {
                var1.pipeline().addLast("packet_handler", networkmanager);
            }
        }).channel(LocalChannel.class).connect(var0).syncUninterruptibly();
        return networkmanager;
    }

    public void enableEncryption(SecretKey var1) {
        this.channel.pipeline().addBefore("splitter", "decrypt", new NettyEncryptingDecoder(CryptManager.func_151229_a(2, var1)));
        this.channel.pipeline().addBefore("prepender", "encrypt", new NettyEncryptingEncoder(CryptManager.func_151229_a(1, var1)));
        this.isEncrypted = true;
    }

    public boolean isChannelOpen() {
        return this.channel != null && this.channel.isOpen();
    }

    public INetHandler getNetHandler() {
        return this.packetListener;
    }

    public IChatComponent getExitMessage() {
        return this.terminationReason;
    }

    public void disableAutoRead() {
        this.channel.config().setAutoRead(false);
    }

    @Override
    protected void channelRead0(ChannelHandlerContext var1, Object var2) {
        this.channelRead0(var1, (Packet)var2);
    }

    static class InboundHandlerTuplePacketListener {
        private final Packet packet;
        private final GenericFutureListener[] futureListeners;

        public InboundHandlerTuplePacketListener(Packet var1, GenericFutureListener... var2) {
            this.packet = var1;
            this.futureListeners = var2;
        }
    }
}
