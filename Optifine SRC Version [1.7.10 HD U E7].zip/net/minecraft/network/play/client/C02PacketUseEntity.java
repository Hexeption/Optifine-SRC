package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.world.World;

public class C02PacketUseEntity extends Packet {
    private int entityId;
    private C02PacketUseEntity.Action action;

    public C02PacketUseEntity() {
    }

    public C02PacketUseEntity(Entity var1, C02PacketUseEntity.Action var2) {
        this.entityId = var1.getEntityId();
        this.action = var2;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.entityId = var1.readInt();
        this.action = C02PacketUseEntity.Action.ACTIONS[var1.readByte() % C02PacketUseEntity.Action.ACTIONS.length];
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.entityId);
        var1.writeByte(this.action.id);
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processUseEntity(this);
    }

    public Entity getEntityFromWorld(World var1) {
        return var1.getEntityByID(this.entityId);
    }

    public C02PacketUseEntity.Action getAction() {
        return this.action;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }

    public enum Action {
        INTERACT(0),
        ATTACK(1);

        private static final C02PacketUseEntity.Action[] ACTIONS = new C02PacketUseEntity.Action[values().length];
        private final int id;

        Action(int var3) {
            this.id = var3;
        }

        static {
            for (C02PacketUseEntity.Action c02packetuseentity$action : values()) {
                ACTIONS[c02packetuseentity$action.id] = c02packetuseentity$action;
            }
        }
    }
}
