package net.minecraft.network.play.client;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C17PacketCustomPayload extends Packet {
    private String channel;
    private int length;
    private byte[] data;

    public C17PacketCustomPayload() {
    }

    public C17PacketCustomPayload(String var1, ByteBuf var2) {
        this(var1, var2.array());
    }

    public C17PacketCustomPayload(String var1, byte[] var2) {
        this.channel = var1;
        this.data = var2;
        if (var2 != null) {
            this.length = var2.length;
            if (this.length >= Short.MAX_VALUE) {
                throw new IllegalArgumentException("Payload may not be larger than 32k");
            }
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.channel = var1.readStringFromBuffer(20);
        this.length = var1.readShort();
        if (this.length > 0 && this.length < Short.MAX_VALUE) {
            this.data = new byte[this.length];
            var1.readBytes(this.data);
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeStringToBuffer(this.channel);
        var1.writeShort((short)this.length);
        if (this.data != null) {
            var1.writeBytes(this.data);
        }
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processVanilla250Packet(this);
    }

    public String getChannel() {
        return this.channel;
    }

    public byte[] getData() {
        return this.data;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
