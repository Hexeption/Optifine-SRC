package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import org.apache.commons.lang3.StringUtils;

public class C14PacketTabComplete extends Packet {
    private String message;

    public C14PacketTabComplete() {
    }

    public C14PacketTabComplete(String var1) {
        this.message = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.message = var1.readStringFromBuffer(Short.MAX_VALUE);
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeStringToBuffer(StringUtils.substring(this.message, 0, Short.MAX_VALUE));
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processTabComplete(this);
    }

    public String getMessage() {
        return this.message;
    }

    @Override
    public String serialize() {
        return String.format("message='%s'", this.message);
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
