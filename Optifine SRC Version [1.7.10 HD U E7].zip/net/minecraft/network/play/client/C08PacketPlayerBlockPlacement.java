package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.item.ItemStack;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C08PacketPlayerBlockPlacement extends Packet {
    private int placedBlockX;
    private int placedBlockY;
    private int placedBlockZ;
    private int placedBlockDirection;
    private ItemStack stack;
    private float facingX;
    private float facingY;
    private float facingZ;

    public C08PacketPlayerBlockPlacement() {
    }

    public C08PacketPlayerBlockPlacement(int var1, int var2, int var3, int var4, ItemStack var5, float var6, float var7, float var8) {
        this.placedBlockX = var1;
        this.placedBlockY = var2;
        this.placedBlockZ = var3;
        this.placedBlockDirection = var4;
        this.stack = var5 != null ? var5.copy() : null;
        this.facingX = var6;
        this.facingY = var7;
        this.facingZ = var8;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.placedBlockX = var1.readInt();
        this.placedBlockY = var1.readUnsignedByte();
        this.placedBlockZ = var1.readInt();
        this.placedBlockDirection = var1.readUnsignedByte();
        this.stack = var1.readItemStackFromBuffer();
        this.facingX = var1.readUnsignedByte() / 16.0F;
        this.facingY = var1.readUnsignedByte() / 16.0F;
        this.facingZ = var1.readUnsignedByte() / 16.0F;
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.placedBlockX);
        var1.writeByte(this.placedBlockY);
        var1.writeInt(this.placedBlockZ);
        var1.writeByte(this.placedBlockDirection);
        var1.writeItemStackToBuffer(this.stack);
        var1.writeByte((int)(this.facingX * 16.0F));
        var1.writeByte((int)(this.facingY * 16.0F));
        var1.writeByte((int)(this.facingZ * 16.0F));
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processPlayerBlockPlacement(this);
    }

    public int getPlacedBlockX() {
        return this.placedBlockX;
    }

    public int getPlacedBlockY() {
        return this.placedBlockY;
    }

    public int getPlacedBlockZ() {
        return this.placedBlockZ;
    }

    public int getPlacedBlockDirection() {
        return this.placedBlockDirection;
    }

    public ItemStack getStack() {
        return this.stack;
    }

    public float getPlacedBlockOffsetX() {
        return this.facingX;
    }

    public float getPlacedBlockOffsetY() {
        return this.facingY;
    }

    public float getPlacedBlockOffsetZ() {
        return this.facingZ;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
