package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.world.EnumDifficulty;

public class C15PacketClientSettings extends Packet {
    private String lang;
    private int view;
    private EntityPlayer.EnumChatVisibility chatVisibility;
    private boolean enableColors;
    private EnumDifficulty difficulty;
    private boolean showCape;

    public C15PacketClientSettings() {
    }

    public C15PacketClientSettings(String var1, int var2, EntityPlayer.EnumChatVisibility var3, boolean var4, EnumDifficulty var5, boolean var6) {
        this.lang = var1;
        this.view = var2;
        this.chatVisibility = var3;
        this.enableColors = var4;
        this.difficulty = var5;
        this.showCape = var6;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.lang = var1.readStringFromBuffer(7);
        this.view = var1.readByte();
        this.chatVisibility = EntityPlayer.EnumChatVisibility.getEnumChatVisibility(var1.readByte());
        this.enableColors = var1.readBoolean();
        this.difficulty = EnumDifficulty.getDifficultyEnum(var1.readByte());
        this.showCape = var1.readBoolean();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeStringToBuffer(this.lang);
        var1.writeByte(this.view);
        var1.writeByte(this.chatVisibility.getChatVisibility());
        var1.writeBoolean(this.enableColors);
        var1.writeByte(this.difficulty.getDifficultyId());
        var1.writeBoolean(this.showCape);
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processClientSettings(this);
    }

    public String getLang() {
        return this.lang;
    }

    public int getView() {
        return this.view;
    }

    public EntityPlayer.EnumChatVisibility getChatVisibility() {
        return this.chatVisibility;
    }

    public boolean isColorsEnabled() {
        return this.enableColors;
    }

    public EnumDifficulty getDifficulty() {
        return this.difficulty;
    }

    public boolean isShowCape() {
        return this.showCape;
    }

    @Override
    public String serialize() {
        return String.format(
            "lang='%s', view=%d, chat=%s, col=%b, difficulty=%s, cape=%b",
            this.lang,
            this.view,
            this.chatVisibility,
            this.enableColors,
            this.difficulty,
            this.showCape
        );
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
