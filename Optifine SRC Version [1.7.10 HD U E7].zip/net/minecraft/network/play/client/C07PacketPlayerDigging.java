package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C07PacketPlayerDigging extends Packet {
    private int diggedBlockX;
    private int diggedBlockY;
    private int diggedBlockZ;
    private int diggingBlockFace;
    private int status;

    public C07PacketPlayerDigging() {
    }

    public C07PacketPlayerDigging(int var1, int var2, int var3, int var4, int var5) {
        this.status = var1;
        this.diggedBlockX = var2;
        this.diggedBlockY = var3;
        this.diggedBlockZ = var4;
        this.diggingBlockFace = var5;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.status = var1.readUnsignedByte();
        this.diggedBlockX = var1.readInt();
        this.diggedBlockY = var1.readUnsignedByte();
        this.diggedBlockZ = var1.readInt();
        this.diggingBlockFace = var1.readUnsignedByte();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeByte(this.status);
        var1.writeInt(this.diggedBlockX);
        var1.writeByte(this.diggedBlockY);
        var1.writeInt(this.diggedBlockZ);
        var1.writeByte(this.diggingBlockFace);
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processPlayerDigging(this);
    }

    public int getDiggedBlockX() {
        return this.diggedBlockX;
    }

    public int getDiggedBlockY() {
        return this.diggedBlockY;
    }

    public int getDiggedBlockZ() {
        return this.diggedBlockZ;
    }

    public int getDiggingBlockFace() {
        return this.diggingBlockFace;
    }

    public int getDiggedBlockStatus() {
        return this.status;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
