package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C12PacketUpdateSign extends Packet {
    private int x;
    private int y;
    private int z;
    private String[] lines;

    public C12PacketUpdateSign() {
    }

    public C12PacketUpdateSign(int var1, int var2, int var3, String[] var4) {
        this.x = var1;
        this.y = var2;
        this.z = var3;
        this.lines = new String[]{var4[0], var4[1], var4[2], var4[3]};
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.x = var1.readInt();
        this.y = var1.readShort();
        this.z = var1.readInt();
        this.lines = new String[4];

        for (int i = 0; i < 4; i++) {
            this.lines[i] = var1.readStringFromBuffer(15);
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.x);
        var1.writeShort(this.y);
        var1.writeInt(this.z);

        for (int i = 0; i < 4; i++) {
            var1.writeStringToBuffer(this.lines[i]);
        }
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processUpdateSign(this);
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    public String[] getLines() {
        return this.lines;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
