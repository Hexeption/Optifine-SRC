package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C0APacketAnimation extends Packet {
    private int id;
    private int type;

    public C0APacketAnimation() {
    }

    public C0APacketAnimation(Entity var1, int var2) {
        this.id = var1.getEntityId();
        this.type = var2;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.id = var1.readInt();
        this.type = var1.readByte();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.id);
        var1.writeByte(this.type);
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processAnimation(this);
    }

    @Override
    public String serialize() {
        return String.format("id=%d, type=%d", this.id, this.type);
    }

    public int getType() {
        return this.type;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
