package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C16PacketClientStatus extends Packet {
    private C16PacketClientStatus.EnumState status;

    public C16PacketClientStatus() {
    }

    public C16PacketClientStatus(C16PacketClientStatus.EnumState var1) {
        this.status = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.status = C16PacketClientStatus.EnumState.BY_ID[var1.readByte() % C16PacketClientStatus.EnumState.BY_ID.length];
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeByte(this.status.id);
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processClientStatus(this);
    }

    public C16PacketClientStatus.EnumState getStatus() {
        return this.status;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }

    public enum EnumState {
        PERFORM_RESPAWN(0),
        REQUEST_STATS(1),
        OPEN_INVENTORY_ACHIEVEMENT(2);

        private final int id;
        private static final C16PacketClientStatus.EnumState[] BY_ID = new C16PacketClientStatus.EnumState[values().length];

        EnumState(int var3) {
            this.id = var3;
        }

        static {
            for (C16PacketClientStatus.EnumState c16packetclientstatus$enumstate : values()) {
                BY_ID[c16packetclientstatus$enumstate.id] = c16packetclientstatus$enumstate;
            }
        }
    }
}
