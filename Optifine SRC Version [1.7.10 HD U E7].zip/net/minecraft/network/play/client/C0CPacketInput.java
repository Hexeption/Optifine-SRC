package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C0CPacketInput extends Packet {
    private float strafeSpeed;
    private float forwardSpeed;
    private boolean jumping;
    private boolean sneaking;

    public C0CPacketInput() {
    }

    public C0CPacketInput(float var1, float var2, boolean var3, boolean var4) {
        this.strafeSpeed = var1;
        this.forwardSpeed = var2;
        this.jumping = var3;
        this.sneaking = var4;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.strafeSpeed = var1.readFloat();
        this.forwardSpeed = var1.readFloat();
        this.jumping = var1.readBoolean();
        this.sneaking = var1.readBoolean();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeFloat(this.strafeSpeed);
        var1.writeFloat(this.forwardSpeed);
        var1.writeBoolean(this.jumping);
        var1.writeBoolean(this.sneaking);
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processInput(this);
    }

    public float getStrafeSpeed() {
        return this.strafeSpeed;
    }

    public float getForwardSpeed() {
        return this.forwardSpeed;
    }

    public boolean isJumping() {
        return this.jumping;
    }

    public boolean isSneaking() {
        return this.sneaking;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
