package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C11PacketEnchantItem extends Packet {
    private int id;
    private int button;

    public C11PacketEnchantItem() {
    }

    public C11PacketEnchantItem(int var1, int var2) {
        this.id = var1;
        this.button = var2;
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processEnchantItem(this);
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.id = var1.readByte();
        this.button = var1.readByte();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeByte(this.id);
        var1.writeByte(this.button);
    }

    @Override
    public String serialize() {
        return String.format("id=%d, button=%d", this.id, this.button);
    }

    public int getId() {
        return this.id;
    }

    public int getButton() {
        return this.button;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
