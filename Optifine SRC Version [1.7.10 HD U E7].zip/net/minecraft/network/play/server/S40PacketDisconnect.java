package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.IChatComponent;

public class S40PacketDisconnect extends Packet {
    private IChatComponent reason;

    public S40PacketDisconnect() {
    }

    public S40PacketDisconnect(IChatComponent var1) {
        this.reason = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.reason = IChatComponent.Serializer.jsonToComponent(var1.readStringFromBuffer(Short.MAX_VALUE));
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeStringToBuffer(IChatComponent.Serializer.componentToJson(this.reason));
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleDisconnect(this);
    }

    @Override
    public boolean hasPriority() {
        return true;
    }

    public IChatComponent func_149165_c() {
        return this.reason;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
