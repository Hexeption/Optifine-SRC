package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.NibbleArray;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;

public class S21PacketChunkData extends Packet {
    private int field_149284_a;
    private int field_149282_b;
    private int field_149283_c;
    private int field_149280_d;
    private byte[] field_149281_e;
    private byte[] field_149278_f;
    private boolean field_149279_g;
    private int field_149285_h;
    private static byte[] field_149286_i = new byte[196864];

    public S21PacketChunkData() {
    }

    public S21PacketChunkData(Chunk var1, boolean var2, int var3) {
        this.field_149284_a = var1.xPosition;
        this.field_149282_b = var1.zPosition;
        this.field_149279_g = var2;
        S21PacketChunkData.Extracted s21packetchunkdata$extracted = func_149269_a(var1, var2, var3);
        Deflater deflater = new Deflater(-1);
        this.field_149280_d = s21packetchunkdata$extracted.field_150281_c;
        this.field_149283_c = s21packetchunkdata$extracted.field_150280_b;

        try {
            this.field_149278_f = s21packetchunkdata$extracted.field_150282_a;
            deflater.setInput(s21packetchunkdata$extracted.field_150282_a, 0, s21packetchunkdata$extracted.field_150282_a.length);
            deflater.finish();
            this.field_149281_e = new byte[s21packetchunkdata$extracted.field_150282_a.length];
            this.field_149285_h = deflater.deflate(this.field_149281_e);
        } finally {
            deflater.end();
        }
    }

    public static int func_149275_c() {
        return 196864;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.field_149284_a = var1.readInt();
        this.field_149282_b = var1.readInt();
        this.field_149279_g = var1.readBoolean();
        this.field_149283_c = var1.readShort();
        this.field_149280_d = var1.readShort();
        this.field_149285_h = var1.readInt();
        if (field_149286_i.length < this.field_149285_h) {
            field_149286_i = new byte[this.field_149285_h];
        }

        var1.readBytes(field_149286_i, 0, this.field_149285_h);
        int i = 0;

        for (int j = 0; j < 16; j++) {
            i += this.field_149283_c >> j & 1;
        }

        int k = 12288 * i;
        if (this.field_149279_g) {
            k += 256;
        }

        this.field_149278_f = new byte[k];
        Inflater inflater = new Inflater();
        inflater.setInput(field_149286_i, 0, this.field_149285_h);

        try {
            inflater.inflate(this.field_149278_f);
        } catch (DataFormatException dataformatexception) {
            throw new IOException("Bad compressed data format");
        } finally {
            inflater.end();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.field_149284_a);
        var1.writeInt(this.field_149282_b);
        var1.writeBoolean(this.field_149279_g);
        var1.writeShort((short)(this.field_149283_c & 65535));
        var1.writeShort((short)(this.field_149280_d & 65535));
        var1.writeInt(this.field_149285_h);
        var1.writeBytes(this.field_149281_e, 0, this.field_149285_h);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleChunkData(this);
    }

    @Override
    public String serialize() {
        return String.format(
            "x=%d, z=%d, full=%b, sects=%d, add=%d, size=%d",
            this.field_149284_a,
            this.field_149282_b,
            this.field_149279_g,
            this.field_149283_c,
            this.field_149280_d,
            this.field_149285_h
        );
    }

    public byte[] func_149272_d() {
        return this.field_149278_f;
    }

    public static S21PacketChunkData.Extracted func_149269_a(Chunk var0, boolean var1, int var2) {
        int i = 0;
        ExtendedBlockStorage[] aextendedblockstorage = var0.getBlockStorageArray();
        int j = 0;
        S21PacketChunkData.Extracted s21packetchunkdata$extracted = new S21PacketChunkData.Extracted();
        byte[] abyte = field_149286_i;
        if (var1) {
            var0.sendUpdates = true;
        }

        for (int k = 0; k < aextendedblockstorage.length; k++) {
            if (aextendedblockstorage[k] != null && (!var1 || !aextendedblockstorage[k].isEmpty()) && (var2 & 1 << k) != 0) {
                s21packetchunkdata$extracted.field_150280_b |= 1 << k;
                if (aextendedblockstorage[k].getBlockMSBArray() != null) {
                    s21packetchunkdata$extracted.field_150281_c |= 1 << k;
                    j++;
                }
            }
        }

        for (int l = 0; l < aextendedblockstorage.length; l++) {
            if (aextendedblockstorage[l] != null && (!var1 || !aextendedblockstorage[l].isEmpty()) && (var2 & 1 << l) != 0) {
                byte[] abyte1 = aextendedblockstorage[l].getBlockLSBArray();
                System.arraycopy(abyte1, 0, abyte, i, abyte1.length);
                i += abyte1.length;
            }
        }

        for (int i1 = 0; i1 < aextendedblockstorage.length; i1++) {
            if (aextendedblockstorage[i1] != null && (!var1 || !aextendedblockstorage[i1].isEmpty()) && (var2 & 1 << i1) != 0) {
                NibbleArray nibblearray = aextendedblockstorage[i1].getMetadataArray();
                System.arraycopy(nibblearray.data, 0, abyte, i, nibblearray.data.length);
                i += nibblearray.data.length;
            }
        }

        for (int j1 = 0; j1 < aextendedblockstorage.length; j1++) {
            if (aextendedblockstorage[j1] != null && (!var1 || !aextendedblockstorage[j1].isEmpty()) && (var2 & 1 << j1) != 0) {
                NibbleArray nibblearray1 = aextendedblockstorage[j1].getBlocklightArray();
                System.arraycopy(nibblearray1.data, 0, abyte, i, nibblearray1.data.length);
                i += nibblearray1.data.length;
            }
        }

        if (!var0.worldObj.provider.hasNoSky) {
            for (int k1 = 0; k1 < aextendedblockstorage.length; k1++) {
                if (aextendedblockstorage[k1] != null && (!var1 || !aextendedblockstorage[k1].isEmpty()) && (var2 & 1 << k1) != 0) {
                    NibbleArray nibblearray2 = aextendedblockstorage[k1].getSkylightArray();
                    System.arraycopy(nibblearray2.data, 0, abyte, i, nibblearray2.data.length);
                    i += nibblearray2.data.length;
                }
            }
        }

        if (j > 0) {
            for (int l1 = 0; l1 < aextendedblockstorage.length; l1++) {
                if (aextendedblockstorage[l1] != null
                    && (!var1 || !aextendedblockstorage[l1].isEmpty())
                    && aextendedblockstorage[l1].getBlockMSBArray() != null
                    && (var2 & 1 << l1) != 0) {
                    NibbleArray nibblearray3 = aextendedblockstorage[l1].getBlockMSBArray();
                    System.arraycopy(nibblearray3.data, 0, abyte, i, nibblearray3.data.length);
                    i += nibblearray3.data.length;
                }
            }
        }

        if (var1) {
            byte[] abyte2 = var0.getBiomeArray();
            System.arraycopy(abyte2, 0, abyte, i, abyte2.length);
            i += abyte2.length;
        }

        s21packetchunkdata$extracted.field_150282_a = new byte[i];
        System.arraycopy(abyte, 0, s21packetchunkdata$extracted.field_150282_a, 0, i);
        return s21packetchunkdata$extracted;
    }

    public int func_149273_e() {
        return this.field_149284_a;
    }

    public int func_149271_f() {
        return this.field_149282_b;
    }

    public int func_149276_g() {
        return this.field_149283_c;
    }

    public int func_149270_h() {
        return this.field_149280_d;
    }

    public boolean func_149274_i() {
        return this.field_149279_g;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }

    public static class Extracted {
        public byte[] field_150282_a;
        public int field_150280_b;
        public int field_150281_c;
    }
}
