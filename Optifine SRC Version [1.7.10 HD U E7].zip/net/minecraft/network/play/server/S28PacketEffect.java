package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S28PacketEffect extends Packet {
    private int soundType;
    private int soundData;
    private int xPos;
    private int yPos;
    private int zPos;
    private boolean serverWide;

    public S28PacketEffect() {
    }

    public S28PacketEffect(int var1, int var2, int var3, int var4, int var5, boolean var6) {
        this.soundType = var1;
        this.xPos = var2;
        this.yPos = var3;
        this.zPos = var4;
        this.soundData = var5;
        this.serverWide = var6;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.soundType = var1.readInt();
        this.xPos = var1.readInt();
        this.yPos = var1.readByte() & 255;
        this.zPos = var1.readInt();
        this.soundData = var1.readInt();
        this.serverWide = var1.readBoolean();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.soundType);
        var1.writeInt(this.xPos);
        var1.writeByte(this.yPos & 0xFF);
        var1.writeInt(this.zPos);
        var1.writeInt(this.soundData);
        var1.writeBoolean(this.serverWide);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleEffect(this);
    }

    public boolean isSoundServerwide() {
        return this.serverWide;
    }

    public int getSoundType() {
        return this.soundType;
    }

    public int getSoundData() {
        return this.soundData;
    }

    public int getPosX() {
        return this.xPos;
    }

    public int getPosY() {
        return this.yPos;
    }

    public int getPosZ() {
        return this.zPos;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
