package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import org.apache.commons.lang3.ArrayUtils;

public class S3APacketTabComplete extends Packet {
    private String[] field_149632_a;

    public S3APacketTabComplete() {
    }

    public S3APacketTabComplete(String[] var1) {
        this.field_149632_a = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.field_149632_a = new String[var1.readVarIntFromBuffer()];

        for (int i = 0; i < this.field_149632_a.length; i++) {
            this.field_149632_a[i] = var1.readStringFromBuffer(Short.MAX_VALUE);
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeVarIntToBuffer(this.field_149632_a.length);

        for (String s : this.field_149632_a) {
            var1.writeStringToBuffer(s);
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleTabComplete(this);
    }

    public String[] func_149630_c() {
        return this.field_149632_a;
    }

    @Override
    public String serialize() {
        return String.format("candidates='%s'", ArrayUtils.toString(this.field_149632_a));
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
