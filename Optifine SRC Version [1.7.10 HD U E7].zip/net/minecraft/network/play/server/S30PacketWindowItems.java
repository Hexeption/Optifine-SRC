package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S30PacketWindowItems extends Packet {
    private int field_148914_a;
    private ItemStack[] field_148913_b;

    public S30PacketWindowItems() {
    }

    public S30PacketWindowItems(int var1, List var2) {
        this.field_148914_a = var1;
        this.field_148913_b = new ItemStack[var2.size()];

        for (int i = 0; i < this.field_148913_b.length; i++) {
            ItemStack itemstack = (ItemStack)var2.get(i);
            this.field_148913_b[i] = itemstack == null ? null : itemstack.copy();
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.field_148914_a = var1.readUnsignedByte();
        short short1 = var1.readShort();
        this.field_148913_b = new ItemStack[short1];

        for (int i = 0; i < short1; i++) {
            this.field_148913_b[i] = var1.readItemStackFromBuffer();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeByte(this.field_148914_a);
        var1.writeShort(this.field_148913_b.length);

        for (ItemStack itemstack : this.field_148913_b) {
            var1.writeItemStackToBuffer(itemstack);
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleWindowItems(this);
    }

    public int func_148911_c() {
        return this.field_148914_a;
    }

    public ItemStack[] func_148910_d() {
        return this.field_148913_b;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
