package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S34PacketMaps extends Packet {
    private int mapId;
    private byte[] field_149190_b;

    public S34PacketMaps() {
    }

    public S34PacketMaps(int var1, byte[] var2) {
        this.mapId = var1;
        this.field_149190_b = var2;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.mapId = var1.readVarIntFromBuffer();
        this.field_149190_b = new byte[var1.readUnsignedShort()];
        var1.readBytes(this.field_149190_b);
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeVarIntToBuffer(this.mapId);
        var1.writeShort(this.field_149190_b.length);
        var1.writeBytes(this.field_149190_b);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleMaps(this);
    }

    @Override
    public String serialize() {
        return String.format("id=%d, length=%d", this.mapId, this.field_149190_b.length);
    }

    public int getMapId() {
        return this.mapId;
    }

    public byte[] getData() {
        return this.field_149190_b;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
