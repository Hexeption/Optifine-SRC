package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.IChatComponent;

public class S02PacketChat extends Packet {
    private IChatComponent chatComponent;
    private boolean isChat = true;

    public S02PacketChat() {
    }

    public S02PacketChat(IChatComponent var1) {
        this(var1, true);
    }

    public S02PacketChat(IChatComponent var1, boolean var2) {
        this.chatComponent = var1;
        this.isChat = var2;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.chatComponent = IChatComponent.Serializer.jsonToComponent(var1.readStringFromBuffer(Short.MAX_VALUE));
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeStringToBuffer(IChatComponent.Serializer.componentToJson(this.chatComponent));
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleChat(this);
    }

    @Override
    public String serialize() {
        return String.format("message='%s'", this.chatComponent);
    }

    public IChatComponent func_148915_c() {
        return this.chatComponent;
    }

    public boolean isChat() {
        return this.isChat;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
