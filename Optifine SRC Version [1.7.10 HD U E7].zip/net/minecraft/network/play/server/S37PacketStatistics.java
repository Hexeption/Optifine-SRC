package net.minecraft.network.play.server;

import com.google.common.collect.Maps;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;

public class S37PacketStatistics extends Packet {
    private Map field_148976_a;

    public S37PacketStatistics() {
    }

    public S37PacketStatistics(Map var1) {
        this.field_148976_a = var1;
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleStatistics(this);
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        int i = var1.readVarIntFromBuffer();
        this.field_148976_a = Maps.newHashMap();

        for (int j = 0; j < i; j++) {
            StatBase statbase = StatList.getOneShotStat(var1.readStringFromBuffer(Short.MAX_VALUE));
            int k = var1.readVarIntFromBuffer();
            if (statbase != null) {
                this.field_148976_a.put(statbase, k);
            }
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeVarIntToBuffer(this.field_148976_a.size());

        for (Entry entry : (Iterable<Entry>) (Iterable) this.field_148976_a.entrySet()) {
            var1.writeStringToBuffer(((StatBase)entry.getKey()).statId);
            var1.writeVarIntToBuffer((Integer)entry.getValue());
        }
    }

    @Override
    public String serialize() {
        return String.format("count=%d", this.field_148976_a.size());
    }

    public Map func_148974_c() {
        return this.field_148976_a;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
