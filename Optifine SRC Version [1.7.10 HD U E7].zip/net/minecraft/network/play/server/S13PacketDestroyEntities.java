package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S13PacketDestroyEntities extends Packet {
    private int[] field_149100_a;

    public S13PacketDestroyEntities() {
    }

    public S13PacketDestroyEntities(int... var1) {
        this.field_149100_a = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.field_149100_a = new int[var1.readByte()];

        for (int i = 0; i < this.field_149100_a.length; i++) {
            this.field_149100_a[i] = var1.readInt();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeByte(this.field_149100_a.length);

        for (int i = 0; i < this.field_149100_a.length; i++) {
            var1.writeInt(this.field_149100_a[i]);
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleDestroyEntities(this);
    }

    @Override
    public String serialize() {
        StringBuilder stringbuilder = new StringBuilder();

        for (int i = 0; i < this.field_149100_a.length; i++) {
            if (i > 0) {
                stringbuilder.append(", ");
            }

            stringbuilder.append(this.field_149100_a[i]);
        }

        return String.format("entities=%d[%s]", this.field_149100_a.length, stringbuilder);
    }

    public int[] func_149098_c() {
        return this.field_149100_a;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
