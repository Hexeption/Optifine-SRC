package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.World;

public class S0APacketUseBed extends Packet {
    private int playerID;
    private int x;
    private int y;
    private int z;

    public S0APacketUseBed() {
    }

    public S0APacketUseBed(EntityPlayer var1, int var2, int var3, int var4) {
        this.x = var2;
        this.y = var3;
        this.z = var4;
        this.playerID = var1.getEntityId();
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.playerID = var1.readInt();
        this.x = var1.readInt();
        this.y = var1.readByte();
        this.z = var1.readInt();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.playerID);
        var1.writeInt(this.x);
        var1.writeByte(this.y);
        var1.writeInt(this.z);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleUseBed(this);
    }

    public EntityPlayer getPlayer(World var1) {
        return (EntityPlayer)var1.getEntityByID(this.playerID);
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
