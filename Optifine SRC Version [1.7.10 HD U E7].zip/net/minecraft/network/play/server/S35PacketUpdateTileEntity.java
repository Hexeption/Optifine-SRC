package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S35PacketUpdateTileEntity extends Packet {
    private int x;
    private int y;
    private int z;
    private int metadata;
    private NBTTagCompound nbt;

    public S35PacketUpdateTileEntity() {
    }

    public S35PacketUpdateTileEntity(int var1, int var2, int var3, int var4, NBTTagCompound var5) {
        this.x = var1;
        this.y = var2;
        this.z = var3;
        this.metadata = var4;
        this.nbt = var5;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.x = var1.readInt();
        this.y = var1.readShort();
        this.z = var1.readInt();
        this.metadata = var1.readUnsignedByte();
        this.nbt = var1.readNBTTagCompoundFromBuffer();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.x);
        var1.writeShort(this.y);
        var1.writeInt(this.z);
        var1.writeByte((byte)this.metadata);
        var1.writeNBTTagCompoundToBuffer(this.nbt);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleUpdateTileEntity(this);
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    public int getTileEntityType() {
        return this.metadata;
    }

    public NBTTagCompound getNbtCompound() {
        return this.nbt;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
