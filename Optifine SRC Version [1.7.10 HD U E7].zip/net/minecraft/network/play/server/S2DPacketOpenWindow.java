package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S2DPacketOpenWindow extends Packet {
    private int windowId;
    private int inventoryType;
    private String windowTitle;
    private int slotCount;
    private boolean useProvidedTitle;
    private int entityId;

    public S2DPacketOpenWindow() {
    }

    public S2DPacketOpenWindow(int var1, int var2, String var3, int var4, boolean var5) {
        this.windowId = var1;
        this.inventoryType = var2;
        this.windowTitle = var3;
        this.slotCount = var4;
        this.useProvidedTitle = var5;
    }

    public S2DPacketOpenWindow(int var1, int var2, String var3, int var4, boolean var5, int var6) {
        this(var1, var2, var3, var4, var5);
        this.entityId = var6;
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleOpenWindow(this);
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.windowId = var1.readUnsignedByte();
        this.inventoryType = var1.readUnsignedByte();
        this.windowTitle = var1.readStringFromBuffer(32);
        this.slotCount = var1.readUnsignedByte();
        this.useProvidedTitle = var1.readBoolean();
        if (this.inventoryType == 11) {
            this.entityId = var1.readInt();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeByte(this.windowId);
        var1.writeByte(this.inventoryType);
        var1.writeStringToBuffer(this.windowTitle);
        var1.writeByte(this.slotCount);
        var1.writeBoolean(this.useProvidedTitle);
        if (this.inventoryType == 11) {
            var1.writeInt(this.entityId);
        }
    }

    public int func_148901_c() {
        return this.windowId;
    }

    public int func_148899_d() {
        return this.inventoryType;
    }

    public String func_148902_e() {
        return this.windowTitle;
    }

    public int func_148898_f() {
        return this.slotCount;
    }

    public boolean func_148900_g() {
        return this.useProvidedTitle;
    }

    public int func_148897_h() {
        return this.entityId;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
