package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.Vec3;
import net.minecraft.world.ChunkPosition;

public class S27PacketExplosion extends Packet {
    private double field_149158_a;
    private double field_149156_b;
    private double field_149157_c;
    private float field_149154_d;
    private List field_149155_e;
    private float field_149152_f;
    private float field_149153_g;
    private float field_149159_h;

    public S27PacketExplosion() {
    }

    public S27PacketExplosion(double var1, double var3, double var5, float var7, List var8, Vec3 var9) {
        this.field_149158_a = var1;
        this.field_149156_b = var3;
        this.field_149157_c = var5;
        this.field_149154_d = var7;
        this.field_149155_e = new ArrayList(var8);
        if (var9 != null) {
            this.field_149152_f = (float)var9.xCoord;
            this.field_149153_g = (float)var9.yCoord;
            this.field_149159_h = (float)var9.zCoord;
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.field_149158_a = var1.readFloat();
        this.field_149156_b = var1.readFloat();
        this.field_149157_c = var1.readFloat();
        this.field_149154_d = var1.readFloat();
        int i = var1.readInt();
        this.field_149155_e = new ArrayList(i);
        int j = (int)this.field_149158_a;
        int k = (int)this.field_149156_b;
        int l = (int)this.field_149157_c;

        for (int i1 = 0; i1 < i; i1++) {
            int j1 = var1.readByte() + j;
            int k1 = var1.readByte() + k;
            int l1 = var1.readByte() + l;
            this.field_149155_e.add(new ChunkPosition(j1, k1, l1));
        }

        this.field_149152_f = var1.readFloat();
        this.field_149153_g = var1.readFloat();
        this.field_149159_h = var1.readFloat();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeFloat((float)this.field_149158_a);
        var1.writeFloat((float)this.field_149156_b);
        var1.writeFloat((float)this.field_149157_c);
        var1.writeFloat(this.field_149154_d);
        var1.writeInt(this.field_149155_e.size());
        int i = (int)this.field_149158_a;
        int j = (int)this.field_149156_b;
        int k = (int)this.field_149157_c;

        for (ChunkPosition chunkposition : (Iterable<ChunkPosition>) (Iterable) this.field_149155_e) {
            int l = chunkposition.chunkPosX - i;
            int i1 = chunkposition.chunkPosY - j;
            int j1 = chunkposition.chunkPosZ - k;
            var1.writeByte(l);
            var1.writeByte(i1);
            var1.writeByte(j1);
        }

        var1.writeFloat(this.field_149152_f);
        var1.writeFloat(this.field_149153_g);
        var1.writeFloat(this.field_149159_h);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleExplosion(this);
    }

    public float func_149149_c() {
        return this.field_149152_f;
    }

    public float func_149144_d() {
        return this.field_149153_g;
    }

    public float func_149147_e() {
        return this.field_149159_h;
    }

    public double func_149148_f() {
        return this.field_149158_a;
    }

    public double func_149143_g() {
        return this.field_149156_b;
    }

    public double func_149145_h() {
        return this.field_149157_c;
    }

    public float func_149146_i() {
        return this.field_149154_d;
    }

    public List func_149150_j() {
        return this.field_149155_e;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
