package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.chunk.Chunk;

public class S26PacketMapChunkBulk extends Packet {
    private int[] field_149266_a;
    private int[] field_149264_b;
    private int[] field_149265_c;
    private int[] field_149262_d;
    private byte[] field_149263_e;
    private byte[][] field_149260_f;
    private int field_149261_g;
    private boolean field_149267_h;
    private static byte[] field_149268_i = new byte[0];

    public S26PacketMapChunkBulk() {
    }

    public S26PacketMapChunkBulk(List var1) {
        int i = var1.size();
        this.field_149266_a = new int[i];
        this.field_149264_b = new int[i];
        this.field_149265_c = new int[i];
        this.field_149262_d = new int[i];
        this.field_149260_f = new byte[i][];
        this.field_149267_h = !var1.isEmpty() && !((Chunk)var1.get(0)).worldObj.provider.hasNoSky;
        int j = 0;

        for (int k = 0; k < i; k++) {
            Chunk chunk = (Chunk)var1.get(k);
            S21PacketChunkData.Extracted s21packetchunkdata$extracted = S21PacketChunkData.func_149269_a(chunk, true, 65535);
            if (field_149268_i.length < j + s21packetchunkdata$extracted.field_150282_a.length) {
                byte[] abyte = new byte[j + s21packetchunkdata$extracted.field_150282_a.length];
                System.arraycopy(field_149268_i, 0, abyte, 0, field_149268_i.length);
                field_149268_i = abyte;
            }

            System.arraycopy(s21packetchunkdata$extracted.field_150282_a, 0, field_149268_i, j, s21packetchunkdata$extracted.field_150282_a.length);
            j += s21packetchunkdata$extracted.field_150282_a.length;
            this.field_149266_a[k] = chunk.xPosition;
            this.field_149264_b[k] = chunk.zPosition;
            this.field_149265_c[k] = s21packetchunkdata$extracted.field_150280_b;
            this.field_149262_d[k] = s21packetchunkdata$extracted.field_150281_c;
            this.field_149260_f[k] = s21packetchunkdata$extracted.field_150282_a;
        }

        Deflater deflater = new Deflater(-1);

        try {
            deflater.setInput(field_149268_i, 0, j);
            deflater.finish();
            this.field_149263_e = new byte[j];
            this.field_149261_g = deflater.deflate(this.field_149263_e);
        } finally {
            deflater.end();
        }
    }

    public static int func_149258_c() {
        return 5;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        short short1 = var1.readShort();
        this.field_149261_g = var1.readInt();
        this.field_149267_h = var1.readBoolean();
        this.field_149266_a = new int[short1];
        this.field_149264_b = new int[short1];
        this.field_149265_c = new int[short1];
        this.field_149262_d = new int[short1];
        this.field_149260_f = new byte[short1][];
        if (field_149268_i.length < this.field_149261_g) {
            field_149268_i = new byte[this.field_149261_g];
        }

        var1.readBytes(field_149268_i, 0, this.field_149261_g);
        byte[] abyte = new byte[S21PacketChunkData.func_149275_c() * short1];
        Inflater inflater = new Inflater();
        inflater.setInput(field_149268_i, 0, this.field_149261_g);

        try {
            inflater.inflate(abyte);
        } catch (DataFormatException dataformatexception) {
            throw new IOException("Bad compressed data format");
        } finally {
            inflater.end();
        }

        int i = 0;

        for (int j = 0; j < short1; j++) {
            this.field_149266_a[j] = var1.readInt();
            this.field_149264_b[j] = var1.readInt();
            this.field_149265_c[j] = var1.readShort();
            this.field_149262_d[j] = var1.readShort();
            int k = 0;
            int l = 0;

            for (int i1 = 0; i1 < 16; i1++) {
                k += this.field_149265_c[j] >> i1 & 1;
                l += this.field_149262_d[j] >> i1 & 1;
            }

            int j1 = 2048 * 4 * k + 256;
            j1 += 2048 * l;
            if (this.field_149267_h) {
                j1 += 2048 * k;
            }

            this.field_149260_f[j] = new byte[j1];
            System.arraycopy(abyte, i, this.field_149260_f[j], 0, j1);
            i += j1;
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeShort(this.field_149266_a.length);
        var1.writeInt(this.field_149261_g);
        var1.writeBoolean(this.field_149267_h);
        var1.writeBytes(this.field_149263_e, 0, this.field_149261_g);

        for (int i = 0; i < this.field_149266_a.length; i++) {
            var1.writeInt(this.field_149266_a[i]);
            var1.writeInt(this.field_149264_b[i]);
            var1.writeShort((short)(this.field_149265_c[i] & 65535));
            var1.writeShort((short)(this.field_149262_d[i] & 65535));
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleMapChunkBulk(this);
    }

    public int func_149255_a(int var1) {
        return this.field_149266_a[var1];
    }

    public int func_149253_b(int var1) {
        return this.field_149264_b[var1];
    }

    public int func_149254_d() {
        return this.field_149266_a.length;
    }

    public byte[] func_149256_c(int var1) {
        return this.field_149260_f[var1];
    }

    @Override
    public String serialize() {
        StringBuilder stringbuilder = new StringBuilder();

        for (int i = 0; i < this.field_149266_a.length; i++) {
            if (i > 0) {
                stringbuilder.append(", ");
            }

            stringbuilder.append(
                String.format(
                    "{x=%d, z=%d, sections=%d, adds=%d, data=%d}",
                    this.field_149266_a[i],
                    this.field_149264_b[i],
                    this.field_149265_c[i],
                    this.field_149262_d[i],
                    this.field_149260_f[i].length
                )
            );
        }

        return String.format("size=%d, chunks=%d[%s]", this.field_149261_g, this.field_149266_a.length, stringbuilder);
    }

    public int[] func_149252_e() {
        return this.field_149265_c;
    }

    public int[] func_149257_f() {
        return this.field_149262_d;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
