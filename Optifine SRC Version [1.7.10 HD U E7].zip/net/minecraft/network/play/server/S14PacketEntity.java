package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.Entity;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.World;

public class S14PacketEntity extends Packet {
    protected int field_149074_a;
    protected byte field_149072_b;
    protected byte field_149073_c;
    protected byte field_149070_d;
    protected byte field_149071_e;
    protected byte field_149068_f;
    protected boolean field_149069_g;

    public S14PacketEntity() {
    }

    public S14PacketEntity(int var1) {
        this.field_149074_a = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.field_149074_a = var1.readInt();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.field_149074_a);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleEntityMovement(this);
    }

    @Override
    public String serialize() {
        return String.format("id=%d", this.field_149074_a);
    }

    @Override
    public String toString() {
        return "Entity_" + super.toString();
    }

    public Entity func_149065_a(World var1) {
        return var1.getEntityByID(this.field_149074_a);
    }

    public byte func_149062_c() {
        return this.field_149072_b;
    }

    public byte func_149061_d() {
        return this.field_149073_c;
    }

    public byte func_149064_e() {
        return this.field_149070_d;
    }

    public byte func_149066_f() {
        return this.field_149071_e;
    }

    public byte func_149063_g() {
        return this.field_149068_f;
    }

    public boolean func_149060_h() {
        return this.field_149069_g;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }

    public static class S15PacketEntityRelMove extends S14PacketEntity {
        public S15PacketEntityRelMove() {
        }

        public S15PacketEntityRelMove(int var1, byte var2, byte var3, byte var4) {
            super(var1);
            this.field_149072_b = var2;
            this.field_149073_c = var3;
            this.field_149070_d = var4;
        }

        @Override
        public void readPacketData(PacketBuffer var1) throws IOException {
            super.readPacketData(var1);
            this.field_149072_b = var1.readByte();
            this.field_149073_c = var1.readByte();
            this.field_149070_d = var1.readByte();
        }

        @Override
        public void writePacketData(PacketBuffer var1) throws IOException {
            super.writePacketData(var1);
            var1.writeByte(this.field_149072_b);
            var1.writeByte(this.field_149073_c);
            var1.writeByte(this.field_149070_d);
        }

        @Override
        public String serialize() {
            return super.serialize() + String.format(", xa=%d, ya=%d, za=%d", this.field_149072_b, this.field_149073_c, this.field_149070_d);
        }

        @Override
        public void processPacket(INetHandler var1) {
            super.processPacket((INetHandlerPlayClient)var1);
        }
    }

    public static class S16PacketEntityLook extends S14PacketEntity {
        public S16PacketEntityLook() {
            this.field_149069_g = true;
        }

        public S16PacketEntityLook(int var1, byte var2, byte var3) {
            super(var1);
            this.field_149071_e = var2;
            this.field_149068_f = var3;
            this.field_149069_g = true;
        }

        @Override
        public void readPacketData(PacketBuffer var1) throws IOException {
            super.readPacketData(var1);
            this.field_149071_e = var1.readByte();
            this.field_149068_f = var1.readByte();
        }

        @Override
        public void writePacketData(PacketBuffer var1) throws IOException {
            super.writePacketData(var1);
            var1.writeByte(this.field_149071_e);
            var1.writeByte(this.field_149068_f);
        }

        @Override
        public String serialize() {
            return super.serialize() + String.format(", yRot=%d, xRot=%d", this.field_149071_e, this.field_149068_f);
        }

        @Override
        public void processPacket(INetHandler var1) {
            super.processPacket((INetHandlerPlayClient)var1);
        }
    }

    public static class S17PacketEntityLookMove extends S14PacketEntity {
        public S17PacketEntityLookMove() {
            this.field_149069_g = true;
        }

        public S17PacketEntityLookMove(int var1, byte var2, byte var3, byte var4, byte var5, byte var6) {
            super(var1);
            this.field_149072_b = var2;
            this.field_149073_c = var3;
            this.field_149070_d = var4;
            this.field_149071_e = var5;
            this.field_149068_f = var6;
            this.field_149069_g = true;
        }

        @Override
        public void readPacketData(PacketBuffer var1) throws IOException {
            super.readPacketData(var1);
            this.field_149072_b = var1.readByte();
            this.field_149073_c = var1.readByte();
            this.field_149070_d = var1.readByte();
            this.field_149071_e = var1.readByte();
            this.field_149068_f = var1.readByte();
        }

        @Override
        public void writePacketData(PacketBuffer var1) throws IOException {
            super.writePacketData(var1);
            var1.writeByte(this.field_149072_b);
            var1.writeByte(this.field_149073_c);
            var1.writeByte(this.field_149070_d);
            var1.writeByte(this.field_149071_e);
            var1.writeByte(this.field_149068_f);
        }

        @Override
        public String serialize() {
            return super.serialize()
                + String.format(
                    ", xa=%d, ya=%d, za=%d, yRot=%d, xRot=%d",
                    this.field_149072_b,
                    this.field_149073_c,
                    this.field_149070_d,
                    this.field_149071_e,
                    this.field_149068_f
                );
        }

        @Override
        public void processPacket(INetHandler var1) {
            super.processPacket((INetHandlerPlayClient)var1);
        }
    }
}
