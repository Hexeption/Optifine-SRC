package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S39PacketPlayerAbilities extends Packet {
    private boolean invulnerable;
    private boolean flying;
    private boolean allowFlying;
    private boolean creativeMode;
    private float flySpeed;
    private float walkSpeed;

    public S39PacketPlayerAbilities() {
    }

    public S39PacketPlayerAbilities(PlayerCapabilities var1) {
        this.setInvulnerable(var1.disableDamage);
        this.setFlying(var1.isFlying);
        this.setAllowFlying(var1.allowFlying);
        this.setCreativeMode(var1.isCreativeMode);
        this.setFlySpeed(var1.getFlySpeed());
        this.setWalkSpeed(var1.getWalkSpeed());
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        byte b0 = var1.readByte();
        this.setInvulnerable((b0 & 1) > 0);
        this.setFlying((b0 & 2) > 0);
        this.setAllowFlying((b0 & 4) > 0);
        this.setCreativeMode((b0 & 8) > 0);
        this.setFlySpeed(var1.readFloat());
        this.setWalkSpeed(var1.readFloat());
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        byte b0 = 0;
        if (this.isInvulnerable()) {
            b0 = (byte)(b0 | 1);
        }

        if (this.isFlying()) {
            b0 = (byte)(b0 | 2);
        }

        if (this.isAllowFlying()) {
            b0 = (byte)(b0 | 4);
        }

        if (this.isCreativeMode()) {
            b0 = (byte)(b0 | 8);
        }

        var1.writeByte(b0);
        var1.writeFloat(this.flySpeed);
        var1.writeFloat(this.walkSpeed);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handlePlayerAbilities(this);
    }

    @Override
    public String serialize() {
        return String.format(
            "invuln=%b, flying=%b, canfly=%b, instabuild=%b, flyspeed=%.4f, walkspped=%.4f",
            this.isInvulnerable(),
            this.isFlying(),
            this.isAllowFlying(),
            this.isCreativeMode(),
            this.getFlySpeed(),
            this.getWalkSpeed()
        );
    }

    public boolean isInvulnerable() {
        return this.invulnerable;
    }

    public void setInvulnerable(boolean var1) {
        this.invulnerable = var1;
    }

    public boolean isFlying() {
        return this.flying;
    }

    public void setFlying(boolean var1) {
        this.flying = var1;
    }

    public boolean isAllowFlying() {
        return this.allowFlying;
    }

    public void setAllowFlying(boolean var1) {
        this.allowFlying = var1;
    }

    public boolean isCreativeMode() {
        return this.creativeMode;
    }

    public void setCreativeMode(boolean var1) {
        this.creativeMode = var1;
    }

    public float getFlySpeed() {
        return this.flySpeed;
    }

    public void setFlySpeed(float var1) {
        this.flySpeed = var1;
    }

    public float getWalkSpeed() {
        return this.walkSpeed;
    }

    public void setWalkSpeed(float var1) {
        this.walkSpeed = var1;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
