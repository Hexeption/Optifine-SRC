package net.minecraft.network.play.server;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import net.minecraft.block.Block;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.chunk.Chunk;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class S22PacketMultiBlockChange extends Packet {
    private static final Logger logger = LogManager.getLogger();
    private ChunkCoordIntPair field_148925_b;
    private byte[] field_148926_c;
    private int field_148924_d;

    public S22PacketMultiBlockChange() {
    }

    public S22PacketMultiBlockChange(int var1, short[] var2, Chunk var3) {
        this.field_148925_b = new ChunkCoordIntPair(var3.xPosition, var3.zPosition);
        this.field_148924_d = var1;
        int i = 4 * var1;

        try {
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(i);
            DataOutputStream dataoutputstream = new DataOutputStream(bytearrayoutputstream);

            for (int j = 0; j < var1; j++) {
                int k = var2[j] >> 12 & 15;
                int l = var2[j] >> 8 & 15;
                int i1 = var2[j] & 255;
                dataoutputstream.writeShort(var2[j]);
                dataoutputstream.writeShort((short)((Block.getIdFromBlock(var3.getBlock(k, i1, l)) & 4095) << 4 | var3.getBlockMetadata(k, i1, l) & 15));
            }

            this.field_148926_c = bytearrayoutputstream.toByteArray();
            if (this.field_148926_c.length != i) {
                throw new RuntimeException("Expected length " + i + " doesn't match received length " + this.field_148926_c.length);
            }
        } catch (IOException ioexception) {
            logger.error("Couldn't create bulk block update packet", ioexception);
            this.field_148926_c = null;
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.field_148925_b = new ChunkCoordIntPair(var1.readInt(), var1.readInt());
        this.field_148924_d = var1.readShort() & '\uffff';
        int i = var1.readInt();
        if (i > 0) {
            this.field_148926_c = new byte[i];
            var1.readBytes(this.field_148926_c);
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.field_148925_b.chunkXPos);
        var1.writeInt(this.field_148925_b.chunkZPos);
        var1.writeShort((short)this.field_148924_d);
        if (this.field_148926_c != null) {
            var1.writeInt(this.field_148926_c.length);
            var1.writeBytes(this.field_148926_c);
        } else {
            var1.writeInt(0);
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleMultiBlockChange(this);
    }

    @Override
    public String serialize() {
        return String.format("xc=%d, zc=%d, count=%d", this.field_148925_b.chunkXPos, this.field_148925_b.chunkZPos, this.field_148924_d);
    }

    public ChunkCoordIntPair func_148920_c() {
        return this.field_148925_b;
    }

    public byte[] func_148921_d() {
        return this.field_148926_c;
    }

    public int func_148922_e() {
        return this.field_148924_d;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
