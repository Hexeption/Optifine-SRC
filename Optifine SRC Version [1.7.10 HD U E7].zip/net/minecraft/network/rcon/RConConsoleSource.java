package net.minecraft.network.rcon;

import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.World;

public class RConConsoleSource implements ICommandSender {
    public static final RConConsoleSource instance = new RConConsoleSource();
    private StringBuffer buffer = new StringBuffer();

    @Override
    public String getCommandSenderName() {
        return "Rcon";
    }

    @Override
    public IChatComponent getFormattedCommandSenderName() {
        return new ChatComponentText(this.getCommandSenderName());
    }

    @Override
    public void addChatMessage(IChatComponent var1) {
        this.buffer.append(var1.getUnformattedText());
    }

    @Override
    public boolean canCommandSenderUseCommand(int var1, String var2) {
        return true;
    }

    @Override
    public ChunkCoordinates getCommandSenderPosition() {
        return new ChunkCoordinates(0, 0, 0);
    }

    @Override
    public World getEntityWorld() {
        return MinecraftServer.getServer().getEntityWorld();
    }
}
