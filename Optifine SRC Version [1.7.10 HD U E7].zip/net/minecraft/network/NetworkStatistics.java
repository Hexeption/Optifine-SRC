package net.minecraft.network;

import java.util.concurrent.atomic.AtomicReference;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class NetworkStatistics {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final Marker NETSTAT_MARKER = MarkerManager.getMarker("NETSTAT_MARKER", NetworkManager.logMarkerStat);
    private NetworkStatistics.Tracker field_152480_c = new NetworkStatistics.Tracker();
    private NetworkStatistics.Tracker field_152481_d = new NetworkStatistics.Tracker();

    public void func_152469_a(int var1, long var2) {
        this.field_152480_c.func_152488_a(var1, var2);
    }

    public void func_152464_b(int var1, long var2) {
        this.field_152481_d.func_152488_a(var1, var2);
    }

    public long func_152465_a() {
        return this.field_152480_c.func_152485_a();
    }

    public long func_152471_b() {
        return this.field_152481_d.func_152485_a();
    }

    public long func_152472_c() {
        return this.field_152480_c.func_152489_b();
    }

    public long func_152473_d() {
        return this.field_152481_d.func_152489_b();
    }

    public NetworkStatistics.PacketStat func_152477_e() {
        return this.field_152480_c.func_152484_c();
    }

    public NetworkStatistics.PacketStat func_152467_f() {
        return this.field_152480_c.func_152486_d();
    }

    public NetworkStatistics.PacketStat func_152475_g() {
        return this.field_152481_d.func_152484_c();
    }

    public NetworkStatistics.PacketStat func_152470_h() {
        return this.field_152481_d.func_152486_d();
    }

    public NetworkStatistics.PacketStat func_152466_a(int var1) {
        return this.field_152480_c.func_152487_a(var1);
    }

    public NetworkStatistics.PacketStat func_152468_b(int var1) {
        return this.field_152481_d.func_152487_a(var1);
    }

    public static class PacketStat {
        private final int packetId;
        private final NetworkStatistics.PacketStatData data;

        public PacketStat(int var1, NetworkStatistics.PacketStatData var2) {
            this.packetId = var1;
            this.data = var2;
        }

        @Override
        public String toString() {
            return "PacketStat(" + this.packetId + ")" + this.data;
        }
    }

    static class PacketStatData {
        private final long totalBytes;
        private final int count;
        private final double averageBytes;

        private PacketStatData(long var1, int var3, double var4) {
            this.totalBytes = var1;
            this.count = var3;
            this.averageBytes = var4;
        }

        public NetworkStatistics.PacketStatData func_152494_a(long var1) {
            return new NetworkStatistics.PacketStatData(var1 + this.totalBytes, this.count + 1, (var1 + this.totalBytes) / (this.count + 1));
        }

        public long getTotalBytes() {
            return this.totalBytes;
        }

        public int getCount() {
            return this.count;
        }

        @Override
        public String toString() {
            return "{totalBytes=" + this.totalBytes + ", count=" + this.count + ", averageBytes=" + this.averageBytes + '}';
        }
    }

    static class Tracker {
        private AtomicReference[] field_152490_a = new AtomicReference[100];

        public Tracker() {
            for (int i = 0; i < 100; i++) {
                this.field_152490_a[i] = new AtomicReference<>(new NetworkStatistics.PacketStatData(0L, 0, 0.0));
            }
        }

        public void func_152488_a(int var1, long var2) {
            try {
                if (var1 < 0 || var1 >= 100) {
                    return;
                }

                NetworkStatistics.PacketStatData networkstatistics$packetstatdata;
                NetworkStatistics.PacketStatData networkstatistics$packetstatdata1;
                do {
                    networkstatistics$packetstatdata = (NetworkStatistics.PacketStatData)this.field_152490_a[var1].get();
                    networkstatistics$packetstatdata1 = networkstatistics$packetstatdata.func_152494_a(var2);
                } while (!this.field_152490_a[var1].compareAndSet(networkstatistics$packetstatdata, networkstatistics$packetstatdata1));
            } catch (Exception exception) {
                if (NetworkStatistics.LOGGER.isDebugEnabled()) {
                    NetworkStatistics.LOGGER.debug(NetworkStatistics.NETSTAT_MARKER, "NetStat failed with packetId: " + var1, exception);
                }
            }
        }

        public long func_152485_a() {
            long i = 0L;

            for (int j = 0; j < 100; j++) {
                i += ((NetworkStatistics.PacketStatData)this.field_152490_a[j].get()).getTotalBytes();
            }

            return i;
        }

        public long func_152489_b() {
            long i = 0L;

            for (int j = 0; j < 100; j++) {
                i += ((NetworkStatistics.PacketStatData)this.field_152490_a[j].get()).getCount();
            }

            return i;
        }

        public NetworkStatistics.PacketStat func_152484_c() {
            int i = -1;
            NetworkStatistics.PacketStatData networkstatistics$packetstatdata = new NetworkStatistics.PacketStatData(-1L, -1, 0.0);

            for (int j = 0; j < 100; j++) {
                NetworkStatistics.PacketStatData networkstatistics$packetstatdata1 = (NetworkStatistics.PacketStatData)this.field_152490_a[j].get();
                if (networkstatistics$packetstatdata1.totalBytes > networkstatistics$packetstatdata.totalBytes) {
                    i = j;
                    networkstatistics$packetstatdata = networkstatistics$packetstatdata1;
                }
            }

            return new NetworkStatistics.PacketStat(i, networkstatistics$packetstatdata);
        }

        public NetworkStatistics.PacketStat func_152486_d() {
            int i = -1;
            NetworkStatistics.PacketStatData networkstatistics$packetstatdata = new NetworkStatistics.PacketStatData(-1L, -1, 0.0);

            for (int j = 0; j < 100; j++) {
                NetworkStatistics.PacketStatData networkstatistics$packetstatdata1 = (NetworkStatistics.PacketStatData)this.field_152490_a[j].get();
                if (networkstatistics$packetstatdata1.count > networkstatistics$packetstatdata.count) {
                    i = j;
                    networkstatistics$packetstatdata = networkstatistics$packetstatdata1;
                }
            }

            return new NetworkStatistics.PacketStat(i, networkstatistics$packetstatdata);
        }

        public NetworkStatistics.PacketStat func_152487_a(int var1) {
            return var1 >= 0 && var1 < 100 ? new NetworkStatistics.PacketStat(var1, (NetworkStatistics.PacketStatData)this.field_152490_a[var1].get()) : null;
        }
    }
}
