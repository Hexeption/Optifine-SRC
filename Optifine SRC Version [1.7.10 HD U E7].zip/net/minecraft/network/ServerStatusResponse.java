package net.minecraft.network;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.mojang.authlib.GameProfile;
import java.lang.reflect.Type;
import java.util.UUID;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.JsonUtils;

public class ServerStatusResponse {
    private IChatComponent serverMotd;
    private ServerStatusResponse.PlayerCountData playerCount;
    private ServerStatusResponse.MinecraftProtocolVersionIdentifier protocolVersion;
    private String favicon;

    public IChatComponent getServerDescription() {
        return this.serverMotd;
    }

    public void setServerDescription(IChatComponent var1) {
        this.serverMotd = var1;
    }

    public ServerStatusResponse.PlayerCountData getPlayerCountData() {
        return this.playerCount;
    }

    public void setPlayerCountData(ServerStatusResponse.PlayerCountData var1) {
        this.playerCount = var1;
    }

    public ServerStatusResponse.MinecraftProtocolVersionIdentifier getProtocolVersionInfo() {
        return this.protocolVersion;
    }

    public void setProtocolVersionInfo(ServerStatusResponse.MinecraftProtocolVersionIdentifier var1) {
        this.protocolVersion = var1;
    }

    public void setFavicon(String var1) {
        this.favicon = var1;
    }

    public String getFavicon() {
        return this.favicon;
    }

    public static class MinecraftProtocolVersionIdentifier {
        private final String name;
        private final int protocol;

        public MinecraftProtocolVersionIdentifier(String var1, int var2) {
            this.name = var1;
            this.protocol = var2;
        }

        public String getName() {
            return this.name;
        }

        public int getProtocol() {
            return this.protocol;
        }

        public static class Serializer implements JsonDeserializer, JsonSerializer {
            public ServerStatusResponse.MinecraftProtocolVersionIdentifier deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) {
                JsonObject jsonobject = JsonUtils.getElementAsJsonObject(var1, "version");
                return new ServerStatusResponse.MinecraftProtocolVersionIdentifier(
                    JsonUtils.getJsonObjectStringFieldValue(jsonobject, "name"), JsonUtils.getJsonObjectIntegerFieldValue(jsonobject, "protocol")
                );
            }

            public JsonElement serialize(ServerStatusResponse.MinecraftProtocolVersionIdentifier var1, Type var2, JsonSerializationContext var3) {
                JsonObject jsonobject = new JsonObject();
                jsonobject.addProperty("name", var1.getName());
                jsonobject.addProperty("protocol", var1.getProtocol());
                return jsonobject;
            }

            @Override
            public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
                return this.serialize((ServerStatusResponse.MinecraftProtocolVersionIdentifier)var1, var2, var3);
            }
        }
    }

    public static class PlayerCountData {
        private final int maxPlayers;
        private final int onlinePlayerCount;
        private GameProfile[] players;

        public PlayerCountData(int var1, int var2) {
            this.maxPlayers = var1;
            this.onlinePlayerCount = var2;
        }

        public int getMaxPlayers() {
            return this.maxPlayers;
        }

        public int getOnlinePlayerCount() {
            return this.onlinePlayerCount;
        }

        public GameProfile[] getPlayers() {
            return this.players;
        }

        public void setPlayers(GameProfile[] var1) {
            this.players = var1;
        }

        public static class Serializer implements JsonDeserializer, JsonSerializer {
            public ServerStatusResponse.PlayerCountData deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) {
                JsonObject jsonobject = JsonUtils.getElementAsJsonObject(var1, "players");
                ServerStatusResponse.PlayerCountData serverstatusresponse$playercountdata = new ServerStatusResponse.PlayerCountData(
                    JsonUtils.getJsonObjectIntegerFieldValue(jsonobject, "max"), JsonUtils.getJsonObjectIntegerFieldValue(jsonobject, "online")
                );
                if (JsonUtils.jsonObjectFieldTypeIsArray(jsonobject, "sample")) {
                    JsonArray jsonarray = JsonUtils.getJsonObjectJsonArrayField(jsonobject, "sample");
                    if (jsonarray.size() > 0) {
                        GameProfile[] agameprofile = new GameProfile[jsonarray.size()];

                        for (int i = 0; i < agameprofile.length; i++) {
                            JsonObject jsonobject1 = JsonUtils.getElementAsJsonObject(jsonarray.get(i), "player[" + i + "]");
                            String s = JsonUtils.getJsonObjectStringFieldValue(jsonobject1, "id");
                            agameprofile[i] = new GameProfile(UUID.fromString(s), JsonUtils.getJsonObjectStringFieldValue(jsonobject1, "name"));
                        }

                        serverstatusresponse$playercountdata.setPlayers(agameprofile);
                    }
                }

                return serverstatusresponse$playercountdata;
            }

            public JsonElement serialize(ServerStatusResponse.PlayerCountData var1, Type var2, JsonSerializationContext var3) {
                JsonObject jsonobject = new JsonObject();
                jsonobject.addProperty("max", var1.getMaxPlayers());
                jsonobject.addProperty("online", var1.getOnlinePlayerCount());
                if (var1.getPlayers() != null && var1.getPlayers().length > 0) {
                    JsonArray jsonarray = new JsonArray();

                    for (int i = 0; i < var1.getPlayers().length; i++) {
                        JsonObject jsonobject1 = new JsonObject();
                        UUID uuid = var1.getPlayers()[i].getId();
                        jsonobject1.addProperty("id", uuid == null ? "" : uuid.toString());
                        jsonobject1.addProperty("name", var1.getPlayers()[i].getName());
                        jsonarray.add(jsonobject1);
                    }

                    jsonobject.add("sample", jsonarray);
                }

                return jsonobject;
            }

            @Override
            public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
                return this.serialize((ServerStatusResponse.PlayerCountData)var1, var2, var3);
            }
        }
    }

    public static class Serializer implements JsonDeserializer, JsonSerializer {
        public ServerStatusResponse deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) {
            JsonObject jsonobject = JsonUtils.getElementAsJsonObject(var1, "status");
            ServerStatusResponse serverstatusresponse = new ServerStatusResponse();
            if (jsonobject.has("description")) {
                serverstatusresponse.setServerDescription(var3.deserialize(jsonobject.get("description"), IChatComponent.class));
            }

            if (jsonobject.has("players")) {
                serverstatusresponse.setPlayerCountData(var3.deserialize(jsonobject.get("players"), ServerStatusResponse.PlayerCountData.class));
            }

            if (jsonobject.has("version")) {
                serverstatusresponse.setProtocolVersionInfo(
                    var3.deserialize(jsonobject.get("version"), ServerStatusResponse.MinecraftProtocolVersionIdentifier.class)
                );
            }

            if (jsonobject.has("favicon")) {
                serverstatusresponse.setFavicon(JsonUtils.getJsonObjectStringFieldValue(jsonobject, "favicon"));
            }

            return serverstatusresponse;
        }

        public JsonElement serialize(ServerStatusResponse var1, Type var2, JsonSerializationContext var3) {
            JsonObject jsonobject = new JsonObject();
            if (var1.getServerDescription() != null) {
                jsonobject.add("description", var3.serialize(var1.getServerDescription()));
            }

            if (var1.getPlayerCountData() != null) {
                jsonobject.add("players", var3.serialize(var1.getPlayerCountData()));
            }

            if (var1.getProtocolVersionInfo() != null) {
                jsonobject.add("version", var3.serialize(var1.getProtocolVersionInfo()));
            }

            if (var1.getFavicon() != null) {
                jsonobject.addProperty("favicon", var1.getFavicon());
            }

            return jsonobject;
        }

        @Override
        public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
            return this.serialize((ServerStatusResponse)var1, var2, var3);
        }
    }
}
