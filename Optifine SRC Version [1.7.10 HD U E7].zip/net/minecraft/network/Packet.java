package net.minecraft.network;

import com.google.common.collect.BiMap;
import io.netty.buffer.ByteBuf;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class Packet {
    private static final Logger logger = LogManager.getLogger();

    public static Packet generatePacket(BiMap var0, int var1) {
        try {
            Class oclass = (Class)var0.get(var1);
            return oclass == null ? null : (Packet)oclass.newInstance();
        } catch (Exception exception) {
            logger.error("Couldn't create packet " + var1, exception);
            return null;
        }
    }

    public static void writeBlob(ByteBuf var0, byte[] var1) {
        var0.writeShort(var1.length);
        var0.writeBytes(var1);
    }

    public static byte[] readBlob(ByteBuf var0) throws IOException {
        short short1 = var0.readShort();
        if (short1 < 0) {
            throw new IOException("Key was smaller than nothing!  Weird key!");
        }

        byte[] abyte = new byte[short1];
        var0.readBytes(abyte);
        return abyte;
    }

    public abstract void readPacketData(PacketBuffer var1) throws IOException;

    public abstract void writePacketData(PacketBuffer var1) throws IOException;

    public abstract void processPacket(INetHandler var1);

    public boolean hasPriority() {
        return false;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }

    public String serialize() {
        return "";
    }
}
