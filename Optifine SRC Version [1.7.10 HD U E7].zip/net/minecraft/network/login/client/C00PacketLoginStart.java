package net.minecraft.network.login.client;

import com.mojang.authlib.GameProfile;
import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginServer;

public class C00PacketLoginStart extends Packet {
    private GameProfile profile;

    public C00PacketLoginStart() {
    }

    public C00PacketLoginStart(GameProfile var1) {
        this.profile = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.profile = new GameProfile(null, var1.readStringFromBuffer(16));
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeStringToBuffer(this.profile.getName());
    }

    public void processPacket(INetHandlerLoginServer var1) {
        var1.processLoginStart(this);
    }

    public GameProfile getProfile() {
        return this.profile;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerLoginServer)var1);
    }
}
