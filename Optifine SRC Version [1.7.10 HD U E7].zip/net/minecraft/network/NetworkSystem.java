package net.minecraft.network;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.local.LocalAddress;
import io.netty.channel.local.LocalServerChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import net.minecraft.client.network.NetHandlerHandshakeMemory;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.network.play.server.S40PacketDisconnect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.NetHandlerHandshakeTCP;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MessageDeserializer;
import net.minecraft.util.MessageDeserializer2;
import net.minecraft.util.MessageSerializer;
import net.minecraft.util.MessageSerializer2;
import net.minecraft.util.ReportedException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NetworkSystem {
    private static final Logger logger = LogManager.getLogger();
    private static final NioEventLoopGroup eventLoops = new NioEventLoopGroup(
        0, new ThreadFactoryBuilder().setNameFormat("Netty IO #%d").setDaemon(true).build()
    );
    private final MinecraftServer mcServer;
    public volatile boolean isAlive;
    private final List endpoints = Collections.synchronizedList(new ArrayList());
    private final List networkManagers = Collections.synchronizedList(new ArrayList());

    public NetworkSystem(MinecraftServer var1) {
        this.mcServer = var1;
        this.isAlive = true;
    }

    public void addLanEndpoint(InetAddress var1, int var2) throws IOException {
        synchronized (this.endpoints) {
            this.endpoints
                .add(
                    new ServerBootstrap()
                        .channel(NioServerSocketChannel.class)
                        .childHandler(
                            new ChannelInitializer() {
                                @Override
                                protected void initChannel(Channel var1) {
                                    try {
                                        var1.config().setOption(ChannelOption.IP_TOS, 24);
                                    } catch (ChannelException channelexception1) {
                                    }

                                    try {
                                        var1.config().setOption(ChannelOption.TCP_NODELAY, false);
                                    } catch (ChannelException channelexception) {
                                    }

                                    var1.pipeline()
                                        .addLast("timeout", new ReadTimeoutHandler(30))
                                        .addLast("legacy_query", new PingResponseHandler(NetworkSystem.this))
                                        .addLast("splitter", new MessageDeserializer2())
                                        .addLast("decoder", new MessageDeserializer(NetworkManager.STATISTICS))
                                        .addLast("prepender", new MessageSerializer2())
                                        .addLast("encoder", new MessageSerializer(NetworkManager.STATISTICS));
                                    NetworkManager networkmanager = new NetworkManager(false);
                                    NetworkSystem.this.networkManagers.add(networkmanager);
                                    var1.pipeline().addLast("packet_handler", networkmanager);
                                    networkmanager.setNetHandler(new NetHandlerHandshakeTCP(NetworkSystem.this.mcServer, networkmanager));
                                }
                            }
                        )
                        .group(eventLoops)
                        .localAddress(var1, var2)
                        .bind()
                        .syncUninterruptibly()
                );
        }
    }

    public SocketAddress addLocalEndpoint() {
        ChannelFuture channelfuture;
        synchronized (this.endpoints) {
            channelfuture = new ServerBootstrap().channel(LocalServerChannel.class).childHandler(new ChannelInitializer() {
                @Override
                protected void initChannel(Channel var1) {
                    NetworkManager networkmanager = new NetworkManager(false);
                    networkmanager.setNetHandler(new NetHandlerHandshakeMemory(NetworkSystem.this.mcServer, networkmanager));
                    NetworkSystem.this.networkManagers.add(networkmanager);
                    var1.pipeline().addLast("packet_handler", networkmanager);
                }
            }).group(eventLoops).localAddress(LocalAddress.ANY).bind().syncUninterruptibly();
            this.endpoints.add(channelfuture);
        }

        return channelfuture.channel().localAddress();
    }

    public void terminateEndpoints() {
        this.isAlive = false;

        for (ChannelFuture channelfuture : (Iterable<ChannelFuture>) (Iterable) this.endpoints) {
            channelfuture.channel().close().syncUninterruptibly();
        }
    }

    public void networkTick() {
        synchronized (this.networkManagers) {
            Iterator iterator = this.networkManagers.iterator();

            while (iterator.hasNext()) {
                final NetworkManager networkmanager = (NetworkManager)iterator.next();
                if (!networkmanager.isChannelOpen()) {
                    iterator.remove();
                    if (networkmanager.getExitMessage() != null) {
                        networkmanager.getNetHandler().onDisconnect(networkmanager.getExitMessage());
                    } else if (networkmanager.getNetHandler() != null) {
                        networkmanager.getNetHandler().onDisconnect(new ChatComponentText("Disconnected"));
                    }
                } else {
                    try {
                        networkmanager.processReceivedPackets();
                    } catch (Exception exception) {
                        if (networkmanager.isLocalChannel()) {
                            CrashReport crashreport = CrashReport.makeCrashReport(exception, "Ticking memory connection");
                            CrashReportCategory crashreportcategory = crashreport.makeCategory("Ticking connection");
                            crashreportcategory.addCrashSectionCallable("Connection", new Callable() {
                                public String call() {
                                    return networkmanager.toString();
                                }
                            });
                            throw new ReportedException(crashreport);
                        }

                        logger.warn("Failed to handle packet for " + networkmanager.getRemoteAddress(), exception);
                        final ChatComponentText chatcomponenttext = new ChatComponentText("Internal server error");
                        networkmanager.scheduleOutboundPacket(new S40PacketDisconnect(chatcomponenttext), new GenericFutureListener() {
                            @Override
                            public void operationComplete(Future var1) {
                                networkmanager.closeChannel(chatcomponenttext);
                            }
                        });
                        networkmanager.disableAutoRead();
                    }
                }
            }
        }
    }

    public MinecraftServer getServer() {
        return this.mcServer;
    }
}
