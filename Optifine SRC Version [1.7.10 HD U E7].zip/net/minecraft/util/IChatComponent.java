package net.minecraft.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map.Entry;

public interface IChatComponent extends Iterable {
    IChatComponent setChatStyle(ChatStyle var1);

    ChatStyle getChatStyle();

    IChatComponent appendText(String var1);

    IChatComponent appendSibling(IChatComponent var1);

    String getUnformattedTextForChat();

    String getUnformattedText();

    String getFormattedText();

    List getSiblings();

    IChatComponent createCopy();

    class Serializer implements JsonDeserializer, JsonSerializer {
        private static final Gson GSON;

        public IChatComponent deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) {
            if (var1.isJsonPrimitive()) {
                return new ChatComponentText(var1.getAsString());
            }

            if (!var1.isJsonObject()) {
                if (var1.isJsonArray()) {
                    JsonArray jsonarray1 = var1.getAsJsonArray();
                    IChatComponent ichatcomponent = null;

                    for (JsonElement jsonelement : jsonarray1) {
                        IChatComponent ichatcomponent1 = this.deserialize(jsonelement, jsonelement.getClass(), var3);
                        if (ichatcomponent == null) {
                            ichatcomponent = ichatcomponent1;
                        } else {
                            ichatcomponent.appendSibling(ichatcomponent1);
                        }
                    }

                    return ichatcomponent;
                } else {
                    throw new JsonParseException("Don't know how to turn " + var1.toString() + " into a Component");
                }
            } else {
                JsonObject jsonobject = var1.getAsJsonObject();
                ChatComponentStyle chatcomponentstyle;
                if (jsonobject.has("text")) {
                    chatcomponentstyle = new ChatComponentText(jsonobject.get("text").getAsString());
                } else {
                    if (!jsonobject.has("translate")) {
                        throw new JsonParseException("Don't know how to turn " + var1.toString() + " into a Component");
                    }

                    String s = jsonobject.get("translate").getAsString();
                    if (jsonobject.has("with")) {
                        JsonArray jsonarray = jsonobject.getAsJsonArray("with");
                        Object[] aobject = new Object[jsonarray.size()];

                        for (int i = 0; i < aobject.length; i++) {
                            aobject[i] = this.deserialize(jsonarray.get(i), var2, var3);
                            if (aobject[i] instanceof ChatComponentText) {
                                ChatComponentText chatcomponenttext = (ChatComponentText)aobject[i];
                                if (chatcomponenttext.getChatStyle().isEmpty() && chatcomponenttext.getSiblings().isEmpty()) {
                                    aobject[i] = chatcomponenttext.getChatComponentText_TextValue();
                                }
                            }
                        }

                        chatcomponentstyle = new ChatComponentTranslation(s, aobject);
                    } else {
                        chatcomponentstyle = new ChatComponentTranslation(s);
                    }
                }

                if (jsonobject.has("extra")) {
                    JsonArray jsonarray2 = jsonobject.getAsJsonArray("extra");
                    if (jsonarray2.size() <= 0) {
                        throw new JsonParseException("Unexpected empty array of components");
                    }

                    for (int j = 0; j < jsonarray2.size(); j++) {
                        chatcomponentstyle.appendSibling(this.deserialize(jsonarray2.get(j), var2, var3));
                    }
                }

                chatcomponentstyle.setChatStyle(var3.deserialize(var1, ChatStyle.class));
                return chatcomponentstyle;
            }
        }

        private void serializeChatStyle(ChatStyle var1, JsonObject var2, JsonSerializationContext var3) {
            JsonElement jsonelement = var3.serialize(var1);
            if (jsonelement.isJsonObject()) {
                JsonObject jsonobject = (JsonObject)jsonelement;

                for (Entry entry : jsonobject.entrySet()) {
                    var2.add((String)entry.getKey(), (JsonElement)entry.getValue());
                }
            }
        }

        public JsonElement serialize(IChatComponent var1, Type var2, JsonSerializationContext var3) {
            if (var1 instanceof ChatComponentText && var1.getChatStyle().isEmpty() && var1.getSiblings().isEmpty()) {
                return new JsonPrimitive(((ChatComponentText)var1).getChatComponentText_TextValue());
            }

            JsonObject jsonobject = new JsonObject();
            if (!var1.getChatStyle().isEmpty()) {
                this.serializeChatStyle(var1.getChatStyle(), jsonobject, var3);
            }

            if (!var1.getSiblings().isEmpty()) {
                JsonArray jsonarray = new JsonArray();

                for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) var1.getSiblings()) {
                    jsonarray.add(this.serialize(ichatcomponent, ichatcomponent.getClass(), var3));
                }

                jsonobject.add("extra", jsonarray);
            }

            if (var1 instanceof ChatComponentText) {
                jsonobject.addProperty("text", ((ChatComponentText)var1).getChatComponentText_TextValue());
            } else {
                if (!(var1 instanceof ChatComponentTranslation)) {
                    throw new IllegalArgumentException("Don't know how to serialize " + var1 + " as a Component");
                }

                ChatComponentTranslation chatcomponenttranslation = (ChatComponentTranslation)var1;
                jsonobject.addProperty("translate", chatcomponenttranslation.getKey());
                if (chatcomponenttranslation.getFormatArgs() != null && chatcomponenttranslation.getFormatArgs().length > 0) {
                    JsonArray jsonarray1 = new JsonArray();

                    for (Object object : chatcomponenttranslation.getFormatArgs()) {
                        if (object instanceof IChatComponent) {
                            jsonarray1.add(this.serialize((IChatComponent)object, object.getClass(), var3));
                        } else {
                            jsonarray1.add(new JsonPrimitive(String.valueOf(object)));
                        }
                    }

                    jsonobject.add("with", jsonarray1);
                }
            }

            return jsonobject;
        }

        public static String componentToJson(IChatComponent var0) {
            return GSON.toJson(var0);
        }

        public static IChatComponent jsonToComponent(String var0) {
            return GSON.fromJson(var0, IChatComponent.class);
        }

        @Override
        public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
            return this.serialize((IChatComponent)var1, var2, var3);
        }

        static {
            GsonBuilder gsonbuilder = new GsonBuilder();
            gsonbuilder.registerTypeHierarchyAdapter(IChatComponent.class, new IChatComponent.Serializer());
            gsonbuilder.registerTypeHierarchyAdapter(ChatStyle.class, new ChatStyle.Serializer());
            gsonbuilder.registerTypeAdapterFactory(new EnumTypeAdapterFactory());
            GSON = gsonbuilder.create();
        }
    }
}
