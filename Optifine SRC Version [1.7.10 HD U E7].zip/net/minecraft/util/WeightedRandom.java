package net.minecraft.util;

import java.util.Collection;
import java.util.Random;

public class WeightedRandom {
    public static int getTotalWeight(Collection var0) {
        int i = 0;

        for (WeightedRandom.Item weightedrandom$item : (Iterable<WeightedRandom.Item>) (Iterable) var0) {
            i += weightedrandom$item.itemWeight;
        }

        return i;
    }

    public static WeightedRandom.Item getRandomItem(Random var0, Collection var1, int var2) {
        if (var2 <= 0) {
            throw new IllegalArgumentException();
        }

        int i = var0.nextInt(var2);

        for (WeightedRandom.Item weightedrandom$item : (Iterable<WeightedRandom.Item>) (Iterable) var1) {
            i -= weightedrandom$item.itemWeight;
            if (i < 0) {
                return weightedrandom$item;
            }
        }

        return null;
    }

    public static WeightedRandom.Item getRandomItem(Random var0, Collection var1) {
        return getRandomItem(var0, var1, getTotalWeight(var1));
    }

    public static int getTotalWeight(WeightedRandom.Item[] var0) {
        int i = 0;

        for (WeightedRandom.Item weightedrandom$item : var0) {
            i += weightedrandom$item.itemWeight;
        }

        return i;
    }

    public static WeightedRandom.Item getRandomItem(Random var0, WeightedRandom.Item[] var1, int var2) {
        if (var2 <= 0) {
            throw new IllegalArgumentException();
        }

        int i = var0.nextInt(var2);

        for (WeightedRandom.Item weightedrandom$item : var1) {
            i -= weightedrandom$item.itemWeight;
            if (i < 0) {
                return weightedrandom$item;
            }
        }

        return null;
    }

    public static WeightedRandom.Item getRandomItem(Random var0, WeightedRandom.Item[] var1) {
        return getRandomItem(var0, var1, getTotalWeight(var1));
    }

    public static class Item {
        protected int itemWeight;

        public Item(int var1) {
            this.itemWeight = var1;
        }
    }
}
