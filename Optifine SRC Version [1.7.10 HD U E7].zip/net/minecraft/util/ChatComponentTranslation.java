package net.minecraft.util;

import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.IllegalFormatException;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatComponentTranslation extends ChatComponentStyle {
    private final String key;
    private final Object[] formatArgs;
    private final Object syncLock = new Object();
    private long lastTranslationUpdateTimeInMilliseconds = -1L;
    List children = Lists.newArrayList();
    public static final Pattern stringVariablePattern = Pattern.compile("%(?:(\\d+)\\$)?([A-Za-z%]|$)");

    public ChatComponentTranslation(String var1, Object... var2) {
        this.key = var1;
        this.formatArgs = var2;

        for (Object object : var2) {
            if (object instanceof IChatComponent) {
                ((IChatComponent)object).getChatStyle().setParentStyle(this.getChatStyle());
            }
        }
    }

    synchronized void ensureInitialized() {
        synchronized (this.syncLock) {
            long i = StatCollector.getLastTranslationUpdateTimeInMilliseconds();
            if (i == this.lastTranslationUpdateTimeInMilliseconds) {
                return;
            }

            this.lastTranslationUpdateTimeInMilliseconds = i;
            this.children.clear();
        }

        try {
            this.initializeFromFormat(StatCollector.translateToLocal(this.key));
        } catch (ChatComponentTranslationFormatException chatcomponenttranslationformatexception1) {
            this.children.clear();

            try {
                this.initializeFromFormat(StatCollector.translateToFallback(this.key));
            } catch (ChatComponentTranslationFormatException chatcomponenttranslationformatexception) {
                throw chatcomponenttranslationformatexception1;
            }
        }
    }

    protected void initializeFromFormat(String var1) {
        boolean flag = false;
        Matcher matcher = stringVariablePattern.matcher(var1);
        int i = 0;
        int j = 0;

        try {
            while (matcher.find(j)) {
                int k = matcher.start();
                int l = matcher.end();
                if (k > j) {
                    ChatComponentText chatcomponenttext = new ChatComponentText(String.format(var1.substring(j, k)));
                    chatcomponenttext.getChatStyle().setParentStyle(this.getChatStyle());
                    this.children.add(chatcomponenttext);
                }

                String s2 = matcher.group(2);
                String s = var1.substring(k, l);
                if ("%".equals(s2) && "%%".equals(s)) {
                    ChatComponentText chatcomponenttext2 = new ChatComponentText("%");
                    chatcomponenttext2.getChatStyle().setParentStyle(this.getChatStyle());
                    this.children.add(chatcomponenttext2);
                } else {
                    if (!"s".equals(s2)) {
                        throw new ChatComponentTranslationFormatException(this, "Unsupported format: '" + s + "'");
                    }

                    String s1 = matcher.group(1);
                    int i1 = s1 != null ? Integer.parseInt(s1) - 1 : i++;
                    this.children.add(this.getFormatArgumentAsComponent(i1));
                }

                j = l;
            }

            if (j < var1.length()) {
                ChatComponentText chatcomponenttext1 = new ChatComponentText(String.format(var1.substring(j)));
                chatcomponenttext1.getChatStyle().setParentStyle(this.getChatStyle());
                this.children.add(chatcomponenttext1);
            }
        } catch (IllegalFormatException illegalformatexception) {
            throw new ChatComponentTranslationFormatException(this, illegalformatexception);
        }
    }

    private IChatComponent getFormatArgumentAsComponent(int var1) {
        if (var1 >= this.formatArgs.length) {
            throw new ChatComponentTranslationFormatException(this, var1);
        }

        Object object = this.formatArgs[var1];
        IChatComponent ichatcomponent;
        if (object instanceof IChatComponent) {
            ichatcomponent = (IChatComponent)object;
        } else {
            ichatcomponent = new ChatComponentText(object == null ? "null" : object.toString());
            ichatcomponent.getChatStyle().setParentStyle(this.getChatStyle());
        }

        return ichatcomponent;
    }

    @Override
    public IChatComponent setChatStyle(ChatStyle var1) {
        super.setChatStyle(var1);

        for (Object object : this.formatArgs) {
            if (object instanceof IChatComponent) {
                ((IChatComponent)object).getChatStyle().setParentStyle(this.getChatStyle());
            }
        }

        if (this.lastTranslationUpdateTimeInMilliseconds > -1L) {
            for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.children) {
                ichatcomponent.getChatStyle().setParentStyle(var1);
            }
        }

        return this;
    }

    @Override
    public Iterator iterator() {
        this.ensureInitialized();
        return Iterators.concat(createDeepCopyIterator(this.children), createDeepCopyIterator(this.siblings));
    }

    @Override
    public String getUnformattedTextForChat() {
        this.ensureInitialized();
        StringBuilder stringbuilder = new StringBuilder();

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.children) {
            stringbuilder.append(ichatcomponent.getUnformattedTextForChat());
        }

        return stringbuilder.toString();
    }

    public ChatComponentTranslation createCopy() {
        Object[] aobject = new Object[this.formatArgs.length];

        for (int i = 0; i < this.formatArgs.length; i++) {
            if (this.formatArgs[i] instanceof IChatComponent) {
                aobject[i] = ((IChatComponent)this.formatArgs[i]).createCopy();
            } else {
                aobject[i] = this.formatArgs[i];
            }
        }

        ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation(this.key, aobject);
        chatcomponenttranslation.setChatStyle(this.getChatStyle().createShallowCopy());

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.getSiblings()) {
            chatcomponenttranslation.appendSibling(ichatcomponent.createCopy());
        }

        return chatcomponenttranslation;
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ChatComponentTranslation)) {
            return false;
        }

        ChatComponentTranslation chatcomponenttranslation = (ChatComponentTranslation)var1;
        return Arrays.equals(this.formatArgs, chatcomponenttranslation.formatArgs) && this.key.equals(chatcomponenttranslation.key) && super.equals(var1);
    }

    @Override
    public int hashCode() {
        int i = super.hashCode();
        i = 31 * i + this.key.hashCode();
        return 31 * i + Arrays.hashCode(this.formatArgs);
    }

    @Override
    public String toString() {
        return "TranslatableComponent{key='"
            + this.key
            + '\''
            + ", args="
            + Arrays.toString(this.formatArgs)
            + ", siblings="
            + this.siblings
            + ", style="
            + this.getChatStyle()
            + '}';
    }

    public String getKey() {
        return this.key;
    }

    public Object[] getFormatArgs() {
        return this.formatArgs;
    }
}
