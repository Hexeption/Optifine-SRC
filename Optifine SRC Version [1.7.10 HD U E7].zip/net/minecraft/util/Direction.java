package net.minecraft.util;

public class Direction {
    public static final int[] offsetX = new int[]{0, -1, 0, 1};
    public static final int[] offsetZ = new int[]{1, 0, -1, 0};
    public static final String[] directions = new String[]{"SOUTH", "WEST", "NORTH", "EAST"};
    public static final int[] directionToFacing = new int[]{3, 4, 2, 5};
    public static final int[] facingToDirection = new int[]{-1, -1, 2, 0, 1, 3};
    public static final int[] rotateOpposite = new int[]{2, 3, 0, 1};
    public static final int[] enderEyeMetaToDirection = new int[]{1, 2, 3, 0};
    public static final int[] rotateLeft = new int[]{3, 0, 1, 2};
    public static final int[][] bedDirection = new int[][]{{1, 0, 3, 2, 5, 4}, {1, 0, 5, 4, 2, 3}, {1, 0, 2, 3, 4, 5}, {1, 0, 4, 5, 3, 2}};

    public static int getMovementDirection(double var0, double var2) {
        if (MathHelper.abs((float)var0) > MathHelper.abs((float)var2)) {
            return var0 > 0.0 ? 1 : 3;
        } else {
            return var2 > 0.0 ? 2 : 0;
        }
    }
}
