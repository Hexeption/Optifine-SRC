package net.minecraft.util;

import com.google.common.collect.ForwardingSet;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Set;

public class JsonSerializableSet extends ForwardingSet implements IJsonSerializable {
    private final Set underlyingSet = Sets.newHashSet();

    @Override
    public void func_152753_a(JsonElement var1) {
        if (var1.isJsonArray()) {
            for (JsonElement jsonelement : var1.getAsJsonArray()) {
                this.add(jsonelement.getAsString());
            }
        }
    }

    @Override
    public JsonElement getSerializableElement() {
        JsonArray jsonarray = new JsonArray();

        for (String s : (Iterable<String>) (Iterable) this) {
            jsonarray.add(new JsonPrimitive(s));
        }

        return jsonarray;
    }

    @Override
    protected Set delegate() {
        return this.underlyingSet;
    }
}
