package net.minecraft.util;

public class ChunkCoordinates implements Comparable {
    public int posX;
    public int posY;
    public int posZ;

    public ChunkCoordinates() {
    }

    public ChunkCoordinates(int var1, int var2, int var3) {
        this.posX = var1;
        this.posY = var2;
        this.posZ = var3;
    }

    public ChunkCoordinates(ChunkCoordinates var1) {
        this.posX = var1.posX;
        this.posY = var1.posY;
        this.posZ = var1.posZ;
    }

    @Override
    public boolean equals(Object var1) {
        if (!(var1 instanceof ChunkCoordinates)) {
            return false;
        }

        ChunkCoordinates chunkcoordinates = (ChunkCoordinates)var1;
        return this.posX == chunkcoordinates.posX && this.posY == chunkcoordinates.posY && this.posZ == chunkcoordinates.posZ;
    }

    @Override
    public int hashCode() {
        return this.posX + this.posZ << 8 + this.posY << 16;
    }

    public int compareTo(ChunkCoordinates var1) {
        if (this.posY == var1.posY) {
            return this.posZ == var1.posZ ? this.posX - var1.posX : this.posZ - var1.posZ;
        } else {
            return this.posY - var1.posY;
        }
    }

    public void set(int var1, int var2, int var3) {
        this.posX = var1;
        this.posY = var2;
        this.posZ = var3;
    }

    public float getDistanceSquared(int var1, int var2, int var3) {
        float f = this.posX - var1;
        float f1 = this.posY - var2;
        float f2 = this.posZ - var3;
        return f * f + f1 * f1 + f2 * f2;
    }

    public float getDistanceSquaredToChunkCoordinates(ChunkCoordinates var1) {
        return this.getDistanceSquared(var1.posX, var1.posY, var1.posZ);
    }

    @Override
    public String toString() {
        return "Pos{x=" + this.posX + ", y=" + this.posY + ", z=" + this.posZ + '}';
    }

    @Override
    public int compareTo(Object var1) {
        return this.compareTo((ChunkCoordinates)var1);
    }
}
