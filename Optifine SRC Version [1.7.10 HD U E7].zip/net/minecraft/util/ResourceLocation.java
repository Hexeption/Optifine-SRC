package net.minecraft.util;

import org.apache.commons.lang3.Validate;

public class ResourceLocation {
    private final String resourceDomain;
    private final String resourcePath;

    public ResourceLocation(String var1, String var2) {
        Validate.notNull(var2);
        if (var1 != null && var1.length() != 0) {
            this.resourceDomain = var1;
        } else {
            this.resourceDomain = "minecraft";
        }

        this.resourcePath = var2;
    }

    public ResourceLocation(String var1) {
        String s = "minecraft";
        String s1 = var1;
        int i = var1.indexOf(58);
        if (i >= 0) {
            s1 = var1.substring(i + 1, var1.length());
            if (i > 1) {
                s = var1.substring(0, i);
            }
        }

        this.resourceDomain = s.toLowerCase();
        this.resourcePath = s1;
    }

    public String getResourcePath() {
        return this.resourcePath;
    }

    public String getResourceDomain() {
        return this.resourceDomain;
    }

    @Override
    public String toString() {
        return this.resourceDomain + ":" + this.resourcePath;
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ResourceLocation)) {
            return false;
        }

        ResourceLocation resourcelocation = (ResourceLocation)var1;
        return this.resourceDomain.equals(resourcelocation.resourceDomain) && this.resourcePath.equals(resourcelocation.resourcePath);
    }

    @Override
    public int hashCode() {
        return 31 * this.resourceDomain.hashCode() + this.resourcePath.hashCode();
    }
}
