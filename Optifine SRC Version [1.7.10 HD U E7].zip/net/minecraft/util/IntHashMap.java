package net.minecraft.util;

import java.util.HashSet;
import java.util.Set;

public class IntHashMap {
    private transient IntHashMap.Entry[] slots;
    private transient int count;
    private int threshold;
    private final float growFactor;
    private transient volatile int versionStamp;
    private Set keySet = new HashSet();

    public IntHashMap() {
        this.growFactor = 12.0F / 16.0F;
        this.threshold = 12;
        this.slots = new IntHashMap.Entry[16];
    }

    private static int computeHash(int var0) {
        var0 ^= var0 >>> 20 ^ var0 >>> 12;
        return var0 ^ var0 >>> 7 ^ var0 >>> 4;
    }

    private static int getSlotIndex(int var0, int var1) {
        return var0 & var1 - 1;
    }

    public Object lookup(int var1) {
        int i = computeHash(var1);

        for (IntHashMap.Entry inthashmap$entry = this.slots[getSlotIndex(i, this.slots.length)];
            inthashmap$entry != null;
            inthashmap$entry = inthashmap$entry.nextEntry
        ) {
            if (inthashmap$entry.hashEntry == var1) {
                return inthashmap$entry.valueEntry;
            }
        }

        return null;
    }

    public boolean containsItem(int var1) {
        return this.lookupEntry(var1) != null;
    }

    final IntHashMap.Entry lookupEntry(int var1) {
        int i = computeHash(var1);

        for (IntHashMap.Entry inthashmap$entry = this.slots[getSlotIndex(i, this.slots.length)];
            inthashmap$entry != null;
            inthashmap$entry = inthashmap$entry.nextEntry
        ) {
            if (inthashmap$entry.hashEntry == var1) {
                return inthashmap$entry;
            }
        }

        return null;
    }

    public void addKey(int var1, Object var2) {
        this.keySet.add(var1);
        int i = computeHash(var1);
        int j = getSlotIndex(i, this.slots.length);

        for (IntHashMap.Entry inthashmap$entry = this.slots[j]; inthashmap$entry != null; inthashmap$entry = inthashmap$entry.nextEntry) {
            if (inthashmap$entry.hashEntry == var1) {
                inthashmap$entry.valueEntry = var2;
                return;
            }
        }

        this.versionStamp++;
        this.insert(i, var1, var2, j);
    }

    private void grow(int var1) {
        IntHashMap.Entry[] ainthashmap$entry = this.slots;
        int i = ainthashmap$entry.length;
        if (i == 1073741824) {
            this.threshold = Integer.MAX_VALUE;
        } else {
            IntHashMap.Entry[] ainthashmap$entry1 = new IntHashMap.Entry[var1];
            this.copyTo(ainthashmap$entry1);
            this.slots = ainthashmap$entry1;
            this.threshold = (int)(var1 * this.growFactor);
        }
    }

    private void copyTo(IntHashMap.Entry[] var1) {
        IntHashMap.Entry[] ainthashmap$entry = this.slots;
        int i = var1.length;

        for (int j = 0; j < ainthashmap$entry.length; j++) {
            IntHashMap.Entry inthashmap$entry = ainthashmap$entry[j];
            if (inthashmap$entry != null) {
                ainthashmap$entry[j] = null;

                while (true) {
                    IntHashMap.Entry inthashmap$entry1 = inthashmap$entry.nextEntry;
                    int k = getSlotIndex(inthashmap$entry.slotHash, i);
                    inthashmap$entry.nextEntry = var1[k];
                    var1[k] = inthashmap$entry;
                    inthashmap$entry = inthashmap$entry1;
                    if (inthashmap$entry == null) {
                        break;
                    }
                }
            }
        }
    }

    public Object removeObject(int var1) {
        this.keySet.remove(var1);
        IntHashMap.Entry inthashmap$entry = this.removeEntry(var1);
        return inthashmap$entry == null ? null : inthashmap$entry.valueEntry;
    }

    final IntHashMap.Entry removeEntry(int var1) {
        int i = computeHash(var1);
        int j = getSlotIndex(i, this.slots.length);
        IntHashMap.Entry inthashmap$entry = this.slots[j];
        IntHashMap.Entry inthashmap$entry1 = inthashmap$entry;

        while (inthashmap$entry1 != null) {
            IntHashMap.Entry inthashmap$entry2 = inthashmap$entry1.nextEntry;
            if (inthashmap$entry1.hashEntry == var1) {
                this.versionStamp++;
                this.count--;
                if (inthashmap$entry == inthashmap$entry1) {
                    this.slots[j] = inthashmap$entry2;
                } else {
                    inthashmap$entry.nextEntry = inthashmap$entry2;
                }

                return inthashmap$entry1;
            }

            inthashmap$entry = inthashmap$entry1;
            inthashmap$entry1 = inthashmap$entry2;
        }

        return inthashmap$entry1;
    }

    public void clearMap() {
        this.versionStamp++;
        IntHashMap.Entry[] ainthashmap$entry = this.slots;

        for (int i = 0; i < ainthashmap$entry.length; i++) {
            ainthashmap$entry[i] = null;
        }

        this.count = 0;
    }

    private void insert(int var1, int var2, Object var3, int var4) {
        IntHashMap.Entry inthashmap$entry = this.slots[var4];
        this.slots[var4] = new IntHashMap.Entry(var1, var2, var3, inthashmap$entry);
        if (this.count++ >= this.threshold) {
            this.grow(2 * this.slots.length);
        }
    }

    static class Entry {
        final int hashEntry;
        Object valueEntry;
        IntHashMap.Entry nextEntry;
        final int slotHash;

        Entry(int var1, int var2, Object var3, IntHashMap.Entry var4) {
            this.valueEntry = var3;
            this.nextEntry = var4;
            this.hashEntry = var2;
            this.slotHash = var1;
        }

        public final int getHash() {
            return this.hashEntry;
        }

        public final Object getValue() {
            return this.valueEntry;
        }

        @Override
        public final boolean equals(Object var1) {
            if (!(var1 instanceof IntHashMap.Entry)) {
                return false;
            }

            IntHashMap.Entry inthashmap$entry = (IntHashMap.Entry)var1;
            Integer integer = this.getHash();
            Integer integer1 = inthashmap$entry.getHash();
            if (integer == integer1 || integer != null && integer.equals(integer1)) {
                Object object = this.getValue();
                Object object1 = inthashmap$entry.getValue();
                if (object == object1 || object != null && object.equals(object1)) {
                    return true;
                }
            }

            return false;
        }

        @Override
        public final int hashCode() {
            return IntHashMap.computeHash(this.hashEntry);
        }

        @Override
        public final String toString() {
            return this.getHash() + "=" + this.getValue();
        }
    }
}
