package net.minecraft.util;

import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.Buffer;
import java.nio.IntBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.imageio.ImageIO;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.event.ClickEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

public class ScreenShotHelper {
    private static final Logger logger = LogManager.getLogger();
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss");
    private static IntBuffer pixelBuffer;
    private static int[] pixelValues;

    public static IChatComponent saveScreenshot(File var0, int var1, int var2, Framebuffer var3) {
        return saveScreenshot(var0, null, var1, var2, var3);
    }

    public static IChatComponent saveScreenshot(File var0, String var1, int var2, int var3, Framebuffer var4) {
        try {
            File file1 = new File(var0, "screenshots");
            file1.mkdir();
            if (OpenGlHelper.isFramebufferEnabled()) {
                var2 = var4.framebufferTextureWidth;
                var3 = var4.framebufferTextureHeight;
            }

            int i = var2 * var3;
            if (pixelBuffer == null || pixelBuffer.capacity() < i) {
                pixelBuffer = BufferUtils.createIntBuffer(i);
                pixelValues = new int[i];
            }

            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);
            GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 1);
            ((Buffer)pixelBuffer).clear();
            if (OpenGlHelper.isFramebufferEnabled()) {
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, var4.framebufferTexture);
                GL11.glGetTexImage(GL11.GL_TEXTURE_2D, 0, GL12.GL_BGRA, GL12.GL_UNSIGNED_INT_8_8_8_8_REV, pixelBuffer);
            } else {
                GL11.glReadPixels(0, 0, var2, var3, GL12.GL_BGRA, GL12.GL_UNSIGNED_INT_8_8_8_8_REV, pixelBuffer);
            }

            pixelBuffer.get(pixelValues);
            TextureUtil.func_147953_a(pixelValues, var2, var3);
            BufferedImage bufferedimage = null;
            if (OpenGlHelper.isFramebufferEnabled()) {
                bufferedimage = new BufferedImage(var4.framebufferWidth, var4.framebufferHeight, 1);
                int j = var4.framebufferTextureHeight - var4.framebufferHeight;

                for (int k = j; k < var4.framebufferTextureHeight; k++) {
                    for (int l = 0; l < var4.framebufferWidth; l++) {
                        bufferedimage.setRGB(l, k - j, pixelValues[k * var4.framebufferTextureWidth + l]);
                    }
                }
            } else {
                bufferedimage = new BufferedImage(var2, var3, 1);
                bufferedimage.setRGB(0, 0, var2, var3, pixelValues, 0, var2);
            }

            File file2;
            if (var1 == null) {
                file2 = getTimestampedPNGFileForDirectory(file1);
            } else {
                file2 = new File(file1, var1);
            }

            ImageIO.write(bufferedimage, "png", file2);
            ChatComponentText chatcomponenttext = new ChatComponentText(file2.getName());
            chatcomponenttext.getChatStyle().setChatClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, file2.getAbsolutePath()));
            chatcomponenttext.getChatStyle().setUnderlined(true);
            return new ChatComponentTranslation("screenshot.success", chatcomponenttext);
        } catch (Exception exception) {
            logger.warn("Couldn't save screenshot", exception);
            return new ChatComponentTranslation("screenshot.failure", exception.getMessage());
        }
    }

    private static File getTimestampedPNGFileForDirectory(File var0) {
        String s = dateFormat.format(new Date()).toString();
        int i = 1;

        while (true) {
            File file1 = new File(var0, s + (i == 1 ? "" : "_" + i) + ".png");
            if (!file1.exists()) {
                return file1;
            }

            i++;
        }
    }
}
