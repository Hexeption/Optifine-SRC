package net.minecraft.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public class EntityDamageSourceIndirect extends EntityDamageSource {
    private Entity indirectEntity;

    public EntityDamageSourceIndirect(String var1, Entity var2, Entity var3) {
        super(var1, var2);
        this.indirectEntity = var3;
    }

    @Override
    public Entity getSourceOfDamage() {
        return this.damageSourceEntity;
    }

    @Override
    public Entity getEntity() {
        return this.indirectEntity;
    }

    @Override
    public IChatComponent getDeathMessage(EntityLivingBase var1) {
        IChatComponent ichatcomponent = this.indirectEntity == null
            ? this.damageSourceEntity.getFormattedCommandSenderName()
            : this.indirectEntity.getFormattedCommandSenderName();
        ItemStack itemstack = this.indirectEntity instanceof EntityLivingBase ? ((EntityLivingBase)this.indirectEntity).getHeldItem() : null;
        String s = "death.attack." + this.damageType;
        String s1 = s + ".item";
        return itemstack != null && itemstack.hasDisplayName() && StatCollector.canTranslate(s1)
            ? new ChatComponentTranslation(s1, var1.getFormattedCommandSenderName(), ichatcomponent, itemstack.func_151000_E())
            : new ChatComponentTranslation(s, var1.getFormattedCommandSenderName(), ichatcomponent);
    }
}
