package net.minecraft.util;

import java.util.regex.Pattern;

public class StringUtils {
    private static final Pattern patternControlCode = Pattern.compile("(?i)\\u00A7[0-9A-FK-OR]");

    public static String ticksToElapsedTime(int var0) {
        int i = var0 / 20;
        int j = i / 60;
        i %= 60;
        return i < 10 ? j + ":0" + i : j + ":" + i;
    }

    public static String stripControlCodes(String var0) {
        return patternControlCode.matcher(var0).replaceAll("");
    }

    public static boolean isNullOrEmpty(String var0) {
        return var0 == null || "".equals(var0);
    }
}
