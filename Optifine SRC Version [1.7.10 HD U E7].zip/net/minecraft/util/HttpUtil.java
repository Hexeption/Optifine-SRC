package net.minecraft.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.ServerSocket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HttpUtil {
    private static final AtomicInteger downloadThreadsStarted = new AtomicInteger(0);
    private static final Logger logger = LogManager.getLogger();

    public static String buildPostString(Map var0) {
        StringBuilder stringbuilder = new StringBuilder();

        for (Entry entry : (Iterable<Entry>) (Iterable) var0.entrySet()) {
            if (stringbuilder.length() > 0) {
                stringbuilder.append('&');
            }

            try {
                stringbuilder.append(URLEncoder.encode((String)entry.getKey(), "UTF-8"));
            } catch (UnsupportedEncodingException unsupportedencodingexception1) {
                unsupportedencodingexception1.printStackTrace();
            }

            if (entry.getValue() != null) {
                stringbuilder.append('=');

                try {
                    stringbuilder.append(URLEncoder.encode(entry.getValue().toString(), "UTF-8"));
                } catch (UnsupportedEncodingException unsupportedencodingexception) {
                    unsupportedencodingexception.printStackTrace();
                }
            }
        }

        return stringbuilder.toString();
    }

    public static String postMap(URL var0, Map var1, boolean var2) {
        return post(var0, buildPostString(var1), var2);
    }

    private static String post(URL var0, String var1, boolean var2) {
        try {
            Proxy proxy = MinecraftServer.getServer() == null ? null : MinecraftServer.getServer().getServerProxy();
            if (proxy == null) {
                proxy = Proxy.NO_PROXY;
            }

            HttpURLConnection httpurlconnection = (HttpURLConnection)var0.openConnection(proxy);
            httpurlconnection.setRequestMethod("POST");
            httpurlconnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            httpurlconnection.setRequestProperty("Content-Length", "" + var1.getBytes().length);
            httpurlconnection.setRequestProperty("Content-Language", "en-US");
            httpurlconnection.setUseCaches(false);
            httpurlconnection.setDoInput(true);
            httpurlconnection.setDoOutput(true);
            DataOutputStream dataoutputstream = new DataOutputStream(httpurlconnection.getOutputStream());
            dataoutputstream.writeBytes(var1);
            dataoutputstream.flush();
            dataoutputstream.close();
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(httpurlconnection.getInputStream()));
            StringBuffer stringbuffer = new StringBuffer();

            while (true) {
                String s = bufferedreader.readLine();
                if (s == null) {
                    bufferedreader.close();
                    return stringbuffer.toString();
                }

                stringbuffer.append(s);
                stringbuffer.append('\r');
            }
        } catch (Exception exception) {
            if (!var2) {
                logger.error("Could not post to " + var0, exception);
            }

            return "";
        }
    }

    public static void downloadResourcePack(
        final File var0, final String var1, final HttpUtil.DownloadListener var2, final Map var3, final int var4, final IProgressUpdate var5, final Proxy var6
    ) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                URLConnection urlconnection = null;
                InputStream inputstream = null;
                DataOutputStream dataoutputstream = null;
                if (var5 != null) {
                    var5.resetProgressAndMessage("Downloading Texture Pack");
                    var5.displayLoadingString("Making Request...");
                }

                try {
                    byte[] abyte = new byte[4096];
                    URL url = new URL(var1);
                    urlconnection = url.openConnection(var6);
                    float f = 0.0F;
                    float f1 = var3.entrySet().size();

                    for (Entry entry : (Iterable<Entry>) (Iterable) var3.entrySet()) {
                        urlconnection.setRequestProperty((String)entry.getKey(), (String)entry.getValue());
                        if (var5 != null) {
                            f++;
                            var5.setLoadingProgress((int)(f / f1 * 100.0F));
                        }
                    }

                    inputstream = urlconnection.getInputStream();
                    f1 = urlconnection.getContentLength();
                    int i = urlconnection.getContentLength();
                    if (var5 != null) {
                        var5.displayLoadingString(String.format("Downloading file (%.2f MB)...", f1 / 1000.0F / 1000.0F));
                    }

                    if (var0.exists()) {
                        long j = var0.length();
                        if (j == i) {
                            var2.onDownloadComplete(var0);
                            if (var5 != null) {
                                var5.setDoneWorking();
                            }

                            return;
                        }

                        HttpUtil.logger.warn("Deleting " + var0 + " as it does not match what we currently have (" + i + " vs our " + j + ").");
                        var0.delete();
                    } else if (var0.getParentFile() != null) {
                        var0.getParentFile().mkdirs();
                    }

                    dataoutputstream = new DataOutputStream(new FileOutputStream(var0));
                    if (var4 > 0 && f1 > var4) {
                        if (var5 != null) {
                            var5.setDoneWorking();
                        }

                        throw new IOException("Filesize is bigger than maximum allowed (file is " + f + ", limit is " + var4 + ")");
                    } else {
                        int k = 0;

                        while (true) {
                            k = inputstream.read(abyte);
                            if (k < 0) {
                                var2.onDownloadComplete(var0);
                                if (var5 != null) {
                                    var5.setDoneWorking();
                                }

                                return;
                            }

                            f += k;
                            if (var5 != null) {
                                var5.setLoadingProgress((int)(f / f1 * 100.0F));
                            }

                            if (var4 > 0 && f > var4) {
                                if (var5 != null) {
                                    var5.setDoneWorking();
                                }

                                throw new IOException("Filesize was bigger than maximum allowed (got >= " + f + ", limit was " + var4 + ")");
                            }

                            dataoutputstream.write(abyte, 0, k);
                        }
                    }
                } catch (Throwable throwable) {
                    throwable.printStackTrace();
                } finally {
                    try {
                        if (inputstream != null) {
                            inputstream.close();
                        }
                    } catch (IOException ioexception1) {
                    }

                    try {
                        if (dataoutputstream != null) {
                            dataoutputstream.close();
                        }
                    } catch (IOException ioexception) {
                    }
                }
            }
        }, "File Downloader #" + downloadThreadsStarted.incrementAndGet());
        thread.setDaemon(true);
        thread.start();
    }

    public static int getSuitableLanPort() throws IOException {
        ServerSocket serversocket = null;
        int i = -1;

        try {
            serversocket = new ServerSocket(0);
            i = serversocket.getLocalPort();
        } finally {
            try {
                if (serversocket != null) {
                    serversocket.close();
                }
            } catch (IOException ioexception) {
            }
        }

        return i;
    }

    public static String get(URL var0) throws IOException {
        HttpURLConnection httpurlconnection = (HttpURLConnection)var0.openConnection();
        httpurlconnection.setRequestMethod("GET");
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(httpurlconnection.getInputStream()));
        StringBuilder stringbuilder = new StringBuilder();

        while (true) {
            String s = bufferedreader.readLine();
            if (s == null) {
                bufferedreader.close();
                return stringbuilder.toString();
            }

            stringbuilder.append(s);
            stringbuilder.append('\r');
        }
    }

    public interface DownloadListener {
        void onDownloadComplete(File var1);
    }
}
