package net.minecraft.util;

public class RegistryNamespacedDefaultedByKey extends RegistryNamespaced {
    private final String field_148760_d;
    private Object field_148761_e;

    public RegistryNamespacedDefaultedByKey(String var1) {
        this.field_148760_d = var1;
    }

    @Override
    public void addObject(int var1, String var2, Object var3) {
        if (this.field_148760_d.equals(var2)) {
            this.field_148761_e = var3;
        }

        super.addObject(var1, var2, var3);
    }

    @Override
    public Object getObject(String var1) {
        Object object = super.getObject(var1);
        return object == null ? this.field_148761_e : object;
    }

    @Override
    public Object getObjectById(int var1) {
        Object object = super.getObjectById(var1);
        return object == null ? this.field_148761_e : object;
    }

    @Override
    public Object getObject(Object var1) {
        return this.getObject((String)var1);
    }
}
