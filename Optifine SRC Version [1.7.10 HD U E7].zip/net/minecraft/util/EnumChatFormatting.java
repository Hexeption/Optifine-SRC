package net.minecraft.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public enum EnumChatFormatting {
    BLACK('0'),
    DARK_BLUE('1'),
    DARK_GREEN('2'),
    DARK_AQUA('3'),
    DARK_RED('4'),
    DARK_PURPLE('5'),
    GOLD('6'),
    GRAY('7'),
    DARK_GRAY('8'),
    BLUE('9'),
    GREEN('a'),
    AQUA('b'),
    RED('c'),
    LIGHT_PURPLE('d'),
    YELLOW('e'),
    WHITE('f'),
    OBFUSCATED('k', true),
    BOLD('l', true),
    STRIKETHROUGH('m', true),
    UNDERLINE('n', true),
    ITALIC('o', true),
    RESET('r');

    private static final Map formattingCodeMapping = new HashMap();
    private static final Map nameMapping = new HashMap();
    private static final Pattern formattingCodePattern = Pattern.compile("(?i)" + String.valueOf('\u00a7') + "[0-9A-FK-OR]");
    private final char formattingCode;
    private final boolean fancyStyling;
    private final String controlString;

    EnumChatFormatting(char var3) {
        this(var3, false);
    }

    EnumChatFormatting(char var3, boolean var4) {
        this.formattingCode = var3;
        this.fancyStyling = var4;
        this.controlString = "\u00a7" + var3;
    }

    public char getFormattingCode() {
        return this.formattingCode;
    }

    public boolean isFancyStyling() {
        return this.fancyStyling;
    }

    public boolean isColor() {
        return !this.fancyStyling && this != RESET;
    }

    public String getFriendlyName() {
        return this.name().toLowerCase();
    }

    @Override
    public String toString() {
        return this.controlString;
    }

    public static String getTextWithoutFormattingCodes(String var0) {
        return var0 == null ? null : formattingCodePattern.matcher(var0).replaceAll("");
    }

    public static EnumChatFormatting getValueByName(String var0) {
        return var0 == null ? null : (EnumChatFormatting)nameMapping.get(var0.toLowerCase());
    }

    public static Collection getValidValues(boolean var0, boolean var1) {
        ArrayList arraylist = new ArrayList();

        for (EnumChatFormatting enumchatformatting : values()) {
            if ((!enumchatformatting.isColor() || var0) && (!enumchatformatting.isFancyStyling() || var1)) {
                arraylist.add(enumchatformatting.getFriendlyName());
            }
        }

        return arraylist;
    }

    static {
        for (EnumChatFormatting enumchatformatting : values()) {
            formattingCodeMapping.put(enumchatformatting.getFormattingCode(), enumchatformatting);
            nameMapping.put(enumchatformatting.getFriendlyName(), enumchatformatting);
        }
    }
}
