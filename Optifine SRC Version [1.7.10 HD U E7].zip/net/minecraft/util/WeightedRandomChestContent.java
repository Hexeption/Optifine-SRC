package net.minecraft.util;

import java.util.Random;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntityDispenser;

public class WeightedRandomChestContent extends WeightedRandom.Item {
    private ItemStack theItemId;
    private int theMinimumChanceToGenerateItem;
    private int theMaximumChanceToGenerateItem;

    public WeightedRandomChestContent(Item var1, int var2, int var3, int var4, int var5) {
        super(var5);
        this.theItemId = new ItemStack(var1, 1, var2);
        this.theMinimumChanceToGenerateItem = var3;
        this.theMaximumChanceToGenerateItem = var4;
    }

    public WeightedRandomChestContent(ItemStack var1, int var2, int var3, int var4) {
        super(var4);
        this.theItemId = var1;
        this.theMinimumChanceToGenerateItem = var2;
        this.theMaximumChanceToGenerateItem = var3;
    }

    public static void generateChestContents(Random var0, WeightedRandomChestContent[] var1, IInventory var2, int var3) {
        for (int i = 0; i < var3; i++) {
            WeightedRandomChestContent weightedrandomchestcontent = (WeightedRandomChestContent)WeightedRandom.getRandomItem(var0, var1);
            int j = weightedrandomchestcontent.theMinimumChanceToGenerateItem
                + var0.nextInt(weightedrandomchestcontent.theMaximumChanceToGenerateItem - weightedrandomchestcontent.theMinimumChanceToGenerateItem + 1);
            if (weightedrandomchestcontent.theItemId.getMaxStackSize() >= j) {
                ItemStack itemstack1 = weightedrandomchestcontent.theItemId.copy();
                itemstack1.stackSize = j;
                var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack1);
            } else {
                for (int k = 0; k < j; k++) {
                    ItemStack itemstack = weightedrandomchestcontent.theItemId.copy();
                    itemstack.stackSize = 1;
                    var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack);
                }
            }
        }
    }

    public static void generateDispenserContents(Random var0, WeightedRandomChestContent[] var1, TileEntityDispenser var2, int var3) {
        for (int i = 0; i < var3; i++) {
            WeightedRandomChestContent weightedrandomchestcontent = (WeightedRandomChestContent)WeightedRandom.getRandomItem(var0, var1);
            int j = weightedrandomchestcontent.theMinimumChanceToGenerateItem
                + var0.nextInt(weightedrandomchestcontent.theMaximumChanceToGenerateItem - weightedrandomchestcontent.theMinimumChanceToGenerateItem + 1);
            if (weightedrandomchestcontent.theItemId.getMaxStackSize() >= j) {
                ItemStack itemstack1 = weightedrandomchestcontent.theItemId.copy();
                itemstack1.stackSize = j;
                var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack1);
            } else {
                for (int k = 0; k < j; k++) {
                    ItemStack itemstack = weightedrandomchestcontent.theItemId.copy();
                    itemstack.stackSize = 1;
                    var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack);
                }
            }
        }
    }

    public static WeightedRandomChestContent[] func_92080_a(WeightedRandomChestContent[] var0, WeightedRandomChestContent... var1) {
        WeightedRandomChestContent[] aweightedrandomchestcontent = new WeightedRandomChestContent[var0.length + var1.length];
        int i = 0;

        for (int j = 0; j < var0.length; j++) {
            aweightedrandomchestcontent[i++] = var0[j];
        }

        for (WeightedRandomChestContent weightedrandomchestcontent : var1) {
            aweightedrandomchestcontent[i++] = weightedrandomchestcontent;
        }

        return aweightedrandomchestcontent;
    }
}
