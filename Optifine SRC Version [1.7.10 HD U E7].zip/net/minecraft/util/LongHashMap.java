package net.minecraft.util;

public class LongHashMap {
    private transient LongHashMap.Entry[] hashArray = new LongHashMap.Entry[1024];
    private transient int numHashElements;
    private int capacity = (int)(12.0F / 16.0F * this.hashArray.length);
    private final float percentUseable = 12.0F / 16.0F;
    private transient volatile int modCount;
    private static final String __OBFID = "CL_00001492";

    private static int getHashedKey(long par0) {
        return (int)(par0 ^ par0 >>> 27);
    }

    private static int hash(int par0) {
        par0 ^= par0 >>> 20 ^ par0 >>> 12;
        return par0 ^ par0 >>> 7 ^ par0 >>> 4;
    }

    private static int getHashIndex(int par0, int par1) {
        return par0 & par1 - 1;
    }

    public int getNumHashElements() {
        return this.numHashElements;
    }

    public Object getValueByKey(long par1) {
        int i = getHashedKey(par1);

        for (LongHashMap.Entry longhashmap$entry = this.hashArray[getHashIndex(i, this.hashArray.length)];
            longhashmap$entry != null;
            longhashmap$entry = longhashmap$entry.nextEntry
        ) {
            if (longhashmap$entry.key == par1) {
                return longhashmap$entry.value;
            }
        }

        return null;
    }

    public boolean containsItem(long par1) {
        return this.getEntry(par1) != null;
    }

    final LongHashMap.Entry getEntry(long par1) {
        int i = getHashedKey(par1);

        for (LongHashMap.Entry longhashmap$entry = this.hashArray[getHashIndex(i, this.hashArray.length)];
            longhashmap$entry != null;
            longhashmap$entry = longhashmap$entry.nextEntry
        ) {
            if (longhashmap$entry.key == par1) {
                return longhashmap$entry;
            }
        }

        return null;
    }

    public void add(long par1, Object par3Obj) {
        int i = getHashedKey(par1);
        int j = getHashIndex(i, this.hashArray.length);

        for (LongHashMap.Entry longhashmap$entry = this.hashArray[j]; longhashmap$entry != null; longhashmap$entry = longhashmap$entry.nextEntry) {
            if (longhashmap$entry.key == par1) {
                longhashmap$entry.value = par3Obj;
                return;
            }
        }

        this.modCount++;
        this.createKey(i, par1, par3Obj, j);
    }

    private void resizeTable(int par1) {
        LongHashMap.Entry[] alonghashmap$entry = this.hashArray;
        int i = alonghashmap$entry.length;
        if (i == 1073741824) {
            this.capacity = Integer.MAX_VALUE;
        } else {
            LongHashMap.Entry[] alonghashmap$entry1 = new LongHashMap.Entry[par1];
            this.copyHashTableTo(alonghashmap$entry1);
            this.hashArray = alonghashmap$entry1;
            this.capacity = (int)(par1 * (12.0F / 16.0F));
        }
    }

    private void copyHashTableTo(LongHashMap.Entry[] par1ArrayOfLongHashMapEntry) {
        LongHashMap.Entry[] alonghashmap$entry = this.hashArray;
        int i = par1ArrayOfLongHashMapEntry.length;

        for (int j = 0; j < alonghashmap$entry.length; j++) {
            LongHashMap.Entry longhashmap$entry = alonghashmap$entry[j];
            if (longhashmap$entry != null) {
                alonghashmap$entry[j] = null;

                while (true) {
                    LongHashMap.Entry longhashmap$entry1 = longhashmap$entry.nextEntry;
                    int k = getHashIndex(longhashmap$entry.hash, i);
                    longhashmap$entry.nextEntry = par1ArrayOfLongHashMapEntry[k];
                    par1ArrayOfLongHashMapEntry[k] = longhashmap$entry;
                    longhashmap$entry = longhashmap$entry1;
                    if (longhashmap$entry1 == null) {
                        break;
                    }
                }
            }
        }
    }

    public Object remove(long par1) {
        LongHashMap.Entry longhashmap$entry = this.removeKey(par1);
        return longhashmap$entry == null ? null : longhashmap$entry.value;
    }

    final LongHashMap.Entry removeKey(long par1) {
        int i = getHashedKey(par1);
        int j = getHashIndex(i, this.hashArray.length);
        LongHashMap.Entry longhashmap$entry = this.hashArray[j];
        LongHashMap.Entry longhashmap$entry1 = longhashmap$entry;

        while (longhashmap$entry1 != null) {
            LongHashMap.Entry longhashmap$entry2 = longhashmap$entry1.nextEntry;
            if (longhashmap$entry1.key == par1) {
                this.modCount++;
                this.numHashElements--;
                if (longhashmap$entry == longhashmap$entry1) {
                    this.hashArray[j] = longhashmap$entry2;
                } else {
                    longhashmap$entry.nextEntry = longhashmap$entry2;
                }

                return longhashmap$entry1;
            }

            longhashmap$entry = longhashmap$entry1;
            longhashmap$entry1 = longhashmap$entry2;
        }

        return longhashmap$entry1;
    }

    private void createKey(int par1, long par2, Object par4Obj, int par5) {
        LongHashMap.Entry longhashmap$entry = this.hashArray[par5];
        this.hashArray[par5] = new LongHashMap.Entry(par1, par2, par4Obj, longhashmap$entry);
        if (this.numHashElements++ >= this.capacity) {
            this.resizeTable(2 * this.hashArray.length);
        }
    }

    public double getKeyDistribution() {
        int i = 0;

        for (int j = 0; j < this.hashArray.length; j++) {
            if (this.hashArray[j] != null) {
                i++;
            }
        }

        return 1.0 * i / this.numHashElements;
    }

    static class Entry {
        final long key;
        Object value;
        LongHashMap.Entry nextEntry;
        final int hash;
        private static final String __OBFID = "CL_00001493";

        Entry(int par1, long par2, Object par4Obj, LongHashMap.Entry par5LongHashMapEntry) {
            this.value = par4Obj;
            this.nextEntry = par5LongHashMapEntry;
            this.key = par2;
            this.hash = par1;
        }

        public final long getKey() {
            return this.key;
        }

        public final Object getValue() {
            return this.value;
        }

        @Override
        public final boolean equals(Object par1Obj) {
            if (!(par1Obj instanceof LongHashMap.Entry)) {
                return false;
            }

            LongHashMap.Entry longhashmap$entry = (LongHashMap.Entry)par1Obj;
            Long olong = this.getKey();
            Long olong1 = longhashmap$entry.getKey();
            if (olong == olong1 || olong != null && olong.equals(olong1)) {
                Object object = this.getValue();
                Object object1 = longhashmap$entry.getValue();
                if (object == object1 || object != null && object.equals(object1)) {
                    return true;
                }
            }

            return false;
        }

        @Override
        public final int hashCode() {
            return LongHashMap.getHashedKey(this.key);
        }

        @Override
        public final String toString() {
            return this.getKey() + "=" + this.getValue();
        }
    }
}
