package net.minecraft.pathfinding;

import net.minecraft.entity.Entity;
import net.minecraft.util.Vec3;

public class PathEntity {
    private final PathPoint[] points;
    private int currentPathIndex;
    private int pathLength;

    public PathEntity(PathPoint[] var1) {
        this.points = var1;
        this.pathLength = var1.length;
    }

    public void incrementPathIndex() {
        this.currentPathIndex++;
    }

    public boolean isFinished() {
        return this.currentPathIndex >= this.pathLength;
    }

    public PathPoint getFinalPathPoint() {
        return this.pathLength > 0 ? this.points[this.pathLength - 1] : null;
    }

    public PathPoint getPathPointFromIndex(int var1) {
        return this.points[var1];
    }

    public int getCurrentPathLength() {
        return this.pathLength;
    }

    public void setCurrentPathLength(int var1) {
        this.pathLength = var1;
    }

    public int getCurrentPathIndex() {
        return this.currentPathIndex;
    }

    public void setCurrentPathIndex(int var1) {
        this.currentPathIndex = var1;
    }

    public Vec3 getVectorFromIndex(Entity var1, int var2) {
        double d0 = this.points[var2].xCoord + (int)(var1.width + 1.0F) * 0.5;
        double d1 = this.points[var2].yCoord;
        double d2 = this.points[var2].zCoord + (int)(var1.width + 1.0F) * 0.5;
        return Vec3.createVectorHelper(d0, d1, d2);
    }

    public Vec3 getPosition(Entity var1) {
        return this.getVectorFromIndex(var1, this.currentPathIndex);
    }

    public boolean isSamePath(PathEntity var1) {
        if (var1 == null) {
            return false;
        }

        if (var1.points.length != this.points.length) {
            return false;
        }

        for (int i = 0; i < this.points.length; i++) {
            if (this.points[i].xCoord != var1.points[i].xCoord
                || this.points[i].yCoord != var1.points[i].yCoord
                || this.points[i].zCoord != var1.points[i].zCoord) {
                return false;
            }
        }

        return true;
    }

    public boolean isDestinationSame(Vec3 var1) {
        PathPoint pathpoint = this.getFinalPathPoint();
        return pathpoint == null ? false : pathpoint.xCoord == (int)var1.xCoord && pathpoint.zCoord == (int)var1.zCoord;
    }
}
