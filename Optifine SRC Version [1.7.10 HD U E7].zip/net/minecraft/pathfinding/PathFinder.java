package net.minecraft.pathfinding;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;

public class PathFinder {
    private IBlockAccess worldMap;
    private Path path = new Path();
    private IntHashMap pointMap = new IntHashMap();
    private PathPoint[] pathOptions = new PathPoint[32];
    private boolean canPassOpenWoodenDoors;
    private boolean canPassClosedWoodenDoor;
    private boolean avoidsWater;
    private boolean canEntitySwim;

    public PathFinder(IBlockAccess var1, boolean var2, boolean var3, boolean var4, boolean var5) {
        this.worldMap = var1;
        this.canPassOpenWoodenDoors = var2;
        this.canPassClosedWoodenDoor = var3;
        this.avoidsWater = var4;
        this.canEntitySwim = var5;
    }

    public PathEntity createEntityPathTo(Entity var1, Entity var2, float var3) {
        return this.createEntityPathTo(var1, var2.posX, var2.boundingBox.minY, var2.posZ, var3);
    }

    public PathEntity createEntityPathTo(Entity var1, int var2, int var3, int var4, float var5) {
        return this.createEntityPathTo(var1, var2 + 0.5F, var3 + 0.5F, var4 + 0.5F, var5);
    }

    private PathEntity createEntityPathTo(Entity var1, double var2, double var4, double var6, float var8) {
        this.path.clearPath();
        this.pointMap.clearMap();
        boolean flag = this.avoidsWater;
        int i = MathHelper.floor_double(var1.boundingBox.minY + 0.5);
        if (this.canEntitySwim && var1.isInWater()) {
            i = (int)var1.boundingBox.minY;
            Block block = this.worldMap.getBlock(MathHelper.floor_double(var1.posX), i, MathHelper.floor_double(var1.posZ));

            while (block == Blocks.flowing_water || block == Blocks.water) {
                block = this.worldMap.getBlock(MathHelper.floor_double(var1.posX), ++i, MathHelper.floor_double(var1.posZ));
            }

            flag = this.avoidsWater;
            this.avoidsWater = false;
        } else {
            i = MathHelper.floor_double(var1.boundingBox.minY + 0.5);
        }

        PathPoint pathpoint2 = this.openPoint(MathHelper.floor_double(var1.boundingBox.minX), i, MathHelper.floor_double(var1.boundingBox.minZ));
        PathPoint pathpoint = this.openPoint(
            MathHelper.floor_double(var2 - var1.width / 2.0F), MathHelper.floor_double(var4), MathHelper.floor_double(var6 - var1.width / 2.0F)
        );
        PathPoint pathpoint1 = new PathPoint(
            MathHelper.floor_float(var1.width + 1.0F), MathHelper.floor_float(var1.height + 1.0F), MathHelper.floor_float(var1.width + 1.0F)
        );
        PathEntity pathentity = this.addToPath(var1, pathpoint2, pathpoint, pathpoint1, var8);
        this.avoidsWater = flag;
        return pathentity;
    }

    private PathEntity addToPath(Entity var1, PathPoint var2, PathPoint var3, PathPoint var4, float var5) {
        var2.totalPathDistance = 0.0F;
        var2.distanceToNext = var2.distanceToSquared(var3);
        var2.distanceToTarget = var2.distanceToNext;
        this.path.clearPath();
        this.path.addPoint(var2);
        PathPoint pathpoint = var2;

        while (!this.path.isPathEmpty()) {
            PathPoint pathpoint1 = this.path.dequeue();
            if (pathpoint1.equals(var3)) {
                return this.createEntityPath(var2, var3);
            }

            if (pathpoint1.distanceToSquared(var3) < pathpoint.distanceToSquared(var3)) {
                pathpoint = pathpoint1;
            }

            pathpoint1.visited = true;
            int i = this.findPathOptions(var1, pathpoint1, var4, var3, var5);

            for (int j = 0; j < i; j++) {
                PathPoint pathpoint2 = this.pathOptions[j];
                float f = pathpoint1.totalPathDistance + pathpoint1.distanceToSquared(pathpoint2);
                if (!pathpoint2.isAssigned() || f < pathpoint2.totalPathDistance) {
                    pathpoint2.previous = pathpoint1;
                    pathpoint2.totalPathDistance = f;
                    pathpoint2.distanceToNext = pathpoint2.distanceToSquared(var3);
                    if (pathpoint2.isAssigned()) {
                        this.path.changeDistance(pathpoint2, pathpoint2.totalPathDistance + pathpoint2.distanceToNext);
                    } else {
                        pathpoint2.distanceToTarget = pathpoint2.totalPathDistance + pathpoint2.distanceToNext;
                        this.path.addPoint(pathpoint2);
                    }
                }
            }
        }

        return pathpoint == var2 ? null : this.createEntityPath(var2, pathpoint);
    }

    private int findPathOptions(Entity var1, PathPoint var2, PathPoint var3, PathPoint var4, float var5) {
        int i = 0;
        byte b0 = 0;
        if (this.canEntityStandAt(var1, var2.xCoord, var2.yCoord + 1, var2.zCoord, var3) == 1) {
            b0 = 1;
        }

        PathPoint pathpoint = this.getSafePoint(var1, var2.xCoord, var2.yCoord, var2.zCoord + 1, var3, b0);
        PathPoint pathpoint1 = this.getSafePoint(var1, var2.xCoord - 1, var2.yCoord, var2.zCoord, var3, b0);
        PathPoint pathpoint2 = this.getSafePoint(var1, var2.xCoord + 1, var2.yCoord, var2.zCoord, var3, b0);
        PathPoint pathpoint3 = this.getSafePoint(var1, var2.xCoord, var2.yCoord, var2.zCoord - 1, var3, b0);
        if (pathpoint != null && !pathpoint.visited && pathpoint.distanceTo(var4) < var5) {
            this.pathOptions[i++] = pathpoint;
        }

        if (pathpoint1 != null && !pathpoint1.visited && pathpoint1.distanceTo(var4) < var5) {
            this.pathOptions[i++] = pathpoint1;
        }

        if (pathpoint2 != null && !pathpoint2.visited && pathpoint2.distanceTo(var4) < var5) {
            this.pathOptions[i++] = pathpoint2;
        }

        if (pathpoint3 != null && !pathpoint3.visited && pathpoint3.distanceTo(var4) < var5) {
            this.pathOptions[i++] = pathpoint3;
        }

        return i;
    }

    private PathPoint getSafePoint(Entity var1, int var2, int var3, int var4, PathPoint var5, int var6) {
        PathPoint pathpoint = null;
        int i = this.canEntityStandAt(var1, var2, var3, var4, var5);
        if (i == 2) {
            return this.openPoint(var2, var3, var4);
        }

        if (i == 1) {
            pathpoint = this.openPoint(var2, var3, var4);
        }

        if (pathpoint == null && var6 > 0 && i != -3 && i != -4 && this.canEntityStandAt(var1, var2, var3 + var6, var4, var5) == 1) {
            pathpoint = this.openPoint(var2, var3 + var6, var4);
            var3 += var6;
        }

        if (pathpoint != null) {
            int j = 0;
            int k = 0;

            while (var3 > 0) {
                k = this.canEntityStandAt(var1, var2, var3 - 1, var4, var5);
                if (this.avoidsWater && k == -1) {
                    return null;
                }

                if (k != 1) {
                    break;
                }

                if (j++ >= var1.getMaxFallHeight()) {
                    return null;
                }

                if (--var3 > 0) {
                    pathpoint = this.openPoint(var2, var3, var4);
                }
            }

            if (k == -2) {
                return null;
            }
        }

        return pathpoint;
    }

    private final PathPoint openPoint(int var1, int var2, int var3) {
        int i = PathPoint.makeHash(var1, var2, var3);
        PathPoint pathpoint = (PathPoint)this.pointMap.lookup(i);
        if (pathpoint == null) {
            pathpoint = new PathPoint(var1, var2, var3);
            this.pointMap.addKey(i, pathpoint);
        }

        return pathpoint;
    }

    public int canEntityStandAt(Entity var1, int var2, int var3, int var4, PathPoint var5) {
        return canEntityStandAt(var1, var2, var3, var4, var5, this.avoidsWater, this.canPassClosedWoodenDoor, this.canPassOpenWoodenDoors);
    }

    public static int canEntityStandAt(Entity var0, int var1, int var2, int var3, PathPoint var4, boolean var5, boolean var6, boolean var7) {
        boolean flag = false;

        for (int i = var1; i < var1 + var4.xCoord; i++) {
            for (int j = var2; j < var2 + var4.yCoord; j++) {
                for (int k = var3; k < var3 + var4.zCoord; k++) {
                    Block block = var0.worldObj.getBlock(i, j, k);
                    if (block.getMaterial() != Material.air) {
                        if (block == Blocks.trapdoor) {
                            flag = true;
                        } else if (block != Blocks.flowing_water && block != Blocks.water) {
                            if (!var7 && block == Blocks.wooden_door) {
                                return 0;
                            }
                        } else {
                            if (var5) {
                                return -1;
                            }

                            flag = true;
                        }

                        int l = block.getRenderType();
                        if (var0.worldObj.getBlock(i, j, k).getRenderType() == 9) {
                            int i1 = MathHelper.floor_double(var0.posX);
                            int j1 = MathHelper.floor_double(var0.posY);
                            int k1 = MathHelper.floor_double(var0.posZ);
                            if (var0.worldObj.getBlock(i1, j1, k1).getRenderType() != 9 && var0.worldObj.getBlock(i1, j1 - 1, k1).getRenderType() != 9) {
                                return -3;
                            }
                        } else if (!block.isPassable(var0.worldObj, i, j, k) && (!var6 || block != Blocks.wooden_door)) {
                            if (l == 11 || block == Blocks.fence_gate || l == 32) {
                                return -3;
                            }

                            if (block == Blocks.trapdoor) {
                                return -4;
                            }

                            Material material = block.getMaterial();
                            if (material != Material.lava) {
                                return 0;
                            }

                            if (!var0.handleLavaMovement()) {
                                return -2;
                            }
                        }
                    }
                }
            }
        }

        return flag ? 2 : 1;
    }

    private PathEntity createEntityPath(PathPoint var1, PathPoint var2) {
        int i = 1;

        for (PathPoint pathpoint = var2; pathpoint.previous != null; pathpoint = pathpoint.previous) {
            i++;
        }

        PathPoint[] apathpoint = new PathPoint[i];
        PathPoint pathpoint1 = var2;

        for (apathpoint[--i] = pathpoint1; pathpoint1.previous != null; apathpoint[--i] = pathpoint1) {
            pathpoint1 = pathpoint1.previous;
        }

        return new PathEntity(apathpoint);
    }
}
