package net.minecraft.pathfinding;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class PathNavigate {
    private EntityLiving theEntity;
    private World worldObj;
    private PathEntity currentPath;
    private double speed;
    private IAttributeInstance pathSearchRange;
    private boolean avoidSun;
    private int totalTicks;
    private int ticksAtLastPos;
    private Vec3 lastPosCheck = Vec3.createVectorHelper(0.0, 0.0, 0.0);
    private boolean canPassOpenWoodenDoors = true;
    private boolean canPassClosedWoodenDoors;
    private boolean avoidsWater;
    private boolean canSwim;

    public PathNavigate(EntityLiving var1, World var2) {
        this.theEntity = var1;
        this.worldObj = var2;
        this.pathSearchRange = var1.getEntityAttribute(SharedMonsterAttributes.followRange);
    }

    public void setAvoidsWater(boolean var1) {
        this.avoidsWater = var1;
    }

    public boolean getAvoidsWater() {
        return this.avoidsWater;
    }

    public void setBreakDoors(boolean var1) {
        this.canPassClosedWoodenDoors = var1;
    }

    public void setEnterDoors(boolean var1) {
        this.canPassOpenWoodenDoors = var1;
    }

    public boolean getCanBreakDoors() {
        return this.canPassClosedWoodenDoors;
    }

    public void setAvoidSun(boolean var1) {
        this.avoidSun = var1;
    }

    public void setSpeed(double var1) {
        this.speed = var1;
    }

    public void setCanSwim(boolean var1) {
        this.canSwim = var1;
    }

    public float getPathSearchRange() {
        return (float)this.pathSearchRange.getAttributeValue();
    }

    public PathEntity getPathToXYZ(double var1, double var3, double var5) {
        return !this.canNavigate()
            ? null
            : this.worldObj
                .getEntityPathToXYZ(
                    this.theEntity,
                    MathHelper.floor_double(var1),
                    (int)var3,
                    MathHelper.floor_double(var5),
                    this.getPathSearchRange(),
                    this.canPassOpenWoodenDoors,
                    this.canPassClosedWoodenDoors,
                    this.avoidsWater,
                    this.canSwim
                );
    }

    public boolean tryMoveToXYZ(double var1, double var3, double var5, double var7) {
        PathEntity pathentity = this.getPathToXYZ(MathHelper.floor_double(var1), (int)var3, MathHelper.floor_double(var5));
        return this.setPath(pathentity, var7);
    }

    public PathEntity getPathToEntityLiving(Entity var1) {
        return !this.canNavigate()
            ? null
            : this.worldObj
                .getPathEntityToEntity(
                    this.theEntity, var1, this.getPathSearchRange(), this.canPassOpenWoodenDoors, this.canPassClosedWoodenDoors, this.avoidsWater, this.canSwim
                );
    }

    public boolean tryMoveToEntityLiving(Entity var1, double var2) {
        PathEntity pathentity = this.getPathToEntityLiving(var1);
        return pathentity != null ? this.setPath(pathentity, var2) : false;
    }

    public boolean setPath(PathEntity var1, double var2) {
        if (var1 == null) {
            this.currentPath = null;
            return false;
        }

        if (!var1.isSamePath(this.currentPath)) {
            this.currentPath = var1;
        }

        if (this.avoidSun) {
            this.removeSunnyPath();
        }

        if (this.currentPath.getCurrentPathLength() == 0) {
            return false;
        }

        this.speed = var2;
        Vec3 vec3 = this.getEntityPosition();
        this.ticksAtLastPos = this.totalTicks;
        this.lastPosCheck.xCoord = vec3.xCoord;
        this.lastPosCheck.yCoord = vec3.yCoord;
        this.lastPosCheck.zCoord = vec3.zCoord;
        return true;
    }

    public PathEntity getPath() {
        return this.currentPath;
    }

    public void onUpdateNavigation() {
        this.totalTicks++;
        if (!this.noPath()) {
            if (this.canNavigate()) {
                this.pathFollow();
            }

            if (!this.noPath()) {
                Vec3 vec3 = this.currentPath.getPosition(this.theEntity);
                if (vec3 != null) {
                    this.theEntity.getMoveHelper().setMoveTo(vec3.xCoord, vec3.yCoord, vec3.zCoord, this.speed);
                }
            }
        }
    }

    private void pathFollow() {
        Vec3 vec3 = this.getEntityPosition();
        int i = this.currentPath.getCurrentPathLength();

        for (int j = this.currentPath.getCurrentPathIndex(); j < this.currentPath.getCurrentPathLength(); j++) {
            if (this.currentPath.getPathPointFromIndex(j).yCoord != (int)vec3.yCoord) {
                i = j;
                break;
            }
        }

        float f = this.theEntity.width * this.theEntity.width;

        for (int k = this.currentPath.getCurrentPathIndex(); k < i; k++) {
            if (vec3.squareDistanceTo(this.currentPath.getVectorFromIndex(this.theEntity, k)) < f) {
                this.currentPath.setCurrentPathIndex(k + 1);
            }
        }

        int k1 = MathHelper.ceiling_float_int(this.theEntity.width);
        int l = (int)this.theEntity.height + 1;
        int i1 = k1;

        for (int j1 = i - 1; j1 >= this.currentPath.getCurrentPathIndex(); j1--) {
            if (this.isDirectPathBetweenPoints(vec3, this.currentPath.getVectorFromIndex(this.theEntity, j1), k1, l, i1)) {
                this.currentPath.setCurrentPathIndex(j1);
                break;
            }
        }

        if (this.totalTicks - this.ticksAtLastPos > 100) {
            if (vec3.squareDistanceTo(this.lastPosCheck) < 2.25) {
                this.clearPathEntity();
            }

            this.ticksAtLastPos = this.totalTicks;
            this.lastPosCheck.xCoord = vec3.xCoord;
            this.lastPosCheck.yCoord = vec3.yCoord;
            this.lastPosCheck.zCoord = vec3.zCoord;
        }
    }

    public boolean noPath() {
        return this.currentPath == null || this.currentPath.isFinished();
    }

    public void clearPathEntity() {
        this.currentPath = null;
    }

    private Vec3 getEntityPosition() {
        return Vec3.createVectorHelper(this.theEntity.posX, this.getPathableYPos(), this.theEntity.posZ);
    }

    private int getPathableYPos() {
        if (this.theEntity.isInWater() && this.canSwim) {
            int i = (int)this.theEntity.boundingBox.minY;
            Block block = this.worldObj.getBlock(MathHelper.floor_double(this.theEntity.posX), i, MathHelper.floor_double(this.theEntity.posZ));
            int j = 0;

            while (block == Blocks.flowing_water || block == Blocks.water) {
                block = this.worldObj.getBlock(MathHelper.floor_double(this.theEntity.posX), ++i, MathHelper.floor_double(this.theEntity.posZ));
                if (++j > 16) {
                    return (int)this.theEntity.boundingBox.minY;
                }
            }

            return i;
        } else {
            return (int)(this.theEntity.boundingBox.minY + 0.5);
        }
    }

    private boolean canNavigate() {
        return this.theEntity.onGround
            || this.canSwim && this.isInLiquid()
            || this.theEntity.isRiding() && this.theEntity instanceof EntityZombie && this.theEntity.ridingEntity instanceof EntityChicken;
    }

    private boolean isInLiquid() {
        return this.theEntity.isInWater() || this.theEntity.handleLavaMovement();
    }

    private void removeSunnyPath() {
        if (!this.worldObj
            .canBlockSeeTheSky(
                MathHelper.floor_double(this.theEntity.posX), (int)(this.theEntity.boundingBox.minY + 0.5), MathHelper.floor_double(this.theEntity.posZ)
            )) {
            for (int i = 0; i < this.currentPath.getCurrentPathLength(); i++) {
                PathPoint pathpoint = this.currentPath.getPathPointFromIndex(i);
                if (this.worldObj.canBlockSeeTheSky(pathpoint.xCoord, pathpoint.yCoord, pathpoint.zCoord)) {
                    this.currentPath.setCurrentPathLength(i - 1);
                    return;
                }
            }
        }
    }

    private boolean isDirectPathBetweenPoints(Vec3 var1, Vec3 var2, int var3, int var4, int var5) {
        int i = MathHelper.floor_double(var1.xCoord);
        int j = MathHelper.floor_double(var1.zCoord);
        double d0 = var2.xCoord - var1.xCoord;
        double d1 = var2.zCoord - var1.zCoord;
        double d2 = d0 * d0 + d1 * d1;
        if (d2 < 1.0E-8) {
            return false;
        }

        double d3 = 1.0 / Math.sqrt(d2);
        d0 *= d3;
        d1 *= d3;
        var3 += 2;
        var5 += 2;
        if (!this.isSafeToStandAt(i, (int)var1.yCoord, j, var3, var4, var5, var1, d0, d1)) {
            return false;
        }

        var3 -= 2;
        var5 -= 2;
        double d4 = 1.0 / Math.abs(d0);
        double d5 = 1.0 / Math.abs(d1);
        double d6 = i * 1 - var1.xCoord;
        double d7 = j * 1 - var1.zCoord;
        if (d0 >= 0.0) {
            d6++;
        }

        if (d1 >= 0.0) {
            d7++;
        }

        d6 /= d0;
        d7 /= d1;
        int k = d0 < 0.0 ? -1 : 1;
        int l = d1 < 0.0 ? -1 : 1;
        int i1 = MathHelper.floor_double(var2.xCoord);
        int j1 = MathHelper.floor_double(var2.zCoord);
        int k1 = i1 - i;
        int l1 = j1 - j;

        while (k1 * k > 0 || l1 * l > 0) {
            if (d6 < d7) {
                d6 += d4;
                i += k;
                k1 = i1 - i;
            } else {
                d7 += d5;
                j += l;
                l1 = j1 - j;
            }

            if (!this.isSafeToStandAt(i, (int)var1.yCoord, j, var3, var4, var5, var1, d0, d1)) {
                return false;
            }
        }

        return true;
    }

    private boolean isSafeToStandAt(int var1, int var2, int var3, int var4, int var5, int var6, Vec3 var7, double var8, double var10) {
        int i = var1 - var4 / 2;
        int j = var3 - var6 / 2;
        if (!this.isPositionClear(i, var2, j, var4, var5, var6, var7, var8, var10)) {
            return false;
        }

        for (int k = i; k < i + var4; k++) {
            for (int l = j; l < j + var6; l++) {
                double d0 = k + 0.5 - var7.xCoord;
                double d1 = l + 0.5 - var7.zCoord;
                if (!(d0 * var8 + d1 * var10 < 0.0)) {
                    Block block = this.worldObj.getBlock(k, var2 - 1, l);
                    Material material = block.getMaterial();
                    if (material == Material.air) {
                        return false;
                    }

                    if (material == Material.water && !this.theEntity.isInWater()) {
                        return false;
                    }

                    if (material == Material.lava) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private boolean isPositionClear(int var1, int var2, int var3, int var4, int var5, int var6, Vec3 var7, double var8, double var10) {
        for (int i = var1; i < var1 + var4; i++) {
            for (int j = var2; j < var2 + var5; j++) {
                for (int k = var3; k < var3 + var6; k++) {
                    double d0 = i + 0.5 - var7.xCoord;
                    double d1 = k + 0.5 - var7.zCoord;
                    if (!(d0 * var8 + d1 * var10 < 0.0)) {
                        Block block = this.worldObj.getBlock(i, j, k);
                        if (!block.isPassable(this.worldObj, i, j, k)) {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }
}
