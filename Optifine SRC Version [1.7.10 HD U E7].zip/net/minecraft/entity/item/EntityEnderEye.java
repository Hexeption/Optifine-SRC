package net.minecraft.entity.item;

import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityEnderEye extends Entity {
    private double targetX;
    private double targetY;
    private double targetZ;
    private int despawnTimer;
    private boolean shatterOrDrop;

    public EntityEnderEye(World var1) {
        super(var1);
        this.setSize(0.25F, 0.25F);
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public boolean isInRangeToRenderDist(double var1) {
        double d0 = this.boundingBox.getAverageEdgeLength() * 4.0;
        d0 *= 64.0;
        return var1 < d0 * d0;
    }

    public EntityEnderEye(World var1, double var2, double var4, double var6) {
        super(var1);
        this.despawnTimer = 0;
        this.setSize(0.25F, 0.25F);
        this.setPosition(var2, var4, var6);
        this.yOffset = 0.0F;
    }

    public void moveTowards(double var1, int var3, double var4) {
        double d0 = var1 - this.posX;
        double d1 = var4 - this.posZ;
        float f = MathHelper.sqrt_double(d0 * d0 + d1 * d1);
        if (f > 12.0F) {
            this.targetX = this.posX + d0 / f * 12.0;
            this.targetZ = this.posZ + d1 / f * 12.0;
            this.targetY = this.posY + 8.0;
        } else {
            this.targetX = var1;
            this.targetY = var3;
            this.targetZ = var4;
        }

        this.despawnTimer = 0;
        this.shatterOrDrop = this.rand.nextInt(5) > 0;
    }

    @Override
    public void setVelocity(double var1, double var3, double var5) {
        this.motionX = var1;
        this.motionY = var3;
        this.motionZ = var5;
        if (this.prevRotationPitch == 0.0F && this.prevRotationYaw == 0.0F) {
            float f = MathHelper.sqrt_double(var1 * var1 + var5 * var5);
            this.prevRotationYaw = this.rotationYaw = (float)(Math.atan2(var1, var5) * 180.0 / (float)Math.PI);
            this.prevRotationPitch = this.rotationPitch = (float)(Math.atan2(var3, f) * 180.0 / (float)Math.PI);
        }
    }

    @Override
    public void onUpdate() {
        this.lastTickPosX = this.posX;
        this.lastTickPosY = this.posY;
        this.lastTickPosZ = this.posZ;
        super.onUpdate();
        this.posX = this.posX + this.motionX;
        this.posY = this.posY + this.motionY;
        this.posZ = this.posZ + this.motionZ;
        float f = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        this.rotationYaw = (float)(Math.atan2(this.motionX, this.motionZ) * 180.0 / (float)Math.PI);
        this.rotationPitch = (float)(Math.atan2(this.motionY, f) * 180.0 / (float)Math.PI);

        while (this.rotationPitch - this.prevRotationPitch < -180.0F) {
            this.prevRotationPitch -= 360.0F;
        }

        while (this.rotationPitch - this.prevRotationPitch >= 180.0F) {
            this.prevRotationPitch += 360.0F;
        }

        while (this.rotationYaw - this.prevRotationYaw < -180.0F) {
            this.prevRotationYaw -= 360.0F;
        }

        while (this.rotationYaw - this.prevRotationYaw >= 180.0F) {
            this.prevRotationYaw += 360.0F;
        }

        this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
        this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
        if (!this.worldObj.isRemote) {
            double d0 = this.targetX - this.posX;
            double d1 = this.targetZ - this.posZ;
            float f1 = (float)Math.sqrt(d0 * d0 + d1 * d1);
            float f2 = (float)Math.atan2(d1, d0);
            double d2 = f + (f1 - f) * 0.0025;
            if (f1 < 1.0F) {
                d2 *= 0.8;
                this.motionY *= 0.8;
            }

            this.motionX = Math.cos(f2) * d2;
            this.motionZ = Math.sin(f2) * d2;
            if (this.posY < this.targetY) {
                this.motionY = this.motionY + (1.0 - this.motionY) * 0.015F;
            } else {
                this.motionY = this.motionY + (-1.0 - this.motionY) * 0.015F;
            }
        }

        float f3 = 0.25F;
        if (this.isInWater()) {
            for (int i = 0; i < 4; i++) {
                this.worldObj
                    .spawnParticle(
                        "bubble",
                        this.posX - this.motionX * f3,
                        this.posY - this.motionY * f3,
                        this.posZ - this.motionZ * f3,
                        this.motionX,
                        this.motionY,
                        this.motionZ
                    );
            }
        } else {
            this.worldObj
                .spawnParticle(
                    "portal",
                    this.posX - this.motionX * f3 + this.rand.nextDouble() * 0.6 - 0.3,
                    this.posY - this.motionY * f3 - 0.5,
                    this.posZ - this.motionZ * f3 + this.rand.nextDouble() * 0.6 - 0.3,
                    this.motionX,
                    this.motionY,
                    this.motionZ
                );
        }

        if (!this.worldObj.isRemote) {
            this.setPosition(this.posX, this.posY, this.posZ);
            this.despawnTimer++;
            if (this.despawnTimer > 80 && !this.worldObj.isRemote) {
                this.setDead();
                if (this.shatterOrDrop) {
                    this.worldObj.spawnEntityInWorld(new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(Items.ender_eye)));
                } else {
                    this.worldObj.playAuxSFX(2003, (int)Math.round(this.posX), (int)Math.round(this.posY), (int)Math.round(this.posZ), 0);
                }
            }
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
    }

    @Override
    public float getShadowSize() {
        return 0.0F;
    }

    @Override
    public float getBrightness(float var1) {
        return 1.0F;
    }

    @Override
    public int getBrightnessForRender(float var1) {
        return 15728880;
    }

    @Override
    public boolean canAttackWithItem() {
        return false;
    }
}
