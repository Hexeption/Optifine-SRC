package net.minecraft.entity.item;

import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityXPOrb extends Entity {
    public int xpColor;
    public int xpOrbAge;
    public int field_70532_c;
    private int xpOrbHealth = 5;
    private int xpValue;
    private EntityPlayer closestPlayer;
    private int xpTargetColor;

    public EntityXPOrb(World var1, double var2, double var4, double var6, int var8) {
        super(var1);
        this.setSize(0.5F, 0.5F);
        this.yOffset = this.height / 2.0F;
        this.setPosition(var2, var4, var6);
        this.rotationYaw = (float)(Math.random() * 360.0);
        this.motionX = (float)(Math.random() * 0.2F - 0.1F) * 2.0F;
        this.motionY = (float)(Math.random() * 0.2) * 2.0F;
        this.motionZ = (float)(Math.random() * 0.2F - 0.1F) * 2.0F;
        this.xpValue = var8;
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    public EntityXPOrb(World var1) {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.yOffset = this.height / 2.0F;
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public int getBrightnessForRender(float var1) {
        float f = 0.5F;
        if (f < 0.0F) {
            f = 0.0F;
        }

        if (f > 1.0F) {
            f = 1.0F;
        }

        int i = super.getBrightnessForRender(var1);
        int j = i & 0xFF;
        int k = i >> 16 & 0xFF;
        j += (int)(f * 15.0F * 16.0F);
        if (j > 240) {
            j = 240;
        }

        return j | k << 16;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.field_70532_c > 0) {
            this.field_70532_c--;
        }

        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY -= 0.03F;
        if (this.worldObj.getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)).getMaterial()
            == Material.lava) {
            this.motionY = 0.2F;
            this.motionX = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F;
            this.motionZ = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F;
            this.playSound("random.fizz", 0.4F, 2.0F + this.rand.nextFloat() * 0.4F);
        }

        this.pushOutOfBlocks(this.posX, (this.boundingBox.minY + this.boundingBox.maxY) / 2.0, this.posZ);
        double d0 = 8.0;
        if (this.xpTargetColor < this.xpColor - 20 + this.getEntityId() % 100) {
            if (this.closestPlayer == null || this.closestPlayer.getDistanceSqToEntity(this) > d0 * d0) {
                this.closestPlayer = this.worldObj.getClosestPlayerToEntity(this, d0);
            }

            this.xpTargetColor = this.xpColor;
        }

        if (this.closestPlayer != null) {
            double d1 = (this.closestPlayer.posX - this.posX) / d0;
            double d2 = (this.closestPlayer.posY + this.closestPlayer.getEyeHeight() - this.posY) / d0;
            double d3 = (this.closestPlayer.posZ - this.posZ) / d0;
            double d4 = Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3);
            double d5 = 1.0 - d4;
            if (d5 > 0.0) {
                d5 *= d5;
                this.motionX += d1 / d4 * d5 * 0.1;
                this.motionY += d2 / d4 * d5 * 0.1;
                this.motionZ += d3 / d4 * d5 * 0.1;
            }
        }

        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        float f = 0.98F;
        if (this.onGround) {
            f = this.worldObj
                    .getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ))
                    .slipperiness
                * 0.98F;
        }

        this.motionX *= f;
        this.motionY *= 0.98F;
        this.motionZ *= f;
        if (this.onGround) {
            this.motionY *= -0.9F;
        }

        this.xpColor++;
        this.xpOrbAge++;
        if (this.xpOrbAge >= 6000) {
            this.setDead();
        }
    }

    @Override
    public boolean handleWaterMovement() {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox, Material.water, this);
    }

    @Override
    protected void dealFireDamage(int var1) {
        this.attackEntityFrom(DamageSource.inFire, var1);
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        this.setBeenAttacked();
        this.xpOrbHealth = (int)(this.xpOrbHealth - var2);
        if (this.xpOrbHealth <= 0) {
            this.setDead();
        }

        return false;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setShort("Health", (byte)this.xpOrbHealth);
        var1.setShort("Age", (short)this.xpOrbAge);
        var1.setShort("Value", (short)this.xpValue);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        this.xpOrbHealth = var1.getShort("Health") & 255;
        this.xpOrbAge = var1.getShort("Age");
        this.xpValue = var1.getShort("Value");
    }

    @Override
    public void onCollideWithPlayer(EntityPlayer var1) {
        if (!this.worldObj.isRemote) {
            if (this.field_70532_c == 0 && var1.xpCooldown == 0) {
                var1.xpCooldown = 2;
                this.worldObj.playSoundAtEntity(var1, "random.orb", 0.1F, 0.5F * ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.8F));
                var1.onItemPickup(this, 1);
                var1.addExperience(this.xpValue);
                this.setDead();
            }
        }
    }

    public int getXpValue() {
        return this.xpValue;
    }

    public int getTextureByXP() {
        if (this.xpValue >= 2477) {
            return 10;
        } else if (this.xpValue >= 1237) {
            return 9;
        } else if (this.xpValue >= 617) {
            return 8;
        } else if (this.xpValue >= 307) {
            return 7;
        } else if (this.xpValue >= 149) {
            return 6;
        } else if (this.xpValue >= 73) {
            return 5;
        } else if (this.xpValue >= 37) {
            return 4;
        } else if (this.xpValue >= 17) {
            return 3;
        } else if (this.xpValue >= 7) {
            return 2;
        } else {
            return this.xpValue >= 3 ? 1 : 0;
        }
    }

    public static int getXPSplit(int var0) {
        if (var0 >= 2477) {
            return 2477;
        } else if (var0 >= 1237) {
            return 1237;
        } else if (var0 >= 617) {
            return 617;
        } else if (var0 >= 307) {
            return 307;
        } else if (var0 >= 149) {
            return 149;
        } else if (var0 >= 73) {
            return 73;
        } else if (var0 >= 37) {
            return 37;
        } else if (var0 >= 17) {
            return 17;
        } else if (var0 >= 7) {
            return 7;
        } else {
            return var0 >= 3 ? 3 : 1;
        }
    }

    @Override
    public boolean canAttackWithItem() {
        return false;
    }
}
