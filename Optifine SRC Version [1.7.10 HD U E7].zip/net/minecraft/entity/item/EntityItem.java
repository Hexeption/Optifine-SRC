package net.minecraft.entity.item;

import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.AchievementList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityItem extends Entity {
    private static final Logger logger = LogManager.getLogger();
    public int age;
    public int delayBeforeCanPickup;
    private int health = 5;
    private String field_145801_f;
    private String field_145802_g;
    public float hoverStart = (float)(Math.random() * Math.PI * 2.0);

    public EntityItem(World var1, double var2, double var4, double var6) {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.yOffset = this.height / 2.0F;
        this.setPosition(var2, var4, var6);
        this.rotationYaw = (float)(Math.random() * 360.0);
        this.motionX = (float)(Math.random() * 0.2F - 0.1F);
        this.motionY = 0.2F;
        this.motionZ = (float)(Math.random() * 0.2F - 0.1F);
    }

    public EntityItem(World var1, double var2, double var4, double var6, ItemStack var8) {
        this(var1, var2, var4, var6);
        this.setEntityItemStack(var8);
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    public EntityItem(World var1) {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.yOffset = this.height / 2.0F;
    }

    @Override
    protected void entityInit() {
        this.getDataWatcher().addObjectByDataType(10, 5);
    }

    @Override
    public void onUpdate() {
        if (this.getEntityItem() == null) {
            this.setDead();
        } else {
            super.onUpdate();
            if (this.delayBeforeCanPickup > 0) {
                this.delayBeforeCanPickup--;
            }

            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
            this.motionY -= 0.04F;
            this.noClip = this.pushOutOfBlocks(this.posX, (this.boundingBox.minY + this.boundingBox.maxY) / 2.0, this.posZ);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            boolean flag = (int)this.prevPosX != (int)this.posX || (int)this.prevPosY != (int)this.posY || (int)this.prevPosZ != (int)this.posZ;
            if (flag || this.ticksExisted % 25 == 0) {
                if (this.worldObj
                        .getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))
                        .getMaterial()
                    == Material.lava) {
                    this.motionY = 0.2F;
                    this.motionX = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F;
                    this.motionZ = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F;
                    this.playSound("random.fizz", 0.4F, 2.0F + this.rand.nextFloat() * 0.4F);
                }

                if (!this.worldObj.isRemote) {
                    this.searchForOtherItemsNearby();
                }
            }

            float f = 0.98F;
            if (this.onGround) {
                f = this.worldObj
                        .getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ))
                        .slipperiness
                    * 0.98F;
            }

            this.motionX *= f;
            this.motionY *= 0.98F;
            this.motionZ *= f;
            if (this.onGround) {
                this.motionY *= -0.5;
            }

            this.age++;
            if (!this.worldObj.isRemote && this.age >= 6000) {
                this.setDead();
            }
        }
    }

    private void searchForOtherItemsNearby() {
        for (EntityItem entityitem : this.worldObj.getEntitiesWithinAABB(EntityItem.class, this.boundingBox.expand(0.5, 0.0, 0.5))) {
            this.combineItems(entityitem);
        }
    }

    public boolean combineItems(EntityItem var1) {
        if (var1 == this) {
            return false;
        }

        if (var1.isEntityAlive() && this.isEntityAlive()) {
            ItemStack itemstack = this.getEntityItem();
            ItemStack itemstack1 = var1.getEntityItem();
            if (itemstack1.getItem() != itemstack.getItem()) {
                return false;
            }

            if (itemstack1.hasTagCompound() ^ itemstack.hasTagCompound()) {
                return false;
            }

            if (itemstack1.hasTagCompound() && !itemstack1.getTagCompound().equals(itemstack.getTagCompound())) {
                return false;
            }

            if (itemstack1.getItem() == null) {
                return false;
            }

            if (itemstack1.getItem().getHasSubtypes() && itemstack1.getMetadata() != itemstack.getMetadata()) {
                return false;
            }

            if (itemstack1.stackSize < itemstack.stackSize) {
                return var1.combineItems(this);
            }

            if (itemstack1.stackSize + itemstack.stackSize > itemstack1.getMaxStackSize()) {
                return false;
            }

            itemstack1.stackSize = itemstack1.stackSize + itemstack.stackSize;
            var1.delayBeforeCanPickup = Math.max(var1.delayBeforeCanPickup, this.delayBeforeCanPickup);
            var1.age = Math.min(var1.age, this.age);
            var1.setEntityItemStack(itemstack1);
            this.setDead();
            return true;
        } else {
            return false;
        }
    }

    public void setAgeToCreativeDespawnTime() {
        this.age = 4800;
    }

    @Override
    public boolean handleWaterMovement() {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox, Material.water, this);
    }

    @Override
    protected void dealFireDamage(int var1) {
        this.attackEntityFrom(DamageSource.inFire, var1);
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        if (this.getEntityItem() != null && this.getEntityItem().getItem() == Items.nether_star && var1.isExplosion()) {
            return false;
        }

        this.setBeenAttacked();
        this.health = (int)(this.health - var2);
        if (this.health <= 0) {
            this.setDead();
        }

        return false;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setShort("Health", (byte)this.health);
        var1.setShort("Age", (short)this.age);
        if (this.getThrower() != null) {
            var1.setString("Thrower", this.field_145801_f);
        }

        if (this.getOwner() != null) {
            var1.setString("Owner", this.field_145802_g);
        }

        if (this.getEntityItem() != null) {
            var1.setTag("Item", this.getEntityItem().writeToNBT(new NBTTagCompound()));
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        this.health = var1.getShort("Health") & 255;
        this.age = var1.getShort("Age");
        if (var1.hasKey("Owner")) {
            this.field_145802_g = var1.getString("Owner");
        }

        if (var1.hasKey("Thrower")) {
            this.field_145801_f = var1.getString("Thrower");
        }

        NBTTagCompound nbttagcompound = var1.getCompoundTag("Item");
        this.setEntityItemStack(ItemStack.loadItemStackFromNBT(nbttagcompound));
        if (this.getEntityItem() == null) {
            this.setDead();
        }
    }

    @Override
    public void onCollideWithPlayer(EntityPlayer var1) {
        if (!this.worldObj.isRemote) {
            ItemStack itemstack = this.getEntityItem();
            int i = itemstack.stackSize;
            if (this.delayBeforeCanPickup == 0
                && (this.field_145802_g == null || 6000 - this.age <= 200 || this.field_145802_g.equals(var1.getCommandSenderName()))
                && var1.inventory.addItemStackToInventory(itemstack)) {
                if (itemstack.getItem() == Item.getItemFromBlock(Blocks.log)) {
                    var1.triggerAchievement(AchievementList.mineWood);
                }

                if (itemstack.getItem() == Item.getItemFromBlock(Blocks.log2)) {
                    var1.triggerAchievement(AchievementList.mineWood);
                }

                if (itemstack.getItem() == Items.leather) {
                    var1.triggerAchievement(AchievementList.killCow);
                }

                if (itemstack.getItem() == Items.diamond) {
                    var1.triggerAchievement(AchievementList.diamonds);
                }

                if (itemstack.getItem() == Items.blaze_rod) {
                    var1.triggerAchievement(AchievementList.blazeRod);
                }

                if (itemstack.getItem() == Items.diamond && this.getThrower() != null) {
                    EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(this.getThrower());
                    if (entityplayer != null && entityplayer != var1) {
                        entityplayer.triggerAchievement(AchievementList.field_150966_x);
                    }
                }

                this.worldObj.playSoundAtEntity(var1, "random.pop", 0.2F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
                var1.onItemPickup(this, i);
                if (itemstack.stackSize <= 0) {
                    this.setDead();
                }
            }
        }
    }

    @Override
    public String getCommandSenderName() {
        return StatCollector.translateToLocal("item." + this.getEntityItem().getUnlocalizedName());
    }

    @Override
    public boolean canAttackWithItem() {
        return false;
    }

    @Override
    public void travelToDimension(int var1) {
        super.travelToDimension(var1);
        if (!this.worldObj.isRemote) {
            this.searchForOtherItemsNearby();
        }
    }

    public ItemStack getEntityItem() {
        ItemStack itemstack = this.getDataWatcher().getWatchableObjectItemStack(10);
        return itemstack == null ? new ItemStack(Blocks.stone) : itemstack;
    }

    public void setEntityItemStack(ItemStack var1) {
        this.getDataWatcher().updateObject(10, var1);
        this.getDataWatcher().setObjectWatched(10);
    }

    public String getOwner() {
        return this.field_145802_g;
    }

    public void setOwner(String var1) {
        this.field_145802_g = var1;
    }

    public String getThrower() {
        return this.field_145801_f;
    }

    public void setThrower(String var1) {
        this.field_145801_f = var1;
    }
}
