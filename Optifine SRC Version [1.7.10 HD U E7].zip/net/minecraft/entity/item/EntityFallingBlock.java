package net.minecraft.entity.item;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityFallingBlock extends Entity {
    private Block blockObj;
    public int metadata;
    public int fallTime;
    public boolean shouldDropItem = true;
    private boolean field_145808_f;
    private boolean hurtEntities;
    private int fallHurtMax = 40;
    private float fallHurtAmount = 2.0F;
    public NBTTagCompound tileEntityData;

    public EntityFallingBlock(World var1) {
        super(var1);
    }

    public EntityFallingBlock(World var1, double var2, double var4, double var6, Block var8) {
        this(var1, var2, var4, var6, var8, 0);
    }

    public EntityFallingBlock(World var1, double var2, double var4, double var6, Block var8, int var9) {
        super(var1);
        this.blockObj = var8;
        this.metadata = var9;
        this.preventEntitySpawning = true;
        this.setSize(0.98F, 0.98F);
        this.yOffset = this.height / 2.0F;
        this.setPosition(var2, var4, var6);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.prevPosX = var2;
        this.prevPosY = var4;
        this.prevPosZ = var6;
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public void onUpdate() {
        if (this.blockObj.getMaterial() == Material.air) {
            this.setDead();
        } else {
            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
            this.fallTime++;
            this.motionY -= 0.04F;
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.98F;
            this.motionY *= 0.98F;
            this.motionZ *= 0.98F;
            if (!this.worldObj.isRemote) {
                int i = MathHelper.floor_double(this.posX);
                int j = MathHelper.floor_double(this.posY);
                int k = MathHelper.floor_double(this.posZ);
                if (this.fallTime == 1) {
                    if (this.worldObj.getBlock(i, j, k) != this.blockObj) {
                        this.setDead();
                        return;
                    }

                    this.worldObj.setBlockToAir(i, j, k);
                }

                if (this.onGround) {
                    this.motionX *= 0.7F;
                    this.motionZ *= 0.7F;
                    this.motionY *= -0.5;
                    if (this.worldObj.getBlock(i, j, k) != Blocks.piston_extension) {
                        this.setDead();
                        if (!this.field_145808_f
                            && this.worldObj.canPlaceEntityOnSide(this.blockObj, i, j, k, true, 1, null, null)
                            && !BlockFalling.canFallBelow(this.worldObj, i, j - 1, k)
                            && this.worldObj.setBlock(i, j, k, this.blockObj, this.metadata, 3)) {
                            if (this.blockObj instanceof BlockFalling) {
                                ((BlockFalling)this.blockObj).playSoundWhenFallen(this.worldObj, i, j, k, this.metadata);
                            }

                            if (this.tileEntityData != null && this.blockObj instanceof ITileEntityProvider) {
                                TileEntity tileentity = this.worldObj.getTileEntity(i, j, k);
                                if (tileentity != null) {
                                    NBTTagCompound nbttagcompound = new NBTTagCompound();
                                    tileentity.writeToNBT(nbttagcompound);

                                    for (String s : (Iterable<String>) (Iterable) this.tileEntityData.getKeySet()) {
                                        NBTBase nbtbase = this.tileEntityData.getTag(s);
                                        if (!s.equals("x") && !s.equals("y") && !s.equals("z")) {
                                            nbttagcompound.setTag(s, nbtbase.copy());
                                        }
                                    }

                                    tileentity.readFromNBT(nbttagcompound);
                                    tileentity.markDirty();
                                }
                            }
                        } else if (this.shouldDropItem && !this.field_145808_f) {
                            this.entityDropItem(new ItemStack(this.blockObj, 1, this.blockObj.damageDropped(this.metadata)), 0.0F);
                        }
                    }
                } else if (this.fallTime > 100 && !this.worldObj.isRemote && (j < 1 || j > 256) || this.fallTime > 600) {
                    if (this.shouldDropItem) {
                        this.entityDropItem(new ItemStack(this.blockObj, 1, this.blockObj.damageDropped(this.metadata)), 0.0F);
                    }

                    this.setDead();
                }
            }
        }
    }

    @Override
    protected void fall(float var1) {
        if (this.hurtEntities) {
            int i = MathHelper.ceiling_float_int(var1 - 1.0F);
            if (i > 0) {
                ArrayList arraylist = new ArrayList(this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox));
                boolean flag = this.blockObj == Blocks.anvil;
                DamageSource damagesource = flag ? DamageSource.anvil : DamageSource.fallingBlock;

                for (Entity entity : (Iterable<Entity>) (Iterable) arraylist) {
                    entity.attackEntityFrom(damagesource, Math.min(MathHelper.floor_float(i * this.fallHurtAmount), this.fallHurtMax));
                }

                if (flag && this.rand.nextFloat() < 0.05F + i * 0.05) {
                    int j = this.metadata >> 2;
                    int k = this.metadata & 3;
                    if (++j > 2) {
                        this.field_145808_f = true;
                    } else {
                        this.metadata = k | j << 2;
                    }
                }
            }
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        var1.setByte("Tile", (byte)Block.getIdFromBlock(this.blockObj));
        var1.setInteger("TileID", Block.getIdFromBlock(this.blockObj));
        var1.setByte("Data", (byte)this.metadata);
        var1.setByte("Time", (byte)this.fallTime);
        var1.setBoolean("DropItem", this.shouldDropItem);
        var1.setBoolean("HurtEntities", this.hurtEntities);
        var1.setFloat("FallHurtAmount", this.fallHurtAmount);
        var1.setInteger("FallHurtMax", this.fallHurtMax);
        if (this.tileEntityData != null) {
            var1.setTag("TileEntityData", this.tileEntityData);
        }
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        if (var1.hasKey("TileID", 99)) {
            this.blockObj = Block.getBlockById(var1.getInteger("TileID"));
        } else {
            this.blockObj = Block.getBlockById(var1.getByte("Tile") & 255);
        }

        this.metadata = var1.getByte("Data") & 255;
        this.fallTime = var1.getByte("Time") & 255;
        if (var1.hasKey("HurtEntities", 99)) {
            this.hurtEntities = var1.getBoolean("HurtEntities");
            this.fallHurtAmount = var1.getFloat("FallHurtAmount");
            this.fallHurtMax = var1.getInteger("FallHurtMax");
        } else if (this.blockObj == Blocks.anvil) {
            this.hurtEntities = true;
        }

        if (var1.hasKey("DropItem", 99)) {
            this.shouldDropItem = var1.getBoolean("DropItem");
        }

        if (var1.hasKey("TileEntityData", 10)) {
            this.tileEntityData = var1.getCompoundTag("TileEntityData");
        }

        if (this.blockObj.getMaterial() == Material.air) {
            this.blockObj = Blocks.sand;
        }
    }

    @Override
    public float getShadowSize() {
        return 0.0F;
    }

    public World getWorldObj() {
        return this.worldObj;
    }

    public void setHurtEntities(boolean var1) {
        this.hurtEntities = var1;
    }

    @Override
    public boolean canRenderOnFire() {
        return false;
    }

    @Override
    public void addEntityCrashInfo(CrashReportCategory var1) {
        super.addEntityCrashInfo(var1);
        var1.addCrashSection("Immitating block ID", Block.getIdFromBlock(this.blockObj));
        var1.addCrashSection("Immitating block data", this.metadata);
    }

    public Block getBlock() {
        return this.blockObj;
    }
}
