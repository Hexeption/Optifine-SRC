package net.minecraft.entity.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityHanging;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapData;

public class EntityItemFrame extends EntityHanging {
    private float itemDropChance = 1.0F;

    public EntityItemFrame(World var1) {
        super(var1);
    }

    public EntityItemFrame(World var1, int var2, int var3, int var4, int var5) {
        super(var1, var2, var3, var4, var5);
        this.setDirection(var5);
    }

    @Override
    protected void entityInit() {
        this.getDataWatcher().addObjectByDataType(2, 5);
        this.getDataWatcher().addObject(3, (byte)0);
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        if (this.getDisplayedItem() != null) {
            if (!this.worldObj.isRemote) {
                this.func_146065_b(var1.getEntity(), false);
                this.setDisplayedItem(null);
            }

            return true;
        } else {
            return super.attackEntityFrom(var1, var2);
        }
    }

    @Override
    public int getWidthPixels() {
        return 9;
    }

    @Override
    public int getHeightPixels() {
        return 9;
    }

    @Override
    public boolean isInRangeToRenderDist(double var1) {
        double d0 = 16.0;
        d0 *= 64.0 * this.renderDistanceWeight;
        return var1 < d0 * d0;
    }

    @Override
    public void onBroken(Entity var1) {
        this.func_146065_b(var1, true);
    }

    public void func_146065_b(Entity var1, boolean var2) {
        ItemStack itemstack = this.getDisplayedItem();
        if (var1 instanceof EntityPlayer) {
            EntityPlayer entityplayer = (EntityPlayer)var1;
            if (entityplayer.capabilities.isCreativeMode) {
                this.removeFrameFromMap(itemstack);
                return;
            }
        }

        if (var2) {
            this.entityDropItem(new ItemStack(Items.item_frame), 0.0F);
        }

        if (itemstack != null && this.rand.nextFloat() < this.itemDropChance) {
            itemstack = itemstack.copy();
            this.removeFrameFromMap(itemstack);
            this.entityDropItem(itemstack, 0.0F);
        }
    }

    private void removeFrameFromMap(ItemStack var1) {
        if (var1 != null) {
            if (var1.getItem() == Items.filled_map) {
                MapData mapdata = ((ItemMap)var1.getItem()).getMapData(var1, this.worldObj);
                mapdata.playersVisibleOnMap.remove("frame-" + this.getEntityId());
            }

            var1.setItemFrame(null);
        }
    }

    public ItemStack getDisplayedItem() {
        return this.getDataWatcher().getWatchableObjectItemStack(2);
    }

    public void setDisplayedItem(ItemStack var1) {
        if (var1 != null) {
            var1 = var1.copy();
            var1.stackSize = 1;
            var1.setItemFrame(this);
        }

        this.getDataWatcher().updateObject(2, var1);
        this.getDataWatcher().setObjectWatched(2);
    }

    public int getRotation() {
        return this.getDataWatcher().getWatchableObjectByte(3);
    }

    public void setItemRotation(int var1) {
        this.getDataWatcher().updateObject(3, (byte)(var1 % 4));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        if (this.getDisplayedItem() != null) {
            var1.setTag("Item", this.getDisplayedItem().writeToNBT(new NBTTagCompound()));
            var1.setByte("ItemRotation", (byte)this.getRotation());
            var1.setFloat("ItemDropChance", this.itemDropChance);
        }

        super.writeEntityToNBT(var1);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        NBTTagCompound nbttagcompound = var1.getCompoundTag("Item");
        if (nbttagcompound != null && !nbttagcompound.hasNoTags()) {
            this.setDisplayedItem(ItemStack.loadItemStackFromNBT(nbttagcompound));
            this.setItemRotation(var1.getByte("ItemRotation"));
            if (var1.hasKey("ItemDropChance", 99)) {
                this.itemDropChance = var1.getFloat("ItemDropChance");
            }
        }

        super.readEntityFromNBT(var1);
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        if (this.getDisplayedItem() == null) {
            ItemStack itemstack = var1.getHeldItem();
            if (itemstack != null && !this.worldObj.isRemote) {
                this.setDisplayedItem(itemstack);
                if (!var1.capabilities.isCreativeMode && --itemstack.stackSize <= 0) {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
                }
            }
        } else if (!this.worldObj.isRemote) {
            this.setItemRotation(this.getRotation() + 1);
        }

        return true;
    }
}
