package net.minecraft.entity.item;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityBoat extends Entity {
    private boolean isBoatEmpty = true;
    private double speedMultiplier = 0.07;
    private int boatPosRotationIncrements;
    private double boatX;
    private double boatY;
    private double boatZ;
    private double boatYaw;
    private double boatPitch;
    private double velocityX;
    private double velocityY;
    private double velocityZ;

    public EntityBoat(World var1) {
        super(var1);
        this.preventEntitySpawning = true;
        this.setSize(1.5F, 0.6F);
        this.yOffset = this.height / 2.0F;
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    @Override
    protected void entityInit() {
        this.dataWatcher.addObject(17, new Integer(0));
        this.dataWatcher.addObject(18, new Integer(1));
        this.dataWatcher.addObject(19, new Float(0.0F));
    }

    @Override
    public AxisAlignedBB getCollisionBox(Entity var1) {
        return var1.boundingBox;
    }

    @Override
    public AxisAlignedBB getBoundingBox() {
        return this.boundingBox;
    }

    @Override
    public boolean canBePushed() {
        return true;
    }

    public EntityBoat(World var1, double var2, double var4, double var6) {
        this(var1);
        this.setPosition(var2, var4 + this.yOffset, var6);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.prevPosX = var2;
        this.prevPosY = var4;
        this.prevPosZ = var6;
    }

    @Override
    public double getMountedYOffset() {
        return this.height * 0.0 - 0.3F;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        if (!this.worldObj.isRemote && !this.isDead) {
            this.setForwardDirection(-this.getForwardDirection());
            this.setTimeSinceHit(10);
            this.setDamageTaken(this.getDamageTaken() + var2 * 10.0F);
            this.setBeenAttacked();
            boolean flag = var1.getEntity() instanceof EntityPlayer && ((EntityPlayer)var1.getEntity()).capabilities.isCreativeMode;
            if (flag || this.getDamageTaken() > 40.0F) {
                if (this.riddenByEntity != null) {
                    this.riddenByEntity.mountEntity(this);
                }

                if (!flag) {
                    this.dropItemWithOffset(Items.boat, 1, 0.0F);
                }

                this.setDead();
            }

            return true;
        } else {
            return true;
        }
    }

    @Override
    public void performHurtAnimation() {
        this.setForwardDirection(-this.getForwardDirection());
        this.setTimeSinceHit(10);
        this.setDamageTaken(this.getDamageTaken() * 11.0F);
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9) {
        if (this.isBoatEmpty) {
            this.boatPosRotationIncrements = var9 + 5;
        } else {
            double d0 = var1 - this.posX;
            double d1 = var3 - this.posY;
            double d2 = var5 - this.posZ;
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            if (!(d3 > 1.0)) {
                return;
            }

            this.boatPosRotationIncrements = 3;
        }

        this.boatX = var1;
        this.boatY = var3;
        this.boatZ = var5;
        this.boatYaw = var7;
        this.boatPitch = var8;
        this.motionX = this.velocityX;
        this.motionY = this.velocityY;
        this.motionZ = this.velocityZ;
    }

    @Override
    public void setVelocity(double var1, double var3, double var5) {
        this.velocityX = this.motionX = var1;
        this.velocityY = this.motionY = var3;
        this.velocityZ = this.motionZ = var5;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.getTimeSinceHit() > 0) {
            this.setTimeSinceHit(this.getTimeSinceHit() - 1);
        }

        if (this.getDamageTaken() > 0.0F) {
            this.setDamageTaken(this.getDamageTaken() - 1.0F);
        }

        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        byte b0 = 5;
        double d0 = 0.0;

        for (int i = 0; i < b0; i++) {
            double d1 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (i + 0) / b0 - 0.125;
            double d3 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (i + 1) / b0 - 0.125;
            AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox(
                this.boundingBox.minX, d1, this.boundingBox.minZ, this.boundingBox.maxX, d3, this.boundingBox.maxZ
            );
            if (this.worldObj.isAABBInMaterial(axisalignedbb, Material.water)) {
                d0 += 1.0 / b0;
            }
        }

        double d10 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        if (d10 > 0.26249999999999996) {
            double d2 = Math.cos(this.rotationYaw * Math.PI / 180.0);
            double d4 = Math.sin(this.rotationYaw * Math.PI / 180.0);

            for (int j = 0; j < 1.0 + d10 * 60.0; j++) {
                double d5 = this.rand.nextFloat() * 2.0F - 1.0F;
                double d6 = (this.rand.nextInt(2) * 2 - 1) * 0.7;
                if (this.rand.nextBoolean()) {
                    double d8 = this.posX - d2 * d5 * 0.8 + d4 * d6;
                    double d9 = this.posZ - d4 * d5 * 0.8 - d2 * d6;
                    this.worldObj.spawnParticle("splash", d8, this.posY - 0.125, d9, this.motionX, this.motionY, this.motionZ);
                } else {
                    double d24 = this.posX + d2 + d4 * d5 * 0.7;
                    double d25 = this.posZ + d4 - d2 * d5 * 0.7;
                    this.worldObj.spawnParticle("splash", d24, this.posY - 0.125, d25, this.motionX, this.motionY, this.motionZ);
                }
            }
        }

        if (this.worldObj.isRemote && this.isBoatEmpty) {
            if (this.boatPosRotationIncrements > 0) {
                double d13 = this.posX + (this.boatX - this.posX) / this.boatPosRotationIncrements;
                double d17 = this.posY + (this.boatY - this.posY) / this.boatPosRotationIncrements;
                double d20 = this.posZ + (this.boatZ - this.posZ) / this.boatPosRotationIncrements;
                double d23 = MathHelper.wrapAngleTo180_double(this.boatYaw - this.rotationYaw);
                this.rotationYaw = (float)(this.rotationYaw + d23 / this.boatPosRotationIncrements);
                this.rotationPitch = (float)(this.rotationPitch + (this.boatPitch - this.rotationPitch) / this.boatPosRotationIncrements);
                this.boatPosRotationIncrements--;
                this.setPosition(d13, d17, d20);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            } else {
                double d14 = this.posX + this.motionX;
                double d18 = this.posY + this.motionY;
                double d21 = this.posZ + this.motionZ;
                this.setPosition(d14, d18, d21);
                if (this.onGround) {
                    this.motionX *= 0.5;
                    this.motionY *= 0.5;
                    this.motionZ *= 0.5;
                }

                this.motionX *= 0.99F;
                this.motionY *= 0.95F;
                this.motionZ *= 0.99F;
            }
        } else {
            if (d0 < 1.0) {
                double d11 = d0 * 2.0 - 1.0;
                this.motionY += 0.04F * d11;
            } else {
                if (this.motionY < 0.0) {
                    this.motionY /= 2.0;
                }

                this.motionY += 0.007F;
            }

            if (this.riddenByEntity != null && this.riddenByEntity instanceof EntityLivingBase) {
                EntityLivingBase entitylivingbase = (EntityLivingBase)this.riddenByEntity;
                float f = this.riddenByEntity.rotationYaw + -entitylivingbase.moveStrafing * 90.0F;
                this.motionX = this.motionX + -Math.sin(f * (float)Math.PI / 180.0F) * this.speedMultiplier * entitylivingbase.moveForward * 0.05F;
                this.motionZ = this.motionZ + Math.cos(f * (float)Math.PI / 180.0F) * this.speedMultiplier * entitylivingbase.moveForward * 0.05F;
            }

            double d12 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (d12 > 0.35) {
                double d15 = 0.35 / d12;
                this.motionX *= d15;
                this.motionZ *= d15;
                d12 = 0.35;
            }

            if (d12 > d10 && this.speedMultiplier < 0.35) {
                this.speedMultiplier = this.speedMultiplier + (0.35 - this.speedMultiplier) / 35.0;
                if (this.speedMultiplier > 0.35) {
                    this.speedMultiplier = 0.35;
                }
            } else {
                this.speedMultiplier = this.speedMultiplier - (this.speedMultiplier - 0.07) / 35.0;
                if (this.speedMultiplier < 0.07) {
                    this.speedMultiplier = 0.07;
                }
            }

            for (int l = 0; l < 4; l++) {
                int k1 = MathHelper.floor_double(this.posX + (l % 2 - 0.5) * 0.8);
                int l1 = MathHelper.floor_double(this.posZ + (l / 2 - 0.5) * 0.8);

                for (int i2 = 0; i2 < 2; i2++) {
                    int k = MathHelper.floor_double(this.posY) + i2;
                    Block block = this.worldObj.getBlock(k1, k, l1);
                    if (block == Blocks.snow_layer) {
                        this.worldObj.setBlockToAir(k1, k, l1);
                        this.isCollidedHorizontally = false;
                    } else if (block == Blocks.waterlily) {
                        this.worldObj.breakBlock(k1, k, l1, true);
                        this.isCollidedHorizontally = false;
                    }
                }
            }

            if (this.onGround) {
                this.motionX *= 0.5;
                this.motionY *= 0.5;
                this.motionZ *= 0.5;
            }

            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            if (!this.isCollidedHorizontally || !(d10 > 0.2)) {
                this.motionX *= 0.99F;
                this.motionY *= 0.95F;
                this.motionZ *= 0.99F;
            } else if (!this.worldObj.isRemote && !this.isDead) {
                this.setDead();

                for (int i1 = 0; i1 < 3; i1++) {
                    this.dropItemWithOffset(Item.getItemFromBlock(Blocks.planks), 1, 0.0F);
                }

                for (int j1 = 0; j1 < 2; j1++) {
                    this.dropItemWithOffset(Items.stick, 1, 0.0F);
                }
            }

            this.rotationPitch = 0.0F;
            double d16 = this.rotationYaw;
            double d19 = this.prevPosX - this.posX;
            double d22 = this.prevPosZ - this.posZ;
            if (d19 * d19 + d22 * d22 > 0.001) {
                d16 = (float)(Math.atan2(d22, d19) * 180.0 / Math.PI);
            }

            double d7 = MathHelper.wrapAngleTo180_double(d16 - this.rotationYaw);
            if (d7 > 20.0) {
                d7 = 20.0;
            }

            if (d7 < -20.0) {
                d7 = -20.0;
            }

            this.rotationYaw = (float)(this.rotationYaw + d7);
            this.setRotation(this.rotationYaw, this.rotationPitch);
            if (!this.worldObj.isRemote) {
                List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.2F, 0.0, 0.2F));
                if (list != null && !list.isEmpty()) {
                    for (int j2 = 0; j2 < list.size(); j2++) {
                        Entity entity = (Entity)list.get(j2);
                        if (entity != this.riddenByEntity && entity.canBePushed() && entity instanceof EntityBoat) {
                            entity.applyEntityCollision(this);
                        }
                    }
                }

                if (this.riddenByEntity != null && this.riddenByEntity.isDead) {
                    this.riddenByEntity = null;
                }
            }
        }
    }

    @Override
    public void updateRiderPosition() {
        if (this.riddenByEntity != null) {
            double d0 = Math.cos(this.rotationYaw * Math.PI / 180.0) * 0.4;
            double d1 = Math.sin(this.rotationYaw * Math.PI / 180.0) * 0.4;
            this.riddenByEntity.setPosition(this.posX + d0, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ + d1);
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
    }

    @Override
    public float getShadowSize() {
        return 0.0F;
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        if (this.riddenByEntity != null && this.riddenByEntity instanceof EntityPlayer && this.riddenByEntity != var1) {
            return true;
        }

        if (!this.worldObj.isRemote) {
            var1.mountEntity(this);
        }

        return true;
    }

    @Override
    protected void updateFallState(double var1, boolean var3) {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posY);
        int k = MathHelper.floor_double(this.posZ);
        if (var3) {
            if (this.fallDistance > 3.0F) {
                this.fall(this.fallDistance);
                if (!this.worldObj.isRemote && !this.isDead) {
                    this.setDead();

                    for (int l = 0; l < 3; l++) {
                        this.dropItemWithOffset(Item.getItemFromBlock(Blocks.planks), 1, 0.0F);
                    }

                    for (int i1 = 0; i1 < 2; i1++) {
                        this.dropItemWithOffset(Items.stick, 1, 0.0F);
                    }
                }

                this.fallDistance = 0.0F;
            }
        } else if (this.worldObj.getBlock(i, j - 1, k).getMaterial() != Material.water && var1 < 0.0) {
            this.fallDistance = (float)(this.fallDistance - var1);
        }
    }

    public void setDamageTaken(float var1) {
        this.dataWatcher.updateObject(19, var1);
    }

    public float getDamageTaken() {
        return this.dataWatcher.getWatchableObjectFloat(19);
    }

    public void setTimeSinceHit(int var1) {
        this.dataWatcher.updateObject(17, var1);
    }

    public int getTimeSinceHit() {
        return this.dataWatcher.getWatchableObjectInt(17);
    }

    public void setForwardDirection(int var1) {
        this.dataWatcher.updateObject(18, var1);
    }

    public int getForwardDirection() {
        return this.dataWatcher.getWatchableObjectInt(18);
    }

    public void setIsBoatEmpty(boolean var1) {
        this.isBoatEmpty = var1;
    }
}
