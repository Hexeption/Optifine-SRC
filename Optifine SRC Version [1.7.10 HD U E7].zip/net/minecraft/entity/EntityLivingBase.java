package net.minecraft.entity;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.BaseAttributeMap;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.ServersideAttributeMap;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagShort;
import net.minecraft.network.play.server.S04PacketEntityEquipment;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.network.play.server.S0DPacketCollectItem;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionHelper;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.CombatTracker;
import net.minecraft.util.DamageSource;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public abstract class EntityLivingBase extends Entity {
    private static final UUID sprintingSpeedBoostModifierUUID = UUID.fromString("662A6B8D-DA3E-4C1C-8813-96EA6097278D");
    private static final AttributeModifier sprintingSpeedBoostModifier = new AttributeModifier(
            sprintingSpeedBoostModifierUUID, "Sprinting speed boost", 0.3F, 2
        )
        .setSaved(false);
    private BaseAttributeMap attributeMap;
    private final CombatTracker _combatTracker = new CombatTracker(this);
    private final HashMap activePotionsMap = new HashMap();
    private final ItemStack[] previousEquipment = new ItemStack[5];
    public boolean isSwingInProgress;
    public int swingProgressInt;
    public int arrowHitTimer;
    public float prevHealth;
    public int hurtTime;
    public int maxHurtTime;
    public float attackedAtYaw;
    public int deathTime;
    public int attackTime;
    public float prevSwingProgress;
    public float swingProgress;
    public float prevLimbSwingAmount;
    public float limbSwingAmount;
    public float limbSwing;
    public int maxHurtResistantTime = 20;
    public float prevCameraPitch;
    public float cameraPitch;
    public float field_70769_ao;
    public float field_70770_ap;
    public float renderYawOffset;
    public float prevRenderYawOffset;
    public float rotationYawHead;
    public float prevRotationYawHead;
    public float jumpMovementFactor = 0.02F;
    protected EntityPlayer attackingPlayer;
    protected int recentlyHit;
    protected boolean dead;
    public int entityAge;
    protected float field_70768_au;
    protected float field_110154_aX;
    protected float field_70764_aw;
    protected float field_70763_ax;
    protected float field_70741_aB;
    protected int scoreValue;
    protected float lastDamage;
    protected boolean isJumping;
    public float moveStrafing;
    public float moveForward;
    protected float randomYawVelocity;
    protected int newPosRotationIncrements;
    protected double newPosX;
    protected double newPosY;
    protected double newPosZ;
    protected double newRotationYaw;
    protected double newRotationPitch;
    private boolean potionsNeedUpdate = true;
    private EntityLivingBase entityLivingToAttack;
    private int revengeTimer;
    private EntityLivingBase lastAttacker;
    private int lastAttackerTime;
    private float landMovementFactor;
    private int jumpTicks;
    private float field_110151_bq;

    public EntityLivingBase(World var1) {
        super(var1);
        this.applyEntityAttributes();
        this.setHealth(this.getMaxHealth());
        this.preventEntitySpawning = true;
        this.field_70770_ap = (float)(Math.random() + 1.0) * 0.01F;
        this.setPosition(this.posX, this.posY, this.posZ);
        this.field_70769_ao = (float)Math.random() * 12398.0F;
        this.rotationYaw = (float)(Math.random() * (float)Math.PI * 2.0);
        this.rotationYawHead = this.rotationYaw;
        this.stepHeight = 0.5F;
    }

    @Override
    protected void entityInit() {
        this.dataWatcher.addObject(7, 0);
        this.dataWatcher.addObject(8, (byte)0);
        this.dataWatcher.addObject(9, (byte)0);
        this.dataWatcher.addObject(6, 1.0F);
    }

    protected void applyEntityAttributes() {
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.maxHealth);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.knockbackResistance);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.movementSpeed);
        if (!this.isAIEnabled()) {
            this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.1F);
        }
    }

    @Override
    protected void updateFallState(double var1, boolean var3) {
        if (!this.isInWater()) {
            this.handleWaterMovement();
        }

        if (var3 && this.fallDistance > 0.0F) {
            int i = MathHelper.floor_double(this.posX);
            int j = MathHelper.floor_double(this.posY - 0.2F - this.yOffset);
            int k = MathHelper.floor_double(this.posZ);
            Block block = this.worldObj.getBlock(i, j, k);
            if (block.getMaterial() == Material.air) {
                int l = this.worldObj.getBlock(i, j - 1, k).getRenderType();
                if (l == 11 || l == 32 || l == 21) {
                    block = this.worldObj.getBlock(i, j - 1, k);
                }
            } else if (!this.worldObj.isRemote && this.fallDistance > 3.0F) {
                this.worldObj.playAuxSFX(2006, i, j, k, MathHelper.ceiling_float_int(this.fallDistance - 3.0F));
            }

            block.onFallenUpon(this.worldObj, i, j, k, this, this.fallDistance);
        }

        super.updateFallState(var1, var3);
    }

    public boolean canBreatheUnderwater() {
        return false;
    }

    @Override
    public void onEntityUpdate() {
        this.prevSwingProgress = this.swingProgress;
        super.onEntityUpdate();
        this.worldObj.theProfiler.startSection("livingEntityBaseTick");
        if (this.isEntityAlive() && this.isEntityInsideOpaqueBlock()) {
            this.attackEntityFrom(DamageSource.inWall, 1.0F);
        }

        if (this.isImmuneToFire() || this.worldObj.isRemote) {
            this.extinguish();
        }

        boolean flag = this instanceof EntityPlayer && ((EntityPlayer)this).capabilities.disableDamage;
        if (this.isEntityAlive() && this.isInsideOfMaterial(Material.water)) {
            if (!this.canBreatheUnderwater() && !this.isPotionActive(Potion.waterBreathing.id) && !flag) {
                this.setAir(this.decreaseAirSupply(this.getAir()));
                if (this.getAir() == -20) {
                    this.setAir(0);

                    for (int i = 0; i < 8; i++) {
                        float f = this.rand.nextFloat() - this.rand.nextFloat();
                        float f1 = this.rand.nextFloat() - this.rand.nextFloat();
                        float f2 = this.rand.nextFloat() - this.rand.nextFloat();
                        this.worldObj.spawnParticle("bubble", this.posX + f, this.posY + f1, this.posZ + f2, this.motionX, this.motionY, this.motionZ);
                    }

                    this.attackEntityFrom(DamageSource.drown, 2.0F);
                }
            }

            if (!this.worldObj.isRemote && this.isRiding() && this.ridingEntity instanceof EntityLivingBase) {
                this.mountEntity(null);
            }
        } else {
            this.setAir(300);
        }

        if (this.isEntityAlive() && this.isWet()) {
            this.extinguish();
        }

        this.prevCameraPitch = this.cameraPitch;
        if (this.attackTime > 0) {
            this.attackTime--;
        }

        if (this.hurtTime > 0) {
            this.hurtTime--;
        }

        if (this.hurtResistantTime > 0 && !(this instanceof EntityPlayerMP)) {
            this.hurtResistantTime--;
        }

        if (this.getHealth() <= 0.0F) {
            this.onDeathUpdate();
        }

        if (this.recentlyHit > 0) {
            this.recentlyHit--;
        } else {
            this.attackingPlayer = null;
        }

        if (this.lastAttacker != null && !this.lastAttacker.isEntityAlive()) {
            this.lastAttacker = null;
        }

        if (this.entityLivingToAttack != null) {
            if (!this.entityLivingToAttack.isEntityAlive()) {
                this.setRevengeTarget(null);
            } else if (this.ticksExisted - this.revengeTimer > 100) {
                this.setRevengeTarget(null);
            }
        }

        this.updatePotionEffects();
        this.field_70763_ax = this.field_70764_aw;
        this.prevRenderYawOffset = this.renderYawOffset;
        this.prevRotationYawHead = this.rotationYawHead;
        this.prevRotationYaw = this.rotationYaw;
        this.prevRotationPitch = this.rotationPitch;
        this.worldObj.theProfiler.endSection();
    }

    public boolean isChild() {
        return false;
    }

    protected void onDeathUpdate() {
        this.deathTime++;
        if (this.deathTime == 20) {
            if (!this.worldObj.isRemote
                && (this.recentlyHit > 0 || this.isPlayer())
                && this.func_146066_aG()
                && this.worldObj.getGameRules().getGameRuleBooleanValue("doMobLoot")) {
                int i = this.getExperiencePoints(this.attackingPlayer);

                while (i > 0) {
                    int j = EntityXPOrb.getXPSplit(i);
                    i -= j;
                    this.worldObj.spawnEntityInWorld(new EntityXPOrb(this.worldObj, this.posX, this.posY, this.posZ, j));
                }
            }

            this.setDead();

            for (int k = 0; k < 20; k++) {
                double d2 = this.rand.nextGaussian() * 0.02;
                double d0 = this.rand.nextGaussian() * 0.02;
                double d1 = this.rand.nextGaussian() * 0.02;
                this.worldObj
                    .spawnParticle(
                        "explode",
                        this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        this.posY + this.rand.nextFloat() * this.height,
                        this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        d2,
                        d0,
                        d1
                    );
            }
        }
    }

    protected boolean func_146066_aG() {
        return !this.isChild();
    }

    protected int decreaseAirSupply(int var1) {
        int i = EnchantmentHelper.getRespiration(this);
        return i > 0 && this.rand.nextInt(i + 1) > 0 ? var1 : var1 - 1;
    }

    protected int getExperiencePoints(EntityPlayer var1) {
        return 0;
    }

    protected boolean isPlayer() {
        return false;
    }

    public Random getRNG() {
        return this.rand;
    }

    public EntityLivingBase getAITarget() {
        return this.entityLivingToAttack;
    }

    public int getRevengeTimer() {
        return this.revengeTimer;
    }

    public void setRevengeTarget(EntityLivingBase var1) {
        this.entityLivingToAttack = var1;
        this.revengeTimer = this.ticksExisted;
    }

    public EntityLivingBase getLastAttacker() {
        return this.lastAttacker;
    }

    public int getLastAttackerTime() {
        return this.lastAttackerTime;
    }

    public void setLastAttacker(Entity var1) {
        if (var1 instanceof EntityLivingBase) {
            this.lastAttacker = (EntityLivingBase)var1;
        } else {
            this.lastAttacker = null;
        }

        this.lastAttackerTime = this.ticksExisted;
    }

    public int getAge() {
        return this.entityAge;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setFloat("HealF", this.getHealth());
        var1.setShort("Health", (short)Math.ceil(this.getHealth()));
        var1.setShort("HurtTime", (short)this.hurtTime);
        var1.setShort("DeathTime", (short)this.deathTime);
        var1.setShort("AttackTime", (short)this.attackTime);
        var1.setFloat("AbsorptionAmount", this.getAbsorptionAmount());

        for (ItemStack itemstack : this.getInventory()) {
            if (itemstack != null) {
                this.attributeMap.removeAttributeModifiers(itemstack.getAttributeModifiers());
            }
        }

        var1.setTag("Attributes", SharedMonsterAttributes.writeBaseAttributeMapToNBT(this.getAttributeMap()));

        for (ItemStack itemstack1 : this.getInventory()) {
            if (itemstack1 != null) {
                this.attributeMap.applyAttributeModifiers(itemstack1.getAttributeModifiers());
            }
        }

        if (!this.activePotionsMap.isEmpty()) {
            NBTTagList nbttaglist = new NBTTagList();

            for (PotionEffect potioneffect : (Iterable<PotionEffect>) (Iterable) this.activePotionsMap.values()) {
                nbttaglist.appendTag(potioneffect.writeCustomPotionEffectToNBT(new NBTTagCompound()));
            }

            var1.setTag("ActiveEffects", nbttaglist);
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        this.setAbsorptionAmount(var1.getFloat("AbsorptionAmount"));
        if (var1.hasKey("Attributes", 9) && this.worldObj != null && !this.worldObj.isRemote) {
            SharedMonsterAttributes.func_151475_a(this.getAttributeMap(), var1.getTagList("Attributes", 10));
        }

        if (var1.hasKey("ActiveEffects", 9)) {
            NBTTagList nbttaglist = var1.getTagList("ActiveEffects", 10);

            for (int i = 0; i < nbttaglist.tagCount(); i++) {
                NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
                PotionEffect potioneffect = PotionEffect.readCustomPotionEffectFromNBT(nbttagcompound);
                if (potioneffect != null) {
                    this.activePotionsMap.put(potioneffect.getPotionID(), potioneffect);
                }
            }
        }

        if (var1.hasKey("HealF", 99)) {
            this.setHealth(var1.getFloat("HealF"));
        } else {
            NBTBase nbtbase = var1.getTag("Health");
            if (nbtbase == null) {
                this.setHealth(this.getMaxHealth());
            } else if (nbtbase.getId() == 5) {
                this.setHealth(((NBTTagFloat)nbtbase).getFloat());
            } else if (nbtbase.getId() == 2) {
                this.setHealth(((NBTTagShort)nbtbase).getShort());
            }
        }

        this.hurtTime = var1.getShort("HurtTime");
        this.deathTime = var1.getShort("DeathTime");
        this.attackTime = var1.getShort("AttackTime");
    }

    protected void updatePotionEffects() {
        Iterator iterator = this.activePotionsMap.keySet().iterator();

        while (iterator.hasNext()) {
            Integer integer = (Integer)iterator.next();
            PotionEffect potioneffect = (PotionEffect)this.activePotionsMap.get(integer);
            if (!potioneffect.onUpdate(this)) {
                if (!this.worldObj.isRemote) {
                    iterator.remove();
                    this.onFinishedPotionEffect(potioneffect);
                }
            } else if (potioneffect.getDuration() % 600 == 0) {
                this.onChangedPotionEffect(potioneffect, false);
            }
        }

        if (this.potionsNeedUpdate) {
            if (!this.worldObj.isRemote) {
                if (this.activePotionsMap.isEmpty()) {
                    this.dataWatcher.updateObject(8, (byte)0);
                    this.dataWatcher.updateObject(7, 0);
                    this.setInvisible(false);
                } else {
                    int i = PotionHelper.calcPotionLiquidColor(this.activePotionsMap.values());
                    this.dataWatcher.updateObject(8, Byte.valueOf((byte)(PotionHelper.func_82817_b(this.activePotionsMap.values()) ? 1 : 0)));
                    this.dataWatcher.updateObject(7, i);
                    this.setInvisible(this.isPotionActive(Potion.invisibility.id));
                }
            }

            this.potionsNeedUpdate = false;
        }

        int j = this.dataWatcher.getWatchableObjectInt(7);
        boolean flag1 = this.dataWatcher.getWatchableObjectByte(8) > 0;
        if (j > 0) {
            boolean flag = false;
            if (!this.isInvisible()) {
                flag = this.rand.nextBoolean();
            } else {
                flag = this.rand.nextInt(15) == 0;
            }

            if (flag1) {
                flag &= this.rand.nextInt(5) == 0;
            }

            if (flag && j > 0) {
                double d0 = (j >> 16 & 0xFF) / 255.0;
                double d1 = (j >> 8 & 0xFF) / 255.0;
                double d2 = (j >> 0 & 0xFF) / 255.0;
                this.worldObj
                    .spawnParticle(
                        flag1 ? "mobSpellAmbient" : "mobSpell",
                        this.posX + (this.rand.nextDouble() - 0.5) * this.width,
                        this.posY + this.rand.nextDouble() * this.height - this.yOffset,
                        this.posZ + (this.rand.nextDouble() - 0.5) * this.width,
                        d0,
                        d1,
                        d2
                    );
            }
        }
    }

    public void clearActivePotions() {
        Iterator iterator = this.activePotionsMap.keySet().iterator();

        while (iterator.hasNext()) {
            Integer integer = (Integer)iterator.next();
            PotionEffect potioneffect = (PotionEffect)this.activePotionsMap.get(integer);
            if (!this.worldObj.isRemote) {
                iterator.remove();
                this.onFinishedPotionEffect(potioneffect);
            }
        }
    }

    public Collection getActivePotionEffects() {
        return this.activePotionsMap.values();
    }

    public boolean isPotionActive(int var1) {
        return this.activePotionsMap.containsKey(var1);
    }

    public boolean isPotionActive(Potion var1) {
        return this.activePotionsMap.containsKey(var1.id);
    }

    public PotionEffect getActivePotionEffect(Potion var1) {
        return (PotionEffect)this.activePotionsMap.get(var1.id);
    }

    public void addPotionEffect(PotionEffect var1) {
        if (this.isPotionApplicable(var1)) {
            if (this.activePotionsMap.containsKey(var1.getPotionID())) {
                ((PotionEffect)this.activePotionsMap.get(var1.getPotionID())).combine(var1);
                this.onChangedPotionEffect((PotionEffect)this.activePotionsMap.get(var1.getPotionID()), true);
            } else {
                this.activePotionsMap.put(var1.getPotionID(), var1);
                this.onNewPotionEffect(var1);
            }
        }
    }

    public boolean isPotionApplicable(PotionEffect var1) {
        if (this.getCreatureAttribute() == EnumCreatureAttribute.UNDEAD) {
            int i = var1.getPotionID();
            if (i == Potion.regeneration.id || i == Potion.poison.id) {
                return false;
            }
        }

        return true;
    }

    public boolean isEntityUndead() {
        return this.getCreatureAttribute() == EnumCreatureAttribute.UNDEAD;
    }

    public void removePotionEffectClient(int var1) {
        this.activePotionsMap.remove(var1);
    }

    public void removePotionEffect(int var1) {
        PotionEffect potioneffect = (PotionEffect)this.activePotionsMap.remove(var1);
        if (potioneffect != null) {
            this.onFinishedPotionEffect(potioneffect);
        }
    }

    protected void onNewPotionEffect(PotionEffect var1) {
        this.potionsNeedUpdate = true;
        if (!this.worldObj.isRemote) {
            Potion.potionTypes[var1.getPotionID()].applyAttributesModifiersToEntity(this, this.getAttributeMap(), var1.getAmplifier());
        }
    }

    protected void onChangedPotionEffect(PotionEffect var1, boolean var2) {
        this.potionsNeedUpdate = true;
        if (var2 && !this.worldObj.isRemote) {
            Potion.potionTypes[var1.getPotionID()].removeAttributesModifiersFromEntity(this, this.getAttributeMap(), var1.getAmplifier());
            Potion.potionTypes[var1.getPotionID()].applyAttributesModifiersToEntity(this, this.getAttributeMap(), var1.getAmplifier());
        }
    }

    protected void onFinishedPotionEffect(PotionEffect var1) {
        this.potionsNeedUpdate = true;
        if (!this.worldObj.isRemote) {
            Potion.potionTypes[var1.getPotionID()].removeAttributesModifiersFromEntity(this, this.getAttributeMap(), var1.getAmplifier());
        }
    }

    public void heal(float var1) {
        float f = this.getHealth();
        if (f > 0.0F) {
            this.setHealth(f + var1);
        }
    }

    public final float getHealth() {
        return this.dataWatcher.getWatchableObjectFloat(6);
    }

    public void setHealth(float var1) {
        this.dataWatcher.updateObject(6, MathHelper.clamp_float(var1, 0.0F, this.getMaxHealth()));
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        if (this.worldObj.isRemote) {
            return false;
        }

        this.entityAge = 0;
        if (this.getHealth() <= 0.0F) {
            return false;
        }

        if (var1.isFireDamage() && this.isPotionActive(Potion.fireResistance)) {
            return false;
        }

        if ((var1 == DamageSource.anvil || var1 == DamageSource.fallingBlock) && this.getEquipmentInSlot(4) != null) {
            this.getEquipmentInSlot(4).damageItem((int)(var2 * 4.0F + this.rand.nextFloat() * var2 * 2.0F), this);
            var2 *= 12.0F / 16.0F;
        }

        this.limbSwingAmount = 1.5F;
        boolean flag = true;
        if (this.hurtResistantTime > this.maxHurtResistantTime / 2.0F) {
            if (var2 <= this.lastDamage) {
                return false;
            }

            this.damageEntity(var1, var2 - this.lastDamage);
            this.lastDamage = var2;
            flag = false;
        } else {
            this.lastDamage = var2;
            this.prevHealth = this.getHealth();
            this.hurtResistantTime = this.maxHurtResistantTime;
            this.damageEntity(var1, var2);
            this.hurtTime = this.maxHurtTime = 10;
        }

        this.attackedAtYaw = 0.0F;
        Entity entity = var1.getEntity();
        if (entity != null) {
            if (entity instanceof EntityLivingBase) {
                this.setRevengeTarget((EntityLivingBase)entity);
            }

            if (entity instanceof EntityPlayer) {
                this.recentlyHit = 100;
                this.attackingPlayer = (EntityPlayer)entity;
            } else if (entity instanceof EntityWolf) {
                EntityWolf entitywolf = (EntityWolf)entity;
                if (entitywolf.isTamed()) {
                    this.recentlyHit = 100;
                    this.attackingPlayer = null;
                }
            }
        }

        if (flag) {
            this.worldObj.setEntityState(this, (byte)2);
            if (var1 != DamageSource.drown) {
                this.setBeenAttacked();
            }

            if (entity != null) {
                double d1 = entity.posX - this.posX;

                double d0;
                for (d0 = entity.posZ - this.posZ; d1 * d1 + d0 * d0 < 1.0E-4; d0 = (Math.random() - Math.random()) * 0.01) {
                    d1 = (Math.random() - Math.random()) * 0.01;
                }

                this.attackedAtYaw = (float)(Math.atan2(d0, d1) * 180.0 / (float)Math.PI) - this.rotationYaw;
                this.knockBack(entity, var2, d1, d0);
            } else {
                this.attackedAtYaw = (int)(Math.random() * 2.0) * 180;
            }
        }

        if (this.getHealth() <= 0.0F) {
            String s = this.getDeathSound();
            if (flag && s != null) {
                this.playSound(s, this.getSoundVolume(), this.getSoundPitch());
            }

            this.onDeath(var1);
        } else {
            String s1 = this.getHurtSound();
            if (flag && s1 != null) {
                this.playSound(s1, this.getSoundVolume(), this.getSoundPitch());
            }
        }

        return true;
    }

    public void renderBrokenItemStack(ItemStack var1) {
        this.playSound("random.break", 0.8F, 0.8F + this.worldObj.rand.nextFloat() * 0.4F);

        for (int i = 0; i < 5; i++) {
            Vec3 vec3 = Vec3.createVectorHelper((this.rand.nextFloat() - 0.5) * 0.1, Math.random() * 0.1 + 0.1, 0.0);
            vec3.rotateAroundX(-this.rotationPitch * (float)Math.PI / 180.0F);
            vec3.rotateAroundY(-this.rotationYaw * (float)Math.PI / 180.0F);
            Vec3 vec31 = Vec3.createVectorHelper((this.rand.nextFloat() - 0.5) * 0.3, -this.rand.nextFloat() * 0.6 - 0.3, 0.6);
            vec31.rotateAroundX(-this.rotationPitch * (float)Math.PI / 180.0F);
            vec31.rotateAroundY(-this.rotationYaw * (float)Math.PI / 180.0F);
            vec31 = vec31.addVector(this.posX, this.posY + this.getEyeHeight(), this.posZ);
            this.worldObj
                .spawnParticle(
                    "iconcrack_" + Item.getIdFromItem(var1.getItem()), vec31.xCoord, vec31.yCoord, vec31.zCoord, vec3.xCoord, vec3.yCoord + 0.05, vec3.zCoord
                );
        }
    }

    public void onDeath(DamageSource var1) {
        Entity entity = var1.getEntity();
        EntityLivingBase entitylivingbase = this.func_94060_bK();
        if (this.scoreValue >= 0 && entitylivingbase != null) {
            entitylivingbase.addToPlayerScore(this, this.scoreValue);
        }

        if (entity != null) {
            entity.onKillEntity(this);
        }

        this.dead = true;
        this.getCombatTracker().func_94549_h();
        if (!this.worldObj.isRemote) {
            int i = 0;
            if (entity instanceof EntityPlayer) {
                i = EnchantmentHelper.getLootingModifier((EntityLivingBase)entity);
            }

            if (this.func_146066_aG() && this.worldObj.getGameRules().getGameRuleBooleanValue("doMobLoot")) {
                this.dropFewItems(this.recentlyHit > 0, i);
                this.dropEquipment(this.recentlyHit > 0, i);
                if (this.recentlyHit > 0) {
                    int j = this.rand.nextInt(200) - i;
                    if (j < 5) {
                        this.dropRareDrop(j <= 0 ? 1 : 0);
                    }
                }
            }
        }

        this.worldObj.setEntityState(this, (byte)3);
    }

    protected void dropEquipment(boolean var1, int var2) {
    }

    public void knockBack(Entity var1, float var2, double var3, double var5) {
        if (!(this.rand.nextDouble() < this.getEntityAttribute(SharedMonsterAttributes.knockbackResistance).getAttributeValue())) {
            this.isAirBorne = true;
            float f = MathHelper.sqrt_double(var3 * var3 + var5 * var5);
            float f1 = 0.4F;
            this.motionX /= 2.0;
            this.motionY /= 2.0;
            this.motionZ /= 2.0;
            this.motionX -= var3 / f * f1;
            this.motionY += f1;
            this.motionZ -= var5 / f * f1;
            if (this.motionY > 0.4F) {
                this.motionY = 0.4F;
            }
        }
    }

    protected String getHurtSound() {
        return "game.neutral.hurt";
    }

    protected String getDeathSound() {
        return "game.neutral.die";
    }

    protected void dropRareDrop(int var1) {
    }

    protected void dropFewItems(boolean var1, int var2) {
    }

    public boolean isOnLadder() {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.boundingBox.minY);
        int k = MathHelper.floor_double(this.posZ);
        Block block = this.worldObj.getBlock(i, j, k);
        return block == Blocks.ladder || block == Blocks.vine;
    }

    @Override
    public boolean isEntityAlive() {
        return !this.isDead && this.getHealth() > 0.0F;
    }

    @Override
    protected void fall(float var1) {
        super.fall(var1);
        PotionEffect potioneffect = this.getActivePotionEffect(Potion.jump);
        float f = potioneffect != null ? potioneffect.getAmplifier() + 1 : 0.0F;
        int i = MathHelper.ceiling_float_int(var1 - 3.0F - f);
        if (i > 0) {
            this.playSound(this.func_146067_o(i), 1.0F, 1.0F);
            this.attackEntityFrom(DamageSource.fall, i);
            int j = MathHelper.floor_double(this.posX);
            int k = MathHelper.floor_double(this.posY - 0.2F - this.yOffset);
            int l = MathHelper.floor_double(this.posZ);
            Block block = this.worldObj.getBlock(j, k, l);
            if (block.getMaterial() != Material.air) {
                Block.SoundType block$soundtype = block.stepSound;
                this.playSound(block$soundtype.getStepSound(), block$soundtype.getVolume() * 0.5F, block$soundtype.getFrequency() * (12.0F / 16.0F));
            }
        }
    }

    protected String func_146067_o(int var1) {
        return var1 > 4 ? "game.neutral.hurt.fall.big" : "game.neutral.hurt.fall.small";
    }

    @Override
    public void performHurtAnimation() {
        this.hurtTime = this.maxHurtTime = 10;
        this.attackedAtYaw = 0.0F;
    }

    public int getTotalArmorValue() {
        int i = 0;

        for (ItemStack itemstack : this.getInventory()) {
            if (itemstack != null && itemstack.getItem() instanceof ItemArmor) {
                int j = ((ItemArmor)itemstack.getItem()).damageReduceAmount;
                i += j;
            }
        }

        return i;
    }

    protected void damageArmor(float var1) {
    }

    protected float applyArmorCalculations(DamageSource var1, float var2) {
        if (!var1.isUnblockable()) {
            int i = 25 - this.getTotalArmorValue();
            float f = var2 * i;
            this.damageArmor(var2);
            var2 = f / 25.0F;
        }

        return var2;
    }

    protected float applyPotionDamageCalculations(DamageSource var1, float var2) {
        if (var1.isDamageAbsolute()) {
            return var2;
        }

        if (this instanceof EntityZombie) {
            var2 = var2;
        }

        if (this.isPotionActive(Potion.resistance) && var1 != DamageSource.outOfWorld) {
            int i = (this.getActivePotionEffect(Potion.resistance).getAmplifier() + 1) * 5;
            int j = 25 - i;
            float f = var2 * j;
            var2 = f / 25.0F;
        }

        if (var2 <= 0.0F) {
            return 0.0F;
        }

        int k = EnchantmentHelper.getEnchantmentModifierDamage(this.getInventory(), var1);
        if (k > 20) {
            k = 20;
        }

        if (k > 0 && k <= 20) {
            int l = 25 - k;
            float f1 = var2 * l;
            var2 = f1 / 25.0F;
        }

        return var2;
    }

    protected void damageEntity(DamageSource var1, float var2) {
        if (!this.isEntityInvulnerable()) {
            var2 = this.applyArmorCalculations(var1, var2);
            var2 = this.applyPotionDamageCalculations(var1, var2);
            float f = var2;
            var2 = Math.max(var2 - this.getAbsorptionAmount(), 0.0F);
            this.setAbsorptionAmount(this.getAbsorptionAmount() - (f - var2));
            if (var2 != 0.0F) {
                float f1 = this.getHealth();
                this.setHealth(f1 - var2);
                this.getCombatTracker().func_94547_a(var1, f1, var2);
                this.setAbsorptionAmount(this.getAbsorptionAmount() - var2);
            }
        }
    }

    public CombatTracker getCombatTracker() {
        return this._combatTracker;
    }

    public EntityLivingBase func_94060_bK() {
        if (this._combatTracker.func_94550_c() != null) {
            return this._combatTracker.func_94550_c();
        } else if (this.attackingPlayer != null) {
            return this.attackingPlayer;
        } else {
            return this.entityLivingToAttack != null ? this.entityLivingToAttack : null;
        }
    }

    public final float getMaxHealth() {
        return (float)this.getEntityAttribute(SharedMonsterAttributes.maxHealth).getAttributeValue();
    }

    public final int getArrowCountInEntity() {
        return this.dataWatcher.getWatchableObjectByte(9);
    }

    public final void setArrowCountInEntity(int var1) {
        this.dataWatcher.updateObject(9, (byte)var1);
    }

    private int getArmSwingAnimationEnd() {
        if (this.isPotionActive(Potion.digSpeed)) {
            return 6 - (1 + this.getActivePotionEffect(Potion.digSpeed).getAmplifier()) * 1;
        } else {
            return this.isPotionActive(Potion.digSlowdown) ? 6 + (1 + this.getActivePotionEffect(Potion.digSlowdown).getAmplifier()) * 2 : 6;
        }
    }

    public void swingItem() {
        if (!this.isSwingInProgress || this.swingProgressInt >= this.getArmSwingAnimationEnd() / 2 || this.swingProgressInt < 0) {
            this.swingProgressInt = -1;
            this.isSwingInProgress = true;
            if (this.worldObj instanceof WorldServer) {
                ((WorldServer)this.worldObj).getEntityTracker().sendToAllTrackingEntity(this, new S0BPacketAnimation(this, 0));
            }
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 2) {
            this.limbSwingAmount = 1.5F;
            this.hurtResistantTime = this.maxHurtResistantTime;
            this.hurtTime = this.maxHurtTime = 10;
            this.attackedAtYaw = 0.0F;
            this.playSound(this.getHurtSound(), this.getSoundVolume(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            this.attackEntityFrom(DamageSource.generic, 0.0F);
        } else if (var1 == 3) {
            this.playSound(this.getDeathSound(), this.getSoundVolume(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            this.setHealth(0.0F);
            this.onDeath(DamageSource.generic);
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    @Override
    protected void kill() {
        this.attackEntityFrom(DamageSource.outOfWorld, 4.0F);
    }

    protected void updateArmSwingProgress() {
        int i = this.getArmSwingAnimationEnd();
        if (this.isSwingInProgress) {
            this.swingProgressInt++;
            if (this.swingProgressInt >= i) {
                this.swingProgressInt = 0;
                this.isSwingInProgress = false;
            }
        } else {
            this.swingProgressInt = 0;
        }

        this.swingProgress = (float)this.swingProgressInt / i;
    }

    public IAttributeInstance getEntityAttribute(IAttribute var1) {
        return this.getAttributeMap().getAttributeInstance(var1);
    }

    public BaseAttributeMap getAttributeMap() {
        if (this.attributeMap == null) {
            this.attributeMap = new ServersideAttributeMap();
        }

        return this.attributeMap;
    }

    public EnumCreatureAttribute getCreatureAttribute() {
        return EnumCreatureAttribute.UNDEFINED;
    }

    public abstract ItemStack getHeldItem();

    public abstract ItemStack getEquipmentInSlot(int var1);

    @Override
    public abstract void setCurrentItemOrArmor(int var1, ItemStack var2);

    @Override
    public void setSprinting(boolean var1) {
        super.setSprinting(var1);
        IAttributeInstance iattributeinstance = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
        if (iattributeinstance.getModifier(sprintingSpeedBoostModifierUUID) != null) {
            iattributeinstance.removeModifier(sprintingSpeedBoostModifier);
        }

        if (var1) {
            iattributeinstance.applyModifier(sprintingSpeedBoostModifier);
        }
    }

    @Override
    public abstract ItemStack[] getInventory();

    protected float getSoundVolume() {
        return 1.0F;
    }

    protected float getSoundPitch() {
        return this.isChild() ? (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.5F : (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F;
    }

    protected boolean isMovementBlocked() {
        return this.getHealth() <= 0.0F;
    }

    public void setPositionAndUpdate(double var1, double var3, double var5) {
        this.setLocationAndAngles(var1, var3, var5, this.rotationYaw, this.rotationPitch);
    }

    public void dismountEntity(Entity var1) {
        double d0 = var1.posX;
        double d1 = var1.boundingBox.minY + var1.height;
        double d2 = var1.posZ;
        byte b0 = 1;

        for (int i = -b0; i <= b0; i++) {
            for (int j = -b0; j < b0; j++) {
                if (i != 0 || j != 0) {
                    int k = (int)(this.posX + i);
                    int l = (int)(this.posZ + j);
                    AxisAlignedBB axisalignedbb = this.boundingBox.getOffsetBoundingBox(i, 1.0, j);
                    if (this.worldObj.func_147461_a(axisalignedbb).isEmpty()) {
                        if (World.doesBlockHaveSolidTopSurface(this.worldObj, k, (int)this.posY, l)) {
                            this.setPositionAndUpdate(this.posX + i, this.posY + 1.0, this.posZ + j);
                            return;
                        }

                        if (World.doesBlockHaveSolidTopSurface(this.worldObj, k, (int)this.posY - 1, l)
                            || this.worldObj.getBlock(k, (int)this.posY - 1, l).getMaterial() == Material.water) {
                            d0 = this.posX + i;
                            d1 = this.posY + 1.0;
                            d2 = this.posZ + j;
                        }
                    }
                }
            }
        }

        this.setPositionAndUpdate(d0, d1, d2);
    }

    public boolean getAlwaysRenderNameTagForRender() {
        return false;
    }

    public IIcon getItemIcon(ItemStack var1, int var2) {
        return var1.getItem().requiresMultipleRenderPasses() ? var1.getItem().getIconFromDamageForRenderPass(var1.getMetadata(), var2) : var1.getIconIndex();
    }

    protected void jump() {
        this.motionY = 0.42F;
        if (this.isPotionActive(Potion.jump)) {
            this.motionY = this.motionY + (this.getActivePotionEffect(Potion.jump).getAmplifier() + 1) * 0.1F;
        }

        if (this.isSprinting()) {
            float f = this.rotationYaw * ((float)Math.PI / 180.0F);
            this.motionX = this.motionX - MathHelper.sin(f) * 0.2F;
            this.motionZ = this.motionZ + MathHelper.cos(f) * 0.2F;
        }

        this.isAirBorne = true;
    }

    public void moveEntityWithHeading(float var1, float var2) {
        if (!this.isInWater() || this instanceof EntityPlayer && ((EntityPlayer)this).capabilities.isFlying) {
            if (!this.handleLavaMovement() || this instanceof EntityPlayer && ((EntityPlayer)this).capabilities.isFlying) {
                float f3 = 0.91F;
                if (this.onGround) {
                    f3 = this.worldObj
                            .getBlock(
                                MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ)
                            )
                            .slipperiness
                        * 0.91F;
                }

                float f = 0.16277136F / (f3 * f3 * f3);
                float f1;
                if (this.onGround) {
                    f1 = this.getAIMoveSpeed() * f;
                } else {
                    f1 = this.jumpMovementFactor;
                }

                this.moveFlying(var1, var2, f1);
                f3 = 0.91F;
                if (this.onGround) {
                    f3 = this.worldObj
                            .getBlock(
                                MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ)
                            )
                            .slipperiness
                        * 0.91F;
                }

                if (this.isOnLadder()) {
                    float f2 = 0.15F;
                    if (this.motionX < -f2) {
                        this.motionX = -f2;
                    }

                    if (this.motionX > f2) {
                        this.motionX = f2;
                    }

                    if (this.motionZ < -f2) {
                        this.motionZ = -f2;
                    }

                    if (this.motionZ > f2) {
                        this.motionZ = f2;
                    }

                    this.fallDistance = 0.0F;
                    if (this.motionY < -0.15) {
                        this.motionY = -0.15;
                    }

                    boolean flag = this.isSneaking() && this instanceof EntityPlayer;
                    if (flag && this.motionY < 0.0) {
                        this.motionY = 0.0;
                    }
                }

                this.moveEntity(this.motionX, this.motionY, this.motionZ);
                if (this.isCollidedHorizontally && this.isOnLadder()) {
                    this.motionY = 0.2;
                }

                if (this.worldObj.isRemote
                    && (
                        !this.worldObj.blockExists((int)this.posX, 0, (int)this.posZ)
                            || !this.worldObj.getChunkFromBlockCoords((int)this.posX, (int)this.posZ).isChunkLoaded
                    )) {
                    if (this.posY > 0.0) {
                        this.motionY = -0.1;
                    } else {
                        this.motionY = 0.0;
                    }
                } else {
                    this.motionY -= 0.08;
                }

                this.motionY *= 0.98F;
                this.motionX *= f3;
                this.motionZ *= f3;
            } else {
                double d1 = this.posY;
                this.moveFlying(var1, var2, 0.02F);
                this.moveEntity(this.motionX, this.motionY, this.motionZ);
                this.motionX *= 0.5;
                this.motionY *= 0.5;
                this.motionZ *= 0.5;
                this.motionY -= 0.02;
                if (this.isCollidedHorizontally && this.isOffsetPositionInLiquid(this.motionX, this.motionY + 0.6F - this.posY + d1, this.motionZ)) {
                    this.motionY = 0.3F;
                }
            }
        } else {
            double d0 = this.posY;
            this.moveFlying(var1, var2, this.isAIEnabled() ? 0.04F : 0.02F);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.8F;
            this.motionY *= 0.8F;
            this.motionZ *= 0.8F;
            this.motionY -= 0.02;
            if (this.isCollidedHorizontally && this.isOffsetPositionInLiquid(this.motionX, this.motionY + 0.6F - this.posY + d0, this.motionZ)) {
                this.motionY = 0.3F;
            }
        }

        this.prevLimbSwingAmount = this.limbSwingAmount;
        double d2 = this.posX - this.prevPosX;
        double d3 = this.posZ - this.prevPosZ;
        float f4 = MathHelper.sqrt_double(d2 * d2 + d3 * d3) * 4.0F;
        if (f4 > 1.0F) {
            f4 = 1.0F;
        }

        this.limbSwingAmount = this.limbSwingAmount + (f4 - this.limbSwingAmount) * 0.4F;
        this.limbSwing = this.limbSwing + this.limbSwingAmount;
    }

    protected boolean isAIEnabled() {
        return false;
    }

    public float getAIMoveSpeed() {
        return this.isAIEnabled() ? this.landMovementFactor : 0.1F;
    }

    public void setAIMoveSpeed(float var1) {
        this.landMovementFactor = var1;
    }

    public boolean attackEntityAsMob(Entity var1) {
        this.setLastAttacker(var1);
        return false;
    }

    public boolean isPlayerSleeping() {
        return false;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (!this.worldObj.isRemote) {
            int i = this.getArrowCountInEntity();
            if (i > 0) {
                if (this.arrowHitTimer <= 0) {
                    this.arrowHitTimer = 20 * (30 - i);
                }

                this.arrowHitTimer--;
                if (this.arrowHitTimer <= 0) {
                    this.setArrowCountInEntity(i - 1);
                }
            }

            for (int j = 0; j < 5; j++) {
                ItemStack itemstack = this.previousEquipment[j];
                ItemStack itemstack1 = this.getEquipmentInSlot(j);
                if (!ItemStack.areItemStacksEqual(itemstack1, itemstack)) {
                    ((WorldServer)this.worldObj)
                        .getEntityTracker()
                        .sendToAllTrackingEntity(this, new S04PacketEntityEquipment(this.getEntityId(), j, itemstack1));
                    if (itemstack != null) {
                        this.attributeMap.removeAttributeModifiers(itemstack.getAttributeModifiers());
                    }

                    if (itemstack1 != null) {
                        this.attributeMap.applyAttributeModifiers(itemstack1.getAttributeModifiers());
                    }

                    this.previousEquipment[j] = itemstack1 == null ? null : itemstack1.copy();
                }
            }

            if (this.ticksExisted % 20 == 0) {
                this.getCombatTracker().func_94549_h();
            }
        }

        this.onLivingUpdate();
        double d0 = this.posX - this.prevPosX;
        double d1 = this.posZ - this.prevPosZ;
        float f = (float)(d0 * d0 + d1 * d1);
        float f1 = this.renderYawOffset;
        float f2 = 0.0F;
        this.field_70768_au = this.field_110154_aX;
        float f3 = 0.0F;
        if (f > 0.0025000002F) {
            f3 = 1.0F;
            f2 = (float)Math.sqrt(f) * 3.0F;
            f1 = (float)Math.atan2(d1, d0) * 180.0F / (float)Math.PI - 90.0F;
        }

        if (this.swingProgress > 0.0F) {
            f1 = this.rotationYaw;
        }

        if (!this.onGround) {
            f3 = 0.0F;
        }

        this.field_110154_aX = this.field_110154_aX + (f3 - this.field_110154_aX) * 0.3F;
        this.worldObj.theProfiler.startSection("headTurn");
        f2 = this.func_110146_f(f1, f2);
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("rangeChecks");

        while (this.rotationYaw - this.prevRotationYaw < -180.0F) {
            this.prevRotationYaw -= 360.0F;
        }

        while (this.rotationYaw - this.prevRotationYaw >= 180.0F) {
            this.prevRotationYaw += 360.0F;
        }

        while (this.renderYawOffset - this.prevRenderYawOffset < -180.0F) {
            this.prevRenderYawOffset -= 360.0F;
        }

        while (this.renderYawOffset - this.prevRenderYawOffset >= 180.0F) {
            this.prevRenderYawOffset += 360.0F;
        }

        while (this.rotationPitch - this.prevRotationPitch < -180.0F) {
            this.prevRotationPitch -= 360.0F;
        }

        while (this.rotationPitch - this.prevRotationPitch >= 180.0F) {
            this.prevRotationPitch += 360.0F;
        }

        while (this.rotationYawHead - this.prevRotationYawHead < -180.0F) {
            this.prevRotationYawHead -= 360.0F;
        }

        while (this.rotationYawHead - this.prevRotationYawHead >= 180.0F) {
            this.prevRotationYawHead += 360.0F;
        }

        this.worldObj.theProfiler.endSection();
        this.field_70764_aw += f2;
    }

    protected float func_110146_f(float var1, float var2) {
        float f = MathHelper.wrapAngleTo180_float(var1 - this.renderYawOffset);
        this.renderYawOffset += f * 0.3F;
        float f1 = MathHelper.wrapAngleTo180_float(this.rotationYaw - this.renderYawOffset);
        boolean flag = f1 < -90.0F || f1 >= 90.0F;
        if (f1 < -75.0F) {
            f1 = -75.0F;
        }

        if (f1 >= 75.0F) {
            f1 = 75.0F;
        }

        this.renderYawOffset = this.rotationYaw - f1;
        if (f1 * f1 > 2500.0F) {
            this.renderYawOffset += f1 * 0.2F;
        }

        if (flag) {
            var2 *= -1.0F;
        }

        return var2;
    }

    public void onLivingUpdate() {
        if (this.jumpTicks > 0) {
            this.jumpTicks--;
        }

        if (this.newPosRotationIncrements > 0) {
            double d0 = this.posX + (this.newPosX - this.posX) / this.newPosRotationIncrements;
            double d1 = this.posY + (this.newPosY - this.posY) / this.newPosRotationIncrements;
            double d2 = this.posZ + (this.newPosZ - this.posZ) / this.newPosRotationIncrements;
            double d3 = MathHelper.wrapAngleTo180_double(this.newRotationYaw - this.rotationYaw);
            this.rotationYaw = (float)(this.rotationYaw + d3 / this.newPosRotationIncrements);
            this.rotationPitch = (float)(this.rotationPitch + (this.newRotationPitch - this.rotationPitch) / this.newPosRotationIncrements);
            this.newPosRotationIncrements--;
            this.setPosition(d0, d1, d2);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        } else if (!this.isServerWorld()) {
            this.motionX *= 0.98;
            this.motionY *= 0.98;
            this.motionZ *= 0.98;
        }

        if (Math.abs(this.motionX) < 0.005) {
            this.motionX = 0.0;
        }

        if (Math.abs(this.motionY) < 0.005) {
            this.motionY = 0.0;
        }

        if (Math.abs(this.motionZ) < 0.005) {
            this.motionZ = 0.0;
        }

        this.worldObj.theProfiler.startSection("ai");
        if (this.isMovementBlocked()) {
            this.isJumping = false;
            this.moveStrafing = 0.0F;
            this.moveForward = 0.0F;
            this.randomYawVelocity = 0.0F;
        } else if (this.isServerWorld()) {
            if (this.isAIEnabled()) {
                this.worldObj.theProfiler.startSection("newAi");
                this.updateAITasks();
                this.worldObj.theProfiler.endSection();
            } else {
                this.worldObj.theProfiler.startSection("oldAi");
                this.updateEntityActionState();
                this.worldObj.theProfiler.endSection();
                this.rotationYawHead = this.rotationYaw;
            }
        }

        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("jump");
        if (this.isJumping) {
            if (this.isInWater() || this.handleLavaMovement()) {
                this.motionY += 0.04F;
            } else if (this.onGround && this.jumpTicks == 0) {
                this.jump();
                this.jumpTicks = 10;
            }
        } else {
            this.jumpTicks = 0;
        }

        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("travel");
        this.moveStrafing *= 0.98F;
        this.moveForward *= 0.98F;
        this.randomYawVelocity *= 0.9F;
        this.moveEntityWithHeading(this.moveStrafing, this.moveForward);
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("push");
        if (!this.worldObj.isRemote) {
            this.collideWithNearbyEntities();
        }

        this.worldObj.theProfiler.endSection();
    }

    protected void updateAITasks() {
    }

    protected void collideWithNearbyEntities() {
        List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.2F, 0.0, 0.2F));
        if (list != null && !list.isEmpty()) {
            for (int i = 0; i < list.size(); i++) {
                Entity entity = (Entity)list.get(i);
                if (entity.canBePushed()) {
                    this.collideWithEntity(entity);
                }
            }
        }
    }

    protected void collideWithEntity(Entity var1) {
        var1.applyEntityCollision(this);
    }

    @Override
    public void updateRidden() {
        super.updateRidden();
        this.field_70768_au = this.field_110154_aX;
        this.field_110154_aX = 0.0F;
        this.fallDistance = 0.0F;
    }

    @Override
    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9) {
        this.yOffset = 0.0F;
        this.newPosX = var1;
        this.newPosY = var3;
        this.newPosZ = var5;
        this.newRotationYaw = var7;
        this.newRotationPitch = var8;
        this.newPosRotationIncrements = var9;
    }

    protected void updateAITick() {
    }

    protected void updateEntityActionState() {
        this.entityAge++;
    }

    public void setJumping(boolean var1) {
        this.isJumping = var1;
    }

    public void onItemPickup(Entity var1, int var2) {
        if (!var1.isDead && !this.worldObj.isRemote) {
            EntityTracker entitytracker = ((WorldServer)this.worldObj).getEntityTracker();
            if (var1 instanceof EntityItem) {
                entitytracker.sendToAllTrackingEntity(var1, new S0DPacketCollectItem(var1.getEntityId(), this.getEntityId()));
            }

            if (var1 instanceof EntityArrow) {
                entitytracker.sendToAllTrackingEntity(var1, new S0DPacketCollectItem(var1.getEntityId(), this.getEntityId()));
            }

            if (var1 instanceof EntityXPOrb) {
                entitytracker.sendToAllTrackingEntity(var1, new S0DPacketCollectItem(var1.getEntityId(), this.getEntityId()));
            }
        }
    }

    public boolean canEntityBeSeen(Entity var1) {
        return this.worldObj
                .rayTraceBlocks(
                    Vec3.createVectorHelper(this.posX, this.posY + this.getEyeHeight(), this.posZ),
                    Vec3.createVectorHelper(var1.posX, var1.posY + var1.getEyeHeight(), var1.posZ)
                )
            == null;
    }

    @Override
    public Vec3 getLookVec() {
        return this.getLook(1.0F);
    }

    public Vec3 getLook(float var1) {
        if (var1 == 1.0F) {
            float f6 = MathHelper.cos(-this.rotationYaw * ((float)Math.PI / 180.0F) - (float)Math.PI);
            float f7 = MathHelper.sin(-this.rotationYaw * ((float)Math.PI / 180.0F) - (float)Math.PI);
            float f8 = -MathHelper.cos(-this.rotationPitch * ((float)Math.PI / 180.0F));
            float f9 = MathHelper.sin(-this.rotationPitch * ((float)Math.PI / 180.0F));
            return Vec3.createVectorHelper(f7 * f8, f9, f6 * f8);
        } else {
            float f = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * var1;
            float f1 = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * var1;
            float f2 = MathHelper.cos(-f1 * ((float)Math.PI / 180.0F) - (float)Math.PI);
            float f3 = MathHelper.sin(-f1 * ((float)Math.PI / 180.0F) - (float)Math.PI);
            float f4 = -MathHelper.cos(-f * ((float)Math.PI / 180.0F));
            float f5 = MathHelper.sin(-f * ((float)Math.PI / 180.0F));
            return Vec3.createVectorHelper(f3 * f4, f5, f2 * f4);
        }
    }

    public float getSwingProgress(float var1) {
        float f = this.swingProgress - this.prevSwingProgress;
        if (f < 0.0F) {
            f++;
        }

        return this.prevSwingProgress + f * var1;
    }

    public Vec3 getPosition(float var1) {
        if (var1 == 1.0F) {
            return Vec3.createVectorHelper(this.posX, this.posY, this.posZ);
        }

        double d0 = this.prevPosX + (this.posX - this.prevPosX) * var1;
        double d1 = this.prevPosY + (this.posY - this.prevPosY) * var1;
        double d2 = this.prevPosZ + (this.posZ - this.prevPosZ) * var1;
        return Vec3.createVectorHelper(d0, d1, d2);
    }

    public MovingObjectPosition rayTrace(double var1, float var3) {
        Vec3 vec3 = this.getPosition(var3);
        Vec3 vec31 = this.getLook(var3);
        Vec3 vec32 = vec3.addVector(vec31.xCoord * var1, vec31.yCoord * var1, vec31.zCoord * var1);
        return this.worldObj.rayTraceBlocks(vec3, vec32, false, false, true);
    }

    public boolean isServerWorld() {
        return !this.worldObj.isRemote;
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public boolean canBePushed() {
        return !this.isDead;
    }

    @Override
    public float getEyeHeight() {
        return this.height * 0.85F;
    }

    @Override
    protected void setBeenAttacked() {
        this.velocityChanged = this.rand.nextDouble() >= this.getEntityAttribute(SharedMonsterAttributes.knockbackResistance).getAttributeValue();
    }

    @Override
    public float getRotationYawHead() {
        return this.rotationYawHead;
    }

    @Override
    public void setRotationYawHead(float var1) {
        this.rotationYawHead = var1;
    }

    public float getAbsorptionAmount() {
        return this.field_110151_bq;
    }

    public void setAbsorptionAmount(float var1) {
        if (var1 < 0.0F) {
            var1 = 0.0F;
        }

        this.field_110151_bq = var1;
    }

    public Team getTeam() {
        return null;
    }

    public boolean isOnSameTeam(EntityLivingBase var1) {
        return this.isOnTeam(var1.getTeam());
    }

    public boolean isOnTeam(Team var1) {
        return this.getTeam() != null ? this.getTeam().isSameTeam(var1) : false;
    }

    public void func_152111_bt() {
    }

    public void func_152112_bu() {
    }
}
