package net.minecraft.entity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public abstract class EntityAgeable extends EntityCreature {
    private float field_98056_d = -1.0F;
    private float field_98057_e;

    public EntityAgeable(World var1) {
        super(var1);
    }

    public abstract EntityAgeable createChild(EntityAgeable var1);

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        if (itemstack != null && itemstack.getItem() == Items.spawn_egg) {
            if (!this.worldObj.isRemote) {
                Class oclass = EntityList.getClassFromID(itemstack.getMetadata());
                if (oclass != null && oclass.isAssignableFrom(this.getClass())) {
                    EntityAgeable entityageable = this.createChild(this);
                    if (entityageable != null) {
                        entityageable.setGrowingAge(-24000);
                        entityageable.setLocationAndAngles(this.posX, this.posY, this.posZ, 0.0F, 0.0F);
                        this.worldObj.spawnEntityInWorld(entityageable);
                        if (itemstack.hasDisplayName()) {
                            entityageable.setCustomNameTag(itemstack.getDisplayName());
                        }

                        if (!var1.capabilities.isCreativeMode) {
                            itemstack.stackSize--;
                            if (itemstack.stackSize <= 0) {
                                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
                            }
                        }
                    }
                }
            }

            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(12, new Integer(0));
    }

    public int getGrowingAge() {
        return this.dataWatcher.getWatchableObjectInt(12);
    }

    public void addGrowth(int var1) {
        int i = this.getGrowingAge();
        i += var1 * 20;
        if (i > 0) {
            i = 0;
        }

        this.setGrowingAge(i);
    }

    public void setGrowingAge(int var1) {
        this.dataWatcher.updateObject(12, var1);
        this.setScaleForAge(this.isChild());
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setInteger("Age", this.getGrowingAge());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.setGrowingAge(var1.getInteger("Age"));
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.worldObj.isRemote) {
            this.setScaleForAge(this.isChild());
        } else {
            int i = this.getGrowingAge();
            if (i < 0) {
                this.setGrowingAge(++i);
            } else if (i > 0) {
                this.setGrowingAge(--i);
            }
        }
    }

    @Override
    public boolean isChild() {
        return this.getGrowingAge() < 0;
    }

    public void setScaleForAge(boolean var1) {
        this.setScale(var1 ? 0.5F : 1.0F);
    }

    @Override
    protected final void setSize(float var1, float var2) {
        boolean flag = this.field_98056_d > 0.0F;
        this.field_98056_d = var1;
        this.field_98057_e = var2;
        if (!flag) {
            this.setScale(1.0F);
        }
    }

    protected final void setScale(float var1) {
        super.setSize(this.field_98056_d * var1, this.field_98057_e * var1);
    }
}
