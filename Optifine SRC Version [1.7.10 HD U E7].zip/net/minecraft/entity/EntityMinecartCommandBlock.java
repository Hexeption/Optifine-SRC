package net.minecraft.entity;

import io.netty.buffer.ByteBuf;
import net.minecraft.block.Block;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityMinecartCommandBlock extends EntityMinecart {
    private final CommandBlockLogic field_145824_a = new CommandBlockLogic() {
        @Override
        public void func_145756_e() {
            EntityMinecartCommandBlock.this.getDataWatcher().updateObject(23, this.getCustomName());
            EntityMinecartCommandBlock.this.getDataWatcher().updateObject(24, IChatComponent.Serializer.componentToJson(this.getLastOutput()));
        }

        @Override
        public int func_145751_f() {
            return 1;
        }

        @Override
        public void func_145757_a(ByteBuf var1) {
            var1.writeInt(EntityMinecartCommandBlock.this.getEntityId());
        }

        @Override
        public ChunkCoordinates getCommandSenderPosition() {
            return new ChunkCoordinates(
                MathHelper.floor_double(EntityMinecartCommandBlock.this.posX),
                MathHelper.floor_double(EntityMinecartCommandBlock.this.posY + 0.5),
                MathHelper.floor_double(EntityMinecartCommandBlock.this.posZ)
            );
        }

        @Override
        public World getEntityWorld() {
            return EntityMinecartCommandBlock.this.worldObj;
        }
    };
    private int field_145823_b = 0;

    public EntityMinecartCommandBlock(World var1) {
        super(var1);
    }

    public EntityMinecartCommandBlock(World var1, double var2, double var4, double var6) {
        super(var1, var2, var4, var6);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.getDataWatcher().addObject(23, "");
        this.getDataWatcher().addObject(24, "");
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.field_145824_a.readDataFromNBT(var1);
        this.getDataWatcher().updateObject(23, this.func_145822_e().getCustomName());
        this.getDataWatcher().updateObject(24, IChatComponent.Serializer.componentToJson(this.func_145822_e().getLastOutput()));
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        this.field_145824_a.writeDataToNBT(var1);
    }

    @Override
    public int getMinecartType() {
        return 6;
    }

    @Override
    public Block getDefaultDisplayTile() {
        return Blocks.command_block;
    }

    public CommandBlockLogic func_145822_e() {
        return this.field_145824_a;
    }

    @Override
    public void onActivatorRailPass(int var1, int var2, int var3, boolean var4) {
        if (var4 && this.ticksExisted - this.field_145823_b >= 4) {
            this.func_145822_e().func_145755_a(this.worldObj);
            this.field_145823_b = this.ticksExisted;
        }
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        if (this.worldObj.isRemote) {
            var1.func_146095_a(this.func_145822_e());
        }

        return super.interactFirst(var1);
    }

    @Override
    public void func_145781_i(int var1) {
        super.func_145781_i(var1);
        if (var1 == 24) {
            try {
                this.field_145824_a.func_145750_b(IChatComponent.Serializer.jsonToComponent(this.getDataWatcher().getWatchableObjectString(24)));
            } catch (Throwable throwable) {
            }
        } else if (var1 == 23) {
            this.field_145824_a.setCommand(this.getDataWatcher().getWatchableObjectString(23));
        }
    }
}
