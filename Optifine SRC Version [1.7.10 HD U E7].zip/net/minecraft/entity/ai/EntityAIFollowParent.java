package net.minecraft.entity.ai;

import java.util.List;
import net.minecraft.entity.passive.EntityAnimal;

public class EntityAIFollowParent extends EntityAIBase {
    EntityAnimal childAnimal;
    EntityAnimal parentAnimal;
    double field_75347_c;
    private int field_75345_d;

    public EntityAIFollowParent(EntityAnimal var1, double var2) {
        this.childAnimal = var1;
        this.field_75347_c = var2;
    }

    @Override
    public boolean shouldExecute() {
        if (this.childAnimal.getGrowingAge() >= 0) {
            return false;
        }

        List list = this.childAnimal.worldObj.getEntitiesWithinAABB(this.childAnimal.getClass(), this.childAnimal.boundingBox.expand(8.0, 4.0, 8.0));
        EntityAnimal entityanimal = null;
        double d0 = Double.MAX_VALUE;

        for (EntityAnimal entityanimal1 : (Iterable<EntityAnimal>) (Iterable) list) {
            if (entityanimal1.getGrowingAge() >= 0) {
                double d1 = this.childAnimal.getDistanceSqToEntity(entityanimal1);
                if (!(d1 > d0)) {
                    d0 = d1;
                    entityanimal = entityanimal1;
                }
            }
        }

        if (entityanimal == null) {
            return false;
        }

        if (d0 < 9.0) {
            return false;
        }

        this.parentAnimal = entityanimal;
        return true;
    }

    @Override
    public boolean continueExecuting() {
        if (!this.parentAnimal.isEntityAlive()) {
            return false;
        }

        double d0 = this.childAnimal.getDistanceSqToEntity(this.parentAnimal);
        return !(d0 < 9.0) && !(d0 > 256.0);
    }

    @Override
    public void startExecuting() {
        this.field_75345_d = 0;
    }

    @Override
    public void resetTask() {
        this.parentAnimal = null;
    }

    @Override
    public void updateTask() {
        if (--this.field_75345_d <= 0) {
            this.field_75345_d = 10;
            this.childAnimal.getNavigator().tryMoveToEntityLiving(this.parentAnimal, this.field_75347_c);
        }
    }
}
