package net.minecraft.entity.ai;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.MathHelper;

public class EntityMoveHelper {
    private EntityLiving entity;
    private double posX;
    private double posY;
    private double posZ;
    private double speed;
    private boolean update;

    public EntityMoveHelper(EntityLiving var1) {
        this.entity = var1;
        this.posX = var1.posX;
        this.posY = var1.posY;
        this.posZ = var1.posZ;
    }

    public boolean isUpdating() {
        return this.update;
    }

    public double getSpeed() {
        return this.speed;
    }

    public void setMoveTo(double var1, double var3, double var5, double var7) {
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        this.speed = var7;
        this.update = true;
    }

    public void onUpdateMoveHelper() {
        this.entity.setMoveForward(0.0F);
        if (this.update) {
            this.update = false;
            int i = MathHelper.floor_double(this.entity.boundingBox.minY + 0.5);
            double d0 = this.posX - this.entity.posX;
            double d1 = this.posZ - this.entity.posZ;
            double d2 = this.posY - i;
            double d3 = d0 * d0 + d2 * d2 + d1 * d1;
            if (!(d3 < 2.5000003E-7F)) {
                float f = (float)(Math.atan2(d1, d0) * 180.0 / (float)Math.PI) - 90.0F;
                this.entity.rotationYaw = this.limitAngle(this.entity.rotationYaw, f, 30.0F);
                this.entity.setAIMoveSpeed((float)(this.speed * this.entity.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue()));
                if (d2 > 0.0 && d0 * d0 + d1 * d1 < 1.0) {
                    this.entity.getJumpHelper().setJumping();
                }
            }
        }
    }

    private float limitAngle(float var1, float var2, float var3) {
        float f = MathHelper.wrapAngleTo180_float(var2 - var1);
        if (f > var3) {
            f = var3;
        }

        if (f < -var3) {
            f = -var3;
        }

        return var1 + f;
    }
}
