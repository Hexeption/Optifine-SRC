package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.util.MathHelper;
import net.minecraft.village.Village;
import net.minecraft.village.VillageDoorInfo;

public class EntityAIRestrictOpenDoor extends EntityAIBase {
    private EntityCreature entityObj;
    private VillageDoorInfo frontDoor;

    public EntityAIRestrictOpenDoor(EntityCreature var1) {
        this.entityObj = var1;
    }

    @Override
    public boolean shouldExecute() {
        if (this.entityObj.worldObj.isDaytime()) {
            return false;
        }

        Village village = this.entityObj
            .worldObj
            .villageCollectionObj
            .findNearestVillage(
                MathHelper.floor_double(this.entityObj.posX), MathHelper.floor_double(this.entityObj.posY), MathHelper.floor_double(this.entityObj.posZ), 16
            );
        if (village == null) {
            return false;
        }

        this.frontDoor = village.findNearestDoor(
            MathHelper.floor_double(this.entityObj.posX), MathHelper.floor_double(this.entityObj.posY), MathHelper.floor_double(this.entityObj.posZ)
        );
        return this.frontDoor == null
            ? false
            : this.frontDoor
                    .getInsideDistanceSquare(
                        MathHelper.floor_double(this.entityObj.posX),
                        MathHelper.floor_double(this.entityObj.posY),
                        MathHelper.floor_double(this.entityObj.posZ)
                    )
                < 2.25;
    }

    @Override
    public boolean continueExecuting() {
        return this.entityObj.worldObj.isDaytime()
            ? false
            : !this.frontDoor.isDetachedFromVillageFlag
                && this.frontDoor.isInside(MathHelper.floor_double(this.entityObj.posX), MathHelper.floor_double(this.entityObj.posZ));
    }

    @Override
    public void startExecuting() {
        this.entityObj.getNavigator().setBreakDoors(false);
        this.entityObj.getNavigator().setEnterDoors(false);
    }

    @Override
    public void resetTask() {
        this.entityObj.getNavigator().setBreakDoors(true);
        this.entityObj.getNavigator().setEnterDoors(true);
        this.frontDoor = null;
    }

    @Override
    public void updateTask() {
        this.frontDoor.incrementDoorOpeningRestrictionCounter();
    }
}
