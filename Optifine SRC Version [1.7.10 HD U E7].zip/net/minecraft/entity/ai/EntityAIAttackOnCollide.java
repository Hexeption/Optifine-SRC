package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityAIAttackOnCollide extends EntityAIBase {
    World worldObj;
    EntityCreature attacker;
    int attackTick;
    double speedTowardsTarget;
    boolean longMemory;
    PathEntity entityPathEntity;
    Class classTarget;
    private int field_75445_i;
    private double field_151497_i;
    private double field_151495_j;
    private double field_151496_k;

    public EntityAIAttackOnCollide(EntityCreature var1, Class var2, double var3, boolean var5) {
        this(var1, var3, var5);
        this.classTarget = var2;
    }

    public EntityAIAttackOnCollide(EntityCreature var1, double var2, boolean var4) {
        this.attacker = var1;
        this.worldObj = var1.worldObj;
        this.speedTowardsTarget = var2;
        this.longMemory = var4;
        this.setMutexBits(3);
    }

    @Override
    public boolean shouldExecute() {
        EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
        if (entitylivingbase == null) {
            return false;
        }

        if (!entitylivingbase.isEntityAlive()) {
            return false;
        }

        if (this.classTarget != null && !this.classTarget.isAssignableFrom(entitylivingbase.getClass())) {
            return false;
        }

        this.entityPathEntity = this.attacker.getNavigator().getPathToEntityLiving(entitylivingbase);
        return this.entityPathEntity != null;
    }

    @Override
    public boolean continueExecuting() {
        EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
        if (entitylivingbase == null) {
            return false;
        } else if (!entitylivingbase.isEntityAlive()) {
            return false;
        } else {
            return !this.longMemory
                ? !this.attacker.getNavigator().noPath()
                : this.attacker
                    .isWithinHomeDistance(
                        MathHelper.floor_double(entitylivingbase.posX),
                        MathHelper.floor_double(entitylivingbase.posY),
                        MathHelper.floor_double(entitylivingbase.posZ)
                    );
        }
    }

    @Override
    public void startExecuting() {
        this.attacker.getNavigator().setPath(this.entityPathEntity, this.speedTowardsTarget);
        this.field_75445_i = 0;
    }

    @Override
    public void resetTask() {
        this.attacker.getNavigator().clearPathEntity();
    }

    @Override
    public void updateTask() {
        EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
        this.attacker.getLookHelper().setLookPositionWithEntity(entitylivingbase, 30.0F, 30.0F);
        double d0 = this.attacker.getDistanceSq(entitylivingbase.posX, entitylivingbase.boundingBox.minY, entitylivingbase.posZ);
        double d1 = this.attacker.width * 2.0F * (this.attacker.width * 2.0F) + entitylivingbase.width;
        this.field_75445_i--;
        if ((this.longMemory || this.attacker.getEntitySenses().canSee(entitylivingbase))
            && this.field_75445_i <= 0
            && (
                this.field_151497_i == 0.0 && this.field_151495_j == 0.0 && this.field_151496_k == 0.0
                    || entitylivingbase.getDistanceSq(this.field_151497_i, this.field_151495_j, this.field_151496_k) >= 1.0
                    || this.attacker.getRNG().nextFloat() < 0.05F
            )) {
            this.field_151497_i = entitylivingbase.posX;
            this.field_151495_j = entitylivingbase.boundingBox.minY;
            this.field_151496_k = entitylivingbase.posZ;
            this.field_75445_i = 4 + this.attacker.getRNG().nextInt(7);
            if (d0 > 1024.0) {
                this.field_75445_i += 10;
            } else if (d0 > 256.0) {
                this.field_75445_i += 5;
            }

            if (!this.attacker.getNavigator().tryMoveToEntityLiving(entitylivingbase, this.speedTowardsTarget)) {
                this.field_75445_i += 15;
            }
        }

        this.attackTick = Math.max(this.attackTick - 1, 0);
        if (d0 <= d1 && this.attackTick <= 20) {
            this.attackTick = 20;
            if (this.attacker.getHeldItem() != null) {
                this.attacker.swingItem();
            }

            this.attacker.attackEntityAsMob(entitylivingbase);
        }
    }
}
