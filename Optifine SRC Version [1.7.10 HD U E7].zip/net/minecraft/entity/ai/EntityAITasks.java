package net.minecraft.entity.ai;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.profiler.Profiler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityAITasks {
    private static final Logger logger = LogManager.getLogger();
    private List taskEntries = new ArrayList();
    private List executingTaskEntries = new ArrayList();
    private final Profiler theProfiler;
    private int tickCount;
    private int tickRate = 3;

    public EntityAITasks(Profiler var1) {
        this.theProfiler = var1;
    }

    public void addTask(int var1, EntityAIBase var2) {
        this.taskEntries.add(new EntityAITasks.EntityAITaskEntry(var1, var2));
    }

    public void removeTask(EntityAIBase var1) {
        Iterator iterator = this.taskEntries.iterator();

        while (iterator.hasNext()) {
            EntityAITasks.EntityAITaskEntry entityaitasks$entityaitaskentry = (EntityAITasks.EntityAITaskEntry)iterator.next();
            EntityAIBase entityaibase = entityaitasks$entityaitaskentry.action;
            if (entityaibase == var1) {
                if (this.executingTaskEntries.contains(entityaitasks$entityaitaskentry)) {
                    entityaibase.resetTask();
                    this.executingTaskEntries.remove(entityaitasks$entityaitaskentry);
                }

                iterator.remove();
            }
        }
    }

    public void onUpdateTasks() {
        ArrayList arraylist = new ArrayList();
        if (this.tickCount++ % this.tickRate == 0) {
            for (EntityAITasks.EntityAITaskEntry entityaitasks$entityaitaskentry : (Iterable<EntityAITasks.EntityAITaskEntry>) (Iterable) this.taskEntries) {
                boolean flag = this.executingTaskEntries.contains(entityaitasks$entityaitaskentry);
                if (flag) {
                    if (this.canUse(entityaitasks$entityaitaskentry) && this.canContinue(entityaitasks$entityaitaskentry)) {
                        continue;
                    }

                    entityaitasks$entityaitaskentry.action.resetTask();
                    this.executingTaskEntries.remove(entityaitasks$entityaitaskentry);
                }

                if (this.canUse(entityaitasks$entityaitaskentry) && entityaitasks$entityaitaskentry.action.shouldExecute()) {
                    arraylist.add(entityaitasks$entityaitaskentry);
                    this.executingTaskEntries.add(entityaitasks$entityaitaskentry);
                }
            }
        } else {
            Iterator iterator = this.executingTaskEntries.iterator();

            while (iterator.hasNext()) {
                EntityAITasks.EntityAITaskEntry entityaitasks$entityaitaskentry1 = (EntityAITasks.EntityAITaskEntry)iterator.next();
                if (!entityaitasks$entityaitaskentry1.action.continueExecuting()) {
                    entityaitasks$entityaitaskentry1.action.resetTask();
                    iterator.remove();
                }
            }
        }

        this.theProfiler.startSection("goalStart");

        for (EntityAITasks.EntityAITaskEntry entityaitasks$entityaitaskentry2 : (Iterable<EntityAITasks.EntityAITaskEntry>) (Iterable) arraylist) {
            this.theProfiler.startSection(entityaitasks$entityaitaskentry2.action.getClass().getSimpleName());
            entityaitasks$entityaitaskentry2.action.startExecuting();
            this.theProfiler.endSection();
        }

        this.theProfiler.endSection();
        this.theProfiler.startSection("goalTick");

        for (EntityAITasks.EntityAITaskEntry entityaitasks$entityaitaskentry3 : (Iterable<EntityAITasks.EntityAITaskEntry>) (Iterable) this.executingTaskEntries) {
            entityaitasks$entityaitaskentry3.action.updateTask();
        }

        this.theProfiler.endSection();
    }

    private boolean canContinue(EntityAITasks.EntityAITaskEntry var1) {
        this.theProfiler.startSection("canContinue");
        boolean flag = var1.action.continueExecuting();
        this.theProfiler.endSection();
        return flag;
    }

    private boolean canUse(EntityAITasks.EntityAITaskEntry var1) {
        this.theProfiler.startSection("canUse");

        for (EntityAITasks.EntityAITaskEntry entityaitasks$entityaitaskentry : (Iterable<EntityAITasks.EntityAITaskEntry>) (Iterable) this.taskEntries) {
            if (entityaitasks$entityaitaskentry != var1) {
                if (var1.priority >= entityaitasks$entityaitaskentry.priority) {
                    if (this.executingTaskEntries.contains(entityaitasks$entityaitaskentry) && !this.areTasksCompatible(var1, entityaitasks$entityaitaskentry)) {
                        this.theProfiler.endSection();
                        return false;
                    }
                } else if (this.executingTaskEntries.contains(entityaitasks$entityaitaskentry) && !entityaitasks$entityaitaskentry.action.isInterruptible()) {
                    this.theProfiler.endSection();
                    return false;
                }
            }
        }

        this.theProfiler.endSection();
        return true;
    }

    private boolean areTasksCompatible(EntityAITasks.EntityAITaskEntry var1, EntityAITasks.EntityAITaskEntry var2) {
        return (var1.action.getMutexBits() & var2.action.getMutexBits()) == 0;
    }

    class EntityAITaskEntry {
        public EntityAIBase action;
        public int priority;

        public EntityAITaskEntry(int var2, EntityAIBase var3) {
            this.priority = var2;
            this.action = var3;
        }
    }
}
