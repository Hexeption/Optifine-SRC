package net.minecraft.entity.ai;

import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.MobSpawnerBaseLogic;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityMinecartMobSpawner extends EntityMinecart {
    private final MobSpawnerBaseLogic mobSpawnerLogic = new MobSpawnerBaseLogic() {
        @Override
        public void func_98267_a(int var1) {
            EntityMinecartMobSpawner.this.worldObj.setEntityState(EntityMinecartMobSpawner.this, (byte)var1);
        }

        @Override
        public World getSpawnerWorld() {
            return EntityMinecartMobSpawner.this.worldObj;
        }

        @Override
        public int getSpawnerX() {
            return MathHelper.floor_double(EntityMinecartMobSpawner.this.posX);
        }

        @Override
        public int getSpawnerY() {
            return MathHelper.floor_double(EntityMinecartMobSpawner.this.posY);
        }

        @Override
        public int getSpawnerZ() {
            return MathHelper.floor_double(EntityMinecartMobSpawner.this.posZ);
        }
    };

    public EntityMinecartMobSpawner(World var1) {
        super(var1);
    }

    public EntityMinecartMobSpawner(World var1, double var2, double var4, double var6) {
        super(var1, var2, var4, var6);
    }

    @Override
    public int getMinecartType() {
        return 4;
    }

    @Override
    public Block getDefaultDisplayTile() {
        return Blocks.mob_spawner;
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.mobSpawnerLogic.readFromNBT(var1);
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        this.mobSpawnerLogic.writeToNBT(var1);
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        this.mobSpawnerLogic.setDelayToMin(var1);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        this.mobSpawnerLogic.updateSpawner();
    }

    public MobSpawnerBaseLogic func_98039_d() {
        return this.mobSpawnerLogic;
    }
}
