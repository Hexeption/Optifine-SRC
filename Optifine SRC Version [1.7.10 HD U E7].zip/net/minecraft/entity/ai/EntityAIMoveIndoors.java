package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.village.Village;
import net.minecraft.village.VillageDoorInfo;

public class EntityAIMoveIndoors extends EntityAIBase {
    private EntityCreature entityObj;
    private VillageDoorInfo doorInfo;
    private int insidePosX = -1;
    private int insidePosZ = -1;

    public EntityAIMoveIndoors(EntityCreature var1) {
        this.entityObj = var1;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        int i = MathHelper.floor_double(this.entityObj.posX);
        int j = MathHelper.floor_double(this.entityObj.posY);
        int k = MathHelper.floor_double(this.entityObj.posZ);
        if ((
                !this.entityObj.worldObj.isDaytime()
                    || this.entityObj.worldObj.isRaining()
                    || !this.entityObj.worldObj.getBiomeGenForCoords(i, k).canSpawnLightningBolt()
            )
            && !this.entityObj.worldObj.provider.hasNoSky) {
            if (this.entityObj.getRNG().nextInt(50) != 0) {
                return false;
            }

            if (this.insidePosX != -1 && this.entityObj.getDistanceSq(this.insidePosX, this.entityObj.posY, this.insidePosZ) < 4.0) {
                return false;
            }

            Village village = this.entityObj.worldObj.villageCollectionObj.findNearestVillage(i, j, k, 14);
            if (village == null) {
                return false;
            }

            this.doorInfo = village.findNearestDoorUnrestricted(i, j, k);
            return this.doorInfo != null;
        } else {
            return false;
        }
    }

    @Override
    public boolean continueExecuting() {
        return !this.entityObj.getNavigator().noPath();
    }

    @Override
    public void startExecuting() {
        this.insidePosX = -1;
        if (this.entityObj.getDistanceSq(this.doorInfo.getInsidePosX(), this.doorInfo.posY, this.doorInfo.getInsidePosZ()) > 256.0) {
            Vec3 vec3 = RandomPositionGenerator.findRandomTargetBlockTowards(
                this.entityObj,
                14,
                3,
                Vec3.createVectorHelper(this.doorInfo.getInsidePosX() + 0.5, this.doorInfo.getInsidePosY(), this.doorInfo.getInsidePosZ() + 0.5)
            );
            if (vec3 != null) {
                this.entityObj.getNavigator().tryMoveToXYZ(vec3.xCoord, vec3.yCoord, vec3.zCoord, 1.0);
            }
        } else {
            this.entityObj
                .getNavigator()
                .tryMoveToXYZ(this.doorInfo.getInsidePosX() + 0.5, this.doorInfo.getInsidePosY(), this.doorInfo.getInsidePosZ() + 0.5, 1.0);
        }
    }

    @Override
    public void resetTask() {
        this.insidePosX = this.doorInfo.getInsidePosX();
        this.insidePosZ = this.doorInfo.getInsidePosZ();
        this.doorInfo = null;
    }
}
