package net.minecraft.entity.ai;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.world.World;

public class EntityAIOcelotSit extends EntityAIBase {
    private final EntityOcelot field_151493_a;
    private final double field_151491_b;
    private int field_151492_c;
    private int field_151489_d;
    private int field_151490_e;
    private int field_151487_f;
    private int field_151488_g;
    private int field_151494_h;

    public EntityAIOcelotSit(EntityOcelot var1, double var2) {
        this.field_151493_a = var1;
        this.field_151491_b = var2;
        this.setMutexBits(5);
    }

    @Override
    public boolean shouldExecute() {
        return this.field_151493_a.isTamed()
            && !this.field_151493_a.isSitting()
            && this.field_151493_a.getRNG().nextDouble() <= 0.0065F
            && this.func_151485_f();
    }

    @Override
    public boolean continueExecuting() {
        return this.field_151492_c <= this.field_151490_e
            && this.field_151489_d <= 60
            && this.func_151486_a(this.field_151493_a.worldObj, this.field_151487_f, this.field_151488_g, this.field_151494_h);
    }

    @Override
    public void startExecuting() {
        this.field_151493_a.getNavigator().tryMoveToXYZ(this.field_151487_f + 0.5, this.field_151488_g + 1, this.field_151494_h + 0.5, this.field_151491_b);
        this.field_151492_c = 0;
        this.field_151489_d = 0;
        this.field_151490_e = this.field_151493_a.getRNG().nextInt(this.field_151493_a.getRNG().nextInt(1200) + 1200) + 1200;
        this.field_151493_a.getAISit().setSitting(false);
    }

    @Override
    public void resetTask() {
        this.field_151493_a.setSitting(false);
    }

    @Override
    public void updateTask() {
        this.field_151492_c++;
        this.field_151493_a.getAISit().setSitting(false);
        if (this.field_151493_a.getDistanceSq(this.field_151487_f, this.field_151488_g + 1, this.field_151494_h) > 1.0) {
            this.field_151493_a.setSitting(false);
            this.field_151493_a.getNavigator().tryMoveToXYZ(this.field_151487_f + 0.5, this.field_151488_g + 1, this.field_151494_h + 0.5, this.field_151491_b);
            this.field_151489_d++;
        } else if (!this.field_151493_a.isSitting()) {
            this.field_151493_a.setSitting(true);
        } else {
            this.field_151489_d--;
        }
    }

    private boolean func_151485_f() {
        int i = (int)this.field_151493_a.posY;
        double d0 = Integer.MAX_VALUE;

        for (int j = (int)this.field_151493_a.posX - 8; j < this.field_151493_a.posX + 8.0; j++) {
            for (int k = (int)this.field_151493_a.posZ - 8; k < this.field_151493_a.posZ + 8.0; k++) {
                if (this.func_151486_a(this.field_151493_a.worldObj, j, i, k) && this.field_151493_a.worldObj.isAirBlock(j, i + 1, k)) {
                    double d1 = this.field_151493_a.getDistanceSq(j, i, k);
                    if (d1 < d0) {
                        this.field_151487_f = j;
                        this.field_151488_g = i;
                        this.field_151494_h = k;
                        d0 = d1;
                    }
                }
            }
        }

        return d0 < Integer.MAX_VALUE;
    }

    private boolean func_151486_a(World var1, int var2, int var3, int var4) {
        Block block = var1.getBlock(var2, var3, var4);
        int i = var1.getBlockMetadata(var2, var3, var4);
        if (block == Blocks.chest) {
            TileEntityChest tileentitychest = (TileEntityChest)var1.getTileEntity(var2, var3, var4);
            if (tileentitychest.numPlayersUsing < 1) {
                return true;
            }
        } else {
            if (block == Blocks.lit_furnace) {
                return true;
            }

            if (block == Blocks.bed && !BlockBed.isBlockHeadOfBed(i)) {
                return true;
            }
        }

        return false;
    }
}
