package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.Vec3;

public class EntityAIMoveTowardsRestriction extends EntityAIBase {
    private EntityCreature theEntity;
    private double movePosX;
    private double movePosY;
    private double movePosZ;
    private double movementSpeed;

    public EntityAIMoveTowardsRestriction(EntityCreature var1, double var2) {
        this.theEntity = var1;
        this.movementSpeed = var2;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        if (this.theEntity.isWithinHomeDistanceCurrentPosition()) {
            return false;
        }

        ChunkCoordinates chunkcoordinates = this.theEntity.getHomePosition();
        Vec3 vec3 = RandomPositionGenerator.findRandomTargetBlockTowards(
            this.theEntity, 16, 7, Vec3.createVectorHelper(chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ)
        );
        if (vec3 == null) {
            return false;
        }

        this.movePosX = vec3.xCoord;
        this.movePosY = vec3.yCoord;
        this.movePosZ = vec3.zCoord;
        return true;
    }

    @Override
    public boolean continueExecuting() {
        return !this.theEntity.getNavigator().noPath();
    }

    @Override
    public void startExecuting() {
        this.theEntity.getNavigator().tryMoveToXYZ(this.movePosX, this.movePosY, this.movePosZ, this.movementSpeed);
    }
}
