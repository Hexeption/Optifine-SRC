package net.minecraft.entity.ai;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.entity.EntityLiving;
import net.minecraft.init.Blocks;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.MathHelper;

public abstract class EntityAIDoorInteract extends EntityAIBase {
    protected EntityLiving theEntity;
    protected int entityPosX;
    protected int entityPosY;
    protected int entityPosZ;
    protected BlockDoor doorBlock;
    boolean hasStoppedDoorInteraction;
    float entityPositionX;
    float entityPositionZ;

    public EntityAIDoorInteract(EntityLiving var1) {
        this.theEntity = var1;
    }

    @Override
    public boolean shouldExecute() {
        if (!this.theEntity.isCollidedHorizontally) {
            return false;
        }

        PathNavigate pathnavigate = this.theEntity.getNavigator();
        PathEntity pathentity = pathnavigate.getPath();
        if (pathentity != null && !pathentity.isFinished() && pathnavigate.getCanBreakDoors()) {
            for (int i = 0; i < Math.min(pathentity.getCurrentPathIndex() + 2, pathentity.getCurrentPathLength()); i++) {
                PathPoint pathpoint = pathentity.getPathPointFromIndex(i);
                this.entityPosX = pathpoint.xCoord;
                this.entityPosY = pathpoint.yCoord + 1;
                this.entityPosZ = pathpoint.zCoord;
                if (!(this.theEntity.getDistanceSq(this.entityPosX, this.theEntity.posY, this.entityPosZ) > 2.25)) {
                    this.doorBlock = this.getWoodenDoorBlock(this.entityPosX, this.entityPosY, this.entityPosZ);
                    if (this.doorBlock != null) {
                        return true;
                    }
                }
            }

            this.entityPosX = MathHelper.floor_double(this.theEntity.posX);
            this.entityPosY = MathHelper.floor_double(this.theEntity.posY + 1.0);
            this.entityPosZ = MathHelper.floor_double(this.theEntity.posZ);
            this.doorBlock = this.getWoodenDoorBlock(this.entityPosX, this.entityPosY, this.entityPosZ);
            return this.doorBlock != null;
        } else {
            return false;
        }
    }

    @Override
    public boolean continueExecuting() {
        return !this.hasStoppedDoorInteraction;
    }

    @Override
    public void startExecuting() {
        this.hasStoppedDoorInteraction = false;
        this.entityPositionX = (float)(this.entityPosX + 0.5F - this.theEntity.posX);
        this.entityPositionZ = (float)(this.entityPosZ + 0.5F - this.theEntity.posZ);
    }

    @Override
    public void updateTask() {
        float f = (float)(this.entityPosX + 0.5F - this.theEntity.posX);
        float f1 = (float)(this.entityPosZ + 0.5F - this.theEntity.posZ);
        float f2 = this.entityPositionX * f + this.entityPositionZ * f1;
        if (f2 < 0.0F) {
            this.hasStoppedDoorInteraction = true;
        }
    }

    private BlockDoor getWoodenDoorBlock(int var1, int var2, int var3) {
        Block block = this.theEntity.worldObj.getBlock(var1, var2, var3);
        return block != Blocks.wooden_door ? null : (BlockDoor)block;
    }
}
