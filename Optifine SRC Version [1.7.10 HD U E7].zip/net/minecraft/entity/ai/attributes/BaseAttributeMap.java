package net.minecraft.entity.ai.attributes;

import com.google.common.collect.Multimap;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.server.management.LowerStringMap;

public abstract class BaseAttributeMap {
    protected final Map attributes = new HashMap();
    protected final Map attributesByName = new LowerStringMap();

    public IAttributeInstance getAttributeInstance(IAttribute var1) {
        return (IAttributeInstance)this.attributes.get(var1);
    }

    public IAttributeInstance getAttributeInstanceByName(String var1) {
        return (IAttributeInstance)this.attributesByName.get(var1);
    }

    public abstract IAttributeInstance registerAttribute(IAttribute var1);

    public Collection getAllAttributes() {
        return this.attributesByName.values();
    }

    public void addAttributeInstance(ModifiableAttributeInstance var1) {
    }

    public void removeAttributeModifiers(Multimap var1) {
        for (Entry entry : (Iterable<Entry>) (Iterable) var1.entries()) {
            IAttributeInstance iattributeinstance = this.getAttributeInstanceByName((String)entry.getKey());
            if (iattributeinstance != null) {
                iattributeinstance.removeModifier((AttributeModifier)entry.getValue());
            }
        }
    }

    public void applyAttributeModifiers(Multimap var1) {
        for (Entry entry : (Iterable<Entry>) (Iterable) var1.entries()) {
            IAttributeInstance iattributeinstance = this.getAttributeInstanceByName((String)entry.getKey());
            if (iattributeinstance != null) {
                iattributeinstance.removeModifier((AttributeModifier)entry.getValue());
                iattributeinstance.applyModifier((AttributeModifier)entry.getValue());
            }
        }
    }
}
