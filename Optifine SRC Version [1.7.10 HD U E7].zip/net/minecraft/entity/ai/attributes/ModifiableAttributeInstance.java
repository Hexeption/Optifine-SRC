package net.minecraft.entity.ai.attributes;

import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class ModifiableAttributeInstance implements IAttributeInstance {
    private final BaseAttributeMap attributeMap;
    private final IAttribute genericAttribute;
    private final Map mapByOperation = Maps.newHashMap();
    private final Map mapByName = Maps.newHashMap();
    private final Map mapByUUID = Maps.newHashMap();
    private double baseValue;
    private boolean needsUpdate = true;
    private double cachedValue;

    public ModifiableAttributeInstance(BaseAttributeMap var1, IAttribute var2) {
        this.attributeMap = var1;
        this.genericAttribute = var2;
        this.baseValue = var2.getDefaultValue();

        for (int i = 0; i < 3; i++) {
            this.mapByOperation.put(i, new HashSet());
        }
    }

    @Override
    public IAttribute getAttribute() {
        return this.genericAttribute;
    }

    @Override
    public double getBaseValue() {
        return this.baseValue;
    }

    @Override
    public void setBaseValue(double var1) {
        if (var1 != this.getBaseValue()) {
            this.baseValue = var1;
            this.flagForUpdate();
        }
    }

    public Collection getModifiersByOperation(int var1) {
        return (Collection)this.mapByOperation.get(var1);
    }

    @Override
    public Collection func_111122_c() {
        HashSet hashset = new HashSet();

        for (int i = 0; i < 3; i++) {
            hashset.addAll(this.getModifiersByOperation(i));
        }

        return hashset;
    }

    @Override
    public AttributeModifier getModifier(UUID var1) {
        return (AttributeModifier)this.mapByUUID.get(var1);
    }

    @Override
    public void applyModifier(AttributeModifier var1) {
        if (this.getModifier(var1.getID()) != null) {
            throw new IllegalArgumentException("Modifier is already applied on this attribute!");
        }

        Set set = (Set)this.mapByName.get(var1.getName());
        if (set == null) {
            set = new HashSet();
            this.mapByName.put(var1.getName(), set);
        }

        ((Set)this.mapByOperation.get(var1.getOperation())).add(var1);
        set.add(var1);
        this.mapByUUID.put(var1.getID(), var1);
        this.flagForUpdate();
    }

    private void flagForUpdate() {
        this.needsUpdate = true;
        this.attributeMap.addAttributeInstance(this);
    }

    @Override
    public void removeModifier(AttributeModifier var1) {
        for (int i = 0; i < 3; i++) {
            Set set = (Set)this.mapByOperation.get(i);
            set.remove(var1);
        }

        Set set1 = (Set)this.mapByName.get(var1.getName());
        if (set1 != null) {
            set1.remove(var1);
            if (set1.isEmpty()) {
                this.mapByName.remove(var1.getName());
            }
        }

        this.mapByUUID.remove(var1.getID());
        this.flagForUpdate();
    }

    @Override
    public void removeAllModifiers() {
        Collection collection = this.func_111122_c();
        if (collection != null) {
            for (AttributeModifier attributemodifier : (Iterable<AttributeModifier>) (Iterable) new ArrayList(collection)) {
                this.removeModifier(attributemodifier);
            }
        }
    }

    @Override
    public double getAttributeValue() {
        if (this.needsUpdate) {
            this.cachedValue = this.computeValue();
            this.needsUpdate = false;
        }

        return this.cachedValue;
    }

    private double computeValue() {
        double d0 = this.getBaseValue();

        for (AttributeModifier attributemodifier : (Iterable<AttributeModifier>) (Iterable) this.getModifiersByOperation(0)) {
            d0 += attributemodifier.getAmount();
        }

        double d1 = d0;

        for (AttributeModifier attributemodifier1 : (Iterable<AttributeModifier>) (Iterable) this.getModifiersByOperation(1)) {
            d1 += d0 * attributemodifier1.getAmount();
        }

        for (AttributeModifier attributemodifier2 : (Iterable<AttributeModifier>) (Iterable) this.getModifiersByOperation(2)) {
            d1 *= 1.0 + attributemodifier2.getAmount();
        }

        return this.genericAttribute.clampValue(d1);
    }
}
