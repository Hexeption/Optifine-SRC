package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;

public class EntityAIRestrictSun extends EntityAIBase {
    private EntityCreature theEntity;

    public EntityAIRestrictSun(EntityCreature var1) {
        this.theEntity = var1;
    }

    @Override
    public boolean shouldExecute() {
        return this.theEntity.worldObj.isDaytime();
    }

    @Override
    public void startExecuting() {
        this.theEntity.getNavigator().setAvoidSun(true);
    }

    @Override
    public void resetTask() {
        this.theEntity.getNavigator().setAvoidSun(false);
    }
}
