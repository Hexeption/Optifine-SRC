package net.minecraft.entity.ai;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityAIFollowOwner extends EntityAIBase {
    private EntityTameable thePet;
    private EntityLivingBase theOwner;
    World theWorld;
    private double field_75336_f;
    private PathNavigate petPathfinder;
    private int field_75343_h;
    float maxDist;
    float minDist;
    private boolean field_75344_i;

    public EntityAIFollowOwner(EntityTameable var1, double var2, float var4, float var5) {
        this.thePet = var1;
        this.theWorld = var1.worldObj;
        this.field_75336_f = var2;
        this.petPathfinder = var1.getNavigator();
        this.minDist = var4;
        this.maxDist = var5;
        this.setMutexBits(3);
    }

    @Override
    public boolean shouldExecute() {
        EntityLivingBase entitylivingbase = this.thePet.getOwner();
        if (entitylivingbase == null) {
            return false;
        }

        if (this.thePet.isSitting()) {
            return false;
        }

        if (this.thePet.getDistanceSqToEntity(entitylivingbase) < this.minDist * this.minDist) {
            return false;
        }

        this.theOwner = entitylivingbase;
        return true;
    }

    @Override
    public boolean continueExecuting() {
        return !this.petPathfinder.noPath() && this.thePet.getDistanceSqToEntity(this.theOwner) > this.maxDist * this.maxDist && !this.thePet.isSitting();
    }

    @Override
    public void startExecuting() {
        this.field_75343_h = 0;
        this.field_75344_i = this.thePet.getNavigator().getAvoidsWater();
        this.thePet.getNavigator().setAvoidsWater(false);
    }

    @Override
    public void resetTask() {
        this.theOwner = null;
        this.petPathfinder.clearPathEntity();
        this.thePet.getNavigator().setAvoidsWater(this.field_75344_i);
    }

    @Override
    public void updateTask() {
        this.thePet.getLookHelper().setLookPositionWithEntity(this.theOwner, 10.0F, this.thePet.getVerticalFaceSpeed());
        if (!this.thePet.isSitting()) {
            if (--this.field_75343_h <= 0) {
                this.field_75343_h = 10;
                if (!this.petPathfinder.tryMoveToEntityLiving(this.theOwner, this.field_75336_f)) {
                    if (!this.thePet.getLeashed()) {
                        if (!(this.thePet.getDistanceSqToEntity(this.theOwner) < 144.0)) {
                            int i = MathHelper.floor_double(this.theOwner.posX) - 2;
                            int j = MathHelper.floor_double(this.theOwner.posZ) - 2;
                            int k = MathHelper.floor_double(this.theOwner.boundingBox.minY);

                            for (int l = 0; l <= 4; l++) {
                                for (int i1 = 0; i1 <= 4; i1++) {
                                    if ((l < 1 || i1 < 1 || l > 3 || i1 > 3)
                                        && World.doesBlockHaveSolidTopSurface(this.theWorld, i + l, k - 1, j + i1)
                                        && !this.theWorld.getBlock(i + l, k, j + i1).isNormalCube()
                                        && !this.theWorld.getBlock(i + l, k + 1, j + i1).isNormalCube()) {
                                        this.thePet.setLocationAndAngles(i + l + 0.5F, k, j + i1 + 0.5F, this.thePet.rotationYaw, this.thePet.rotationPitch);
                                        this.petPathfinder.clearPathEntity();
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
