package net.minecraft.entity.ai;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;

public class EntityAINearestAttackableTarget extends EntityAITarget {
    private final Class targetClass;
    private final int targetChance;
    private final EntityAINearestAttackableTarget.Sorter theNearestAttackableTargetSorter;
    private final IEntitySelector targetEntitySelector;
    private EntityLivingBase targetEntity;

    public EntityAINearestAttackableTarget(EntityCreature var1, Class var2, int var3, boolean var4) {
        this(var1, var2, var3, var4, false);
    }

    public EntityAINearestAttackableTarget(EntityCreature var1, Class var2, int var3, boolean var4, boolean var5) {
        this(var1, var2, var3, var4, var5, null);
    }

    public EntityAINearestAttackableTarget(EntityCreature var1, Class var2, int var3, boolean var4, boolean var5, final IEntitySelector var6) {
        super(var1, var4, var5);
        this.targetClass = var2;
        this.targetChance = var3;
        this.theNearestAttackableTargetSorter = new EntityAINearestAttackableTarget.Sorter(var1);
        this.setMutexBits(1);
        this.targetEntitySelector = new IEntitySelector() {
            @Override
            public boolean isEntityApplicable(Entity var1) {
                if (!(var1 instanceof EntityLivingBase)) {
                    return false;
                } else {
                    return var6 != null && !var6.isEntityApplicable(var1)
                        ? false
                        : EntityAINearestAttackableTarget.this.isSuitableTarget((EntityLivingBase)var1, false);
                }
            }
        };
    }

    @Override
    public boolean shouldExecute() {
        if (this.targetChance > 0 && this.taskOwner.getRNG().nextInt(this.targetChance) != 0) {
            return false;
        }

        double d0 = this.getTargetDistance();
        List list = this.taskOwner
            .worldObj
            .selectEntitiesWithinAABB(this.targetClass, this.taskOwner.boundingBox.expand(d0, 4.0, d0), this.targetEntitySelector);
        Collections.sort(list, this.theNearestAttackableTargetSorter);
        if (list.isEmpty()) {
            return false;
        }

        this.targetEntity = (EntityLivingBase)list.get(0);
        return true;
    }

    @Override
    public void startExecuting() {
        this.taskOwner.setAttackTarget(this.targetEntity);
        super.startExecuting();
    }

    public static class Sorter implements Comparator {
        private final Entity theEntity;

        public Sorter(Entity var1) {
            this.theEntity = var1;
        }

        public int compare(Entity var1, Entity var2) {
            double d0 = this.theEntity.getDistanceSqToEntity(var1);
            double d1 = this.theEntity.getDistanceSqToEntity(var2);
            if (d0 < d1) {
                return -1;
            } else {
                return d0 > d1 ? 1 : 0;
            }
        }

        @Override
        public int compare(Object var1, Object var2) {
            return this.compare((Entity)var1, (Entity)var2);
        }
    }
}
