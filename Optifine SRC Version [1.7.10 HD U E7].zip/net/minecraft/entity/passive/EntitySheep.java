package net.minecraft.entity.passive;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIEatGrass;
import net.minecraft.entity.ai.EntityAIFollowParent;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntitySheep extends EntityAnimal {
    private final InventoryCrafting inventoryCrafting = new InventoryCrafting(new Container() {
        @Override
        public boolean canInteractWith(EntityPlayer var1) {
            return false;
        }
    }, 2, 1);
    public static final float[][] fleeceColorTable = new float[][]{
        {1.0F, 1.0F, 1.0F},
        {0.85F, 0.5F, 0.2F},
        {0.7F, 0.3F, 0.85F},
        {0.4F, 0.6F, 0.85F},
        {0.9F, 0.9F, 0.2F},
        {0.5F, 0.8F, 0.1F},
        {0.95F, 0.5F, 0.65F},
        {0.3F, 0.3F, 0.3F},
        {0.6F, 0.6F, 0.6F},
        {0.3F, 0.5F, 0.6F},
        {0.5F, 0.25F, 0.7F},
        {0.2F, 0.3F, 0.7F},
        {0.4F, 0.3F, 0.2F},
        {0.4F, 0.5F, 0.2F},
        {0.6F, 0.2F, 0.2F},
        {0.1F, 0.1F, 0.1F}
    };
    private int sheepTimer;
    private EntityAIEatGrass entityAIEatGrass = new EntityAIEatGrass(this);

    public EntitySheep(World var1) {
        super(var1);
        this.setSize(0.9F, 1.3F);
        this.getNavigator().setAvoidsWater(true);
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAIPanic(this, 1.25));
        this.tasks.addTask(2, new EntityAIMate(this, 1.0));
        this.tasks.addTask(3, new EntityAITempt(this, 1.1, Items.wheat, false));
        this.tasks.addTask(4, new EntityAIFollowParent(this, 1.1));
        this.tasks.addTask(5, this.entityAIEatGrass);
        this.tasks.addTask(6, new EntityAIWander(this, 1.0));
        this.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
        this.tasks.addTask(8, new EntityAILookIdle(this));
        this.inventoryCrafting.setInventorySlotContents(0, new ItemStack(Items.dye, 1, 0));
        this.inventoryCrafting.setInventorySlotContents(1, new ItemStack(Items.dye, 1, 0));
    }

    @Override
    protected boolean isAIEnabled() {
        return true;
    }

    @Override
    protected void updateAITasks() {
        this.sheepTimer = this.entityAIEatGrass.getEatingGrassTimer();
        super.updateAITasks();
    }

    @Override
    public void onLivingUpdate() {
        if (this.worldObj.isRemote) {
            this.sheepTimer = Math.max(0, this.sheepTimer - 1);
        }

        super.onLivingUpdate();
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(8.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23F);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
    }

    @Override
    protected void dropFewItems(boolean var1, int var2) {
        if (!this.getSheared()) {
            this.entityDropItem(new ItemStack(Item.getItemFromBlock(Blocks.wool), 1, this.getFleeceColor()), 0.0F);
        }
    }

    @Override
    protected Item getDropItem() {
        return Item.getItemFromBlock(Blocks.wool);
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 10) {
            this.sheepTimer = 40;
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    public float getHeadRotationPointY(float var1) {
        if (this.sheepTimer <= 0) {
            return 0.0F;
        } else if (this.sheepTimer >= 4 && this.sheepTimer <= 36) {
            return 1.0F;
        } else {
            return this.sheepTimer < 4 ? (this.sheepTimer - var1) / 4.0F : -(this.sheepTimer - 40 - var1) / 4.0F;
        }
    }

    public float getHeadRotationAngleX(float var1) {
        if (this.sheepTimer > 4 && this.sheepTimer <= 36) {
            float f = (this.sheepTimer - 4 - var1) / 32.0F;
            return (float)Math.PI * 0.2F + (float)Math.PI * 0.07F * MathHelper.sin(f * 28.7F);
        } else {
            return this.sheepTimer > 0 ? (float)Math.PI * 0.2F : this.rotationPitch / (180.0F / (float)Math.PI);
        }
    }

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        if (itemstack != null && itemstack.getItem() == Items.shears && !this.getSheared() && !this.isChild()) {
            if (!this.worldObj.isRemote) {
                this.setSheared(true);
                int i = 1 + this.rand.nextInt(3);

                for (int j = 0; j < i; j++) {
                    EntityItem entityitem = this.entityDropItem(new ItemStack(Item.getItemFromBlock(Blocks.wool), 1, this.getFleeceColor()), 1.0F);
                    entityitem.motionY = entityitem.motionY + this.rand.nextFloat() * 0.05F;
                    entityitem.motionX = entityitem.motionX + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F;
                    entityitem.motionZ = entityitem.motionZ + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F;
                }
            }

            itemstack.damageItem(1, var1);
            this.playSound("mob.sheep.shear", 1.0F, 1.0F);
        }

        return super.interact(var1);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setBoolean("Sheared", this.getSheared());
        var1.setByte("Color", (byte)this.getFleeceColor());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.setSheared(var1.getBoolean("Sheared"));
        this.setFleeceColor(var1.getByte("Color"));
    }

    @Override
    protected String getLivingSound() {
        return "mob.sheep.say";
    }

    @Override
    protected String getHurtSound() {
        return "mob.sheep.say";
    }

    @Override
    protected String getDeathSound() {
        return "mob.sheep.say";
    }

    @Override
    protected void playStepSound(int var1, int var2, int var3, Block var4) {
        this.playSound("mob.sheep.step", 0.15F, 1.0F);
    }

    public int getFleeceColor() {
        return this.dataWatcher.getWatchableObjectByte(16) & 15;
    }

    public void setFleeceColor(int var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        this.dataWatcher.updateObject(16, (byte)(b0 & 240 | var1 & 15));
    }

    public boolean getSheared() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 16) != 0;
    }

    public void setSheared(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var1) {
            this.dataWatcher.updateObject(16, (byte)(b0 | 16));
        } else {
            this.dataWatcher.updateObject(16, (byte)(b0 & -17));
        }
    }

    public static int getRandomFleeceColor(Random var0) {
        int i = var0.nextInt(100);
        if (i < 5) {
            return 15;
        } else if (i < 10) {
            return 7;
        } else if (i < 15) {
            return 8;
        } else if (i < 18) {
            return 12;
        } else {
            return var0.nextInt(500) == 0 ? 6 : 0;
        }
    }

    public EntitySheep createChild(EntityAgeable var1) {
        EntitySheep entitysheep = (EntitySheep)var1;
        EntitySheep entitysheep1 = new EntitySheep(this.worldObj);
        int i = this.getDyeBasedOnParents(this, entitysheep);
        entitysheep1.setFleeceColor(15 - i);
        return entitysheep1;
    }

    @Override
    public void eatGrassBonus() {
        this.setSheared(false);
        if (this.isChild()) {
            this.addGrowth(60);
        }
    }

    @Override
    public IEntityLivingData onSpawnWithEgg(IEntityLivingData var1) {
        var1 = super.onSpawnWithEgg(var1);
        this.setFleeceColor(getRandomFleeceColor(this.worldObj.rand));
        return var1;
    }

    private int getDyeBasedOnParents(EntityAnimal var1, EntityAnimal var2) {
        int i = this.getDyeFromFleeceColor(var1);
        int j = this.getDyeFromFleeceColor(var2);
        this.inventoryCrafting.getStackInSlot(0).setMetadata(i);
        this.inventoryCrafting.getStackInSlot(1).setMetadata(j);
        ItemStack itemstack = CraftingManager.getInstance().findMatchingRecipe(this.inventoryCrafting, ((EntitySheep)var1).worldObj);
        int k;
        if (itemstack != null && itemstack.getItem() == Items.dye) {
            k = itemstack.getMetadata();
        } else {
            k = this.worldObj.rand.nextBoolean() ? i : j;
        }

        return k;
    }

    private int getDyeFromFleeceColor(EntityAnimal var1) {
        return 15 - ((EntitySheep)var1).getFleeceColor();
    }
}
