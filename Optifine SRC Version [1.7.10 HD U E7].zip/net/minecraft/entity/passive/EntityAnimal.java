package net.minecraft.entity.passive;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public abstract class EntityAnimal extends EntityAgeable implements IAnimals {
    private int inLove;
    private int breeding;
    private EntityPlayer playerInLove;

    public EntityAnimal(World var1) {
        super(var1);
    }

    @Override
    protected void updateAITick() {
        if (this.getGrowingAge() != 0) {
            this.inLove = 0;
        }

        super.updateAITick();
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.getGrowingAge() != 0) {
            this.inLove = 0;
        }

        if (this.inLove > 0) {
            this.inLove--;
            String s = "heart";
            if (this.inLove % 10 == 0) {
                double d0 = this.rand.nextGaussian() * 0.02;
                double d1 = this.rand.nextGaussian() * 0.02;
                double d2 = this.rand.nextGaussian() * 0.02;
                this.worldObj
                    .spawnParticle(
                        s,
                        this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        this.posY + 0.5 + this.rand.nextFloat() * this.height,
                        this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        d0,
                        d1,
                        d2
                    );
            }
        } else {
            this.breeding = 0;
        }
    }

    @Override
    protected void attackEntity(Entity var1, float var2) {
        if (var1 instanceof EntityPlayer) {
            if (var2 < 3.0F) {
                double d0 = var1.posX - this.posX;
                double d1 = var1.posZ - this.posZ;
                this.rotationYaw = (float)(Math.atan2(d1, d0) * 180.0 / (float)Math.PI) - 90.0F;
                this.hasAttacked = true;
            }

            EntityPlayer entityplayer = (EntityPlayer)var1;
            if (entityplayer.getCurrentEquippedItem() == null || !this.isBreedingItem(entityplayer.getCurrentEquippedItem())) {
                this.entityToAttack = null;
            }
        } else if (var1 instanceof EntityAnimal) {
            EntityAnimal entityanimal = (EntityAnimal)var1;
            if (this.getGrowingAge() > 0 && entityanimal.getGrowingAge() < 0) {
                if (var2 < 2.5) {
                    this.hasAttacked = true;
                }
            } else if (this.inLove > 0 && entityanimal.inLove > 0) {
                if (entityanimal.entityToAttack == null) {
                    entityanimal.entityToAttack = this;
                }

                if (entityanimal.entityToAttack == this && var2 < 3.5) {
                    entityanimal.inLove++;
                    this.inLove++;
                    this.breeding++;
                    if (this.breeding % 4 == 0) {
                        this.worldObj
                            .spawnParticle(
                                "heart",
                                this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                                this.posY + 0.5 + this.rand.nextFloat() * this.height,
                                this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                                0.0,
                                0.0,
                                0.0
                            );
                    }

                    if (this.breeding == 60) {
                        this.procreate((EntityAnimal)var1);
                    }
                } else {
                    this.breeding = 0;
                }
            } else {
                this.breeding = 0;
                this.entityToAttack = null;
            }
        }
    }

    private void procreate(EntityAnimal var1) {
        EntityAgeable entityageable = this.createChild(var1);
        if (entityageable != null) {
            if (this.playerInLove == null && var1.func_146083_cb() != null) {
                this.playerInLove = var1.func_146083_cb();
            }

            if (this.playerInLove != null) {
                this.playerInLove.triggerAchievement(StatList.animalsBredStat);
                if (this instanceof EntityCow) {
                    this.playerInLove.triggerAchievement(AchievementList.breedCow);
                }
            }

            this.setGrowingAge(6000);
            var1.setGrowingAge(6000);
            this.inLove = 0;
            this.breeding = 0;
            this.entityToAttack = null;
            var1.entityToAttack = null;
            var1.breeding = 0;
            var1.inLove = 0;
            entityageable.setGrowingAge(-24000);
            entityageable.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);

            for (int i = 0; i < 7; i++) {
                double d0 = this.rand.nextGaussian() * 0.02;
                double d1 = this.rand.nextGaussian() * 0.02;
                double d2 = this.rand.nextGaussian() * 0.02;
                this.worldObj
                    .spawnParticle(
                        "heart",
                        this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        this.posY + 0.5 + this.rand.nextFloat() * this.height,
                        this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        d0,
                        d1,
                        d2
                    );
            }

            this.worldObj.spawnEntityInWorld(entityageable);
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        this.fleeingTick = 60;
        if (!this.isAIEnabled()) {
            IAttributeInstance iattributeinstance = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
            if (iattributeinstance.getModifier(field_110179_h) == null) {
                iattributeinstance.applyModifier(field_110181_i);
            }
        }

        this.entityToAttack = null;
        this.inLove = 0;
        return super.attackEntityFrom(var1, var2);
    }

    @Override
    public float getBlockPathWeight(int var1, int var2, int var3) {
        return this.worldObj.getBlock(var1, var2 - 1, var3) == Blocks.grass ? 10.0F : this.worldObj.getLightBrightness(var1, var2, var3) - 0.5F;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setInteger("InLove", this.inLove);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.inLove = var1.getInteger("InLove");
    }

    @Override
    protected Entity findPlayerToAttack() {
        if (this.fleeingTick > 0) {
            return null;
        }

        float f = 8.0F;
        if (this.inLove > 0) {
            List list = this.worldObj.getEntitiesWithinAABB(this.getClass(), this.boundingBox.expand(f, f, f));

            for (int i = 0; i < list.size(); i++) {
                EntityAnimal entityanimal = (EntityAnimal)list.get(i);
                if (entityanimal != this && entityanimal.inLove > 0) {
                    return entityanimal;
                }
            }
        } else if (this.getGrowingAge() == 0) {
            List list1 = this.worldObj.getEntitiesWithinAABB(EntityPlayer.class, this.boundingBox.expand(f, f, f));

            for (int j = 0; j < list1.size(); j++) {
                EntityPlayer entityplayer = (EntityPlayer)list1.get(j);
                if (entityplayer.getCurrentEquippedItem() != null && this.isBreedingItem(entityplayer.getCurrentEquippedItem())) {
                    return entityplayer;
                }
            }
        } else if (this.getGrowingAge() > 0) {
            List list2 = this.worldObj.getEntitiesWithinAABB(this.getClass(), this.boundingBox.expand(f, f, f));

            for (int k = 0; k < list2.size(); k++) {
                EntityAnimal entityanimal1 = (EntityAnimal)list2.get(k);
                if (entityanimal1 != this && entityanimal1.getGrowingAge() < 0) {
                    return entityanimal1;
                }
            }
        }

        return null;
    }

    @Override
    public boolean getCanSpawnHere() {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.boundingBox.minY);
        int k = MathHelper.floor_double(this.posZ);
        return this.worldObj.getBlock(i, j - 1, k) == Blocks.grass && this.worldObj.getFullBlockLightValue(i, j, k) > 8 && super.getCanSpawnHere();
    }

    @Override
    public int getTalkInterval() {
        return 120;
    }

    @Override
    protected boolean canDespawn() {
        return false;
    }

    @Override
    protected int getExperiencePoints(EntityPlayer var1) {
        return 1 + this.worldObj.rand.nextInt(3);
    }

    public boolean isBreedingItem(ItemStack var1) {
        return var1.getItem() == Items.wheat;
    }

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        if (itemstack != null && this.isBreedingItem(itemstack) && this.getGrowingAge() == 0 && this.inLove <= 0) {
            if (!var1.capabilities.isCreativeMode) {
                itemstack.stackSize--;
                if (itemstack.stackSize <= 0) {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
                }
            }

            this.setInLove(var1);
            return true;
        } else {
            return super.interact(var1);
        }
    }

    public void setInLove(EntityPlayer var1) {
        this.inLove = 600;
        this.playerInLove = var1;
        this.entityToAttack = null;
        this.worldObj.setEntityState(this, (byte)18);
    }

    public EntityPlayer func_146083_cb() {
        return this.playerInLove;
    }

    public boolean isInLove() {
        return this.inLove > 0;
    }

    public void resetInLove() {
        this.inLove = 0;
    }

    public boolean canMateWith(EntityAnimal var1) {
        if (var1 == this) {
            return false;
        } else {
            return var1.getClass() != this.getClass() ? false : this.isInLove() && var1.isInLove();
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 18) {
            for (int i = 0; i < 7; i++) {
                double d0 = this.rand.nextGaussian() * 0.02;
                double d1 = this.rand.nextGaussian() * 0.02;
                double d2 = this.rand.nextGaussian() * 0.02;
                this.worldObj
                    .spawnParticle(
                        "heart",
                        this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        this.posY + 0.5 + this.rand.nextFloat() * this.height,
                        this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                        d0,
                        d1,
                        d2
                    );
            }
        } else {
            super.handleHealthUpdate(var1);
        }
    }
}
