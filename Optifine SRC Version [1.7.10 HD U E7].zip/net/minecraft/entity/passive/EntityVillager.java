package net.minecraft.entity.passive;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentData;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.INpc;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIFollowGolem;
import net.minecraft.entity.ai.EntityAILookAtTradePlayer;
import net.minecraft.entity.ai.EntityAIMoveIndoors;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAIOpenDoor;
import net.minecraft.entity.ai.EntityAIPlay;
import net.minecraft.entity.ai.EntityAIRestrictOpenDoor;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITradePlayer;
import net.minecraft.entity.ai.EntityAIVillagerMate;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityAIWatchClosest2;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Tuple;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.village.Village;
import net.minecraft.world.World;

public class EntityVillager extends EntityAgeable implements IMerchant, INpc {
    private int randomTickDivider;
    private boolean isMating;
    private boolean isPlaying;
    Village villageObj;
    private EntityPlayer buyingPlayer;
    private MerchantRecipeList buyingList;
    private int timeUntilReset;
    private boolean needsInitilization;
    private int wealth;
    private String lastBuyingPlayer;
    private boolean isLookingForHome;
    private float field_82191_bN;
    private static final Map villagersSellingList = new HashMap();
    private static final Map blacksmithSellingList = new HashMap();

    public EntityVillager(World var1) {
        this(var1, 0);
    }

    public EntityVillager(World var1, int var2) {
        super(var1);
        this.setProfession(var2);
        this.setSize(0.6F, 1.8F);
        this.getNavigator().setBreakDoors(true);
        this.getNavigator().setAvoidsWater(true);
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAIAvoidEntity(this, EntityZombie.class, 8.0F, 0.6, 0.6));
        this.tasks.addTask(1, new EntityAITradePlayer(this));
        this.tasks.addTask(1, new EntityAILookAtTradePlayer(this));
        this.tasks.addTask(2, new EntityAIMoveIndoors(this));
        this.tasks.addTask(3, new EntityAIRestrictOpenDoor(this));
        this.tasks.addTask(4, new EntityAIOpenDoor(this, true));
        this.tasks.addTask(5, new EntityAIMoveTowardsRestriction(this, 0.6));
        this.tasks.addTask(6, new EntityAIVillagerMate(this));
        this.tasks.addTask(7, new EntityAIFollowGolem(this));
        this.tasks.addTask(8, new EntityAIPlay(this, 0.32));
        this.tasks.addTask(9, new EntityAIWatchClosest2(this, EntityPlayer.class, 3.0F, 1.0F));
        this.tasks.addTask(9, new EntityAIWatchClosest2(this, EntityVillager.class, 5.0F, 0.02F));
        this.tasks.addTask(9, new EntityAIWander(this, 0.6));
        this.tasks.addTask(10, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.5);
    }

    @Override
    public boolean isAIEnabled() {
        return true;
    }

    @Override
    protected void updateAITick() {
        if (--this.randomTickDivider <= 0) {
            this.worldObj
                .villageCollectionObj
                .addVillagerPosition(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ));
            this.randomTickDivider = 70 + this.rand.nextInt(50);
            this.villageObj = this.worldObj
                .villageCollectionObj
                .findNearestVillage(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ), 32);
            if (this.villageObj == null) {
                this.detachHome();
            } else {
                ChunkCoordinates chunkcoordinates = this.villageObj.getCenter();
                this.setHomeArea(chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ, (int)(this.villageObj.getVillageRadius() * 0.6F));
                if (this.isLookingForHome) {
                    this.isLookingForHome = false;
                    this.villageObj.setDefaultPlayerReputation(5);
                }
            }
        }

        if (!this.isTrading() && this.timeUntilReset > 0) {
            this.timeUntilReset--;
            if (this.timeUntilReset <= 0) {
                if (this.needsInitilization) {
                    if (this.buyingList.size() > 1) {
                        for (MerchantRecipe merchantrecipe : (Iterable<MerchantRecipe>) (Iterable) this.buyingList) {
                            if (merchantrecipe.isRecipeDisabled()) {
                                merchantrecipe.func_82783_a(this.rand.nextInt(6) + this.rand.nextInt(6) + 2);
                            }
                        }
                    }

                    this.addDefaultEquipmentAndRecipies(1);
                    this.needsInitilization = false;
                    if (this.villageObj != null && this.lastBuyingPlayer != null) {
                        this.worldObj.setEntityState(this, (byte)14);
                        this.villageObj.setReputationForPlayer(this.lastBuyingPlayer, 1);
                    }
                }

                this.addPotionEffect(new PotionEffect(Potion.regeneration.id, 200, 0));
            }
        }

        super.updateAITick();
    }

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        boolean flag = itemstack != null && itemstack.getItem() == Items.spawn_egg;
        if (!flag && this.isEntityAlive() && !this.isTrading() && !this.isChild()) {
            if (!this.worldObj.isRemote) {
                this.setCustomer(var1);
                var1.displayGUIMerchant(this, this.getCustomNameTag());
            }

            return true;
        } else {
            return super.interact(var1);
        }
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, 0);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setInteger("Profession", this.getProfession());
        var1.setInteger("Riches", this.wealth);
        if (this.buyingList != null) {
            var1.setTag("Offers", this.buyingList.getRecipiesAsTags());
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.setProfession(var1.getInteger("Profession"));
        this.wealth = var1.getInteger("Riches");
        if (var1.hasKey("Offers", 10)) {
            NBTTagCompound nbttagcompound = var1.getCompoundTag("Offers");
            this.buyingList = new MerchantRecipeList(nbttagcompound);
        }
    }

    @Override
    protected boolean canDespawn() {
        return false;
    }

    @Override
    protected String getLivingSound() {
        return this.isTrading() ? "mob.villager.haggle" : "mob.villager.idle";
    }

    @Override
    protected String getHurtSound() {
        return "mob.villager.hit";
    }

    @Override
    protected String getDeathSound() {
        return "mob.villager.death";
    }

    public void setProfession(int var1) {
        this.dataWatcher.updateObject(16, var1);
    }

    public int getProfession() {
        return this.dataWatcher.getWatchableObjectInt(16);
    }

    public boolean isMating() {
        return this.isMating;
    }

    public void setMating(boolean var1) {
        this.isMating = var1;
    }

    public void setPlaying(boolean var1) {
        this.isPlaying = var1;
    }

    public boolean isPlaying() {
        return this.isPlaying;
    }

    @Override
    public void setRevengeTarget(EntityLivingBase var1) {
        super.setRevengeTarget(var1);
        if (this.villageObj != null && var1 != null) {
            this.villageObj.addOrRenewAgressor(var1);
            if (var1 instanceof EntityPlayer) {
                byte b0 = -1;
                if (this.isChild()) {
                    b0 = -3;
                }

                this.villageObj.setReputationForPlayer(var1.getCommandSenderName(), b0);
                if (this.isEntityAlive()) {
                    this.worldObj.setEntityState(this, (byte)13);
                }
            }
        }
    }

    @Override
    public void onDeath(DamageSource var1) {
        if (this.villageObj != null) {
            Entity entity = var1.getEntity();
            if (entity != null) {
                if (entity instanceof EntityPlayer) {
                    this.villageObj.setReputationForPlayer(entity.getCommandSenderName(), -2);
                } else if (entity instanceof IMob) {
                    this.villageObj.endMatingSeason();
                }
            } else if (entity == null) {
                EntityPlayer entityplayer = this.worldObj.getClosestPlayerToEntity(this, 16.0);
                if (entityplayer != null) {
                    this.villageObj.endMatingSeason();
                }
            }
        }

        super.onDeath(var1);
    }

    @Override
    public void setCustomer(EntityPlayer var1) {
        this.buyingPlayer = var1;
    }

    @Override
    public EntityPlayer getCustomer() {
        return this.buyingPlayer;
    }

    public boolean isTrading() {
        return this.buyingPlayer != null;
    }

    @Override
    public void useRecipe(MerchantRecipe var1) {
        var1.incrementToolUses();
        this.livingSoundTime = -this.getTalkInterval();
        this.playSound("mob.villager.yes", this.getSoundVolume(), this.getSoundPitch());
        if (var1.hasSameIDsAs((MerchantRecipe)this.buyingList.get(this.buyingList.size() - 1))) {
            this.timeUntilReset = 40;
            this.needsInitilization = true;
            if (this.buyingPlayer != null) {
                this.lastBuyingPlayer = this.buyingPlayer.getCommandSenderName();
            } else {
                this.lastBuyingPlayer = null;
            }
        }

        if (var1.getItemToBuy().getItem() == Items.emerald) {
            this.wealth = this.wealth + var1.getItemToBuy().stackSize;
        }
    }

    @Override
    public void verifySellingItem(ItemStack var1) {
        if (!this.worldObj.isRemote && this.livingSoundTime > -this.getTalkInterval() + 20) {
            this.livingSoundTime = -this.getTalkInterval();
            if (var1 != null) {
                this.playSound("mob.villager.yes", this.getSoundVolume(), this.getSoundPitch());
            } else {
                this.playSound("mob.villager.no", this.getSoundVolume(), this.getSoundPitch());
            }
        }
    }

    @Override
    public MerchantRecipeList getRecipes(EntityPlayer var1) {
        if (this.buyingList == null) {
            this.addDefaultEquipmentAndRecipies(1);
        }

        return this.buyingList;
    }

    private float adjustProbability(float var1) {
        float f = var1 + this.field_82191_bN;
        return f > 0.9F ? 0.9F - (f - 0.9F) : f;
    }

    private void addDefaultEquipmentAndRecipies(int var1) {
        if (this.buyingList != null) {
            this.field_82191_bN = MathHelper.sqrt_float(this.buyingList.size()) * 0.2F;
        } else {
            this.field_82191_bN = 0.0F;
        }

        MerchantRecipeList merchantrecipelist = new MerchantRecipeList();
        switch (this.getProfession()) {
            case 0:
                func_146091_a(merchantrecipelist, Items.wheat, this.rand, this.adjustProbability(0.9F));
                func_146091_a(merchantrecipelist, Item.getItemFromBlock(Blocks.wool), this.rand, this.adjustProbability(0.5F));
                func_146091_a(merchantrecipelist, Items.chicken, this.rand, this.adjustProbability(0.5F));
                func_146091_a(merchantrecipelist, Items.cooked_fish, this.rand, this.adjustProbability(0.4F));
                func_146089_b(merchantrecipelist, Items.bread, this.rand, this.adjustProbability(0.9F));
                func_146089_b(merchantrecipelist, Items.melon, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.apple, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.cookie, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.shears, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.flint_and_steel, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.cooked_chicken, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.arrow, this.rand, this.adjustProbability(0.5F));
                if (this.rand.nextFloat() < this.adjustProbability(0.5F)) {
                    merchantrecipelist.add(
                        new MerchantRecipe(
                            new ItemStack(Blocks.gravel, 10), new ItemStack(Items.emerald), new ItemStack(Items.flint, 4 + this.rand.nextInt(2), 0)
                        )
                    );
                }
                break;
            case 1:
                func_146091_a(merchantrecipelist, Items.paper, this.rand, this.adjustProbability(0.8F));
                func_146091_a(merchantrecipelist, Items.book, this.rand, this.adjustProbability(0.8F));
                func_146091_a(merchantrecipelist, Items.written_book, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Item.getItemFromBlock(Blocks.bookshelf), this.rand, this.adjustProbability(0.8F));
                func_146089_b(merchantrecipelist, Item.getItemFromBlock(Blocks.glass), this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.compass, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.clock, this.rand, this.adjustProbability(0.2F));
                if (this.rand.nextFloat() < this.adjustProbability(0.07F)) {
                    Enchantment enchantment = Enchantment.enchantmentsBookList[this.rand.nextInt(Enchantment.enchantmentsBookList.length)];
                    int j = MathHelper.getRandomIntegerInRange(this.rand, enchantment.getMinLevel(), enchantment.getMaxLevel());
                    ItemStack itemstack = Items.enchanted_book.getEnchantedItemStack(new EnchantmentData(enchantment, j));
                    int k = 2 + this.rand.nextInt(5 + j * 10) + 3 * j;
                    merchantrecipelist.add(new MerchantRecipe(new ItemStack(Items.book), new ItemStack(Items.emerald, k), itemstack));
                }
                break;
            case 2:
                func_146089_b(merchantrecipelist, Items.ender_eye, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.experience_bottle, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.redstone, this.rand, this.adjustProbability(0.4F));
                func_146089_b(merchantrecipelist, Item.getItemFromBlock(Blocks.glowstone), this.rand, this.adjustProbability(0.3F));
                Item[] aitem = new Item[]{
                    Items.iron_sword,
                    Items.diamond_sword,
                    Items.iron_chestplate,
                    Items.diamond_chestplate,
                    Items.iron_axe,
                    Items.diamond_axe,
                    Items.iron_pickaxe,
                    Items.diamond_pickaxe
                };

                for (Item item : aitem) {
                    if (this.rand.nextFloat() < this.adjustProbability(0.05F)) {
                        merchantrecipelist.add(
                            new MerchantRecipe(
                                new ItemStack(item, 1, 0),
                                new ItemStack(Items.emerald, 2 + this.rand.nextInt(3), 0),
                                EnchantmentHelper.addRandomEnchantment(this.rand, new ItemStack(item, 1, 0), 5 + this.rand.nextInt(15))
                            )
                        );
                    }
                }
                break;
            case 3:
                func_146091_a(merchantrecipelist, Items.coal, this.rand, this.adjustProbability(0.7F));
                func_146091_a(merchantrecipelist, Items.iron_ingot, this.rand, this.adjustProbability(0.5F));
                func_146091_a(merchantrecipelist, Items.gold_ingot, this.rand, this.adjustProbability(0.5F));
                func_146091_a(merchantrecipelist, Items.diamond, this.rand, this.adjustProbability(0.5F));
                func_146089_b(merchantrecipelist, Items.iron_sword, this.rand, this.adjustProbability(0.5F));
                func_146089_b(merchantrecipelist, Items.diamond_sword, this.rand, this.adjustProbability(0.5F));
                func_146089_b(merchantrecipelist, Items.iron_axe, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.diamond_axe, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.iron_pickaxe, this.rand, this.adjustProbability(0.5F));
                func_146089_b(merchantrecipelist, Items.diamond_pickaxe, this.rand, this.adjustProbability(0.5F));
                func_146089_b(merchantrecipelist, Items.iron_shovel, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.diamond_shovel, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.iron_hoe, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.diamond_hoe, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.iron_boots, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.diamond_boots, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.iron_helmet, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.diamond_helmet, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.iron_chestplate, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.diamond_chestplate, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.iron_leggings, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.diamond_leggings, this.rand, this.adjustProbability(0.2F));
                func_146089_b(merchantrecipelist, Items.chainmail_boots, this.rand, this.adjustProbability(0.1F));
                func_146089_b(merchantrecipelist, Items.chainmail_helmet, this.rand, this.adjustProbability(0.1F));
                func_146089_b(merchantrecipelist, Items.chainmail_chestplate, this.rand, this.adjustProbability(0.1F));
                func_146089_b(merchantrecipelist, Items.chainmail_leggings, this.rand, this.adjustProbability(0.1F));
                break;
            case 4:
                func_146091_a(merchantrecipelist, Items.coal, this.rand, this.adjustProbability(0.7F));
                func_146091_a(merchantrecipelist, Items.porkchop, this.rand, this.adjustProbability(0.5F));
                func_146091_a(merchantrecipelist, Items.beef, this.rand, this.adjustProbability(0.5F));
                func_146089_b(merchantrecipelist, Items.saddle, this.rand, this.adjustProbability(0.1F));
                func_146089_b(merchantrecipelist, Items.leather_chestplate, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.leather_boots, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.leather_helmet, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.leather_leggings, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.cooked_porkchop, this.rand, this.adjustProbability(0.3F));
                func_146089_b(merchantrecipelist, Items.cooked_beef, this.rand, this.adjustProbability(0.3F));
        }

        if (merchantrecipelist.isEmpty()) {
            func_146091_a(merchantrecipelist, Items.gold_ingot, this.rand, 1.0F);
        }

        Collections.shuffle(merchantrecipelist);
        if (this.buyingList == null) {
            this.buyingList = new MerchantRecipeList();
        }

        for (int i = 0; i < var1 && i < merchantrecipelist.size(); i++) {
            this.buyingList.addToListWithCheck((MerchantRecipe)merchantrecipelist.get(i));
        }
    }

    @Override
    public void setRecipes(MerchantRecipeList var1) {
    }

    private static void func_146091_a(MerchantRecipeList var0, Item var1, Random var2, float var3) {
        if (var2.nextFloat() < var3) {
            var0.add(new MerchantRecipe(func_146088_a(var1, var2), Items.emerald));
        }
    }

    private static ItemStack func_146088_a(Item var0, Random var1) {
        return new ItemStack(var0, func_146092_b(var0, var1), 0);
    }

    private static int func_146092_b(Item var0, Random var1) {
        Tuple tuple = (Tuple)villagersSellingList.get(var0);
        if (tuple == null) {
            return 1;
        } else {
            return (Integer) tuple.getFirst() >= (Integer) tuple.getSecond()
                ? (Integer)tuple.getFirst()
                : (Integer)tuple.getFirst() + var1.nextInt((Integer)tuple.getSecond() - (Integer)tuple.getFirst());
        }
    }

    private static void func_146089_b(MerchantRecipeList var0, Item var1, Random var2, float var3) {
        if (var2.nextFloat() < var3) {
            int i = func_146090_c(var1, var2);
            ItemStack itemstack;
            ItemStack itemstack1;
            if (i < 0) {
                itemstack = new ItemStack(Items.emerald, 1, 0);
                itemstack1 = new ItemStack(var1, -i, 0);
            } else {
                itemstack = new ItemStack(Items.emerald, i, 0);
                itemstack1 = new ItemStack(var1, 1, 0);
            }

            var0.add(new MerchantRecipe(itemstack, itemstack1));
        }
    }

    private static int func_146090_c(Item var0, Random var1) {
        Tuple tuple = (Tuple)blacksmithSellingList.get(var0);
        if (tuple == null) {
            return 1;
        } else {
            return (Integer) tuple.getFirst() >= (Integer) tuple.getSecond()
                ? (Integer)tuple.getFirst()
                : (Integer)tuple.getFirst() + var1.nextInt((Integer)tuple.getSecond() - (Integer)tuple.getFirst());
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 12) {
            this.generateRandomParticles("heart");
        } else if (var1 == 13) {
            this.generateRandomParticles("angryVillager");
        } else if (var1 == 14) {
            this.generateRandomParticles("happyVillager");
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    private void generateRandomParticles(String var1) {
        for (int i = 0; i < 5; i++) {
            double d0 = this.rand.nextGaussian() * 0.02;
            double d1 = this.rand.nextGaussian() * 0.02;
            double d2 = this.rand.nextGaussian() * 0.02;
            this.worldObj
                .spawnParticle(
                    var1,
                    this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    this.posY + 1.0 + this.rand.nextFloat() * this.height,
                    this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    d0,
                    d1,
                    d2
                );
        }
    }

    @Override
    public IEntityLivingData onSpawnWithEgg(IEntityLivingData var1) {
        var1 = super.onSpawnWithEgg(var1);
        this.setProfession(this.worldObj.rand.nextInt(5));
        return var1;
    }

    public void setLookingForHome() {
        this.isLookingForHome = true;
    }

    public EntityVillager createChild(EntityAgeable var1) {
        EntityVillager entityvillager = new EntityVillager(this.worldObj);
        entityvillager.onSpawnWithEgg(null);
        return entityvillager;
    }

    @Override
    public boolean allowLeashing() {
        return false;
    }

    static {
        villagersSellingList.put(Items.coal, new Tuple(16, 24));
        villagersSellingList.put(Items.iron_ingot, new Tuple(8, 10));
        villagersSellingList.put(Items.gold_ingot, new Tuple(8, 10));
        villagersSellingList.put(Items.diamond, new Tuple(4, 6));
        villagersSellingList.put(Items.paper, new Tuple(24, 36));
        villagersSellingList.put(Items.book, new Tuple(11, 13));
        villagersSellingList.put(Items.written_book, new Tuple(1, 1));
        villagersSellingList.put(Items.ender_pearl, new Tuple(3, 4));
        villagersSellingList.put(Items.ender_eye, new Tuple(2, 3));
        villagersSellingList.put(Items.porkchop, new Tuple(14, 18));
        villagersSellingList.put(Items.beef, new Tuple(14, 18));
        villagersSellingList.put(Items.chicken, new Tuple(14, 18));
        villagersSellingList.put(Items.cooked_fish, new Tuple(9, 13));
        villagersSellingList.put(Items.wheat_seeds, new Tuple(34, 48));
        villagersSellingList.put(Items.melon_seeds, new Tuple(30, 38));
        villagersSellingList.put(Items.pumpkin_seeds, new Tuple(30, 38));
        villagersSellingList.put(Items.wheat, new Tuple(18, 22));
        villagersSellingList.put(Item.getItemFromBlock(Blocks.wool), new Tuple(14, 22));
        villagersSellingList.put(Items.rotten_flesh, new Tuple(36, 64));
        blacksmithSellingList.put(Items.flint_and_steel, new Tuple(3, 4));
        blacksmithSellingList.put(Items.shears, new Tuple(3, 4));
        blacksmithSellingList.put(Items.iron_sword, new Tuple(7, 11));
        blacksmithSellingList.put(Items.diamond_sword, new Tuple(12, 14));
        blacksmithSellingList.put(Items.iron_axe, new Tuple(6, 8));
        blacksmithSellingList.put(Items.diamond_axe, new Tuple(9, 12));
        blacksmithSellingList.put(Items.iron_pickaxe, new Tuple(7, 9));
        blacksmithSellingList.put(Items.diamond_pickaxe, new Tuple(10, 12));
        blacksmithSellingList.put(Items.iron_shovel, new Tuple(4, 6));
        blacksmithSellingList.put(Items.diamond_shovel, new Tuple(7, 8));
        blacksmithSellingList.put(Items.iron_hoe, new Tuple(4, 6));
        blacksmithSellingList.put(Items.diamond_hoe, new Tuple(7, 8));
        blacksmithSellingList.put(Items.iron_boots, new Tuple(4, 6));
        blacksmithSellingList.put(Items.diamond_boots, new Tuple(7, 8));
        blacksmithSellingList.put(Items.iron_helmet, new Tuple(4, 6));
        blacksmithSellingList.put(Items.diamond_helmet, new Tuple(7, 8));
        blacksmithSellingList.put(Items.iron_chestplate, new Tuple(10, 14));
        blacksmithSellingList.put(Items.diamond_chestplate, new Tuple(16, 19));
        blacksmithSellingList.put(Items.iron_leggings, new Tuple(8, 10));
        blacksmithSellingList.put(Items.diamond_leggings, new Tuple(11, 14));
        blacksmithSellingList.put(Items.chainmail_boots, new Tuple(5, 7));
        blacksmithSellingList.put(Items.chainmail_helmet, new Tuple(5, 7));
        blacksmithSellingList.put(Items.chainmail_chestplate, new Tuple(11, 15));
        blacksmithSellingList.put(Items.chainmail_leggings, new Tuple(9, 11));
        blacksmithSellingList.put(Items.bread, new Tuple(-4, -2));
        blacksmithSellingList.put(Items.melon, new Tuple(-8, -4));
        blacksmithSellingList.put(Items.apple, new Tuple(-8, -4));
        blacksmithSellingList.put(Items.cookie, new Tuple(-10, -7));
        blacksmithSellingList.put(Item.getItemFromBlock(Blocks.glass), new Tuple(-5, -3));
        blacksmithSellingList.put(Item.getItemFromBlock(Blocks.bookshelf), new Tuple(3, 4));
        blacksmithSellingList.put(Items.leather_chestplate, new Tuple(4, 5));
        blacksmithSellingList.put(Items.leather_boots, new Tuple(2, 4));
        blacksmithSellingList.put(Items.leather_helmet, new Tuple(2, 4));
        blacksmithSellingList.put(Items.leather_leggings, new Tuple(2, 4));
        blacksmithSellingList.put(Items.saddle, new Tuple(6, 8));
        blacksmithSellingList.put(Items.experience_bottle, new Tuple(-4, -1));
        blacksmithSellingList.put(Items.redstone, new Tuple(-4, -1));
        blacksmithSellingList.put(Items.compass, new Tuple(10, 12));
        blacksmithSellingList.put(Items.clock, new Tuple(10, 12));
        blacksmithSellingList.put(Item.getItemFromBlock(Blocks.glowstone), new Tuple(-3, -1));
        blacksmithSellingList.put(Items.cooked_porkchop, new Tuple(-7, -5));
        blacksmithSellingList.put(Items.cooked_beef, new Tuple(-7, -5));
        blacksmithSellingList.put(Items.cooked_chicken, new Tuple(-8, -6));
        blacksmithSellingList.put(Items.ender_eye, new Tuple(7, 11));
        blacksmithSellingList.put(Items.arrow, new Tuple(-12, -8));
    }
}
