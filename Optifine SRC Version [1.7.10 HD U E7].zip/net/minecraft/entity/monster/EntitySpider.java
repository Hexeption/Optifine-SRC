package net.minecraft.entity.monster;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class EntitySpider extends EntityMob {
    public EntitySpider(World var1) {
        super(var1);
        this.setSize(1.4F, 0.9F);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (!this.worldObj.isRemote) {
            this.setBesideClimbableBlock(this.isCollidedHorizontally);
        }
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(16.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.8F);
    }

    @Override
    protected Entity findPlayerToAttack() {
        float f = this.getBrightness(1.0F);
        if (f < 0.5F) {
            double d0 = 16.0;
            return this.worldObj.getClosestVulnerablePlayerToEntity(this, d0);
        } else {
            return null;
        }
    }

    @Override
    protected String getLivingSound() {
        return "mob.spider.say";
    }

    @Override
    protected String getHurtSound() {
        return "mob.spider.say";
    }

    @Override
    protected String getDeathSound() {
        return "mob.spider.death";
    }

    @Override
    protected void playStepSound(int var1, int var2, int var3, Block var4) {
        this.playSound("mob.spider.step", 0.15F, 1.0F);
    }

    @Override
    protected void attackEntity(Entity var1, float var2) {
        float f = this.getBrightness(1.0F);
        if (f > 0.5F && this.rand.nextInt(100) == 0) {
            this.entityToAttack = null;
        } else {
            if (!(var2 > 2.0F) || !(var2 < 6.0F) || this.rand.nextInt(10) != 0) {
                super.attackEntity(var1, var2);
            } else if (this.onGround) {
                double d0 = var1.posX - this.posX;
                double d1 = var1.posZ - this.posZ;
                float f1 = MathHelper.sqrt_double(d0 * d0 + d1 * d1);
                this.motionX = d0 / f1 * 0.5 * 0.8F + this.motionX * 0.2F;
                this.motionZ = d1 / f1 * 0.5 * 0.8F + this.motionZ * 0.2F;
                this.motionY = 0.4F;
            }
        }
    }

    @Override
    protected Item getDropItem() {
        return Items.string;
    }

    @Override
    protected void dropFewItems(boolean var1, int var2) {
        super.dropFewItems(var1, var2);
        if (var1 && (this.rand.nextInt(3) == 0 || this.rand.nextInt(1 + var2) > 0)) {
            this.dropItem(Items.spider_eye, 1);
        }
    }

    @Override
    public boolean isOnLadder() {
        return this.isBesideClimbableBlock();
    }

    @Override
    public void setInWeb() {
    }

    @Override
    public EnumCreatureAttribute getCreatureAttribute() {
        return EnumCreatureAttribute.ARTHROPOD;
    }

    @Override
    public boolean isPotionApplicable(PotionEffect var1) {
        return var1.getPotionID() == Potion.poison.id ? false : super.isPotionApplicable(var1);
    }

    public boolean isBesideClimbableBlock() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
    }

    public void setBesideClimbableBlock(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var1) {
            b0 = (byte)(b0 | 1);
        } else {
            b0 = (byte)(b0 & -2);
        }

        this.dataWatcher.updateObject(16, b0);
    }

    @Override
    public IEntityLivingData onSpawnWithEgg(IEntityLivingData var1) {
        var1 = super.onSpawnWithEgg(var1);
        if (this.worldObj.rand.nextInt(100) == 0) {
            EntitySkeleton entityskeleton = new EntitySkeleton(this.worldObj);
            entityskeleton.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);
            entityskeleton.onSpawnWithEgg(null);
            this.worldObj.spawnEntityInWorld(entityskeleton);
            entityskeleton.mountEntity(this);
        }

        if (var1 == null) {
            var1 = new EntitySpider.GroupData();
            if (this.worldObj.difficultySetting == EnumDifficulty.HARD
                && this.worldObj.rand.nextFloat() < 0.1F * this.worldObj.getTensionFactorForBlock(this.posX, this.posY, this.posZ)) {
                ((EntitySpider.GroupData)var1).func_111104_a(this.worldObj.rand);
            }
        }

        if (var1 instanceof EntitySpider.GroupData) {
            int i = ((EntitySpider.GroupData)var1).field_111105_a;
            if (i > 0 && Potion.potionTypes[i] != null) {
                this.addPotionEffect(new PotionEffect(i, Integer.MAX_VALUE));
            }
        }

        return var1;
    }

    public static class GroupData implements IEntityLivingData {
        public int field_111105_a;

        public void func_111104_a(Random var1) {
            int i = var1.nextInt(5);
            if (i <= 1) {
                this.field_111105_a = Potion.moveSpeed.id;
            } else if (i <= 2) {
                this.field_111105_a = Potion.damageBoost.id;
            } else if (i <= 3) {
                this.field_111105_a = Potion.regeneration.id;
            } else if (i <= 4) {
                this.field_111105_a = Potion.invisibility.id;
            }
        }
    }
}
