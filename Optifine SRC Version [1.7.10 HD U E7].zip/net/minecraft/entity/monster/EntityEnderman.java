package net.minecraft.entity.monster;

import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EntityEnderman extends EntityMob {
    private static final UUID attackingSpeedBoostModifierUUID = UUID.fromString("020E0DFB-87AE-4653-9556-831010E291A0");
    private static final AttributeModifier attackingSpeedBoostModifier = new AttributeModifier(
            attackingSpeedBoostModifierUUID, "Attacking speed boost", 6.2F, 0
        )
        .setSaved(false);
    private static boolean[] carriableBlocks = new boolean[256];
    private int teleportDelay;
    private int stareTimer;
    private Entity lastEntityToAttack;
    private boolean isAggressive;

    public EntityEnderman(World var1) {
        super(var1);
        this.setSize(0.6F, 2.9F);
        this.stepHeight = 1.0F;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.3F);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(7.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
        this.dataWatcher.addObject(17, new Byte((byte)0));
        this.dataWatcher.addObject(18, new Byte((byte)0));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setShort("carried", (short)Block.getIdFromBlock(this.getCarriedBlock()));
        var1.setShort("carriedData", (short)this.getCarryingData());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.setCarriedBlock(Block.getBlockById(var1.getShort("carried")));
        this.setCarryingData(var1.getShort("carriedData"));
    }

    @Override
    protected Entity findPlayerToAttack() {
        EntityPlayer entityplayer = this.worldObj.getClosestVulnerablePlayerToEntity(this, 64.0);
        if (entityplayer != null) {
            if (this.shouldAttackPlayer(entityplayer)) {
                this.isAggressive = true;
                if (this.stareTimer == 0) {
                    this.worldObj.playSoundEffect(entityplayer.posX, entityplayer.posY, entityplayer.posZ, "mob.endermen.stare", 1.0F, 1.0F);
                }

                if (this.stareTimer++ == 5) {
                    this.stareTimer = 0;
                    this.setScreaming(true);
                    return entityplayer;
                }
            } else {
                this.stareTimer = 0;
            }
        }

        return null;
    }

    private boolean shouldAttackPlayer(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.armorInventory[3];
        if (itemstack != null && itemstack.getItem() == Item.getItemFromBlock(Blocks.pumpkin)) {
            return false;
        }

        Vec3 vec3 = var1.getLook(1.0F).normalize();
        Vec3 vec31 = Vec3.createVectorHelper(
            this.posX - var1.posX, this.boundingBox.minY + this.height / 2.0F - (var1.posY + var1.getEyeHeight()), this.posZ - var1.posZ
        );
        double d0 = vec31.lengthVector();
        vec31 = vec31.normalize();
        double d1 = vec3.dotProduct(vec31);
        return d1 > 1.0 - 0.025 / d0 && var1.canEntityBeSeen(this);
    }

    @Override
    public void onLivingUpdate() {
        if (this.isWet()) {
            this.attackEntityFrom(DamageSource.drown, 1.0F);
        }

        if (this.lastEntityToAttack != this.entityToAttack) {
            IAttributeInstance iattributeinstance = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
            iattributeinstance.removeModifier(attackingSpeedBoostModifier);
            if (this.entityToAttack != null) {
                iattributeinstance.applyModifier(attackingSpeedBoostModifier);
            }
        }

        this.lastEntityToAttack = this.entityToAttack;
        if (!this.worldObj.isRemote && this.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) {
            if (this.getCarriedBlock().getMaterial() == Material.air) {
                if (this.rand.nextInt(20) == 0) {
                    int k = MathHelper.floor_double(this.posX - 2.0 + this.rand.nextDouble() * 4.0);
                    int i = MathHelper.floor_double(this.posY + this.rand.nextDouble() * 3.0);
                    int j = MathHelper.floor_double(this.posZ - 2.0 + this.rand.nextDouble() * 4.0);
                    Block block = this.worldObj.getBlock(k, i, j);
                    if (carriableBlocks[Block.getIdFromBlock(block)]) {
                        this.setCarriedBlock(block);
                        this.setCarryingData(this.worldObj.getBlockMetadata(k, i, j));
                        this.worldObj.setBlock(k, i, j, Blocks.air);
                    }
                }
            } else if (this.rand.nextInt(2000) == 0) {
                int l = MathHelper.floor_double(this.posX - 1.0 + this.rand.nextDouble() * 2.0);
                int j1 = MathHelper.floor_double(this.posY + this.rand.nextDouble() * 2.0);
                int k1 = MathHelper.floor_double(this.posZ - 1.0 + this.rand.nextDouble() * 2.0);
                Block block2 = this.worldObj.getBlock(l, j1, k1);
                Block block1 = this.worldObj.getBlock(l, j1 - 1, k1);
                if (block2.getMaterial() == Material.air && block1.getMaterial() != Material.air && block1.renderAsNormalBlock()) {
                    this.worldObj.setBlock(l, j1, k1, this.getCarriedBlock(), this.getCarryingData(), 3);
                    this.setCarriedBlock(Blocks.air);
                }
            }
        }

        for (int i1 = 0; i1 < 2; i1++) {
            this.worldObj
                .spawnParticle(
                    "portal",
                    this.posX + (this.rand.nextDouble() - 0.5) * this.width,
                    this.posY + this.rand.nextDouble() * this.height - 0.25,
                    this.posZ + (this.rand.nextDouble() - 0.5) * this.width,
                    (this.rand.nextDouble() - 0.5) * 2.0,
                    -this.rand.nextDouble(),
                    (this.rand.nextDouble() - 0.5) * 2.0
                );
        }

        if (this.worldObj.isDaytime() && !this.worldObj.isRemote) {
            float f = this.getBrightness(1.0F);
            if (f > 0.5F
                && this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))
                && this.rand.nextFloat() * 30.0F < (f - 0.4F) * 2.0F) {
                this.entityToAttack = null;
                this.setScreaming(false);
                this.isAggressive = false;
                this.teleportRandomly();
            }
        }

        if (this.isWet() || this.isBurning()) {
            this.entityToAttack = null;
            this.setScreaming(false);
            this.isAggressive = false;
            this.teleportRandomly();
        }

        if (this.isScreaming() && !this.isAggressive && this.rand.nextInt(100) == 0) {
            this.setScreaming(false);
        }

        this.isJumping = false;
        if (this.entityToAttack != null) {
            this.faceEntity(this.entityToAttack, 100.0F, 100.0F);
        }

        if (!this.worldObj.isRemote && this.isEntityAlive()) {
            if (this.entityToAttack != null) {
                if (this.entityToAttack instanceof EntityPlayer && this.shouldAttackPlayer((EntityPlayer)this.entityToAttack)) {
                    if (this.entityToAttack.getDistanceSqToEntity(this) < 16.0) {
                        this.teleportRandomly();
                    }

                    this.teleportDelay = 0;
                } else if (this.entityToAttack.getDistanceSqToEntity(this) > 256.0 && this.teleportDelay++ >= 30 && this.teleportToEntity(this.entityToAttack)) {
                    this.teleportDelay = 0;
                }
            } else {
                this.setScreaming(false);
                this.teleportDelay = 0;
            }
        }

        super.onLivingUpdate();
    }

    protected boolean teleportRandomly() {
        double d0 = this.posX + (this.rand.nextDouble() - 0.5) * 64.0;
        double d1 = this.posY + (this.rand.nextInt(64) - 32);
        double d2 = this.posZ + (this.rand.nextDouble() - 0.5) * 64.0;
        return this.teleportTo(d0, d1, d2);
    }

    protected boolean teleportToEntity(Entity var1) {
        Vec3 vec3 = Vec3.createVectorHelper(
            this.posX - var1.posX, this.boundingBox.minY + this.height / 2.0F - var1.posY + var1.getEyeHeight(), this.posZ - var1.posZ
        );
        vec3 = vec3.normalize();
        double d0 = 16.0;
        double d1 = this.posX + (this.rand.nextDouble() - 0.5) * 8.0 - vec3.xCoord * d0;
        double d2 = this.posY + (this.rand.nextInt(16) - 8) - vec3.yCoord * d0;
        double d3 = this.posZ + (this.rand.nextDouble() - 0.5) * 8.0 - vec3.zCoord * d0;
        return this.teleportTo(d1, d2, d3);
    }

    protected boolean teleportTo(double var1, double var3, double var5) {
        double d0 = this.posX;
        double d1 = this.posY;
        double d2 = this.posZ;
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        boolean flag = false;
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posY);
        int k = MathHelper.floor_double(this.posZ);
        if (this.worldObj.blockExists(i, j, k)) {
            boolean flag1 = false;

            while (!flag1 && j > 0) {
                Block block = this.worldObj.getBlock(i, j - 1, k);
                if (block.getMaterial().blocksMovement()) {
                    flag1 = true;
                } else {
                    this.posY--;
                    j--;
                }
            }

            if (flag1) {
                this.setPosition(this.posX, this.posY, this.posZ);
                if (this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).isEmpty() && !this.worldObj.isAnyLiquid(this.boundingBox)) {
                    flag = true;
                }
            }
        }

        if (!flag) {
            this.setPosition(d0, d1, d2);
            return false;
        }

        short short1 = 128;

        for (int l = 0; l < short1; l++) {
            double d3 = l / (short1 - 1.0);
            float f = (this.rand.nextFloat() - 0.5F) * 0.2F;
            float f1 = (this.rand.nextFloat() - 0.5F) * 0.2F;
            float f2 = (this.rand.nextFloat() - 0.5F) * 0.2F;
            double d4 = d0 + (this.posX - d0) * d3 + (this.rand.nextDouble() - 0.5) * this.width * 2.0;
            double d5 = d1 + (this.posY - d1) * d3 + this.rand.nextDouble() * this.height;
            double d6 = d2 + (this.posZ - d2) * d3 + (this.rand.nextDouble() - 0.5) * this.width * 2.0;
            this.worldObj.spawnParticle("portal", d4, d5, d6, f, f1, f2);
        }

        this.worldObj.playSoundEffect(d0, d1, d2, "mob.endermen.portal", 1.0F, 1.0F);
        this.playSound("mob.endermen.portal", 1.0F, 1.0F);
        return true;
    }

    @Override
    protected String getLivingSound() {
        return this.isScreaming() ? "mob.endermen.scream" : "mob.endermen.idle";
    }

    @Override
    protected String getHurtSound() {
        return "mob.endermen.hit";
    }

    @Override
    protected String getDeathSound() {
        return "mob.endermen.death";
    }

    @Override
    protected Item getDropItem() {
        return Items.ender_pearl;
    }

    @Override
    protected void dropFewItems(boolean var1, int var2) {
        Item item = this.getDropItem();
        if (item != null) {
            int i = this.rand.nextInt(2 + var2);

            for (int j = 0; j < i; j++) {
                this.dropItem(item, 1);
            }
        }
    }

    public void setCarriedBlock(Block var1) {
        this.dataWatcher.updateObject(16, (byte)(Block.getIdFromBlock(var1) & 0xFF));
    }

    public Block getCarriedBlock() {
        return Block.getBlockById(this.dataWatcher.getWatchableObjectByte(16));
    }

    public void setCarryingData(int var1) {
        this.dataWatcher.updateObject(17, (byte)(var1 & 0xFF));
    }

    public int getCarryingData() {
        return this.dataWatcher.getWatchableObjectByte(17);
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        this.setScreaming(true);
        if (var1 instanceof EntityDamageSource && var1.getEntity() instanceof EntityPlayer) {
            this.isAggressive = true;
        }

        if (var1 instanceof EntityDamageSourceIndirect) {
            this.isAggressive = false;

            for (int i = 0; i < 64; i++) {
                if (this.teleportRandomly()) {
                    return true;
                }
            }

            return false;
        } else {
            return super.attackEntityFrom(var1, var2);
        }
    }

    public boolean isScreaming() {
        return this.dataWatcher.getWatchableObjectByte(18) > 0;
    }

    public void setScreaming(boolean var1) {
        this.dataWatcher.updateObject(18, (byte)(var1 ? 1 : 0));
    }

    static {
        carriableBlocks[Block.getIdFromBlock(Blocks.grass)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.dirt)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.sand)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.gravel)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.yellow_flower)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.red_flower)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.brown_mushroom)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.red_mushroom)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.tnt)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.cactus)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.clay)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.pumpkin)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.melon_block)] = true;
        carriableBlocks[Block.getIdFromBlock(Blocks.mycelium)] = true;
    }
}
