package net.minecraft.entity.monster;

import net.minecraft.block.Block;
import net.minecraft.block.BlockSilverfish;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.Facing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import org.apache.commons.lang3.tuple.ImmutablePair;

public class EntitySilverfish extends EntityMob {
    private int allySummonCooldown;

    public EntitySilverfish(World var1) {
        super(var1);
        this.setSize(0.3F, 0.7F);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(8.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.6F);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0);
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    @Override
    protected Entity findPlayerToAttack() {
        double d0 = 8.0;
        return this.worldObj.getClosestVulnerablePlayerToEntity(this, d0);
    }

    @Override
    protected String getLivingSound() {
        return "mob.silverfish.say";
    }

    @Override
    protected String getHurtSound() {
        return "mob.silverfish.hit";
    }

    @Override
    protected String getDeathSound() {
        return "mob.silverfish.kill";
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        if (this.allySummonCooldown <= 0 && (var1 instanceof EntityDamageSource || var1 == DamageSource.magic)) {
            this.allySummonCooldown = 20;
        }

        return super.attackEntityFrom(var1, var2);
    }

    @Override
    protected void attackEntity(Entity var1, float var2) {
        if (this.attackTime <= 0 && var2 < 1.2F && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY) {
            this.attackTime = 20;
            this.attackEntityAsMob(var1);
        }
    }

    @Override
    protected void playStepSound(int var1, int var2, int var3, Block var4) {
        this.playSound("mob.silverfish.step", 0.15F, 1.0F);
    }

    @Override
    protected Item getDropItem() {
        return Item.getItemById(0);
    }

    @Override
    public void onUpdate() {
        this.renderYawOffset = this.rotationYaw;
        super.onUpdate();
    }

    @Override
    protected void updateEntityActionState() {
        super.updateEntityActionState();
        if (!this.worldObj.isRemote) {
            if (this.allySummonCooldown > 0) {
                this.allySummonCooldown--;
                if (this.allySummonCooldown == 0) {
                    int i = MathHelper.floor_double(this.posX);
                    int j = MathHelper.floor_double(this.posY);
                    int k = MathHelper.floor_double(this.posZ);
                    boolean flag = false;

                    for (byte b0 = 0; !flag && b0 <= 5 && b0 >= -5; b0 = (byte)(b0 <= 0 ? 1 - b0 : 0 - b0)) {
                        for (byte b1 = 0; !flag && b1 <= 10 && b1 >= -10; b1 = (byte)(b1 <= 0 ? 1 - b1 : 0 - b1)) {
                            for (byte b2 = 0; !flag && b2 <= 10 && b2 >= -10; b2 = (byte)(b2 <= 0 ? 1 - b2 : 0 - b2)) {
                                if (this.worldObj.getBlock(i + b1, j + b0, k + b2) == Blocks.monster_egg) {
                                    if (!this.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) {
                                        int l = this.worldObj.getBlockMetadata(i + b1, j + b0, k + b2);
                                        ImmutablePair immutablepair = BlockSilverfish.func_150197_b(l);
                                        this.worldObj.setBlock(i + b1, j + b0, k + b2, (Block)immutablepair.getLeft(), (Integer)immutablepair.getRight(), 3);
                                    } else {
                                        this.worldObj.breakBlock(i + b1, j + b0, k + b2, false);
                                    }

                                    Blocks.monster_egg.onBlockDestroyedByPlayer(this.worldObj, i + b1, j + b0, k + b2, 0);
                                    if (this.rand.nextBoolean()) {
                                        flag = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (this.entityToAttack == null && !this.hasPath()) {
                int i1 = MathHelper.floor_double(this.posX);
                int j1 = MathHelper.floor_double(this.posY + 0.5);
                int k1 = MathHelper.floor_double(this.posZ);
                int l1 = this.rand.nextInt(6);
                Block block = this.worldObj.getBlock(i1 + Facing.offsetsXForSide[l1], j1 + Facing.offsetsYForSide[l1], k1 + Facing.offsetsZForSide[l1]);
                int i2 = this.worldObj.getBlockMetadata(i1 + Facing.offsetsXForSide[l1], j1 + Facing.offsetsYForSide[l1], k1 + Facing.offsetsZForSide[l1]);
                if (BlockSilverfish.func_150196_a(block)) {
                    this.worldObj
                        .setBlock(
                            i1 + Facing.offsetsXForSide[l1],
                            j1 + Facing.offsetsYForSide[l1],
                            k1 + Facing.offsetsZForSide[l1],
                            Blocks.monster_egg,
                            BlockSilverfish.func_150195_a(block, i2),
                            3
                        );
                    this.spawnExplosionParticle();
                    this.setDead();
                } else {
                    this.updateWanderPath();
                }
            } else if (this.entityToAttack != null && !this.hasPath()) {
                this.entityToAttack = null;
            }
        }
    }

    @Override
    public float getBlockPathWeight(int var1, int var2, int var3) {
        return this.worldObj.getBlock(var1, var2 - 1, var3) == Blocks.stone ? 10.0F : super.getBlockPathWeight(var1, var2, var3);
    }

    @Override
    protected boolean isValidLightLevel() {
        return true;
    }

    @Override
    public boolean getCanSpawnHere() {
        if (super.getCanSpawnHere()) {
            EntityPlayer entityplayer = this.worldObj.getClosestPlayerToEntity(this, 5.0);
            return entityplayer == null;
        } else {
            return false;
        }
    }

    @Override
    public EnumCreatureAttribute getCreatureAttribute() {
        return EnumCreatureAttribute.ARTHROPOD;
    }
}
