package net.minecraft.entity.monster;

import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityBlaze extends EntityMob {
    private float heightOffset = 0.5F;
    private int heightOffsetUpdateTime;
    private int field_70846_g;

    public EntityBlaze(World var1) {
        super(var1);
        this.isImmuneToFire = true;
        this.experienceValue = 10;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(6.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
    }

    @Override
    protected String getLivingSound() {
        return "mob.blaze.breathe";
    }

    @Override
    protected String getHurtSound() {
        return "mob.blaze.hit";
    }

    @Override
    protected String getDeathSound() {
        return "mob.blaze.death";
    }

    @Override
    public int getBrightnessForRender(float var1) {
        return 15728880;
    }

    @Override
    public float getBrightness(float var1) {
        return 1.0F;
    }

    @Override
    public void onLivingUpdate() {
        if (!this.worldObj.isRemote) {
            if (this.isWet()) {
                this.attackEntityFrom(DamageSource.drown, 1.0F);
            }

            this.heightOffsetUpdateTime--;
            if (this.heightOffsetUpdateTime <= 0) {
                this.heightOffsetUpdateTime = 100;
                this.heightOffset = 0.5F + (float)this.rand.nextGaussian() * 3.0F;
            }

            if (this.getEntityToAttack() != null
                && this.getEntityToAttack().posY + this.getEntityToAttack().getEyeHeight() > this.posY + this.getEyeHeight() + this.heightOffset) {
                this.motionY = this.motionY + (0.3F - this.motionY) * 0.3F;
            }
        }

        if (this.rand.nextInt(24) == 0) {
            this.worldObj
                .playSoundEffect(
                    this.posX + 0.5, this.posY + 0.5, this.posZ + 0.5, "fire.fire", 1.0F + this.rand.nextFloat(), this.rand.nextFloat() * 0.7F + 0.3F
                );
        }

        if (!this.onGround && this.motionY < 0.0) {
            this.motionY *= 0.6;
        }

        for (int i = 0; i < 2; i++) {
            this.worldObj
                .spawnParticle(
                    "largesmoke",
                    this.posX + (this.rand.nextDouble() - 0.5) * this.width,
                    this.posY + this.rand.nextDouble() * this.height,
                    this.posZ + (this.rand.nextDouble() - 0.5) * this.width,
                    0.0,
                    0.0,
                    0.0
                );
        }

        super.onLivingUpdate();
    }

    @Override
    protected void attackEntity(Entity var1, float var2) {
        if (this.attackTime <= 0 && var2 < 2.0F && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY) {
            this.attackTime = 20;
            this.attackEntityAsMob(var1);
        } else if (var2 < 30.0F) {
            double d0 = var1.posX - this.posX;
            double d1 = var1.boundingBox.minY + var1.height / 2.0F - (this.posY + this.height / 2.0F);
            double d2 = var1.posZ - this.posZ;
            if (this.attackTime == 0) {
                this.field_70846_g++;
                if (this.field_70846_g == 1) {
                    this.attackTime = 60;
                    this.func_70844_e(true);
                } else if (this.field_70846_g <= 4) {
                    this.attackTime = 6;
                } else {
                    this.attackTime = 100;
                    this.field_70846_g = 0;
                    this.func_70844_e(false);
                }

                if (this.field_70846_g > 1) {
                    float f = MathHelper.sqrt_float(var2) * 0.5F;
                    this.worldObj.playAuxSFXAtEntity(null, 1009, (int)this.posX, (int)this.posY, (int)this.posZ, 0);

                    for (int i = 0; i < 1; i++) {
                        EntitySmallFireball entitysmallfireball = new EntitySmallFireball(
                            this.worldObj, this, d0 + this.rand.nextGaussian() * f, d1, d2 + this.rand.nextGaussian() * f
                        );
                        entitysmallfireball.posY = this.posY + this.height / 2.0F + 0.5;
                        this.worldObj.spawnEntityInWorld(entitysmallfireball);
                    }
                }
            }

            this.rotationYaw = (float)(Math.atan2(d2, d0) * 180.0 / (float)Math.PI) - 90.0F;
            this.hasAttacked = true;
        }
    }

    @Override
    protected void fall(float var1) {
    }

    @Override
    protected Item getDropItem() {
        return Items.blaze_rod;
    }

    @Override
    public boolean isBurning() {
        return this.func_70845_n();
    }

    @Override
    protected void dropFewItems(boolean var1, int var2) {
        if (var1) {
            int i = this.rand.nextInt(2 + var2);

            for (int j = 0; j < i; j++) {
                this.dropItem(Items.blaze_rod, 1);
            }
        }
    }

    public boolean func_70845_n() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
    }

    public void func_70844_e(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var1) {
            b0 = (byte)(b0 | 1);
        } else {
            b0 = (byte)(b0 & -2);
        }

        this.dataWatcher.updateObject(16, b0);
    }

    @Override
    protected boolean isValidLightLevel() {
        return true;
    }
}
