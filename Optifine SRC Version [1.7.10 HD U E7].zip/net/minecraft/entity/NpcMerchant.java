package net.minecraft.entity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryMerchant;
import net.minecraft.item.ItemStack;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;

public class NpcMerchant implements IMerchant {
    private InventoryMerchant theMerchantInventory;
    private EntityPlayer customer;
    private MerchantRecipeList recipeList;

    public NpcMerchant(EntityPlayer var1) {
        this.customer = var1;
        this.theMerchantInventory = new InventoryMerchant(var1, this);
    }

    @Override
    public EntityPlayer getCustomer() {
        return this.customer;
    }

    @Override
    public void setCustomer(EntityPlayer var1) {
    }

    @Override
    public MerchantRecipeList getRecipes(EntityPlayer var1) {
        return this.recipeList;
    }

    @Override
    public void setRecipes(MerchantRecipeList var1) {
        this.recipeList = var1;
    }

    @Override
    public void useRecipe(MerchantRecipe var1) {
    }

    @Override
    public void verifySellingItem(ItemStack var1) {
    }
}
