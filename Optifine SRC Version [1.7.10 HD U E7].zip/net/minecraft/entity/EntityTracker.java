package net.minecraft.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderEye;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.network.Packet;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.ReportedException;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityTracker {
    private static final Logger logger = LogManager.getLogger();
    private final WorldServer theWorld;
    private Set trackedEntities = new HashSet();
    private IntHashMap trackedEntityHashTable = new IntHashMap();
    private int maxTrackingDistanceThreshold;

    public EntityTracker(WorldServer var1) {
        this.theWorld = var1;
        this.maxTrackingDistanceThreshold = var1.func_73046_m().getConfigurationManager().getEntityViewDistance();
    }

    public void trackEntity(Entity var1) {
        if (var1 instanceof EntityPlayerMP) {
            this.trackEntity(var1, 512, 2);
            EntityPlayerMP entityplayermp = (EntityPlayerMP)var1;

            for (EntityTrackerEntry entitytrackerentry : (Iterable<EntityTrackerEntry>) (Iterable) this.trackedEntities) {
                if (entitytrackerentry.trackedEntity != entityplayermp) {
                    entitytrackerentry.updatePlayerEntity(entityplayermp);
                }
            }
        } else if (var1 instanceof EntityFishHook) {
            this.addEntityToTracker(var1, 64, 5, true);
        } else if (var1 instanceof EntityArrow) {
            this.addEntityToTracker(var1, 64, 20, false);
        } else if (var1 instanceof EntitySmallFireball) {
            this.addEntityToTracker(var1, 64, 10, false);
        } else if (var1 instanceof EntityFireball) {
            this.addEntityToTracker(var1, 64, 10, false);
        } else if (var1 instanceof EntitySnowball) {
            this.addEntityToTracker(var1, 64, 10, true);
        } else if (var1 instanceof EntityEnderPearl) {
            this.addEntityToTracker(var1, 64, 10, true);
        } else if (var1 instanceof EntityEnderEye) {
            this.addEntityToTracker(var1, 64, 4, true);
        } else if (var1 instanceof EntityEgg) {
            this.addEntityToTracker(var1, 64, 10, true);
        } else if (var1 instanceof EntityPotion) {
            this.addEntityToTracker(var1, 64, 10, true);
        } else if (var1 instanceof EntityExpBottle) {
            this.addEntityToTracker(var1, 64, 10, true);
        } else if (var1 instanceof EntityFireworkRocket) {
            this.addEntityToTracker(var1, 64, 10, true);
        } else if (var1 instanceof EntityItem) {
            this.addEntityToTracker(var1, 64, 20, true);
        } else if (var1 instanceof EntityMinecart) {
            this.addEntityToTracker(var1, 80, 3, true);
        } else if (var1 instanceof EntityBoat) {
            this.addEntityToTracker(var1, 80, 3, true);
        } else if (var1 instanceof EntitySquid) {
            this.addEntityToTracker(var1, 64, 3, true);
        } else if (var1 instanceof EntityWither) {
            this.addEntityToTracker(var1, 80, 3, false);
        } else if (var1 instanceof EntityBat) {
            this.addEntityToTracker(var1, 80, 3, false);
        } else if (var1 instanceof IAnimals) {
            this.addEntityToTracker(var1, 80, 3, true);
        } else if (var1 instanceof EntityDragon) {
            this.addEntityToTracker(var1, 160, 3, true);
        } else if (var1 instanceof EntityTNTPrimed) {
            this.addEntityToTracker(var1, 160, 10, true);
        } else if (var1 instanceof EntityFallingBlock) {
            this.addEntityToTracker(var1, 160, 20, true);
        } else if (var1 instanceof EntityHanging) {
            this.addEntityToTracker(var1, 160, Integer.MAX_VALUE, false);
        } else if (var1 instanceof EntityXPOrb) {
            this.addEntityToTracker(var1, 160, 20, true);
        } else if (var1 instanceof EntityEnderCrystal) {
            this.addEntityToTracker(var1, 256, Integer.MAX_VALUE, false);
        }
    }

    public void trackEntity(Entity var1, int var2, int var3) {
        this.addEntityToTracker(var1, var2, var3, false);
    }

    public void addEntityToTracker(Entity var1, int var2, final int var3, boolean var4) {
        if (var2 > this.maxTrackingDistanceThreshold) {
            var2 = this.maxTrackingDistanceThreshold;
        }

        try {
            if (this.trackedEntityHashTable.containsItem(var1.getEntityId())) {
                throw new IllegalStateException("Entity is already tracked!");
            }

            EntityTrackerEntry entitytrackerentry = new EntityTrackerEntry(var1, var2, var3, var4);
            this.trackedEntities.add(entitytrackerentry);
            this.trackedEntityHashTable.addKey(var1.getEntityId(), entitytrackerentry);
            entitytrackerentry.updatePlayerEntities(this.theWorld.playerEntities);
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Adding entity to track");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity To Track");
            crashreportcategory.addCrashSection("Tracking range", var2 + " blocks");
            crashreportcategory.addCrashSectionCallable("Update interval", new Callable() {
                public String call() {
                    String s = "Once per " + var3 + " ticks";
                    if (var3 == Integer.MAX_VALUE) {
                        s = "Maximum (" + s + ")";
                    }

                    return s;
                }
            });
            var1.addEntityCrashInfo(crashreportcategory);
            CrashReportCategory crashreportcategory1 = crashreport.makeCategory("Entity That Is Already Tracked");
            ((EntityTrackerEntry)this.trackedEntityHashTable.lookup(var1.getEntityId())).trackedEntity.addEntityCrashInfo(crashreportcategory1);

            try {
                throw new ReportedException(crashreport);
            } catch (ReportedException reportedexception) {
                logger.error("\"Silently\" catching entity tracking error.", reportedexception);
            }
        }
    }

    public void untrackEntity(Entity var1) {
        if (var1 instanceof EntityPlayerMP) {
            EntityPlayerMP entityplayermp = (EntityPlayerMP)var1;

            for (EntityTrackerEntry entitytrackerentry : (Iterable<EntityTrackerEntry>) (Iterable) this.trackedEntities) {
                entitytrackerentry.removeFromTrackedPlayers(entityplayermp);
            }
        }

        EntityTrackerEntry entitytrackerentry1 = (EntityTrackerEntry)this.trackedEntityHashTable.removeObject(var1.getEntityId());
        if (entitytrackerentry1 != null) {
            this.trackedEntities.remove(entitytrackerentry1);
            entitytrackerentry1.sendDestroyEntityPacketToTrackedPlayers();
        }
    }

    public void updateTrackedEntities() {
        ArrayList arraylist = new ArrayList();

        for (EntityTrackerEntry entitytrackerentry : (Iterable<EntityTrackerEntry>) (Iterable) this.trackedEntities) {
            entitytrackerentry.updatePlayerList(this.theWorld.playerEntities);
            if (entitytrackerentry.playerEntitiesUpdated && entitytrackerentry.trackedEntity instanceof EntityPlayerMP) {
                arraylist.add((EntityPlayerMP)entitytrackerentry.trackedEntity);
            }
        }

        for (int i = 0; i < arraylist.size(); i++) {
            EntityPlayerMP entityplayermp = (EntityPlayerMP)arraylist.get(i);

            for (EntityTrackerEntry entitytrackerentry1 : (Iterable<EntityTrackerEntry>) (Iterable) this.trackedEntities) {
                if (entitytrackerentry1.trackedEntity != entityplayermp) {
                    entitytrackerentry1.updatePlayerEntity(entityplayermp);
                }
            }
        }
    }

    public void sendToAllTrackingEntity(Entity var1, Packet var2) {
        EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)this.trackedEntityHashTable.lookup(var1.getEntityId());
        if (entitytrackerentry != null) {
            entitytrackerentry.func_151259_a(var2);
        }
    }

    public void func_151248_b(Entity var1, Packet var2) {
        EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)this.trackedEntityHashTable.lookup(var1.getEntityId());
        if (entitytrackerentry != null) {
            entitytrackerentry.func_151261_b(var2);
        }
    }

    public void removePlayerFromTrackers(EntityPlayerMP var1) {
        for (EntityTrackerEntry entitytrackerentry : (Iterable<EntityTrackerEntry>) (Iterable) this.trackedEntities) {
            entitytrackerentry.removeTrackedPlayerSymmetric(var1);
        }
    }

    public void func_85172_a(EntityPlayerMP var1, Chunk var2) {
        for (EntityTrackerEntry entitytrackerentry : (Iterable<EntityTrackerEntry>) (Iterable) this.trackedEntities) {
            if (entitytrackerentry.trackedEntity != var1
                && entitytrackerentry.trackedEntity.chunkCoordX == var2.xPosition
                && entitytrackerentry.trackedEntity.chunkCoordZ == var2.zPosition) {
                entitytrackerentry.updatePlayerEntity(var1);
            }
        }
    }
}
