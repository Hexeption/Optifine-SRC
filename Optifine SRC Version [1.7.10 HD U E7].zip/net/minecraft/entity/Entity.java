package net.minecraft.entity;

import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Callable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.enchantment.EnchantmentProtection;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Direction;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Vec3;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public abstract class Entity {
    private static int nextEntityID;
    private int entityId;
    public double renderDistanceWeight;
    public boolean preventEntitySpawning;
    public Entity riddenByEntity;
    public Entity ridingEntity;
    public boolean forceSpawn;
    public World worldObj;
    public double prevPosX;
    public double prevPosY;
    public double prevPosZ;
    public double posX;
    public double posY;
    public double posZ;
    public double motionX;
    public double motionY;
    public double motionZ;
    public float rotationYaw;
    public float rotationPitch;
    public float prevRotationYaw;
    public float prevRotationPitch;
    public final AxisAlignedBB boundingBox;
    public boolean onGround;
    public boolean isCollidedHorizontally;
    public boolean isCollidedVertically;
    public boolean isCollided;
    public boolean velocityChanged;
    protected boolean isInWeb;
    public boolean field_70135_K;
    public boolean isDead;
    public float yOffset;
    public float width;
    public float height;
    public float prevDistanceWalkedModified;
    public float distanceWalkedModified;
    public float distanceWalkedOnStepModified;
    public float fallDistance;
    private int nextStepDistance;
    public double lastTickPosX;
    public double lastTickPosY;
    public double lastTickPosZ;
    public float yOffset2;
    public float stepHeight;
    public boolean noClip;
    public float entityCollisionReduction;
    protected Random rand;
    public int ticksExisted;
    public int fireResistance;
    private int fire;
    protected boolean inWater;
    public int hurtResistantTime;
    private boolean firstUpdate;
    protected boolean isImmuneToFire;
    protected DataWatcher dataWatcher;
    private double entityRiderPitchDelta;
    private double entityRiderYawDelta;
    public boolean addedToChunk;
    public int chunkCoordX;
    public int chunkCoordY;
    public int chunkCoordZ;
    public int serverPosX;
    public int serverPosY;
    public int serverPosZ;
    public boolean ignoreFrustumCheck;
    public boolean isAirBorne;
    public int timeUntilPortal;
    protected boolean inPortal;
    protected int portalCounter;
    public int dimension;
    protected int teleportDirection;
    private boolean invulnerable;
    protected UUID entityUniqueID;
    public Entity.EnumEntitySize myEntitySize;

    public int getEntityId() {
        return this.entityId;
    }

    public void setEntityId(int var1) {
        this.entityId = var1;
    }

    public Entity(World var1) {
        this.entityId = nextEntityID++;
        this.renderDistanceWeight = 1.0;
        this.boundingBox = AxisAlignedBB.getBoundingBox(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        this.field_70135_K = true;
        this.width = 0.6F;
        this.height = 1.8F;
        this.nextStepDistance = 1;
        this.rand = new Random();
        this.fireResistance = 1;
        this.firstUpdate = true;
        this.entityUniqueID = UUID.randomUUID();
        this.myEntitySize = Entity.EnumEntitySize.SIZE_2;
        this.worldObj = var1;
        this.setPosition(0.0, 0.0, 0.0);
        if (var1 != null) {
            this.dimension = var1.provider.dimensionId;
        }

        this.dataWatcher = new DataWatcher(this);
        this.dataWatcher.addObject(0, (byte)0);
        this.dataWatcher.addObject(1, (short)300);
        this.entityInit();
    }

    protected abstract void entityInit();

    public DataWatcher getDataWatcher() {
        return this.dataWatcher;
    }

    @Override
    public boolean equals(Object var1) {
        return var1 instanceof Entity ? ((Entity)var1).entityId == this.entityId : false;
    }

    @Override
    public int hashCode() {
        return this.entityId;
    }

    protected void preparePlayerToSpawn() {
        if (this.worldObj != null) {
            while (this.posY > 0.0) {
                this.setPosition(this.posX, this.posY, this.posZ);
                if (this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).isEmpty()) {
                    break;
                }

                this.posY++;
            }

            this.motionX = this.motionY = this.motionZ = 0.0;
            this.rotationPitch = 0.0F;
        }
    }

    public void setDead() {
        this.isDead = true;
    }

    protected void setSize(float var1, float var2) {
        if (var1 != this.width || var2 != this.height) {
            float f = this.width;
            this.width = var1;
            this.height = var2;
            this.boundingBox.maxX = this.boundingBox.minX + this.width;
            this.boundingBox.maxZ = this.boundingBox.minZ + this.width;
            this.boundingBox.maxY = this.boundingBox.minY + this.height;
            if (this.width > f && !this.firstUpdate && !this.worldObj.isRemote) {
                this.moveEntity(f - this.width, 0.0, f - this.width);
            }
        }

        float f1 = var1 % 2.0F;
        if (f1 < 0.375) {
            this.myEntitySize = Entity.EnumEntitySize.SIZE_1;
        } else if (f1 < 0.75) {
            this.myEntitySize = Entity.EnumEntitySize.SIZE_2;
        } else if (f1 < 1.0) {
            this.myEntitySize = Entity.EnumEntitySize.SIZE_3;
        } else if (f1 < 1.375) {
            this.myEntitySize = Entity.EnumEntitySize.SIZE_4;
        } else if (f1 < 1.75) {
            this.myEntitySize = Entity.EnumEntitySize.SIZE_5;
        } else {
            this.myEntitySize = Entity.EnumEntitySize.SIZE_6;
        }
    }

    protected void setRotation(float var1, float var2) {
        this.rotationYaw = var1 % 360.0F;
        this.rotationPitch = var2 % 360.0F;
    }

    public void setPosition(double var1, double var3, double var5) {
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        float f = this.width / 2.0F;
        float f1 = this.height;
        this.boundingBox.setBounds(var1 - f, var3 - this.yOffset + this.yOffset2, var5 - f, var1 + f, var3 - this.yOffset + this.yOffset2 + f1, var5 + f);
    }

    public void setAngles(float var1, float var2) {
        float f = this.rotationPitch;
        float f1 = this.rotationYaw;
        this.rotationYaw = (float)(this.rotationYaw + var1 * 0.15);
        this.rotationPitch = (float)(this.rotationPitch - var2 * 0.15);
        if (this.rotationPitch < -90.0F) {
            this.rotationPitch = -90.0F;
        }

        if (this.rotationPitch > 90.0F) {
            this.rotationPitch = 90.0F;
        }

        this.prevRotationPitch = this.prevRotationPitch + (this.rotationPitch - f);
        this.prevRotationYaw = this.prevRotationYaw + (this.rotationYaw - f1);
    }

    public void onUpdate() {
        this.onEntityUpdate();
    }

    public void onEntityUpdate() {
        this.worldObj.theProfiler.startSection("entityBaseTick");
        if (this.ridingEntity != null && this.ridingEntity.isDead) {
            this.ridingEntity = null;
        }

        this.prevDistanceWalkedModified = this.distanceWalkedModified;
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.prevRotationPitch = this.rotationPitch;
        this.prevRotationYaw = this.rotationYaw;
        if (!this.worldObj.isRemote && this.worldObj instanceof WorldServer) {
            this.worldObj.theProfiler.startSection("portal");
            MinecraftServer minecraftserver = ((WorldServer)this.worldObj).func_73046_m();
            int i = this.getMaxInPortalTime();
            if (this.inPortal) {
                if (minecraftserver.getAllowNether()) {
                    if (this.ridingEntity == null && this.portalCounter++ >= i) {
                        this.portalCounter = i;
                        this.timeUntilPortal = this.getPortalCooldown();
                        byte b0;
                        if (this.worldObj.provider.dimensionId == -1) {
                            b0 = 0;
                        } else {
                            b0 = -1;
                        }

                        this.travelToDimension(b0);
                    }

                    this.inPortal = false;
                }
            } else {
                if (this.portalCounter > 0) {
                    this.portalCounter -= 4;
                }

                if (this.portalCounter < 0) {
                    this.portalCounter = 0;
                }
            }

            if (this.timeUntilPortal > 0) {
                this.timeUntilPortal--;
            }

            this.worldObj.theProfiler.endSection();
        }

        if (this.isSprinting() && !this.isInWater()) {
            int j = MathHelper.floor_double(this.posX);
            int k = MathHelper.floor_double(this.posY - 0.2F - this.yOffset);
            int l = MathHelper.floor_double(this.posZ);
            Block block = this.worldObj.getBlock(j, k, l);
            if (block.getMaterial() != Material.air) {
                this.worldObj
                    .spawnParticle(
                        "blockcrack_" + Block.getIdFromBlock(block) + "_" + this.worldObj.getBlockMetadata(j, k, l),
                        this.posX + (this.rand.nextFloat() - 0.5) * this.width,
                        this.boundingBox.minY + 0.1,
                        this.posZ + (this.rand.nextFloat() - 0.5) * this.width,
                        -this.motionX * 4.0,
                        1.5,
                        -this.motionZ * 4.0
                    );
            }
        }

        this.handleWaterMovement();
        if (this.worldObj.isRemote) {
            this.fire = 0;
        } else if (this.fire > 0) {
            if (this.isImmuneToFire) {
                this.fire -= 4;
                if (this.fire < 0) {
                    this.fire = 0;
                }
            } else {
                if (this.fire % 20 == 0) {
                    this.attackEntityFrom(DamageSource.onFire, 1.0F);
                }

                this.fire--;
            }
        }

        if (this.handleLavaMovement()) {
            this.setOnFireFromLava();
            this.fallDistance *= 0.5F;
        }

        if (this.posY < -64.0) {
            this.kill();
        }

        if (!this.worldObj.isRemote) {
            this.setFlag(0, this.fire > 0);
        }

        this.firstUpdate = false;
        this.worldObj.theProfiler.endSection();
    }

    public int getMaxInPortalTime() {
        return 0;
    }

    protected void setOnFireFromLava() {
        if (!this.isImmuneToFire) {
            this.attackEntityFrom(DamageSource.lava, 4.0F);
            this.setFire(15);
        }
    }

    public void setFire(int var1) {
        int i = var1 * 20;
        i = EnchantmentProtection.getFireTimeForEntity(this, i);
        if (this.fire < i) {
            this.fire = i;
        }
    }

    public void extinguish() {
        this.fire = 0;
    }

    protected void kill() {
        this.setDead();
    }

    public boolean isOffsetPositionInLiquid(double var1, double var3, double var5) {
        AxisAlignedBB axisalignedbb = this.boundingBox.getOffsetBoundingBox(var1, var3, var5);
        List list = this.worldObj.getCollidingBoundingBoxes(this, axisalignedbb);
        return !list.isEmpty() ? false : !this.worldObj.isAnyLiquid(axisalignedbb);
    }

    public void moveEntity(double var1, double var3, double var5) {
        if (this.noClip) {
            this.boundingBox.offset(var1, var3, var5);
            this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0;
            this.posY = this.boundingBox.minY + this.yOffset - this.yOffset2;
            this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0;
        } else {
            this.worldObj.theProfiler.startSection("move");
            this.yOffset2 *= 0.4F;
            double d0 = this.posX;
            double d1 = this.posY;
            double d2 = this.posZ;
            if (this.isInWeb) {
                this.isInWeb = false;
                var1 *= 0.25;
                var3 *= 0.05F;
                var5 *= 0.25;
                this.motionX = 0.0;
                this.motionY = 0.0;
                this.motionZ = 0.0;
            }

            double d3 = var1;
            double d4 = var3;
            double d5 = var5;
            AxisAlignedBB axisalignedbb = this.boundingBox.copy();
            boolean flag = this.onGround && this.isSneaking() && this instanceof EntityPlayer;
            if (flag) {
                double d6 = 0.05;

                while (var1 != 0.0 && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(var1, -1.0, 0.0)).isEmpty()) {
                    if (var1 < d6 && var1 >= -d6) {
                        var1 = 0.0;
                    } else if (var1 > 0.0) {
                        var1 -= d6;
                    } else {
                        var1 += d6;
                    }

                    d3 = var1;
                }

                for (;
                    var5 != 0.0 && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(0.0, -1.0, var5)).isEmpty();
                    d5 = var5
                ) {
                    if (var5 < d6 && var5 >= -d6) {
                        var5 = 0.0;
                    } else if (var5 > 0.0) {
                        var5 -= d6;
                    } else {
                        var5 += d6;
                    }
                }

                while (
                    var1 != 0.0
                        && var5 != 0.0
                        && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(var1, -1.0, var5)).isEmpty()
                ) {
                    if (var1 < d6 && var1 >= -d6) {
                        var1 = 0.0;
                    } else if (var1 > 0.0) {
                        var1 -= d6;
                    } else {
                        var1 += d6;
                    }

                    if (var5 < d6 && var5 >= -d6) {
                        var5 = 0.0;
                    } else if (var5 > 0.0) {
                        var5 -= d6;
                    } else {
                        var5 += d6;
                    }

                    d3 = var1;
                    d5 = var5;
                }
            }

            List list = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(var1, var3, var5));

            for (int i = 0; i < list.size(); i++) {
                var3 = ((AxisAlignedBB)list.get(i)).calculateYOffset(this.boundingBox, var3);
            }

            this.boundingBox.offset(0.0, var3, 0.0);
            if (!this.field_70135_K && d4 != var3) {
                var5 = 0.0;
                var3 = var5;
                var1 = var3;
            }

            boolean flag1 = this.onGround || d4 != var3 && d4 < 0.0;

            for (int j = 0; j < list.size(); j++) {
                var1 = ((AxisAlignedBB)list.get(j)).calculateXOffset(this.boundingBox, var1);
            }

            this.boundingBox.offset(var1, 0.0, 0.0);
            if (!this.field_70135_K && d3 != var1) {
                var5 = 0.0;
                var3 = var5;
                var1 = var3;
            }

            for (int j1 = 0; j1 < list.size(); j1++) {
                var5 = ((AxisAlignedBB)list.get(j1)).calculateZOffset(this.boundingBox, var5);
            }

            this.boundingBox.offset(0.0, 0.0, var5);
            if (!this.field_70135_K && d5 != var5) {
                var5 = 0.0;
                var3 = var5;
                var1 = var3;
            }

            if (this.stepHeight > 0.0F && flag1 && (flag || this.yOffset2 < 0.05F) && (d3 != var1 || d5 != var5)) {
                double d9 = var1;
                double d7 = var3;
                double d8 = var5;
                var1 = d3;
                var3 = this.stepHeight;
                var5 = d5;
                AxisAlignedBB axisalignedbb1 = this.boundingBox.copy();
                this.boundingBox.setBB(axisalignedbb);
                list = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(var1, var3, var5));

                for (int k = 0; k < list.size(); k++) {
                    var3 = ((AxisAlignedBB)list.get(k)).calculateYOffset(this.boundingBox, var3);
                }

                this.boundingBox.offset(0.0, var3, 0.0);
                if (!this.field_70135_K && d4 != var3) {
                    var5 = 0.0;
                    var3 = var5;
                    var1 = var3;
                }

                for (int l1 = 0; l1 < list.size(); l1++) {
                    var1 = ((AxisAlignedBB)list.get(l1)).calculateXOffset(this.boundingBox, var1);
                }

                this.boundingBox.offset(var1, 0.0, 0.0);
                if (!this.field_70135_K && d3 != var1) {
                    var5 = 0.0;
                    var3 = var5;
                    var1 = var3;
                }

                for (int i2 = 0; i2 < list.size(); i2++) {
                    var5 = ((AxisAlignedBB)list.get(i2)).calculateZOffset(this.boundingBox, var5);
                }

                this.boundingBox.offset(0.0, 0.0, var5);
                if (!this.field_70135_K && d5 != var5) {
                    var5 = 0.0;
                    var3 = var5;
                    var1 = var3;
                }

                if (!this.field_70135_K && d4 != var3) {
                    var5 = 0.0;
                    var3 = var5;
                    var1 = var3;
                } else {
                    var3 = -this.stepHeight;

                    for (int j2 = 0; j2 < list.size(); j2++) {
                        var3 = ((AxisAlignedBB)list.get(j2)).calculateYOffset(this.boundingBox, var3);
                    }

                    this.boundingBox.offset(0.0, var3, 0.0);
                }

                if (d9 * d9 + d8 * d8 >= var1 * var1 + var5 * var5) {
                    var1 = d9;
                    var3 = d7;
                    var5 = d8;
                    this.boundingBox.setBB(axisalignedbb1);
                }
            }

            this.worldObj.theProfiler.endSection();
            this.worldObj.theProfiler.startSection("rest");
            this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0;
            this.posY = this.boundingBox.minY + this.yOffset - this.yOffset2;
            this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0;
            this.isCollidedHorizontally = d3 != var1 || d5 != var5;
            this.isCollidedVertically = d4 != var3;
            this.onGround = d4 != var3 && d4 < 0.0;
            this.isCollided = this.isCollidedHorizontally || this.isCollidedVertically;
            this.updateFallState(var3, this.onGround);
            if (d3 != var1) {
                this.motionX = 0.0;
            }

            if (d4 != var3) {
                this.motionY = 0.0;
            }

            if (d5 != var5) {
                this.motionZ = 0.0;
            }

            double d10 = this.posX - d0;
            double d11 = this.posY - d1;
            double d12 = this.posZ - d2;
            if (this.canTriggerWalking() && !flag && this.ridingEntity == null) {
                int k1 = MathHelper.floor_double(this.posX);
                int k2 = MathHelper.floor_double(this.posY - 0.2F - this.yOffset);
                int l = MathHelper.floor_double(this.posZ);
                Block block = this.worldObj.getBlock(k1, k2, l);
                int i1 = this.worldObj.getBlock(k1, k2 - 1, l).getRenderType();
                if (i1 == 11 || i1 == 32 || i1 == 21) {
                    block = this.worldObj.getBlock(k1, k2 - 1, l);
                }

                if (block != Blocks.ladder) {
                    d11 = 0.0;
                }

                this.distanceWalkedModified = (float)(this.distanceWalkedModified + MathHelper.sqrt_double(d10 * d10 + d12 * d12) * 0.6);
                this.distanceWalkedOnStepModified = (float)(this.distanceWalkedOnStepModified + MathHelper.sqrt_double(d10 * d10 + d11 * d11 + d12 * d12) * 0.6);
                if (this.distanceWalkedOnStepModified > this.nextStepDistance && block.getMaterial() != Material.air) {
                    this.nextStepDistance = (int)this.distanceWalkedOnStepModified + 1;
                    if (this.isInWater()) {
                        float f = MathHelper.sqrt_double(this.motionX * this.motionX * 0.2F + this.motionY * this.motionY + this.motionZ * this.motionZ * 0.2F)
                            * 0.35F;
                        if (f > 1.0F) {
                            f = 1.0F;
                        }

                        this.playSound(this.getSwimSound(), f, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
                    }

                    this.playStepSound(k1, k2, l, block);
                    block.onEntityWalking(this.worldObj, k1, k2, l, this);
                }
            }

            try {
                this.doBlockCollisions();
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Checking entity block collision");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being checked for collision");
                this.addEntityCrashInfo(crashreportcategory);
                throw new ReportedException(crashreport);
            }

            boolean flag2 = this.isWet();
            if (this.worldObj.func_147470_e(this.boundingBox.contract(0.001, 0.001, 0.001))) {
                this.dealFireDamage(1);
                if (!flag2) {
                    this.fire++;
                    if (this.fire == 0) {
                        this.setFire(8);
                    }
                }
            } else if (this.fire <= 0) {
                this.fire = -this.fireResistance;
            }

            if (flag2 && this.fire > 0) {
                this.playSound("random.fizz", 0.7F, 1.6F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
                this.fire = -this.fireResistance;
            }

            this.worldObj.theProfiler.endSection();
        }
    }

    protected String getSwimSound() {
        return "game.neutral.swim";
    }

    protected void doBlockCollisions() {
        int i = MathHelper.floor_double(this.boundingBox.minX + 0.001);
        int j = MathHelper.floor_double(this.boundingBox.minY + 0.001);
        int k = MathHelper.floor_double(this.boundingBox.minZ + 0.001);
        int l = MathHelper.floor_double(this.boundingBox.maxX - 0.001);
        int i1 = MathHelper.floor_double(this.boundingBox.maxY - 0.001);
        int j1 = MathHelper.floor_double(this.boundingBox.maxZ - 0.001);
        if (this.worldObj.checkChunksExist(i, j, k, l, i1, j1)) {
            for (int k1 = i; k1 <= l; k1++) {
                for (int l1 = j; l1 <= i1; l1++) {
                    for (int i2 = k; i2 <= j1; i2++) {
                        Block block = this.worldObj.getBlock(k1, l1, i2);

                        try {
                            block.onEntityCollidedWithBlock(this.worldObj, k1, l1, i2, this);
                        } catch (Throwable throwable) {
                            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Colliding entity with block");
                            CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being collided with");
                            CrashReportCategory.addBlockInfo(crashreportcategory, k1, l1, i2, block, this.worldObj.getBlockMetadata(k1, l1, i2));
                            throw new ReportedException(crashreport);
                        }
                    }
                }
            }
        }
    }

    protected void playStepSound(int var1, int var2, int var3, Block var4) {
        Block.SoundType block$soundtype = var4.stepSound;
        if (this.worldObj.getBlock(var1, var2 + 1, var3) == Blocks.snow_layer) {
            block$soundtype = Blocks.snow_layer.stepSound;
            this.playSound(block$soundtype.getStepSound(), block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
        } else if (!var4.getMaterial().isLiquid()) {
            this.playSound(block$soundtype.getStepSound(), block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
        }
    }

    public void playSound(String var1, float var2, float var3) {
        this.worldObj.playSoundAtEntity(this, var1, var2, var3);
    }

    protected boolean canTriggerWalking() {
        return true;
    }

    protected void updateFallState(double var1, boolean var3) {
        if (var3) {
            if (this.fallDistance > 0.0F) {
                this.fall(this.fallDistance);
                this.fallDistance = 0.0F;
            }
        } else if (var1 < 0.0) {
            this.fallDistance = (float)(this.fallDistance - var1);
        }
    }

    public AxisAlignedBB getBoundingBox() {
        return null;
    }

    protected void dealFireDamage(int var1) {
        if (!this.isImmuneToFire) {
            this.attackEntityFrom(DamageSource.inFire, var1);
        }
    }

    public final boolean isImmuneToFire() {
        return this.isImmuneToFire;
    }

    protected void fall(float var1) {
        if (this.riddenByEntity != null) {
            this.riddenByEntity.fall(var1);
        }
    }

    public boolean isWet() {
        return this.inWater
            || this.worldObj.isRainingAt(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))
            || this.worldObj
                .isRainingAt(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY + this.height), MathHelper.floor_double(this.posZ));
    }

    public boolean isInWater() {
        return this.inWater;
    }

    public boolean handleWaterMovement() {
        if (this.worldObj.handleMaterialAcceleration(this.boundingBox.expand(0.0, -0.4F, 0.0).contract(0.001, 0.001, 0.001), Material.water, this)) {
            if (!this.inWater && !this.firstUpdate) {
                float f = MathHelper.sqrt_double(this.motionX * this.motionX * 0.2F + this.motionY * this.motionY + this.motionZ * this.motionZ * 0.2F) * 0.2F;
                if (f > 1.0F) {
                    f = 1.0F;
                }

                this.playSound(this.getSplashSound(), f, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
                float f1 = MathHelper.floor_double(this.boundingBox.minY);

                for (int i = 0; i < 1.0F + this.width * 20.0F; i++) {
                    float f2 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
                    float f3 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
                    this.worldObj
                        .spawnParticle(
                            "bubble", this.posX + f2, f1 + 1.0F, this.posZ + f3, this.motionX, this.motionY - this.rand.nextFloat() * 0.2F, this.motionZ
                        );
                }

                for (int j = 0; j < 1.0F + this.width * 20.0F; j++) {
                    float f4 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
                    float f5 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
                    this.worldObj.spawnParticle("splash", this.posX + f4, f1 + 1.0F, this.posZ + f5, this.motionX, this.motionY, this.motionZ);
                }
            }

            this.fallDistance = 0.0F;
            this.inWater = true;
            this.fire = 0;
        } else {
            this.inWater = false;
        }

        return this.inWater;
    }

    protected String getSplashSound() {
        return "game.neutral.swim.splash";
    }

    public boolean isInsideOfMaterial(Material var1) {
        double d0 = this.posY + this.getEyeHeight();
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_float(MathHelper.floor_double(d0));
        int k = MathHelper.floor_double(this.posZ);
        Block block = this.worldObj.getBlock(i, j, k);
        if (block.getMaterial() == var1) {
            float f = BlockLiquid.getLiquidHeightPercent(this.worldObj.getBlockMetadata(i, j, k)) - 1.0F / 9.0F;
            float f1 = j + 1 - f;
            return d0 < f1;
        } else {
            return false;
        }
    }

    public float getEyeHeight() {
        return 0.0F;
    }

    public boolean handleLavaMovement() {
        return this.worldObj.isMaterialInBB(this.boundingBox.expand(-0.1F, -0.4F, -0.1F), Material.lava);
    }

    public void moveFlying(float var1, float var2, float var3) {
        float f = var1 * var1 + var2 * var2;
        if (!(f < 1.0E-4F)) {
            f = MathHelper.sqrt_float(f);
            if (f < 1.0F) {
                f = 1.0F;
            }

            f = var3 / f;
            var1 *= f;
            var2 *= f;
            float f1 = MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F);
            float f2 = MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F);
            this.motionX += var1 * f2 - var2 * f1;
            this.motionZ += var2 * f2 + var1 * f1;
        }
    }

    public int getBrightnessForRender(float var1) {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posZ);
        if (this.worldObj.blockExists(i, 0, j)) {
            double d0 = (this.boundingBox.maxY - this.boundingBox.minY) * 0.66;
            int k = MathHelper.floor_double(this.posY - this.yOffset + d0);
            return this.worldObj.getLightBrightnessForSkyBlocks(i, k, j, 0);
        } else {
            return 0;
        }
    }

    public float getBrightness(float var1) {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posZ);
        if (this.worldObj.blockExists(i, 0, j)) {
            double d0 = (this.boundingBox.maxY - this.boundingBox.minY) * 0.66;
            int k = MathHelper.floor_double(this.posY - this.yOffset + d0);
            return this.worldObj.getLightBrightness(i, k, j);
        } else {
            return 0.0F;
        }
    }

    public void setWorld(World var1) {
        this.worldObj = var1;
    }

    public void setPositionAndRotation(double var1, double var3, double var5, float var7, float var8) {
        this.prevPosX = this.posX = var1;
        this.prevPosY = this.posY = var3;
        this.prevPosZ = this.posZ = var5;
        this.prevRotationYaw = this.rotationYaw = var7;
        this.prevRotationPitch = this.rotationPitch = var8;
        this.yOffset2 = 0.0F;
        double d0 = this.prevRotationYaw - var7;
        if (d0 < -180.0) {
            this.prevRotationYaw += 360.0F;
        }

        if (d0 >= 180.0) {
            this.prevRotationYaw -= 360.0F;
        }

        this.setPosition(this.posX, this.posY, this.posZ);
        this.setRotation(var7, var8);
    }

    public void setLocationAndAngles(double var1, double var3, double var5, float var7, float var8) {
        this.lastTickPosX = this.prevPosX = this.posX = var1;
        this.lastTickPosY = this.prevPosY = this.posY = var3 + this.yOffset;
        this.lastTickPosZ = this.prevPosZ = this.posZ = var5;
        this.rotationYaw = var7;
        this.rotationPitch = var8;
        this.setPosition(this.posX, this.posY, this.posZ);
    }

    public float getDistanceToEntity(Entity var1) {
        float f = (float)(this.posX - var1.posX);
        float f1 = (float)(this.posY - var1.posY);
        float f2 = (float)(this.posZ - var1.posZ);
        return MathHelper.sqrt_float(f * f + f1 * f1 + f2 * f2);
    }

    public double getDistanceSq(double var1, double var3, double var5) {
        double d0 = this.posX - var1;
        double d1 = this.posY - var3;
        double d2 = this.posZ - var5;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public double getDistance(double var1, double var3, double var5) {
        double d0 = this.posX - var1;
        double d1 = this.posY - var3;
        double d2 = this.posZ - var5;
        return MathHelper.sqrt_double(d0 * d0 + d1 * d1 + d2 * d2);
    }

    public double getDistanceSqToEntity(Entity var1) {
        double d0 = this.posX - var1.posX;
        double d1 = this.posY - var1.posY;
        double d2 = this.posZ - var1.posZ;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public void onCollideWithPlayer(EntityPlayer var1) {
    }

    public void applyEntityCollision(Entity var1) {
        if (var1.riddenByEntity != this && var1.ridingEntity != this) {
            double d0 = var1.posX - this.posX;
            double d1 = var1.posZ - this.posZ;
            double d2 = MathHelper.abs_max(d0, d1);
            if (d2 >= 0.01F) {
                d2 = MathHelper.sqrt_double(d2);
                d0 /= d2;
                d1 /= d2;
                double d3 = 1.0 / d2;
                if (d3 > 1.0) {
                    d3 = 1.0;
                }

                d0 *= d3;
                d1 *= d3;
                d0 *= 0.05F;
                d1 *= 0.05F;
                d0 *= 1.0F - this.entityCollisionReduction;
                d1 *= 1.0F - this.entityCollisionReduction;
                this.addVelocity(-d0, 0.0, -d1);
                var1.addVelocity(d0, 0.0, d1);
            }
        }
    }

    public void addVelocity(double var1, double var3, double var5) {
        this.motionX += var1;
        this.motionY += var3;
        this.motionZ += var5;
        this.isAirBorne = true;
    }

    protected void setBeenAttacked() {
        this.velocityChanged = true;
    }

    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        this.setBeenAttacked();
        return false;
    }

    public boolean canBeCollidedWith() {
        return false;
    }

    public boolean canBePushed() {
        return false;
    }

    public void addToPlayerScore(Entity var1, int var2) {
    }

    public boolean isInRangeToRender3d(double var1, double var3, double var5) {
        double d0 = this.posX - var1;
        double d1 = this.posY - var3;
        double d2 = this.posZ - var5;
        double d3 = d0 * d0 + d1 * d1 + d2 * d2;
        return this.isInRangeToRenderDist(d3);
    }

    public boolean isInRangeToRenderDist(double var1) {
        double d0 = this.boundingBox.getAverageEdgeLength();
        d0 *= 64.0 * this.renderDistanceWeight;
        return var1 < d0 * d0;
    }

    public boolean writeMountToNBT(NBTTagCompound var1) {
        String s = this.getEntityString();
        if (!this.isDead && s != null) {
            var1.setString("id", s);
            this.writeToNBT(var1);
            return true;
        } else {
            return false;
        }
    }

    public boolean writeToNBTOptional(NBTTagCompound var1) {
        String s = this.getEntityString();
        if (!this.isDead && s != null && this.riddenByEntity == null) {
            var1.setString("id", s);
            this.writeToNBT(var1);
            return true;
        } else {
            return false;
        }
    }

    public void writeToNBT(NBTTagCompound var1) {
        try {
            var1.setTag("Pos", this.newDoubleNBTList(this.posX, this.posY + this.yOffset2, this.posZ));
            var1.setTag("Motion", this.newDoubleNBTList(this.motionX, this.motionY, this.motionZ));
            var1.setTag("Rotation", this.newFloatNBTList(this.rotationYaw, this.rotationPitch));
            var1.setFloat("FallDistance", this.fallDistance);
            var1.setShort("Fire", (short)this.fire);
            var1.setShort("Air", (short)this.getAir());
            var1.setBoolean("OnGround", this.onGround);
            var1.setInteger("Dimension", this.dimension);
            var1.setBoolean("Invulnerable", this.invulnerable);
            var1.setInteger("PortalCooldown", this.timeUntilPortal);
            var1.setLong("UUIDMost", this.getUniqueID().getMostSignificantBits());
            var1.setLong("UUIDLeast", this.getUniqueID().getLeastSignificantBits());
            this.writeEntityToNBT(var1);
            if (this.ridingEntity != null) {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                if (this.ridingEntity.writeMountToNBT(nbttagcompound)) {
                    var1.setTag("Riding", nbttagcompound);
                }
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Saving entity NBT");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being saved");
            this.addEntityCrashInfo(crashreportcategory);
            throw new ReportedException(crashreport);
        }
    }

    public void readFromNBT(NBTTagCompound var1) {
        try {
            NBTTagList nbttaglist = var1.getTagList("Pos", 6);
            NBTTagList nbttaglist1 = var1.getTagList("Motion", 6);
            NBTTagList nbttaglist2 = var1.getTagList("Rotation", 5);
            this.motionX = nbttaglist1.getDoubleAt(0);
            this.motionY = nbttaglist1.getDoubleAt(1);
            this.motionZ = nbttaglist1.getDoubleAt(2);
            if (Math.abs(this.motionX) > 10.0) {
                this.motionX = 0.0;
            }

            if (Math.abs(this.motionY) > 10.0) {
                this.motionY = 0.0;
            }

            if (Math.abs(this.motionZ) > 10.0) {
                this.motionZ = 0.0;
            }

            this.prevPosX = this.lastTickPosX = this.posX = nbttaglist.getDoubleAt(0);
            this.prevPosY = this.lastTickPosY = this.posY = nbttaglist.getDoubleAt(1);
            this.prevPosZ = this.lastTickPosZ = this.posZ = nbttaglist.getDoubleAt(2);
            this.prevRotationYaw = this.rotationYaw = nbttaglist2.getFloatAt(0);
            this.prevRotationPitch = this.rotationPitch = nbttaglist2.getFloatAt(1);
            this.fallDistance = var1.getFloat("FallDistance");
            this.fire = var1.getShort("Fire");
            this.setAir(var1.getShort("Air"));
            this.onGround = var1.getBoolean("OnGround");
            this.dimension = var1.getInteger("Dimension");
            this.invulnerable = var1.getBoolean("Invulnerable");
            this.timeUntilPortal = var1.getInteger("PortalCooldown");
            if (var1.hasKey("UUIDMost", 4) && var1.hasKey("UUIDLeast", 4)) {
                this.entityUniqueID = new UUID(var1.getLong("UUIDMost"), var1.getLong("UUIDLeast"));
            }

            this.setPosition(this.posX, this.posY, this.posZ);
            this.setRotation(this.rotationYaw, this.rotationPitch);
            this.readEntityFromNBT(var1);
            if (this.shouldSetPosAfterLoading()) {
                this.setPosition(this.posX, this.posY, this.posZ);
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Loading entity NBT");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being loaded");
            this.addEntityCrashInfo(crashreportcategory);
            throw new ReportedException(crashreport);
        }
    }

    protected boolean shouldSetPosAfterLoading() {
        return true;
    }

    protected final String getEntityString() {
        return EntityList.getEntityString(this);
    }

    protected abstract void readEntityFromNBT(NBTTagCompound var1);

    protected abstract void writeEntityToNBT(NBTTagCompound var1);

    public void onChunkLoad() {
    }

    protected NBTTagList newDoubleNBTList(double... var1) {
        NBTTagList nbttaglist = new NBTTagList();

        for (double d0 : var1) {
            nbttaglist.appendTag(new NBTTagDouble(d0));
        }

        return nbttaglist;
    }

    protected NBTTagList newFloatNBTList(float... var1) {
        NBTTagList nbttaglist = new NBTTagList();

        for (float f : var1) {
            nbttaglist.appendTag(new NBTTagFloat(f));
        }

        return nbttaglist;
    }

    public float getShadowSize() {
        return this.height / 2.0F;
    }

    public EntityItem dropItem(Item var1, int var2) {
        return this.dropItemWithOffset(var1, var2, 0.0F);
    }

    public EntityItem dropItemWithOffset(Item var1, int var2, float var3) {
        return this.entityDropItem(new ItemStack(var1, var2, 0), var3);
    }

    public EntityItem entityDropItem(ItemStack var1, float var2) {
        if (var1.stackSize != 0 && var1.getItem() != null) {
            EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY + var2, this.posZ, var1);
            entityitem.delayBeforeCanPickup = 10;
            this.worldObj.spawnEntityInWorld(entityitem);
            return entityitem;
        } else {
            return null;
        }
    }

    public boolean isEntityAlive() {
        return !this.isDead;
    }

    public boolean isEntityInsideOpaqueBlock() {
        for (int i = 0; i < 8; i++) {
            float f = ((i >> 0) % 2 - 0.5F) * this.width * 0.8F;
            float f1 = ((i >> 1) % 2 - 0.5F) * 0.1F;
            float f2 = ((i >> 2) % 2 - 0.5F) * this.width * 0.8F;
            int j = MathHelper.floor_double(this.posX + f);
            int k = MathHelper.floor_double(this.posY + this.getEyeHeight() + f1);
            int l = MathHelper.floor_double(this.posZ + f2);
            if (this.worldObj.getBlock(j, k, l).isNormalCube()) {
                return true;
            }
        }

        return false;
    }

    public boolean interactFirst(EntityPlayer var1) {
        return false;
    }

    public AxisAlignedBB getCollisionBox(Entity var1) {
        return null;
    }

    public void updateRidden() {
        if (this.ridingEntity.isDead) {
            this.ridingEntity = null;
        } else {
            this.motionX = 0.0;
            this.motionY = 0.0;
            this.motionZ = 0.0;
            this.onUpdate();
            if (this.ridingEntity != null) {
                this.ridingEntity.updateRiderPosition();
                this.entityRiderYawDelta = this.entityRiderYawDelta + (this.ridingEntity.rotationYaw - this.ridingEntity.prevRotationYaw);
                this.entityRiderPitchDelta = this.entityRiderPitchDelta + (this.ridingEntity.rotationPitch - this.ridingEntity.prevRotationPitch);

                while (this.entityRiderYawDelta >= 180.0) {
                    this.entityRiderYawDelta -= 360.0;
                }

                while (this.entityRiderYawDelta < -180.0) {
                    this.entityRiderYawDelta += 360.0;
                }

                while (this.entityRiderPitchDelta >= 180.0) {
                    this.entityRiderPitchDelta -= 360.0;
                }

                while (this.entityRiderPitchDelta < -180.0) {
                    this.entityRiderPitchDelta += 360.0;
                }

                double d0 = this.entityRiderYawDelta * 0.5;
                double d1 = this.entityRiderPitchDelta * 0.5;
                float f = 10.0F;
                if (d0 > f) {
                    d0 = f;
                }

                if (d0 < -f) {
                    d0 = -f;
                }

                if (d1 > f) {
                    d1 = f;
                }

                if (d1 < -f) {
                    d1 = -f;
                }

                this.entityRiderYawDelta -= d0;
                this.entityRiderPitchDelta -= d1;
            }
        }
    }

    public void updateRiderPosition() {
        if (this.riddenByEntity != null) {
            this.riddenByEntity.setPosition(this.posX, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ);
        }
    }

    public double getYOffset() {
        return this.yOffset;
    }

    public double getMountedYOffset() {
        return this.height * 0.75;
    }

    public void mountEntity(Entity var1) {
        this.entityRiderPitchDelta = 0.0;
        this.entityRiderYawDelta = 0.0;
        if (var1 == null) {
            if (this.ridingEntity != null) {
                this.setLocationAndAngles(
                    this.ridingEntity.posX,
                    this.ridingEntity.boundingBox.minY + this.ridingEntity.height,
                    this.ridingEntity.posZ,
                    this.rotationYaw,
                    this.rotationPitch
                );
                this.ridingEntity.riddenByEntity = null;
            }

            this.ridingEntity = null;
        } else {
            if (this.ridingEntity != null) {
                this.ridingEntity.riddenByEntity = null;
            }

            if (var1 != null) {
                for (Entity entity = var1.ridingEntity; entity != null; entity = entity.ridingEntity) {
                    if (entity == this) {
                        return;
                    }
                }
            }

            this.ridingEntity = var1;
            var1.riddenByEntity = this;
        }
    }

    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9) {
        this.setPosition(var1, var3, var5);
        this.setRotation(var7, var8);
        List list = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.contract(1.0 / 32.0, 0.0, 1.0 / 32.0));
        if (!list.isEmpty()) {
            double d0 = 0.0;

            for (int i = 0; i < list.size(); i++) {
                AxisAlignedBB axisalignedbb = (AxisAlignedBB)list.get(i);
                if (axisalignedbb.maxY > d0) {
                    d0 = axisalignedbb.maxY;
                }
            }

            var3 += d0 - this.boundingBox.minY;
            this.setPosition(var1, var3, var5);
        }
    }

    public float getCollisionBorderSize() {
        return 0.1F;
    }

    public Vec3 getLookVec() {
        return null;
    }

    public void setInPortal() {
        if (this.timeUntilPortal > 0) {
            this.timeUntilPortal = this.getPortalCooldown();
        } else {
            double d0 = this.prevPosX - this.posX;
            double d1 = this.prevPosZ - this.posZ;
            if (!this.worldObj.isRemote && !this.inPortal) {
                this.teleportDirection = Direction.getMovementDirection(d0, d1);
            }

            this.inPortal = true;
        }
    }

    public int getPortalCooldown() {
        return 300;
    }

    public void setVelocity(double var1, double var3, double var5) {
        this.motionX = var1;
        this.motionY = var3;
        this.motionZ = var5;
    }

    public void handleHealthUpdate(byte var1) {
    }

    public void performHurtAnimation() {
    }

    public ItemStack[] getInventory() {
        return null;
    }

    public void setCurrentItemOrArmor(int var1, ItemStack var2) {
    }

    public boolean isBurning() {
        boolean flag = this.worldObj != null && this.worldObj.isRemote;
        return !this.isImmuneToFire && (this.fire > 0 || flag && this.getFlag(0));
    }

    public boolean isRiding() {
        return this.ridingEntity != null;
    }

    public boolean isSneaking() {
        return this.getFlag(1);
    }

    public void setSneaking(boolean var1) {
        this.setFlag(1, var1);
    }

    public boolean isSprinting() {
        return this.getFlag(3);
    }

    public void setSprinting(boolean var1) {
        this.setFlag(3, var1);
    }

    public boolean isInvisible() {
        return this.getFlag(5);
    }

    public boolean isInvisibleToPlayer(EntityPlayer var1) {
        return this.isInvisible();
    }

    public void setInvisible(boolean var1) {
        this.setFlag(5, var1);
    }

    public boolean isEating() {
        return this.getFlag(4);
    }

    public void setEating(boolean var1) {
        this.setFlag(4, var1);
    }

    protected boolean getFlag(int var1) {
        return (this.dataWatcher.getWatchableObjectByte(0) & 1 << var1) != 0;
    }

    protected void setFlag(int var1, boolean var2) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(0);
        if (var2) {
            this.dataWatcher.updateObject(0, (byte)(b0 | 1 << var1));
        } else {
            this.dataWatcher.updateObject(0, (byte)(b0 & ~(1 << var1)));
        }
    }

    public int getAir() {
        return this.dataWatcher.getWatchableObjectShort(1);
    }

    public void setAir(int var1) {
        this.dataWatcher.updateObject(1, (short)var1);
    }

    public void onStruckByLightning(EntityLightningBolt var1) {
        this.dealFireDamage(5);
        this.fire++;
        if (this.fire == 0) {
            this.setFire(8);
        }
    }

    public void onKillEntity(EntityLivingBase var1) {
    }

    protected boolean pushOutOfBlocks(double var1, double var3, double var5) {
        int i = MathHelper.floor_double(var1);
        int j = MathHelper.floor_double(var3);
        int k = MathHelper.floor_double(var5);
        double d0 = var1 - i;
        double d1 = var3 - j;
        double d2 = var5 - k;
        List list = this.worldObj.func_147461_a(this.boundingBox);
        if (list.isEmpty() && !this.worldObj.isBlockFullCube(i, j, k)) {
            return false;
        }

        boolean flag = !this.worldObj.isBlockFullCube(i - 1, j, k);
        boolean flag1 = !this.worldObj.isBlockFullCube(i + 1, j, k);
        boolean flag2 = !this.worldObj.isBlockFullCube(i, j - 1, k);
        boolean flag3 = !this.worldObj.isBlockFullCube(i, j + 1, k);
        boolean flag4 = !this.worldObj.isBlockFullCube(i, j, k - 1);
        boolean flag5 = !this.worldObj.isBlockFullCube(i, j, k + 1);
        byte b0 = 3;
        double d3 = 9999.0;
        if (flag && d0 < d3) {
            d3 = d0;
            b0 = 0;
        }

        if (flag1 && 1.0 - d0 < d3) {
            d3 = 1.0 - d0;
            b0 = 1;
        }

        if (flag3 && 1.0 - d1 < d3) {
            d3 = 1.0 - d1;
            b0 = 3;
        }

        if (flag4 && d2 < d3) {
            d3 = d2;
            b0 = 4;
        }

        if (flag5 && 1.0 - d2 < d3) {
            d3 = 1.0 - d2;
            b0 = 5;
        }

        float f = this.rand.nextFloat() * 0.2F + 0.1F;
        if (b0 == 0) {
            this.motionX = -f;
        }

        if (b0 == 1) {
            this.motionX = f;
        }

        if (b0 == 2) {
            this.motionY = -f;
        }

        if (b0 == 3) {
            this.motionY = f;
        }

        if (b0 == 4) {
            this.motionZ = -f;
        }

        if (b0 == 5) {
            this.motionZ = f;
        }

        return true;
    }

    public void setInWeb() {
        this.isInWeb = true;
        this.fallDistance = 0.0F;
    }

    public String getCommandSenderName() {
        String s = EntityList.getEntityString(this);
        if (s == null) {
            s = "generic";
        }

        return StatCollector.translateToLocal("entity." + s + ".name");
    }

    public Entity[] getParts() {
        return null;
    }

    public boolean isEntityEqual(Entity var1) {
        return this == var1;
    }

    public float getRotationYawHead() {
        return 0.0F;
    }

    public void setRotationYawHead(float var1) {
    }

    public boolean canAttackWithItem() {
        return true;
    }

    public boolean hitByEntity(Entity var1) {
        return false;
    }

    @Override
    public String toString() {
        return String.format(
            "%s['%s'/%d, l='%s', x=%.2f, y=%.2f, z=%.2f]",
            this.getClass().getSimpleName(),
            this.getCommandSenderName(),
            this.entityId,
            this.worldObj == null ? "~NULL~" : this.worldObj.getWorldInfo().getWorldName(),
            this.posX,
            this.posY,
            this.posZ
        );
    }

    public boolean isEntityInvulnerable() {
        return this.invulnerable;
    }

    public void copyLocationAndAnglesFrom(Entity var1) {
        this.setLocationAndAngles(var1.posX, var1.posY, var1.posZ, var1.rotationYaw, var1.rotationPitch);
    }

    public void copyDataFrom(Entity var1, boolean var2) {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        var1.writeToNBT(nbttagcompound);
        this.readFromNBT(nbttagcompound);
        this.timeUntilPortal = var1.timeUntilPortal;
        this.teleportDirection = var1.teleportDirection;
    }

    public void travelToDimension(int var1) {
        if (!this.worldObj.isRemote && !this.isDead) {
            this.worldObj.theProfiler.startSection("changeDimension");
            MinecraftServer minecraftserver = MinecraftServer.getServer();
            int i = this.dimension;
            WorldServer worldserver = minecraftserver.worldServerForDimension(i);
            WorldServer worldserver1 = minecraftserver.worldServerForDimension(var1);
            this.dimension = var1;
            if (i == 1 && var1 == 1) {
                worldserver1 = minecraftserver.worldServerForDimension(0);
                this.dimension = 0;
            }

            this.worldObj.removeEntity(this);
            this.isDead = false;
            this.worldObj.theProfiler.startSection("reposition");
            minecraftserver.getConfigurationManager().transferEntityToWorld(this, i, worldserver, worldserver1);
            this.worldObj.theProfiler.endStartSection("reloading");
            Entity entity = EntityList.createEntityByName(EntityList.getEntityString(this), worldserver1);
            if (entity != null) {
                entity.copyDataFrom(this, true);
                if (i == 1 && var1 == 1) {
                    ChunkCoordinates chunkcoordinates = worldserver1.getSpawnPoint();
                    chunkcoordinates.posY = this.worldObj.getTopSolidOrLiquidBlock(chunkcoordinates.posX, chunkcoordinates.posZ);
                    entity.setLocationAndAngles(chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ, entity.rotationYaw, entity.rotationPitch);
                }

                worldserver1.spawnEntityInWorld(entity);
            }

            this.isDead = true;
            this.worldObj.theProfiler.endSection();
            worldserver.resetUpdateEntityTick();
            worldserver1.resetUpdateEntityTick();
            this.worldObj.theProfiler.endSection();
        }
    }

    public float getExplosionResistance(Explosion var1, World var2, int var3, int var4, int var5, Block var6) {
        return var6.getExplosionResistance(this);
    }

    public boolean func_145774_a(Explosion var1, World var2, int var3, int var4, int var5, Block var6, float var7) {
        return true;
    }

    public int getMaxFallHeight() {
        return 3;
    }

    public int getTeleportDirection() {
        return this.teleportDirection;
    }

    public boolean doesEntityNotTriggerPressurePlate() {
        return false;
    }

    public void addEntityCrashInfo(CrashReportCategory var1) {
        var1.addCrashSectionCallable("Entity Type", new Callable() {
            public String call() {
                return EntityList.getEntityString(Entity.this) + " (" + Entity.this.getClass().getCanonicalName() + ")";
            }
        });
        var1.addCrashSection("Entity ID", this.entityId);
        var1.addCrashSectionCallable("Entity Name", new Callable() {
            public String call() {
                return Entity.this.getCommandSenderName();
            }
        });
        var1.addCrashSection("Entity's Exact location", String.format("%.2f, %.2f, %.2f", this.posX, this.posY, this.posZ));
        var1.addCrashSection(
            "Entity's Block location",
            CrashReportCategory.getLocationInfo(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))
        );
        var1.addCrashSection("Entity's Momentum", String.format("%.2f, %.2f, %.2f", this.motionX, this.motionY, this.motionZ));
    }

    public boolean canRenderOnFire() {
        return this.isBurning();
    }

    public UUID getUniqueID() {
        return this.entityUniqueID;
    }

    public boolean isPushedByWater() {
        return true;
    }

    public IChatComponent getFormattedCommandSenderName() {
        return new ChatComponentText(this.getCommandSenderName());
    }

    public void func_145781_i(int var1) {
    }

    public enum EnumEntitySize {
        SIZE_1,
        SIZE_2,
        SIZE_3,
        SIZE_4,
        SIZE_5,
        SIZE_6;

        public int multiplyBy32AndRound(double var1) {
            double d0 = var1 - (MathHelper.floor_double(var1) + 0.5);
            switch (this) {
                case SIZE_1:
                    return (d0 < 0.0 ? !(d0 < -0.3125) : !(d0 < 0.3125)) ? MathHelper.floor_double(var1 * 32.0) : MathHelper.ceiling_double_int(var1 * 32.0);
                case SIZE_2:
                    if (d0 < 0.0 ? !(d0 < -0.3125) : !(d0 < 0.3125)) {
                        return MathHelper.ceiling_double_int(var1 * 32.0);
                    }

                    return MathHelper.floor_double(var1 * 32.0);
                case SIZE_3:
                    if (d0 > 0.0) {
                        return MathHelper.floor_double(var1 * 32.0);
                    }

                    return MathHelper.ceiling_double_int(var1 * 32.0);
                case SIZE_4:
                    if (d0 < 0.0 ? !(d0 < -0.1875) : !(d0 < 0.1875)) {
                        return MathHelper.floor_double(var1 * 32.0);
                    }

                    return MathHelper.ceiling_double_int(var1 * 32.0);
                case SIZE_5:
                    if (d0 < 0.0 ? !(d0 < -0.1875) : !(d0 < 0.1875)) {
                        return MathHelper.ceiling_double_int(var1 * 32.0);
                    }

                    return MathHelper.floor_double(var1 * 32.0);
                case SIZE_6:
                default:
                    return d0 > 0.0 ? MathHelper.ceiling_double_int(var1 * 32.0) : MathHelper.floor_double(var1 * 32.0);
            }
        }
    }
}
