package net.minecraft.entity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.ReportedException;
import org.apache.commons.lang3.ObjectUtils;

public class DataWatcher {
    private final Entity field_151511_a;
    private boolean isBlank = true;
    private static final HashMap dataTypes = new HashMap();
    private final Map watchedObjects = new HashMap();
    private boolean objectChanged;
    private ReadWriteLock lock = new ReentrantReadWriteLock();

    public DataWatcher(Entity var1) {
        this.field_151511_a = var1;
    }

    public void addObject(int var1, Object var2) {
        Integer integer = (Integer)dataTypes.get(var2.getClass());
        if (integer == null) {
            throw new IllegalArgumentException("Unknown data type: " + var2.getClass());
        }

        if (var1 > 31) {
            throw new IllegalArgumentException("Data value id is too big with " + var1 + "! (Max is " + 31 + ")");
        }

        if (this.watchedObjects.containsKey(var1)) {
            throw new IllegalArgumentException("Duplicate id value for " + var1 + "!");
        }

        DataWatcher.WatchableObject datawatcher$watchableobject = new DataWatcher.WatchableObject(integer, var1, var2);
        this.lock.writeLock().lock();
        this.watchedObjects.put(var1, datawatcher$watchableobject);
        this.lock.writeLock().unlock();
        this.isBlank = false;
    }

    public void addObjectByDataType(int var1, int var2) {
        DataWatcher.WatchableObject datawatcher$watchableobject = new DataWatcher.WatchableObject(var2, var1, null);
        this.lock.writeLock().lock();
        this.watchedObjects.put(var1, datawatcher$watchableobject);
        this.lock.writeLock().unlock();
        this.isBlank = false;
    }

    public byte getWatchableObjectByte(int var1) {
        return (Byte)this.getWatchedObject(var1).getObject();
    }

    public short getWatchableObjectShort(int var1) {
        return (Short)this.getWatchedObject(var1).getObject();
    }

    public int getWatchableObjectInt(int var1) {
        return (Integer)this.getWatchedObject(var1).getObject();
    }

    public float getWatchableObjectFloat(int var1) {
        return (Float)this.getWatchedObject(var1).getObject();
    }

    public String getWatchableObjectString(int var1) {
        return (String)this.getWatchedObject(var1).getObject();
    }

    public ItemStack getWatchableObjectItemStack(int var1) {
        return (ItemStack)this.getWatchedObject(var1).getObject();
    }

    private DataWatcher.WatchableObject getWatchedObject(int var1) {
        this.lock.readLock().lock();

        DataWatcher.WatchableObject datawatcher$watchableobject;
        try {
            datawatcher$watchableobject = (DataWatcher.WatchableObject)this.watchedObjects.get(var1);
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Getting synched entity data");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Synched entity data");
            crashreportcategory.addCrashSection("Data ID", var1);
            throw new ReportedException(crashreport);
        }

        this.lock.readLock().unlock();
        return datawatcher$watchableobject;
    }

    public void updateObject(int var1, Object var2) {
        DataWatcher.WatchableObject datawatcher$watchableobject = this.getWatchedObject(var1);
        if (ObjectUtils.notEqual(var2, datawatcher$watchableobject.getObject())) {
            datawatcher$watchableobject.setObject(var2);
            this.field_151511_a.func_145781_i(var1);
            datawatcher$watchableobject.setWatched(true);
            this.objectChanged = true;
        }
    }

    public void setObjectWatched(int var1) {
        this.getWatchedObject(var1).watched = true;
        this.objectChanged = true;
    }

    public boolean hasObjectChanged() {
        return this.objectChanged;
    }

    public static void writeWatchedListToPacketBuffer(List var0, PacketBuffer var1) throws IOException {
        if (var0 != null) {
            for (DataWatcher.WatchableObject datawatcher$watchableobject : (Iterable<DataWatcher.WatchableObject>) (Iterable) var0) {
                writeWatchableObjectToPacketBuffer(var1, datawatcher$watchableobject);
            }
        }

        var1.writeByte(127);
    }

    public List getChanged() {
        ArrayList arraylist = null;
        if (this.objectChanged) {
            this.lock.readLock().lock();

            for (DataWatcher.WatchableObject datawatcher$watchableobject : (Iterable<DataWatcher.WatchableObject>) (Iterable) this.watchedObjects.values()) {
                if (datawatcher$watchableobject.isWatched()) {
                    datawatcher$watchableobject.setWatched(false);
                    if (arraylist == null) {
                        arraylist = new ArrayList();
                    }

                    arraylist.add(datawatcher$watchableobject);
                }
            }

            this.lock.readLock().unlock();
        }

        this.objectChanged = false;
        return arraylist;
    }

    public void func_151509_a(PacketBuffer var1) throws IOException {
        this.lock.readLock().lock();

        for (DataWatcher.WatchableObject datawatcher$watchableobject : (Iterable<DataWatcher.WatchableObject>) (Iterable) this.watchedObjects.values()) {
            writeWatchableObjectToPacketBuffer(var1, datawatcher$watchableobject);
        }

        this.lock.readLock().unlock();
        var1.writeByte(127);
    }

    public List getAllWatched() {
        ArrayList arraylist = null;
        this.lock.readLock().lock();

        for (DataWatcher.WatchableObject datawatcher$watchableobject : (Iterable<DataWatcher.WatchableObject>) (Iterable) this.watchedObjects.values()) {
            if (arraylist == null) {
                arraylist = new ArrayList();
            }

            arraylist.add(datawatcher$watchableobject);
        }

        this.lock.readLock().unlock();
        return arraylist;
    }

    private static void writeWatchableObjectToPacketBuffer(PacketBuffer var0, DataWatcher.WatchableObject var1) throws IOException {
        int i = (var1.getObjectType() << 5 | var1.getDataValueId() & 31) & 0xFF;
        var0.writeByte(i);
        switch (var1.getObjectType()) {
            case 0:
                var0.writeByte((Byte)var1.getObject());
                break;
            case 1:
                var0.writeShort((Short)var1.getObject());
                break;
            case 2:
                var0.writeInt((Integer)var1.getObject());
                break;
            case 3:
                var0.writeFloat((Float)var1.getObject());
                break;
            case 4:
                var0.writeStringToBuffer((String)var1.getObject());
                break;
            case 5:
                ItemStack itemstack = (ItemStack)var1.getObject();
                var0.writeItemStackToBuffer(itemstack);
                break;
            case 6:
                ChunkCoordinates chunkcoordinates = (ChunkCoordinates)var1.getObject();
                var0.writeInt(chunkcoordinates.posX);
                var0.writeInt(chunkcoordinates.posY);
                var0.writeInt(chunkcoordinates.posZ);
        }
    }

    public static List readWatchedListFromPacketBuffer(PacketBuffer var0) throws IOException {
        ArrayList arraylist = null;

        for (byte b0 = var0.readByte(); b0 != 127; b0 = var0.readByte()) {
            if (arraylist == null) {
                arraylist = new ArrayList();
            }

            int i = (b0 & 224) >> 5;
            int j = b0 & 31;
            DataWatcher.WatchableObject datawatcher$watchableobject = null;
            switch (i) {
                case 0:
                    datawatcher$watchableobject = new DataWatcher.WatchableObject(i, j, var0.readByte());
                    break;
                case 1:
                    datawatcher$watchableobject = new DataWatcher.WatchableObject(i, j, var0.readShort());
                    break;
                case 2:
                    datawatcher$watchableobject = new DataWatcher.WatchableObject(i, j, var0.readInt());
                    break;
                case 3:
                    datawatcher$watchableobject = new DataWatcher.WatchableObject(i, j, var0.readFloat());
                    break;
                case 4:
                    datawatcher$watchableobject = new DataWatcher.WatchableObject(i, j, var0.readStringFromBuffer(Short.MAX_VALUE));
                    break;
                case 5:
                    datawatcher$watchableobject = new DataWatcher.WatchableObject(i, j, var0.readItemStackFromBuffer());
                    break;
                case 6:
                    int k = var0.readInt();
                    int l = var0.readInt();
                    int i1 = var0.readInt();
                    datawatcher$watchableobject = new DataWatcher.WatchableObject(i, j, new ChunkCoordinates(k, l, i1));
            }

            arraylist.add(datawatcher$watchableobject);
        }

        return arraylist;
    }

    public void updateWatchedObjectsFromList(List var1) {
        this.lock.writeLock().lock();

        for (DataWatcher.WatchableObject datawatcher$watchableobject : (Iterable<DataWatcher.WatchableObject>) (Iterable) var1) {
            DataWatcher.WatchableObject datawatcher$watchableobject1 = (DataWatcher.WatchableObject)this.watchedObjects
                .get(datawatcher$watchableobject.getDataValueId());
            if (datawatcher$watchableobject1 != null) {
                datawatcher$watchableobject1.setObject(datawatcher$watchableobject.getObject());
                this.field_151511_a.func_145781_i(datawatcher$watchableobject.getDataValueId());
            }
        }

        this.lock.writeLock().unlock();
        this.objectChanged = true;
    }

    public boolean getIsBlank() {
        return this.isBlank;
    }

    public void func_111144_e() {
        this.objectChanged = false;
    }

    static {
        dataTypes.put(Byte.class, 0);
        dataTypes.put(Short.class, 1);
        dataTypes.put(Integer.class, 2);
        dataTypes.put(Float.class, 3);
        dataTypes.put(String.class, 4);
        dataTypes.put(ItemStack.class, 5);
        dataTypes.put(ChunkCoordinates.class, 6);
    }

    public static class WatchableObject {
        private final int objectType;
        private final int dataValueId;
        private Object watchedObject;
        private boolean watched;

        public WatchableObject(int var1, int var2, Object var3) {
            this.dataValueId = var2;
            this.watchedObject = var3;
            this.objectType = var1;
            this.watched = true;
        }

        public int getDataValueId() {
            return this.dataValueId;
        }

        public void setObject(Object var1) {
            this.watchedObject = var1;
        }

        public Object getObject() {
            return this.watchedObject;
        }

        public int getObjectType() {
            return this.objectType;
        }

        public boolean isWatched() {
            return this.watched;
        }

        public void setWatched(boolean var1) {
            this.watched = var1;
        }
    }
}
