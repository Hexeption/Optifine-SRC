package net.minecraft.entity.player;

import com.google.common.collect.Sets;
import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.item.EntityMinecartHopper;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerBeacon;
import net.minecraft.inventory.ContainerBrewingStand;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.ContainerDispenser;
import net.minecraft.inventory.ContainerEnchantment;
import net.minecraft.inventory.ContainerFurnace;
import net.minecraft.inventory.ContainerHopper;
import net.minecraft.inventory.ContainerHorseInventory;
import net.minecraft.inventory.ContainerMerchant;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryMerchant;
import net.minecraft.inventory.SlotCrafting;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemMapBase;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C15PacketClientSettings;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S06PacketUpdateHealth;
import net.minecraft.network.play.server.S0APacketUseBed;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.network.play.server.S13PacketDestroyEntities;
import net.minecraft.network.play.server.S19PacketEntityStatus;
import net.minecraft.network.play.server.S1BPacketEntityAttach;
import net.minecraft.network.play.server.S1DPacketEntityEffect;
import net.minecraft.network.play.server.S1EPacketRemoveEntityEffect;
import net.minecraft.network.play.server.S1FPacketSetExperience;
import net.minecraft.network.play.server.S26PacketMapChunkBulk;
import net.minecraft.network.play.server.S2BPacketChangeGameState;
import net.minecraft.network.play.server.S2DPacketOpenWindow;
import net.minecraft.network.play.server.S2EPacketCloseWindow;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.network.play.server.S30PacketWindowItems;
import net.minecraft.network.play.server.S31PacketWindowProperty;
import net.minecraft.network.play.server.S36PacketSignEditorOpen;
import net.minecraft.network.play.server.S39PacketPlayerAbilities;
import net.minecraft.network.play.server.S3FPacketCustomPayload;
import net.minecraft.potion.PotionEffect;
import net.minecraft.scoreboard.IScoreObjectiveCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.ItemInWorldManager;
import net.minecraft.server.management.UserListOpsEntry;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.stats.StatisticsFile;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.tileentity.TileEntityBrewingStand;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityDropper;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.JsonSerializableSet;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.WorldServer;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import org.apache.commons.io.Charsets;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityPlayerMP extends EntityPlayer implements ICrafting {
    private static final Logger logger = LogManager.getLogger();
    private String translator = "en_US";
    public NetHandlerPlayServer playerNetServerHandler;
    public final MinecraftServer mcServer;
    public final ItemInWorldManager theItemInWorldManager;
    public double managedPosX;
    public double managedPosZ;
    public final List loadedChunks = new LinkedList();
    private final List destroyedItemsNetCache = new LinkedList();
    private final StatisticsFile field_147103_bO;
    private float field_130068_bO = Float.MIN_VALUE;
    private float lastHealth = -1.0E8F;
    private int lastFoodLevel = -99999999;
    private boolean wasHungry = true;
    private int lastExperience = -99999999;
    private int field_147101_bU = 60;
    private EntityPlayer.EnumChatVisibility chatVisibility;
    private boolean chatColours = true;
    private long playerLastActiveTime = System.currentTimeMillis();
    private int currentWindowId;
    public boolean isChangingQuantityOnly;
    public int ping;
    public boolean playerConqueredTheEnd;

    public EntityPlayerMP(MinecraftServer var1, WorldServer var2, GameProfile var3, ItemInWorldManager var4) {
        super(var2, var3);
        var4.thisPlayerMP = this;
        this.theItemInWorldManager = var4;
        ChunkCoordinates chunkcoordinates = var2.getSpawnPoint();
        int i = chunkcoordinates.posX;
        int j = chunkcoordinates.posZ;
        int k = chunkcoordinates.posY;
        if (!var2.provider.hasNoSky && var2.getWorldInfo().getGameType() != WorldSettings.GameType.ADVENTURE) {
            int l = Math.max(5, var1.getSpawnProtectionSize() - 6);
            i += this.rand.nextInt(l * 2) - l;
            j += this.rand.nextInt(l * 2) - l;
            k = var2.getTopSolidOrLiquidBlock(i, j);
        }

        this.mcServer = var1;
        this.field_147103_bO = var1.getConfigurationManager().getPlayerStatsFile(this);
        this.stepHeight = 0.0F;
        this.yOffset = 0.0F;
        this.setLocationAndAngles(i + 0.5, k, j + 0.5, 0.0F, 0.0F);

        while (!var2.getCollidingBoundingBoxes(this, this.boundingBox).isEmpty()) {
            this.setPosition(this.posX, this.posY + 1.0, this.posZ);
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        if (var1.hasKey("playerGameType", 99)) {
            if (MinecraftServer.getServer().getForceGamemode()) {
                this.theItemInWorldManager.setGameType(MinecraftServer.getServer().getGameType());
            } else {
                this.theItemInWorldManager.setGameType(WorldSettings.GameType.getByID(var1.getInteger("playerGameType")));
            }
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setInteger("playerGameType", this.theItemInWorldManager.getGameType().getID());
    }

    @Override
    public void addExperienceLevel(int var1) {
        super.addExperienceLevel(var1);
        this.lastExperience = -1;
    }

    public void addSelfToInternalCraftingInventory() {
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    protected void resetHeight() {
        this.yOffset = 0.0F;
    }

    @Override
    public float getEyeHeight() {
        return 1.62F;
    }

    @Override
    public void onUpdate() {
        this.theItemInWorldManager.updateBlockRemoving();
        this.field_147101_bU--;
        if (this.hurtResistantTime > 0) {
            this.hurtResistantTime--;
        }

        this.openContainer.detectAndSendChanges();
        if (!this.worldObj.isRemote && !this.openContainer.canInteractWith(this)) {
            this.closeScreen();
            this.openContainer = this.inventoryContainer;
        }

        while (!this.destroyedItemsNetCache.isEmpty()) {
            int i = Math.min(this.destroyedItemsNetCache.size(), 127);
            int[] aint = new int[i];
            Iterator iterator = this.destroyedItemsNetCache.iterator();
            int j = 0;

            while (iterator.hasNext() && j < i) {
                aint[j++] = (Integer)iterator.next();
                iterator.remove();
            }

            this.playerNetServerHandler.sendPacket(new S13PacketDestroyEntities(aint));
        }

        if (!this.loadedChunks.isEmpty()) {
            ArrayList arraylist = new ArrayList();
            Iterator iterator1 = this.loadedChunks.iterator();
            ArrayList arraylist1 = new ArrayList();

            while (iterator1.hasNext() && arraylist.size() < S26PacketMapChunkBulk.func_149258_c()) {
                ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)iterator1.next();
                if (chunkcoordintpair != null) {
                    if (this.worldObj.blockExists(chunkcoordintpair.chunkXPos << 4, 0, chunkcoordintpair.chunkZPos << 4)) {
                        Chunk chunk = this.worldObj.getChunkFromChunkCoords(chunkcoordintpair.chunkXPos, chunkcoordintpair.chunkZPos);
                        if (chunk.func_150802_k()) {
                            arraylist.add(chunk);
                            arraylist1.addAll(
                                ((WorldServer)this.worldObj)
                                    .func_147486_a(
                                        chunkcoordintpair.chunkXPos * 16,
                                        0,
                                        chunkcoordintpair.chunkZPos * 16,
                                        chunkcoordintpair.chunkXPos * 16 + 16,
                                        256,
                                        chunkcoordintpair.chunkZPos * 16 + 16
                                    )
                            );
                            iterator1.remove();
                        }
                    }
                } else {
                    iterator1.remove();
                }
            }

            if (!arraylist.isEmpty()) {
                this.playerNetServerHandler.sendPacket(new S26PacketMapChunkBulk(arraylist));

                for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) arraylist1) {
                    this.func_147097_b(tileentity);
                }

                for (Chunk chunk1 : (Iterable<Chunk>) (Iterable) arraylist) {
                    this.getServerForPlayer().getEntityTracker().func_85172_a(this, chunk1);
                }
            }
        }
    }

    public void onUpdateEntity() {
        try {
            super.onUpdate();

            for (int i = 0; i < this.inventory.getSizeInventory(); i++) {
                ItemStack itemstack = this.inventory.getStackInSlot(i);
                if (itemstack != null && itemstack.getItem().isMap()) {
                    Packet packet = ((ItemMapBase)itemstack.getItem()).createMapDataPacket(itemstack, this.worldObj, this);
                    if (packet != null) {
                        this.playerNetServerHandler.sendPacket(packet);
                    }
                }
            }

            if (this.getHealth() != this.lastHealth
                || this.lastFoodLevel != this.foodStats.getFoodLevel()
                || this.foodStats.getSaturationLevel() == 0.0F != this.wasHungry) {
                this.playerNetServerHandler
                    .sendPacket(new S06PacketUpdateHealth(this.getHealth(), this.foodStats.getFoodLevel(), this.foodStats.getSaturationLevel()));
                this.lastHealth = this.getHealth();
                this.lastFoodLevel = this.foodStats.getFoodLevel();
                this.wasHungry = this.foodStats.getSaturationLevel() == 0.0F;
            }

            if (this.getHealth() + this.getAbsorptionAmount() != this.field_130068_bO) {
                this.field_130068_bO = this.getHealth() + this.getAbsorptionAmount();

                for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.getWorldScoreboard().func_96520_a(IScoreObjectiveCriteria.health)) {
                    this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective).func_96651_a(Arrays.asList(this));
                }
            }

            if (this.experienceTotal != this.lastExperience) {
                this.lastExperience = this.experienceTotal;
                this.playerNetServerHandler.sendPacket(new S1FPacketSetExperience(this.experience, this.experienceTotal, this.experienceLevel));
            }

            if (this.ticksExisted % 20 * 5 == 0 && !this.getStatFile().hasAchievementUnlocked(AchievementList.exploreAllBiomes)) {
                this.func_147098_j();
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Ticking player");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Player being ticked");
            this.addEntityCrashInfo(crashreportcategory);
            throw new ReportedException(crashreport);
        }
    }

    protected void func_147098_j() {
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posZ));
        if (biomegenbase != null) {
            String s = biomegenbase.biomeName;
            JsonSerializableSet jsonserializableset = (JsonSerializableSet)this.getStatFile().func_150870_b(AchievementList.exploreAllBiomes);
            if (jsonserializableset == null) {
                jsonserializableset = (JsonSerializableSet)this.getStatFile().func_150872_a(AchievementList.exploreAllBiomes, new JsonSerializableSet());
            }

            jsonserializableset.add(s);
            if (this.getStatFile().canUnlockAchievement(AchievementList.exploreAllBiomes)
                && jsonserializableset.size() == BiomeGenBase.explorationBiomesList.size()) {
                HashSet hashset = Sets.newHashSet(BiomeGenBase.explorationBiomesList);

                for (String s1 : (Iterable<String>) (Iterable) jsonserializableset) {
                    Iterator iterator = hashset.iterator();

                    while (iterator.hasNext()) {
                        BiomeGenBase biomegenbase1 = (BiomeGenBase)iterator.next();
                        if (biomegenbase1.biomeName.equals(s1)) {
                            iterator.remove();
                        }
                    }

                    if (hashset.isEmpty()) {
                        break;
                    }
                }

                if (hashset.isEmpty()) {
                    this.triggerAchievement(AchievementList.exploreAllBiomes);
                }
            }
        }
    }

    @Override
    public void onDeath(DamageSource var1) {
        this.mcServer.getConfigurationManager().sendChatMsg(this.getCombatTracker().func_151521_b());
        if (!this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            this.inventory.dropAllItems();
        }

        for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.worldObj.getScoreboard().func_96520_a(IScoreObjectiveCriteria.deathCount)) {
            Score score = this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective);
            score.func_96648_a();
        }

        EntityLivingBase entitylivingbase = this.func_94060_bK();
        if (entitylivingbase != null) {
            int i = EntityList.getEntityID(entitylivingbase);
            EntityList.EntityEggInfo entitylist$entityegginfo = (EntityList.EntityEggInfo)EntityList.entityEggs.get(i);
            if (entitylist$entityegginfo != null) {
                this.addStat(entitylist$entityegginfo.field_151513_e, 1);
            }

            entitylivingbase.addToPlayerScore(this, this.scoreValue);
        }

        this.addStat(StatList.deathsStat, 1);
        this.getCombatTracker().func_94549_h();
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        boolean flag = this.mcServer.isDedicatedServer() && this.mcServer.isPVPEnabled() && "fall".equals(var1.damageType);
        if (!flag && this.field_147101_bU > 0 && var1 != DamageSource.outOfWorld) {
            return false;
        }

        if (var1 instanceof EntityDamageSource) {
            Entity entity = var1.getEntity();
            if (entity instanceof EntityPlayer && !this.canAttackPlayer((EntityPlayer)entity)) {
                return false;
            }

            if (entity instanceof EntityArrow) {
                EntityArrow entityarrow = (EntityArrow)entity;
                if (entityarrow.shootingEntity instanceof EntityPlayer && !this.canAttackPlayer((EntityPlayer)entityarrow.shootingEntity)) {
                    return false;
                }
            }
        }

        return super.attackEntityFrom(var1, var2);
    }

    @Override
    public boolean canAttackPlayer(EntityPlayer var1) {
        return !this.mcServer.isPVPEnabled() ? false : super.canAttackPlayer(var1);
    }

    @Override
    public void travelToDimension(int var1) {
        if (this.dimension == 1 && var1 == 1) {
            this.triggerAchievement(AchievementList.theEnd2);
            this.worldObj.removeEntity(this);
            this.playerConqueredTheEnd = true;
            this.playerNetServerHandler.sendPacket(new S2BPacketChangeGameState(4, 0.0F));
        } else {
            if (this.dimension == 0 && var1 == 1) {
                this.triggerAchievement(AchievementList.theEnd);
                ChunkCoordinates chunkcoordinates = this.mcServer.worldServerForDimension(var1).getEntrancePortalLocation();
                if (chunkcoordinates != null) {
                    this.playerNetServerHandler.setPlayerLocation(chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ, 0.0F, 0.0F);
                }

                var1 = 1;
            } else {
                this.triggerAchievement(AchievementList.portal);
            }

            this.mcServer.getConfigurationManager().transferPlayerToDimension(this, var1);
            this.lastExperience = -1;
            this.lastHealth = -1.0F;
            this.lastFoodLevel = -1;
        }
    }

    private void func_147097_b(TileEntity var1) {
        if (var1 != null) {
            Packet packet = var1.getDescriptionPacket();
            if (packet != null) {
                this.playerNetServerHandler.sendPacket(packet);
            }
        }
    }

    @Override
    public void onItemPickup(Entity var1, int var2) {
        super.onItemPickup(var1, var2);
        this.openContainer.detectAndSendChanges();
    }

    @Override
    public EntityPlayer.EnumStatus sleepInBedAt(int var1, int var2, int var3) {
        EntityPlayer.EnumStatus entityplayer$enumstatus = super.sleepInBedAt(var1, var2, var3);
        if (entityplayer$enumstatus == EntityPlayer.EnumStatus.OK) {
            S0APacketUseBed s0apacketusebed = new S0APacketUseBed(this, var1, var2, var3);
            this.getServerForPlayer().getEntityTracker().sendToAllTrackingEntity(this, s0apacketusebed);
            this.playerNetServerHandler.setPlayerLocation(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
            this.playerNetServerHandler.sendPacket(s0apacketusebed);
        }

        return entityplayer$enumstatus;
    }

    @Override
    public void wakeUpPlayer(boolean var1, boolean var2, boolean var3) {
        if (this.isPlayerSleeping()) {
            this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(this, 2));
        }

        super.wakeUpPlayer(var1, var2, var3);
        if (this.playerNetServerHandler != null) {
            this.playerNetServerHandler.setPlayerLocation(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
        }
    }

    @Override
    public void mountEntity(Entity var1) {
        super.mountEntity(var1);
        this.playerNetServerHandler.sendPacket(new S1BPacketEntityAttach(0, this, this.ridingEntity));
        this.playerNetServerHandler.setPlayerLocation(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
    }

    @Override
    protected void updateFallState(double var1, boolean var3) {
    }

    public void handleFalling(double var1, boolean var3) {
        super.updateFallState(var1, var3);
    }

    @Override
    public void displayGUIEditSign(TileEntity var1) {
        if (var1 instanceof TileEntitySign) {
            ((TileEntitySign)var1).func_145912_a(this);
            this.playerNetServerHandler.sendPacket(new S36PacketSignEditorOpen(var1.xCoord, var1.yCoord, var1.zCoord));
        }
    }

    private void getNextWindowId() {
        this.currentWindowId = this.currentWindowId % 100 + 1;
    }

    @Override
    public void displayGUIWorkbench(int var1, int var2, int var3) {
        this.getNextWindowId();
        this.playerNetServerHandler.sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 1, "Crafting", 9, true));
        this.openContainer = new ContainerWorkbench(this.inventory, this.worldObj, var1, var2, var3);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayGUIEnchantment(int var1, int var2, int var3, String var4) {
        this.getNextWindowId();
        this.playerNetServerHandler.sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 4, var4 == null ? "" : var4, 9, var4 != null));
        this.openContainer = new ContainerEnchantment(this.inventory, this.worldObj, var1, var2, var3);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayGUIAnvil(int var1, int var2, int var3) {
        this.getNextWindowId();
        this.playerNetServerHandler.sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 8, "Repairing", 9, true));
        this.openContainer = new ContainerRepair(this.inventory, this.worldObj, var1, var2, var3, this);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayGUIChest(IInventory var1) {
        if (this.openContainer != this.inventoryContainer) {
            this.closeScreen();
        }

        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 0, var1.getInventoryName(), var1.getSizeInventory(), var1.isCustomInventoryName()));
        this.openContainer = new ContainerChest(this.inventory, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void func_146093_a(TileEntityHopper var1) {
        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 9, var1.getInventoryName(), var1.getSizeInventory(), var1.isCustomInventoryName()));
        this.openContainer = new ContainerHopper(this.inventory, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayGUIHopperMinecart(EntityMinecartHopper var1) {
        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 9, var1.getInventoryName(), var1.getSizeInventory(), var1.isCustomInventoryName()));
        this.openContainer = new ContainerHopper(this.inventory, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void func_146101_a(TileEntityFurnace var1) {
        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 2, var1.getInventoryName(), var1.getSizeInventory(), var1.isCustomInventoryName()));
        this.openContainer = new ContainerFurnace(this.inventory, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void func_146102_a(TileEntityDispenser var1) {
        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(
                new S2DPacketOpenWindow(
                    this.currentWindowId,
                    var1 instanceof TileEntityDropper ? 10 : 3,
                    var1.getInventoryName(),
                    var1.getSizeInventory(),
                    var1.isCustomInventoryName()
                )
            );
        this.openContainer = new ContainerDispenser(this.inventory, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void func_146098_a(TileEntityBrewingStand var1) {
        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 5, var1.getInventoryName(), var1.getSizeInventory(), var1.isCustomInventoryName()));
        this.openContainer = new ContainerBrewingStand(this.inventory, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void func_146104_a(TileEntityBeacon var1) {
        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 7, var1.getInventoryName(), var1.getSizeInventory(), var1.isCustomInventoryName()));
        this.openContainer = new ContainerBeacon(this.inventory, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayGUIMerchant(IMerchant var1, String var2) {
        this.getNextWindowId();
        this.openContainer = new ContainerMerchant(this.inventory, var1, this.worldObj);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
        InventoryMerchant inventorymerchant = ((ContainerMerchant)this.openContainer).getMerchantInventory();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, 6, var2 == null ? "" : var2, inventorymerchant.getSizeInventory(), var2 != null));
        MerchantRecipeList merchantrecipelist = var1.getRecipes(this);
        if (merchantrecipelist != null) {
            PacketBuffer packetbuffer = new PacketBuffer(Unpooled.buffer());

            try {
                packetbuffer.writeInt(this.currentWindowId);
                merchantrecipelist.func_151391_a(packetbuffer);
                this.playerNetServerHandler.sendPacket(new S3FPacketCustomPayload("MC|TrList", packetbuffer));
            } catch (IOException ioexception) {
                logger.error("Couldn't send trade list", ioexception);
            } finally {
                packetbuffer.release();
            }
        }
    }

    @Override
    public void displayGUIHorse(EntityHorse var1, IInventory var2) {
        if (this.openContainer != this.inventoryContainer) {
            this.closeScreen();
        }

        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(
                new S2DPacketOpenWindow(
                    this.currentWindowId, 11, var2.getInventoryName(), var2.getSizeInventory(), var2.isCustomInventoryName(), var1.getEntityId()
                )
            );
        this.openContainer = new ContainerHorseInventory(this.inventory, var2, var1);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void sendSlotContents(Container var1, int var2, ItemStack var3) {
        if (!(var1.getSlot(var2) instanceof SlotCrafting)) {
            if (!this.isChangingQuantityOnly) {
                this.playerNetServerHandler.sendPacket(new S2FPacketSetSlot(var1.windowId, var2, var3));
            }
        }
    }

    public void sendContainerToPlayer(Container var1) {
        this.updateCraftingInventory(var1, var1.getInventory());
    }

    @Override
    public void updateCraftingInventory(Container var1, List var2) {
        this.playerNetServerHandler.sendPacket(new S30PacketWindowItems(var1.windowId, var2));
        this.playerNetServerHandler.sendPacket(new S2FPacketSetSlot(-1, -1, this.inventory.getItemStack()));
    }

    @Override
    public void sendProgressBarUpdate(Container var1, int var2, int var3) {
        this.playerNetServerHandler.sendPacket(new S31PacketWindowProperty(var1.windowId, var2, var3));
    }

    @Override
    public void closeScreen() {
        this.playerNetServerHandler.sendPacket(new S2EPacketCloseWindow(this.openContainer.windowId));
        this.closeContainer();
    }

    public void updateHeldItem() {
        if (!this.isChangingQuantityOnly) {
            this.playerNetServerHandler.sendPacket(new S2FPacketSetSlot(-1, -1, this.inventory.getItemStack()));
        }
    }

    public void closeContainer() {
        this.openContainer.onContainerClosed(this);
        this.openContainer = this.inventoryContainer;
    }

    public void setEntityActionState(float var1, float var2, boolean var3, boolean var4) {
        if (this.ridingEntity != null) {
            if (var1 >= -1.0F && var1 <= 1.0F) {
                this.moveStrafing = var1;
            }

            if (var2 >= -1.0F && var2 <= 1.0F) {
                this.moveForward = var2;
            }

            this.isJumping = var3;
            this.setSneaking(var4);
        }
    }

    @Override
    public void addStat(StatBase var1, int var2) {
        if (var1 != null) {
            this.field_147103_bO.func_150871_b(this, var1, var2);

            for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.getWorldScoreboard().func_96520_a(var1.func_150952_k())) {
                this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective).func_96648_a();
            }

            if (this.field_147103_bO.func_150879_e()) {
                this.field_147103_bO.func_150876_a(this);
            }
        }
    }

    public void mountEntityAndWakeUp() {
        if (this.riddenByEntity != null) {
            this.riddenByEntity.mountEntity(this);
        }

        if (this.sleeping) {
            this.wakeUpPlayer(true, false, false);
        }
    }

    public void setPlayerHealthUpdated() {
        this.lastHealth = -1.0E8F;
    }

    @Override
    public void addChatComponentMessage(IChatComponent var1) {
        this.playerNetServerHandler.sendPacket(new S02PacketChat(var1));
    }

    @Override
    protected void onItemUseFinish() {
        this.playerNetServerHandler.sendPacket(new S19PacketEntityStatus(this, (byte)9));
        super.onItemUseFinish();
    }

    @Override
    public void setItemInUse(ItemStack var1, int var2) {
        super.setItemInUse(var1, var2);
        if (var1 != null && var1.getItem() != null && var1.getItem().getItemUseAction(var1) == EnumAction.eat) {
            this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(this, 3));
        }
    }

    @Override
    public void clonePlayer(EntityPlayer var1, boolean var2) {
        super.clonePlayer(var1, var2);
        this.lastExperience = -1;
        this.lastHealth = -1.0F;
        this.lastFoodLevel = -1;
        this.destroyedItemsNetCache.addAll(((EntityPlayerMP)var1).destroyedItemsNetCache);
    }

    @Override
    protected void onNewPotionEffect(PotionEffect var1) {
        super.onNewPotionEffect(var1);
        this.playerNetServerHandler.sendPacket(new S1DPacketEntityEffect(this.getEntityId(), var1));
    }

    @Override
    protected void onChangedPotionEffect(PotionEffect var1, boolean var2) {
        super.onChangedPotionEffect(var1, var2);
        this.playerNetServerHandler.sendPacket(new S1DPacketEntityEffect(this.getEntityId(), var1));
    }

    @Override
    protected void onFinishedPotionEffect(PotionEffect var1) {
        super.onFinishedPotionEffect(var1);
        this.playerNetServerHandler.sendPacket(new S1EPacketRemoveEntityEffect(this.getEntityId(), var1));
    }

    @Override
    public void setPositionAndUpdate(double var1, double var3, double var5) {
        this.playerNetServerHandler.setPlayerLocation(var1, var3, var5, this.rotationYaw, this.rotationPitch);
    }

    @Override
    public void onCriticalHit(Entity var1) {
        this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(var1, 4));
    }

    @Override
    public void onEnchantmentCritical(Entity var1) {
        this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(var1, 5));
    }

    @Override
    public void sendPlayerAbilities() {
        if (this.playerNetServerHandler != null) {
            this.playerNetServerHandler.sendPacket(new S39PacketPlayerAbilities(this.capabilities));
        }
    }

    public WorldServer getServerForPlayer() {
        return (WorldServer)this.worldObj;
    }

    @Override
    public void setGameType(WorldSettings.GameType var1) {
        this.theItemInWorldManager.setGameType(var1);
        this.playerNetServerHandler.sendPacket(new S2BPacketChangeGameState(3, var1.getID()));
    }

    @Override
    public void addChatMessage(IChatComponent var1) {
        this.playerNetServerHandler.sendPacket(new S02PacketChat(var1));
    }

    @Override
    public boolean canCommandSenderUseCommand(int var1, String var2) {
        if ("seed".equals(var2) && !this.mcServer.isDedicatedServer()) {
            return true;
        }

        if (!"tell".equals(var2) && !"help".equals(var2) && !"me".equals(var2)) {
            if (this.mcServer.getConfigurationManager().canSendCommands(this.getGameProfile())) {
                UserListOpsEntry userlistopsentry = (UserListOpsEntry)this.mcServer.getConfigurationManager().getOppedPlayers().getEntry(this.getGameProfile());
                return userlistopsentry != null ? userlistopsentry.func_152644_a() >= var1 : this.mcServer.getOpPermissionLevel() >= var1;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    public String getPlayerIP() {
        String s = this.playerNetServerHandler.netManager.getRemoteAddress().toString();
        s = s.substring(s.indexOf("/") + 1);
        return s.substring(0, s.indexOf(":"));
    }

    public void func_147100_a(C15PacketClientSettings var1) {
        this.translator = var1.getLang();
        int i = 256 >> var1.getView();
        if (i > 3 && i < 20) {
        }

        this.chatVisibility = var1.getChatVisibility();
        this.chatColours = var1.isColorsEnabled();
        if (this.mcServer.isSinglePlayer() && this.mcServer.getServerOwner().equals(this.getCommandSenderName())) {
            this.mcServer.setDifficultyForAllWorlds(var1.getDifficulty());
        }

        this.setHideCape(1, !var1.isShowCape());
    }

    public EntityPlayer.EnumChatVisibility func_147096_v() {
        return this.chatVisibility;
    }

    public void requestTexturePackLoad(String var1) {
        this.playerNetServerHandler.sendPacket(new S3FPacketCustomPayload("MC|RPack", var1.getBytes(Charsets.UTF_8)));
    }

    @Override
    public ChunkCoordinates getCommandSenderPosition() {
        return new ChunkCoordinates(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY + 0.5), MathHelper.floor_double(this.posZ));
    }

    public void markPlayerActive() {
        this.playerLastActiveTime = MinecraftServer.getCurrentTimeMillis();
    }

    public StatisticsFile getStatFile() {
        return this.field_147103_bO;
    }

    public void func_152339_d(Entity var1) {
        if (var1 instanceof EntityPlayer) {
            this.playerNetServerHandler.sendPacket(new S13PacketDestroyEntities(var1.getEntityId()));
        } else {
            this.destroyedItemsNetCache.add(var1.getEntityId());
        }
    }

    public long getLastActiveTime() {
        return this.playerLastActiveTime;
    }
}
