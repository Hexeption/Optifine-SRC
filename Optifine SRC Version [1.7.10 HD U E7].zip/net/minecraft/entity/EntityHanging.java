package net.minecraft.entity;

import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Direction;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public abstract class EntityHanging extends Entity {
    private int tickCounter1;
    public int hangingDirection;
    public int field_146063_b;
    public int field_146064_c;
    public int field_146062_d;

    public EntityHanging(World var1) {
        super(var1);
        this.yOffset = 0.0F;
        this.setSize(0.5F, 0.5F);
    }

    public EntityHanging(World var1, int var2, int var3, int var4, int var5) {
        this(var1);
        this.field_146063_b = var2;
        this.field_146064_c = var3;
        this.field_146062_d = var4;
    }

    @Override
    protected void entityInit() {
    }

    public void setDirection(int var1) {
        this.hangingDirection = var1;
        this.prevRotationYaw = this.rotationYaw = var1 * 90;
        float f = this.getWidthPixels();
        float f1 = this.getHeightPixels();
        float f2 = this.getWidthPixels();
        if (var1 != 2 && var1 != 0) {
            f = 0.5F;
        } else {
            f2 = 0.5F;
            this.rotationYaw = this.prevRotationYaw = Direction.rotateOpposite[var1] * 90;
        }

        f /= 32.0F;
        f1 /= 32.0F;
        f2 /= 32.0F;
        float f3 = this.field_146063_b + 0.5F;
        float f4 = this.field_146064_c + 0.5F;
        float f5 = this.field_146062_d + 0.5F;
        float f6 = 9.0F / 16.0F;
        if (var1 == 2) {
            f5 -= f6;
        }

        if (var1 == 1) {
            f3 -= f6;
        }

        if (var1 == 0) {
            f5 += f6;
        }

        if (var1 == 3) {
            f3 += f6;
        }

        if (var1 == 2) {
            f3 -= this.func_70517_b(this.getWidthPixels());
        }

        if (var1 == 1) {
            f5 += this.func_70517_b(this.getWidthPixels());
        }

        if (var1 == 0) {
            f3 += this.func_70517_b(this.getWidthPixels());
        }

        if (var1 == 3) {
            f5 -= this.func_70517_b(this.getWidthPixels());
        }

        f4 += this.func_70517_b(this.getHeightPixels());
        this.setPosition(f3, f4, f5);
        float f7 = -0.03125F;
        this.boundingBox.setBounds(f3 - f - f7, f4 - f1 - f7, f5 - f2 - f7, f3 + f + f7, f4 + f1 + f7, f5 + f2 + f7);
    }

    private float func_70517_b(int var1) {
        if (var1 == 32) {
            return 0.5F;
        } else {
            return var1 == 64 ? 0.5F : 0.0F;
        }
    }

    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        if (this.tickCounter1++ == 100 && !this.worldObj.isRemote) {
            this.tickCounter1 = 0;
            if (!this.isDead && !this.onValidSurface()) {
                this.setDead();
                this.onBroken(null);
            }
        }
    }

    public boolean onValidSurface() {
        if (!this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).isEmpty()) {
            return false;
        }

        int i = Math.max(1, this.getWidthPixels() / 16);
        int j = Math.max(1, this.getHeightPixels() / 16);
        int k = this.field_146063_b;
        int l = this.field_146064_c;
        int i1 = this.field_146062_d;
        if (this.hangingDirection == 2) {
            k = MathHelper.floor_double(this.posX - this.getWidthPixels() / 32.0F);
        }

        if (this.hangingDirection == 1) {
            i1 = MathHelper.floor_double(this.posZ - this.getWidthPixels() / 32.0F);
        }

        if (this.hangingDirection == 0) {
            k = MathHelper.floor_double(this.posX - this.getWidthPixels() / 32.0F);
        }

        if (this.hangingDirection == 3) {
            i1 = MathHelper.floor_double(this.posZ - this.getWidthPixels() / 32.0F);
        }

        l = MathHelper.floor_double(this.posY - this.getHeightPixels() / 32.0F);

        for (int j1 = 0; j1 < i; j1++) {
            for (int k1 = 0; k1 < j; k1++) {
                Material material;
                if (this.hangingDirection != 2 && this.hangingDirection != 0) {
                    material = this.worldObj.getBlock(this.field_146063_b, l + k1, i1 + j1).getMaterial();
                } else {
                    material = this.worldObj.getBlock(k + j1, l + k1, this.field_146062_d).getMaterial();
                }

                if (!material.isSolid()) {
                    return false;
                }
            }
        }

        for (Entity entity : (Iterable<Entity>) (Iterable) this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox)) {
            if (entity instanceof EntityHanging) {
                return false;
            }
        }

        return true;
    }

    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    @Override
    public boolean hitByEntity(Entity var1) {
        return var1 instanceof EntityPlayer ? this.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)var1), 0.0F) : false;
    }

    @Override
    public void func_145781_i(int var1) {
        this.worldObj.func_147450_X();
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        if (!this.isDead && !this.worldObj.isRemote) {
            this.setDead();
            this.setBeenAttacked();
            this.onBroken(var1.getEntity());
        }

        return true;
    }

    @Override
    public void moveEntity(double var1, double var3, double var5) {
        if (!this.worldObj.isRemote && !this.isDead && var1 * var1 + var3 * var3 + var5 * var5 > 0.0) {
            this.setDead();
            this.onBroken(null);
        }
    }

    @Override
    public void addVelocity(double var1, double var3, double var5) {
        if (!this.worldObj.isRemote && !this.isDead && var1 * var1 + var3 * var3 + var5 * var5 > 0.0) {
            this.setDead();
            this.onBroken(null);
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setByte("Direction", (byte)this.hangingDirection);
        var1.setInteger("TileX", this.field_146063_b);
        var1.setInteger("TileY", this.field_146064_c);
        var1.setInteger("TileZ", this.field_146062_d);
        switch (this.hangingDirection) {
            case 0:
                var1.setByte("Dir", (byte)2);
                break;
            case 1:
                var1.setByte("Dir", (byte)1);
                break;
            case 2:
                var1.setByte("Dir", (byte)0);
                break;
            case 3:
                var1.setByte("Dir", (byte)3);
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        if (var1.hasKey("Direction", 99)) {
            this.hangingDirection = var1.getByte("Direction");
        } else {
            switch (var1.getByte("Dir")) {
                case 0:
                    this.hangingDirection = 2;
                    break;
                case 1:
                    this.hangingDirection = 1;
                    break;
                case 2:
                    this.hangingDirection = 0;
                    break;
                case 3:
                    this.hangingDirection = 3;
            }
        }

        this.field_146063_b = var1.getInteger("TileX");
        this.field_146064_c = var1.getInteger("TileY");
        this.field_146062_d = var1.getInteger("TileZ");
        this.setDirection(this.hangingDirection);
    }

    public abstract int getWidthPixels();

    public abstract int getHeightPixels();

    public abstract void onBroken(Entity var1);

    @Override
    protected boolean shouldSetPosAfterLoading() {
        return false;
    }
}
