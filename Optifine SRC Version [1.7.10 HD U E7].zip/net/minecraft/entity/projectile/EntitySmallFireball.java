package net.minecraft.entity.projectile;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class EntitySmallFireball extends EntityFireball {
    public EntitySmallFireball(World var1) {
        super(var1);
        this.setSize(5.0F / 16.0F, 5.0F / 16.0F);
    }

    public EntitySmallFireball(World var1, EntityLivingBase var2, double var3, double var5, double var7) {
        super(var1, var2, var3, var5, var7);
        this.setSize(5.0F / 16.0F, 5.0F / 16.0F);
    }

    public EntitySmallFireball(World var1, double var2, double var4, double var6, double var8, double var10, double var12) {
        super(var1, var2, var4, var6, var8, var10, var12);
        this.setSize(5.0F / 16.0F, 5.0F / 16.0F);
    }

    @Override
    protected void onImpact(MovingObjectPosition var1) {
        if (!this.worldObj.isRemote) {
            if (var1.entityHit != null) {
                if (!var1.entityHit.isImmuneToFire() && var1.entityHit.attackEntityFrom(DamageSource.causeFireballDamage(this, this.shootingEntity), 5.0F)) {
                    var1.entityHit.setFire(5);
                }
            } else {
                int i = var1.blockX;
                int j = var1.blockY;
                int k = var1.blockZ;
                switch (var1.sideHit) {
                    case 0:
                        j--;
                        break;
                    case 1:
                        j++;
                        break;
                    case 2:
                        k--;
                        break;
                    case 3:
                        k++;
                        break;
                    case 4:
                        i--;
                        break;
                    case 5:
                        i++;
                }

                if (this.worldObj.isAirBlock(i, j, k)) {
                    this.worldObj.setBlock(i, j, k, Blocks.fire);
                }
            }

            this.setDead();
        }
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        return false;
    }
}
