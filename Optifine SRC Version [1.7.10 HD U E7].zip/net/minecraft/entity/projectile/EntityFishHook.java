package net.minecraft.entity.projectile;

import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemFishFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.StatList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.util.WeightedRandom;
import net.minecraft.util.WeightedRandomFishable;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class EntityFishHook extends Entity {
    private static final List JUNK = Arrays.asList(
        new WeightedRandomFishable(new ItemStack(Items.leather_boots), 10).setMaxDamagePercent(0.9F),
        new WeightedRandomFishable(new ItemStack(Items.leather), 10),
        new WeightedRandomFishable(new ItemStack(Items.bone), 10),
        new WeightedRandomFishable(new ItemStack(Items.potionitem), 10),
        new WeightedRandomFishable(new ItemStack(Items.string), 5),
        new WeightedRandomFishable(new ItemStack(Items.fishing_rod), 2).setMaxDamagePercent(0.9F),
        new WeightedRandomFishable(new ItemStack(Items.bowl), 10),
        new WeightedRandomFishable(new ItemStack(Items.stick), 5),
        new WeightedRandomFishable(new ItemStack(Items.dye, 10, 0), 1),
        new WeightedRandomFishable(new ItemStack(Blocks.tripwire_hook), 10),
        new WeightedRandomFishable(new ItemStack(Items.rotten_flesh), 10)
    );
    private static final List VALUABLES = Arrays.asList(
        new WeightedRandomFishable(new ItemStack(Blocks.waterlily), 1),
        new WeightedRandomFishable(new ItemStack(Items.name_tag), 1),
        new WeightedRandomFishable(new ItemStack(Items.saddle), 1),
        new WeightedRandomFishable(new ItemStack(Items.bow), 1).setMaxDamagePercent(0.25F).setEnchantable(),
        new WeightedRandomFishable(new ItemStack(Items.fishing_rod), 1).setMaxDamagePercent(0.25F).setEnchantable(),
        new WeightedRandomFishable(new ItemStack(Items.book), 1).setEnchantable()
    );
    private static final List FISH = Arrays.asList(
        new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.COD.getItemDamage()), 60),
        new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.SALMON.getItemDamage()), 25),
        new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.CLOWNFISH.getItemDamage()), 2),
        new WeightedRandomFishable(new ItemStack(Items.fish, 1, ItemFishFood.FishType.PUFFERFISH.getItemDamage()), 13)
    );
    private int xTile = -1;
    private int yTile = -1;
    private int zTile = -1;
    private Block inTile;
    private boolean inGround;
    public int shake;
    public EntityPlayer angler;
    private int ticksInGround;
    private int ticksInAir;
    private int ticksCatchable;
    private int ticksCaughtDelay;
    private int ticksCatchableDelay;
    private float fishApproachAngle;
    public Entity caughtEntity;
    private int fishPosRotationIncrements;
    private double fishX;
    private double fishY;
    private double fishZ;
    private double fishYaw;
    private double fishPitch;
    private double clientMotionX;
    private double clientMotionY;
    private double clientMotionZ;

    public EntityFishHook(World var1) {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.ignoreFrustumCheck = true;
    }

    public EntityFishHook(World var1, double var2, double var4, double var6, EntityPlayer var8) {
        this(var1);
        this.setPosition(var2, var4, var6);
        this.ignoreFrustumCheck = true;
        this.angler = var8;
        var8.fishEntity = this;
    }

    public EntityFishHook(World var1, EntityPlayer var2) {
        super(var1);
        this.ignoreFrustumCheck = true;
        this.angler = var2;
        this.angler.fishEntity = this;
        this.setSize(0.25F, 0.25F);
        this.setLocationAndAngles(var2.posX, var2.posY + 1.62 - var2.yOffset, var2.posZ, var2.rotationYaw, var2.rotationPitch);
        this.posX = this.posX - MathHelper.cos(this.rotationYaw / 180.0F * (float)Math.PI) * 0.16F;
        this.posY -= 0.1F;
        this.posZ = this.posZ - MathHelper.sin(this.rotationYaw / 180.0F * (float)Math.PI) * 0.16F;
        this.setPosition(this.posX, this.posY, this.posZ);
        this.yOffset = 0.0F;
        float f = 0.4F;
        this.motionX = -MathHelper.sin(this.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.rotationPitch / 180.0F * (float)Math.PI) * f;
        this.motionZ = MathHelper.cos(this.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.rotationPitch / 180.0F * (float)Math.PI) * f;
        this.motionY = -MathHelper.sin(this.rotationPitch / 180.0F * (float)Math.PI) * f;
        this.handleHookCasting(this.motionX, this.motionY, this.motionZ, 1.5F, 1.0F);
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public boolean isInRangeToRenderDist(double var1) {
        double d0 = this.boundingBox.getAverageEdgeLength() * 4.0;
        d0 *= 64.0;
        return var1 < d0 * d0;
    }

    public void handleHookCasting(double var1, double var3, double var5, float var7, float var8) {
        float f = MathHelper.sqrt_double(var1 * var1 + var3 * var3 + var5 * var5);
        var1 /= f;
        var3 /= f;
        var5 /= f;
        var1 += this.rand.nextGaussian() * 0.0075F * var8;
        var3 += this.rand.nextGaussian() * 0.0075F * var8;
        var5 += this.rand.nextGaussian() * 0.0075F * var8;
        var1 *= var7;
        var3 *= var7;
        var5 *= var7;
        this.motionX = var1;
        this.motionY = var3;
        this.motionZ = var5;
        float f1 = MathHelper.sqrt_double(var1 * var1 + var5 * var5);
        this.prevRotationYaw = this.rotationYaw = (float)(Math.atan2(var1, var5) * 180.0 / (float)Math.PI);
        this.prevRotationPitch = this.rotationPitch = (float)(Math.atan2(var3, f1) * 180.0 / (float)Math.PI);
        this.ticksInGround = 0;
    }

    @Override
    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9) {
        this.fishX = var1;
        this.fishY = var3;
        this.fishZ = var5;
        this.fishYaw = var7;
        this.fishPitch = var8;
        this.fishPosRotationIncrements = var9;
        this.motionX = this.clientMotionX;
        this.motionY = this.clientMotionY;
        this.motionZ = this.clientMotionZ;
    }

    @Override
    public void setVelocity(double var1, double var3, double var5) {
        this.clientMotionX = this.motionX = var1;
        this.clientMotionY = this.motionY = var3;
        this.clientMotionZ = this.motionZ = var5;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.fishPosRotationIncrements > 0) {
            double d7 = this.posX + (this.fishX - this.posX) / this.fishPosRotationIncrements;
            double d8 = this.posY + (this.fishY - this.posY) / this.fishPosRotationIncrements;
            double d9 = this.posZ + (this.fishZ - this.posZ) / this.fishPosRotationIncrements;
            double d1 = MathHelper.wrapAngleTo180_double(this.fishYaw - this.rotationYaw);
            this.rotationYaw = (float)(this.rotationYaw + d1 / this.fishPosRotationIncrements);
            this.rotationPitch = (float)(this.rotationPitch + (this.fishPitch - this.rotationPitch) / this.fishPosRotationIncrements);
            this.fishPosRotationIncrements--;
            this.setPosition(d7, d8, d9);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        } else {
            if (!this.worldObj.isRemote) {
                ItemStack itemstack = this.angler.getCurrentEquippedItem();
                if (this.angler.isDead
                    || !this.angler.isEntityAlive()
                    || itemstack == null
                    || itemstack.getItem() != Items.fishing_rod
                    || this.getDistanceSqToEntity(this.angler) > 1024.0) {
                    this.setDead();
                    this.angler.fishEntity = null;
                    return;
                }

                if (this.caughtEntity != null) {
                    if (!this.caughtEntity.isDead) {
                        this.posX = this.caughtEntity.posX;
                        this.posY = this.caughtEntity.boundingBox.minY + this.caughtEntity.height * 0.8;
                        this.posZ = this.caughtEntity.posZ;
                        return;
                    }

                    this.caughtEntity = null;
                }
            }

            if (this.shake > 0) {
                this.shake--;
            }

            if (this.inGround) {
                if (this.worldObj.getBlock(this.xTile, this.yTile, this.zTile) == this.inTile) {
                    this.ticksInGround++;
                    if (this.ticksInGround == 1200) {
                        this.setDead();
                    }

                    return;
                }

                this.inGround = false;
                this.motionX = this.motionX * (this.rand.nextFloat() * 0.2F);
                this.motionY = this.motionY * (this.rand.nextFloat() * 0.2F);
                this.motionZ = this.motionZ * (this.rand.nextFloat() * 0.2F);
                this.ticksInGround = 0;
                this.ticksInAir = 0;
            } else {
                this.ticksInAir++;
            }

            Vec3 vec31 = Vec3.createVectorHelper(this.posX, this.posY, this.posZ);
            Vec3 vec3 = Vec3.createVectorHelper(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
            MovingObjectPosition movingobjectposition = this.worldObj.rayTraceBlocks(vec31, vec3);
            vec31 = Vec3.createVectorHelper(this.posX, this.posY, this.posZ);
            vec3 = Vec3.createVectorHelper(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
            if (movingobjectposition != null) {
                vec3 = Vec3.createVectorHelper(movingobjectposition.hitVec.xCoord, movingobjectposition.hitVec.yCoord, movingobjectposition.hitVec.zCoord);
            }

            Entity entity = null;
            List list = this.worldObj
                .getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0, 1.0, 1.0));
            double d0 = 0.0;

            for (int i = 0; i < list.size(); i++) {
                Entity entity1 = (Entity)list.get(i);
                if (entity1.canBeCollidedWith() && (entity1 != this.angler || this.ticksInAir >= 5)) {
                    float f = 0.3F;
                    AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(f, f, f);
                    MovingObjectPosition movingobjectposition1 = axisalignedbb.calculateIntercept(vec31, vec3);
                    if (movingobjectposition1 != null) {
                        double d2 = vec31.distanceTo(movingobjectposition1.hitVec);
                        if (d2 < d0 || d0 == 0.0) {
                            entity = entity1;
                            d0 = d2;
                        }
                    }
                }
            }

            if (entity != null) {
                movingobjectposition = new MovingObjectPosition(entity);
            }

            if (movingobjectposition != null) {
                if (movingobjectposition.entityHit != null) {
                    if (movingobjectposition.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, this.angler), 0.0F)) {
                        this.caughtEntity = movingobjectposition.entityHit;
                    }
                } else {
                    this.inGround = true;
                }
            }

            if (!this.inGround) {
                this.moveEntity(this.motionX, this.motionY, this.motionZ);
                float f5 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
                this.rotationYaw = (float)(Math.atan2(this.motionX, this.motionZ) * 180.0 / (float)Math.PI);
                this.rotationPitch = (float)(Math.atan2(this.motionY, f5) * 180.0 / (float)Math.PI);

                while (this.rotationPitch - this.prevRotationPitch < -180.0F) {
                    this.prevRotationPitch -= 360.0F;
                }

                while (this.rotationPitch - this.prevRotationPitch >= 180.0F) {
                    this.prevRotationPitch += 360.0F;
                }

                while (this.rotationYaw - this.prevRotationYaw < -180.0F) {
                    this.prevRotationYaw -= 360.0F;
                }

                while (this.rotationYaw - this.prevRotationYaw >= 180.0F) {
                    this.prevRotationYaw += 360.0F;
                }

                this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
                this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
                float f6 = 0.92F;
                if (this.onGround || this.isCollidedHorizontally) {
                    f6 = 0.5F;
                }

                byte b0 = 5;
                double d10 = 0.0;

                for (int j = 0; j < b0; j++) {
                    double d3 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (j + 0) / b0 - 0.125 + 0.125;
                    double d4 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (j + 1) / b0 - 0.125 + 0.125;
                    AxisAlignedBB axisalignedbb1 = AxisAlignedBB.getBoundingBox(
                        this.boundingBox.minX, d3, this.boundingBox.minZ, this.boundingBox.maxX, d4, this.boundingBox.maxZ
                    );
                    if (this.worldObj.isAABBInMaterial(axisalignedbb1, Material.water)) {
                        d10 += 1.0 / b0;
                    }
                }

                if (!this.worldObj.isRemote && d10 > 0.0) {
                    WorldServer worldserver = (WorldServer)this.worldObj;
                    int k = 1;
                    if (this.rand.nextFloat() < 0.25F
                        && this.worldObj
                            .isRainingAt(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY) + 1, MathHelper.floor_double(this.posZ))) {
                        k = 2;
                    }

                    if (this.rand.nextFloat() < 0.5F
                        && !this.worldObj
                            .canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY) + 1, MathHelper.floor_double(this.posZ))) {
                        k--;
                    }

                    if (this.ticksCatchable > 0) {
                        this.ticksCatchable--;
                        if (this.ticksCatchable <= 0) {
                            this.ticksCaughtDelay = 0;
                            this.ticksCatchableDelay = 0;
                        }
                    } else if (this.ticksCatchableDelay > 0) {
                        this.ticksCatchableDelay -= k;
                        if (this.ticksCatchableDelay <= 0) {
                            this.motionY -= 0.2F;
                            this.playSound("random.splash", 0.25F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
                            float f1 = MathHelper.floor_double(this.boundingBox.minY);
                            worldserver.func_147487_a(
                                "bubble", this.posX, f1 + 1.0F, this.posZ, (int)(1.0F + this.width * 20.0F), this.width, 0.0, this.width, 0.2F
                            );
                            worldserver.func_147487_a(
                                "wake", this.posX, f1 + 1.0F, this.posZ, (int)(1.0F + this.width * 20.0F), this.width, 0.0, this.width, 0.2F
                            );
                            this.ticksCatchable = MathHelper.getRandomIntegerInRange(this.rand, 10, 30);
                        } else {
                            this.fishApproachAngle = (float)(this.fishApproachAngle + this.rand.nextGaussian() * 4.0);
                            float f7 = this.fishApproachAngle * ((float)Math.PI / 180.0F);
                            float f9 = MathHelper.sin(f7);
                            float f2 = MathHelper.cos(f7);
                            double d12 = this.posX + f9 * this.ticksCatchableDelay * 0.1F;
                            double d5 = MathHelper.floor_double(this.boundingBox.minY) + 1.0F;
                            double d6 = this.posZ + f2 * this.ticksCatchableDelay * 0.1F;
                            if (this.rand.nextFloat() < 0.15F) {
                                worldserver.func_147487_a("bubble", d12, d5 - 0.1F, d6, 1, f9, 0.1, f2, 0.0);
                            }

                            float f3 = f9 * 0.04F;
                            float f4 = f2 * 0.04F;
                            worldserver.func_147487_a("wake", d12, d5, d6, 0, f4, 0.01, -f3, 1.0);
                            worldserver.func_147487_a("wake", d12, d5, d6, 0, -f4, 0.01, f3, 1.0);
                        }
                    } else if (this.ticksCaughtDelay > 0) {
                        this.ticksCaughtDelay -= k;
                        float f8 = 0.15F;
                        if (this.ticksCaughtDelay < 20) {
                            f8 = (float)(f8 + (20 - this.ticksCaughtDelay) * 0.05);
                        } else if (this.ticksCaughtDelay < 40) {
                            f8 = (float)(f8 + (40 - this.ticksCaughtDelay) * 0.02);
                        } else if (this.ticksCaughtDelay < 60) {
                            f8 = (float)(f8 + (60 - this.ticksCaughtDelay) * 0.01);
                        }

                        if (this.rand.nextFloat() < f8) {
                            float f10 = MathHelper.randomFloatClamp(this.rand, 0.0F, 360.0F) * ((float)Math.PI / 180.0F);
                            float f11 = MathHelper.randomFloatClamp(this.rand, 25.0F, 60.0F);
                            double d13 = this.posX + MathHelper.sin(f10) * f11 * 0.1F;
                            double d14 = MathHelper.floor_double(this.boundingBox.minY) + 1.0F;
                            double d15 = this.posZ + MathHelper.cos(f10) * f11 * 0.1F;
                            worldserver.func_147487_a("splash", d13, d14, d15, 2 + this.rand.nextInt(2), 0.1F, 0.0, 0.1F, 0.0);
                        }

                        if (this.ticksCaughtDelay <= 0) {
                            this.fishApproachAngle = MathHelper.randomFloatClamp(this.rand, 0.0F, 360.0F);
                            this.ticksCatchableDelay = MathHelper.getRandomIntegerInRange(this.rand, 20, 80);
                        }
                    } else {
                        this.ticksCaughtDelay = MathHelper.getRandomIntegerInRange(this.rand, 100, 900);
                        this.ticksCaughtDelay = this.ticksCaughtDelay - EnchantmentHelper.func_151387_h(this.angler) * 20 * 5;
                    }

                    if (this.ticksCatchable > 0) {
                        this.motionY = this.motionY - this.rand.nextFloat() * this.rand.nextFloat() * this.rand.nextFloat() * 0.2;
                    }
                }

                double d11 = d10 * 2.0 - 1.0;
                this.motionY += 0.04F * d11;
                if (d10 > 0.0) {
                    f6 = (float)(f6 * 0.9);
                    this.motionY *= 0.8;
                }

                this.motionX *= f6;
                this.motionY *= f6;
                this.motionZ *= f6;
                this.setPosition(this.posX, this.posY, this.posZ);
            }
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setShort("xTile", (short)this.xTile);
        var1.setShort("yTile", (short)this.yTile);
        var1.setShort("zTile", (short)this.zTile);
        var1.setByte("inTile", (byte)Block.getIdFromBlock(this.inTile));
        var1.setByte("shake", (byte)this.shake);
        var1.setByte("inGround", (byte)(this.inGround ? 1 : 0));
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        this.xTile = var1.getShort("xTile");
        this.yTile = var1.getShort("yTile");
        this.zTile = var1.getShort("zTile");
        this.inTile = Block.getBlockById(var1.getByte("inTile") & 255);
        this.shake = var1.getByte("shake") & 255;
        this.inGround = var1.getByte("inGround") == 1;
    }

    @Override
    public float getShadowSize() {
        return 0.0F;
    }

    public int handleHookRetraction() {
        if (this.worldObj.isRemote) {
            return 0;
        }

        byte b0 = 0;
        if (this.caughtEntity != null) {
            double d0 = this.angler.posX - this.posX;
            double d2 = this.angler.posY - this.posY;
            double d4 = this.angler.posZ - this.posZ;
            double d6 = MathHelper.sqrt_double(d0 * d0 + d2 * d2 + d4 * d4);
            double d8 = 0.1;
            this.caughtEntity.motionX += d0 * d8;
            this.caughtEntity.motionY = this.caughtEntity.motionY + (d2 * d8 + MathHelper.sqrt_double(d6) * 0.08);
            this.caughtEntity.motionZ += d4 * d8;
            b0 = 3;
        } else if (this.ticksCatchable > 0) {
            EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, this.func_146033_f());
            double d1 = this.angler.posX - this.posX;
            double d3 = this.angler.posY - this.posY;
            double d5 = this.angler.posZ - this.posZ;
            double d7 = MathHelper.sqrt_double(d1 * d1 + d3 * d3 + d5 * d5);
            double d9 = 0.1;
            entityitem.motionX = d1 * d9;
            entityitem.motionY = d3 * d9 + MathHelper.sqrt_double(d7) * 0.08;
            entityitem.motionZ = d5 * d9;
            this.worldObj.spawnEntityInWorld(entityitem);
            this.angler
                .worldObj
                .spawnEntityInWorld(
                    new EntityXPOrb(this.angler.worldObj, this.angler.posX, this.angler.posY + 0.5, this.angler.posZ + 0.5, this.rand.nextInt(6) + 1)
                );
            b0 = 1;
        }

        if (this.inGround) {
            b0 = 2;
        }

        this.setDead();
        this.angler.fishEntity = null;
        return b0;
    }

    private ItemStack func_146033_f() {
        float f = this.worldObj.rand.nextFloat();
        int i = EnchantmentHelper.func_151386_g(this.angler);
        int j = EnchantmentHelper.func_151387_h(this.angler);
        float f1 = 0.1F - i * 0.025F - j * 0.01F;
        float f2 = 0.05F + i * 0.01F - j * 0.01F;
        f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
        f2 = MathHelper.clamp_float(f2, 0.0F, 1.0F);
        if (f < f1) {
            this.angler.addStat(StatList.field_151183_A, 1);
            return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.rand, JUNK)).getItemStack(this.rand);
        } else {
            f -= f1;
            if (f < f2) {
                this.angler.addStat(StatList.field_151184_B, 1);
                return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.rand, VALUABLES)).getItemStack(this.rand);
            } else {
                f -= f2;
                this.angler.addStat(StatList.fishCaughtStat, 1);
                return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.rand, FISH)).getItemStack(this.rand);
            }
        }
    }

    @Override
    public void setDead() {
        super.setDead();
        if (this.angler != null) {
            this.angler.fishEntity = null;
        }
    }
}
