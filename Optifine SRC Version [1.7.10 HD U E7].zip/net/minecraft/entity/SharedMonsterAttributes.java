package net.minecraft.entity;

import java.util.Collection;
import java.util.UUID;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.BaseAttributeMap;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SharedMonsterAttributes {
    private static final Logger logger = LogManager.getLogger();
    public static final IAttribute maxHealth = new RangedAttribute("generic.maxHealth", 20.0, 0.0, Double.MAX_VALUE)
        .setDescription("Max Health")
        .setShouldWatch(true);
    public static final IAttribute followRange = new RangedAttribute("generic.followRange", 32.0, 0.0, 2048.0).setDescription("Follow Range");
    public static final IAttribute knockbackResistance = new RangedAttribute("generic.knockbackResistance", 0.0, 0.0, 1.0)
        .setDescription("Knockback Resistance");
    public static final IAttribute movementSpeed = new RangedAttribute("generic.movementSpeed", 0.7F, 0.0, Double.MAX_VALUE)
        .setDescription("Movement Speed")
        .setShouldWatch(true);
    public static final IAttribute attackDamage = new RangedAttribute("generic.attackDamage", 2.0, 0.0, Double.MAX_VALUE);

    public static NBTTagList writeBaseAttributeMapToNBT(BaseAttributeMap var0) {
        NBTTagList nbttaglist = new NBTTagList();

        for (IAttributeInstance iattributeinstance : (Iterable<IAttributeInstance>) (Iterable) var0.getAllAttributes()) {
            nbttaglist.appendTag(writeAttributeInstanceToNBT(iattributeinstance));
        }

        return nbttaglist;
    }

    private static NBTTagCompound writeAttributeInstanceToNBT(IAttributeInstance var0) {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        IAttribute iattribute = var0.getAttribute();
        nbttagcompound.setString("Name", iattribute.getAttributeUnlocalizedName());
        nbttagcompound.setDouble("Base", var0.getBaseValue());
        Collection collection = var0.func_111122_c();
        if (collection != null && !collection.isEmpty()) {
            NBTTagList nbttaglist = new NBTTagList();

            for (AttributeModifier attributemodifier : (Iterable<AttributeModifier>) (Iterable) collection) {
                if (attributemodifier.isSaved()) {
                    nbttaglist.appendTag(writeAttributeModifierToNBT(attributemodifier));
                }
            }

            nbttagcompound.setTag("Modifiers", nbttaglist);
        }

        return nbttagcompound;
    }

    private static NBTTagCompound writeAttributeModifierToNBT(AttributeModifier var0) {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        nbttagcompound.setString("Name", var0.getName());
        nbttagcompound.setDouble("Amount", var0.getAmount());
        nbttagcompound.setInteger("Operation", var0.getOperation());
        nbttagcompound.setLong("UUIDMost", var0.getID().getMostSignificantBits());
        nbttagcompound.setLong("UUIDLeast", var0.getID().getLeastSignificantBits());
        return nbttagcompound;
    }

    public static void func_151475_a(BaseAttributeMap var0, NBTTagList var1) {
        for (int i = 0; i < var1.tagCount(); i++) {
            NBTTagCompound nbttagcompound = var1.getCompoundTagAt(i);
            IAttributeInstance iattributeinstance = var0.getAttributeInstanceByName(nbttagcompound.getString("Name"));
            if (iattributeinstance != null) {
                applyModifiersToAttributeInstance(iattributeinstance, nbttagcompound);
            } else {
                logger.warn("Ignoring unknown attribute '" + nbttagcompound.getString("Name") + "'");
            }
        }
    }

    private static void applyModifiersToAttributeInstance(IAttributeInstance var0, NBTTagCompound var1) {
        var0.setBaseValue(var1.getDouble("Base"));
        if (var1.hasKey("Modifiers", 9)) {
            NBTTagList nbttaglist = var1.getTagList("Modifiers", 10);

            for (int i = 0; i < nbttaglist.tagCount(); i++) {
                AttributeModifier attributemodifier = readAttributeModifierFromNBT(nbttaglist.getCompoundTagAt(i));
                AttributeModifier attributemodifier1 = var0.getModifier(attributemodifier.getID());
                if (attributemodifier1 != null) {
                    var0.removeModifier(attributemodifier1);
                }

                var0.applyModifier(attributemodifier);
            }
        }
    }

    public static AttributeModifier readAttributeModifierFromNBT(NBTTagCompound var0) {
        UUID uuid = new UUID(var0.getLong("UUIDMost"), var0.getLong("UUIDLeast"));
        return new AttributeModifier(uuid, var0.getString("Name"), var0.getDouble("Amount"), var0.getInteger("Operation"));
    }
}
