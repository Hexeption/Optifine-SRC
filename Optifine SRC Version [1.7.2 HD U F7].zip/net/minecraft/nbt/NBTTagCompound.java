package net.minecraft.nbt;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.ReportedException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NBTTagCompound extends NBTBase {
    private static final Logger logger = LogManager.getLogger();
    private Map tagMap = new HashMap();

    @Override
    void write(DataOutput var1) throws IOException {
        for (String s : (Iterable<String>) (Iterable) this.tagMap.keySet()) {
            NBTBase nbtbase = (NBTBase)this.tagMap.get(s);
            writeEntry(s, nbtbase, var1);
        }

        var1.writeByte(0);
    }

    @Override
    void func_74735_a(DataInput var1, int var2) throws IOException {
        if (var2 > 512) {
            throw new RuntimeException("Tried to read NBT tag with too high complexity, depth > 512");
        }

        this.tagMap.clear();

        while (true) {
            byte b0 = func_150300_a(var1);
            if (b0 == 0) {
                return;
            }

            String s = func_150294_b(var1);
            NBTBase nbtbase = func_150293_a(b0, s, var1, var2 + 1);
            this.tagMap.put(s, nbtbase);
        }
    }

    public Set getKeySet() {
        return this.tagMap.keySet();
    }

    @Override
    public byte getId() {
        return 10;
    }

    public void setTag(String var1, NBTBase var2) {
        this.tagMap.put(var1, var2);
    }

    public void setByte(String var1, byte var2) {
        this.tagMap.put(var1, new NBTTagByte(var2));
    }

    public void setShort(String var1, short var2) {
        this.tagMap.put(var1, new NBTTagShort(var2));
    }

    public void setInteger(String var1, int var2) {
        this.tagMap.put(var1, new NBTTagInt(var2));
    }

    public void setLong(String var1, long var2) {
        this.tagMap.put(var1, new NBTTagLong(var2));
    }

    public void setFloat(String var1, float var2) {
        this.tagMap.put(var1, new NBTTagFloat(var2));
    }

    public void setDouble(String var1, double var2) {
        this.tagMap.put(var1, new NBTTagDouble(var2));
    }

    public void setString(String var1, String var2) {
        this.tagMap.put(var1, new NBTTagString(var2));
    }

    public void setByteArray(String var1, byte[] var2) {
        this.tagMap.put(var1, new NBTTagByteArray(var2));
    }

    public void setIntArray(String var1, int[] var2) {
        this.tagMap.put(var1, new NBTTagIntArray(var2));
    }

    public void setBoolean(String var1, boolean var2) {
        this.setByte(var1, (byte)(var2 ? 1 : 0));
    }

    public NBTBase getTag(String var1) {
        return (NBTBase)this.tagMap.get(var1);
    }

    public byte getTagId(String var1) {
        NBTBase nbtbase = (NBTBase)this.tagMap.get(var1);
        return nbtbase != null ? nbtbase.getId() : 0;
    }

    public boolean hasKey(String var1) {
        return this.tagMap.containsKey(var1);
    }

    public boolean hasKey(String var1, int var2) {
        byte b0 = this.getTagId(var1);
        if (b0 == var2) {
            return true;
        }

        if (var2 != 99) {
            if (b0 > 0) {
                logger.warn("NBT tag {} was of wrong type; expected {}, found {}", var1, func_150283_g(var2), func_150283_g(b0));
            }

            return false;
        } else {
            return b0 == 1 || b0 == 2 || b0 == 3 || b0 == 4 || b0 == 5 || b0 == 6;
        }
    }

    public byte getByte(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? 0 : ((NBTBase.NBTPrimitive)this.tagMap.get(var1)).getByte();
        } catch (ClassCastException classcastexception) {
            return 0;
        }
    }

    public short getShort(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? 0 : ((NBTBase.NBTPrimitive)this.tagMap.get(var1)).getShort();
        } catch (ClassCastException classcastexception) {
            return 0;
        }
    }

    public int getInteger(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? 0 : ((NBTBase.NBTPrimitive)this.tagMap.get(var1)).getInt();
        } catch (ClassCastException classcastexception) {
            return 0;
        }
    }

    public long getLong(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? 0L : ((NBTBase.NBTPrimitive)this.tagMap.get(var1)).getLong();
        } catch (ClassCastException classcastexception) {
            return 0L;
        }
    }

    public float getFloat(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? 0.0F : ((NBTBase.NBTPrimitive)this.tagMap.get(var1)).getFloat();
        } catch (ClassCastException classcastexception) {
            return 0.0F;
        }
    }

    public double getDouble(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? 0.0 : ((NBTBase.NBTPrimitive)this.tagMap.get(var1)).getDouble();
        } catch (ClassCastException classcastexception) {
            return 0.0;
        }
    }

    public String getString(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? "" : ((NBTBase)this.tagMap.get(var1)).getString();
        } catch (ClassCastException classcastexception) {
            return "";
        }
    }

    public byte[] getByteArray(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? new byte[0] : ((NBTTagByteArray)this.tagMap.get(var1)).getByteArray();
        } catch (ClassCastException classcastexception) {
            throw new ReportedException(this.createCrashReport(var1, 7, classcastexception));
        }
    }

    public int[] getIntArray(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? new int[0] : ((NBTTagIntArray)this.tagMap.get(var1)).getIntArray();
        } catch (ClassCastException classcastexception) {
            throw new ReportedException(this.createCrashReport(var1, 11, classcastexception));
        }
    }

    public NBTTagCompound getCompoundTag(String var1) {
        try {
            return !this.tagMap.containsKey(var1) ? new NBTTagCompound() : (NBTTagCompound)this.tagMap.get(var1);
        } catch (ClassCastException classcastexception) {
            throw new ReportedException(this.createCrashReport(var1, 10, classcastexception));
        }
    }

    public NBTTagList getTagList(String var1, int var2) {
        try {
            if (this.getTagId(var1) != 9) {
                return new NBTTagList();
            }

            NBTTagList nbttaglist = (NBTTagList)this.tagMap.get(var1);
            return nbttaglist.tagCount() > 0 && nbttaglist.getTagType() != var2 ? new NBTTagList() : nbttaglist;
        } catch (ClassCastException classcastexception) {
            throw new ReportedException(this.createCrashReport(var1, 9, classcastexception));
        }
    }

    public boolean getBoolean(String var1) {
        return this.getByte(var1) != 0;
    }

    public void removeTag(String var1) {
        this.tagMap.remove(var1);
    }

    @Override
    public String toString() {
        String s = "{";

        for (String s1 : (Iterable<String>) (Iterable) this.tagMap.keySet()) {
            s = s + s1 + ':' + this.tagMap.get(s1) + ',';
        }

        return s + "}";
    }

    public boolean hasNoTags() {
        return this.tagMap.isEmpty();
    }

    private CrashReport createCrashReport(final String var1, final int var2, ClassCastException var3) {
        CrashReport crashreport = CrashReport.makeCrashReport(var3, "Reading NBT data");
        CrashReportCategory crashreportcategory = crashreport.makeCategoryDepth("Corrupt NBT tag", 1);
        crashreportcategory.addCrashSectionCallable("Tag type found", new Callable() {
            public String call() {
                return NBTBase.NBT_TYPES[((NBTBase)NBTTagCompound.this.tagMap.get(var1)).getId()];
            }
        });
        crashreportcategory.addCrashSectionCallable("Tag type expected", new Callable() {
            public String call() {
                return NBTBase.NBT_TYPES[var2];
            }
        });
        crashreportcategory.addCrashSection("Tag name", var1);
        return crashreport;
    }

    @Override
    public NBTBase copy() {
        NBTTagCompound nbttagcompound = new NBTTagCompound();

        for (String s : (Iterable<String>) (Iterable) this.tagMap.keySet()) {
            nbttagcompound.setTag(s, ((NBTBase)this.tagMap.get(s)).copy());
        }

        return nbttagcompound;
    }

    @Override
    public boolean equals(Object var1) {
        if (super.equals(var1)) {
            NBTTagCompound nbttagcompound = (NBTTagCompound)var1;
            return this.tagMap.entrySet().equals(nbttagcompound.tagMap.entrySet());
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ this.tagMap.hashCode();
    }

    private static void writeEntry(String var0, NBTBase var1, DataOutput var2) throws IOException {
        var2.writeByte(var1.getId());
        if (var1.getId() != 0) {
            var2.writeUTF(var0);
            var1.write(var2);
        }
    }

    private static byte func_150300_a(DataInput var0) throws IOException {
        return var0.readByte();
    }

    private static String func_150294_b(DataInput var0) throws IOException {
        return var0.readUTF();
    }

    static NBTBase func_150293_a(byte var0, String var1, DataInput var2, int var3) {
        NBTBase nbtbase = NBTBase.createNewByType(var0);

        try {
            nbtbase.func_74735_a(var2, var3);
            return nbtbase;
        } catch (IOException ioexception) {
            CrashReport crashreport = CrashReport.makeCrashReport(ioexception, "Loading NBT data");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("NBT Tag");
            crashreportcategory.addCrashSection("Tag name", var1);
            crashreportcategory.addCrashSection("Tag type", var0);
            throw new ReportedException(crashreport);
        }
    }
}
