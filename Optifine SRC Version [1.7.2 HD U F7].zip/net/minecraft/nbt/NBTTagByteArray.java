package net.minecraft.nbt;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

public class NBTTagByteArray extends NBTBase {
    private byte[] byteArray;

    NBTTagByteArray() {
    }

    public NBTTagByteArray(byte[] var1) {
        this.byteArray = var1;
    }

    @Override
    void write(DataOutput var1) throws IOException {
        var1.writeInt(this.byteArray.length);
        var1.write(this.byteArray);
    }

    @Override
    void func_74735_a(DataInput var1, int var2) throws IOException {
        int i = var1.readInt();
        this.byteArray = new byte[i];
        var1.readFully(this.byteArray);
    }

    @Override
    public byte getId() {
        return 7;
    }

    @Override
    public String toString() {
        return "[" + this.byteArray.length + " bytes]";
    }

    @Override
    public NBTBase copy() {
        byte[] abyte = new byte[this.byteArray.length];
        System.arraycopy(this.byteArray, 0, abyte, 0, this.byteArray.length);
        return new NBTTagByteArray(abyte);
    }

    @Override
    public boolean equals(Object var1) {
        return super.equals(var1) ? Arrays.equals(this.byteArray, ((NBTTagByteArray)var1).byteArray) : false;
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ Arrays.hashCode(this.byteArray);
    }

    public byte[] getByteArray() {
        return this.byteArray;
    }
}
