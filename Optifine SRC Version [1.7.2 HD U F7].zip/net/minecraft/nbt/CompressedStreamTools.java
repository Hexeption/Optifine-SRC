package net.minecraft.nbt;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.ReportedException;

public class CompressedStreamTools {
    public static NBTTagCompound readCompressed(InputStream var0) throws IOException {
        DataInputStream datainputstream = new DataInputStream(new BufferedInputStream(new GZIPInputStream(var0)));

        try {
            return read(datainputstream);
        } finally {
            datainputstream.close();
        }
    }

    public static void writeCompressed(NBTTagCompound var0, OutputStream var1) throws IOException {
        DataOutputStream dataoutputstream = new DataOutputStream(new GZIPOutputStream(var1));

        try {
            write(var0, dataoutputstream);
        } finally {
            dataoutputstream.close();
        }
    }

    public static NBTTagCompound func_74792_a(byte[] var0) throws IOException {
        DataInputStream datainputstream = new DataInputStream(new BufferedInputStream(new GZIPInputStream(new ByteArrayInputStream(var0))));

        try {
            return read(datainputstream);
        } finally {
            datainputstream.close();
        }
    }

    public static byte[] compress(NBTTagCompound var0) throws IOException {
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
        DataOutputStream dataoutputstream = new DataOutputStream(new GZIPOutputStream(bytearrayoutputstream));

        try {
            write(var0, dataoutputstream);
        } finally {
            dataoutputstream.close();
        }

        return bytearrayoutputstream.toByteArray();
    }

    public static void safeWrite(NBTTagCompound var0, File var1) throws IOException {
        File file1 = new File(var1.getAbsolutePath() + "_tmp");
        if (file1.exists()) {
            file1.delete();
        }

        write(var0, file1);
        if (var1.exists()) {
            var1.delete();
        }

        if (var1.exists()) {
            throw new IOException("Failed to delete " + var1);
        }

        file1.renameTo(var1);
    }

    public static void write(NBTTagCompound var0, File var1) throws IOException {
        DataOutputStream dataoutputstream = new DataOutputStream(new FileOutputStream(var1));

        try {
            write(var0, dataoutputstream);
        } finally {
            dataoutputstream.close();
        }
    }

    public static NBTTagCompound read(File var0) throws IOException {
        if (!var0.exists()) {
            return null;
        }

        DataInputStream datainputstream = new DataInputStream(new FileInputStream(var0));

        try {
            return read(datainputstream);
        } finally {
            datainputstream.close();
        }
    }

    public static NBTTagCompound read(DataInput var0) throws IOException {
        NBTBase nbtbase = func_150664_a(var0, 0);
        if (nbtbase instanceof NBTTagCompound) {
            return (NBTTagCompound)nbtbase;
        } else {
            throw new IOException("Root tag must be a named compound tag");
        }
    }

    public static void write(NBTTagCompound var0, DataOutput var1) throws IOException {
        writeTag(var0, var1);
    }

    private static void writeTag(NBTBase var0, DataOutput var1) throws IOException {
        var1.writeByte(var0.getId());
        if (var0.getId() != 0) {
            var1.writeUTF("");
            var0.write(var1);
        }
    }

    private static NBTBase func_150664_a(DataInput var0, int var1) throws IOException {
        byte b0 = var0.readByte();
        if (b0 == 0) {
            return new NBTTagEnd();
        }

        var0.readUTF();
        NBTBase nbtbase = NBTBase.createNewByType(b0);

        try {
            nbtbase.func_74735_a(var0, var1);
            return nbtbase;
        } catch (IOException ioexception) {
            CrashReport crashreport = CrashReport.makeCrashReport(ioexception, "Loading NBT data");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("NBT Tag");
            crashreportcategory.addCrashSection("Tag name", "[UNNAMED TAG]");
            crashreportcategory.addCrashSection("Tag type", b0);
            throw new ReportedException(crashreport);
        }
    }
}
