package net.minecraft.util;

import java.util.UUID;
import java.util.regex.Pattern;

public class Util {
    private static final Pattern field_147174_a = Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}");

    public static Util.EnumOS getOSType() {
        String s = System.getProperty("os.name").toLowerCase();
        if (s.contains("win")) {
            return Util.EnumOS.WINDOWS;
        } else if (s.contains("mac")) {
            return Util.EnumOS.MACOS;
        } else if (s.contains("solaris")) {
            return Util.EnumOS.SOLARIS;
        } else if (s.contains("sunos")) {
            return Util.EnumOS.SOLARIS;
        } else if (s.contains("linux")) {
            return Util.EnumOS.LINUX;
        } else {
            return s.contains("unix") ? Util.EnumOS.LINUX : Util.EnumOS.UNKNOWN;
        }
    }

    public static boolean func_147172_a(String var0) {
        return field_147174_a.matcher(var0).matches();
    }

    public static UUID func_147173_b(String var0) {
        if (var0 == null) {
            return null;
        }

        if (func_147172_a(var0)) {
            return UUID.fromString(var0);
        }

        if (var0.length() == 32) {
            String s = var0.substring(0, 8)
                + "-"
                + var0.substring(8, 12)
                + "-"
                + var0.substring(12, 16)
                + "-"
                + var0.substring(16, 20)
                + "-"
                + var0.substring(20, 32);
            if (func_147172_a(s)) {
                return UUID.fromString(s);
            }
        }

        return null;
    }

    public enum EnumOS {
        LINUX,
        SOLARIS,
        WINDOWS,
        MACOS,
        UNKNOWN;
    }
}
