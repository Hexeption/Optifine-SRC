package net.minecraft.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;

public class CombatTracker {
    private final List combatEntries = new ArrayList();
    private final EntityLivingBase fighter;
    private int field_94555_c;
    private boolean field_94552_d;
    private boolean field_94553_e;
    private String field_94551_f;

    public CombatTracker(EntityLivingBase var1) {
        this.fighter = var1;
    }

    public void func_94545_a() {
        this.func_94542_g();
        if (this.fighter.isOnLadder()) {
            Block block = this.fighter
                .worldObj
                .getBlock(
                    MathHelper.floor_double(this.fighter.posX),
                    MathHelper.floor_double(this.fighter.boundingBox.minY),
                    MathHelper.floor_double(this.fighter.posZ)
                );
            if (block == Blocks.ladder) {
                this.field_94551_f = "ladder";
            } else if (block == Blocks.vine) {
                this.field_94551_f = "vines";
            }
        } else if (this.fighter.isInWater()) {
            this.field_94551_f = "water";
        }
    }

    public void func_94547_a(DamageSource var1, float var2, float var3) {
        this.func_94549_h();
        this.func_94545_a();
        CombatEntry combatentry = new CombatEntry(var1, this.fighter.ticksExisted, var2, var3, this.field_94551_f, this.fighter.fallDistance);
        this.combatEntries.add(combatentry);
        this.field_94555_c = this.fighter.ticksExisted;
        this.field_94553_e = true;
        this.field_94552_d = this.field_94552_d | combatentry.func_94559_f();
    }

    public IChatComponent func_151521_b() {
        if (this.combatEntries.size() == 0) {
            return new ChatComponentTranslation("death.attack.generic", this.fighter.getFormattedCommandSenderName());
        }

        CombatEntry combatentry = this.func_94544_f();
        CombatEntry combatentry1 = (CombatEntry)this.combatEntries.get(this.combatEntries.size() - 1);
        IChatComponent ichatcomponent1 = combatentry1.func_151522_h();
        Entity entity = combatentry1.getDamageSrc().getEntity();
        IChatComponent ichatcomponent;
        if (combatentry != null && combatentry1.getDamageSrc() == DamageSource.fall) {
            IChatComponent ichatcomponent2 = combatentry.func_151522_h();
            if (combatentry.getDamageSrc() == DamageSource.fall || combatentry.getDamageSrc() == DamageSource.outOfWorld) {
                ichatcomponent = new ChatComponentTranslation(
                    "death.fell.accident." + this.func_94548_b(combatentry), this.fighter.getFormattedCommandSenderName()
                );
            } else if (ichatcomponent2 != null && (ichatcomponent1 == null || !ichatcomponent2.equals(ichatcomponent1))) {
                Entity entity1 = combatentry.getDamageSrc().getEntity();
                ItemStack itemstack1 = entity1 instanceof EntityLivingBase ? ((EntityLivingBase)entity1).getHeldItem() : null;
                if (itemstack1 != null && itemstack1.hasDisplayName()) {
                    ichatcomponent = new ChatComponentTranslation(
                        "death.fell.assist.item", this.fighter.getFormattedCommandSenderName(), ichatcomponent2, itemstack1.func_151000_E()
                    );
                } else {
                    ichatcomponent = new ChatComponentTranslation("death.fell.assist", this.fighter.getFormattedCommandSenderName(), ichatcomponent2);
                }
            } else if (ichatcomponent1 != null) {
                ItemStack itemstack = entity instanceof EntityLivingBase ? ((EntityLivingBase)entity).getHeldItem() : null;
                if (itemstack != null && itemstack.hasDisplayName()) {
                    ichatcomponent = new ChatComponentTranslation(
                        "death.fell.finish.item", this.fighter.getFormattedCommandSenderName(), ichatcomponent1, itemstack.func_151000_E()
                    );
                } else {
                    ichatcomponent = new ChatComponentTranslation("death.fell.finish", this.fighter.getFormattedCommandSenderName(), ichatcomponent1);
                }
            } else {
                ichatcomponent = new ChatComponentTranslation("death.fell.killer", this.fighter.getFormattedCommandSenderName());
            }
        } else {
            ichatcomponent = combatentry1.getDamageSrc().getDeathMessage(this.fighter);
        }

        return ichatcomponent;
    }

    public EntityLivingBase func_94550_c() {
        EntityLivingBase entitylivingbase = null;
        EntityPlayer entityplayer = null;
        float f = 0.0F;
        float f1 = 0.0F;

        for (CombatEntry combatentry : (Iterable<CombatEntry>) (Iterable) this.combatEntries) {
            if (combatentry.getDamageSrc().getEntity() instanceof EntityPlayer && (entityplayer == null || combatentry.func_94563_c() > f1)) {
                f1 = combatentry.func_94563_c();
                entityplayer = (EntityPlayer)combatentry.getDamageSrc().getEntity();
            }

            if (combatentry.getDamageSrc().getEntity() instanceof EntityLivingBase && (entitylivingbase == null || combatentry.func_94563_c() > f)) {
                f = combatentry.func_94563_c();
                entitylivingbase = (EntityLivingBase)combatentry.getDamageSrc().getEntity();
            }
        }

        return entityplayer != null && f1 >= f / 3.0F ? entityplayer : entitylivingbase;
    }

    private CombatEntry func_94544_f() {
        CombatEntry combatentry = null;
        CombatEntry combatentry1 = null;
        byte b0 = 0;
        float f = 0.0F;

        for (int i = 0; i < this.combatEntries.size(); i++) {
            CombatEntry combatentry2 = (CombatEntry)this.combatEntries.get(i);
            CombatEntry combatentry3 = i > 0 ? (CombatEntry)this.combatEntries.get(i - 1) : null;
            if ((combatentry2.getDamageSrc() == DamageSource.fall || combatentry2.getDamageSrc() == DamageSource.outOfWorld)
                && combatentry2.func_94561_i() > 0.0F
                && (combatentry == null || combatentry2.func_94561_i() > f)) {
                if (i > 0) {
                    combatentry = combatentry3;
                } else {
                    combatentry = combatentry2;
                }

                f = combatentry2.func_94561_i();
            }

            if (combatentry2.func_94562_g() != null && (combatentry1 == null || combatentry2.func_94563_c() > b0)) {
                combatentry1 = combatentry2;
            }
        }

        if (f > 5.0F && combatentry != null) {
            return combatentry;
        } else {
            return b0 > 5 && combatentry1 != null ? combatentry1 : null;
        }
    }

    private String func_94548_b(CombatEntry var1) {
        return var1.func_94562_g() == null ? "generic" : var1.func_94562_g();
    }

    private void func_94542_g() {
        this.field_94551_f = null;
    }

    private void func_94549_h() {
        int i = this.field_94552_d ? 300 : 100;
        if (this.field_94553_e && this.fighter.ticksExisted - this.field_94555_c > i) {
            this.combatEntries.clear();
            this.field_94553_e = false;
            this.field_94552_d = false;
        }
    }
}
