package net.minecraft.util;

import java.util.ArrayList;
import java.util.List;

public class AABBPool {
    private final int field_72306_a;
    private final int field_72304_b;
    private final List field_72305_c = new ArrayList();
    private int field_72302_d;
    private int field_72303_e;
    private int field_72301_f;

    public AABBPool(int var1, int var2) {
        this.field_72306_a = var1;
        this.field_72304_b = var2;
    }

    public AxisAlignedBB func_72299_a(double var1, double var3, double var5, double var7, double var9, double var11) {
        AxisAlignedBB axisalignedbb;
        if (this.field_72302_d >= this.field_72305_c.size()) {
            axisalignedbb = new AxisAlignedBB(var1, var3, var5, var7, var9, var11);
            this.field_72305_c.add(axisalignedbb);
        } else {
            axisalignedbb = (AxisAlignedBB)this.field_72305_c.get(this.field_72302_d);
            axisalignedbb.setBounds(var1, var3, var5, var7, var9, var11);
        }

        this.field_72302_d++;
        return axisalignedbb;
    }

    public void func_72298_a() {
        if (this.field_72302_d > this.field_72303_e) {
            this.field_72303_e = this.field_72302_d;
        }

        if (this.field_72301_f++ == this.field_72306_a) {
            int i = Math.max(this.field_72303_e, this.field_72305_c.size() - this.field_72304_b);

            while (this.field_72305_c.size() > i) {
                this.field_72305_c.remove(i);
            }

            this.field_72303_e = 0;
            this.field_72301_f = 0;
        }

        this.field_72302_d = 0;
    }

    public void func_72300_b() {
        this.field_72302_d = 0;
        this.field_72305_c.clear();
    }

    public int func_83013_c() {
        return this.field_72305_c.size();
    }

    public int func_83012_d() {
        return this.field_72302_d;
    }
}
