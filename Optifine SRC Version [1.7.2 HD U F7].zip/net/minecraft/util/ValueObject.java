package net.minecraft.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public abstract class ValueObject {
    @Override
    public String toString() {
        StringBuilder stringbuilder = new StringBuilder("{");

        for (Field field : this.getClass().getFields()) {
            if (!func_148766_a(field)) {
                try {
                    stringbuilder.append(field.getName()).append("=").append(field.get(this)).append(" ");
                } catch (IllegalAccessException illegalaccessexception) {
                }
            }
        }

        stringbuilder.deleteCharAt(stringbuilder.length() - 1);
        stringbuilder.append('}');
        return stringbuilder.toString();
    }

    private static boolean func_148766_a(Field var0) {
        return Modifier.isStatic(var0.getModifiers());
    }
}
