package net.minecraft.util;

public class Vec3 {
    public static final Vec3Pool field_82592_a = new Vec3Pool(-1, -1);
    public final Vec3Pool field_72447_d;
    public double xCoord;
    public double yCoord;
    public double zCoord;

    public static Vec3 createVectorHelper(double var0, double var2, double var4) {
        return new Vec3(field_82592_a, var0, var2, var4);
    }

    protected Vec3(Vec3Pool var1, double var2, double var4, double var6) {
        if (var2 == -0.0) {
            var2 = 0.0;
        }

        if (var4 == -0.0) {
            var4 = 0.0;
        }

        if (var6 == -0.0) {
            var6 = 0.0;
        }

        this.xCoord = var2;
        this.yCoord = var4;
        this.zCoord = var6;
        this.field_72447_d = var1;
    }

    protected Vec3 setComponents(double var1, double var3, double var5) {
        this.xCoord = var1;
        this.yCoord = var3;
        this.zCoord = var5;
        return this;
    }

    public Vec3 subtract(Vec3 var1) {
        return this.field_72447_d.func_72345_a(var1.xCoord - this.xCoord, var1.yCoord - this.yCoord, var1.zCoord - this.zCoord);
    }

    public Vec3 normalize() {
        double d0 = MathHelper.sqrt_double(this.xCoord * this.xCoord + this.yCoord * this.yCoord + this.zCoord * this.zCoord);
        return d0 < 1.0E-4
            ? this.field_72447_d.func_72345_a(0.0, 0.0, 0.0)
            : this.field_72447_d.func_72345_a(this.xCoord / d0, this.yCoord / d0, this.zCoord / d0);
    }

    public double dotProduct(Vec3 var1) {
        return this.xCoord * var1.xCoord + this.yCoord * var1.yCoord + this.zCoord * var1.zCoord;
    }

    public Vec3 crossProduct(Vec3 var1) {
        return this.field_72447_d
            .func_72345_a(
                this.yCoord * var1.zCoord - this.zCoord * var1.yCoord,
                this.zCoord * var1.xCoord - this.xCoord * var1.zCoord,
                this.xCoord * var1.yCoord - this.yCoord * var1.xCoord
            );
    }

    public Vec3 addVector(double var1, double var3, double var5) {
        return this.field_72447_d.func_72345_a(this.xCoord + var1, this.yCoord + var3, this.zCoord + var5);
    }

    public double distanceTo(Vec3 var1) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        return MathHelper.sqrt_double(d0 * d0 + d1 * d1 + d2 * d2);
    }

    public double squareDistanceTo(Vec3 var1) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public double squareDistanceTo(double var1, double var3, double var5) {
        double d0 = var1 - this.xCoord;
        double d1 = var3 - this.yCoord;
        double d2 = var5 - this.zCoord;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public double lengthVector() {
        return MathHelper.sqrt_double(this.xCoord * this.xCoord + this.yCoord * this.yCoord + this.zCoord * this.zCoord);
    }

    public Vec3 getIntermediateWithXValue(Vec3 var1, double var2) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        if (d0 * d0 < 1.0E-7F) {
            return null;
        }

        double d3 = (var2 - this.xCoord) / d0;
        return !(d3 < 0.0) && !(d3 > 1.0) ? this.field_72447_d.func_72345_a(this.xCoord + d0 * d3, this.yCoord + d1 * d3, this.zCoord + d2 * d3) : null;
    }

    public Vec3 getIntermediateWithYValue(Vec3 var1, double var2) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        if (d1 * d1 < 1.0E-7F) {
            return null;
        }

        double d3 = (var2 - this.yCoord) / d1;
        return !(d3 < 0.0) && !(d3 > 1.0) ? this.field_72447_d.func_72345_a(this.xCoord + d0 * d3, this.yCoord + d1 * d3, this.zCoord + d2 * d3) : null;
    }

    public Vec3 getIntermediateWithZValue(Vec3 var1, double var2) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        if (d2 * d2 < 1.0E-7F) {
            return null;
        }

        double d3 = (var2 - this.zCoord) / d2;
        return !(d3 < 0.0) && !(d3 > 1.0) ? this.field_72447_d.func_72345_a(this.xCoord + d0 * d3, this.yCoord + d1 * d3, this.zCoord + d2 * d3) : null;
    }

    @Override
    public String toString() {
        return "(" + this.xCoord + ", " + this.yCoord + ", " + this.zCoord + ")";
    }

    public void rotateAroundX(float var1) {
        float f = MathHelper.cos(var1);
        float f1 = MathHelper.sin(var1);
        double d0 = this.xCoord;
        double d1 = this.yCoord * f + this.zCoord * f1;
        double d2 = this.zCoord * f - this.yCoord * f1;
        this.xCoord = d0;
        this.yCoord = d1;
        this.zCoord = d2;
    }

    public void rotateAroundY(float var1) {
        float f = MathHelper.cos(var1);
        float f1 = MathHelper.sin(var1);
        double d0 = this.xCoord * f + this.zCoord * f1;
        double d1 = this.yCoord;
        double d2 = this.zCoord * f - this.xCoord * f1;
        this.xCoord = d0;
        this.yCoord = d1;
        this.zCoord = d2;
    }

    public void rotateAroundZ(float var1) {
        float f = MathHelper.cos(var1);
        float f1 = MathHelper.sin(var1);
        double d0 = this.xCoord * f + this.yCoord * f1;
        double d1 = this.yCoord * f - this.xCoord * f1;
        double d2 = this.zCoord;
        this.xCoord = d0;
        this.yCoord = d1;
        this.zCoord = d2;
    }
}
