package net.minecraft.util;

import com.mojang.authlib.GameProfile;

public class Session {
    private final String username;
    private final String playerID;
    private final String token;

    public Session(String var1, String var2, String var3) {
        this.username = var1;
        this.playerID = var2;
        this.token = var3;
    }

    public String getSessionID() {
        return "token:" + this.token + ":" + this.playerID;
    }

    public String getPlayerID() {
        return this.playerID;
    }

    public String getUsername() {
        return this.username;
    }

    public String getToken() {
        return this.token;
    }

    public GameProfile getProfile() {
        return new GameProfile(this.getPlayerID(), this.getUsername());
    }
}
