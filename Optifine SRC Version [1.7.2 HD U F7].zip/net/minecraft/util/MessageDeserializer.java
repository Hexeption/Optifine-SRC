package net.minecraft.util;

import com.google.common.collect.BiMap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import java.io.IOException;
import java.util.List;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class MessageDeserializer extends ByteToMessageDecoder {
    private static final Logger logger = LogManager.getLogger();
    private static final Marker field_150799_b = MarkerManager.getMarker("PACKET_RECEIVED", NetworkManager.logMarkerPackets);

    @Override
    protected void decode(ChannelHandlerContext var1, ByteBuf var2, List var3) throws IOException {
        if (var2.readableBytes() != 0) {
            PacketBuffer packetbuffer = new PacketBuffer(var2);
            int i = packetbuffer.readVarIntFromBuffer();
            Packet packet = Packet.generatePacket(((BiMap) var1.channel().attr(NetworkManager.attrKeyReceivable).get()), i);
            if (packet == null) {
                throw new IOException("Bad packet id " + i);
            }

            packet.readPacketData(packetbuffer);
            if (packetbuffer.readableBytes() > 0) {
                throw new IOException("Packet was larger than I expected, found " + packetbuffer.readableBytes() + " bytes extra whilst reading packet " + i);
            }

            var3.add(packet);
            if (logger.isDebugEnabled()) {
                logger.debug(
                    field_150799_b,
                    " IN: [{}:{}] {}[{}]",
                    var1.channel().attr(NetworkManager.attrKeyConnectionState).get(),
                    i,
                    packet.getClass().getName(),
                    packet.serialize()
                );
            }
        }
    }
}
