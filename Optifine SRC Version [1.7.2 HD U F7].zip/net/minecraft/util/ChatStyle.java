package net.minecraft.util;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.HoverEvent;

public class ChatStyle {
    private ChatStyle parentStyle;
    private EnumChatFormatting color;
    private Boolean bold;
    private Boolean italic;
    private Boolean underlined;
    private Boolean strikethrough;
    private Boolean obfuscated;
    private ClickEvent chatClickEvent;
    private HoverEvent chatHoverEvent;
    private static final ChatStyle rootStyle = new ChatStyle() {
        @Override
        public EnumChatFormatting getColor() {
            return null;
        }

        @Override
        public boolean getBold() {
            return false;
        }

        @Override
        public boolean getItalic() {
            return false;
        }

        @Override
        public boolean getStrikethrough() {
            return false;
        }

        @Override
        public boolean getUnderlined() {
            return false;
        }

        @Override
        public boolean getObfuscated() {
            return false;
        }

        @Override
        public ClickEvent getChatClickEvent() {
            return null;
        }

        @Override
        public HoverEvent getChatHoverEvent() {
            return null;
        }

        @Override
        public ChatStyle setColor(EnumChatFormatting var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setBold(Boolean var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setItalic(Boolean var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setStrikethrough(Boolean var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setUnderlined(Boolean var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setObfuscated(Boolean var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setChatClickEvent(ClickEvent var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setChatHoverEvent(HoverEvent var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public ChatStyle setParentStyle(ChatStyle var1) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String toString() {
            return "Style.ROOT";
        }

        @Override
        public ChatStyle createShallowCopy() {
            return this;
        }

        @Override
        public ChatStyle createDeepCopy() {
            return this;
        }

        @Override
        public String getFormattingCode() {
            return "";
        }
    };

    public EnumChatFormatting getColor() {
        return this.color == null ? this.getParent().getColor() : this.color;
    }

    public boolean getBold() {
        return this.bold == null ? this.getParent().getBold() : this.bold;
    }

    public boolean getItalic() {
        return this.italic == null ? this.getParent().getItalic() : this.italic;
    }

    public boolean getStrikethrough() {
        return this.strikethrough == null ? this.getParent().getStrikethrough() : this.strikethrough;
    }

    public boolean getUnderlined() {
        return this.underlined == null ? this.getParent().getUnderlined() : this.underlined;
    }

    public boolean getObfuscated() {
        return this.obfuscated == null ? this.getParent().getObfuscated() : this.obfuscated;
    }

    public boolean isEmpty() {
        return this.bold == null
            && this.italic == null
            && this.strikethrough == null
            && this.underlined == null
            && this.obfuscated == null
            && this.color == null
            && this.chatClickEvent == null
            && this.chatHoverEvent == null;
    }

    public ClickEvent getChatClickEvent() {
        return this.chatClickEvent == null ? this.getParent().getChatClickEvent() : this.chatClickEvent;
    }

    public HoverEvent getChatHoverEvent() {
        return this.chatHoverEvent == null ? this.getParent().getChatHoverEvent() : this.chatHoverEvent;
    }

    public ChatStyle setColor(EnumChatFormatting var1) {
        this.color = var1;
        return this;
    }

    public ChatStyle setBold(Boolean var1) {
        this.bold = var1;
        return this;
    }

    public ChatStyle setItalic(Boolean var1) {
        this.italic = var1;
        return this;
    }

    public ChatStyle setStrikethrough(Boolean var1) {
        this.strikethrough = var1;
        return this;
    }

    public ChatStyle setUnderlined(Boolean var1) {
        this.underlined = var1;
        return this;
    }

    public ChatStyle setObfuscated(Boolean var1) {
        this.obfuscated = var1;
        return this;
    }

    public ChatStyle setChatClickEvent(ClickEvent var1) {
        this.chatClickEvent = var1;
        return this;
    }

    public ChatStyle setChatHoverEvent(HoverEvent var1) {
        this.chatHoverEvent = var1;
        return this;
    }

    public ChatStyle setParentStyle(ChatStyle var1) {
        this.parentStyle = var1;
        return this;
    }

    public String getFormattingCode() {
        if (this.isEmpty()) {
            return this.parentStyle != null ? this.parentStyle.getFormattingCode() : "";
        }

        StringBuilder stringbuilder = new StringBuilder();
        if (this.getColor() != null) {
            stringbuilder.append(this.getColor());
        }

        if (this.getBold()) {
            stringbuilder.append(EnumChatFormatting.BOLD);
        }

        if (this.getItalic()) {
            stringbuilder.append(EnumChatFormatting.ITALIC);
        }

        if (this.getUnderlined()) {
            stringbuilder.append(EnumChatFormatting.UNDERLINE);
        }

        if (this.getObfuscated()) {
            stringbuilder.append(EnumChatFormatting.OBFUSCATED);
        }

        if (this.getStrikethrough()) {
            stringbuilder.append(EnumChatFormatting.STRIKETHROUGH);
        }

        return stringbuilder.toString();
    }

    private ChatStyle getParent() {
        return this.parentStyle == null ? rootStyle : this.parentStyle;
    }

    @Override
    public String toString() {
        return "Style{hasParent="
            + (this.parentStyle != null)
            + ", color="
            + this.color
            + ", bold="
            + this.bold
            + ", italic="
            + this.italic
            + ", underlined="
            + this.underlined
            + ", obfuscated="
            + this.obfuscated
            + ", clickEvent="
            + this.getChatClickEvent()
            + ", hoverEvent="
            + this.getChatHoverEvent()
            + '}';
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ChatStyle)) {
            return false;
        }

        ChatStyle chatstyle = (ChatStyle)var1;
        return this.getBold() == chatstyle.getBold()
            && this.getColor() == chatstyle.getColor()
            && this.getItalic() == chatstyle.getItalic()
            && this.getObfuscated() == chatstyle.getObfuscated()
            && this.getStrikethrough() == chatstyle.getStrikethrough()
            && this.getUnderlined() == chatstyle.getUnderlined()
            && (this.getChatClickEvent() != null ? this.getChatClickEvent().equals(chatstyle.getChatClickEvent()) : chatstyle.getChatClickEvent() == null)
            && (this.getChatHoverEvent() != null ? this.getChatHoverEvent().equals(chatstyle.getChatHoverEvent()) : chatstyle.getChatHoverEvent() == null);
    }

    @Override
    public int hashCode() {
        int i = this.color.hashCode();
        i = 31 * i + this.bold.hashCode();
        i = 31 * i + this.italic.hashCode();
        i = 31 * i + this.underlined.hashCode();
        i = 31 * i + this.strikethrough.hashCode();
        i = 31 * i + this.obfuscated.hashCode();
        i = 31 * i + this.chatClickEvent.hashCode();
        return 31 * i + this.chatHoverEvent.hashCode();
    }

    public ChatStyle createShallowCopy() {
        ChatStyle chatstyle = new ChatStyle();
        chatstyle.bold = this.bold;
        chatstyle.italic = this.italic;
        chatstyle.strikethrough = this.strikethrough;
        chatstyle.underlined = this.underlined;
        chatstyle.obfuscated = this.obfuscated;
        chatstyle.color = this.color;
        chatstyle.chatClickEvent = this.chatClickEvent;
        chatstyle.chatHoverEvent = this.chatHoverEvent;
        chatstyle.parentStyle = this.parentStyle;
        return chatstyle;
    }

    public ChatStyle createDeepCopy() {
        ChatStyle chatstyle = new ChatStyle();
        chatstyle.setBold(this.getBold());
        chatstyle.setItalic(this.getItalic());
        chatstyle.setStrikethrough(this.getStrikethrough());
        chatstyle.setUnderlined(this.getUnderlined());
        chatstyle.setObfuscated(this.getObfuscated());
        chatstyle.setColor(this.getColor());
        chatstyle.setChatClickEvent(this.getChatClickEvent());
        chatstyle.setChatHoverEvent(this.getChatHoverEvent());
        return chatstyle;
    }

    public static class Serializer implements JsonDeserializer, JsonSerializer {
        public ChatStyle deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) {
            if (var1.isJsonObject()) {
                ChatStyle chatstyle = new ChatStyle();
                JsonObject jsonobject = var1.getAsJsonObject();
                if (jsonobject.has("bold")) {
                    chatstyle.bold = jsonobject.get("bold").getAsBoolean();
                }

                if (jsonobject.has("italic")) {
                    chatstyle.italic = jsonobject.get("italic").getAsBoolean();
                }

                if (jsonobject.has("underlined")) {
                    chatstyle.underlined = jsonobject.get("underlined").getAsBoolean();
                }

                if (jsonobject.has("strikethrough")) {
                    chatstyle.strikethrough = jsonobject.get("strikethrough").getAsBoolean();
                }

                if (jsonobject.has("obfuscated")) {
                    chatstyle.obfuscated = jsonobject.get("obfuscated").getAsBoolean();
                }

                if (jsonobject.has("color")) {
                    chatstyle.color = var3.deserialize(jsonobject.get("color"), EnumChatFormatting.class);
                }

                if (jsonobject.has("clickEvent")) {
                    JsonObject jsonobject1 = jsonobject.getAsJsonObject("clickEvent");
                    ClickEvent.Action clickevent$action = ClickEvent.Action.getValueByCanonicalName(jsonobject1.getAsJsonPrimitive("action").getAsString());
                    String s = jsonobject1.getAsJsonPrimitive("value").getAsString();
                    if (clickevent$action != null && s != null && clickevent$action.shouldAllowInChat()) {
                        chatstyle.chatClickEvent = new ClickEvent(clickevent$action, s);
                    }
                }

                if (jsonobject.has("hoverEvent")) {
                    JsonObject jsonobject2 = jsonobject.getAsJsonObject("hoverEvent");
                    HoverEvent.Action hoverevent$action = HoverEvent.Action.getValueByCanonicalName(jsonobject2.getAsJsonPrimitive("action").getAsString());
                    IChatComponent ichatcomponent = var3.deserialize(jsonobject2.get("value"), IChatComponent.class);
                    if (hoverevent$action != null && ichatcomponent != null && hoverevent$action.shouldAllowInChat()) {
                        chatstyle.chatHoverEvent = new HoverEvent(hoverevent$action, ichatcomponent);
                    }
                }

                return chatstyle;
            } else {
                return null;
            }
        }

        public JsonElement serialize(ChatStyle var1, Type var2, JsonSerializationContext var3) {
            if (var1.isEmpty()) {
                return null;
            }

            JsonObject jsonobject = new JsonObject();
            if (var1.bold != null) {
                jsonobject.addProperty("bold", var1.bold);
            }

            if (var1.italic != null) {
                jsonobject.addProperty("italic", var1.italic);
            }

            if (var1.underlined != null) {
                jsonobject.addProperty("underlined", var1.underlined);
            }

            if (var1.strikethrough != null) {
                jsonobject.addProperty("strikethrough", var1.strikethrough);
            }

            if (var1.obfuscated != null) {
                jsonobject.addProperty("obfuscated", var1.obfuscated);
            }

            if (var1.color != null) {
                jsonobject.add("color", var3.serialize(var1.color));
            }

            if (var1.chatClickEvent != null) {
                JsonObject jsonobject1 = new JsonObject();
                jsonobject1.addProperty("action", var1.chatClickEvent.getAction().getCanonicalName());
                jsonobject1.addProperty("value", var1.chatClickEvent.getValue());
                jsonobject.add("clickEvent", jsonobject1);
            }

            if (var1.chatHoverEvent != null) {
                JsonObject jsonobject2 = new JsonObject();
                jsonobject2.addProperty("action", var1.chatHoverEvent.getAction().getCanonicalName());
                jsonobject2.add("value", var3.serialize(var1.chatHoverEvent.getValue()));
                jsonobject.add("hoverEvent", jsonobject2);
            }

            return jsonobject;
        }

        @Override
        public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
            return this.serialize((ChatStyle)var1, var2, var3);
        }
    }
}
