package net.minecraft.util;

public class AxisAlignedBB {
    private static final ThreadLocal field_72335_g = new ThreadLocal() {
        protected AABBPool initialValue() {
            return new AABBPool(300, 2000);
        }
    };
    public double minX;
    public double minY;
    public double minZ;
    public double maxX;
    public double maxY;
    public double maxZ;

    public static AxisAlignedBB getBoundingBox(double var0, double var2, double var4, double var6, double var8, double var10) {
        return new AxisAlignedBB(var0, var2, var4, var6, var8, var10);
    }

    public static AABBPool func_72332_a() {
        return (AABBPool)field_72335_g.get();
    }

    protected AxisAlignedBB(double var1, double var3, double var5, double var7, double var9, double var11) {
        this.minX = var1;
        this.minY = var3;
        this.minZ = var5;
        this.maxX = var7;
        this.maxY = var9;
        this.maxZ = var11;
    }

    public AxisAlignedBB setBounds(double var1, double var3, double var5, double var7, double var9, double var11) {
        this.minX = var1;
        this.minY = var3;
        this.minZ = var5;
        this.maxX = var7;
        this.maxY = var9;
        this.maxZ = var11;
        return this;
    }

    public AxisAlignedBB addCoord(double var1, double var3, double var5) {
        double d0 = this.minX;
        double d1 = this.minY;
        double d2 = this.minZ;
        double d3 = this.maxX;
        double d4 = this.maxY;
        double d5 = this.maxZ;
        if (var1 < 0.0) {
            d0 += var1;
        }

        if (var1 > 0.0) {
            d3 += var1;
        }

        if (var3 < 0.0) {
            d1 += var3;
        }

        if (var3 > 0.0) {
            d4 += var3;
        }

        if (var5 < 0.0) {
            d2 += var5;
        }

        if (var5 > 0.0) {
            d5 += var5;
        }

        return func_72332_a().func_72299_a(d0, d1, d2, d3, d4, d5);
    }

    public AxisAlignedBB expand(double var1, double var3, double var5) {
        double d0 = this.minX - var1;
        double d1 = this.minY - var3;
        double d2 = this.minZ - var5;
        double d3 = this.maxX + var1;
        double d4 = this.maxY + var3;
        double d5 = this.maxZ + var5;
        return func_72332_a().func_72299_a(d0, d1, d2, d3, d4, d5);
    }

    public AxisAlignedBB union(AxisAlignedBB var1) {
        double d0 = Math.min(this.minX, var1.minX);
        double d1 = Math.min(this.minY, var1.minY);
        double d2 = Math.min(this.minZ, var1.minZ);
        double d3 = Math.max(this.maxX, var1.maxX);
        double d4 = Math.max(this.maxY, var1.maxY);
        double d5 = Math.max(this.maxZ, var1.maxZ);
        return func_72332_a().func_72299_a(d0, d1, d2, d3, d4, d5);
    }

    public AxisAlignedBB getOffsetBoundingBox(double var1, double var3, double var5) {
        return func_72332_a().func_72299_a(this.minX + var1, this.minY + var3, this.minZ + var5, this.maxX + var1, this.maxY + var3, this.maxZ + var5);
    }

    public double calculateXOffset(AxisAlignedBB var1, double var2) {
        if (var1.maxY <= this.minY || var1.minY >= this.maxY) {
            return var2;
        }

        if (!(var1.maxZ <= this.minZ) && !(var1.minZ >= this.maxZ)) {
            if (var2 > 0.0 && var1.maxX <= this.minX) {
                double d0 = this.minX - var1.maxX;
                if (d0 < var2) {
                    var2 = d0;
                }
            }

            if (var2 < 0.0 && var1.minX >= this.maxX) {
                double d1 = this.maxX - var1.minX;
                if (d1 > var2) {
                    var2 = d1;
                }
            }

            return var2;
        } else {
            return var2;
        }
    }

    public double calculateYOffset(AxisAlignedBB var1, double var2) {
        if (var1.maxX <= this.minX || var1.minX >= this.maxX) {
            return var2;
        }

        if (!(var1.maxZ <= this.minZ) && !(var1.minZ >= this.maxZ)) {
            if (var2 > 0.0 && var1.maxY <= this.minY) {
                double d0 = this.minY - var1.maxY;
                if (d0 < var2) {
                    var2 = d0;
                }
            }

            if (var2 < 0.0 && var1.minY >= this.maxY) {
                double d1 = this.maxY - var1.minY;
                if (d1 > var2) {
                    var2 = d1;
                }
            }

            return var2;
        } else {
            return var2;
        }
    }

    public double calculateZOffset(AxisAlignedBB var1, double var2) {
        if (var1.maxX <= this.minX || var1.minX >= this.maxX) {
            return var2;
        }

        if (!(var1.maxY <= this.minY) && !(var1.minY >= this.maxY)) {
            if (var2 > 0.0 && var1.maxZ <= this.minZ) {
                double d0 = this.minZ - var1.maxZ;
                if (d0 < var2) {
                    var2 = d0;
                }
            }

            if (var2 < 0.0 && var1.minZ >= this.maxZ) {
                double d1 = this.maxZ - var1.minZ;
                if (d1 > var2) {
                    var2 = d1;
                }
            }

            return var2;
        } else {
            return var2;
        }
    }

    public boolean intersectsWith(AxisAlignedBB var1) {
        if (var1.maxX <= this.minX || var1.minX >= this.maxX) {
            return false;
        } else {
            return var1.maxY <= this.minY || var1.minY >= this.maxY ? false : !(var1.maxZ <= this.minZ) && !(var1.minZ >= this.maxZ);
        }
    }

    public AxisAlignedBB offset(double var1, double var3, double var5) {
        this.minX += var1;
        this.minY += var3;
        this.minZ += var5;
        this.maxX += var1;
        this.maxY += var3;
        this.maxZ += var5;
        return this;
    }

    public boolean isVecInside(Vec3 var1) {
        if (var1.xCoord <= this.minX || var1.xCoord >= this.maxX) {
            return false;
        } else {
            return var1.yCoord <= this.minY || var1.yCoord >= this.maxY ? false : !(var1.zCoord <= this.minZ) && !(var1.zCoord >= this.maxZ);
        }
    }

    public double getAverageEdgeLength() {
        double d0 = this.maxX - this.minX;
        double d1 = this.maxY - this.minY;
        double d2 = this.maxZ - this.minZ;
        return (d0 + d1 + d2) / 3.0;
    }

    public AxisAlignedBB contract(double var1, double var3, double var5) {
        double d0 = this.minX + var1;
        double d1 = this.minY + var3;
        double d2 = this.minZ + var5;
        double d3 = this.maxX - var1;
        double d4 = this.maxY - var3;
        double d5 = this.maxZ - var5;
        return func_72332_a().func_72299_a(d0, d1, d2, d3, d4, d5);
    }

    public AxisAlignedBB copy() {
        return func_72332_a().func_72299_a(this.minX, this.minY, this.minZ, this.maxX, this.maxY, this.maxZ);
    }

    public MovingObjectPosition calculateIntercept(Vec3 var1, Vec3 var2) {
        Vec3 vec3 = var1.getIntermediateWithXValue(var2, this.minX);
        Vec3 vec31 = var1.getIntermediateWithXValue(var2, this.maxX);
        Vec3 vec32 = var1.getIntermediateWithYValue(var2, this.minY);
        Vec3 vec33 = var1.getIntermediateWithYValue(var2, this.maxY);
        Vec3 vec34 = var1.getIntermediateWithZValue(var2, this.minZ);
        Vec3 vec35 = var1.getIntermediateWithZValue(var2, this.maxZ);
        if (!this.isVecInYZ(vec3)) {
            vec3 = null;
        }

        if (!this.isVecInYZ(vec31)) {
            vec31 = null;
        }

        if (!this.isVecInXZ(vec32)) {
            vec32 = null;
        }

        if (!this.isVecInXZ(vec33)) {
            vec33 = null;
        }

        if (!this.isVecInXY(vec34)) {
            vec34 = null;
        }

        if (!this.isVecInXY(vec35)) {
            vec35 = null;
        }

        Vec3 vec36 = null;
        if (vec3 != null && (vec36 == null || var1.squareDistanceTo(vec3) < var1.squareDistanceTo(vec36))) {
            vec36 = vec3;
        }

        if (vec31 != null && (vec36 == null || var1.squareDistanceTo(vec31) < var1.squareDistanceTo(vec36))) {
            vec36 = vec31;
        }

        if (vec32 != null && (vec36 == null || var1.squareDistanceTo(vec32) < var1.squareDistanceTo(vec36))) {
            vec36 = vec32;
        }

        if (vec33 != null && (vec36 == null || var1.squareDistanceTo(vec33) < var1.squareDistanceTo(vec36))) {
            vec36 = vec33;
        }

        if (vec34 != null && (vec36 == null || var1.squareDistanceTo(vec34) < var1.squareDistanceTo(vec36))) {
            vec36 = vec34;
        }

        if (vec35 != null && (vec36 == null || var1.squareDistanceTo(vec35) < var1.squareDistanceTo(vec36))) {
            vec36 = vec35;
        }

        if (vec36 == null) {
            return null;
        }

        byte b0 = -1;
        if (vec36 == vec3) {
            b0 = 4;
        }

        if (vec36 == vec31) {
            b0 = 5;
        }

        if (vec36 == vec32) {
            b0 = 0;
        }

        if (vec36 == vec33) {
            b0 = 1;
        }

        if (vec36 == vec34) {
            b0 = 2;
        }

        if (vec36 == vec35) {
            b0 = 3;
        }

        return new MovingObjectPosition(0, 0, 0, b0, vec36);
    }

    private boolean isVecInYZ(Vec3 var1) {
        return var1 == null ? false : var1.yCoord >= this.minY && var1.yCoord <= this.maxY && var1.zCoord >= this.minZ && var1.zCoord <= this.maxZ;
    }

    private boolean isVecInXZ(Vec3 var1) {
        return var1 == null ? false : var1.xCoord >= this.minX && var1.xCoord <= this.maxX && var1.zCoord >= this.minZ && var1.zCoord <= this.maxZ;
    }

    private boolean isVecInXY(Vec3 var1) {
        return var1 == null ? false : var1.xCoord >= this.minX && var1.xCoord <= this.maxX && var1.yCoord >= this.minY && var1.yCoord <= this.maxY;
    }

    public void setBB(AxisAlignedBB var1) {
        this.minX = var1.minX;
        this.minY = var1.minY;
        this.minZ = var1.minZ;
        this.maxX = var1.maxX;
        this.maxY = var1.maxY;
        this.maxZ = var1.maxZ;
    }

    @Override
    public String toString() {
        return "box[" + this.minX + ", " + this.minY + ", " + this.minZ + " -> " + this.maxX + ", " + this.maxY + ", " + this.maxZ + "]";
    }
}
