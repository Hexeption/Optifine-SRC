package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenDesertWells extends WorldGenerator {
    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        while (var1.isAirBlock(var3, var4, var5) && var4 > 2) {
            var4--;
        }

        if (var1.getBlock(var3, var4, var5) != Blocks.sand) {
            return false;
        }

        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                if (var1.isAirBlock(var3 + i, var4 - 1, var5 + j) && var1.isAirBlock(var3 + i, var4 - 2, var5 + j)) {
                    return false;
                }
            }
        }

        for (int l = -1; l <= 0; l++) {
            for (int l1 = -2; l1 <= 2; l1++) {
                for (int k = -2; k <= 2; k++) {
                    var1.setBlock(var3 + l1, var4 + l, var5 + k, Blocks.sandstone, 0, 2);
                }
            }
        }

        var1.setBlock(var3, var4, var5, Blocks.flowing_water, 0, 2);
        var1.setBlock(var3 - 1, var4, var5, Blocks.flowing_water, 0, 2);
        var1.setBlock(var3 + 1, var4, var5, Blocks.flowing_water, 0, 2);
        var1.setBlock(var3, var4, var5 - 1, Blocks.flowing_water, 0, 2);
        var1.setBlock(var3, var4, var5 + 1, Blocks.flowing_water, 0, 2);

        for (int i1 = -2; i1 <= 2; i1++) {
            for (int i2 = -2; i2 <= 2; i2++) {
                if (i1 == -2 || i1 == 2 || i2 == -2 || i2 == 2) {
                    var1.setBlock(var3 + i1, var4 + 1, var5 + i2, Blocks.sandstone, 0, 2);
                }
            }
        }

        var1.setBlock(var3 + 2, var4 + 1, var5, Blocks.stone_slab, 1, 2);
        var1.setBlock(var3 - 2, var4 + 1, var5, Blocks.stone_slab, 1, 2);
        var1.setBlock(var3, var4 + 1, var5 + 2, Blocks.stone_slab, 1, 2);
        var1.setBlock(var3, var4 + 1, var5 - 2, Blocks.stone_slab, 1, 2);

        for (int j1 = -1; j1 <= 1; j1++) {
            for (int j2 = -1; j2 <= 1; j2++) {
                if (j1 == 0 && j2 == 0) {
                    var1.setBlock(var3 + j1, var4 + 4, var5 + j2, Blocks.sandstone, 0, 2);
                } else {
                    var1.setBlock(var3 + j1, var4 + 4, var5 + j2, Blocks.stone_slab, 1, 2);
                }
            }
        }

        for (int k1 = 1; k1 <= 3; k1++) {
            var1.setBlock(var3 - 1, var4 + k1, var5 - 1, Blocks.sandstone, 0, 2);
            var1.setBlock(var3 - 1, var4 + k1, var5 + 1, Blocks.sandstone, 0, 2);
            var1.setBlock(var3 + 1, var4 + k1, var5 - 1, Blocks.sandstone, 0, 2);
            var1.setBlock(var3 + 1, var4 + k1, var5 + 1, Blocks.sandstone, 0, 2);
        }

        return true;
    }
}
