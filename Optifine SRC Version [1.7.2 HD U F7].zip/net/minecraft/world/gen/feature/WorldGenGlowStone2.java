package net.minecraft.world.gen.feature;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class WorldGenGlowStone2 extends WorldGenerator {
    @Override
    public boolean generate(World var1, Random var2, int var3, int var4, int var5) {
        if (!var1.isAirBlock(var3, var4, var5)) {
            return false;
        }

        if (var1.getBlock(var3, var4 + 1, var5) != Blocks.netherrack) {
            return false;
        }

        var1.setBlock(var3, var4, var5, Blocks.glowstone, 0, 2);

        for (int i = 0; i < 1500; i++) {
            int j = var3 + var2.nextInt(8) - var2.nextInt(8);
            int k = var4 - var2.nextInt(12);
            int l = var5 + var2.nextInt(8) - var2.nextInt(8);
            if (var1.getBlock(j, k, l).getMaterial() == Material.air) {
                int i1 = 0;

                for (int j1 = 0; j1 < 6; j1++) {
                    Block block = null;
                    if (j1 == 0) {
                        block = var1.getBlock(j - 1, k, l);
                    }

                    if (j1 == 1) {
                        block = var1.getBlock(j + 1, k, l);
                    }

                    if (j1 == 2) {
                        block = var1.getBlock(j, k - 1, l);
                    }

                    if (j1 == 3) {
                        block = var1.getBlock(j, k + 1, l);
                    }

                    if (j1 == 4) {
                        block = var1.getBlock(j, k, l - 1);
                    }

                    if (j1 == 5) {
                        block = var1.getBlock(j, k, l + 1);
                    }

                    if (block == Blocks.glowstone) {
                        i1++;
                    }
                }

                if (i1 == 1) {
                    var1.setBlock(j, k, l, Blocks.glowstone, 0, 2);
                }
            }
        }

        return true;
    }
}
