package net.minecraft.world.gen;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import net.minecraft.world.gen.feature.WorldGenDungeons;
import net.minecraft.world.gen.feature.WorldGenLakes;
import net.minecraft.world.gen.structure.MapGenMineshaft;
import net.minecraft.world.gen.structure.MapGenScatteredFeature;
import net.minecraft.world.gen.structure.MapGenStronghold;
import net.minecraft.world.gen.structure.MapGenStructure;
import net.minecraft.world.gen.structure.MapGenVillage;

public class ChunkProviderFlat implements IChunkProvider {
    private World worldObj;
    private Random random;
    private final Block[] cachedBlockIDs = new Block[256];
    private final byte[] cachedBlockMetadata = new byte[256];
    private final FlatGeneratorInfo flatWorldGenInfo;
    private final List structureGenerators = new ArrayList();
    private final boolean hasDecoration;
    private final boolean hasDungeons;
    private WorldGenLakes waterLakeGenerator;
    private WorldGenLakes lavaLakeGenerator;

    public ChunkProviderFlat(World var1, long var2, boolean var4, String var5) {
        this.worldObj = var1;
        this.random = new Random(var2);
        this.flatWorldGenInfo = FlatGeneratorInfo.createFlatGeneratorFromString(var5);
        if (var4) {
            Map map = this.flatWorldGenInfo.getWorldFeatures();
            if (map.containsKey("village")) {
                Map map1 = (Map)map.get("village");
                if (!map1.containsKey("size")) {
                    map1.put("size", "1");
                }

                this.structureGenerators.add(new MapGenVillage(map1));
            }

            if (map.containsKey("biome_1")) {
                this.structureGenerators.add(new MapGenScatteredFeature((Map)map.get("biome_1")));
            }

            if (map.containsKey("mineshaft")) {
                this.structureGenerators.add(new MapGenMineshaft((Map)map.get("mineshaft")));
            }

            if (map.containsKey("stronghold")) {
                this.structureGenerators.add(new MapGenStronghold((Map)map.get("stronghold")));
            }
        }

        this.hasDecoration = this.flatWorldGenInfo.getWorldFeatures().containsKey("decoration");
        if (this.flatWorldGenInfo.getWorldFeatures().containsKey("lake")) {
            this.waterLakeGenerator = new WorldGenLakes(Blocks.water);
        }

        if (this.flatWorldGenInfo.getWorldFeatures().containsKey("lava_lake")) {
            this.lavaLakeGenerator = new WorldGenLakes(Blocks.lava);
        }

        this.hasDungeons = this.flatWorldGenInfo.getWorldFeatures().containsKey("dungeon");

        for (FlatLayerInfo flatlayerinfo : (Iterable<FlatLayerInfo>) (Iterable) this.flatWorldGenInfo.getFlatLayers()) {
            for (int i = flatlayerinfo.getMinY(); i < flatlayerinfo.getMinY() + flatlayerinfo.getLayerCount(); i++) {
                this.cachedBlockIDs[i] = flatlayerinfo.func_151536_b();
                this.cachedBlockMetadata[i] = (byte)flatlayerinfo.getFillBlockMeta();
            }
        }
    }

    @Override
    public Chunk loadChunk(int var1, int var2) {
        return this.provideChunk(var1, var2);
    }

    @Override
    public Chunk provideChunk(int var1, int var2) {
        Chunk chunk = new Chunk(this.worldObj, var1, var2);

        for (int i = 0; i < this.cachedBlockIDs.length; i++) {
            Block block = this.cachedBlockIDs[i];
            if (block != null) {
                int j = i >> 4;
                ExtendedBlockStorage extendedblockstorage = chunk.getBlockStorageArray()[j];
                if (extendedblockstorage == null) {
                    extendedblockstorage = new ExtendedBlockStorage(i, !this.worldObj.provider.hasNoSky);
                    chunk.getBlockStorageArray()[j] = extendedblockstorage;
                }

                for (int k = 0; k < 16; k++) {
                    for (int l = 0; l < 16; l++) {
                        extendedblockstorage.setExtBlockID(k, i & 15, l, block);
                        extendedblockstorage.setExtBlockMetadata(k, i & 15, l, this.cachedBlockMetadata[i]);
                    }
                }
            }
        }

        chunk.generateSkylightMap();
        BiomeGenBase[] abiomegenbase = this.worldObj.getWorldChunkManager().loadBlockGeneratorData(null, var1 * 16, var2 * 16, 16, 16);
        byte[] abyte = chunk.getBiomeArray();

        for (int i1 = 0; i1 < abyte.length; i1++) {
            abyte[i1] = (byte)abiomegenbase[i1].biomeID;
        }

        for (MapGenStructure mapgenstructure : (Iterable<MapGenStructure>) (Iterable) this.structureGenerators) {
            mapgenstructure.generate(this, this.worldObj, var1, var2, null);
        }

        chunk.generateSkylightMap();
        return chunk;
    }

    @Override
    public boolean chunkExists(int var1, int var2) {
        return true;
    }

    @Override
    public void populate(IChunkProvider var1, int var2, int var3) {
        int i = var2 * 16;
        int j = var3 * 16;
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(i + 16, j + 16);
        boolean flag = false;
        this.random.setSeed(this.worldObj.getSeed());
        long k = this.random.nextLong() / 2L * 2L + 1L;
        long l = this.random.nextLong() / 2L * 2L + 1L;
        this.random.setSeed(var2 * k + var3 * l ^ this.worldObj.getSeed());

        for (MapGenStructure mapgenstructure : (Iterable<MapGenStructure>) (Iterable) this.structureGenerators) {
            boolean flag1 = mapgenstructure.generateStructuresInChunk(this.worldObj, this.random, var2, var3);
            if (mapgenstructure instanceof MapGenVillage) {
                flag |= flag1;
            }
        }

        if (this.waterLakeGenerator != null && !flag && this.random.nextInt(4) == 0) {
            int j1 = i + this.random.nextInt(16) + 8;
            int i2 = this.random.nextInt(256);
            int l2 = j + this.random.nextInt(16) + 8;
            this.waterLakeGenerator.generate(this.worldObj, this.random, j1, i2, l2);
        }

        if (this.lavaLakeGenerator != null && !flag && this.random.nextInt(8) == 0) {
            int k1 = i + this.random.nextInt(16) + 8;
            int j2 = this.random.nextInt(this.random.nextInt(248) + 8);
            int i3 = j + this.random.nextInt(16) + 8;
            if (j2 < 63 || this.random.nextInt(10) == 0) {
                this.lavaLakeGenerator.generate(this.worldObj, this.random, k1, j2, i3);
            }
        }

        if (this.hasDungeons) {
            for (int l1 = 0; l1 < 8; l1++) {
                int k2 = i + this.random.nextInt(16) + 8;
                int j3 = this.random.nextInt(256);
                int i1 = j + this.random.nextInt(16) + 8;
                new WorldGenDungeons().generate(this.worldObj, this.random, k2, j3, i1);
            }
        }

        if (this.hasDecoration) {
            biomegenbase.decorate(this.worldObj, this.random, i, j);
        }
    }

    @Override
    public boolean saveChunks(boolean var1, IProgressUpdate var2) {
        return true;
    }

    @Override
    public void saveExtraData() {
    }

    @Override
    public boolean unloadQueuedChunks() {
        return false;
    }

    @Override
    public boolean canSave() {
        return true;
    }

    @Override
    public String makeString() {
        return "FlatLevelSource";
    }

    @Override
    public List getPossibleCreatures(EnumCreatureType var1, int var2, int var3, int var4) {
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(var2, var4);
        return biomegenbase.getSpawnableList(var1);
    }

    @Override
    public ChunkPosition findClosestStructure(World var1, String var2, int var3, int var4, int var5) {
        if ("Stronghold".equals(var2)) {
            for (MapGenStructure mapgenstructure : (Iterable<MapGenStructure>) (Iterable) this.structureGenerators) {
                if (mapgenstructure instanceof MapGenStronghold) {
                    return mapgenstructure.getNearestInstance(var1, var3, var4, var5);
                }
            }
        }

        return null;
    }

    @Override
    public int getLoadedChunkCount() {
        return 0;
    }

    @Override
    public void recreateStructures(int var1, int var2) {
        for (MapGenStructure mapgenstructure : (Iterable<MapGenStructure>) (Iterable) this.structureGenerators) {
            mapgenstructure.generate(this, this.worldObj, var1, var2, null);
        }
    }
}
