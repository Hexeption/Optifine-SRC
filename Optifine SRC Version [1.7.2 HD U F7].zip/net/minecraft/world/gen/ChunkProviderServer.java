package net.minecraft.world.gen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.LongHashMap;
import net.minecraft.util.ReportedException;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.MinecraftException;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.EmptyChunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.chunk.storage.IChunkLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ChunkProviderServer implements IChunkProvider {
    private static final Logger logger = LogManager.getLogger();
    private Set droppedChunksSet = new HashSet();
    private Chunk dummyChunk;
    private IChunkProvider serverChunkGenerator;
    private IChunkLoader chunkLoader;
    public boolean chunkLoadOverride = true;
    private LongHashMap id2ChunkMap = new LongHashMap();
    private List loadedChunks = new ArrayList();
    private WorldServer worldObj;

    public ChunkProviderServer(WorldServer var1, IChunkLoader var2, IChunkProvider var3) {
        this.dummyChunk = new EmptyChunk(var1, 0, 0);
        this.worldObj = var1;
        this.chunkLoader = var2;
        this.serverChunkGenerator = var3;
    }

    @Override
    public boolean chunkExists(int var1, int var2) {
        return this.id2ChunkMap.containsItem(ChunkCoordIntPair.chunkXZ2Int(var1, var2));
    }

    public void dropChunk(int var1, int var2) {
        if (this.worldObj.provider.canRespawnHere()) {
            ChunkCoordinates chunkcoordinates = this.worldObj.getSpawnPoint();
            int i = var1 * 16 + 8 - chunkcoordinates.posX;
            int j = var2 * 16 + 8 - chunkcoordinates.posZ;
            short short1 = 128;
            if (i < -short1 || i > short1 || j < -short1 || j > short1) {
                this.droppedChunksSet.add(ChunkCoordIntPair.chunkXZ2Int(var1, var2));
            }
        } else {
            this.droppedChunksSet.add(ChunkCoordIntPair.chunkXZ2Int(var1, var2));
        }
    }

    public void unloadAllChunks() {
        for (Chunk chunk : (Iterable<Chunk>) (Iterable) this.loadedChunks) {
            this.dropChunk(chunk.xPosition, chunk.zPosition);
        }
    }

    @Override
    public Chunk loadChunk(int var1, int var2) {
        long i = ChunkCoordIntPair.chunkXZ2Int(var1, var2);
        this.droppedChunksSet.remove(i);
        Chunk chunk = (Chunk)this.id2ChunkMap.getValueByKey(i);
        if (chunk == null) {
            chunk = this.loadChunkFromFile(var1, var2);
            if (chunk == null) {
                if (this.serverChunkGenerator == null) {
                    chunk = this.dummyChunk;
                } else {
                    try {
                        chunk = this.serverChunkGenerator.provideChunk(var1, var2);
                    } catch (Throwable throwable) {
                        CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Exception generating new chunk");
                        CrashReportCategory crashreportcategory = crashreport.makeCategory("Chunk to be generated");
                        crashreportcategory.addCrashSection("Location", String.format("%d,%d", var1, var2));
                        crashreportcategory.addCrashSection("Position hash", i);
                        crashreportcategory.addCrashSection("Generator", this.serverChunkGenerator.makeString());
                        throw new ReportedException(crashreport);
                    }
                }
            }

            this.id2ChunkMap.add(i, chunk);
            this.loadedChunks.add(chunk);
            chunk.onChunkLoad();
            chunk.populateChunk(this, this, var1, var2);
        }

        return chunk;
    }

    @Override
    public Chunk provideChunk(int var1, int var2) {
        Chunk chunk = (Chunk)this.id2ChunkMap.getValueByKey(ChunkCoordIntPair.chunkXZ2Int(var1, var2));
        if (chunk == null) {
            return !this.worldObj.findingSpawnPoint && !this.chunkLoadOverride ? this.dummyChunk : this.loadChunk(var1, var2);
        } else {
            return chunk;
        }
    }

    private Chunk loadChunkFromFile(int var1, int var2) {
        if (this.chunkLoader == null) {
            return null;
        }

        try {
            Chunk chunk = this.chunkLoader.loadChunk(this.worldObj, var1, var2);
            if (chunk != null) {
                chunk.lastSaveTime = this.worldObj.getTotalWorldTime();
                if (this.serverChunkGenerator != null) {
                    this.serverChunkGenerator.recreateStructures(var1, var2);
                }
            }

            return chunk;
        } catch (Exception exception) {
            logger.error("Couldn't load chunk", exception);
            return null;
        }
    }

    private void saveChunkExtraData(Chunk var1) {
        if (this.chunkLoader != null) {
            try {
                this.chunkLoader.saveExtraChunkData(this.worldObj, var1);
            } catch (Exception exception) {
                logger.error("Couldn't save entities", exception);
            }
        }
    }

    private void saveChunkData(Chunk var1) {
        if (this.chunkLoader != null) {
            try {
                var1.lastSaveTime = this.worldObj.getTotalWorldTime();
                this.chunkLoader.saveChunk(this.worldObj, var1);
            } catch (IOException ioexception) {
                logger.error("Couldn't save chunk", ioexception);
            } catch (MinecraftException minecraftexception) {
                logger.error("Couldn't save chunk; already in use by another instance of Minecraft?", minecraftexception);
            }
        }
    }

    @Override
    public void populate(IChunkProvider var1, int var2, int var3) {
        Chunk chunk = this.provideChunk(var2, var3);
        if (!chunk.isTerrainPopulated) {
            chunk.func_150809_p();
            if (this.serverChunkGenerator != null) {
                this.serverChunkGenerator.populate(var1, var2, var3);
                chunk.setChunkModified();
            }
        }
    }

    @Override
    public boolean saveChunks(boolean var1, IProgressUpdate var2) {
        int i = 0;

        for (int j = 0; j < this.loadedChunks.size(); j++) {
            Chunk chunk = (Chunk)this.loadedChunks.get(j);
            if (var1) {
                this.saveChunkExtraData(chunk);
            }

            if (chunk.needsSaving(var1)) {
                this.saveChunkData(chunk);
                chunk.isModified = false;
                if (++i == 24 && !var1) {
                    return false;
                }
            }
        }

        return true;
    }

    @Override
    public void saveExtraData() {
        if (this.chunkLoader != null) {
            this.chunkLoader.saveExtraData();
        }
    }

    @Override
    public boolean unloadQueuedChunks() {
        if (!this.worldObj.disableLevelSaving) {
            for (int i = 0; i < 100; i++) {
                if (!this.droppedChunksSet.isEmpty()) {
                    Long olong = (Long)this.droppedChunksSet.iterator().next();
                    Chunk chunk = (Chunk)this.id2ChunkMap.getValueByKey(olong);
                    chunk.onChunkUnload();
                    this.saveChunkData(chunk);
                    this.saveChunkExtraData(chunk);
                    this.droppedChunksSet.remove(olong);
                    this.id2ChunkMap.remove(olong);
                    this.loadedChunks.remove(chunk);
                }
            }

            if (this.chunkLoader != null) {
                this.chunkLoader.chunkTick();
            }
        }

        return this.serverChunkGenerator.unloadQueuedChunks();
    }

    @Override
    public boolean canSave() {
        return !this.worldObj.disableLevelSaving;
    }

    @Override
    public String makeString() {
        return "ServerChunkCache: " + this.id2ChunkMap.getNumHashElements() + " Drop: " + this.droppedChunksSet.size();
    }

    @Override
    public List getPossibleCreatures(EnumCreatureType var1, int var2, int var3, int var4) {
        return this.serverChunkGenerator.getPossibleCreatures(var1, var2, var3, var4);
    }

    @Override
    public ChunkPosition findClosestStructure(World var1, String var2, int var3, int var4, int var5) {
        return this.serverChunkGenerator.findClosestStructure(var1, var2, var3, var4, var5);
    }

    @Override
    public int getLoadedChunkCount() {
        return this.id2ChunkMap.getNumHashElements();
    }

    @Override
    public void recreateStructures(int var1, int var2) {
    }
}
