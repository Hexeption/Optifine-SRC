package net.minecraft.world;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEventData;
import net.minecraft.block.material.Material;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityTracker;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.INpc;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.network.play.server.S19PacketEntityStatus;
import net.minecraft.network.play.server.S24PacketBlockAction;
import net.minecraft.network.play.server.S27PacketExplosion;
import net.minecraft.network.play.server.S2APacketParticles;
import net.minecraft.network.play.server.S2BPacketChangeGameState;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import net.minecraft.profiler.Profiler;
import net.minecraft.scoreboard.ScoreboardSaveData;
import net.minecraft.scoreboard.ServerScoreboard;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerManager;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.ReportedException;
import net.minecraft.util.Vec3;
import net.minecraft.util.WeightedRandom;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import net.minecraft.world.chunk.storage.IChunkLoader;
import net.minecraft.world.gen.ChunkProviderServer;
import net.minecraft.world.gen.feature.WorldGeneratorBonusChest;
import net.minecraft.world.storage.ISaveHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WorldServer extends World {
    private static final Logger logger = LogManager.getLogger();
    private final MinecraftServer mcServer;
    private final EntityTracker theEntityTracker;
    private final PlayerManager thePlayerManager;
    private Set pendingTickListEntriesHashSet;
    private TreeSet pendingTickListEntriesTreeSet;
    public ChunkProviderServer theChunkProviderServer;
    public boolean disableLevelSaving;
    private boolean allPlayersSleeping;
    private int updateEntityTick;
    private final Teleporter worldTeleporter;
    private final SpawnerAnimals animalSpawner = new SpawnerAnimals();
    private WorldServer.ServerBlockEventList[] field_147490_S = new WorldServer.ServerBlockEventList[]{
        new WorldServer.ServerBlockEventList(), new WorldServer.ServerBlockEventList()
    };
    private int blockEventCacheIndex;
    private static final WeightedRandomChestContent[] bonusChestContent = new WeightedRandomChestContent[]{
        new WeightedRandomChestContent(Items.stick, 0, 1, 3, 10),
        new WeightedRandomChestContent(Item.getItemFromBlock(Blocks.planks), 0, 1, 3, 10),
        new WeightedRandomChestContent(Item.getItemFromBlock(Blocks.log), 0, 1, 3, 10),
        new WeightedRandomChestContent(Items.stone_axe, 0, 1, 1, 3),
        new WeightedRandomChestContent(Items.wooden_axe, 0, 1, 1, 5),
        new WeightedRandomChestContent(Items.stone_pickaxe, 0, 1, 1, 3),
        new WeightedRandomChestContent(Items.wooden_pickaxe, 0, 1, 1, 5),
        new WeightedRandomChestContent(Items.apple, 0, 2, 3, 5),
        new WeightedRandomChestContent(Items.bread, 0, 2, 3, 3),
        new WeightedRandomChestContent(Item.getItemFromBlock(Blocks.log2), 0, 1, 3, 10)
    };
    private List pendingTickListEntriesThisTick = new ArrayList();
    private IntHashMap entityIdMap;

    public WorldServer(MinecraftServer var1, ISaveHandler var2, String var3, int var4, WorldSettings var5, Profiler var6) {
        super(var2, var3, var5, WorldProvider.getProviderForDimension(var4), var6);
        this.mcServer = var1;
        this.theEntityTracker = new EntityTracker(this);
        this.thePlayerManager = new PlayerManager(this, var1.getConfigurationManager().getViewDistance());
        if (this.entityIdMap == null) {
            this.entityIdMap = new IntHashMap();
        }

        if (this.pendingTickListEntriesHashSet == null) {
            this.pendingTickListEntriesHashSet = new HashSet();
        }

        if (this.pendingTickListEntriesTreeSet == null) {
            this.pendingTickListEntriesTreeSet = new TreeSet();
        }

        this.worldTeleporter = new Teleporter(this);
        this.worldScoreboard = new ServerScoreboard(var1);
        ScoreboardSaveData scoreboardsavedata = (ScoreboardSaveData)this.mapStorage.loadData(ScoreboardSaveData.class, "scoreboard");
        if (scoreboardsavedata == null) {
            scoreboardsavedata = new ScoreboardSaveData();
            this.mapStorage.setData("scoreboard", scoreboardsavedata);
        }

        scoreboardsavedata.func_96499_a(this.worldScoreboard);
        ((ServerScoreboard)this.worldScoreboard).func_96547_a(scoreboardsavedata);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorldInfo().isHardcoreModeEnabled() && this.difficultySetting != EnumDifficulty.HARD) {
            this.difficultySetting = EnumDifficulty.HARD;
        }

        this.provider.worldChunkMgr.cleanupCache();
        if (this.areAllPlayersAsleep()) {
            if (this.getGameRules().getGameRuleBooleanValue("doDaylightCycle")) {
                long i = this.worldInfo.getWorldTime() + 24000L;
                this.worldInfo.setWorldTime(i - i % 24000L);
            }

            this.wakeAllPlayers();
        }

        this.theProfiler.startSection("mobSpawner");
        if (this.getGameRules().getGameRuleBooleanValue("doMobSpawning")) {
            this.animalSpawner.findChunksForSpawning(this, this.spawnHostileMobs, this.spawnPeacefulMobs, this.worldInfo.getWorldTotalTime() % 400L == 0L);
        }

        this.theProfiler.endStartSection("chunkSource");
        this.chunkProvider.unloadQueuedChunks();
        int j = this.calculateSkylightSubtracted(1.0F);
        if (j != this.skylightSubtracted) {
            this.skylightSubtracted = j;
        }

        this.worldInfo.incrementTotalWorldTime(this.worldInfo.getWorldTotalTime() + 1L);
        if (this.getGameRules().getGameRuleBooleanValue("doDaylightCycle")) {
            this.worldInfo.setWorldTime(this.worldInfo.getWorldTime() + 1L);
        }

        this.theProfiler.endStartSection("tickPending");
        this.tickUpdates(false);
        this.theProfiler.endStartSection("tickBlocks");
        this.func_147456_g();
        this.theProfiler.endStartSection("chunkMap");
        this.thePlayerManager.updatePlayerInstances();
        this.theProfiler.endStartSection("village");
        this.villageCollectionObj.tick();
        this.villageSiegeObj.tick();
        this.theProfiler.endStartSection("portalForcer");
        this.worldTeleporter.removeStalePortalLocations(this.getTotalWorldTime());
        this.theProfiler.endSection();
        this.func_147488_Z();
    }

    public BiomeGenBase.SpawnListEntry spawnRandomCreature(EnumCreatureType var1, int var2, int var3, int var4) {
        List list = this.getChunkProvider().getPossibleCreatures(var1, var2, var3, var4);
        return list != null && !list.isEmpty() ? (BiomeGenBase.SpawnListEntry)WeightedRandom.getRandomItem(this.rand, list) : null;
    }

    @Override
    public void updateAllPlayersSleepingFlag() {
        this.allPlayersSleeping = !this.playerEntities.isEmpty();

        for (EntityPlayer entityplayer : (Iterable<EntityPlayer>) (Iterable) this.playerEntities) {
            if (!entityplayer.isPlayerSleeping()) {
                this.allPlayersSleeping = false;
                break;
            }
        }
    }

    protected void wakeAllPlayers() {
        this.allPlayersSleeping = false;

        for (EntityPlayer entityplayer : (Iterable<EntityPlayer>) (Iterable) this.playerEntities) {
            if (entityplayer.isPlayerSleeping()) {
                entityplayer.wakeUpPlayer(false, false, true);
            }
        }

        this.resetRainAndThunder();
    }

    private void resetRainAndThunder() {
        this.worldInfo.setRainTime(0);
        this.worldInfo.setRaining(false);
        this.worldInfo.setThunderTime(0);
        this.worldInfo.setThundering(false);
    }

    public boolean areAllPlayersAsleep() {
        if (this.allPlayersSleeping && !this.isRemote) {
            for (EntityPlayer entityplayer : (Iterable<EntityPlayer>) (Iterable) this.playerEntities) {
                if (!entityplayer.isPlayerFullyAsleep()) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    @Override
    public void setSpawnLocation() {
        if (this.worldInfo.getSpawnY() <= 0) {
            this.worldInfo.setSpawnY(64);
        }

        int i = this.worldInfo.getSpawnX();
        int j = this.worldInfo.getSpawnZ();
        int k = 0;

        while (this.getTopBlock(i, j).getMaterial() == Material.air) {
            i += this.rand.nextInt(8) - this.rand.nextInt(8);
            j += this.rand.nextInt(8) - this.rand.nextInt(8);
            if (++k == 10000) {
                break;
            }
        }

        this.worldInfo.setSpawnX(i);
        this.worldInfo.setSpawnZ(j);
    }

    @Override
    protected void func_147456_g() {
        super.func_147456_g();
        int i = 0;
        int j = 0;

        for (ChunkCoordIntPair chunkcoordintpair : (Iterable<ChunkCoordIntPair>) (Iterable) this.activeChunkSet) {
            int k = chunkcoordintpair.chunkXPos * 16;
            int l = chunkcoordintpair.chunkZPos * 16;
            this.theProfiler.startSection("getChunk");
            Chunk chunk = this.getChunkFromChunkCoords(chunkcoordintpair.chunkXPos, chunkcoordintpair.chunkZPos);
            this.func_147467_a(k, l, chunk);
            this.theProfiler.endStartSection("tickChunk");
            chunk.func_150804_b(false);
            this.theProfiler.endStartSection("thunder");
            if (this.rand.nextInt(100000) == 0 && this.isRaining() && this.isThundering()) {
                this.updateLCG = this.updateLCG * 3 + 1013904223;
                int i1 = this.updateLCG >> 2;
                int j1 = k + (i1 & 15);
                int k1 = l + (i1 >> 8 & 15);
                int l1 = this.getPrecipitationHeight(j1, k1);
                if (this.isRainingAt(j1, l1, k1)) {
                    this.addWeatherEffect(new EntityLightningBolt(this, j1, l1, k1));
                }
            }

            this.theProfiler.endStartSection("iceandsnow");
            if (this.rand.nextInt(16) == 0) {
                this.updateLCG = this.updateLCG * 3 + 1013904223;
                int i3 = this.updateLCG >> 2;
                int j3 = i3 & 15;
                int k3 = i3 >> 8 & 15;
                int l3 = this.getPrecipitationHeight(j3 + k, k3 + l);
                if (this.isBlockFreezableNaturally(j3 + k, l3 - 1, k3 + l)) {
                    this.setBlock(j3 + k, l3 - 1, k3 + l, Blocks.ice);
                }

                if (this.isRaining() && this.canSnowAt(j3 + k, l3, k3 + l, true)) {
                    this.setBlock(j3 + k, l3, k3 + l, Blocks.snow_layer);
                }

                if (this.isRaining()) {
                    BiomeGenBase biomegenbase = this.getBiomeGenForCoords(j3 + k, k3 + l);
                    if (biomegenbase.canSpawnLightningBolt()) {
                        this.getBlock(j3 + k, l3 - 1, k3 + l).fillWithRain(this, j3 + k, l3 - 1, k3 + l);
                    }
                }
            }

            this.theProfiler.endStartSection("tickBlocks");

            for (ExtendedBlockStorage extendedblockstorage : chunk.getBlockStorageArray()) {
                if (extendedblockstorage != null && extendedblockstorage.getNeedsRandomTick()) {
                    for (int i4 = 0; i4 < 3; i4++) {
                        this.updateLCG = this.updateLCG * 3 + 1013904223;
                        int i2 = this.updateLCG >> 2;
                        int j2 = i2 & 15;
                        int k2 = i2 >> 8 & 15;
                        int l2 = i2 >> 16 & 15;
                        j++;
                        Block block = extendedblockstorage.getBlockByExtId(j2, l2, k2);
                        if (block.getTickRandomly()) {
                            i++;
                            block.updateTick(this, j2 + k, l2 + extendedblockstorage.getYLocation(), k2 + l, this.rand);
                        }
                    }
                }
            }

            this.theProfiler.endSection();
        }
    }

    @Override
    public boolean isBlockTickScheduledThisTick(int var1, int var2, int var3, Block var4) {
        NextTickListEntry nextticklistentry = new NextTickListEntry(var1, var2, var3, var4);
        return this.pendingTickListEntriesThisTick.contains(nextticklistentry);
    }

    @Override
    public void scheduleBlockUpdate(int var1, int var2, int var3, Block var4, int var5) {
        this.scheduleBlockUpdateWithPriority(var1, var2, var3, var4, var5, 0);
    }

    @Override
    public void scheduleBlockUpdateWithPriority(int var1, int var2, int var3, Block var4, int var5, int var6) {
        NextTickListEntry nextticklistentry = new NextTickListEntry(var1, var2, var3, var4);
        byte b0 = 0;
        if (this.scheduledUpdatesAreImmediate && var4.getMaterial() != Material.air) {
            if (var4.requiresUpdates()) {
                b0 = 8;
                if (this.checkChunksExist(
                    nextticklistentry.xCoord - b0,
                    nextticklistentry.yCoord - b0,
                    nextticklistentry.zCoord - b0,
                    nextticklistentry.xCoord + b0,
                    nextticklistentry.yCoord + b0,
                    nextticklistentry.zCoord + b0
                )) {
                    Block block = this.getBlock(nextticklistentry.xCoord, nextticklistentry.yCoord, nextticklistentry.zCoord);
                    if (block.getMaterial() != Material.air && block == nextticklistentry.func_151351_a()) {
                        block.updateTick(this, nextticklistentry.xCoord, nextticklistentry.yCoord, nextticklistentry.zCoord, this.rand);
                    }
                }

                return;
            }

            var5 = 1;
        }

        if (this.checkChunksExist(var1 - b0, var2 - b0, var3 - b0, var1 + b0, var2 + b0, var3 + b0)) {
            if (var4.getMaterial() != Material.air) {
                nextticklistentry.setScheduledTime(var5 + this.worldInfo.getWorldTotalTime());
                nextticklistentry.setPriority(var6);
            }

            if (!this.pendingTickListEntriesHashSet.contains(nextticklistentry)) {
                this.pendingTickListEntriesHashSet.add(nextticklistentry);
                this.pendingTickListEntriesTreeSet.add(nextticklistentry);
            }
        }
    }

    @Override
    public void func_147446_b(int var1, int var2, int var3, Block var4, int var5, int var6) {
        NextTickListEntry nextticklistentry = new NextTickListEntry(var1, var2, var3, var4);
        nextticklistentry.setPriority(var6);
        if (var4.getMaterial() != Material.air) {
            nextticklistentry.setScheduledTime(var5 + this.worldInfo.getWorldTotalTime());
        }

        if (!this.pendingTickListEntriesHashSet.contains(nextticklistentry)) {
            this.pendingTickListEntriesHashSet.add(nextticklistentry);
            this.pendingTickListEntriesTreeSet.add(nextticklistentry);
        }
    }

    @Override
    public void updateEntities() {
        if (this.playerEntities.isEmpty()) {
            if (this.updateEntityTick++ >= 1200) {
                return;
            }
        } else {
            this.resetUpdateEntityTick();
        }

        super.updateEntities();
    }

    public void resetUpdateEntityTick() {
        this.updateEntityTick = 0;
    }

    @Override
    public boolean tickUpdates(boolean var1) {
        int i = this.pendingTickListEntriesTreeSet.size();
        if (i != this.pendingTickListEntriesHashSet.size()) {
            throw new IllegalStateException("TickNextTick list out of synch");
        }

        if (i > 1000) {
            i = 1000;
        }

        this.theProfiler.startSection("cleaning");

        for (int j = 0; j < i; j++) {
            NextTickListEntry nextticklistentry = (NextTickListEntry)this.pendingTickListEntriesTreeSet.first();
            if (!var1 && nextticklistentry.scheduledTime > this.worldInfo.getWorldTotalTime()) {
                break;
            }

            this.pendingTickListEntriesTreeSet.remove(nextticklistentry);
            this.pendingTickListEntriesHashSet.remove(nextticklistentry);
            this.pendingTickListEntriesThisTick.add(nextticklistentry);
        }

        this.theProfiler.endSection();
        this.theProfiler.startSection("ticking");
        Iterator iterator = this.pendingTickListEntriesThisTick.iterator();

        while (iterator.hasNext()) {
            NextTickListEntry nextticklistentry1 = (NextTickListEntry)iterator.next();
            iterator.remove();
            byte b0 = 0;
            if (this.checkChunksExist(
                nextticklistentry1.xCoord - b0,
                nextticklistentry1.yCoord - b0,
                nextticklistentry1.zCoord - b0,
                nextticklistentry1.xCoord + b0,
                nextticklistentry1.yCoord + b0,
                nextticklistentry1.zCoord + b0
            )) {
                Block block = this.getBlock(nextticklistentry1.xCoord, nextticklistentry1.yCoord, nextticklistentry1.zCoord);
                if (block.getMaterial() != Material.air && Block.isEqualTo(block, nextticklistentry1.func_151351_a())) {
                    try {
                        block.updateTick(this, nextticklistentry1.xCoord, nextticklistentry1.yCoord, nextticklistentry1.zCoord, this.rand);
                    } catch (Throwable throwable1) {
                        CrashReport crashreport = CrashReport.makeCrashReport(throwable1, "Exception while ticking a block");
                        CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being ticked");

                        int k;
                        try {
                            k = this.getBlockMetadata(nextticklistentry1.xCoord, nextticklistentry1.yCoord, nextticklistentry1.zCoord);
                        } catch (Throwable throwable) {
                            k = -1;
                        }

                        CrashReportCategory.addBlockInfo(
                            crashreportcategory, nextticklistentry1.xCoord, nextticklistentry1.yCoord, nextticklistentry1.zCoord, block, k
                        );
                        throw new ReportedException(crashreport);
                    }
                }
            } else {
                this.scheduleBlockUpdate(nextticklistentry1.xCoord, nextticklistentry1.yCoord, nextticklistentry1.zCoord, nextticklistentry1.func_151351_a(), 0);
            }
        }

        this.theProfiler.endSection();
        this.pendingTickListEntriesThisTick.clear();
        return !this.pendingTickListEntriesTreeSet.isEmpty();
    }

    @Override
    public List getPendingBlockUpdates(Chunk var1, boolean var2) {
        ArrayList arraylist = null;
        ChunkCoordIntPair chunkcoordintpair = var1.getChunkCoordIntPair();
        int i = (chunkcoordintpair.chunkXPos << 4) - 2;
        int j = i + 16 + 2;
        int k = (chunkcoordintpair.chunkZPos << 4) - 2;
        int l = k + 16 + 2;

        for (int i1 = 0; i1 < 2; i1++) {
            Iterator iterator;
            if (i1 == 0) {
                iterator = this.pendingTickListEntriesTreeSet.iterator();
            } else {
                iterator = this.pendingTickListEntriesThisTick.iterator();
                if (!this.pendingTickListEntriesThisTick.isEmpty()) {
                    logger.debug("toBeTicked = " + this.pendingTickListEntriesThisTick.size());
                }
            }

            while (iterator.hasNext()) {
                NextTickListEntry nextticklistentry = (NextTickListEntry)iterator.next();
                if (nextticklistentry.xCoord >= i && nextticklistentry.xCoord < j && nextticklistentry.zCoord >= k && nextticklistentry.zCoord < l) {
                    if (var2) {
                        this.pendingTickListEntriesHashSet.remove(nextticklistentry);
                        iterator.remove();
                    }

                    if (arraylist == null) {
                        arraylist = new ArrayList();
                    }

                    arraylist.add(nextticklistentry);
                }
            }
        }

        return arraylist;
    }

    @Override
    public void updateEntityWithOptionalForce(Entity var1, boolean var2) {
        if (!this.mcServer.getCanSpawnAnimals() && (var1 instanceof EntityAnimal || var1 instanceof EntityWaterMob)) {
            var1.setDead();
        }

        if (!this.mcServer.getCanSpawnNPCs() && var1 instanceof INpc) {
            var1.setDead();
        }

        super.updateEntityWithOptionalForce(var1, var2);
    }

    @Override
    protected IChunkProvider createChunkProvider() {
        IChunkLoader ichunkloader = this.saveHandler.getChunkLoader(this.provider);
        this.theChunkProviderServer = new ChunkProviderServer(this, ichunkloader, this.provider.createChunkGenerator());
        return this.theChunkProviderServer;
    }

    public List func_147486_a(int var1, int var2, int var3, int var4, int var5, int var6) {
        ArrayList arraylist = new ArrayList();

        for (int i = 0; i < this.loadedTileEntityList.size(); i++) {
            TileEntity tileentity = (TileEntity)this.loadedTileEntityList.get(i);
            if (tileentity.xCoord >= var1
                && tileentity.yCoord >= var2
                && tileentity.zCoord >= var3
                && tileentity.xCoord < var4
                && tileentity.yCoord < var5
                && tileentity.zCoord < var6) {
                arraylist.add(tileentity);
            }
        }

        return arraylist;
    }

    @Override
    public boolean canMineBlock(EntityPlayer var1, int var2, int var3, int var4) {
        return !this.mcServer.isBlockProtected(this, var2, var3, var4, var1);
    }

    @Override
    protected void initialize(WorldSettings var1) {
        if (this.entityIdMap == null) {
            this.entityIdMap = new IntHashMap();
        }

        if (this.pendingTickListEntriesHashSet == null) {
            this.pendingTickListEntriesHashSet = new HashSet();
        }

        if (this.pendingTickListEntriesTreeSet == null) {
            this.pendingTickListEntriesTreeSet = new TreeSet();
        }

        this.createSpawnPosition(var1);
        super.initialize(var1);
    }

    protected void createSpawnPosition(WorldSettings var1) {
        if (!this.provider.canRespawnHere()) {
            this.worldInfo.setSpawnPosition(0, this.provider.getAverageGroundLevel(), 0);
        } else {
            this.findingSpawnPoint = true;
            WorldChunkManager worldchunkmanager = this.provider.worldChunkMgr;
            List list = worldchunkmanager.getBiomesToSpawnIn();
            Random random = new Random(this.getSeed());
            ChunkPosition chunkposition = worldchunkmanager.findBiomePosition(0, 0, 256, list, random);
            int i = 0;
            int j = this.provider.getAverageGroundLevel();
            int k = 0;
            if (chunkposition != null) {
                i = chunkposition.chunkPosX;
                k = chunkposition.chunkPosZ;
            } else {
                logger.warn("Unable to find spawn biome");
            }

            int l = 0;

            while (!this.provider.canCoordinateBeSpawn(i, k)) {
                i += random.nextInt(64) - random.nextInt(64);
                k += random.nextInt(64) - random.nextInt(64);
                if (++l == 1000) {
                    break;
                }
            }

            this.worldInfo.setSpawnPosition(i, j, k);
            this.findingSpawnPoint = false;
            if (var1.isBonusChestEnabled()) {
                this.createBonusChest();
            }
        }
    }

    protected void createBonusChest() {
        WorldGeneratorBonusChest worldgeneratorbonuschest = new WorldGeneratorBonusChest(bonusChestContent, 10);

        for (int i = 0; i < 10; i++) {
            int j = this.worldInfo.getSpawnX() + this.rand.nextInt(6) - this.rand.nextInt(6);
            int k = this.worldInfo.getSpawnZ() + this.rand.nextInt(6) - this.rand.nextInt(6);
            int l = this.getTopSolidOrLiquidBlock(j, k) + 1;
            if (worldgeneratorbonuschest.generate(this, this.rand, j, l, k)) {
                break;
            }
        }
    }

    public ChunkCoordinates getEntrancePortalLocation() {
        return this.provider.getEntrancePortalLocation();
    }

    public void saveAllChunks(boolean var1, IProgressUpdate var2) throws MinecraftException {
        if (this.chunkProvider.canSave()) {
            if (var2 != null) {
                var2.displaySavingString("Saving level");
            }

            this.saveLevel();
            if (var2 != null) {
                var2.displayLoadingString("Saving chunks");
            }

            this.chunkProvider.saveChunks(var1, var2);
        }
    }

    public void saveChunkData() {
        if (this.chunkProvider.canSave()) {
            this.chunkProvider.saveExtraData();
        }
    }

    protected void saveLevel() throws MinecraftException {
        this.checkSessionLock();
        this.saveHandler.saveWorldInfoWithPlayer(this.worldInfo, this.mcServer.getConfigurationManager().getHostPlayerData());
        this.mapStorage.saveAllData();
    }

    @Override
    protected void onEntityAdded(Entity var1) {
        super.onEntityAdded(var1);
        this.entityIdMap.addKey(var1.getEntityId(), var1);
        Entity[] aentity = var1.getParts();
        if (aentity != null) {
            for (int i = 0; i < aentity.length; i++) {
                this.entityIdMap.addKey(aentity[i].getEntityId(), aentity[i]);
            }
        }
    }

    @Override
    protected void onEntityRemoved(Entity var1) {
        super.onEntityRemoved(var1);
        this.entityIdMap.removeObject(var1.getEntityId());
        Entity[] aentity = var1.getParts();
        if (aentity != null) {
            for (int i = 0; i < aentity.length; i++) {
                this.entityIdMap.removeObject(aentity[i].getEntityId());
            }
        }
    }

    @Override
    public Entity getEntityByID(int var1) {
        return (Entity)this.entityIdMap.lookup(var1);
    }

    @Override
    public boolean addWeatherEffect(Entity var1) {
        if (super.addWeatherEffect(var1)) {
            this.mcServer
                .getConfigurationManager()
                .sendToAllNear(var1.posX, var1.posY, var1.posZ, 512.0, this.provider.dimensionId, new S2CPacketSpawnGlobalEntity(var1));
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void setEntityState(Entity var1, byte var2) {
        this.getEntityTracker().func_151248_b(var1, new S19PacketEntityStatus(var1, var2));
    }

    @Override
    public Explosion newExplosion(Entity var1, double var2, double var4, double var6, float var8, boolean var9, boolean var10) {
        Explosion explosion = new Explosion(this, var1, var2, var4, var6, var8);
        explosion.isFlaming = var9;
        explosion.isSmoking = var10;
        explosion.doExplosionA();
        explosion.doExplosionB(false);
        if (!var10) {
            explosion.affectedBlockPositions.clear();
        }

        for (EntityPlayer entityplayer : (Iterable<EntityPlayer>) (Iterable) this.playerEntities) {
            if (entityplayer.getDistanceSq(var2, var4, var6) < 4096.0) {
                ((EntityPlayerMP)entityplayer)
                    .playerNetServerHandler
                    .sendPacket(
                        new S27PacketExplosion(var2, var4, var6, var8, explosion.affectedBlockPositions, (Vec3)explosion.func_77277_b().get(entityplayer))
                    );
            }
        }

        return explosion;
    }

    @Override
    public void addBlockEvent(int var1, int var2, int var3, Block var4, int var5, int var6) {
        BlockEventData blockeventdata = new BlockEventData(var1, var2, var3, var4, var5, var6);

        for (BlockEventData blockeventdata1 : (Iterable<BlockEventData>) (Iterable) this.field_147490_S[this.blockEventCacheIndex]) {
            if (blockeventdata1.equals(blockeventdata)) {
                return;
            }
        }

        this.field_147490_S[this.blockEventCacheIndex].add(blockeventdata);
    }

    private void func_147488_Z() {
        while (!this.field_147490_S[this.blockEventCacheIndex].isEmpty()) {
            int i = this.blockEventCacheIndex;
            this.blockEventCacheIndex ^= 1;

            for (BlockEventData blockeventdata : (Iterable<BlockEventData>) (Iterable) this.field_147490_S[i]) {
                if (this.func_147485_a(blockeventdata)) {
                    this.mcServer
                        .getConfigurationManager()
                        .sendToAllNear(
                            blockeventdata.func_151340_a(),
                            blockeventdata.func_151342_b(),
                            blockeventdata.func_151341_c(),
                            64.0,
                            this.provider.dimensionId,
                            new S24PacketBlockAction(
                                blockeventdata.func_151340_a(),
                                blockeventdata.func_151342_b(),
                                blockeventdata.func_151341_c(),
                                blockeventdata.getBlock(),
                                blockeventdata.getEventID(),
                                blockeventdata.getEventParameter()
                            )
                        );
                }
            }

            this.field_147490_S[i].clear();
        }
    }

    private boolean func_147485_a(BlockEventData var1) {
        Block block = this.getBlock(var1.func_151340_a(), var1.func_151342_b(), var1.func_151341_c());
        return block == var1.getBlock()
            ? block.onBlockEventReceived(this, var1.func_151340_a(), var1.func_151342_b(), var1.func_151341_c(), var1.getEventID(), var1.getEventParameter())
            : false;
    }

    public void flush() {
        this.saveHandler.flush();
    }

    @Override
    protected void updateWeather() {
        boolean flag = this.isRaining();
        super.updateWeather();
        if (this.prevRainingStrength != this.rainingStrength) {
            this.mcServer
                .getConfigurationManager()
                .sendPacketToAllPlayersInDimension(new S2BPacketChangeGameState(7, this.rainingStrength), this.provider.dimensionId);
        }

        if (this.prevThunderingStrength != this.thunderingStrength) {
            this.mcServer
                .getConfigurationManager()
                .sendPacketToAllPlayersInDimension(new S2BPacketChangeGameState(8, this.thunderingStrength), this.provider.dimensionId);
        }

        if (flag != this.isRaining()) {
            if (flag) {
                this.mcServer.getConfigurationManager().sendPacketToAllPlayers(new S2BPacketChangeGameState(2, 0.0F));
            } else {
                this.mcServer.getConfigurationManager().sendPacketToAllPlayers(new S2BPacketChangeGameState(1, 0.0F));
            }

            this.mcServer.getConfigurationManager().sendPacketToAllPlayers(new S2BPacketChangeGameState(7, this.rainingStrength));
            this.mcServer.getConfigurationManager().sendPacketToAllPlayers(new S2BPacketChangeGameState(8, this.thunderingStrength));
        }
    }

    public MinecraftServer func_73046_m() {
        return this.mcServer;
    }

    public EntityTracker getEntityTracker() {
        return this.theEntityTracker;
    }

    public PlayerManager getPlayerManager() {
        return this.thePlayerManager;
    }

    public Teleporter getDefaultTeleporter() {
        return this.worldTeleporter;
    }

    public void func_147487_a(String var1, double var2, double var4, double var6, int var8, double var9, double var11, double var13, double var15) {
        S2APacketParticles s2apacketparticles = new S2APacketParticles(
            var1, (float)var2, (float)var4, (float)var6, (float)var9, (float)var11, (float)var13, (float)var15, var8
        );

        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayerMP entityplayermp = (EntityPlayerMP)this.playerEntities.get(i);
            ChunkCoordinates chunkcoordinates = entityplayermp.getCommandSenderPosition();
            double d0 = var2 - chunkcoordinates.posX;
            double d1 = var4 - chunkcoordinates.posY;
            double d2 = var6 - chunkcoordinates.posZ;
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            if (d3 <= 256.0) {
                entityplayermp.playerNetServerHandler.sendPacket(s2apacketparticles);
            }
        }
    }

    static class ServerBlockEventList extends ArrayList {
        private ServerBlockEventList() {
        }
    }
}
