package net.minecraft.world;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Vec3Pool;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;

public class ChunkCache implements IBlockAccess {
    private int chunkX;
    private int chunkZ;
    private Chunk[][] chunkArray;
    private boolean hasExtendedLevels;
    private World worldObj;

    public ChunkCache(World var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
        this.worldObj = var1;
        this.chunkX = var2 - var8 >> 4;
        this.chunkZ = var4 - var8 >> 4;
        int i = var5 + var8 >> 4;
        int j = var7 + var8 >> 4;
        this.chunkArray = new Chunk[i - this.chunkX + 1][j - this.chunkZ + 1];
        this.hasExtendedLevels = true;

        for (int k = this.chunkX; k <= i; k++) {
            for (int l = this.chunkZ; l <= j; l++) {
                Chunk chunk = var1.getChunkFromChunkCoords(k, l);
                if (chunk != null) {
                    this.chunkArray[k - this.chunkX][l - this.chunkZ] = chunk;
                }
            }
        }

        for (int i1 = var2 >> 4; i1 <= var5 >> 4; i1++) {
            for (int j1 = var4 >> 4; j1 <= var7 >> 4; j1++) {
                Chunk chunk1 = this.chunkArray[i1 - this.chunkX][j1 - this.chunkZ];
                if (chunk1 != null && !chunk1.getAreLevelsEmpty(var3, var6)) {
                    this.hasExtendedLevels = false;
                }
            }
        }
    }

    @Override
    public boolean extendedLevelsInChunkCache() {
        return this.hasExtendedLevels;
    }

    @Override
    public Block getBlock(int var1, int var2, int var3) {
        Block block = Blocks.air;
        if (var2 >= 0 && var2 < 256) {
            int i = (var1 >> 4) - this.chunkX;
            int j = (var3 >> 4) - this.chunkZ;
            if (i >= 0 && i < this.chunkArray.length && j >= 0 && j < this.chunkArray[i].length) {
                Chunk chunk = this.chunkArray[i][j];
                if (chunk != null) {
                    block = chunk.getBlock(var1 & 15, var2, var3 & 15);
                }
            }
        }

        return block;
    }

    @Override
    public TileEntity getTileEntity(int var1, int var2, int var3) {
        int i = (var1 >> 4) - this.chunkX;
        int j = (var3 >> 4) - this.chunkZ;
        return this.chunkArray[i][j].getBlockTileEntityInChunk(var1 & 15, var2, var3 & 15);
    }

    @Override
    public int getLightBrightnessForSkyBlocks(int var1, int var2, int var3, int var4) {
        int i = this.getSkyBlockTypeBrightness(EnumSkyBlock.Sky, var1, var2, var3);
        int j = this.getSkyBlockTypeBrightness(EnumSkyBlock.Block, var1, var2, var3);
        if (j < var4) {
            j = var4;
        }

        return i << 20 | j << 4;
    }

    @Override
    public int getBlockMetadata(int var1, int var2, int var3) {
        if (var2 < 0) {
            return 0;
        }

        if (var2 >= 256) {
            return 0;
        }

        int i = (var1 >> 4) - this.chunkX;
        int j = (var3 >> 4) - this.chunkZ;
        return this.chunkArray[i][j].getBlockMetadata(var1 & 15, var2, var3 & 15);
    }

    @Override
    public BiomeGenBase getBiomeGenForCoords(int var1, int var2) {
        return this.worldObj.getBiomeGenForCoords(var1, var2);
    }

    @Override
    public Vec3Pool func_82732_R() {
        return this.worldObj.func_82732_R();
    }

    @Override
    public boolean isAirBlock(int var1, int var2, int var3) {
        return this.getBlock(var1, var2, var3).getMaterial() == Material.air;
    }

    public int getSkyBlockTypeBrightness(EnumSkyBlock var1, int var2, int var3, int var4) {
        if (var3 < 0) {
            var3 = 0;
        }

        if (var3 >= 256) {
            var3 = 255;
        }

        if (var3 < 0 || var3 >= 256 || var2 < -30000000 || var4 < -30000000 || var2 >= 30000000 || var4 > 30000000) {
            return var1.defaultLightValue;
        }

        if (var1 == EnumSkyBlock.Sky && this.worldObj.provider.hasNoSky) {
            return 0;
        }

        if (this.getBlock(var2, var3, var4).getUseNeighborBrightness()) {
            int j1 = this.getSpecialBlockBrightness(var1, var2, var3 + 1, var4);
            int k1 = this.getSpecialBlockBrightness(var1, var2 + 1, var3, var4);
            int k = this.getSpecialBlockBrightness(var1, var2 - 1, var3, var4);
            int l = this.getSpecialBlockBrightness(var1, var2, var3, var4 + 1);
            int i1 = this.getSpecialBlockBrightness(var1, var2, var3, var4 - 1);
            if (k1 > j1) {
                j1 = k1;
            }

            if (k > j1) {
                j1 = k;
            }

            if (l > j1) {
                j1 = l;
            }

            if (i1 > j1) {
                j1 = i1;
            }

            return j1;
        } else {
            int i = (var2 >> 4) - this.chunkX;
            int j = (var4 >> 4) - this.chunkZ;
            return this.chunkArray[i][j].getSavedLightValue(var1, var2 & 15, var3, var4 & 15);
        }
    }

    public int getSpecialBlockBrightness(EnumSkyBlock var1, int var2, int var3, int var4) {
        if (var3 < 0) {
            var3 = 0;
        }

        if (var3 >= 256) {
            var3 = 255;
        }

        if (var3 >= 0 && var3 < 256 && var2 >= -30000000 && var4 >= -30000000 && var2 < 30000000 && var4 <= 30000000) {
            int i = (var2 >> 4) - this.chunkX;
            int j = (var4 >> 4) - this.chunkZ;
            return this.chunkArray[i][j].getSavedLightValue(var1, var2 & 15, var3, var4 & 15);
        } else {
            return var1.defaultLightValue;
        }
    }

    @Override
    public int getHeight() {
        return 256;
    }

    @Override
    public int isBlockProvidingPowerTo(int var1, int var2, int var3, int var4) {
        return this.getBlock(var1, var2, var3).isProvidingStrongPower(this, var1, var2, var3, var4);
    }
}
