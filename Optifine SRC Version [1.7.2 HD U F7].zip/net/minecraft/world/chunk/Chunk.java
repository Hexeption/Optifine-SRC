package net.minecraft.world.chunk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Callable;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.command.IEntitySelector;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Chunk {
    private static final Logger logger = LogManager.getLogger();
    public static boolean isLit;
    private ExtendedBlockStorage[] storageArrays = new ExtendedBlockStorage[16];
    private byte[] blockBiomeArray = new byte[256];
    public int[] precipitationHeightMap = new int[256];
    public boolean[] updateSkylightColumns = new boolean[256];
    public boolean isChunkLoaded;
    public World worldObj;
    public int[] heightMap;
    public final int xPosition;
    public final int zPosition;
    private boolean isGapLightingUpdated;
    public Map chunkTileEntityMap = new HashMap();
    public List[] entityLists;
    public boolean isTerrainPopulated;
    public boolean isLightPopulated;
    public boolean field_150815_m;
    public boolean isModified;
    public boolean hasEntities;
    public long lastSaveTime;
    public boolean sendUpdates;
    public int heightMapMinimum;
    public long inhabitedTime;
    private int queuedLightChecks = 4096;

    public Chunk(World var1, int var2, int var3) {
        this.entityLists = new List[16];
        this.worldObj = var1;
        this.xPosition = var2;
        this.zPosition = var3;
        this.heightMap = new int[256];

        for (int i = 0; i < this.entityLists.length; i++) {
            this.entityLists[i] = new ArrayList();
        }

        Arrays.fill(this.precipitationHeightMap, -999);
        Arrays.fill(this.blockBiomeArray, (byte)-1);
    }

    public Chunk(World var1, Block[] var2, int var3, int var4) {
        this(var1, var3, var4);
        int i = var2.length / 256;
        boolean flag = !var1.provider.hasNoSky;

        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                for (int l = 0; l < i; l++) {
                    Block block = var2[j << 11 | k << 7 | l];
                    if (block != null && block.getMaterial() != Material.air) {
                        int i1 = l >> 4;
                        if (this.storageArrays[i1] == null) {
                            this.storageArrays[i1] = new ExtendedBlockStorage(i1 << 4, flag);
                        }

                        this.storageArrays[i1].setExtBlockID(j, l & 15, k, block);
                    }
                }
            }
        }
    }

    public Chunk(World var1, Block[] var2, byte[] var3, int var4, int var5) {
        this(var1, var4, var5);
        int i = var2.length / 256;
        boolean flag = !var1.provider.hasNoSky;

        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                for (int l = 0; l < i; l++) {
                    int i1 = j * i * 16 | k * i | l;
                    Block block = var2[i1];
                    if (block != null && block != Blocks.air) {
                        int j1 = l >> 4;
                        if (this.storageArrays[j1] == null) {
                            this.storageArrays[j1] = new ExtendedBlockStorage(j1 << 4, flag);
                        }

                        this.storageArrays[j1].setExtBlockID(j, l & 15, k, block);
                        this.storageArrays[j1].setExtBlockMetadata(j, l & 15, k, var3[i1]);
                    }
                }
            }
        }
    }

    public boolean isAtLocation(int var1, int var2) {
        return var1 == this.xPosition && var2 == this.zPosition;
    }

    public int getHeightValue(int var1, int var2) {
        return this.heightMap[var2 << 4 | var1];
    }

    public int getTopFilledSegment() {
        for (int i = this.storageArrays.length - 1; i >= 0; i--) {
            if (this.storageArrays[i] != null) {
                return this.storageArrays[i].getYLocation();
            }
        }

        return 0;
    }

    public ExtendedBlockStorage[] getBlockStorageArray() {
        return this.storageArrays;
    }

    public void generateHeightMap() {
        int i = this.getTopFilledSegment();
        this.heightMapMinimum = Integer.MAX_VALUE;

        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                this.precipitationHeightMap[j + (k << 4)] = -999;

                for (int l = i + 16 - 1; l > 0; l--) {
                    Block block = this.getBlock(j, l - 1, k);
                    if (block.getLightOpacity() != 0) {
                        this.heightMap[k << 4 | j] = l;
                        if (l < this.heightMapMinimum) {
                            this.heightMapMinimum = l;
                        }
                        break;
                    }
                }
            }
        }

        this.isModified = true;
    }

    public void generateSkylightMap() {
        int i = this.getTopFilledSegment();
        this.heightMapMinimum = Integer.MAX_VALUE;

        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                this.precipitationHeightMap[j + (k << 4)] = -999;

                for (int l = i + 16 - 1; l > 0; l--) {
                    if (this.getBlockLightOpacity(j, l - 1, k) != 0) {
                        this.heightMap[k << 4 | j] = l;
                        if (l < this.heightMapMinimum) {
                            this.heightMapMinimum = l;
                        }
                        break;
                    }
                }

                if (!this.worldObj.provider.hasNoSky) {
                    int k1 = 15;
                    int i1 = i + 16 - 1;

                    while (true) {
                        int j1 = this.getBlockLightOpacity(j, i1, k);
                        if (j1 == 0 && k1 != 15) {
                            j1 = 1;
                        }

                        k1 -= j1;
                        if (k1 > 0) {
                            ExtendedBlockStorage extendedblockstorage = this.storageArrays[i1 >> 4];
                            if (extendedblockstorage != null) {
                                extendedblockstorage.setExtSkylightValue(j, i1 & 15, k, k1);
                                this.worldObj.markBlockForRenderUpdate((this.xPosition << 4) + j, i1, (this.zPosition << 4) + k);
                            }
                        }

                        if (--i1 <= 0 || k1 <= 0) {
                            break;
                        }
                    }
                }
            }
        }

        this.isModified = true;
    }

    private void propagateSkylightOcclusion(int var1, int var2) {
        this.updateSkylightColumns[var1 + var2 * 16] = true;
        this.isGapLightingUpdated = true;
    }

    private void recheckGaps(boolean var1) {
        this.worldObj.theProfiler.startSection("recheckGaps");
        if (this.worldObj.doChunksNearChunkExist(this.xPosition * 16 + 8, 0, this.zPosition * 16 + 8, 16)) {
            for (int i = 0; i < 16; i++) {
                for (int j = 0; j < 16; j++) {
                    if (this.updateSkylightColumns[i + j * 16]) {
                        this.updateSkylightColumns[i + j * 16] = false;
                        int k = this.getHeightValue(i, j);
                        int l = this.xPosition * 16 + i;
                        int i1 = this.zPosition * 16 + j;
                        int j1 = this.worldObj.getChunkHeightMapMinimum(l - 1, i1);
                        int k1 = this.worldObj.getChunkHeightMapMinimum(l + 1, i1);
                        int l1 = this.worldObj.getChunkHeightMapMinimum(l, i1 - 1);
                        int i2 = this.worldObj.getChunkHeightMapMinimum(l, i1 + 1);
                        if (k1 < j1) {
                            j1 = k1;
                        }

                        if (l1 < j1) {
                            j1 = l1;
                        }

                        if (i2 < j1) {
                            j1 = i2;
                        }

                        this.checkSkylightNeighborHeight(l, i1, j1);
                        this.checkSkylightNeighborHeight(l - 1, i1, k);
                        this.checkSkylightNeighborHeight(l + 1, i1, k);
                        this.checkSkylightNeighborHeight(l, i1 - 1, k);
                        this.checkSkylightNeighborHeight(l, i1 + 1, k);
                        if (var1) {
                            this.worldObj.theProfiler.endSection();
                            return;
                        }
                    }
                }
            }

            this.isGapLightingUpdated = false;
        }

        this.worldObj.theProfiler.endSection();
    }

    private void checkSkylightNeighborHeight(int var1, int var2, int var3) {
        int i = this.worldObj.getHeightValue(var1, var2);
        if (i > var3) {
            this.updateSkylightNeighborHeight(var1, var2, var3, i + 1);
        } else if (i < var3) {
            this.updateSkylightNeighborHeight(var1, var2, i, var3 + 1);
        }
    }

    private void updateSkylightNeighborHeight(int var1, int var2, int var3, int var4) {
        if (var4 > var3 && this.worldObj.doChunksNearChunkExist(var1, 0, var2, 16)) {
            for (int i = var3; i < var4; i++) {
                this.worldObj.updateLightByType(EnumSkyBlock.Sky, var1, i, var2);
            }

            this.isModified = true;
        }
    }

    private void relightBlock(int var1, int var2, int var3) {
        int i = this.heightMap[var3 << 4 | var1] & 0xFF;
        int j = i;
        if (var2 > i) {
            j = var2;
        }

        while (j > 0 && this.getBlockLightOpacity(var1, j - 1, var3) == 0) {
            j--;
        }

        if (j != i) {
            this.worldObj.markBlocksDirtyVertical(var1 + this.xPosition * 16, var3 + this.zPosition * 16, j, i);
            this.heightMap[var3 << 4 | var1] = j;
            int k = this.xPosition * 16 + var1;
            int l = this.zPosition * 16 + var3;
            if (!this.worldObj.provider.hasNoSky) {
                if (j < i) {
                    for (int k1 = j; k1 < i; k1++) {
                        ExtendedBlockStorage extendedblockstorage2 = this.storageArrays[k1 >> 4];
                        if (extendedblockstorage2 != null) {
                            extendedblockstorage2.setExtSkylightValue(var1, k1 & 15, var3, 15);
                            this.worldObj.markBlockForRenderUpdate((this.xPosition << 4) + var1, k1, (this.zPosition << 4) + var3);
                        }
                    }
                } else {
                    for (int i1 = i; i1 < j; i1++) {
                        ExtendedBlockStorage extendedblockstorage = this.storageArrays[i1 >> 4];
                        if (extendedblockstorage != null) {
                            extendedblockstorage.setExtSkylightValue(var1, i1 & 15, var3, 0);
                            this.worldObj.markBlockForRenderUpdate((this.xPosition << 4) + var1, i1, (this.zPosition << 4) + var3);
                        }
                    }
                }

                int l1 = 15;

                while (j > 0 && l1 > 0) {
                    int j2 = this.getBlockLightOpacity(var1, --j, var3);
                    if (j2 == 0) {
                        j2 = 1;
                    }

                    l1 -= j2;
                    if (l1 < 0) {
                        l1 = 0;
                    }

                    ExtendedBlockStorage extendedblockstorage1 = this.storageArrays[j >> 4];
                    if (extendedblockstorage1 != null) {
                        extendedblockstorage1.setExtSkylightValue(var1, j & 15, var3, l1);
                    }
                }
            }

            int i2 = this.heightMap[var3 << 4 | var1];
            int k2 = i;
            int l2 = i2;
            if (l2 < k2) {
                int j1 = k2;
                k2 = l2;
                l2 = j1;
            }

            if (i2 < this.heightMapMinimum) {
                this.heightMapMinimum = i2;
            }

            if (!this.worldObj.provider.hasNoSky) {
                this.updateSkylightNeighborHeight(k - 1, l, k2, l2);
                this.updateSkylightNeighborHeight(k + 1, l, k2, l2);
                this.updateSkylightNeighborHeight(k, l - 1, k2, l2);
                this.updateSkylightNeighborHeight(k, l + 1, k2, l2);
                this.updateSkylightNeighborHeight(k, l, k2, l2);
            }

            this.isModified = true;
        }
    }

    public int getBlockLightOpacity(int var1, int var2, int var3) {
        return this.getBlock(var1, var2, var3).getLightOpacity();
    }

    public Block getBlock(final int var1, final int var2, final int var3) {
        Block block = Blocks.air;
        if (var2 >> 4 < this.storageArrays.length) {
            ExtendedBlockStorage extendedblockstorage = this.storageArrays[var2 >> 4];
            if (extendedblockstorage != null) {
                try {
                    block = extendedblockstorage.getBlockByExtId(var1, var2 & 15, var3);
                } catch (Throwable throwable) {
                    CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Getting block");
                    CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being got");
                    crashreportcategory.addCrashSectionCallable("Location", new Callable() {
                        public String call() {
                            return CrashReportCategory.getLocationInfo(var1, var2, var3);
                        }
                    });
                    throw new ReportedException(crashreport);
                }
            }
        }

        return block;
    }

    public int getBlockMetadata(int var1, int var2, int var3) {
        if (var2 >> 4 >= this.storageArrays.length) {
            return 0;
        }

        ExtendedBlockStorage extendedblockstorage = this.storageArrays[var2 >> 4];
        return extendedblockstorage != null ? extendedblockstorage.getExtBlockMetadata(var1, var2 & 15, var3) : 0;
    }

    public boolean setBlockIDWithMetadata(int var1, int var2, int var3, Block var4, int var5) {
        int i = var3 << 4 | var1;
        if (var2 >= this.precipitationHeightMap[i] - 1) {
            this.precipitationHeightMap[i] = -999;
        }

        int j = this.heightMap[i];
        Block block = this.getBlock(var1, var2, var3);
        int k = this.getBlockMetadata(var1, var2, var3);
        if (block == var4 && k == var5) {
            return false;
        }

        ExtendedBlockStorage extendedblockstorage = this.storageArrays[var2 >> 4];
        boolean flag = false;
        if (extendedblockstorage == null) {
            if (var4 == Blocks.air) {
                return false;
            }

            extendedblockstorage = this.storageArrays[var2 >> 4] = new ExtendedBlockStorage(var2 >> 4 << 4, !this.worldObj.provider.hasNoSky);
            flag = var2 >= j;
        }

        int l = this.xPosition * 16 + var1;
        int i1 = this.zPosition * 16 + var3;
        if (!this.worldObj.isRemote) {
            block.onBlockPreDestroy(this.worldObj, l, var2, i1, k);
        }

        extendedblockstorage.setExtBlockID(var1, var2 & 15, var3, var4);
        if (!this.worldObj.isRemote) {
            block.breakBlock(this.worldObj, l, var2, i1, block, k);
        } else if (block instanceof ITileEntityProvider && block != var4) {
            this.worldObj.removeTileEntity(l, var2, i1);
        }

        if (extendedblockstorage.getBlockByExtId(var1, var2 & 15, var3) != var4) {
            return false;
        }

        extendedblockstorage.setExtBlockMetadata(var1, var2 & 15, var3, var5);
        if (flag) {
            this.generateSkylightMap();
        } else {
            int j1 = var4.getLightOpacity();
            int k1 = block.getLightOpacity();
            if (j1 > 0) {
                if (var2 >= j) {
                    this.relightBlock(var1, var2 + 1, var3);
                }
            } else if (var2 == j - 1) {
                this.relightBlock(var1, var2, var3);
            }

            if (j1 != k1
                && (
                    j1 < k1
                        || this.getSavedLightValue(EnumSkyBlock.Sky, var1, var2, var3) > 0
                        || this.getSavedLightValue(EnumSkyBlock.Block, var1, var2, var3) > 0
                )) {
                this.propagateSkylightOcclusion(var1, var3);
            }
        }

        if (block instanceof ITileEntityProvider) {
            TileEntity tileentity = this.getBlockTileEntityInChunk(var1, var2, var3);
            if (tileentity != null) {
                tileentity.updateContainingBlockInfo();
            }
        }

        if (!this.worldObj.isRemote) {
            var4.onBlockAdded(this.worldObj, l, var2, i1);
        }

        if (var4 instanceof ITileEntityProvider) {
            TileEntity tileentity1 = this.getBlockTileEntityInChunk(var1, var2, var3);
            if (tileentity1 == null) {
                tileentity1 = ((ITileEntityProvider)var4).createNewTileEntity(this.worldObj, var5);
                this.worldObj.setTileEntity(l, var2, i1, tileentity1);
            }

            if (tileentity1 != null) {
                tileentity1.updateContainingBlockInfo();
            }
        }

        this.isModified = true;
        return true;
    }

    public boolean setBlockMetadata(int var1, int var2, int var3, int var4) {
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[var2 >> 4];
        if (extendedblockstorage == null) {
            return false;
        }

        int i = extendedblockstorage.getExtBlockMetadata(var1, var2 & 15, var3);
        if (i == var4) {
            return false;
        }

        this.isModified = true;
        extendedblockstorage.setExtBlockMetadata(var1, var2 & 15, var3, var4);
        if (extendedblockstorage.getBlockByExtId(var1, var2 & 15, var3) instanceof ITileEntityProvider) {
            TileEntity tileentity = this.getBlockTileEntityInChunk(var1, var2, var3);
            if (tileentity != null) {
                tileentity.updateContainingBlockInfo();
                tileentity.blockMetadata = var4;
            }
        }

        return true;
    }

    public int getSavedLightValue(EnumSkyBlock var1, int var2, int var3, int var4) {
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[var3 >> 4];
        if (extendedblockstorage == null) {
            return this.canBlockSeeTheSky(var2, var3, var4) ? var1.defaultLightValue : 0;
        } else if (var1 == EnumSkyBlock.Sky) {
            return this.worldObj.provider.hasNoSky ? 0 : extendedblockstorage.getExtSkylightValue(var2, var3 & 15, var4);
        } else {
            return var1 == EnumSkyBlock.Block ? extendedblockstorage.getExtBlocklightValue(var2, var3 & 15, var4) : var1.defaultLightValue;
        }
    }

    public void setLightValue(EnumSkyBlock var1, int var2, int var3, int var4, int var5) {
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[var3 >> 4];
        if (extendedblockstorage == null) {
            extendedblockstorage = this.storageArrays[var3 >> 4] = new ExtendedBlockStorage(var3 >> 4 << 4, !this.worldObj.provider.hasNoSky);
            this.generateSkylightMap();
        }

        this.isModified = true;
        if (var1 == EnumSkyBlock.Sky) {
            if (!this.worldObj.provider.hasNoSky) {
                extendedblockstorage.setExtSkylightValue(var2, var3 & 15, var4, var5);
            }
        } else if (var1 == EnumSkyBlock.Block) {
            extendedblockstorage.setExtBlocklightValue(var2, var3 & 15, var4, var5);
        }
    }

    public int getBlockLightValue(int var1, int var2, int var3, int var4) {
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[var2 >> 4];
        if (extendedblockstorage == null) {
            return !this.worldObj.provider.hasNoSky && var4 < EnumSkyBlock.Sky.defaultLightValue ? EnumSkyBlock.Sky.defaultLightValue - var4 : 0;
        }

        int i = this.worldObj.provider.hasNoSky ? 0 : extendedblockstorage.getExtSkylightValue(var1, var2 & 15, var3);
        if (i > 0) {
            isLit = true;
        }

        i -= var4;
        int j = extendedblockstorage.getExtBlocklightValue(var1, var2 & 15, var3);
        if (j > i) {
            i = j;
        }

        return i;
    }

    public void addEntity(Entity var1) {
        this.hasEntities = true;
        int i = MathHelper.floor_double(var1.posX / 16.0);
        int j = MathHelper.floor_double(var1.posZ / 16.0);
        if (i != this.xPosition || j != this.zPosition) {
            logger.error("Wrong location! " + var1);
            Thread.dumpStack();
        }

        int k = MathHelper.floor_double(var1.posY / 16.0);
        if (k < 0) {
            k = 0;
        }

        if (k >= this.entityLists.length) {
            k = this.entityLists.length - 1;
        }

        var1.addedToChunk = true;
        var1.chunkCoordX = this.xPosition;
        var1.chunkCoordY = k;
        var1.chunkCoordZ = this.zPosition;
        this.entityLists[k].add(var1);
    }

    public void removeEntity(Entity var1) {
        this.removeEntityAtIndex(var1, var1.chunkCoordY);
    }

    public void removeEntityAtIndex(Entity var1, int var2) {
        if (var2 < 0) {
            var2 = 0;
        }

        if (var2 >= this.entityLists.length) {
            var2 = this.entityLists.length - 1;
        }

        this.entityLists[var2].remove(var1);
    }

    public boolean canBlockSeeTheSky(int var1, int var2, int var3) {
        return var2 >= this.heightMap[var3 << 4 | var1];
    }

    public TileEntity getBlockTileEntityInChunk(int var1, int var2, int var3) {
        ChunkPosition chunkposition = new ChunkPosition(var1, var2, var3);
        TileEntity tileentity = (TileEntity)this.chunkTileEntityMap.get(chunkposition);
        if (tileentity == null) {
            Block block = this.getBlock(var1, var2, var3);
            if (!block.hasTileEntity()) {
                return null;
            }

            tileentity = ((ITileEntityProvider)block).createNewTileEntity(this.worldObj, this.getBlockMetadata(var1, var2, var3));
            this.worldObj.setTileEntity(this.xPosition * 16 + var1, var2, this.zPosition * 16 + var3, tileentity);
        }

        if (tileentity != null && tileentity.isInvalid()) {
            this.chunkTileEntityMap.remove(chunkposition);
            return null;
        } else {
            return tileentity;
        }
    }

    public void addTileEntity(TileEntity var1) {
        int i = var1.xCoord - this.xPosition * 16;
        int j = var1.yCoord;
        int k = var1.zCoord - this.zPosition * 16;
        this.setBlockTileEntityInChunk(i, j, k, var1);
        if (this.isChunkLoaded) {
            this.worldObj.loadedTileEntityList.add(var1);
        }
    }

    public void setBlockTileEntityInChunk(int var1, int var2, int var3, TileEntity var4) {
        ChunkPosition chunkposition = new ChunkPosition(var1, var2, var3);
        var4.setWorldObj(this.worldObj);
        var4.xCoord = this.xPosition * 16 + var1;
        var4.yCoord = var2;
        var4.zCoord = this.zPosition * 16 + var3;
        if (this.getBlock(var1, var2, var3) instanceof ITileEntityProvider) {
            if (this.chunkTileEntityMap.containsKey(chunkposition)) {
                ((TileEntity)this.chunkTileEntityMap.get(chunkposition)).invalidate();
            }

            var4.validate();
            this.chunkTileEntityMap.put(chunkposition, var4);
        }
    }

    public void removeTileEntity(int var1, int var2, int var3) {
        ChunkPosition chunkposition = new ChunkPosition(var1, var2, var3);
        if (this.isChunkLoaded) {
            TileEntity tileentity = (TileEntity)this.chunkTileEntityMap.remove(chunkposition);
            if (tileentity != null) {
                tileentity.invalidate();
            }
        }
    }

    public void onChunkLoad() {
        this.isChunkLoaded = true;
        this.worldObj.func_147448_a(this.chunkTileEntityMap.values());

        for (int i = 0; i < this.entityLists.length; i++) {
            for (Entity entity : (Iterable<Entity>) (Iterable) this.entityLists[i]) {
                entity.onChunkLoad();
            }

            this.worldObj.addLoadedEntities(this.entityLists[i]);
        }
    }

    public void onChunkUnload() {
        this.isChunkLoaded = false;

        for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) this.chunkTileEntityMap.values()) {
            this.worldObj.markTileEntityForRemoval(tileentity);
        }

        for (int i = 0; i < this.entityLists.length; i++) {
            this.worldObj.unloadEntities(this.entityLists[i]);
        }
    }

    public void setChunkModified() {
        this.isModified = true;
    }

    public void getEntitiesWithinAABBForEntity(Entity var1, AxisAlignedBB var2, List var3, IEntitySelector var4) {
        int i = MathHelper.floor_double((var2.minY - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxY + 2.0) / 16.0);
        i = MathHelper.clamp_int(i, 0, this.entityLists.length - 1);
        j = MathHelper.clamp_int(j, 0, this.entityLists.length - 1);

        for (int k = i; k <= j; k++) {
            List list = this.entityLists[k];

            for (int l = 0; l < list.size(); l++) {
                Entity entity = (Entity)list.get(l);
                if (entity != var1 && entity.boundingBox.intersectsWith(var2) && (var4 == null || var4.isEntityApplicable(entity))) {
                    var3.add(entity);
                    Entity[] aentity = entity.getParts();
                    if (aentity != null) {
                        for (int i1 = 0; i1 < aentity.length; i1++) {
                            entity = aentity[i1];
                            if (entity != var1 && entity.boundingBox.intersectsWith(var2) && (var4 == null || var4.isEntityApplicable(entity))) {
                                var3.add(entity);
                            }
                        }
                    }
                }
            }
        }
    }

    public void getEntitiesOfTypeWithinAAAB(Class var1, AxisAlignedBB var2, List var3, IEntitySelector var4) {
        int i = MathHelper.floor_double((var2.minY - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxY + 2.0) / 16.0);
        i = MathHelper.clamp_int(i, 0, this.entityLists.length - 1);
        j = MathHelper.clamp_int(j, 0, this.entityLists.length - 1);

        for (int k = i; k <= j; k++) {
            List list = this.entityLists[k];

            for (int l = 0; l < list.size(); l++) {
                Entity entity = (Entity)list.get(l);
                if (var1.isAssignableFrom(entity.getClass()) && entity.boundingBox.intersectsWith(var2) && (var4 == null || var4.isEntityApplicable(entity))) {
                    var3.add(entity);
                }
            }
        }
    }

    public boolean needsSaving(boolean var1) {
        if (var1) {
            if (this.hasEntities && this.worldObj.getTotalWorldTime() != this.lastSaveTime || this.isModified) {
                return true;
            }
        } else if (this.hasEntities && this.worldObj.getTotalWorldTime() >= this.lastSaveTime + 600L) {
            return true;
        }

        return this.isModified;
    }

    public Random getRandomWithSeed(long var1) {
        return new Random(
            this.worldObj.getSeed()
                    + this.xPosition * this.xPosition * 4987142
                    + this.xPosition * 5947611
                    + this.zPosition * this.zPosition * 4392871L
                    + this.zPosition * 389711
                ^ var1
        );
    }

    public boolean isEmpty() {
        return false;
    }

    public void populateChunk(IChunkProvider var1, IChunkProvider var2, int var3, int var4) {
        if (!this.isTerrainPopulated && var1.chunkExists(var3 + 1, var4 + 1) && var1.chunkExists(var3, var4 + 1) && var1.chunkExists(var3 + 1, var4)) {
            var1.populate(var2, var3, var4);
        }

        if (var1.chunkExists(var3 - 1, var4)
            && !var1.provideChunk(var3 - 1, var4).isTerrainPopulated
            && var1.chunkExists(var3 - 1, var4 + 1)
            && var1.chunkExists(var3, var4 + 1)
            && var1.chunkExists(var3 - 1, var4 + 1)) {
            var1.populate(var2, var3 - 1, var4);
        }

        if (var1.chunkExists(var3, var4 - 1)
            && !var1.provideChunk(var3, var4 - 1).isTerrainPopulated
            && var1.chunkExists(var3 + 1, var4 - 1)
            && var1.chunkExists(var3 + 1, var4 - 1)
            && var1.chunkExists(var3 + 1, var4)) {
            var1.populate(var2, var3, var4 - 1);
        }

        if (var1.chunkExists(var3 - 1, var4 - 1)
            && !var1.provideChunk(var3 - 1, var4 - 1).isTerrainPopulated
            && var1.chunkExists(var3, var4 - 1)
            && var1.chunkExists(var3 - 1, var4)) {
            var1.populate(var2, var3 - 1, var4 - 1);
        }
    }

    public int getPrecipitationHeight(int var1, int var2) {
        int i = var1 | var2 << 4;
        int j = this.precipitationHeightMap[i];
        if (j == -999) {
            int k = this.getTopFilledSegment() + 15;
            j = -1;

            while (k > 0 && j == -1) {
                Block block = this.getBlock(var1, k, var2);
                Material material = block.getMaterial();
                if (!material.blocksMovement() && !material.isLiquid()) {
                    k--;
                } else {
                    j = k + 1;
                }
            }

            this.precipitationHeightMap[i] = j;
        }

        return j;
    }

    public void func_150804_b(boolean var1) {
        if (this.isGapLightingUpdated && !this.worldObj.provider.hasNoSky && !var1) {
            this.recheckGaps(this.worldObj.isRemote);
        }

        this.field_150815_m = true;
        if (!this.isLightPopulated && this.isTerrainPopulated) {
            this.func_150809_p();
        }
    }

    public boolean func_150802_k() {
        return this.field_150815_m && this.isTerrainPopulated && this.isLightPopulated;
    }

    public ChunkCoordIntPair getChunkCoordIntPair() {
        return new ChunkCoordIntPair(this.xPosition, this.zPosition);
    }

    public boolean getAreLevelsEmpty(int var1, int var2) {
        if (var1 < 0) {
            var1 = 0;
        }

        if (var2 >= 256) {
            var2 = 255;
        }

        for (int i = var1; i <= var2; i += 16) {
            ExtendedBlockStorage extendedblockstorage = this.storageArrays[i >> 4];
            if (extendedblockstorage != null && !extendedblockstorage.isEmpty()) {
                return false;
            }
        }

        return true;
    }

    public void setStorageArrays(ExtendedBlockStorage[] var1) {
        this.storageArrays = var1;
    }

    public void fillChunk(byte[] var1, int var2, int var3, boolean var4) {
        int i = 0;
        boolean flag = !this.worldObj.provider.hasNoSky;

        for (int j = 0; j < this.storageArrays.length; j++) {
            if ((var2 & 1 << j) != 0) {
                if (this.storageArrays[j] == null) {
                    this.storageArrays[j] = new ExtendedBlockStorage(j << 4, flag);
                }

                byte[] abyte = this.storageArrays[j].getBlockLSBArray();
                System.arraycopy(var1, i, abyte, 0, abyte.length);
                i += abyte.length;
            } else if (var4 && this.storageArrays[j] != null) {
                this.storageArrays[j] = null;
            }
        }

        for (int k = 0; k < this.storageArrays.length; k++) {
            if ((var2 & 1 << k) != 0 && this.storageArrays[k] != null) {
                NibbleArray nibblearray = this.storageArrays[k].getMetadataArray();
                System.arraycopy(var1, i, nibblearray.data, 0, nibblearray.data.length);
                i += nibblearray.data.length;
            }
        }

        for (int l = 0; l < this.storageArrays.length; l++) {
            if ((var2 & 1 << l) != 0 && this.storageArrays[l] != null) {
                NibbleArray nibblearray1 = this.storageArrays[l].getBlocklightArray();
                System.arraycopy(var1, i, nibblearray1.data, 0, nibblearray1.data.length);
                i += nibblearray1.data.length;
            }
        }

        if (flag) {
            for (int i1 = 0; i1 < this.storageArrays.length; i1++) {
                if ((var2 & 1 << i1) != 0 && this.storageArrays[i1] != null) {
                    NibbleArray nibblearray2 = this.storageArrays[i1].getSkylightArray();
                    System.arraycopy(var1, i, nibblearray2.data, 0, nibblearray2.data.length);
                    i += nibblearray2.data.length;
                }
            }
        }

        for (int j1 = 0; j1 < this.storageArrays.length; j1++) {
            if ((var3 & 1 << j1) != 0) {
                if (this.storageArrays[j1] == null) {
                    i += 2048;
                } else {
                    NibbleArray nibblearray3 = this.storageArrays[j1].getBlockMSBArray();
                    if (nibblearray3 == null) {
                        nibblearray3 = this.storageArrays[j1].createBlockMSBArray();
                    }

                    System.arraycopy(var1, i, nibblearray3.data, 0, nibblearray3.data.length);
                    i += nibblearray3.data.length;
                }
            } else if (var4 && this.storageArrays[j1] != null && this.storageArrays[j1].getBlockMSBArray() != null) {
                this.storageArrays[j1].clearMSBArray();
            }
        }

        if (var4) {
            System.arraycopy(var1, i, this.blockBiomeArray, 0, this.blockBiomeArray.length);
            i += this.blockBiomeArray.length;
        }

        for (int k1 = 0; k1 < this.storageArrays.length; k1++) {
            if (this.storageArrays[k1] != null && (var2 & 1 << k1) != 0) {
                this.storageArrays[k1].removeInvalidBlocks();
            }
        }

        this.isLightPopulated = true;
        this.isTerrainPopulated = true;
        this.generateHeightMap();

        for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) this.chunkTileEntityMap.values()) {
            tileentity.updateContainingBlockInfo();
        }
    }

    public BiomeGenBase getBiomeGenForWorldCoords(int var1, int var2, WorldChunkManager var3) {
        int i = this.blockBiomeArray[var2 << 4 | var1] & 255;
        if (i == 255) {
            BiomeGenBase biomegenbase = var3.getBiomeGenAt((this.xPosition << 4) + var1, (this.zPosition << 4) + var2);
            i = biomegenbase.biomeID;
            this.blockBiomeArray[var2 << 4 | var1] = (byte)(i & 0xFF);
        }

        return BiomeGenBase.getBiome(i) == null ? BiomeGenBase.plains : BiomeGenBase.getBiome(i);
    }

    public byte[] getBiomeArray() {
        return this.blockBiomeArray;
    }

    public void setBiomeArray(byte[] var1) {
        this.blockBiomeArray = var1;
    }

    public void resetRelightChecks() {
        this.queuedLightChecks = 0;
    }

    public void enqueueRelightChecks() {
        for (int i = 0; i < 8; i++) {
            if (this.queuedLightChecks >= 4096) {
                return;
            }

            int j = this.queuedLightChecks % 16;
            int k = this.queuedLightChecks / 16 % 16;
            int l = this.queuedLightChecks / 256;
            this.queuedLightChecks++;
            int i1 = (this.xPosition << 4) + k;
            int j1 = (this.zPosition << 4) + l;

            for (int k1 = 0; k1 < 16; k1++) {
                int l1 = (j << 4) + k1;
                if (this.storageArrays[j] == null && (k1 == 0 || k1 == 15 || k == 0 || k == 15 || l == 0 || l == 15)
                    || this.storageArrays[j] != null && this.storageArrays[j].getBlockByExtId(k, k1, l).getMaterial() == Material.air) {
                    if (this.worldObj.getBlock(i1, l1 - 1, j1).getLightValue() > 0) {
                        this.worldObj.updateAllLightTypes(i1, l1 - 1, j1);
                    }

                    if (this.worldObj.getBlock(i1, l1 + 1, j1).getLightValue() > 0) {
                        this.worldObj.updateAllLightTypes(i1, l1 + 1, j1);
                    }

                    if (this.worldObj.getBlock(i1 - 1, l1, j1).getLightValue() > 0) {
                        this.worldObj.updateAllLightTypes(i1 - 1, l1, j1);
                    }

                    if (this.worldObj.getBlock(i1 + 1, l1, j1).getLightValue() > 0) {
                        this.worldObj.updateAllLightTypes(i1 + 1, l1, j1);
                    }

                    if (this.worldObj.getBlock(i1, l1, j1 - 1).getLightValue() > 0) {
                        this.worldObj.updateAllLightTypes(i1, l1, j1 - 1);
                    }

                    if (this.worldObj.getBlock(i1, l1, j1 + 1).getLightValue() > 0) {
                        this.worldObj.updateAllLightTypes(i1, l1, j1 + 1);
                    }

                    this.worldObj.updateAllLightTypes(i1, l1, j1);
                }
            }
        }
    }

    public void func_150809_p() {
        this.isTerrainPopulated = true;
        this.isLightPopulated = true;
        if (!this.worldObj.provider.hasNoSky) {
            if (this.worldObj.checkChunksExist(this.xPosition * 16 - 1, 0, this.zPosition * 16 - 1, this.xPosition * 16 + 1, 63, this.zPosition * 16 + 1)) {
                for (int i = 0; i < 16; i++) {
                    for (int j = 0; j < 16; j++) {
                        if (!this.func_150811_f(i, j)) {
                            this.isLightPopulated = false;
                            break;
                        }
                    }
                }

                if (this.isLightPopulated) {
                    Chunk chunk = this.worldObj.getChunkFromBlockCoords(this.xPosition * 16 - 1, this.zPosition * 16);
                    chunk.func_150801_a(3);
                    chunk = this.worldObj.getChunkFromBlockCoords(this.xPosition * 16 + 16, this.zPosition * 16);
                    chunk.func_150801_a(1);
                    chunk = this.worldObj.getChunkFromBlockCoords(this.xPosition * 16, this.zPosition * 16 - 1);
                    chunk.func_150801_a(0);
                    chunk = this.worldObj.getChunkFromBlockCoords(this.xPosition * 16, this.zPosition * 16 + 16);
                    chunk.func_150801_a(2);
                }
            } else {
                this.isLightPopulated = false;
            }
        }
    }

    private void func_150801_a(int var1) {
        if (this.isTerrainPopulated) {
            if (var1 == 3) {
                for (int i = 0; i < 16; i++) {
                    this.func_150811_f(15, i);
                }
            } else if (var1 == 1) {
                for (int j = 0; j < 16; j++) {
                    this.func_150811_f(0, j);
                }
            } else if (var1 == 0) {
                for (int k = 0; k < 16; k++) {
                    this.func_150811_f(k, 15);
                }
            } else if (var1 == 2) {
                for (int l = 0; l < 16; l++) {
                    this.func_150811_f(l, 0);
                }
            }
        }
    }

    private boolean func_150811_f(int var1, int var2) {
        int i = this.getTopFilledSegment();
        boolean flag = false;
        boolean flag1 = false;

        int j;
        for (j = i + 16 - 1; j > 63 || j > 0 && !flag1; j--) {
            int k = this.getBlockLightOpacity(var1, j, var2);
            if (k == 255 && j < 63) {
                flag1 = true;
            }

            if (!flag && k > 0) {
                flag = true;
            } else if (flag && k == 0 && !this.worldObj.updateAllLightTypes(this.xPosition * 16 + var1, j, this.zPosition * 16 + var2)) {
                return false;
            }
        }

        for (; j > 0; j--) {
            if (this.getBlock(var1, j, var2).getLightValue() > 0) {
                this.worldObj.updateAllLightTypes(this.xPosition * 16 + var1, j, this.zPosition * 16 + var2);
            }
        }

        return true;
    }
}
