package net.minecraft.network.play.server;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S3FPacketCustomPayload extends Packet {
    private String channel;
    private byte[] data;

    public S3FPacketCustomPayload() {
    }

    public S3FPacketCustomPayload(String var1, ByteBuf var2) {
        this(var1, var2.array());
    }

    public S3FPacketCustomPayload(String var1, byte[] var2) {
        this.channel = var1;
        this.data = var2;
        if (var2.length >= Short.MAX_VALUE) {
            throw new IllegalArgumentException("Payload may not be larger than 32767 bytes");
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.channel = var1.readStringFromBuffer(20);
        this.data = new byte[var1.readUnsignedShort()];
        var1.readBytes(this.data);
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeStringToBuffer(this.channel);
        var1.writeShort(this.data.length);
        var1.writeBytes(this.data);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleCustomPayload(this);
    }

    public String func_149169_c() {
        return this.channel;
    }

    public byte[] func_149168_d() {
        return this.data;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
