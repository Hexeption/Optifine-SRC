package net.minecraft.network;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import io.netty.buffer.Unpooled;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Callable;
import net.minecraft.block.material.Material;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityMinecartCommandBlock;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerBeacon;
import net.minecraft.inventory.ContainerMerchant;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemEditableBook;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemWritableBook;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C01PacketChatMessage;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0CPacketInput;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.client.C10PacketCreativeInventoryAction;
import net.minecraft.network.play.client.C11PacketEnchantItem;
import net.minecraft.network.play.client.C12PacketUpdateSign;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import net.minecraft.network.play.client.C14PacketTabComplete;
import net.minecraft.network.play.client.C15PacketClientSettings;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.network.play.server.S00PacketKeepAlive;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.network.play.server.S32PacketConfirmTransaction;
import net.minecraft.network.play.server.S3APacketTabComplete;
import net.minecraft.network.play.server.S40PacketDisconnect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.BanEntry;
import net.minecraft.stats.AchievementList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.ReportedException;
import net.minecraft.world.WorldServer;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NetHandlerPlayServer implements INetHandlerPlayServer {
    private static final Logger logger = LogManager.getLogger();
    public final NetworkManager netManager;
    private final MinecraftServer serverController;
    public EntityPlayerMP playerEntity;
    private int networkTickCount;
    private int floatingTickCount;
    private boolean field_147366_g;
    private int field_147378_h;
    private long lastPingTime;
    private static Random field_147376_j = new Random();
    private long lastSentPingPacket;
    private int chatSpamThresholdCount;
    private int itemDropThreshold;
    private IntHashMap field_147372_n = new IntHashMap();
    private double lastPosX;
    private double lastPosY;
    private double lastPosZ;
    private boolean hasMoved = true;

    public NetHandlerPlayServer(MinecraftServer var1, NetworkManager var2, EntityPlayerMP var3) {
        this.serverController = var1;
        this.netManager = var2;
        var2.setNetHandler(this);
        this.playerEntity = var3;
        var3.playerNetServerHandler = this;
    }

    @Override
    public void onNetworkTick() {
        this.field_147366_g = false;
        this.networkTickCount++;
        this.serverController.theProfiler.startSection("keepAlive");
        if (this.networkTickCount - this.lastSentPingPacket > 40L) {
            this.lastSentPingPacket = this.networkTickCount;
            this.lastPingTime = this.currentTimeMillis();
            this.field_147378_h = (int)this.lastPingTime;
            this.sendPacket(new S00PacketKeepAlive(this.field_147378_h));
        }

        if (this.chatSpamThresholdCount > 0) {
            this.chatSpamThresholdCount--;
        }

        if (this.itemDropThreshold > 0) {
            this.itemDropThreshold--;
        }

        this.serverController.theProfiler.endStartSection("playerTick");
        this.serverController.theProfiler.endSection();
    }

    public NetworkManager getNetworkManager() {
        return this.netManager;
    }

    public void kickPlayerFromServer(String var1) {
        final ChatComponentText chatcomponenttext = new ChatComponentText(var1);
        this.netManager.scheduleOutboundPacket(new S40PacketDisconnect(chatcomponenttext), new GenericFutureListener() {
            @Override
            public void operationComplete(Future var1) {
                NetHandlerPlayServer.this.netManager.closeChannel(chatcomponenttext);
            }
        });
        this.netManager.disableAutoRead();
    }

    @Override
    public void processInput(C0CPacketInput var1) {
        this.playerEntity.setEntityActionState(var1.getStrafeSpeed(), var1.getForwardSpeed(), var1.isJumping(), var1.isSneaking());
    }

    @Override
    public void processPlayer(C03PacketPlayer var1) {
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        this.field_147366_g = true;
        if (!this.playerEntity.playerConqueredTheEnd) {
            if (!this.hasMoved) {
                double d0 = var1.getPositionY() - this.lastPosY;
                if (var1.getPositionX() == this.lastPosX && d0 * d0 < 0.01 && var1.getPositionZ() == this.lastPosZ) {
                    this.hasMoved = true;
                }
            }

            if (this.hasMoved) {
                if (this.playerEntity.ridingEntity != null) {
                    float f4 = this.playerEntity.rotationYaw;
                    float f = this.playerEntity.rotationPitch;
                    this.playerEntity.ridingEntity.updateRiderPosition();
                    double d13 = this.playerEntity.posX;
                    double d14 = this.playerEntity.posY;
                    double d15 = this.playerEntity.posZ;
                    if (var1.getRotating()) {
                        f4 = var1.getYaw();
                        f = var1.getPitch();
                    }

                    this.playerEntity.onGround = var1.func_149465_i();
                    this.playerEntity.onUpdateEntity();
                    this.playerEntity.yOffset2 = 0.0F;
                    this.playerEntity.setPositionAndRotation(d13, d14, d15, f4, f);
                    if (this.playerEntity.ridingEntity != null) {
                        this.playerEntity.ridingEntity.updateRiderPosition();
                    }

                    this.serverController.getConfigurationManager().serverUpdateMountedMovingPlayer(this.playerEntity);
                    if (this.hasMoved) {
                        this.lastPosX = this.playerEntity.posX;
                        this.lastPosY = this.playerEntity.posY;
                        this.lastPosZ = this.playerEntity.posZ;
                    }

                    worldserver.updateEntity(this.playerEntity);
                    return;
                }

                if (this.playerEntity.isPlayerSleeping()) {
                    this.playerEntity.onUpdateEntity();
                    this.playerEntity
                        .setPositionAndRotation(this.lastPosX, this.lastPosY, this.lastPosZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
                    worldserver.updateEntity(this.playerEntity);
                    return;
                }

                double d12 = this.playerEntity.posY;
                this.lastPosX = this.playerEntity.posX;
                this.lastPosY = this.playerEntity.posY;
                this.lastPosZ = this.playerEntity.posZ;
                double d1 = this.playerEntity.posX;
                double d2 = this.playerEntity.posY;
                double d3 = this.playerEntity.posZ;
                float f1 = this.playerEntity.rotationYaw;
                float f2 = this.playerEntity.rotationPitch;
                if (var1.func_149466_j() && var1.getPositionY() == -999.0 && var1.getStance() == -999.0) {
                    var1.func_149469_a(false);
                }

                if (var1.func_149466_j()) {
                    d1 = var1.getPositionX();
                    d2 = var1.getPositionY();
                    d3 = var1.getPositionZ();
                    double d4 = var1.getStance() - var1.getPositionY();
                    if (!this.playerEntity.isPlayerSleeping() && (d4 > 1.65 || d4 < 0.1)) {
                        this.kickPlayerFromServer("Illegal stance");
                        logger.warn(this.playerEntity.getCommandSenderName() + " had an illegal stance: " + d4);
                        return;
                    }

                    if (Math.abs(var1.getPositionX()) > 3.2E7 || Math.abs(var1.getPositionZ()) > 3.2E7) {
                        this.kickPlayerFromServer("Illegal position");
                        return;
                    }
                }

                if (var1.getRotating()) {
                    f1 = var1.getYaw();
                    f2 = var1.getPitch();
                }

                this.playerEntity.onUpdateEntity();
                this.playerEntity.yOffset2 = 0.0F;
                this.playerEntity.setPositionAndRotation(this.lastPosX, this.lastPosY, this.lastPosZ, f1, f2);
                if (!this.hasMoved) {
                    return;
                }

                double d16 = d1 - this.playerEntity.posX;
                double d5 = d2 - this.playerEntity.posY;
                double d6 = d3 - this.playerEntity.posZ;
                double d7 = Math.min(Math.abs(d16), Math.abs(this.playerEntity.motionX));
                double d8 = Math.min(Math.abs(d5), Math.abs(this.playerEntity.motionY));
                double d9 = Math.min(Math.abs(d6), Math.abs(this.playerEntity.motionZ));
                double d10 = d7 * d7 + d8 * d8 + d9 * d9;
                if (d10 > 100.0
                    && (!this.serverController.isSinglePlayer() || !this.serverController.getServerOwner().equals(this.playerEntity.getCommandSenderName()))) {
                    logger.warn(
                        this.playerEntity.getCommandSenderName() + " moved too quickly! " + d16 + "," + d5 + "," + d6 + " (" + d7 + ", " + d8 + ", " + d9 + ")"
                    );
                    this.setPlayerLocation(this.lastPosX, this.lastPosY, this.lastPosZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
                    return;
                }

                float f3 = 1.0F / 16.0F;
                boolean flag = worldserver.getCollidingBoundingBoxes(this.playerEntity, this.playerEntity.boundingBox.copy().contract(f3, f3, f3)).isEmpty();
                if (this.playerEntity.onGround && !var1.func_149465_i() && d5 > 0.0) {
                    this.playerEntity.jump();
                }

                this.playerEntity.moveEntity(d16, d5, d6);
                this.playerEntity.onGround = var1.func_149465_i();
                this.playerEntity.addMovementStat(d16, d5, d6);
                double d11 = d5;
                d16 = d1 - this.playerEntity.posX;
                d5 = d2 - this.playerEntity.posY;
                if (d5 > -0.5 || d5 < 0.5) {
                    d5 = 0.0;
                }

                d6 = d3 - this.playerEntity.posZ;
                d10 = d16 * d16 + d5 * d5 + d6 * d6;
                boolean flag1 = false;
                if (d10 > 1.0 / 16.0 && !this.playerEntity.isPlayerSleeping() && !this.playerEntity.theItemInWorldManager.isCreative()) {
                    flag1 = true;
                    logger.warn(this.playerEntity.getCommandSenderName() + " moved wrongly!");
                }

                this.playerEntity.setPositionAndRotation(d1, d2, d3, f1, f2);
                boolean flag2 = worldserver.getCollidingBoundingBoxes(this.playerEntity, this.playerEntity.boundingBox.copy().contract(f3, f3, f3)).isEmpty();
                if (flag && (flag1 || !flag2) && !this.playerEntity.isPlayerSleeping()) {
                    this.setPlayerLocation(this.lastPosX, this.lastPosY, this.lastPosZ, f1, f2);
                    return;
                }

                AxisAlignedBB axisalignedbb = this.playerEntity.boundingBox.copy().expand(f3, f3, f3).addCoord(0.0, -0.55, 0.0);
                if (this.serverController.isFlightAllowed()
                    || this.playerEntity.theItemInWorldManager.isCreative()
                    || worldserver.checkBlockCollision(axisalignedbb)) {
                    this.floatingTickCount = 0;
                } else if (d11 >= -0.03125) {
                    this.floatingTickCount++;
                    if (this.floatingTickCount > 80) {
                        logger.warn(this.playerEntity.getCommandSenderName() + " was kicked for floating too long!");
                        this.kickPlayerFromServer("Flying is not enabled on this server");
                        return;
                    }
                }

                this.playerEntity.onGround = var1.func_149465_i();
                this.serverController.getConfigurationManager().serverUpdateMountedMovingPlayer(this.playerEntity);
                this.playerEntity.handleFalling(this.playerEntity.posY - d12, var1.func_149465_i());
            } else if (this.networkTickCount % 20 == 0) {
                this.setPlayerLocation(this.lastPosX, this.lastPosY, this.lastPosZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
            }
        }
    }

    public void setPlayerLocation(double var1, double var3, double var5, float var7, float var8) {
        this.hasMoved = false;
        this.lastPosX = var1;
        this.lastPosY = var3;
        this.lastPosZ = var5;
        this.playerEntity.setPositionAndRotation(var1, var3, var5, var7, var8);
        this.playerEntity.playerNetServerHandler.sendPacket(new S08PacketPlayerPosLook(var1, var3 + 1.62F, var5, var7, var8, false));
    }

    @Override
    public void processPlayerDigging(C07PacketPlayerDigging var1) {
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        this.playerEntity.markPlayerActive();
        if (var1.getDiggedBlockStatus() == 4) {
            this.playerEntity.dropOneItem(false);
        } else if (var1.getDiggedBlockStatus() == 3) {
            this.playerEntity.dropOneItem(true);
        } else if (var1.getDiggedBlockStatus() == 5) {
            this.playerEntity.stopUsingItem();
        } else {
            boolean flag = false;
            if (var1.getDiggedBlockStatus() == 0) {
                flag = true;
            }

            if (var1.getDiggedBlockStatus() == 1) {
                flag = true;
            }

            if (var1.getDiggedBlockStatus() == 2) {
                flag = true;
            }

            int i = var1.getDiggedBlockX();
            int j = var1.getDiggedBlockY();
            int k = var1.getDiggedBlockZ();
            if (flag) {
                double d0 = this.playerEntity.posX - (i + 0.5);
                double d1 = this.playerEntity.posY - (j + 0.5) + 1.5;
                double d2 = this.playerEntity.posZ - (k + 0.5);
                double d3 = d0 * d0 + d1 * d1 + d2 * d2;
                if (d3 > 36.0) {
                    return;
                }

                if (j >= this.serverController.getBuildLimit()) {
                    return;
                }
            }

            if (var1.getDiggedBlockStatus() == 0) {
                if (!this.serverController.isBlockProtected(worldserver, i, j, k, this.playerEntity)) {
                    this.playerEntity.theItemInWorldManager.onBlockClicked(i, j, k, var1.getDiggingBlockFace());
                } else {
                    this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(i, j, k, worldserver));
                }
            } else if (var1.getDiggedBlockStatus() == 2) {
                this.playerEntity.theItemInWorldManager.blockRemoving(i, j, k);
                if (worldserver.getBlock(i, j, k).getMaterial() != Material.air) {
                    this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(i, j, k, worldserver));
                }
            } else if (var1.getDiggedBlockStatus() == 1) {
                this.playerEntity.theItemInWorldManager.cancelDestroyingBlock(i, j, k);
                if (worldserver.getBlock(i, j, k).getMaterial() != Material.air) {
                    this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(i, j, k, worldserver));
                }
            }
        }
    }

    @Override
    public void processPlayerBlockPlacement(C08PacketPlayerBlockPlacement var1) {
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        ItemStack itemstack = this.playerEntity.inventory.getCurrentItem();
        boolean flag = false;
        int i = var1.getPlacedBlockX();
        int j = var1.getPlacedBlockY();
        int k = var1.getPlacedBlockZ();
        int l = var1.getPlacedBlockDirection();
        this.playerEntity.markPlayerActive();
        if (var1.getPlacedBlockDirection() == 255) {
            if (itemstack == null) {
                return;
            }

            this.playerEntity.theItemInWorldManager.tryUseItem(this.playerEntity, worldserver, itemstack);
        } else if (var1.getPlacedBlockY() < this.serverController.getBuildLimit() - 1
            || var1.getPlacedBlockDirection() != 1 && var1.getPlacedBlockY() < this.serverController.getBuildLimit()) {
            if (this.hasMoved
                && this.playerEntity.getDistanceSq(i + 0.5, j + 0.5, k + 0.5) < 64.0
                && !this.serverController.isBlockProtected(worldserver, i, j, k, this.playerEntity)) {
                this.playerEntity
                    .theItemInWorldManager
                    .activateBlockOrUseItem(
                        this.playerEntity,
                        worldserver,
                        itemstack,
                        i,
                        j,
                        k,
                        l,
                        var1.getPlacedBlockOffsetX(),
                        var1.getPlacedBlockOffsetY(),
                        var1.getPlacedBlockOffsetZ()
                    );
            }

            flag = true;
        } else {
            ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation("build.tooHigh", this.serverController.getBuildLimit());
            chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.RED);
            this.playerEntity.playerNetServerHandler.sendPacket(new S02PacketChat(chatcomponenttranslation));
            flag = true;
        }

        if (flag) {
            this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(i, j, k, worldserver));
            if (l == 0) {
                j--;
            }

            if (l == 1) {
                j++;
            }

            if (l == 2) {
                k--;
            }

            if (l == 3) {
                k++;
            }

            if (l == 4) {
                i--;
            }

            if (l == 5) {
                i++;
            }

            this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(i, j, k, worldserver));
        }

        itemstack = this.playerEntity.inventory.getCurrentItem();
        if (itemstack != null && itemstack.stackSize == 0) {
            this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem] = null;
            itemstack = null;
        }

        if (itemstack == null || itemstack.getMaxItemUseDuration() == 0) {
            this.playerEntity.isChangingQuantityOnly = true;
            this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem] = ItemStack.copyItemStack(
                this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem]
            );
            Slot slot = this.playerEntity.openContainer.getSlotFromInventory(this.playerEntity.inventory, this.playerEntity.inventory.currentItem);
            this.playerEntity.openContainer.detectAndSendChanges();
            this.playerEntity.isChangingQuantityOnly = false;
            if (!ItemStack.areItemStacksEqual(this.playerEntity.inventory.getCurrentItem(), var1.getStack())) {
                this.sendPacket(new S2FPacketSetSlot(this.playerEntity.openContainer.windowId, slot.slotNumber, this.playerEntity.inventory.getCurrentItem()));
            }
        }
    }

    @Override
    public void onDisconnect(IChatComponent var1) {
        logger.info(this.playerEntity.getCommandSenderName() + " lost connection: " + var1);
        this.serverController.refreshStatusNextTick();
        ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation(
            "multiplayer.player.left", this.playerEntity.getFormattedCommandSenderName()
        );
        chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.YELLOW);
        this.serverController.getConfigurationManager().sendChatMsg(chatcomponenttranslation);
        this.playerEntity.mountEntityAndWakeUp();
        this.serverController.getConfigurationManager().playerLoggedOut(this.playerEntity);
        if (this.serverController.isSinglePlayer() && this.playerEntity.getCommandSenderName().equals(this.serverController.getServerOwner())) {
            logger.info("Stopping singleplayer server as player logged out");
            this.serverController.initiateShutdown();
        }
    }

    public void sendPacket(final Packet var1) {
        if (var1 instanceof S02PacketChat) {
            S02PacketChat s02packetchat = (S02PacketChat)var1;
            EntityPlayer.EnumChatVisibility entityplayer$enumchatvisibility = this.playerEntity.func_147096_v();
            if (entityplayer$enumchatvisibility == EntityPlayer.EnumChatVisibility.HIDDEN) {
                return;
            }

            if (entityplayer$enumchatvisibility == EntityPlayer.EnumChatVisibility.SYSTEM && !s02packetchat.isChat()) {
                return;
            }
        }

        try {
            this.netManager.scheduleOutboundPacket(var1);
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Sending packet");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Packet being sent");
            crashreportcategory.addCrashSectionCallable("Packet class", new Callable() {
                public String call() {
                    return var1.getClass().getCanonicalName();
                }
            });
            throw new ReportedException(crashreport);
        }
    }

    @Override
    public void processHeldItemChange(C09PacketHeldItemChange var1) {
        if (var1.getSlotId() >= 0 && var1.getSlotId() < InventoryPlayer.getHotbarSize()) {
            this.playerEntity.inventory.currentItem = var1.getSlotId();
            this.playerEntity.markPlayerActive();
        } else {
            logger.warn(this.playerEntity.getCommandSenderName() + " tried to set an invalid carried item");
        }
    }

    @Override
    public void processChatMessage(C01PacketChatMessage var1) {
        if (this.playerEntity.func_147096_v() == EntityPlayer.EnumChatVisibility.HIDDEN) {
            ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation("chat.cannotSend");
            chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.RED);
            this.sendPacket(new S02PacketChat(chatcomponenttranslation));
        } else {
            this.playerEntity.markPlayerActive();
            String s = var1.getMessage();
            s = StringUtils.normalizeSpace(s);

            for (int i = 0; i < s.length(); i++) {
                if (!ChatAllowedCharacters.isAllowedCharacter(s.charAt(i))) {
                    this.kickPlayerFromServer("Illegal characters in chat");
                    return;
                }
            }

            if (s.startsWith("/")) {
                this.handleSlashCommand(s);
            } else {
                ChatComponentTranslation chatcomponenttranslation1 = new ChatComponentTranslation(
                    "chat.type.text", this.playerEntity.getFormattedCommandSenderName(), s
                );
                this.serverController.getConfigurationManager().sendChatMsgImpl(chatcomponenttranslation1, false);
            }

            this.chatSpamThresholdCount += 20;
            if (this.chatSpamThresholdCount > 200 && !this.serverController.getConfigurationManager().func_72353_e(this.playerEntity.getCommandSenderName())) {
                this.kickPlayerFromServer("disconnect.spam");
            }
        }
    }

    private void handleSlashCommand(String var1) {
        this.serverController.getCommandManager().executeCommand(this.playerEntity, var1);
    }

    @Override
    public void processAnimation(C0APacketAnimation var1) {
        this.playerEntity.markPlayerActive();
        if (var1.getType() == 1) {
            this.playerEntity.swingItem();
        }
    }

    @Override
    public void processEntityAction(C0BPacketEntityAction var1) {
        this.playerEntity.markPlayerActive();
        if (var1.func_149513_d() == 1) {
            this.playerEntity.setSneaking(true);
        } else if (var1.func_149513_d() == 2) {
            this.playerEntity.setSneaking(false);
        } else if (var1.func_149513_d() == 4) {
            this.playerEntity.setSprinting(true);
        } else if (var1.func_149513_d() == 5) {
            this.playerEntity.setSprinting(false);
        } else if (var1.func_149513_d() == 3) {
            this.playerEntity.wakeUpPlayer(false, true, true);
            this.hasMoved = false;
        } else if (var1.func_149513_d() == 6) {
            if (this.playerEntity.ridingEntity != null && this.playerEntity.ridingEntity instanceof EntityHorse) {
                ((EntityHorse)this.playerEntity.ridingEntity).setJumpPower(var1.func_149512_e());
            }
        } else if (var1.func_149513_d() == 7 && this.playerEntity.ridingEntity != null && this.playerEntity.ridingEntity instanceof EntityHorse) {
            ((EntityHorse)this.playerEntity.ridingEntity).openGUI(this.playerEntity);
        }
    }

    @Override
    public void processUseEntity(C02PacketUseEntity var1) {
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        Entity entity = var1.getEntityFromWorld(worldserver);
        this.playerEntity.markPlayerActive();
        if (entity != null) {
            boolean flag = this.playerEntity.canEntityBeSeen(entity);
            double d0 = 36.0;
            if (!flag) {
                d0 = 9.0;
            }

            if (this.playerEntity.getDistanceSqToEntity(entity) < d0) {
                if (var1.getAction() == C02PacketUseEntity.Action.INTERACT) {
                    this.playerEntity.interactWith(entity);
                } else if (var1.getAction() == C02PacketUseEntity.Action.ATTACK) {
                    if (entity instanceof EntityItem || entity instanceof EntityXPOrb || entity instanceof EntityArrow || entity == this.playerEntity) {
                        this.kickPlayerFromServer("Attempting to attack an invalid entity");
                        this.serverController.logWarning("Player " + this.playerEntity.getCommandSenderName() + " tried to attack an invalid entity");
                        return;
                    }

                    this.playerEntity.attackTargetEntityWithCurrentItem(entity);
                }
            }
        }
    }

    @Override
    public void processClientStatus(C16PacketClientStatus var1) {
        this.playerEntity.markPlayerActive();
        C16PacketClientStatus.EnumState c16packetclientstatus$enumstate = var1.getStatus();
        switch (c16packetclientstatus$enumstate) {
            case PERFORM_RESPAWN:
                if (this.playerEntity.playerConqueredTheEnd) {
                    this.playerEntity = this.serverController.getConfigurationManager().recreatePlayerEntity(this.playerEntity, 0, true);
                } else if (this.playerEntity.getServerForPlayer().getWorldInfo().isHardcoreModeEnabled()) {
                    if (this.serverController.isSinglePlayer() && this.playerEntity.getCommandSenderName().equals(this.serverController.getServerOwner())) {
                        this.playerEntity.playerNetServerHandler.kickPlayerFromServer("You have died. Game over, man, it's game over!");
                        this.serverController.deleteWorldAndStopServer();
                    } else {
                        BanEntry banentry = new BanEntry(this.playerEntity.getCommandSenderName());
                        banentry.func_73689_b("Death in Hardcore");
                        this.serverController.getConfigurationManager().func_72390_e().func_73706_a(banentry);
                        this.playerEntity.playerNetServerHandler.kickPlayerFromServer("You have died. Game over, man, it's game over!");
                    }
                } else {
                    if (this.playerEntity.getHealth() > 0.0F) {
                        return;
                    }

                    this.playerEntity = this.serverController.getConfigurationManager().recreatePlayerEntity(this.playerEntity, 0, false);
                }
                break;
            case REQUEST_STATS:
                this.playerEntity.getStatFile().func_150876_a(this.playerEntity);
                break;
            case OPEN_INVENTORY_ACHIEVEMENT:
                this.playerEntity.triggerAchievement(AchievementList.openInventory);
        }
    }

    @Override
    public void processCloseWindow(C0DPacketCloseWindow var1) {
        this.playerEntity.closeContainer();
    }

    @Override
    public void processClickWindow(C0EPacketClickWindow var1) {
        this.playerEntity.markPlayerActive();
        if (this.playerEntity.openContainer.windowId == var1.getWindowId() && this.playerEntity.openContainer.getCanCraft(this.playerEntity)) {
            ItemStack itemstack = this.playerEntity.openContainer.slotClick(var1.getSlotId(), var1.getUsedButton(), var1.getMode(), this.playerEntity);
            if (ItemStack.areItemStacksEqual(var1.getClickedItem(), itemstack)) {
                this.playerEntity.playerNetServerHandler.sendPacket(new S32PacketConfirmTransaction(var1.getWindowId(), var1.getActionNumber(), true));
                this.playerEntity.isChangingQuantityOnly = true;
                this.playerEntity.openContainer.detectAndSendChanges();
                this.playerEntity.updateHeldItem();
                this.playerEntity.isChangingQuantityOnly = false;
            } else {
                this.field_147372_n.addKey(this.playerEntity.openContainer.windowId, var1.getActionNumber());
                this.playerEntity.playerNetServerHandler.sendPacket(new S32PacketConfirmTransaction(var1.getWindowId(), var1.getActionNumber(), false));
                this.playerEntity.openContainer.setCanCraft(this.playerEntity, false);
                ArrayList arraylist = new ArrayList();

                for (int i = 0; i < this.playerEntity.openContainer.inventorySlots.size(); i++) {
                    arraylist.add(((Slot)this.playerEntity.openContainer.inventorySlots.get(i)).getStack());
                }

                this.playerEntity.updateCraftingInventory(this.playerEntity.openContainer, arraylist);
            }
        }
    }

    @Override
    public void processEnchantItem(C11PacketEnchantItem var1) {
        this.playerEntity.markPlayerActive();
        if (this.playerEntity.openContainer.windowId == var1.getId() && this.playerEntity.openContainer.getCanCraft(this.playerEntity)) {
            this.playerEntity.openContainer.enchantItem(this.playerEntity, var1.getButton());
            this.playerEntity.openContainer.detectAndSendChanges();
        }
    }

    @Override
    public void processCreativeInventoryAction(C10PacketCreativeInventoryAction var1) {
        if (this.playerEntity.theItemInWorldManager.isCreative()) {
            boolean flag = var1.getSlotId() < 0;
            ItemStack itemstack = var1.getStack();
            boolean flag1 = var1.getSlotId() >= 1 && var1.getSlotId() < 36 + InventoryPlayer.getHotbarSize();
            boolean flag2 = itemstack == null || itemstack.getItem() != null;
            boolean flag3 = itemstack == null || itemstack.getMetadata() >= 0 && itemstack.stackSize <= 64 && itemstack.stackSize > 0;
            if (flag1 && flag2 && flag3) {
                if (itemstack == null) {
                    this.playerEntity.inventoryContainer.putStackInSlot(var1.getSlotId(), null);
                } else {
                    this.playerEntity.inventoryContainer.putStackInSlot(var1.getSlotId(), itemstack);
                }

                this.playerEntity.inventoryContainer.setCanCraft(this.playerEntity, true);
            } else if (flag && flag2 && flag3 && this.itemDropThreshold < 200) {
                this.itemDropThreshold += 20;
                EntityItem entityitem = this.playerEntity.dropPlayerItemWithRandomChoice(itemstack, true);
                if (entityitem != null) {
                    entityitem.setAgeToCreativeDespawnTime();
                }
            }
        }
    }

    @Override
    public void processConfirmTransaction(C0FPacketConfirmTransaction var1) {
        Short oshort = (Short)this.field_147372_n.lookup(this.playerEntity.openContainer.windowId);
        if (oshort != null
            && var1.getUid() == oshort
            && this.playerEntity.openContainer.windowId == var1.getId()
            && !this.playerEntity.openContainer.getCanCraft(this.playerEntity)) {
            this.playerEntity.openContainer.setCanCraft(this.playerEntity, true);
        }
    }

    @Override
    public void processUpdateSign(C12PacketUpdateSign var1) {
        this.playerEntity.markPlayerActive();
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        if (worldserver.blockExists(var1.getX(), var1.getY(), var1.getZ())) {
            TileEntity tileentity = worldserver.getTileEntity(var1.getX(), var1.getY(), var1.getZ());
            if (tileentity instanceof TileEntitySign) {
                TileEntitySign tileentitysign = (TileEntitySign)tileentity;
                if (!tileentitysign.getIsEditable() || tileentitysign.func_145911_b() != this.playerEntity) {
                    this.serverController.logWarning("Player " + this.playerEntity.getCommandSenderName() + " just tried to change non-editable sign");
                    return;
                }
            }

            for (int j = 0; j < 4; j++) {
                boolean flag = true;
                if (var1.getLines()[j].length() > 15) {
                    flag = false;
                } else {
                    for (int i = 0; i < var1.getLines()[j].length(); i++) {
                        if (!ChatAllowedCharacters.isAllowedCharacter(var1.getLines()[j].charAt(i))) {
                            flag = false;
                        }
                    }
                }

                if (!flag) {
                    var1.getLines()[j] = "!?";
                }
            }

            if (tileentity instanceof TileEntitySign) {
                int k = var1.getX();
                int l = var1.getY();
                int i1 = var1.getZ();
                TileEntitySign tileentitysign1 = (TileEntitySign)tileentity;
                System.arraycopy(var1.getLines(), 0, tileentitysign1.signText, 0, 4);
                tileentitysign1.markDirty();
                worldserver.markBlockForUpdate(k, l, i1);
            }
        }
    }

    @Override
    public void processKeepAlive(C00PacketKeepAlive var1) {
        if (var1.getKey() == this.field_147378_h) {
            int i = (int)(this.currentTimeMillis() - this.lastPingTime);
            this.playerEntity.ping = (this.playerEntity.ping * 3 + i) / 4;
        }
    }

    private long currentTimeMillis() {
        return System.nanoTime() / 1000000L;
    }

    @Override
    public void processPlayerAbilities(C13PacketPlayerAbilities var1) {
        this.playerEntity.capabilities.isFlying = var1.isFlying() && this.playerEntity.capabilities.allowFlying;
    }

    @Override
    public void processTabComplete(C14PacketTabComplete var1) {
        ArrayList arraylist = Lists.newArrayList();

        for (String s : (Iterable<String>) (Iterable) this.serverController.getPossibleCompletions(this.playerEntity, var1.getMessage())) {
            arraylist.add(s);
        }

        this.playerEntity.playerNetServerHandler.sendPacket(new S3APacketTabComplete(((String[]) arraylist.toArray(new String[arraylist.size()]))));
    }

    @Override
    public void processClientSettings(C15PacketClientSettings var1) {
        this.playerEntity.func_147100_a(var1);
    }

    @Override
    public void processVanilla250Packet(C17PacketCustomPayload var1) {
        if ("MC|BEdit".equals(var1.getChannel())) {
            try {
                ItemStack itemstack = new PacketBuffer(Unpooled.wrappedBuffer(var1.getData())).readItemStackFromBuffer();
                if (!ItemWritableBook.validBookPageTagContents(itemstack.getTagCompound())) {
                    throw new IOException("Invalid book tag!");
                }

                ItemStack itemstack1 = this.playerEntity.inventory.getCurrentItem();
                if (itemstack.getItem() == Items.writable_book && itemstack.getItem() == itemstack1.getItem()) {
                    itemstack1.setTagInfo("pages", itemstack.getTagCompound().getTagList("pages", 8));
                }
            } catch (Exception exception4) {
                logger.error("Couldn't handle book info", exception4);
            }
        } else if ("MC|BSign".equals(var1.getChannel())) {
            try {
                ItemStack itemstack2 = new PacketBuffer(Unpooled.wrappedBuffer(var1.getData())).readItemStackFromBuffer();
                if (!ItemEditableBook.validBookTagContents(itemstack2.getTagCompound())) {
                    throw new IOException("Invalid book tag!");
                }

                ItemStack itemstack3 = this.playerEntity.inventory.getCurrentItem();
                if (itemstack2.getItem() == Items.written_book && itemstack3.getItem() == Items.writable_book) {
                    itemstack3.setTagInfo("author", new NBTTagString(this.playerEntity.getCommandSenderName()));
                    itemstack3.setTagInfo("title", new NBTTagString(itemstack2.getTagCompound().getString("title")));
                    itemstack3.setTagInfo("pages", itemstack2.getTagCompound().getTagList("pages", 8));
                    itemstack3.setItem(Items.written_book);
                }
            } catch (Exception exception3) {
                logger.error("Couldn't sign book", exception3);
            }
        } else if ("MC|TrSel".equals(var1.getChannel())) {
            try {
                DataInputStream datainputstream = new DataInputStream(new ByteArrayInputStream(var1.getData()));
                int i = datainputstream.readInt();
                Container container = this.playerEntity.openContainer;
                if (container instanceof ContainerMerchant) {
                    ((ContainerMerchant)container).setCurrentRecipeIndex(i);
                }
            } catch (Exception exception2) {
                logger.error("Couldn't select trade", exception2);
            }
        } else if ("MC|AdvCdm".equals(var1.getChannel())) {
            if (!this.serverController.isCommandBlockEnabled()) {
                this.playerEntity.addChatMessage(new ChatComponentTranslation("advMode.notEnabled"));
            } else if (this.playerEntity.canCommandSenderUseCommand(2, "") && this.playerEntity.capabilities.isCreativeMode) {
                try {
                    PacketBuffer packetbuffer = new PacketBuffer(Unpooled.wrappedBuffer(var1.getData()));
                    byte b0 = packetbuffer.readByte();
                    CommandBlockLogic commandblocklogic = null;
                    if (b0 == 0) {
                        TileEntity tileentity = this.playerEntity
                            .worldObj
                            .getTileEntity(packetbuffer.readInt(), packetbuffer.readInt(), packetbuffer.readInt());
                        if (tileentity instanceof TileEntityCommandBlock) {
                            commandblocklogic = ((TileEntityCommandBlock)tileentity).func_145993_a();
                        }
                    } else if (b0 == 1) {
                        Entity entity = this.playerEntity.worldObj.getEntityByID(packetbuffer.readInt());
                        if (entity instanceof EntityMinecartCommandBlock) {
                            commandblocklogic = ((EntityMinecartCommandBlock)entity).func_145822_e();
                        }
                    }

                    String s1 = packetbuffer.readStringFromBuffer(packetbuffer.readableBytes());
                    if (commandblocklogic != null) {
                        commandblocklogic.setCommand(s1);
                        commandblocklogic.func_145756_e();
                        this.playerEntity.addChatMessage(new ChatComponentTranslation("advMode.setCommand.success", s1));
                    }
                } catch (Exception exception1) {
                    logger.error("Couldn't set command block", exception1);
                }
            } else {
                this.playerEntity.addChatMessage(new ChatComponentTranslation("advMode.notAllowed"));
            }
        } else if ("MC|Beacon".equals(var1.getChannel())) {
            if (this.playerEntity.openContainer instanceof ContainerBeacon) {
                try {
                    DataInputStream datainputstream1 = new DataInputStream(new ByteArrayInputStream(var1.getData()));
                    int j = datainputstream1.readInt();
                    int k = datainputstream1.readInt();
                    ContainerBeacon containerbeacon = (ContainerBeacon)this.playerEntity.openContainer;
                    Slot slot = containerbeacon.getSlot(0);
                    if (slot.getHasStack()) {
                        slot.decrStackSize(1);
                        TileEntityBeacon tileentitybeacon = containerbeacon.func_148327_e();
                        tileentitybeacon.setPrimaryEffect(j);
                        tileentitybeacon.setSecondaryEffect(k);
                        tileentitybeacon.markDirty();
                    }
                } catch (Exception exception) {
                    logger.error("Couldn't set beacon", exception);
                }
            }
        } else if ("MC|ItemName".equals(var1.getChannel()) && this.playerEntity.openContainer instanceof ContainerRepair) {
            ContainerRepair containerrepair = (ContainerRepair)this.playerEntity.openContainer;
            if (var1.getData() != null && var1.getData().length >= 1) {
                String s = ChatAllowedCharacters.filterAllowedCharacters(new String(var1.getData(), Charsets.UTF_8));
                if (s.length() <= 30) {
                    containerrepair.updateItemName(s);
                }
            } else {
                containerrepair.updateItemName("");
            }
        }
    }

    @Override
    public void onConnectionStateTransition(EnumConnectionState var1, EnumConnectionState var2) {
        if (var2 != EnumConnectionState.PLAY) {
            throw new IllegalStateException("Unexpected change in protocol!");
        }
    }
}
