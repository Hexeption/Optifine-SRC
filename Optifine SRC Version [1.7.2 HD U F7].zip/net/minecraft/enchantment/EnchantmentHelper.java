package net.minecraft.enchantment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.WeightedRandom;

public class EnchantmentHelper {
    private static final Random enchantmentRand = new Random();
    private static final EnchantmentHelper.ModifierDamage enchantmentModifierDamage = new EnchantmentHelper.ModifierDamage();
    private static final EnchantmentHelper.ModifierLiving enchantmentModifierLiving = new EnchantmentHelper.ModifierLiving();
    private static final EnchantmentHelper.HurtIterator field_151388_d = new EnchantmentHelper.HurtIterator();
    private static final EnchantmentHelper.DamageIterator field_151389_e = new EnchantmentHelper.DamageIterator();

    public static int getEnchantmentLevel(int var0, ItemStack var1) {
        if (var1 == null) {
            return 0;
        }

        NBTTagList nbttaglist = var1.getEnchantmentTagList();
        if (nbttaglist == null) {
            return 0;
        }

        for (int i = 0; i < nbttaglist.tagCount(); i++) {
            short short1 = nbttaglist.getCompoundTagAt(i).getShort("id");
            short short2 = nbttaglist.getCompoundTagAt(i).getShort("lvl");
            if (short1 == var0) {
                return short2;
            }
        }

        return 0;
    }

    public static Map getEnchantments(ItemStack var0) {
        LinkedHashMap linkedhashmap = new LinkedHashMap();
        NBTTagList nbttaglist = var0.getItem() == Items.enchanted_book ? Items.enchanted_book.func_92110_g(var0) : var0.getEnchantmentTagList();
        if (nbttaglist != null) {
            for (int i = 0; i < nbttaglist.tagCount(); i++) {
                short short1 = nbttaglist.getCompoundTagAt(i).getShort("id");
                short short2 = nbttaglist.getCompoundTagAt(i).getShort("lvl");
                linkedhashmap.put(Integer.valueOf(short1), Integer.valueOf(short2));
            }
        }

        return linkedhashmap;
    }

    public static void setEnchantments(Map var0, ItemStack var1) {
        NBTTagList nbttaglist = new NBTTagList();

        for (int i : (Iterable<Integer>) (Iterable) var0.keySet()) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            nbttagcompound.setShort("id", (short)i);
            nbttagcompound.setShort("lvl", (short)((Integer)var0.get(i)).intValue());
            nbttaglist.appendTag(nbttagcompound);
            if (var1.getItem() == Items.enchanted_book) {
                Items.enchanted_book.addEnchantment(var1, new EnchantmentData(i, (Integer)var0.get(i)));
            }
        }

        if (nbttaglist.tagCount() > 0) {
            if (var1.getItem() != Items.enchanted_book) {
                var1.setTagInfo("ench", nbttaglist);
            }
        } else if (var1.hasTagCompound()) {
            var1.getTagCompound().removeTag("ench");
        }
    }

    public static int getMaxEnchantmentLevel(int var0, ItemStack[] var1) {
        if (var1 == null) {
            return 0;
        }

        int i = 0;

        for (ItemStack itemstack : var1) {
            int j = getEnchantmentLevel(var0, itemstack);
            if (j > i) {
                i = j;
            }
        }

        return i;
    }

    private static void applyEnchantmentModifier(EnchantmentHelper.IModifier var0, ItemStack var1) {
        if (var1 != null) {
            NBTTagList nbttaglist = var1.getEnchantmentTagList();
            if (nbttaglist != null) {
                for (int i = 0; i < nbttaglist.tagCount(); i++) {
                    short short1 = nbttaglist.getCompoundTagAt(i).getShort("id");
                    short short2 = nbttaglist.getCompoundTagAt(i).getShort("lvl");
                    if (Enchantment.enchantmentsList[short1] != null) {
                        var0.calculateModifier(Enchantment.enchantmentsList[short1], short2);
                    }
                }
            }
        }
    }

    private static void applyEnchantmentModifierArray(EnchantmentHelper.IModifier var0, ItemStack[] var1) {
        for (ItemStack itemstack : var1) {
            applyEnchantmentModifier(var0, itemstack);
        }
    }

    public static int getEnchantmentModifierDamage(ItemStack[] var0, DamageSource var1) {
        enchantmentModifierDamage.damageModifier = 0;
        enchantmentModifierDamage.source = var1;
        applyEnchantmentModifierArray(enchantmentModifierDamage, var0);
        if (enchantmentModifierDamage.damageModifier > 25) {
            enchantmentModifierDamage.damageModifier = 25;
        }

        return (enchantmentModifierDamage.damageModifier + 1 >> 1) + enchantmentRand.nextInt((enchantmentModifierDamage.damageModifier >> 1) + 1);
    }

    public static float getEnchantmentModifierLiving(EntityLivingBase var0, EntityLivingBase var1) {
        enchantmentModifierLiving.livingModifier = 0.0F;
        enchantmentModifierLiving.entityLiving = var1;
        applyEnchantmentModifier(enchantmentModifierLiving, var0.getHeldItem());
        return enchantmentModifierLiving.livingModifier;
    }

    public static void func_151384_a(EntityLivingBase var0, Entity var1) {
        field_151388_d.field_151363_b = var1;
        field_151388_d.field_151364_a = var0;
        applyEnchantmentModifierArray(field_151388_d, var0.getInventory());
        if (var1 instanceof EntityPlayer) {
            applyEnchantmentModifier(field_151388_d, var0.getHeldItem());
        }
    }

    public static void func_151385_b(EntityLivingBase var0, Entity var1) {
        field_151389_e.field_151366_a = var0;
        field_151389_e.field_151365_b = var1;
        applyEnchantmentModifierArray(field_151389_e, var0.getInventory());
        if (var0 instanceof EntityPlayer) {
            applyEnchantmentModifier(field_151389_e, var0.getHeldItem());
        }
    }

    public static int getKnockbackModifier(EntityLivingBase var0, EntityLivingBase var1) {
        return getEnchantmentLevel(Enchantment.knockback.effectId, var0.getHeldItem());
    }

    public static int getFireAspectModifier(EntityLivingBase var0) {
        return getEnchantmentLevel(Enchantment.fireAspect.effectId, var0.getHeldItem());
    }

    public static int getRespiration(EntityLivingBase var0) {
        return getMaxEnchantmentLevel(Enchantment.respiration.effectId, var0.getInventory());
    }

    public static int getEfficiencyModifier(EntityLivingBase var0) {
        return getEnchantmentLevel(Enchantment.efficiency.effectId, var0.getHeldItem());
    }

    public static boolean getSilkTouchModifier(EntityLivingBase var0) {
        return getEnchantmentLevel(Enchantment.silkTouch.effectId, var0.getHeldItem()) > 0;
    }

    public static int getFortuneModifier(EntityLivingBase var0) {
        return getEnchantmentLevel(Enchantment.fortune.effectId, var0.getHeldItem());
    }

    public static int func_151386_g(EntityLivingBase var0) {
        return getEnchantmentLevel(Enchantment.luckOfTheSea.effectId, var0.getHeldItem());
    }

    public static int func_151387_h(EntityLivingBase var0) {
        return getEnchantmentLevel(Enchantment.lure.effectId, var0.getHeldItem());
    }

    public static int getLootingModifier(EntityLivingBase var0) {
        return getEnchantmentLevel(Enchantment.looting.effectId, var0.getHeldItem());
    }

    public static boolean getAquaAffinityModifier(EntityLivingBase var0) {
        return getMaxEnchantmentLevel(Enchantment.aquaAffinity.effectId, var0.getInventory()) > 0;
    }

    public static ItemStack func_92099_a(Enchantment var0, EntityLivingBase var1) {
        for (ItemStack itemstack : var1.getInventory()) {
            if (itemstack != null && getEnchantmentLevel(var0.effectId, itemstack) > 0) {
                return itemstack;
            }
        }

        return null;
    }

    public static int calcItemStackEnchantability(Random var0, int var1, int var2, ItemStack var3) {
        Item item = var3.getItem();
        int i = item.getItemEnchantability();
        if (i <= 0) {
            return 0;
        }

        if (var2 > 15) {
            var2 = 15;
        }

        int j = var0.nextInt(8) + 1 + (var2 >> 1) + var0.nextInt(var2 + 1);
        if (var1 == 0) {
            return Math.max(j / 3, 1);
        } else {
            return var1 == 1 ? j * 2 / 3 + 1 : Math.max(j, var2 * 2);
        }
    }

    public static ItemStack addRandomEnchantment(Random var0, ItemStack var1, int var2) {
        List list = buildEnchantmentList(var0, var1, var2);
        boolean flag = var1.getItem() == Items.book;
        if (flag) {
            var1.setItem(Items.enchanted_book);
        }

        if (list != null) {
            for (EnchantmentData enchantmentdata : (Iterable<EnchantmentData>) (Iterable) list) {
                if (flag) {
                    Items.enchanted_book.addEnchantment(var1, enchantmentdata);
                } else {
                    var1.addEnchantment(enchantmentdata.enchantmentobj, enchantmentdata.enchantmentLevel);
                }
            }
        }

        return var1;
    }

    public static List buildEnchantmentList(Random var0, ItemStack var1, int var2) {
        Item item = var1.getItem();
        int i = item.getItemEnchantability();
        if (i <= 0) {
            return null;
        }

        i /= 2;
        i = 1 + var0.nextInt((i >> 1) + 1) + var0.nextInt((i >> 1) + 1);
        int j = i + var2;
        float f = (var0.nextFloat() + var0.nextFloat() - 1.0F) * 0.15F;
        int k = (int)(j * (1.0F + f) + 0.5F);
        if (k < 1) {
            k = 1;
        }

        ArrayList arraylist = null;
        Map map = mapEnchantmentData(k, var1);
        if (map != null && !map.isEmpty()) {
            EnchantmentData enchantmentdata = (EnchantmentData)WeightedRandom.getRandomItem(var0, map.values());
            if (enchantmentdata != null) {
                arraylist = new ArrayList();
                arraylist.add(enchantmentdata);

                for (int l = k; var0.nextInt(50) <= l; l >>= 1) {
                    Iterator iterator = map.keySet().iterator();

                    while (iterator.hasNext()) {
                        Integer integer = (Integer)iterator.next();
                        boolean flag = true;

                        for (EnchantmentData enchantmentdata1 : (Iterable<EnchantmentData>) (Iterable) arraylist) {
                            if (!enchantmentdata1.enchantmentobj.canApplyTogether(Enchantment.enchantmentsList[integer])) {
                                flag = false;
                                break;
                            }
                        }

                        if (!flag) {
                            iterator.remove();
                        }
                    }

                    if (!map.isEmpty()) {
                        EnchantmentData enchantmentdata2 = (EnchantmentData)WeightedRandom.getRandomItem(var0, map.values());
                        arraylist.add(enchantmentdata2);
                    }
                }
            }
        }

        return arraylist;
    }

    public static Map mapEnchantmentData(int var0, ItemStack var1) {
        Item item = var1.getItem();
        HashMap hashmap = null;
        boolean flag = var1.getItem() == Items.book;

        for (Enchantment enchantment : Enchantment.enchantmentsList) {
            if (enchantment != null && (enchantment.type.canEnchantItem(item) || flag)) {
                for (int i = enchantment.getMinLevel(); i <= enchantment.getMaxLevel(); i++) {
                    if (var0 >= enchantment.getMinEnchantability(i) && var0 <= enchantment.getMaxEnchantability(i)) {
                        if (hashmap == null) {
                            hashmap = new HashMap();
                        }

                        hashmap.put(enchantment.effectId, new EnchantmentData(enchantment, i));
                    }
                }
            }
        }

        return hashmap;
    }

    static final class DamageIterator implements EnchantmentHelper.IModifier {
        public EntityLivingBase field_151366_a;
        public Entity field_151365_b;

        private DamageIterator() {
        }

        @Override
        public void calculateModifier(Enchantment var1, int var2) {
            var1.func_151368_a(this.field_151366_a, this.field_151365_b, var2);
        }
    }

    static final class HurtIterator implements EnchantmentHelper.IModifier {
        public EntityLivingBase field_151364_a;
        public Entity field_151363_b;

        private HurtIterator() {
        }

        @Override
        public void calculateModifier(Enchantment var1, int var2) {
            var1.func_151367_b(this.field_151364_a, this.field_151363_b, var2);
        }
    }

    interface IModifier {
        void calculateModifier(Enchantment var1, int var2);
    }

    static final class ModifierDamage implements EnchantmentHelper.IModifier {
        public int damageModifier;
        public DamageSource source;

        private ModifierDamage() {
        }

        @Override
        public void calculateModifier(Enchantment var1, int var2) {
            this.damageModifier = this.damageModifier + var1.calcModifierDamage(var2, this.source);
        }
    }

    static final class ModifierLiving implements EnchantmentHelper.IModifier {
        public float livingModifier;
        public EntityLivingBase entityLiving;

        private ModifierLiving() {
        }

        @Override
        public void calculateModifier(Enchantment var1, int var2) {
            this.livingModifier = this.livingModifier + var1.func_77323_a(var2, this.entityLiving);
        }
    }
}
