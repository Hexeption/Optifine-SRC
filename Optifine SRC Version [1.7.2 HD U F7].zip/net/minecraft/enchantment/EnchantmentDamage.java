package net.minecraft.enchantment;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class EnchantmentDamage extends Enchantment {
    private static final String[] protectionName = new String[]{"all", "undead", "arthropods"};
    private static final int[] baseEnchantability = new int[]{1, 5, 5};
    private static final int[] levelEnchantability = new int[]{11, 8, 8};
    private static final int[] thresholdEnchantability = new int[]{20, 20, 20};
    public final int damageType;

    public EnchantmentDamage(int var1, int var2, int var3) {
        super(var1, var2, EnumEnchantmentType.weapon);
        this.damageType = var3;
    }

    @Override
    public int getMinEnchantability(int var1) {
        return baseEnchantability[this.damageType] + (var1 - 1) * levelEnchantability[this.damageType];
    }

    @Override
    public int getMaxEnchantability(int var1) {
        return this.getMinEnchantability(var1) + thresholdEnchantability[this.damageType];
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public float func_77323_a(int var1, EntityLivingBase var2) {
        if (this.damageType == 0) {
            return var1 * 1.25F;
        } else if (this.damageType == 1 && var2.getCreatureAttribute() == EnumCreatureAttribute.UNDEAD) {
            return var1 * 2.5F;
        } else {
            return this.damageType == 2 && var2.getCreatureAttribute() == EnumCreatureAttribute.ARTHROPOD ? var1 * 2.5F : 0.0F;
        }
    }

    @Override
    public String getName() {
        return "enchantment.damage." + protectionName[this.damageType];
    }

    @Override
    public boolean canApplyTogether(Enchantment var1) {
        return !(var1 instanceof EnchantmentDamage);
    }

    @Override
    public boolean canApply(ItemStack var1) {
        return var1.getItem() instanceof ItemAxe ? true : super.canApply(var1);
    }

    @Override
    public void func_151368_a(EntityLivingBase var1, Entity var2, int var3) {
        if (var2 instanceof EntityLivingBase) {
            EntityLivingBase entitylivingbase = (EntityLivingBase)var2;
            if (this.damageType == 2 && entitylivingbase.getCreatureAttribute() == EnumCreatureAttribute.ARTHROPOD) {
                int i = 20 + var1.getRNG().nextInt(10 * var3);
                entitylivingbase.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, i, 3));
            }
        }
    }
}
