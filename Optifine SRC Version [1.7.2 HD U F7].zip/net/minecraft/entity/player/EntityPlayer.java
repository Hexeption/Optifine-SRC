package net.minecraft.entity.player;

import com.google.common.base.Charsets;
import com.mojang.authlib.GameProfile;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.material.Material;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityMinecartHopper;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.event.ClickEvent;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryEnderChest;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.scoreboard.IScoreObjectiveCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.tileentity.TileEntityBrewingStand;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.FoodStats;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Util;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.chunk.IChunkProvider;

public abstract class EntityPlayer extends EntityLivingBase implements ICommandSender {
    public InventoryPlayer inventory = new InventoryPlayer(this);
    private InventoryEnderChest theInventoryEnderChest = new InventoryEnderChest();
    public Container inventoryContainer;
    public Container openContainer;
    protected FoodStats foodStats = new FoodStats();
    protected int flyToggleTimer;
    public float prevCameraYaw;
    public float cameraYaw;
    public int xpCooldown;
    public double field_71091_bM;
    public double field_71096_bN;
    public double field_71097_bO;
    public double field_71094_bP;
    public double field_71095_bQ;
    public double field_71085_bR;
    protected boolean sleeping;
    public ChunkCoordinates playerLocation;
    private int sleepTimer;
    public float field_71079_bU;
    public float field_71082_cx;
    public float field_71089_bV;
    private ChunkCoordinates spawnChunk;
    private boolean spawnForced;
    private ChunkCoordinates startMinecartRidingCoordinate;
    public PlayerCapabilities capabilities = new PlayerCapabilities();
    public int experienceLevel;
    public int experienceTotal;
    public float experience;
    private ItemStack itemInUse;
    private int itemInUseCount;
    protected float speedOnGround = 0.1F;
    protected float speedInAir = 0.02F;
    private int field_82249_h;
    private final GameProfile gameProfile;
    public EntityFishHook fishEntity;

    public EntityPlayer(World var1, GameProfile var2) {
        super(var1);
        this.entityUniqueID = getUUID(var2);
        this.gameProfile = var2;
        this.inventoryContainer = new ContainerPlayer(this.inventory, !var1.isRemote, this);
        this.openContainer = this.inventoryContainer;
        this.yOffset = 1.62F;
        ChunkCoordinates chunkcoordinates = var1.getSpawnPoint();
        this.setLocationAndAngles(chunkcoordinates.posX + 0.5, chunkcoordinates.posY + 1, chunkcoordinates.posZ + 0.5, 0.0F, 0.0F);
        this.field_70741_aB = 180.0F;
        this.fireResistance = 20;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, (byte)0);
        this.dataWatcher.addObject(17, 0.0F);
        this.dataWatcher.addObject(18, 0);
    }

    public ItemStack getItemInUse() {
        return this.itemInUse;
    }

    public int getItemInUseCount() {
        return this.itemInUseCount;
    }

    public boolean isUsingItem() {
        return this.itemInUse != null;
    }

    public int getItemInUseDuration() {
        return this.isUsingItem() ? this.itemInUse.getMaxItemUseDuration() - this.itemInUseCount : 0;
    }

    public void stopUsingItem() {
        if (this.itemInUse != null) {
            this.itemInUse.onPlayerStoppedUsing(this.worldObj, this, this.itemInUseCount);
        }

        this.clearItemInUse();
    }

    public void clearItemInUse() {
        this.itemInUse = null;
        this.itemInUseCount = 0;
        if (!this.worldObj.isRemote) {
            this.setEating(false);
        }
    }

    public boolean isBlocking() {
        return this.isUsingItem() && this.itemInUse.getItem().getItemUseAction(this.itemInUse) == EnumAction.block;
    }

    @Override
    public void onUpdate() {
        if (this.itemInUse != null) {
            ItemStack itemstack = this.inventory.getCurrentItem();
            if (itemstack == this.itemInUse) {
                if (this.itemInUseCount <= 25 && this.itemInUseCount % 4 == 0) {
                    this.updateItemUse(itemstack, 5);
                }

                if (--this.itemInUseCount == 0 && !this.worldObj.isRemote) {
                    this.onItemUseFinish();
                }
            } else {
                this.clearItemInUse();
            }
        }

        if (this.xpCooldown > 0) {
            this.xpCooldown--;
        }

        if (this.isPlayerSleeping()) {
            this.sleepTimer++;
            if (this.sleepTimer > 100) {
                this.sleepTimer = 100;
            }

            if (!this.worldObj.isRemote) {
                if (!this.isInBed()) {
                    this.wakeUpPlayer(true, true, false);
                } else if (this.worldObj.isDaytime()) {
                    this.wakeUpPlayer(false, true, true);
                }
            }
        } else if (this.sleepTimer > 0) {
            this.sleepTimer++;
            if (this.sleepTimer >= 110) {
                this.sleepTimer = 0;
            }
        }

        super.onUpdate();
        if (!this.worldObj.isRemote && this.openContainer != null && !this.openContainer.canInteractWith(this)) {
            this.closeScreen();
            this.openContainer = this.inventoryContainer;
        }

        if (this.isBurning() && this.capabilities.disableDamage) {
            this.extinguish();
        }

        this.field_71091_bM = this.field_71094_bP;
        this.field_71096_bN = this.field_71095_bQ;
        this.field_71097_bO = this.field_71085_bR;
        double d3 = this.posX - this.field_71094_bP;
        double d0 = this.posY - this.field_71095_bQ;
        double d1 = this.posZ - this.field_71085_bR;
        double d2 = 10.0;
        if (d3 > d2) {
            this.field_71091_bM = this.field_71094_bP = this.posX;
        }

        if (d1 > d2) {
            this.field_71097_bO = this.field_71085_bR = this.posZ;
        }

        if (d0 > d2) {
            this.field_71096_bN = this.field_71095_bQ = this.posY;
        }

        if (d3 < -d2) {
            this.field_71091_bM = this.field_71094_bP = this.posX;
        }

        if (d1 < -d2) {
            this.field_71097_bO = this.field_71085_bR = this.posZ;
        }

        if (d0 < -d2) {
            this.field_71096_bN = this.field_71095_bQ = this.posY;
        }

        this.field_71094_bP += d3 * 0.25;
        this.field_71085_bR += d1 * 0.25;
        this.field_71095_bQ += d0 * 0.25;
        if (this.ridingEntity == null) {
            this.startMinecartRidingCoordinate = null;
        }

        if (!this.worldObj.isRemote) {
            this.foodStats.onUpdate(this);
            this.addStat(StatList.minutesPlayedStat, 1);
        }
    }

    @Override
    public int getMaxInPortalTime() {
        return this.capabilities.disableDamage ? 0 : 80;
    }

    @Override
    protected String getSwimSound() {
        return "game.player.swim";
    }

    @Override
    protected String getSplashSound() {
        return "game.player.swim.splash";
    }

    @Override
    public int getPortalCooldown() {
        return 10;
    }

    @Override
    public void playSound(String var1, float var2, float var3) {
        this.worldObj.playSoundToNearExcept(this, var1, var2, var3);
    }

    protected void updateItemUse(ItemStack var1, int var2) {
        if (var1.getItemUseAction() == EnumAction.drink) {
            this.playSound("random.drink", 0.5F, this.worldObj.rand.nextFloat() * 0.1F + 0.9F);
        }

        if (var1.getItemUseAction() == EnumAction.eat) {
            for (int i = 0; i < var2; i++) {
                Vec3 vec3 = this.worldObj.func_82732_R().func_72345_a((this.rand.nextFloat() - 0.5) * 0.1, Math.random() * 0.1 + 0.1, 0.0);
                vec3.rotateAroundX(-this.rotationPitch * (float)Math.PI / 180.0F);
                vec3.rotateAroundY(-this.rotationYaw * (float)Math.PI / 180.0F);
                Vec3 vec31 = this.worldObj.func_82732_R().func_72345_a((this.rand.nextFloat() - 0.5) * 0.3, -this.rand.nextFloat() * 0.6 - 0.3, 0.6);
                vec31.rotateAroundX(-this.rotationPitch * (float)Math.PI / 180.0F);
                vec31.rotateAroundY(-this.rotationYaw * (float)Math.PI / 180.0F);
                vec31 = vec31.addVector(this.posX, this.posY + this.getEyeHeight(), this.posZ);
                String s = "iconcrack_" + Item.getIdFromItem(var1.getItem());
                if (var1.getHasSubtypes()) {
                    s = s + "_" + var1.getMetadata();
                }

                this.worldObj.spawnParticle(s, vec31.xCoord, vec31.yCoord, vec31.zCoord, vec3.xCoord, vec3.yCoord + 0.05, vec3.zCoord);
            }

            this.playSound("random.eat", 0.5F + 0.5F * this.rand.nextInt(2), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
        }
    }

    protected void onItemUseFinish() {
        if (this.itemInUse != null) {
            this.updateItemUse(this.itemInUse, 16);
            int i = this.itemInUse.stackSize;
            ItemStack itemstack = this.itemInUse.onItemUseFinish(this.worldObj, this);
            if (itemstack != this.itemInUse || itemstack != null && itemstack.stackSize != i) {
                this.inventory.mainInventory[this.inventory.currentItem] = itemstack;
                if (itemstack.stackSize == 0) {
                    this.inventory.mainInventory[this.inventory.currentItem] = null;
                }
            }

            this.clearItemInUse();
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 9) {
            this.onItemUseFinish();
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    @Override
    protected boolean isMovementBlocked() {
        return this.getHealth() <= 0.0F || this.isPlayerSleeping();
    }

    protected void closeScreen() {
        this.openContainer = this.inventoryContainer;
    }

    @Override
    public void mountEntity(Entity var1) {
        if (this.ridingEntity != null && var1 == null) {
            if (!this.worldObj.isRemote) {
                this.dismountEntity(this.ridingEntity);
            }

            if (this.ridingEntity != null) {
                this.ridingEntity.riddenByEntity = null;
            }

            this.ridingEntity = null;
        } else {
            super.mountEntity(var1);
        }
    }

    @Override
    public void updateRidden() {
        if (!this.worldObj.isRemote && this.isSneaking()) {
            this.mountEntity(null);
            this.setSneaking(false);
        } else {
            double d0 = this.posX;
            double d1 = this.posY;
            double d2 = this.posZ;
            float f = this.rotationYaw;
            float f1 = this.rotationPitch;
            super.updateRidden();
            this.prevCameraYaw = this.cameraYaw;
            this.cameraYaw = 0.0F;
            this.addMountedMovementStat(this.posX - d0, this.posY - d1, this.posZ - d2);
            if (this.ridingEntity instanceof EntityPig) {
                this.rotationPitch = f1;
                this.rotationYaw = f;
                this.renderYawOffset = ((EntityPig)this.ridingEntity).renderYawOffset;
            }
        }
    }

    @Override
    public void preparePlayerToSpawn() {
        this.yOffset = 1.62F;
        this.setSize(0.6F, 1.8F);
        super.preparePlayerToSpawn();
        this.setHealth(this.getMaxHealth());
        this.deathTime = 0;
    }

    @Override
    protected void updateEntityActionState() {
        super.updateEntityActionState();
        this.updateArmSwingProgress();
    }

    @Override
    public void onLivingUpdate() {
        if (this.flyToggleTimer > 0) {
            this.flyToggleTimer--;
        }

        if (this.worldObj.difficultySetting == EnumDifficulty.PEACEFUL
            && this.getHealth() < this.getMaxHealth()
            && this.worldObj.getGameRules().getGameRuleBooleanValue("naturalRegeneration")
            && this.ticksExisted % 20 * 12 == 0) {
            this.heal(1.0F);
        }

        this.inventory.decrementAnimations();
        this.prevCameraYaw = this.cameraYaw;
        super.onLivingUpdate();
        IAttributeInstance iattributeinstance = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
        if (!this.worldObj.isRemote) {
            iattributeinstance.setBaseValue(this.capabilities.getWalkSpeed());
        }

        this.jumpMovementFactor = this.speedInAir;
        if (this.isSprinting()) {
            this.jumpMovementFactor = (float)(this.jumpMovementFactor + this.speedInAir * 0.3);
        }

        this.setAIMoveSpeed((float)iattributeinstance.getAttributeValue());
        float f = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        float f1 = (float)Math.atan(-this.motionY * 0.2F) * 15.0F;
        if (f > 0.1F) {
            f = 0.1F;
        }

        if (!this.onGround || this.getHealth() <= 0.0F) {
            f = 0.0F;
        }

        if (this.onGround || this.getHealth() <= 0.0F) {
            f1 = 0.0F;
        }

        this.cameraYaw = this.cameraYaw + (f - this.cameraYaw) * 0.4F;
        this.cameraPitch = this.cameraPitch + (f1 - this.cameraPitch) * 0.8F;
        if (this.getHealth() > 0.0F) {
            AxisAlignedBB axisalignedbb = null;
            if (this.ridingEntity != null && !this.ridingEntity.isDead) {
                axisalignedbb = this.boundingBox.union(this.ridingEntity.boundingBox).expand(1.0, 0.0, 1.0);
            } else {
                axisalignedbb = this.boundingBox.expand(1.0, 0.5, 1.0);
            }

            List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, axisalignedbb);
            if (list != null) {
                for (int i = 0; i < list.size(); i++) {
                    Entity entity = (Entity)list.get(i);
                    if (!entity.isDead) {
                        this.collideWithPlayer(entity);
                    }
                }
            }
        }
    }

    private void collideWithPlayer(Entity var1) {
        var1.onCollideWithPlayer(this);
    }

    public int getScore() {
        return this.dataWatcher.getWatchableObjectInt(18);
    }

    public void setScore(int var1) {
        this.dataWatcher.updateObject(18, var1);
    }

    public void addScore(int var1) {
        int i = this.getScore();
        this.dataWatcher.updateObject(18, i + var1);
    }

    @Override
    public void onDeath(DamageSource var1) {
        super.onDeath(var1);
        this.setSize(0.2F, 0.2F);
        this.setPosition(this.posX, this.posY, this.posZ);
        this.motionY = 0.1F;
        if (this.getCommandSenderName().equals("Notch")) {
            this.func_146097_a(new ItemStack(Items.apple, 1), true, false);
        }

        if (!this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            this.inventory.dropAllItems();
        }

        if (var1 != null) {
            this.motionX = -MathHelper.cos((this.attackedAtYaw + this.rotationYaw) * (float)Math.PI / 180.0F) * 0.1F;
            this.motionZ = -MathHelper.sin((this.attackedAtYaw + this.rotationYaw) * (float)Math.PI / 180.0F) * 0.1F;
        } else {
            this.motionX = this.motionZ = 0.0;
        }

        this.yOffset = 0.1F;
        this.addStat(StatList.deathsStat, 1);
    }

    @Override
    protected String getHurtSound() {
        return "game.player.hurt";
    }

    @Override
    protected String getDeathSound() {
        return "game.player.die";
    }

    @Override
    public void addToPlayerScore(Entity var1, int var2) {
        this.addScore(var2);
        Collection collection = this.getWorldScoreboard().func_96520_a(IScoreObjectiveCriteria.totalKillCount);
        if (var1 instanceof EntityPlayer) {
            this.addStat(StatList.playerKillsStat, 1);
            collection.addAll(this.getWorldScoreboard().func_96520_a(IScoreObjectiveCriteria.playerKillCount));
        } else {
            this.addStat(StatList.mobKillsStat, 1);
        }

        for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) collection) {
            Score score = this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective);
            score.func_96648_a();
        }
    }

    public EntityItem dropOneItem(boolean var1) {
        return this.func_146097_a(
            this.inventory
                .decrStackSize(this.inventory.currentItem, var1 && this.inventory.getCurrentItem() != null ? this.inventory.getCurrentItem().stackSize : 1),
            false,
            true
        );
    }

    public EntityItem dropPlayerItemWithRandomChoice(ItemStack var1, boolean var2) {
        return this.func_146097_a(var1, false, false);
    }

    public EntityItem func_146097_a(ItemStack var1, boolean var2, boolean var3) {
        if (var1 == null) {
            return null;
        }

        if (var1.stackSize == 0) {
            return null;
        }

        EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY - 0.3F + this.getEyeHeight(), this.posZ, var1);
        entityitem.delayBeforeCanPickup = 40;
        if (var3) {
            entityitem.setThrower(this.getCommandSenderName());
        }

        float f = 0.1F;
        if (var2) {
            float f1 = this.rand.nextFloat() * 0.5F;
            float f2 = this.rand.nextFloat() * (float)Math.PI * 2.0F;
            entityitem.motionX = -MathHelper.sin(f2) * f1;
            entityitem.motionZ = MathHelper.cos(f2) * f1;
            entityitem.motionY = 0.2F;
        } else {
            f = 0.3F;
            entityitem.motionX = -MathHelper.sin(this.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.rotationPitch / 180.0F * (float)Math.PI) * f;
            entityitem.motionZ = MathHelper.cos(this.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.rotationPitch / 180.0F * (float)Math.PI) * f;
            entityitem.motionY = -MathHelper.sin(this.rotationPitch / 180.0F * (float)Math.PI) * f + 0.1F;
            f = 0.02F;
            float f3 = this.rand.nextFloat() * (float)Math.PI * 2.0F;
            f *= this.rand.nextFloat();
            entityitem.motionX = entityitem.motionX + Math.cos(f3) * f;
            entityitem.motionY = entityitem.motionY + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F;
            entityitem.motionZ = entityitem.motionZ + Math.sin(f3) * f;
        }

        this.joinEntityItemWithWorld(entityitem);
        this.addStat(StatList.dropStat, 1);
        return entityitem;
    }

    protected void joinEntityItemWithWorld(EntityItem var1) {
        this.worldObj.spawnEntityInWorld(var1);
    }

    public float getBreakSpeed(Block var1, boolean var2) {
        float f = this.inventory.getStrVsBlock(var1);
        if (f > 1.0F) {
            int i = EnchantmentHelper.getEfficiencyModifier(this);
            ItemStack itemstack = this.inventory.getCurrentItem();
            if (i > 0 && itemstack != null) {
                float f1 = i * i + 1;
                if (!itemstack.canItemHarvestBlock(var1) && !(f > 1.0F)) {
                    f += f1 * 0.08F;
                } else {
                    f += f1;
                }
            }
        }

        if (this.isPotionActive(Potion.digSpeed)) {
            f *= 1.0F + (this.getActivePotionEffect(Potion.digSpeed).getAmplifier() + 1) * 0.2F;
        }

        if (this.isPotionActive(Potion.digSlowdown)) {
            f *= 1.0F - (this.getActivePotionEffect(Potion.digSlowdown).getAmplifier() + 1) * 0.2F;
        }

        if (this.isInsideOfMaterial(Material.water) && !EnchantmentHelper.getAquaAffinityModifier(this)) {
            f /= 5.0F;
        }

        if (!this.onGround) {
            f /= 5.0F;
        }

        return f;
    }

    public boolean canHarvestBlock(Block var1) {
        return this.inventory.func_146025_b(var1);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.entityUniqueID = getUUID(this.gameProfile);
        NBTTagList nbttaglist = var1.getTagList("Inventory", 10);
        this.inventory.readFromNBT(nbttaglist);
        this.inventory.currentItem = var1.getInteger("SelectedItemSlot");
        this.sleeping = var1.getBoolean("Sleeping");
        this.sleepTimer = var1.getShort("SleepTimer");
        this.experience = var1.getFloat("XpP");
        this.experienceLevel = var1.getInteger("XpLevel");
        this.experienceTotal = var1.getInteger("XpTotal");
        this.setScore(var1.getInteger("Score"));
        if (this.sleeping) {
            this.playerLocation = new ChunkCoordinates(
                MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)
            );
            this.wakeUpPlayer(true, true, false);
        }

        if (var1.hasKey("SpawnX", 99) && var1.hasKey("SpawnY", 99) && var1.hasKey("SpawnZ", 99)) {
            this.spawnChunk = new ChunkCoordinates(var1.getInteger("SpawnX"), var1.getInteger("SpawnY"), var1.getInteger("SpawnZ"));
            this.spawnForced = var1.getBoolean("SpawnForced");
        }

        this.foodStats.readNBT(var1);
        this.capabilities.readCapabilitiesFromNBT(var1);
        if (var1.hasKey("EnderItems", 9)) {
            NBTTagList nbttaglist1 = var1.getTagList("EnderItems", 10);
            this.theInventoryEnderChest.loadInventoryFromNBT(nbttaglist1);
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setTag("Inventory", this.inventory.writeToNBT(new NBTTagList()));
        var1.setInteger("SelectedItemSlot", this.inventory.currentItem);
        var1.setBoolean("Sleeping", this.sleeping);
        var1.setShort("SleepTimer", (short)this.sleepTimer);
        var1.setFloat("XpP", this.experience);
        var1.setInteger("XpLevel", this.experienceLevel);
        var1.setInteger("XpTotal", this.experienceTotal);
        var1.setInteger("Score", this.getScore());
        if (this.spawnChunk != null) {
            var1.setInteger("SpawnX", this.spawnChunk.posX);
            var1.setInteger("SpawnY", this.spawnChunk.posY);
            var1.setInteger("SpawnZ", this.spawnChunk.posZ);
            var1.setBoolean("SpawnForced", this.spawnForced);
        }

        this.foodStats.writeNBT(var1);
        this.capabilities.writeCapabilitiesToNBT(var1);
        var1.setTag("EnderItems", this.theInventoryEnderChest.saveInventoryToNBT());
    }

    public void displayGUIChest(IInventory var1) {
    }

    public void func_146093_a(TileEntityHopper var1) {
    }

    public void displayGUIHopperMinecart(EntityMinecartHopper var1) {
    }

    public void displayGUIHorse(EntityHorse var1, IInventory var2) {
    }

    public void displayGUIEnchantment(int var1, int var2, int var3, String var4) {
    }

    public void displayGUIAnvil(int var1, int var2, int var3) {
    }

    public void displayGUIWorkbench(int var1, int var2, int var3) {
    }

    @Override
    public float getEyeHeight() {
        return 0.12F;
    }

    protected void resetHeight() {
        this.yOffset = 1.62F;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        if (this.capabilities.disableDamage && !var1.canHarmInCreative()) {
            return false;
        }

        this.entityAge = 0;
        if (this.getHealth() <= 0.0F) {
            return false;
        }

        if (this.isPlayerSleeping() && !this.worldObj.isRemote) {
            this.wakeUpPlayer(true, true, false);
        }

        if (var1.isDifficultyScaled()) {
            if (this.worldObj.difficultySetting == EnumDifficulty.PEACEFUL) {
                var2 = 0.0F;
            }

            if (this.worldObj.difficultySetting == EnumDifficulty.EASY) {
                var2 = var2 / 2.0F + 1.0F;
            }

            if (this.worldObj.difficultySetting == EnumDifficulty.HARD) {
                var2 = var2 * 3.0F / 2.0F;
            }
        }

        if (var2 == 0.0F) {
            return false;
        }

        Entity entity = var1.getEntity();
        if (entity instanceof EntityArrow && ((EntityArrow)entity).shootingEntity != null) {
            entity = ((EntityArrow)entity).shootingEntity;
        }

        this.addStat(StatList.damageTakenStat, Math.round(var2 * 10.0F));
        return super.attackEntityFrom(var1, var2);
    }

    public boolean canAttackPlayer(EntityPlayer var1) {
        Team team = this.getTeam();
        Team team1 = var1.getTeam();
        if (team == null) {
            return true;
        } else {
            return !team.isSameTeam(team1) ? true : team.getAllowFriendlyFire();
        }
    }

    @Override
    protected void damageArmor(float var1) {
        this.inventory.damageArmor(var1);
    }

    @Override
    public int getTotalArmorValue() {
        return this.inventory.getTotalArmorValue();
    }

    public float getArmorVisibility() {
        int i = 0;

        for (ItemStack itemstack : this.inventory.armorInventory) {
            if (itemstack != null) {
                i++;
            }
        }

        return (float)i / this.inventory.armorInventory.length;
    }

    @Override
    protected void damageEntity(DamageSource var1, float var2) {
        if (!this.isEntityInvulnerable()) {
            if (!var1.isUnblockable() && this.isBlocking() && var2 > 0.0F) {
                var2 = (1.0F + var2) * 0.5F;
            }

            var2 = this.applyArmorCalculations(var1, var2);
            var2 = this.applyPotionDamageCalculations(var1, var2);
            float f = var2;
            var2 = Math.max(var2 - this.getAbsorptionAmount(), 0.0F);
            this.setAbsorptionAmount(this.getAbsorptionAmount() - (f - var2));
            if (var2 != 0.0F) {
                this.addExhaustion(var1.getHungerDamage());
                float f1 = this.getHealth();
                this.setHealth(this.getHealth() - var2);
                this.getCombatTracker().func_94547_a(var1, f1, var2);
            }
        }
    }

    public void func_146101_a(TileEntityFurnace var1) {
    }

    public void func_146102_a(TileEntityDispenser var1) {
    }

    public void displayGUIEditSign(TileEntity var1) {
    }

    public void func_146095_a(CommandBlockLogic var1) {
    }

    public void func_146098_a(TileEntityBrewingStand var1) {
    }

    public void func_146104_a(TileEntityBeacon var1) {
    }

    public void displayGUIMerchant(IMerchant var1, String var2) {
    }

    public void displayGUIBook(ItemStack var1) {
    }

    public boolean interactWith(Entity var1) {
        ItemStack itemstack = this.getCurrentEquippedItem();
        ItemStack itemstack1 = itemstack != null ? itemstack.copy() : null;
        if (!var1.interactFirst(this)) {
            if (itemstack != null && var1 instanceof EntityLivingBase) {
                if (this.capabilities.isCreativeMode) {
                    itemstack = itemstack1;
                }

                if (itemstack.interactWithEntity(this, (EntityLivingBase)var1)) {
                    if (itemstack.stackSize <= 0 && !this.capabilities.isCreativeMode) {
                        this.destroyCurrentEquippedItem();
                    }

                    return true;
                }
            }

            return false;
        } else {
            if (itemstack != null && itemstack == this.getCurrentEquippedItem()) {
                if (itemstack.stackSize <= 0 && !this.capabilities.isCreativeMode) {
                    this.destroyCurrentEquippedItem();
                } else if (itemstack.stackSize < itemstack1.stackSize && this.capabilities.isCreativeMode) {
                    itemstack.stackSize = itemstack1.stackSize;
                }
            }

            return true;
        }
    }

    public ItemStack getCurrentEquippedItem() {
        return this.inventory.getCurrentItem();
    }

    public void destroyCurrentEquippedItem() {
        this.inventory.setInventorySlotContents(this.inventory.currentItem, null);
    }

    @Override
    public double getYOffset() {
        return this.yOffset - 0.5F;
    }

    public void attackTargetEntityWithCurrentItem(Entity var1) {
        if (var1.canAttackWithItem()) {
            if (!var1.hitByEntity(this)) {
                float f = (float)this.getEntityAttribute(SharedMonsterAttributes.attackDamage).getAttributeValue();
                int i = 0;
                float f1 = 0.0F;
                if (var1 instanceof EntityLivingBase) {
                    f1 = EnchantmentHelper.getEnchantmentModifierLiving(this, (EntityLivingBase)var1);
                    i += EnchantmentHelper.getKnockbackModifier(this, (EntityLivingBase)var1);
                }

                if (this.isSprinting()) {
                    i++;
                }

                if (f > 0.0F || f1 > 0.0F) {
                    boolean flag = this.fallDistance > 0.0F
                        && !this.onGround
                        && !this.isOnLadder()
                        && !this.isInWater()
                        && !this.isPotionActive(Potion.blindness)
                        && this.ridingEntity == null
                        && var1 instanceof EntityLivingBase;
                    if (flag && f > 0.0F) {
                        f *= 1.5F;
                    }

                    f += f1;
                    boolean flag1 = false;
                    int j = EnchantmentHelper.getFireAspectModifier(this);
                    if (var1 instanceof EntityLivingBase && j > 0 && !var1.isBurning()) {
                        flag1 = true;
                        var1.setFire(1);
                    }

                    boolean flag2 = var1.attackEntityFrom(DamageSource.causePlayerDamage(this), f);
                    if (flag2) {
                        if (i > 0) {
                            var1.addVelocity(
                                -MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F) * i * 0.5F,
                                0.1,
                                MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F) * i * 0.5F
                            );
                            this.motionX *= 0.6;
                            this.motionZ *= 0.6;
                            this.setSprinting(false);
                        }

                        if (flag) {
                            this.onCriticalHit(var1);
                        }

                        if (f1 > 0.0F) {
                            this.onEnchantmentCritical(var1);
                        }

                        if (f >= 18.0F) {
                            this.triggerAchievement(AchievementList.overkill);
                        }

                        this.setLastAttacker(var1);
                        if (var1 instanceof EntityLivingBase) {
                            EnchantmentHelper.func_151384_a((EntityLivingBase)var1, this);
                        }

                        EnchantmentHelper.func_151385_b(this, var1);
                        ItemStack itemstack = this.getCurrentEquippedItem();
                        Entity entity = var1;
                        if (var1 instanceof EntityDragonPart) {
                            IEntityMultiPart ientitymultipart = ((EntityDragonPart)var1).entityDragonObj;
                            if (ientitymultipart != null && ientitymultipart instanceof EntityLivingBase) {
                                entity = (EntityLivingBase)ientitymultipart;
                            }
                        }

                        if (itemstack != null && entity instanceof EntityLivingBase) {
                            itemstack.hitEntity((EntityLivingBase)entity, this);
                            if (itemstack.stackSize <= 0) {
                                this.destroyCurrentEquippedItem();
                            }
                        }

                        if (var1 instanceof EntityLivingBase) {
                            this.addStat(StatList.damageDealtStat, Math.round(f * 10.0F));
                            if (j > 0) {
                                var1.setFire(j * 4);
                            }
                        }

                        this.addExhaustion(0.3F);
                    } else if (flag1) {
                        var1.extinguish();
                    }
                }
            }
        }
    }

    public void onCriticalHit(Entity var1) {
    }

    public void onEnchantmentCritical(Entity var1) {
    }

    public void respawnPlayer() {
    }

    @Override
    public void setDead() {
        super.setDead();
        this.inventoryContainer.onContainerClosed(this);
        if (this.openContainer != null) {
            this.openContainer.onContainerClosed(this);
        }
    }

    @Override
    public boolean isEntityInsideOpaqueBlock() {
        return !this.sleeping && super.isEntityInsideOpaqueBlock();
    }

    public GameProfile getGameProfile() {
        return this.gameProfile;
    }

    public EntityPlayer.EnumStatus sleepInBedAt(int var1, int var2, int var3) {
        if (!this.worldObj.isRemote) {
            if (this.isPlayerSleeping() || !this.isEntityAlive()) {
                return EntityPlayer.EnumStatus.OTHER_PROBLEM;
            }

            if (!this.worldObj.provider.isSurfaceWorld()) {
                return EntityPlayer.EnumStatus.NOT_POSSIBLE_HERE;
            }

            if (this.worldObj.isDaytime()) {
                return EntityPlayer.EnumStatus.NOT_POSSIBLE_NOW;
            }

            if (Math.abs(this.posX - var1) > 3.0 || Math.abs(this.posY - var2) > 2.0 || Math.abs(this.posZ - var3) > 3.0) {
                return EntityPlayer.EnumStatus.TOO_FAR_AWAY;
            }

            double d0 = 8.0;
            double d1 = 5.0;
            List list = this.worldObj
                .getEntitiesWithinAABB(
                    EntityMob.class, AxisAlignedBB.func_72332_a().func_72299_a(var1 - d0, var2 - d1, var3 - d0, var1 + d0, var2 + d1, var3 + d0)
                );
            if (!list.isEmpty()) {
                return EntityPlayer.EnumStatus.NOT_SAFE;
            }
        }

        if (this.isRiding()) {
            this.mountEntity(null);
        }

        this.setSize(0.2F, 0.2F);
        this.yOffset = 0.2F;
        if (this.worldObj.blockExists(var1, var2, var3)) {
            int j = this.worldObj.getBlockMetadata(var1, var2, var3);
            int i = BlockBed.getDirection(j);
            float f1 = 0.5F;
            float f = 0.5F;
            switch (i) {
                case 0:
                    f = 0.9F;
                    break;
                case 1:
                    f1 = 0.1F;
                    break;
                case 2:
                    f = 0.1F;
                    break;
                case 3:
                    f1 = 0.9F;
            }

            this.func_71013_b(i);
            this.setPosition(var1 + f1, var2 + 15.0F / 16.0F, var3 + f);
        } else {
            this.setPosition(var1 + 0.5F, var2 + 15.0F / 16.0F, var3 + 0.5F);
        }

        this.sleeping = true;
        this.sleepTimer = 0;
        this.playerLocation = new ChunkCoordinates(var1, var2, var3);
        this.motionX = this.motionZ = this.motionY = 0.0;
        if (!this.worldObj.isRemote) {
            this.worldObj.updateAllPlayersSleepingFlag();
        }

        return EntityPlayer.EnumStatus.OK;
    }

    private void func_71013_b(int var1) {
        this.field_71079_bU = 0.0F;
        this.field_71089_bV = 0.0F;
        switch (var1) {
            case 0:
                this.field_71089_bV = -1.8F;
                break;
            case 1:
                this.field_71079_bU = 1.8F;
                break;
            case 2:
                this.field_71089_bV = 1.8F;
                break;
            case 3:
                this.field_71079_bU = -1.8F;
        }
    }

    public void wakeUpPlayer(boolean var1, boolean var2, boolean var3) {
        this.setSize(0.6F, 1.8F);
        this.resetHeight();
        ChunkCoordinates chunkcoordinates = this.playerLocation;
        ChunkCoordinates chunkcoordinates1 = this.playerLocation;
        if (chunkcoordinates != null && this.worldObj.getBlock(chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ) == Blocks.bed) {
            BlockBed.setBedOccupied(this.worldObj, chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ, false);
            chunkcoordinates1 = BlockBed.getSafeExitLocation(this.worldObj, chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ, 0);
            if (chunkcoordinates1 == null) {
                chunkcoordinates1 = new ChunkCoordinates(chunkcoordinates.posX, chunkcoordinates.posY + 1, chunkcoordinates.posZ);
            }

            this.setPosition(chunkcoordinates1.posX + 0.5F, chunkcoordinates1.posY + this.yOffset + 0.1F, chunkcoordinates1.posZ + 0.5F);
        }

        this.sleeping = false;
        if (!this.worldObj.isRemote && var2) {
            this.worldObj.updateAllPlayersSleepingFlag();
        }

        if (var1) {
            this.sleepTimer = 0;
        } else {
            this.sleepTimer = 100;
        }

        if (var3) {
            this.setSpawnChunk(this.playerLocation, false);
        }
    }

    private boolean isInBed() {
        return this.worldObj.getBlock(this.playerLocation.posX, this.playerLocation.posY, this.playerLocation.posZ) == Blocks.bed;
    }

    public static ChunkCoordinates verifyRespawnCoordinates(World var0, ChunkCoordinates var1, boolean var2) {
        IChunkProvider ichunkprovider = var0.getChunkProvider();
        ichunkprovider.loadChunk(var1.posX - 3 >> 4, var1.posZ - 3 >> 4);
        ichunkprovider.loadChunk(var1.posX + 3 >> 4, var1.posZ - 3 >> 4);
        ichunkprovider.loadChunk(var1.posX - 3 >> 4, var1.posZ + 3 >> 4);
        ichunkprovider.loadChunk(var1.posX + 3 >> 4, var1.posZ + 3 >> 4);
        if (var0.getBlock(var1.posX, var1.posY, var1.posZ) == Blocks.bed) {
            return BlockBed.getSafeExitLocation(var0, var1.posX, var1.posY, var1.posZ, 0);
        }

        Material material = var0.getBlock(var1.posX, var1.posY, var1.posZ).getMaterial();
        Material material1 = var0.getBlock(var1.posX, var1.posY + 1, var1.posZ).getMaterial();
        boolean flag = !material.isSolid() && !material.isLiquid();
        boolean flag1 = !material1.isSolid() && !material1.isLiquid();
        return var2 && flag && flag1 ? var1 : null;
    }

    public float getBedOrientationInDegrees() {
        if (this.playerLocation != null) {
            int i = this.worldObj.getBlockMetadata(this.playerLocation.posX, this.playerLocation.posY, this.playerLocation.posZ);
            int j = BlockBed.getDirection(i);
            switch (j) {
                case 0:
                    return 90.0F;
                case 1:
                    return 0.0F;
                case 2:
                    return 270.0F;
                case 3:
                    return 180.0F;
            }
        }

        return 0.0F;
    }

    @Override
    public boolean isPlayerSleeping() {
        return this.sleeping;
    }

    public boolean isPlayerFullyAsleep() {
        return this.sleeping && this.sleepTimer >= 100;
    }

    public int getSleepTimer() {
        return this.sleepTimer;
    }

    protected boolean getHideCape(int var1) {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1 << var1) != 0;
    }

    protected void setHideCape(int var1, boolean var2) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var2) {
            this.dataWatcher.updateObject(16, (byte)(b0 | 1 << var1));
        } else {
            this.dataWatcher.updateObject(16, (byte)(b0 & ~(1 << var1)));
        }
    }

    public void addChatComponentMessage(IChatComponent var1) {
    }

    public ChunkCoordinates getBedLocation() {
        return this.spawnChunk;
    }

    public boolean isSpawnForced() {
        return this.spawnForced;
    }

    public void setSpawnChunk(ChunkCoordinates var1, boolean var2) {
        if (var1 != null) {
            this.spawnChunk = new ChunkCoordinates(var1);
            this.spawnForced = var2;
        } else {
            this.spawnChunk = null;
            this.spawnForced = false;
        }
    }

    public void triggerAchievement(StatBase var1) {
        this.addStat(var1, 1);
    }

    public void addStat(StatBase var1, int var2) {
    }

    @Override
    public void jump() {
        super.jump();
        this.addStat(StatList.jumpStat, 1);
        if (this.isSprinting()) {
            this.addExhaustion(0.8F);
        } else {
            this.addExhaustion(0.2F);
        }
    }

    @Override
    public void moveEntityWithHeading(float var1, float var2) {
        double d0 = this.posX;
        double d1 = this.posY;
        double d2 = this.posZ;
        if (this.capabilities.isFlying && this.ridingEntity == null) {
            double d3 = this.motionY;
            float f = this.jumpMovementFactor;
            this.jumpMovementFactor = this.capabilities.getFlySpeed();
            super.moveEntityWithHeading(var1, var2);
            this.motionY = d3 * 0.6;
            this.jumpMovementFactor = f;
        } else {
            super.moveEntityWithHeading(var1, var2);
        }

        this.addMovementStat(this.posX - d0, this.posY - d1, this.posZ - d2);
    }

    @Override
    public float getAIMoveSpeed() {
        return (float)this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue();
    }

    public void addMovementStat(double var1, double var3, double var5) {
        if (this.ridingEntity == null) {
            if (this.isInsideOfMaterial(Material.water)) {
                int i = Math.round(MathHelper.sqrt_double(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
                if (i > 0) {
                    this.addStat(StatList.distanceDoveStat, i);
                    this.addExhaustion(0.015F * i * 0.01F);
                }
            } else if (this.isInWater()) {
                int j = Math.round(MathHelper.sqrt_double(var1 * var1 + var5 * var5) * 100.0F);
                if (j > 0) {
                    this.addStat(StatList.distanceSwumStat, j);
                    this.addExhaustion(0.015F * j * 0.01F);
                }
            } else if (this.isOnLadder()) {
                if (var3 > 0.0) {
                    this.addStat(StatList.distanceClimbedStat, (int)Math.round(var3 * 100.0));
                }
            } else if (this.onGround) {
                int k = Math.round(MathHelper.sqrt_double(var1 * var1 + var5 * var5) * 100.0F);
                if (k > 0) {
                    this.addStat(StatList.distanceWalkedStat, k);
                    if (this.isSprinting()) {
                        this.addExhaustion(10.0F * 0.01F * k * 0.01F);
                    } else {
                        this.addExhaustion(0.01F * k * 0.01F);
                    }
                }
            } else {
                int l = Math.round(MathHelper.sqrt_double(var1 * var1 + var5 * var5) * 100.0F);
                if (l > 25) {
                    this.addStat(StatList.distanceFlownStat, l);
                }
            }
        }
    }

    private void addMountedMovementStat(double var1, double var3, double var5) {
        if (this.ridingEntity != null) {
            int i = Math.round(MathHelper.sqrt_double(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
            if (i > 0) {
                if (this.ridingEntity instanceof EntityMinecart) {
                    this.addStat(StatList.distanceByMinecartStat, i);
                    if (this.startMinecartRidingCoordinate == null) {
                        this.startMinecartRidingCoordinate = new ChunkCoordinates(
                            MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)
                        );
                    } else if (this.startMinecartRidingCoordinate
                            .getDistanceSquared(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))
                        >= 1000000.0) {
                        this.addStat(AchievementList.onARail, 1);
                    }
                } else if (this.ridingEntity instanceof EntityBoat) {
                    this.addStat(StatList.distanceByBoatStat, i);
                } else if (this.ridingEntity instanceof EntityPig) {
                    this.addStat(StatList.distanceByPigStat, i);
                } else if (this.ridingEntity instanceof EntityHorse) {
                    this.addStat(StatList.field_151185_q, i);
                }
            }
        }
    }

    @Override
    protected void fall(float var1) {
        if (!this.capabilities.allowFlying) {
            if (var1 >= 2.0F) {
                this.addStat(StatList.distanceFallenStat, (int)Math.round(var1 * 100.0));
            }

            super.fall(var1);
        }
    }

    @Override
    protected String func_146067_o(int var1) {
        return var1 > 4 ? "game.player.hurt.fall.big" : "game.player.hurt.fall.small";
    }

    @Override
    public void onKillEntity(EntityLivingBase var1) {
        if (var1 instanceof IMob) {
            this.triggerAchievement(AchievementList.killEnemy);
        }

        int i = EntityList.getEntityID(var1);
        EntityList.EntityEggInfo entitylist$entityegginfo = (EntityList.EntityEggInfo)EntityList.entityEggs.get(i);
        if (entitylist$entityegginfo != null) {
            this.addStat(entitylist$entityegginfo.field_151512_d, 1);
        }
    }

    @Override
    public void setInWeb() {
        if (!this.capabilities.isFlying) {
            super.setInWeb();
        }
    }

    @Override
    public IIcon getItemIcon(ItemStack var1, int var2) {
        IIcon iicon = super.getItemIcon(var1, var2);
        if (var1.getItem() == Items.fishing_rod && this.fishEntity != null) {
            iicon = Items.fishing_rod.func_94597_g();
        } else {
            if (var1.getItem().requiresMultipleRenderPasses()) {
                return var1.getItem().getIconFromDamageForRenderPass(var1.getMetadata(), var2);
            }

            if (this.itemInUse != null && var1.getItem() == Items.bow) {
                int i = var1.getMaxItemUseDuration() - this.itemInUseCount;
                if (i >= 18) {
                    return Items.bow.getItemIconForUseDuration(2);
                }

                if (i > 13) {
                    return Items.bow.getItemIconForUseDuration(1);
                }

                if (i > 0) {
                    return Items.bow.getItemIconForUseDuration(0);
                }
            }
        }

        return iicon;
    }

    public ItemStack getCurrentArmor(int var1) {
        return this.inventory.armorItemInSlot(var1);
    }

    public void addExperience(int var1) {
        this.addScore(var1);
        int i = Integer.MAX_VALUE - this.experienceTotal;
        if (var1 > i) {
            var1 = i;
        }

        this.experience = this.experience + (float)var1 / this.xpBarCap();

        for (this.experienceTotal += var1; this.experience >= 1.0F; this.experience = this.experience / this.xpBarCap()) {
            this.experience = (this.experience - 1.0F) * this.xpBarCap();
            this.addExperienceLevel(1);
        }
    }

    public void addExperienceLevel(int var1) {
        this.experienceLevel += var1;
        if (this.experienceLevel < 0) {
            this.experienceLevel = 0;
            this.experience = 0.0F;
            this.experienceTotal = 0;
        }

        if (var1 > 0 && this.experienceLevel % 5 == 0 && this.field_82249_h < this.ticksExisted - 100.0F) {
            float f = this.experienceLevel > 30 ? 1.0F : this.experienceLevel / 30.0F;
            this.worldObj.playSoundAtEntity(this, "random.levelup", f * (12.0F / 16.0F), 1.0F);
            this.field_82249_h = this.ticksExisted;
        }
    }

    public int xpBarCap() {
        if (this.experienceLevel >= 30) {
            return 62 + (this.experienceLevel - 30) * 7;
        } else {
            return this.experienceLevel >= 15 ? 17 + (this.experienceLevel - 15) * 3 : 17;
        }
    }

    public void addExhaustion(float var1) {
        if (!this.capabilities.disableDamage) {
            if (!this.worldObj.isRemote) {
                this.foodStats.addExhaustion(var1);
            }
        }
    }

    public FoodStats getFoodStats() {
        return this.foodStats;
    }

    public boolean canEat(boolean var1) {
        return (var1 || this.foodStats.needFood()) && !this.capabilities.disableDamage;
    }

    public boolean shouldHeal() {
        return this.getHealth() > 0.0F && this.getHealth() < this.getMaxHealth();
    }

    public void setItemInUse(ItemStack var1, int var2) {
        if (var1 != this.itemInUse) {
            this.itemInUse = var1;
            this.itemInUseCount = var2;
            if (!this.worldObj.isRemote) {
                this.setEating(true);
            }
        }
    }

    public boolean isCurrentToolAdventureModeExempt(int var1, int var2, int var3) {
        if (this.capabilities.allowEdit) {
            return true;
        }

        Block block = this.worldObj.getBlock(var1, var2, var3);
        if (block.getMaterial() != Material.air) {
            if (block.getMaterial().isAdventureModeExempt()) {
                return true;
            }

            if (this.getCurrentEquippedItem() != null) {
                ItemStack itemstack = this.getCurrentEquippedItem();
                if (itemstack.canItemHarvestBlock(block) || itemstack.getStrVsBlock(block) > 1.0F) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean canPlayerEdit(int var1, int var2, int var3, int var4, ItemStack var5) {
        if (this.capabilities.allowEdit) {
            return true;
        } else {
            return var5 != null ? var5.canEditBlocks() : false;
        }
    }

    @Override
    protected int getExperiencePoints(EntityPlayer var1) {
        if (this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            return 0;
        }

        int i = this.experienceLevel * 7;
        return i > 100 ? 100 : i;
    }

    @Override
    protected boolean isPlayer() {
        return true;
    }

    @Override
    public boolean getAlwaysRenderNameTagForRender() {
        return true;
    }

    public void clonePlayer(EntityPlayer var1, boolean var2) {
        if (var2) {
            this.inventory.copyInventory(var1.inventory);
            this.setHealth(var1.getHealth());
            this.foodStats = var1.foodStats;
            this.experienceLevel = var1.experienceLevel;
            this.experienceTotal = var1.experienceTotal;
            this.experience = var1.experience;
            this.setScore(var1.getScore());
            this.teleportDirection = var1.teleportDirection;
        } else if (this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            this.inventory.copyInventory(var1.inventory);
            this.experienceLevel = var1.experienceLevel;
            this.experienceTotal = var1.experienceTotal;
            this.experience = var1.experience;
            this.setScore(var1.getScore());
        }

        this.theInventoryEnderChest = var1.theInventoryEnderChest;
    }

    @Override
    protected boolean canTriggerWalking() {
        return !this.capabilities.isFlying;
    }

    public void sendPlayerAbilities() {
    }

    public void setGameType(WorldSettings.GameType var1) {
    }

    @Override
    public String getCommandSenderName() {
        return this.gameProfile.getName();
    }

    @Override
    public World getEntityWorld() {
        return this.worldObj;
    }

    public InventoryEnderChest getInventoryEnderChest() {
        return this.theInventoryEnderChest;
    }

    @Override
    public ItemStack getEquipmentInSlot(int var1) {
        return var1 == 0 ? this.inventory.getCurrentItem() : this.inventory.armorInventory[var1 - 1];
    }

    @Override
    public ItemStack getHeldItem() {
        return this.inventory.getCurrentItem();
    }

    @Override
    public void setCurrentItemOrArmor(int var1, ItemStack var2) {
        this.inventory.armorInventory[var1] = var2;
    }

    @Override
    public boolean isInvisibleToPlayer(EntityPlayer var1) {
        if (!this.isInvisible()) {
            return false;
        }

        Team team = this.getTeam();
        return team == null || var1 == null || var1.getTeam() != team || !team.func_98297_h();
    }

    @Override
    public ItemStack[] getInventory() {
        return this.inventory.armorInventory;
    }

    public boolean getHideCape() {
        return this.getHideCape(1);
    }

    @Override
    public boolean isPushedByWater() {
        return !this.capabilities.isFlying;
    }

    public Scoreboard getWorldScoreboard() {
        return this.worldObj.getScoreboard();
    }

    @Override
    public Team getTeam() {
        return this.getWorldScoreboard().getPlayersTeam(this.getCommandSenderName());
    }

    @Override
    public IChatComponent getFormattedCommandSenderName() {
        ChatComponentText chatcomponenttext = new ChatComponentText(ScorePlayerTeam.formatPlayerName(this.getTeam(), this.getCommandSenderName()));
        chatcomponenttext.getChatStyle().setChatClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/msg " + this.getCommandSenderName() + " "));
        return chatcomponenttext;
    }

    @Override
    public void setAbsorptionAmount(float var1) {
        if (var1 < 0.0F) {
            var1 = 0.0F;
        }

        this.getDataWatcher().updateObject(17, var1);
    }

    @Override
    public float getAbsorptionAmount() {
        return this.getDataWatcher().getWatchableObjectFloat(17);
    }

    public static UUID getUUID(GameProfile var0) {
        UUID uuid = Util.func_147173_b(var0.getId());
        if (uuid == null) {
            uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + var0.getName()).getBytes(Charsets.UTF_8));
        }

        return uuid;
    }

    public enum EnumChatVisibility {
        FULL(0, "options.chat.visibility.full"),
        SYSTEM(1, "options.chat.visibility.system"),
        HIDDEN(2, "options.chat.visibility.hidden");

        private static final EntityPlayer.EnumChatVisibility[] field_151432_d = new EntityPlayer.EnumChatVisibility[values().length];
        private final int chatVisibility;
        private final String resourceKey;

        EnumChatVisibility(int var3, String var4) {
            this.chatVisibility = var3;
            this.resourceKey = var4;
        }

        public int getChatVisibility() {
            return this.chatVisibility;
        }

        public static EntityPlayer.EnumChatVisibility getEnumChatVisibility(int var0) {
            return field_151432_d[var0 % field_151432_d.length];
        }

        public String getResourceKey() {
            return this.resourceKey;
        }

        static {
            for (EntityPlayer.EnumChatVisibility entityplayer$enumchatvisibility : values()) {
                field_151432_d[entityplayer$enumchatvisibility.chatVisibility] = entityplayer$enumchatvisibility;
            }
        }
    }

    public enum EnumStatus {
        OK,
        NOT_POSSIBLE_HERE,
        NOT_POSSIBLE_NOW,
        TOO_FAR_AWAY,
        OTHER_PROBLEM,
        NOT_SAFE;
    }
}
