package net.minecraft.entity.effect;

import java.util.List;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class EntityLightningBolt extends EntityWeatherEffect {
    private int lightningState;
    public long boltVertex;
    private int boltLivingTime;

    public EntityLightningBolt(World var1, double var2, double var4, double var6) {
        super(var1);
        this.setLocationAndAngles(var2, var4, var6, 0.0F, 0.0F);
        this.lightningState = 2;
        this.boltVertex = this.rand.nextLong();
        this.boltLivingTime = this.rand.nextInt(3) + 1;
        if (!var1.isRemote
            && var1.getGameRules().getGameRuleBooleanValue("doFireTick")
            && (var1.difficultySetting == EnumDifficulty.NORMAL || var1.difficultySetting == EnumDifficulty.HARD)
            && var1.doChunksNearChunkExist(MathHelper.floor_double(var2), MathHelper.floor_double(var4), MathHelper.floor_double(var6), 10)) {
            int i = MathHelper.floor_double(var2);
            int j = MathHelper.floor_double(var4);
            int k = MathHelper.floor_double(var6);
            if (var1.getBlock(i, j, k).getMaterial() == Material.air && Blocks.fire.canPlaceBlockAt(var1, i, j, k)) {
                var1.setBlock(i, j, k, Blocks.fire);
            }

            for (int i1 = 0; i1 < 4; i1++) {
                j = MathHelper.floor_double(var2) + this.rand.nextInt(3) - 1;
                k = MathHelper.floor_double(var4) + this.rand.nextInt(3) - 1;
                int l = MathHelper.floor_double(var6) + this.rand.nextInt(3) - 1;
                if (var1.getBlock(j, k, l).getMaterial() == Material.air && Blocks.fire.canPlaceBlockAt(var1, j, k, l)) {
                    var1.setBlock(j, k, l, Blocks.fire);
                }
            }
        }
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.lightningState == 2) {
            this.worldObj.playSoundEffect(this.posX, this.posY, this.posZ, "ambient.weather.thunder", 10000.0F, 0.8F + this.rand.nextFloat() * 0.2F);
            this.worldObj.playSoundEffect(this.posX, this.posY, this.posZ, "random.explode", 2.0F, 0.5F + this.rand.nextFloat() * 0.2F);
        }

        this.lightningState--;
        if (this.lightningState < 0) {
            if (this.boltLivingTime == 0) {
                this.setDead();
            } else if (this.lightningState < -this.rand.nextInt(10)) {
                this.boltLivingTime--;
                this.lightningState = 1;
                this.boltVertex = this.rand.nextLong();
                if (!this.worldObj.isRemote
                    && this.worldObj.getGameRules().getGameRuleBooleanValue("doFireTick")
                    && this.worldObj
                        .doChunksNearChunkExist(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ), 10)
                    )
                 {
                    int i = MathHelper.floor_double(this.posX);
                    int j = MathHelper.floor_double(this.posY);
                    int k = MathHelper.floor_double(this.posZ);
                    if (this.worldObj.getBlock(i, j, k).getMaterial() == Material.air && Blocks.fire.canPlaceBlockAt(this.worldObj, i, j, k)) {
                        this.worldObj.setBlock(i, j, k, Blocks.fire);
                    }
                }
            }
        }

        if (this.lightningState >= 0) {
            if (this.worldObj.isRemote) {
                this.worldObj.lastLightningBolt = 2;
            } else {
                double d0 = 3.0;
                List list = this.worldObj
                    .getEntitiesWithinAABBExcludingEntity(
                        this,
                        AxisAlignedBB.func_72332_a()
                            .func_72299_a(this.posX - d0, this.posY - d0, this.posZ - d0, this.posX + d0, this.posY + 6.0 + d0, this.posZ + d0)
                    );

                for (int l = 0; l < list.size(); l++) {
                    Entity entity = (Entity)list.get(l);
                    entity.onStruckByLightning(this);
                }
            }
        }
    }

    @Override
    protected void entityInit() {
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
    }
}
