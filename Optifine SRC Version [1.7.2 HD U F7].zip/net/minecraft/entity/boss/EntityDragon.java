package net.minecraft.entity.boss;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEndPortal;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EntityDragon extends EntityLiving implements IBossDisplayData, IEntityMultiPart, IMob {
    public double targetX;
    public double targetY;
    public double targetZ;
    public double[][] ringBuffer = new double[64][3];
    public int ringBufferIndex = -1;
    public EntityDragonPart[] dragonPartArray;
    public EntityDragonPart dragonPartHead;
    public EntityDragonPart dragonPartBody;
    public EntityDragonPart dragonPartTail1;
    public EntityDragonPart dragonPartTail2;
    public EntityDragonPart dragonPartTail3;
    public EntityDragonPart dragonPartWing1;
    public EntityDragonPart dragonPartWing2;
    public float prevAnimTime;
    public float animTime;
    public boolean forceNewTarget;
    public boolean slowed;
    private Entity target;
    public int deathTicks;
    public EntityEnderCrystal healingEnderCrystal;

    public EntityDragon(World var1) {
        super(var1);
        this.dragonPartArray = new EntityDragonPart[]{
            this.dragonPartHead = new EntityDragonPart(this, "head", 6.0F, 6.0F),
            this.dragonPartBody = new EntityDragonPart(this, "body", 8.0F, 8.0F),
            this.dragonPartTail1 = new EntityDragonPart(this, "tail", 4.0F, 4.0F),
            this.dragonPartTail2 = new EntityDragonPart(this, "tail", 4.0F, 4.0F),
            this.dragonPartTail3 = new EntityDragonPart(this, "tail", 4.0F, 4.0F),
            this.dragonPartWing1 = new EntityDragonPart(this, "wing", 4.0F, 4.0F),
            this.dragonPartWing2 = new EntityDragonPart(this, "wing", 4.0F, 4.0F)
        };
        this.setHealth(this.getMaxHealth());
        this.setSize(16.0F, 8.0F);
        this.noClip = true;
        this.isImmuneToFire = true;
        this.targetY = 100.0;
        this.ignoreFrustumCheck = true;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(200.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
    }

    public double[] getMovementOffsets(int var1, float var2) {
        if (this.getHealth() <= 0.0F) {
            var2 = 0.0F;
        }

        var2 = 1.0F - var2;
        int i = this.ringBufferIndex - var1 * 1 & 63;
        int j = this.ringBufferIndex - var1 * 1 - 1 & 63;
        double[] adouble = new double[3];
        double d0 = this.ringBuffer[i][0];
        double d1 = MathHelper.wrapAngleTo180_double(this.ringBuffer[j][0] - d0);
        adouble[0] = d0 + d1 * var2;
        d0 = this.ringBuffer[i][1];
        d1 = this.ringBuffer[j][1] - d0;
        adouble[1] = d0 + d1 * var2;
        adouble[2] = this.ringBuffer[i][2] + (this.ringBuffer[j][2] - this.ringBuffer[i][2]) * var2;
        return adouble;
    }

    @Override
    public void onLivingUpdate() {
        if (this.worldObj.isRemote) {
            float f = MathHelper.cos(this.animTime * (float)Math.PI * 2.0F);
            float f1 = MathHelper.cos(this.prevAnimTime * (float)Math.PI * 2.0F);
            if (f1 <= -0.3F && f >= -0.3F) {
                this.worldObj.playSound(this.posX, this.posY, this.posZ, "mob.enderdragon.wings", 5.0F, 0.8F + this.rand.nextFloat() * 0.3F, false);
            }
        }

        this.prevAnimTime = this.animTime;
        if (this.getHealth() <= 0.0F) {
            float f11 = (this.rand.nextFloat() - 0.5F) * 8.0F;
            float f13 = (this.rand.nextFloat() - 0.5F) * 4.0F;
            float f14 = (this.rand.nextFloat() - 0.5F) * 8.0F;
            this.worldObj.spawnParticle("largeexplode", this.posX + f11, this.posY + 2.0 + f13, this.posZ + f14, 0.0, 0.0, 0.0);
        } else {
            this.updateDragonEnderCrystal();
            float f10 = 0.2F / (MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ) * 10.0F + 1.0F);
            f10 *= (float)Math.pow(2.0, this.motionY);
            if (this.slowed) {
                this.animTime += f10 * 0.5F;
            } else {
                this.animTime += f10;
            }

            this.rotationYaw = MathHelper.wrapAngleTo180_float(this.rotationYaw);
            if (this.ringBufferIndex < 0) {
                for (int i = 0; i < this.ringBuffer.length; i++) {
                    this.ringBuffer[i][0] = this.rotationYaw;
                    this.ringBuffer[i][1] = this.posY;
                }
            }

            if (++this.ringBufferIndex == this.ringBuffer.length) {
                this.ringBufferIndex = 0;
            }

            this.ringBuffer[this.ringBufferIndex][0] = this.rotationYaw;
            this.ringBuffer[this.ringBufferIndex][1] = this.posY;
            if (this.worldObj.isRemote) {
                if (this.newPosRotationIncrements > 0) {
                    double d10 = this.posX + (this.newPosX - this.posX) / this.newPosRotationIncrements;
                    double d0 = this.posY + (this.newPosY - this.posY) / this.newPosRotationIncrements;
                    double d1 = this.posZ + (this.newPosZ - this.posZ) / this.newPosRotationIncrements;
                    double d2 = MathHelper.wrapAngleTo180_double(this.newRotationYaw - this.rotationYaw);
                    this.rotationYaw = (float)(this.rotationYaw + d2 / this.newPosRotationIncrements);
                    this.rotationPitch = (float)(this.rotationPitch + (this.newRotationPitch - this.rotationPitch) / this.newPosRotationIncrements);
                    this.newPosRotationIncrements--;
                    this.setPosition(d10, d0, d1);
                    this.setRotation(this.rotationYaw, this.rotationPitch);
                }
            } else {
                double d11 = this.targetX - this.posX;
                double d12 = this.targetY - this.posY;
                double d13 = this.targetZ - this.posZ;
                double d14 = d11 * d11 + d12 * d12 + d13 * d13;
                if (this.target != null) {
                    this.targetX = this.target.posX;
                    this.targetZ = this.target.posZ;
                    double d3 = this.targetX - this.posX;
                    double d5 = this.targetZ - this.posZ;
                    double d7 = Math.sqrt(d3 * d3 + d5 * d5);
                    double d8 = 0.4F + d7 / 80.0 - 1.0;
                    if (d8 > 10.0) {
                        d8 = 10.0;
                    }

                    this.targetY = this.target.boundingBox.minY + d8;
                } else {
                    this.targetX = this.targetX + this.rand.nextGaussian() * 2.0;
                    this.targetZ = this.targetZ + this.rand.nextGaussian() * 2.0;
                }

                if (this.forceNewTarget || d14 < 100.0 || d14 > 22500.0 || this.isCollidedHorizontally || this.isCollidedVertically) {
                    this.setNewTarget();
                }

                d12 /= MathHelper.sqrt_double(d11 * d11 + d13 * d13);
                float f17 = 0.6F;
                if (d12 < -f17) {
                    d12 = -f17;
                }

                if (d12 > f17) {
                    d12 = f17;
                }

                this.motionY += d12 * 0.1F;
                this.rotationYaw = MathHelper.wrapAngleTo180_float(this.rotationYaw);
                double d4 = 180.0 - Math.atan2(d11, d13) * 180.0 / (float)Math.PI;
                double d6 = MathHelper.wrapAngleTo180_double(d4 - this.rotationYaw);
                if (d6 > 50.0) {
                    d6 = 50.0;
                }

                if (d6 < -50.0) {
                    d6 = -50.0;
                }

                Vec3 vec3 = this.worldObj.func_82732_R().func_72345_a(this.targetX - this.posX, this.targetY - this.posY, this.targetZ - this.posZ).normalize();
                Vec3 vec32 = this.worldObj
                    .func_82732_R()
                    .func_72345_a(
                        MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F), this.motionY, -MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F)
                    )
                    .normalize();
                float f5 = (float)(vec32.dotProduct(vec3) + 0.5) / 1.5F;
                if (f5 < 0.0F) {
                    f5 = 0.0F;
                }

                this.randomYawVelocity *= 0.8F;
                float f6 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ) * 1.0F + 1.0F;
                double d9 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ) * 1.0 + 1.0;
                if (d9 > 40.0) {
                    d9 = 40.0;
                }

                this.randomYawVelocity = (float)(this.randomYawVelocity + d6 * (0.7F / d9 / f6));
                this.rotationYaw = this.rotationYaw + this.randomYawVelocity * 0.1F;
                float f7 = (float)(2.0 / (d9 + 1.0));
                float f8 = 0.06F;
                this.moveFlying(0.0F, -1.0F, f8 * (f5 * f7 + (1.0F - f7)));
                if (this.slowed) {
                    this.moveEntity(this.motionX * 0.8F, this.motionY * 0.8F, this.motionZ * 0.8F);
                } else {
                    this.moveEntity(this.motionX, this.motionY, this.motionZ);
                }

                Vec3 vec31 = this.worldObj.func_82732_R().func_72345_a(this.motionX, this.motionY, this.motionZ).normalize();
                float f9 = (float)(vec31.dotProduct(vec32) + 1.0) / 2.0F;
                f9 = 0.8F + 0.15F * f9;
                this.motionX *= f9;
                this.motionZ *= f9;
                this.motionY *= 0.91F;
            }

            this.renderYawOffset = this.rotationYaw;
            this.dragonPartHead.width = this.dragonPartHead.height = 3.0F;
            this.dragonPartTail1.width = this.dragonPartTail1.height = 2.0F;
            this.dragonPartTail2.width = this.dragonPartTail2.height = 2.0F;
            this.dragonPartTail3.width = this.dragonPartTail3.height = 2.0F;
            this.dragonPartBody.height = 3.0F;
            this.dragonPartBody.width = 5.0F;
            this.dragonPartWing1.height = 2.0F;
            this.dragonPartWing1.width = 4.0F;
            this.dragonPartWing2.height = 3.0F;
            this.dragonPartWing2.width = 4.0F;
            float f12 = (float)(this.getMovementOffsets(5, 1.0F)[1] - this.getMovementOffsets(10, 1.0F)[1]) * 10.0F / 180.0F * (float)Math.PI;
            float f2 = MathHelper.cos(f12);
            float f15 = -MathHelper.sin(f12);
            float f3 = this.rotationYaw * (float)Math.PI / 180.0F;
            float f16 = MathHelper.sin(f3);
            float f4 = MathHelper.cos(f3);
            this.dragonPartBody.onUpdate();
            this.dragonPartBody.setLocationAndAngles(this.posX + f16 * 0.5F, this.posY, this.posZ - f4 * 0.5F, 0.0F, 0.0F);
            this.dragonPartWing1.onUpdate();
            this.dragonPartWing1.setLocationAndAngles(this.posX + f4 * 4.5F, this.posY + 2.0, this.posZ + f16 * 4.5F, 0.0F, 0.0F);
            this.dragonPartWing2.onUpdate();
            this.dragonPartWing2.setLocationAndAngles(this.posX - f4 * 4.5F, this.posY + 2.0, this.posZ - f16 * 4.5F, 0.0F, 0.0F);
            if (!this.worldObj.isRemote && this.hurtTime == 0) {
                this.collideWithEntities(
                    this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.dragonPartWing1.boundingBox.expand(4.0, 2.0, 4.0).offset(0.0, -2.0, 0.0))
                );
                this.collideWithEntities(
                    this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.dragonPartWing2.boundingBox.expand(4.0, 2.0, 4.0).offset(0.0, -2.0, 0.0))
                );
                this.attackEntitiesInList(this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.dragonPartHead.boundingBox.expand(1.0, 1.0, 1.0)));
            }

            double[] adouble1 = this.getMovementOffsets(5, 1.0F);
            double[] adouble = this.getMovementOffsets(0, 1.0F);
            float f18 = MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F - this.randomYawVelocity * 0.01F);
            float f19 = MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F - this.randomYawVelocity * 0.01F);
            this.dragonPartHead.onUpdate();
            this.dragonPartHead
                .setLocationAndAngles(
                    this.posX + f18 * 5.5F * f2, this.posY + (adouble[1] - adouble1[1]) * 1.0 + f15 * 5.5F, this.posZ - f19 * 5.5F * f2, 0.0F, 0.0F
                );

            for (int j = 0; j < 3; j++) {
                EntityDragonPart entitydragonpart = null;
                if (j == 0) {
                    entitydragonpart = this.dragonPartTail1;
                }

                if (j == 1) {
                    entitydragonpart = this.dragonPartTail2;
                }

                if (j == 2) {
                    entitydragonpart = this.dragonPartTail3;
                }

                double[] adouble2 = this.getMovementOffsets(12 + j * 2, 1.0F);
                float f20 = this.rotationYaw * (float)Math.PI / 180.0F + this.simplifyAngle(adouble2[0] - adouble1[0]) * (float)Math.PI / 180.0F * 1.0F;
                float f21 = MathHelper.sin(f20);
                float f22 = MathHelper.cos(f20);
                float f23 = 1.5F;
                float f24 = (j + 1) * 2.0F;
                entitydragonpart.onUpdate();
                entitydragonpart.setLocationAndAngles(
                    this.posX - (f16 * f23 + f21 * f24) * f2,
                    this.posY + (adouble2[1] - adouble1[1]) * 1.0 - (f24 + f23) * f15 + 1.5,
                    this.posZ + (f4 * f23 + f22 * f24) * f2,
                    0.0F,
                    0.0F
                );
            }

            if (!this.worldObj.isRemote) {
                this.slowed = this.destroyBlocksInAABB(this.dragonPartHead.boundingBox) | this.destroyBlocksInAABB(this.dragonPartBody.boundingBox);
            }
        }
    }

    private void updateDragonEnderCrystal() {
        if (this.healingEnderCrystal != null) {
            if (this.healingEnderCrystal.isDead) {
                if (!this.worldObj.isRemote) {
                    this.attackEntityFromPart(this.dragonPartHead, DamageSource.setExplosionSource(null), 10.0F);
                }

                this.healingEnderCrystal = null;
            } else if (this.ticksExisted % 10 == 0 && this.getHealth() < this.getMaxHealth()) {
                this.setHealth(this.getHealth() + 1.0F);
            }
        }

        if (this.rand.nextInt(10) == 0) {
            float f = 32.0F;
            List list = this.worldObj.getEntitiesWithinAABB(EntityEnderCrystal.class, this.boundingBox.expand(f, f, f));
            EntityEnderCrystal entityendercrystal = null;
            double d0 = Double.MAX_VALUE;

            for (EntityEnderCrystal entityendercrystal1 : (Iterable<EntityEnderCrystal>) (Iterable) list) {
                double d1 = entityendercrystal1.getDistanceSqToEntity(this);
                if (d1 < d0) {
                    d0 = d1;
                    entityendercrystal = entityendercrystal1;
                }
            }

            this.healingEnderCrystal = entityendercrystal;
        }
    }

    private void collideWithEntities(List var1) {
        double d0 = (this.dragonPartBody.boundingBox.minX + this.dragonPartBody.boundingBox.maxX) / 2.0;
        double d1 = (this.dragonPartBody.boundingBox.minZ + this.dragonPartBody.boundingBox.maxZ) / 2.0;

        for (Entity entity : (Iterable<Entity>) (Iterable) var1) {
            if (entity instanceof EntityLivingBase) {
                double d2 = entity.posX - d0;
                double d3 = entity.posZ - d1;
                double d4 = d2 * d2 + d3 * d3;
                entity.addVelocity(d2 / d4 * 4.0, 0.2F, d3 / d4 * 4.0);
            }
        }
    }

    private void attackEntitiesInList(List var1) {
        for (int i = 0; i < var1.size(); i++) {
            Entity entity = (Entity)var1.get(i);
            if (entity instanceof EntityLivingBase) {
                entity.attackEntityFrom(DamageSource.causeMobDamage(this), 10.0F);
            }
        }
    }

    private void setNewTarget() {
        this.forceNewTarget = false;
        if (this.rand.nextInt(2) == 0 && !this.worldObj.playerEntities.isEmpty()) {
            this.target = (Entity)this.worldObj.playerEntities.get(this.rand.nextInt(this.worldObj.playerEntities.size()));
        } else {
            boolean flag = false;

            do {
                this.targetX = 0.0;
                this.targetY = 70.0F + this.rand.nextFloat() * 50.0F;
                this.targetZ = 0.0;
                this.targetX = this.targetX + (this.rand.nextFloat() * 120.0F - 60.0F);
                this.targetZ = this.targetZ + (this.rand.nextFloat() * 120.0F - 60.0F);
                double d0 = this.posX - this.targetX;
                double d1 = this.posY - this.targetY;
                double d2 = this.posZ - this.targetZ;
                flag = d0 * d0 + d1 * d1 + d2 * d2 > 100.0;
            } while (!flag);

            this.target = null;
        }
    }

    private float simplifyAngle(double var1) {
        return (float)MathHelper.wrapAngleTo180_double(var1);
    }

    private boolean destroyBlocksInAABB(AxisAlignedBB var1) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.minY);
        int k = MathHelper.floor_double(var1.minZ);
        int l = MathHelper.floor_double(var1.maxX);
        int i1 = MathHelper.floor_double(var1.maxY);
        int j1 = MathHelper.floor_double(var1.maxZ);
        boolean flag = false;
        boolean flag1 = false;

        for (int k1 = i; k1 <= l; k1++) {
            for (int l1 = j; l1 <= i1; l1++) {
                for (int i2 = k; i2 <= j1; i2++) {
                    Block block = this.worldObj.getBlock(k1, l1, i2);
                    if (block.getMaterial() != Material.air) {
                        if (block != Blocks.obsidian
                            && block != Blocks.end_stone
                            && block != Blocks.bedrock
                            && this.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) {
                            flag1 = this.worldObj.setBlockToAir(k1, l1, i2) || flag1;
                        } else {
                            flag = true;
                        }
                    }
                }
            }
        }

        if (flag1) {
            double d1 = var1.minX + (var1.maxX - var1.minX) * this.rand.nextFloat();
            double d2 = var1.minY + (var1.maxY - var1.minY) * this.rand.nextFloat();
            double d0 = var1.minZ + (var1.maxZ - var1.minZ) * this.rand.nextFloat();
            this.worldObj.spawnParticle("largeexplode", d1, d2, d0, 0.0, 0.0, 0.0);
        }

        return flag;
    }

    @Override
    public boolean attackEntityFromPart(EntityDragonPart var1, DamageSource var2, float var3) {
        if (var1 != this.dragonPartHead) {
            var3 = var3 / 4.0F + 1.0F;
        }

        float f = this.rotationYaw * (float)Math.PI / 180.0F;
        float f1 = MathHelper.sin(f);
        float f2 = MathHelper.cos(f);
        this.targetX = this.posX + f1 * 5.0F + (this.rand.nextFloat() - 0.5F) * 2.0F;
        this.targetY = this.posY + this.rand.nextFloat() * 3.0F + 1.0;
        this.targetZ = this.posZ - f2 * 5.0F + (this.rand.nextFloat() - 0.5F) * 2.0F;
        this.target = null;
        if (var2.getEntity() instanceof EntityPlayer || var2.isExplosion()) {
            this.func_82195_e(var2, var3);
        }

        return true;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        return false;
    }

    protected boolean func_82195_e(DamageSource var1, float var2) {
        return super.attackEntityFrom(var1, var2);
    }

    @Override
    protected void onDeathUpdate() {
        this.deathTicks++;
        if (this.deathTicks >= 180 && this.deathTicks <= 200) {
            float f = (this.rand.nextFloat() - 0.5F) * 8.0F;
            float f1 = (this.rand.nextFloat() - 0.5F) * 4.0F;
            float f2 = (this.rand.nextFloat() - 0.5F) * 8.0F;
            this.worldObj.spawnParticle("hugeexplosion", this.posX + f, this.posY + 2.0 + f1, this.posZ + f2, 0.0, 0.0, 0.0);
        }

        if (!this.worldObj.isRemote) {
            if (this.deathTicks > 150 && this.deathTicks % 5 == 0) {
                int i = 1000;

                while (i > 0) {
                    int k = EntityXPOrb.getXPSplit(i);
                    i -= k;
                    this.worldObj.spawnEntityInWorld(new EntityXPOrb(this.worldObj, this.posX, this.posY, this.posZ, k));
                }
            }

            if (this.deathTicks == 1) {
                this.worldObj.playBroadcastSound(1018, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
            }
        }

        this.moveEntity(0.0, 0.1F, 0.0);
        this.renderYawOffset = this.rotationYaw += 20.0F;
        if (this.deathTicks == 200 && !this.worldObj.isRemote) {
            int j = 2000;

            while (j > 0) {
                int l = EntityXPOrb.getXPSplit(j);
                j -= l;
                this.worldObj.spawnEntityInWorld(new EntityXPOrb(this.worldObj, this.posX, this.posY, this.posZ, l));
            }

            this.createEnderPortal(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posZ));
            this.setDead();
        }
    }

    private void createEnderPortal(int var1, int var2) {
        byte b0 = 64;
        BlockEndPortal.field_149948_a = true;
        byte b1 = 4;

        for (int i = b0 - 1; i <= b0 + 32; i++) {
            for (int j = var1 - b1; j <= var1 + b1; j++) {
                for (int k = var2 - b1; k <= var2 + b1; k++) {
                    double d0 = j - var1;
                    double d1 = k - var2;
                    double d2 = d0 * d0 + d1 * d1;
                    if (d2 <= (b1 - 0.5) * (b1 - 0.5)) {
                        if (i < b0) {
                            if (d2 <= (b1 - 1 - 0.5) * (b1 - 1 - 0.5)) {
                                this.worldObj.setBlock(j, i, k, Blocks.bedrock);
                            }
                        } else if (i > b0) {
                            this.worldObj.setBlock(j, i, k, Blocks.air);
                        } else if (d2 > (b1 - 1 - 0.5) * (b1 - 1 - 0.5)) {
                            this.worldObj.setBlock(j, i, k, Blocks.bedrock);
                        } else {
                            this.worldObj.setBlock(j, i, k, Blocks.end_portal);
                        }
                    }
                }
            }
        }

        this.worldObj.setBlock(var1, b0 + 0, var2, Blocks.bedrock);
        this.worldObj.setBlock(var1, b0 + 1, var2, Blocks.bedrock);
        this.worldObj.setBlock(var1, b0 + 2, var2, Blocks.bedrock);
        this.worldObj.setBlock(var1 - 1, b0 + 2, var2, Blocks.torch);
        this.worldObj.setBlock(var1 + 1, b0 + 2, var2, Blocks.torch);
        this.worldObj.setBlock(var1, b0 + 2, var2 - 1, Blocks.torch);
        this.worldObj.setBlock(var1, b0 + 2, var2 + 1, Blocks.torch);
        this.worldObj.setBlock(var1, b0 + 3, var2, Blocks.bedrock);
        this.worldObj.setBlock(var1, b0 + 4, var2, Blocks.dragon_egg);
        BlockEndPortal.field_149948_a = false;
    }

    @Override
    public void despawnEntity() {
    }

    @Override
    public Entity[] getParts() {
        return this.dragonPartArray;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public World func_82194_d() {
        return this.worldObj;
    }

    @Override
    protected String getLivingSound() {
        return "mob.enderdragon.growl";
    }

    @Override
    protected String getHurtSound() {
        return "mob.enderdragon.hit";
    }

    @Override
    protected float getSoundVolume() {
        return 5.0F;
    }
}
