package net.minecraft.entity.ai;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.EntityCreature;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.village.Village;
import net.minecraft.village.VillageDoorInfo;

public class EntityAIMoveThroughVillage extends EntityAIBase {
    private EntityCreature theEntity;
    private double movementSpeed;
    private PathEntity entityPathNavigate;
    private VillageDoorInfo doorInfo;
    private boolean isNocturnal;
    private List doorList = new ArrayList();

    public EntityAIMoveThroughVillage(EntityCreature var1, double var2, boolean var4) {
        this.theEntity = var1;
        this.movementSpeed = var2;
        this.isNocturnal = var4;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        this.func_75414_f();
        if (this.isNocturnal && this.theEntity.worldObj.isDaytime()) {
            return false;
        }

        Village village = this.theEntity
            .worldObj
            .villageCollectionObj
            .findNearestVillage(
                MathHelper.floor_double(this.theEntity.posX), MathHelper.floor_double(this.theEntity.posY), MathHelper.floor_double(this.theEntity.posZ), 0
            );
        if (village == null) {
            return false;
        }

        this.doorInfo = this.func_75412_a(village);
        if (this.doorInfo == null) {
            return false;
        }

        boolean flag = this.theEntity.getNavigator().getCanBreakDoors();
        this.theEntity.getNavigator().setBreakDoors(false);
        this.entityPathNavigate = this.theEntity.getNavigator().getPathToXYZ(this.doorInfo.posX, this.doorInfo.posY, this.doorInfo.posZ);
        this.theEntity.getNavigator().setBreakDoors(flag);
        if (this.entityPathNavigate != null) {
            return true;
        }

        Vec3 vec3 = RandomPositionGenerator.findRandomTargetBlockTowards(
            this.theEntity, 10, 7, this.theEntity.worldObj.func_82732_R().func_72345_a(this.doorInfo.posX, this.doorInfo.posY, this.doorInfo.posZ)
        );
        if (vec3 == null) {
            return false;
        }

        this.theEntity.getNavigator().setBreakDoors(false);
        this.entityPathNavigate = this.theEntity.getNavigator().getPathToXYZ(vec3.xCoord, vec3.yCoord, vec3.zCoord);
        this.theEntity.getNavigator().setBreakDoors(flag);
        return this.entityPathNavigate != null;
    }

    @Override
    public boolean continueExecuting() {
        if (this.theEntity.getNavigator().noPath()) {
            return false;
        }

        float f = this.theEntity.width + 4.0F;
        return this.theEntity.getDistanceSq(this.doorInfo.posX, this.doorInfo.posY, this.doorInfo.posZ) > f * f;
    }

    @Override
    public void startExecuting() {
        this.theEntity.getNavigator().setPath(this.entityPathNavigate, this.movementSpeed);
    }

    @Override
    public void resetTask() {
        if (this.theEntity.getNavigator().noPath() || this.theEntity.getDistanceSq(this.doorInfo.posX, this.doorInfo.posY, this.doorInfo.posZ) < 16.0) {
            this.doorList.add(this.doorInfo);
        }
    }

    private VillageDoorInfo func_75412_a(Village var1) {
        VillageDoorInfo villagedoorinfo = null;
        int i = Integer.MAX_VALUE;

        for (VillageDoorInfo villagedoorinfo1 : (Iterable<VillageDoorInfo>) (Iterable) var1.getVillageDoorInfoList()) {
            int j = villagedoorinfo1.getDistanceSquared(
                MathHelper.floor_double(this.theEntity.posX), MathHelper.floor_double(this.theEntity.posY), MathHelper.floor_double(this.theEntity.posZ)
            );
            if (j < i && !this.func_75413_a(villagedoorinfo1)) {
                villagedoorinfo = villagedoorinfo1;
                i = j;
            }
        }

        return villagedoorinfo;
    }

    private boolean func_75413_a(VillageDoorInfo var1) {
        for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.doorList) {
            if (var1.posX == villagedoorinfo.posX && var1.posY == villagedoorinfo.posY && var1.posZ == villagedoorinfo.posZ) {
                return true;
            }
        }

        return false;
    }

    private void func_75414_f() {
        if (this.doorList.size() > 15) {
            this.doorList.remove(0);
        }
    }
}
