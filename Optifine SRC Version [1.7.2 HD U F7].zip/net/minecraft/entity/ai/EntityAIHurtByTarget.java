package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.util.AxisAlignedBB;

public class EntityAIHurtByTarget extends EntityAITarget {
    boolean entityCallsForHelp;
    private int revengeTimerOld;

    public EntityAIHurtByTarget(EntityCreature var1, boolean var2) {
        super(var1, false);
        this.entityCallsForHelp = var2;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        int i = this.taskOwner.getRevengeTimer();
        return i != this.revengeTimerOld && this.isSuitableTarget(this.taskOwner.getAITarget(), false);
    }

    @Override
    public void startExecuting() {
        this.taskOwner.setAttackTarget(this.taskOwner.getAITarget());
        this.revengeTimerOld = this.taskOwner.getRevengeTimer();
        if (this.entityCallsForHelp) {
            double d0 = this.getTargetDistance();

            for (EntityCreature entitycreature : this.taskOwner
                .worldObj
                .getEntitiesWithinAABB(
                    this.taskOwner.getClass(),
                    AxisAlignedBB.func_72332_a()
                        .func_72299_a(
                            this.taskOwner.posX,
                            this.taskOwner.posY,
                            this.taskOwner.posZ,
                            this.taskOwner.posX + 1.0,
                            this.taskOwner.posY + 1.0,
                            this.taskOwner.posZ + 1.0
                        )
                        .expand(d0, 10.0, d0)
                )) {
                if (this.taskOwner != entitycreature && entitycreature.getAttackTarget() == null && !entitycreature.isOnSameTeam(this.taskOwner.getAITarget())) {
                    entitycreature.setAttackTarget(this.taskOwner.getAITarget());
                }
            }
        }

        super.startExecuting();
    }
}
