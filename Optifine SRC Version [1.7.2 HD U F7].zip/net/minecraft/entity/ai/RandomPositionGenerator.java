package net.minecraft.entity.ai;

import java.util.Random;
import net.minecraft.entity.EntityCreature;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class RandomPositionGenerator {
    private static Vec3 staticVector = Vec3.createVectorHelper(0.0, 0.0, 0.0);

    public static Vec3 findRandomTarget(EntityCreature var0, int var1, int var2) {
        return findRandomTargetBlock(var0, var1, var2, null);
    }

    public static Vec3 findRandomTargetBlockTowards(EntityCreature var0, int var1, int var2, Vec3 var3) {
        staticVector.xCoord = var3.xCoord - var0.posX;
        staticVector.yCoord = var3.yCoord - var0.posY;
        staticVector.zCoord = var3.zCoord - var0.posZ;
        return findRandomTargetBlock(var0, var1, var2, staticVector);
    }

    public static Vec3 findRandomTargetBlockAwayFrom(EntityCreature var0, int var1, int var2, Vec3 var3) {
        staticVector.xCoord = var0.posX - var3.xCoord;
        staticVector.yCoord = var0.posY - var3.yCoord;
        staticVector.zCoord = var0.posZ - var3.zCoord;
        return findRandomTargetBlock(var0, var1, var2, staticVector);
    }

    private static Vec3 findRandomTargetBlock(EntityCreature var0, int var1, int var2, Vec3 var3) {
        Random random = var0.getRNG();
        boolean flag = false;
        int i = 0;
        int j = 0;
        int k = 0;
        float f = -99999.0F;
        boolean flag1;
        if (var0.hasHome()) {
            double d0 = var0.getHomePosition()
                    .getDistanceSquared(MathHelper.floor_double(var0.posX), MathHelper.floor_double(var0.posY), MathHelper.floor_double(var0.posZ))
                + 4.0F;
            double d1 = var0.getMaximumHomeDistance() + var1;
            flag1 = d0 < d1 * d1;
        } else {
            flag1 = false;
        }

        for (int j1 = 0; j1 < 10; j1++) {
            int l = random.nextInt(2 * var1) - var1;
            int k1 = random.nextInt(2 * var2) - var2;
            int i1 = random.nextInt(2 * var1) - var1;
            if (var3 == null || !(l * var3.xCoord + i1 * var3.zCoord < 0.0)) {
                l += MathHelper.floor_double(var0.posX);
                k1 += MathHelper.floor_double(var0.posY);
                i1 += MathHelper.floor_double(var0.posZ);
                if (!flag1 || var0.isWithinHomeDistance(l, k1, i1)) {
                    float f1 = var0.getBlockPathWeight(l, k1, i1);
                    if (f1 > f) {
                        f = f1;
                        i = l;
                        j = k1;
                        k = i1;
                        flag = true;
                    }
                }
            }
        }

        return flag ? var0.worldObj.func_82732_R().func_72345_a(i, j, k) : null;
    }
}
