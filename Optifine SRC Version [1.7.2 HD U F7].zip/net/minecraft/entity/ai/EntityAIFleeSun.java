package net.minecraft.entity.ai;

import java.util.Random;
import net.minecraft.entity.EntityCreature;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EntityAIFleeSun extends EntityAIBase {
    private EntityCreature theCreature;
    private double shelterX;
    private double shelterY;
    private double shelterZ;
    private double movementSpeed;
    private World theWorld;

    public EntityAIFleeSun(EntityCreature var1, double var2) {
        this.theCreature = var1;
        this.movementSpeed = var2;
        this.theWorld = var1.worldObj;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        if (!this.theWorld.isDaytime()) {
            return false;
        }

        if (!this.theCreature.isBurning()) {
            return false;
        }

        if (!this.theWorld
            .canBlockSeeTheSky(
                MathHelper.floor_double(this.theCreature.posX), (int)this.theCreature.boundingBox.minY, MathHelper.floor_double(this.theCreature.posZ)
            )) {
            return false;
        }

        Vec3 vec3 = this.findPossibleShelter();
        if (vec3 == null) {
            return false;
        }

        this.shelterX = vec3.xCoord;
        this.shelterY = vec3.yCoord;
        this.shelterZ = vec3.zCoord;
        return true;
    }

    @Override
    public boolean continueExecuting() {
        return !this.theCreature.getNavigator().noPath();
    }

    @Override
    public void startExecuting() {
        this.theCreature.getNavigator().tryMoveToXYZ(this.shelterX, this.shelterY, this.shelterZ, this.movementSpeed);
    }

    private Vec3 findPossibleShelter() {
        Random random = this.theCreature.getRNG();

        for (int i = 0; i < 10; i++) {
            int j = MathHelper.floor_double(this.theCreature.posX + random.nextInt(20) - 10.0);
            int k = MathHelper.floor_double(this.theCreature.boundingBox.minY + random.nextInt(6) - 3.0);
            int l = MathHelper.floor_double(this.theCreature.posZ + random.nextInt(20) - 10.0);
            if (!this.theWorld.canBlockSeeTheSky(j, k, l) && this.theCreature.getBlockPathWeight(j, k, l) < 0.0F) {
                return this.theWorld.func_82732_R().func_72345_a(j, k, l);
            }
        }

        return null;
    }
}
