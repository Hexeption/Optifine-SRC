package net.minecraft.entity;

import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class EntityLeashKnot extends EntityHanging {
    public EntityLeashKnot(World var1) {
        super(var1);
    }

    public EntityLeashKnot(World var1, int var2, int var3, int var4) {
        super(var1, var2, var3, var4, 0);
        this.setPosition(var2 + 0.5, var3 + 0.5, var4 + 0.5);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
    }

    @Override
    public void setDirection(int var1) {
    }

    @Override
    public int getWidthPixels() {
        return 9;
    }

    @Override
    public int getHeightPixels() {
        return 9;
    }

    @Override
    public boolean isInRangeToRenderDist(double var1) {
        return var1 < 1024.0;
    }

    @Override
    public void onBroken(Entity var1) {
    }

    @Override
    public boolean writeToNBTOptional(NBTTagCompound var1) {
        return false;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        ItemStack itemstack = var1.getHeldItem();
        boolean flag = false;
        if (itemstack != null && itemstack.getItem() == Items.lead && !this.worldObj.isRemote) {
            double d0 = 7.0;
            List list = this.worldObj
                .getEntitiesWithinAABB(
                    EntityLiving.class,
                    AxisAlignedBB.func_72332_a().func_72299_a(this.posX - d0, this.posY - d0, this.posZ - d0, this.posX + d0, this.posY + d0, this.posZ + d0)
                );
            if (list != null) {
                for (EntityLiving entityliving : (Iterable<EntityLiving>) (Iterable) list) {
                    if (entityliving.getLeashed() && entityliving.getLeashedToEntity() == var1) {
                        entityliving.setLeashedToEntity(this, true);
                        flag = true;
                    }
                }
            }
        }

        if (!this.worldObj.isRemote && !flag) {
            this.setDead();
            if (var1.capabilities.isCreativeMode) {
                double d1 = 7.0;
                List list1 = this.worldObj
                    .getEntitiesWithinAABB(
                        EntityLiving.class,
                        AxisAlignedBB.func_72332_a()
                            .func_72299_a(this.posX - d1, this.posY - d1, this.posZ - d1, this.posX + d1, this.posY + d1, this.posZ + d1)
                    );
                if (list1 != null) {
                    for (EntityLiving entityliving1 : (Iterable<EntityLiving>) (Iterable) list1) {
                        if (entityliving1.getLeashed() && entityliving1.getLeashedToEntity() == this) {
                            entityliving1.clearLeashed(true, false);
                        }
                    }
                }
            }
        }

        return true;
    }

    @Override
    public boolean onValidSurface() {
        return this.worldObj.getBlock(this.field_146063_b, this.field_146064_c, this.field_146062_d).getRenderType() == 11;
    }

    public static EntityLeashKnot func_110129_a(World var0, int var1, int var2, int var3) {
        EntityLeashKnot entityleashknot = new EntityLeashKnot(var0, var1, var2, var3);
        entityleashknot.forceSpawn = true;
        var0.spawnEntityInWorld(entityleashknot);
        return entityleashknot;
    }

    public static EntityLeashKnot getKnotForBlock(World var0, int var1, int var2, int var3) {
        List list = var0.getEntitiesWithinAABB(
            EntityLeashKnot.class, AxisAlignedBB.func_72332_a().func_72299_a(var1 - 1.0, var2 - 1.0, var3 - 1.0, var1 + 1.0, var2 + 1.0, var3 + 1.0)
        );
        if (list != null) {
            for (EntityLeashKnot entityleashknot : (Iterable<EntityLeashKnot>) (Iterable) list) {
                if (entityleashknot.field_146063_b == var1 && entityleashknot.field_146064_c == var2 && entityleashknot.field_146062_d == var3) {
                    return entityleashknot;
                }
            }
        }

        return null;
    }
}
