package net.minecraft.entity.item;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRailBase;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EntityMinecartCommandBlock;
import net.minecraft.entity.ai.EntityMinecartMobSpawner;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public abstract class EntityMinecart extends Entity {
    private boolean isInReverse;
    private String entityName;
    private static final int[][][] matrix = new int[][][]{
        {{0, 0, -1}, {0, 0, 1}},
        {{-1, 0, 0}, {1, 0, 0}},
        {{-1, -1, 0}, {1, 0, 0}},
        {{-1, 0, 0}, {1, -1, 0}},
        {{0, 0, -1}, {0, -1, 1}},
        {{0, -1, -1}, {0, 0, 1}},
        {{0, 0, 1}, {1, 0, 0}},
        {{0, 0, 1}, {-1, 0, 0}},
        {{0, 0, -1}, {-1, 0, 0}},
        {{0, 0, -1}, {1, 0, 0}}
    };
    private int turnProgress;
    private double minecartX;
    private double minecartY;
    private double minecartZ;
    private double minecartYaw;
    private double minecartPitch;
    private double velocityX;
    private double velocityY;
    private double velocityZ;

    public EntityMinecart(World var1) {
        super(var1);
        this.preventEntitySpawning = true;
        this.setSize(0.98F, 0.7F);
        this.yOffset = this.height / 2.0F;
    }

    public static EntityMinecart createMinecart(World var0, double var1, double var3, double var5, int var7) {
        switch (var7) {
            case 1:
                return new EntityMinecartChest(var0, var1, var3, var5);
            case 2:
                return new EntityMinecartFurnace(var0, var1, var3, var5);
            case 3:
                return new EntityMinecartTNT(var0, var1, var3, var5);
            case 4:
                return new EntityMinecartMobSpawner(var0, var1, var3, var5);
            case 5:
                return new EntityMinecartHopper(var0, var1, var3, var5);
            case 6:
                return new EntityMinecartCommandBlock(var0, var1, var3, var5);
            default:
                return new EntityMinecartEmpty(var0, var1, var3, var5);
        }
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    @Override
    protected void entityInit() {
        this.dataWatcher.addObject(17, new Integer(0));
        this.dataWatcher.addObject(18, new Integer(1));
        this.dataWatcher.addObject(19, new Float(0.0F));
        this.dataWatcher.addObject(20, new Integer(0));
        this.dataWatcher.addObject(21, new Integer(6));
        this.dataWatcher.addObject(22, (byte)0);
    }

    @Override
    public AxisAlignedBB getCollisionBox(Entity var1) {
        return var1.canBePushed() ? var1.boundingBox : null;
    }

    @Override
    public AxisAlignedBB getBoundingBox() {
        return null;
    }

    @Override
    public boolean canBePushed() {
        return true;
    }

    public EntityMinecart(World var1, double var2, double var4, double var6) {
        this(var1);
        this.setPosition(var2, var4, var6);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.prevPosX = var2;
        this.prevPosY = var4;
        this.prevPosZ = var6;
    }

    @Override
    public double getMountedYOffset() {
        return this.height * 0.0 - 0.3F;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.worldObj.isRemote || this.isDead) {
            return true;
        }

        if (this.isEntityInvulnerable()) {
            return false;
        }

        this.setRollingDirection(-this.getRollingDirection());
        this.setRollingAmplitude(10);
        this.setBeenAttacked();
        this.setDamage(this.getDamage() + var2 * 10.0F);
        boolean flag = var1.getEntity() instanceof EntityPlayer && ((EntityPlayer)var1.getEntity()).capabilities.isCreativeMode;
        if (flag || this.getDamage() > 40.0F) {
            if (this.riddenByEntity != null) {
                this.riddenByEntity.mountEntity(this);
            }

            if (flag && !this.isCustomInventoryName()) {
                this.setDead();
            } else {
                this.killMinecart(var1);
            }
        }

        return true;
    }

    public void killMinecart(DamageSource var1) {
        this.setDead();
        ItemStack itemstack = new ItemStack(Items.minecart, 1);
        if (this.entityName != null) {
            itemstack.setStackDisplayName(this.entityName);
        }

        this.entityDropItem(itemstack, 0.0F);
    }

    @Override
    public void performHurtAnimation() {
        this.setRollingDirection(-this.getRollingDirection());
        this.setRollingAmplitude(10);
        this.setDamage(this.getDamage() + this.getDamage() * 10.0F);
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public void setDead() {
        super.setDead();
    }

    @Override
    public void onUpdate() {
        if (this.getRollingAmplitude() > 0) {
            this.setRollingAmplitude(this.getRollingAmplitude() - 1);
        }

        if (this.getDamage() > 0.0F) {
            this.setDamage(this.getDamage() - 1.0F);
        }

        if (this.posY < -64.0) {
            this.kill();
        }

        if (!this.worldObj.isRemote && this.worldObj instanceof WorldServer) {
            this.worldObj.theProfiler.startSection("portal");
            MinecraftServer minecraftserver = ((WorldServer)this.worldObj).func_73046_m();
            int i = this.getMaxInPortalTime();
            if (this.inPortal) {
                if (minecraftserver.getAllowNether()) {
                    if (this.ridingEntity == null && this.portalCounter++ >= i) {
                        this.portalCounter = i;
                        this.timeUntilPortal = this.getPortalCooldown();
                        byte b0;
                        if (this.worldObj.provider.dimensionId == -1) {
                            b0 = 0;
                        } else {
                            b0 = -1;
                        }

                        this.travelToDimension(b0);
                    }

                    this.inPortal = false;
                }
            } else {
                if (this.portalCounter > 0) {
                    this.portalCounter -= 4;
                }

                if (this.portalCounter < 0) {
                    this.portalCounter = 0;
                }
            }

            if (this.timeUntilPortal > 0) {
                this.timeUntilPortal--;
            }

            this.worldObj.theProfiler.endSection();
        }

        if (this.worldObj.isRemote) {
            if (this.turnProgress > 0) {
                double d6 = this.posX + (this.minecartX - this.posX) / this.turnProgress;
                double d7 = this.posY + (this.minecartY - this.posY) / this.turnProgress;
                double d1 = this.posZ + (this.minecartZ - this.posZ) / this.turnProgress;
                double d3 = MathHelper.wrapAngleTo180_double(this.minecartYaw - this.rotationYaw);
                this.rotationYaw = (float)(this.rotationYaw + d3 / this.turnProgress);
                this.rotationPitch = (float)(this.rotationPitch + (this.minecartPitch - this.rotationPitch) / this.turnProgress);
                this.turnProgress--;
                this.setPosition(d6, d7, d1);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            } else {
                this.setPosition(this.posX, this.posY, this.posZ);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            }
        } else {
            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
            this.motionY -= 0.04F;
            int l = MathHelper.floor_double(this.posX);
            int i1 = MathHelper.floor_double(this.posY);
            int j1 = MathHelper.floor_double(this.posZ);
            if (BlockRailBase.isRailBlockAt(this.worldObj, l, i1 - 1, j1)) {
                i1--;
            }

            double d0 = 0.4;
            double d2 = 1.0 / 128.0;
            Block block = this.worldObj.getBlock(l, i1, j1);
            if (BlockRailBase.isRailBlock(block)) {
                int j = this.worldObj.getBlockMetadata(l, i1, j1);
                this.func_145821_a(l, i1, j1, d0, d2, block, j);
                if (block == Blocks.activator_rail) {
                    this.onActivatorRailPass(l, i1, j1, (j & 8) != 0);
                }
            } else {
                this.func_94088_b(d0);
            }

            this.doBlockCollisions();
            this.rotationPitch = 0.0F;
            double d8 = this.prevPosX - this.posX;
            double d4 = this.prevPosZ - this.posZ;
            if (d8 * d8 + d4 * d4 > 0.001) {
                this.rotationYaw = (float)(Math.atan2(d4, d8) * 180.0 / Math.PI);
                if (this.isInReverse) {
                    this.rotationYaw += 180.0F;
                }
            }

            double d5 = MathHelper.wrapAngleTo180_float(this.rotationYaw - this.prevRotationYaw);
            if (d5 < -170.0 || d5 >= 170.0) {
                this.rotationYaw += 180.0F;
                this.isInReverse = !this.isInReverse;
            }

            this.setRotation(this.rotationYaw, this.rotationPitch);
            List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.2F, 0.0, 0.2F));
            if (list != null && !list.isEmpty()) {
                for (int k = 0; k < list.size(); k++) {
                    Entity entity = (Entity)list.get(k);
                    if (entity != this.riddenByEntity && entity.canBePushed() && entity instanceof EntityMinecart) {
                        entity.applyEntityCollision(this);
                    }
                }
            }

            if (this.riddenByEntity != null && this.riddenByEntity.isDead) {
                if (this.riddenByEntity.ridingEntity == this) {
                    this.riddenByEntity.ridingEntity = null;
                }

                this.riddenByEntity = null;
            }
        }
    }

    public void onActivatorRailPass(int var1, int var2, int var3, boolean var4) {
    }

    protected void func_94088_b(double var1) {
        if (this.motionX < -var1) {
            this.motionX = -var1;
        }

        if (this.motionX > var1) {
            this.motionX = var1;
        }

        if (this.motionZ < -var1) {
            this.motionZ = -var1;
        }

        if (this.motionZ > var1) {
            this.motionZ = var1;
        }

        if (this.onGround) {
            this.motionX *= 0.5;
            this.motionY *= 0.5;
            this.motionZ *= 0.5;
        }

        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        if (!this.onGround) {
            this.motionX *= 0.95F;
            this.motionY *= 0.95F;
            this.motionZ *= 0.95F;
        }
    }

    protected void func_145821_a(int var1, int var2, int var3, double var4, double var6, Block var8, int var9) {
        this.fallDistance = 0.0F;
        Vec3 vec3 = this.func_70489_a(this.posX, this.posY, this.posZ);
        this.posY = var2;
        boolean flag = false;
        boolean flag1 = false;
        if (var8 == Blocks.golden_rail) {
            flag = (var9 & 8) != 0;
            flag1 = !flag;
        }

        if (((BlockRailBase)var8).isPowered()) {
            var9 &= 7;
        }

        if (var9 >= 2 && var9 <= 5) {
            this.posY = var2 + 1;
        }

        if (var9 == 2) {
            this.motionX -= var6;
        }

        if (var9 == 3) {
            this.motionX += var6;
        }

        if (var9 == 4) {
            this.motionZ += var6;
        }

        if (var9 == 5) {
            this.motionZ -= var6;
        }

        int[][] aint = matrix[var9];
        double d0 = aint[1][0] - aint[0][0];
        double d1 = aint[1][2] - aint[0][2];
        double d2 = Math.sqrt(d0 * d0 + d1 * d1);
        double d3 = this.motionX * d0 + this.motionZ * d1;
        if (d3 < 0.0) {
            d0 = -d0;
            d1 = -d1;
        }

        double d4 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        if (d4 > 2.0) {
            d4 = 2.0;
        }

        this.motionX = d4 * d0 / d2;
        this.motionZ = d4 * d1 / d2;
        if (this.riddenByEntity != null && this.riddenByEntity instanceof EntityLivingBase) {
            double d5 = ((EntityLivingBase)this.riddenByEntity).moveForward;
            if (d5 > 0.0) {
                double d6 = -Math.sin(this.riddenByEntity.rotationYaw * (float)Math.PI / 180.0F);
                double d7 = Math.cos(this.riddenByEntity.rotationYaw * (float)Math.PI / 180.0F);
                double d8 = this.motionX * this.motionX + this.motionZ * this.motionZ;
                if (d8 < 0.01) {
                    this.motionX += d6 * 0.1;
                    this.motionZ += d7 * 0.1;
                    flag1 = false;
                }
            }
        }

        if (flag1) {
            double d15 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (d15 < 0.03) {
                this.motionX *= 0.0;
                this.motionY *= 0.0;
                this.motionZ *= 0.0;
            } else {
                this.motionX *= 0.5;
                this.motionY *= 0.0;
                this.motionZ *= 0.5;
            }
        }

        double d16 = 0.0;
        double d17 = var1 + 0.5 + aint[0][0] * 0.5;
        double d18 = var3 + 0.5 + aint[0][2] * 0.5;
        double d19 = var1 + 0.5 + aint[1][0] * 0.5;
        double d9 = var3 + 0.5 + aint[1][2] * 0.5;
        d0 = d19 - d17;
        d1 = d9 - d18;
        if (d0 == 0.0) {
            this.posX = var1 + 0.5;
            d16 = this.posZ - var3;
        } else if (d1 == 0.0) {
            this.posZ = var3 + 0.5;
            d16 = this.posX - var1;
        } else {
            double d10 = this.posX - d17;
            double d11 = this.posZ - d18;
            d16 = (d10 * d0 + d11 * d1) * 2.0;
        }

        this.posX = d17 + d0 * d16;
        this.posZ = d18 + d1 * d16;
        this.setPosition(this.posX, this.posY + this.yOffset, this.posZ);
        double d20 = this.motionX;
        double d21 = this.motionZ;
        if (this.riddenByEntity != null) {
            d20 *= 0.75;
            d21 *= 0.75;
        }

        if (d20 < -var4) {
            d20 = -var4;
        }

        if (d20 > var4) {
            d20 = var4;
        }

        if (d21 < -var4) {
            d21 = -var4;
        }

        if (d21 > var4) {
            d21 = var4;
        }

        this.moveEntity(d20, 0.0, d21);
        if (aint[0][1] != 0 && MathHelper.floor_double(this.posX) - var1 == aint[0][0] && MathHelper.floor_double(this.posZ) - var3 == aint[0][2]) {
            this.setPosition(this.posX, this.posY + aint[0][1], this.posZ);
        } else if (aint[1][1] != 0 && MathHelper.floor_double(this.posX) - var1 == aint[1][0] && MathHelper.floor_double(this.posZ) - var3 == aint[1][2]) {
            this.setPosition(this.posX, this.posY + aint[1][1], this.posZ);
        }

        this.applyDrag();
        Vec3 vec31 = this.func_70489_a(this.posX, this.posY, this.posZ);
        if (vec31 != null && vec3 != null) {
            double d12 = (vec3.yCoord - vec31.yCoord) * 0.05;
            d4 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (d4 > 0.0) {
                this.motionX = this.motionX / d4 * (d4 + d12);
                this.motionZ = this.motionZ / d4 * (d4 + d12);
            }

            this.setPosition(this.posX, vec31.yCoord, this.posZ);
        }

        int j = MathHelper.floor_double(this.posX);
        int i = MathHelper.floor_double(this.posZ);
        if (j != var1 || i != var3) {
            d4 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            this.motionX = d4 * (j - var1);
            this.motionZ = d4 * (i - var3);
        }

        if (flag) {
            double d13 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (d13 > 0.01) {
                double d14 = 0.06;
                this.motionX = this.motionX + this.motionX / d13 * d14;
                this.motionZ = this.motionZ + this.motionZ / d13 * d14;
            } else if (var9 == 1) {
                if (this.worldObj.getBlock(var1 - 1, var2, var3).isNormalCube()) {
                    this.motionX = 0.02;
                } else if (this.worldObj.getBlock(var1 + 1, var2, var3).isNormalCube()) {
                    this.motionX = -0.02;
                }
            } else if (var9 == 0) {
                if (this.worldObj.getBlock(var1, var2, var3 - 1).isNormalCube()) {
                    this.motionZ = 0.02;
                } else if (this.worldObj.getBlock(var1, var2, var3 + 1).isNormalCube()) {
                    this.motionZ = -0.02;
                }
            }
        }
    }

    protected void applyDrag() {
        if (this.riddenByEntity != null) {
            this.motionX *= 0.997F;
            this.motionY *= 0.0;
            this.motionZ *= 0.997F;
        } else {
            this.motionX *= 0.96F;
            this.motionY *= 0.0;
            this.motionZ *= 0.96F;
        }
    }

    public Vec3 func_70495_a(double var1, double var3, double var5, double var7) {
        int i = MathHelper.floor_double(var1);
        int j = MathHelper.floor_double(var3);
        int k = MathHelper.floor_double(var5);
        if (BlockRailBase.isRailBlockAt(this.worldObj, i, j - 1, k)) {
            j--;
        }

        Block block = this.worldObj.getBlock(i, j, k);
        if (!BlockRailBase.isRailBlock(block)) {
            return null;
        }

        int l = this.worldObj.getBlockMetadata(i, j, k);
        if (((BlockRailBase)block).isPowered()) {
            l &= 7;
        }

        var3 = j;
        if (l >= 2 && l <= 5) {
            var3 = j + 1;
        }

        int[][] aint = matrix[l];
        double d0 = aint[1][0] - aint[0][0];
        double d1 = aint[1][2] - aint[0][2];
        double d2 = Math.sqrt(d0 * d0 + d1 * d1);
        d0 /= d2;
        d1 /= d2;
        var1 += d0 * var7;
        var5 += d1 * var7;
        if (aint[0][1] != 0 && MathHelper.floor_double(var1) - i == aint[0][0] && MathHelper.floor_double(var5) - k == aint[0][2]) {
            var3 += aint[0][1];
        } else if (aint[1][1] != 0 && MathHelper.floor_double(var1) - i == aint[1][0] && MathHelper.floor_double(var5) - k == aint[1][2]) {
            var3 += aint[1][1];
        }

        return this.func_70489_a(var1, var3, var5);
    }

    public Vec3 func_70489_a(double var1, double var3, double var5) {
        int i = MathHelper.floor_double(var1);
        int j = MathHelper.floor_double(var3);
        int k = MathHelper.floor_double(var5);
        if (BlockRailBase.isRailBlockAt(this.worldObj, i, j - 1, k)) {
            j--;
        }

        Block block = this.worldObj.getBlock(i, j, k);
        if (BlockRailBase.isRailBlock(block)) {
            int l = this.worldObj.getBlockMetadata(i, j, k);
            var3 = j;
            if (((BlockRailBase)block).isPowered()) {
                l &= 7;
            }

            if (l >= 2 && l <= 5) {
                var3 = j + 1;
            }

            int[][] aint = matrix[l];
            double d0 = 0.0;
            double d1 = i + 0.5 + aint[0][0] * 0.5;
            double d2 = j + 0.5 + aint[0][1] * 0.5;
            double d3 = k + 0.5 + aint[0][2] * 0.5;
            double d4 = i + 0.5 + aint[1][0] * 0.5;
            double d5 = j + 0.5 + aint[1][1] * 0.5;
            double d6 = k + 0.5 + aint[1][2] * 0.5;
            double d7 = d4 - d1;
            double d8 = (d5 - d2) * 2.0;
            double d9 = d6 - d3;
            if (d7 == 0.0) {
                var1 = i + 0.5;
                d0 = var5 - k;
            } else if (d9 == 0.0) {
                var5 = k + 0.5;
                d0 = var1 - i;
            } else {
                double d10 = var1 - d1;
                double d11 = var5 - d3;
                d0 = (d10 * d7 + d11 * d9) * 2.0;
            }

            var1 = d1 + d7 * d0;
            var3 = d2 + d8 * d0;
            var5 = d3 + d9 * d0;
            if (d8 < 0.0) {
                var3++;
            }

            if (d8 > 0.0) {
                var3 += 0.5;
            }

            return this.worldObj.func_82732_R().func_72345_a(var1, var3, var5);
        } else {
            return null;
        }
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        if (var1.getBoolean("CustomDisplayTile")) {
            this.func_145819_k(var1.getInteger("DisplayTile"));
            this.setDisplayTileData(var1.getInteger("DisplayData"));
            this.setDisplayTileOffset(var1.getInteger("DisplayOffset"));
        }

        if (var1.hasKey("CustomName", 8) && var1.getString("CustomName").length() > 0) {
            this.entityName = var1.getString("CustomName");
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        if (this.hasDisplayTile()) {
            var1.setBoolean("CustomDisplayTile", true);
            var1.setInteger("DisplayTile", this.getDisplayTile().getMaterial() == Material.air ? 0 : Block.getIdFromBlock(this.getDisplayTile()));
            var1.setInteger("DisplayData", this.getDisplayTileData());
            var1.setInteger("DisplayOffset", this.getDisplayTileOffset());
        }

        if (this.entityName != null && this.entityName.length() > 0) {
            var1.setString("CustomName", this.entityName);
        }
    }

    @Override
    public float getShadowSize() {
        return 0.0F;
    }

    @Override
    public void applyEntityCollision(Entity var1) {
        if (!this.worldObj.isRemote) {
            if (var1 != this.riddenByEntity) {
                if (var1 instanceof EntityLivingBase
                    && !(var1 instanceof EntityPlayer)
                    && !(var1 instanceof EntityIronGolem)
                    && this.getMinecartType() == 0
                    && this.motionX * this.motionX + this.motionZ * this.motionZ > 0.01
                    && this.riddenByEntity == null
                    && var1.ridingEntity == null) {
                    var1.mountEntity(this);
                }

                double d0 = var1.posX - this.posX;
                double d1 = var1.posZ - this.posZ;
                double d2 = d0 * d0 + d1 * d1;
                if (d2 >= 1.0E-4F) {
                    d2 = MathHelper.sqrt_double(d2);
                    d0 /= d2;
                    d1 /= d2;
                    double d3 = 1.0 / d2;
                    if (d3 > 1.0) {
                        d3 = 1.0;
                    }

                    d0 *= d3;
                    d1 *= d3;
                    d0 *= 0.1F;
                    d1 *= 0.1F;
                    d0 *= 1.0F - this.entityCollisionReduction;
                    d1 *= 1.0F - this.entityCollisionReduction;
                    d0 *= 0.5;
                    d1 *= 0.5;
                    if (var1 instanceof EntityMinecart) {
                        double d4 = var1.posX - this.posX;
                        double d5 = var1.posZ - this.posZ;
                        Vec3 vec3 = this.worldObj.func_82732_R().func_72345_a(d4, 0.0, d5).normalize();
                        Vec3 vec31 = this.worldObj
                            .func_82732_R()
                            .func_72345_a(
                                MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F), 0.0, MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F)
                            )
                            .normalize();
                        double d6 = Math.abs(vec3.dotProduct(vec31));
                        if (d6 < 0.8F) {
                            return;
                        }

                        double d7 = var1.motionX + this.motionX;
                        double d8 = var1.motionZ + this.motionZ;
                        if (((EntityMinecart)var1).getMinecartType() == 2 && this.getMinecartType() != 2) {
                            this.motionX *= 0.2F;
                            this.motionZ *= 0.2F;
                            this.addVelocity(var1.motionX - d0, 0.0, var1.motionZ - d1);
                            var1.motionX *= 0.95F;
                            var1.motionZ *= 0.95F;
                        } else if (((EntityMinecart)var1).getMinecartType() != 2 && this.getMinecartType() == 2) {
                            var1.motionX *= 0.2F;
                            var1.motionZ *= 0.2F;
                            var1.addVelocity(this.motionX + d0, 0.0, this.motionZ + d1);
                            this.motionX *= 0.95F;
                            this.motionZ *= 0.95F;
                        } else {
                            d7 /= 2.0;
                            d8 /= 2.0;
                            this.motionX *= 0.2F;
                            this.motionZ *= 0.2F;
                            this.addVelocity(d7 - d0, 0.0, d8 - d1);
                            var1.motionX *= 0.2F;
                            var1.motionZ *= 0.2F;
                            var1.addVelocity(d7 + d0, 0.0, d8 + d1);
                        }
                    } else {
                        this.addVelocity(-d0, 0.0, -d1);
                        var1.addVelocity(d0 / 4.0, 0.0, d1 / 4.0);
                    }
                }
            }
        }
    }

    @Override
    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9) {
        this.minecartX = var1;
        this.minecartY = var3;
        this.minecartZ = var5;
        this.minecartYaw = var7;
        this.minecartPitch = var8;
        this.turnProgress = var9 + 2;
        this.motionX = this.velocityX;
        this.motionY = this.velocityY;
        this.motionZ = this.velocityZ;
    }

    @Override
    public void setVelocity(double var1, double var3, double var5) {
        this.velocityX = this.motionX = var1;
        this.velocityY = this.motionY = var3;
        this.velocityZ = this.motionZ = var5;
    }

    public void setDamage(float var1) {
        this.dataWatcher.updateObject(19, var1);
    }

    public float getDamage() {
        return this.dataWatcher.getWatchableObjectFloat(19);
    }

    public void setRollingAmplitude(int var1) {
        this.dataWatcher.updateObject(17, var1);
    }

    public int getRollingAmplitude() {
        return this.dataWatcher.getWatchableObjectInt(17);
    }

    public void setRollingDirection(int var1) {
        this.dataWatcher.updateObject(18, var1);
    }

    public int getRollingDirection() {
        return this.dataWatcher.getWatchableObjectInt(18);
    }

    public abstract int getMinecartType();

    public Block getDisplayTile() {
        if (!this.hasDisplayTile()) {
            return this.getDefaultDisplayTile();
        }

        int i = this.getDataWatcher().getWatchableObjectInt(20) & 65535;
        return Block.getBlockById(i);
    }

    public Block getDefaultDisplayTile() {
        return Blocks.air;
    }

    public int getDisplayTileData() {
        return !this.hasDisplayTile() ? this.getDefaultDisplayTileData() : this.getDataWatcher().getWatchableObjectInt(20) >> 16;
    }

    public int getDefaultDisplayTileData() {
        return 0;
    }

    public int getDisplayTileOffset() {
        return !this.hasDisplayTile() ? this.getDefaultDisplayTileOffset() : this.getDataWatcher().getWatchableObjectInt(21);
    }

    public int getDefaultDisplayTileOffset() {
        return 6;
    }

    public void func_145819_k(int var1) {
        this.getDataWatcher().updateObject(20, var1 & 65535 | this.getDisplayTileData() << 16);
        this.setHasDisplayTile(true);
    }

    public void setDisplayTileData(int var1) {
        this.getDataWatcher().updateObject(20, Block.getIdFromBlock(this.getDisplayTile()) & 65535 | var1 << 16);
        this.setHasDisplayTile(true);
    }

    public void setDisplayTileOffset(int var1) {
        this.getDataWatcher().updateObject(21, var1);
        this.setHasDisplayTile(true);
    }

    public boolean hasDisplayTile() {
        return this.getDataWatcher().getWatchableObjectByte(22) == 1;
    }

    public void setHasDisplayTile(boolean var1) {
        this.getDataWatcher().updateObject(22, (byte)(var1 ? 1 : 0));
    }

    public void setMinecartName(String var1) {
        this.entityName = var1;
    }

    @Override
    public String getCommandSenderName() {
        return this.entityName != null ? this.entityName : super.getCommandSenderName();
    }

    public boolean isCustomInventoryName() {
        return this.entityName != null;
    }

    public String func_95999_t() {
        return this.entityName;
    }
}
