package net.minecraft.entity.passive;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollowParent;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAIRunAroundLikeCrazy;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.AnimalChest;
import net.minecraft.inventory.IInvBasic;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.potion.Potion;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public class EntityHorse extends EntityAnimal implements IInvBasic {
    private static final IEntitySelector horseBreedingSelector = new IEntitySelector() {
        @Override
        public boolean isEntityApplicable(Entity var1) {
            return var1 instanceof EntityHorse && ((EntityHorse)var1).func_110205_ce();
        }
    };
    private static final IAttribute horseJumpStrength = new RangedAttribute("horse.jumpStrength", 0.7, 0.0, 2.0)
        .setDescription("Jump Strength")
        .setShouldWatch(true);
    private static final String[] horseArmorTextures = new String[]{
        null,
        "textures/entity/horse/armor/horse_armor_iron.png",
        "textures/entity/horse/armor/horse_armor_gold.png",
        "textures/entity/horse/armor/horse_armor_diamond.png"
    };
    private static final String[] field_110273_bx = new String[]{"", "meo", "goo", "dio"};
    private static final int[] armorValues = new int[]{0, 5, 7, 11};
    private static final String[] horseTextures = new String[]{
        "textures/entity/horse/horse_white.png",
        "textures/entity/horse/horse_creamy.png",
        "textures/entity/horse/horse_chestnut.png",
        "textures/entity/horse/horse_brown.png",
        "textures/entity/horse/horse_black.png",
        "textures/entity/horse/horse_gray.png",
        "textures/entity/horse/horse_darkbrown.png"
    };
    private static final String[] field_110269_bA = new String[]{"hwh", "hcr", "hch", "hbr", "hbl", "hgr", "hdb"};
    private static final String[] horseMarkingTextures = new String[]{
        null,
        "textures/entity/horse/horse_markings_white.png",
        "textures/entity/horse/horse_markings_whitefield.png",
        "textures/entity/horse/horse_markings_whitedots.png",
        "textures/entity/horse/horse_markings_blackdots.png"
    };
    private static final String[] field_110292_bC = new String[]{"", "wo_", "wmo", "wdo", "bdo"};
    private int eatingHaystackCounter;
    private int openMouthCounter;
    private int jumpRearingCounter;
    public int field_110278_bp;
    public int field_110279_bq;
    protected boolean horseJumping;
    private AnimalChest horseChest;
    private boolean hasReproduced;
    protected int temper;
    protected float jumpPower;
    private boolean field_110294_bI;
    private float headLean;
    private float prevHeadLean;
    private float rearingAmount;
    private float prevRearingAmount;
    private float mouthOpenness;
    private float prevMouthOpenness;
    private int gallopTime;
    private String field_110286_bQ;
    private String[] field_110280_bR = new String[3];

    public EntityHorse(World var1) {
        super(var1);
        this.setSize(1.4F, 1.6F);
        this.isImmuneToFire = false;
        this.setChested(false);
        this.getNavigator().setAvoidsWater(true);
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAIPanic(this, 1.2));
        this.tasks.addTask(1, new EntityAIRunAroundLikeCrazy(this, 1.2));
        this.tasks.addTask(2, new EntityAIMate(this, 1.0));
        this.tasks.addTask(4, new EntityAIFollowParent(this, 1.0));
        this.tasks.addTask(6, new EntityAIWander(this, 0.7));
        this.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
        this.tasks.addTask(8, new EntityAILookIdle(this));
        this.func_110226_cD();
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, 0);
        this.dataWatcher.addObject(19, (byte)0);
        this.dataWatcher.addObject(20, 0);
        this.dataWatcher.addObject(21, String.valueOf(""));
        this.dataWatcher.addObject(22, 0);
    }

    public void setHorseType(int var1) {
        this.dataWatcher.updateObject(19, (byte)var1);
        this.func_110230_cF();
    }

    public int getHorseType() {
        return this.dataWatcher.getWatchableObjectByte(19);
    }

    public void setHorseVariant(int var1) {
        this.dataWatcher.updateObject(20, var1);
        this.func_110230_cF();
    }

    public int getHorseVariant() {
        return this.dataWatcher.getWatchableObjectInt(20);
    }

    @Override
    public String getCommandSenderName() {
        if (this.hasCustomNameTag()) {
            return this.getCustomNameTag();
        }

        int i = this.getHorseType();
        switch (i) {
            case 0:
            default:
                return StatCollector.translateToLocal("entity.horse.name");
            case 1:
                return StatCollector.translateToLocal("entity.donkey.name");
            case 2:
                return StatCollector.translateToLocal("entity.mule.name");
            case 3:
                return StatCollector.translateToLocal("entity.zombiehorse.name");
            case 4:
                return StatCollector.translateToLocal("entity.skeletonhorse.name");
        }
    }

    private boolean getHorseWatchableBoolean(int var1) {
        return (this.dataWatcher.getWatchableObjectInt(16) & var1) != 0;
    }

    private void setHorseWatchableBoolean(int var1, boolean var2) {
        int i = this.dataWatcher.getWatchableObjectInt(16);
        if (var2) {
            this.dataWatcher.updateObject(16, i | var1);
        } else {
            this.dataWatcher.updateObject(16, i & ~var1);
        }
    }

    public boolean isAdultHorse() {
        return !this.isChild();
    }

    public boolean isTame() {
        return this.getHorseWatchableBoolean(2);
    }

    public boolean func_110253_bW() {
        return this.isAdultHorse();
    }

    public String func_142019_cb() {
        return this.dataWatcher.getWatchableObjectString(21);
    }

    public void func_110213_b(String var1) {
        this.dataWatcher.updateObject(21, var1);
    }

    public float getHorseSize() {
        int i = this.getGrowingAge();
        return i >= 0 ? 1.0F : 0.5F + (-24000 - i) / -24000.0F * 0.5F;
    }

    @Override
    public void setScaleForAge(boolean var1) {
        if (var1) {
            this.setScale(this.getHorseSize());
        } else {
            this.setScale(1.0F);
        }
    }

    public boolean isHorseJumping() {
        return this.horseJumping;
    }

    public void setHorseTamed(boolean var1) {
        this.setHorseWatchableBoolean(2, var1);
    }

    public void setHorseJumping(boolean var1) {
        this.horseJumping = var1;
    }

    @Override
    public boolean allowLeashing() {
        return !this.isUndead() && super.allowLeashing();
    }

    @Override
    protected void func_142017_o(float var1) {
        if (var1 > 6.0F && this.isEatingHaystack()) {
            this.setEatingHaystack(false);
        }
    }

    public boolean isChested() {
        return this.getHorseWatchableBoolean(8);
    }

    public int func_110241_cb() {
        return this.dataWatcher.getWatchableObjectInt(22);
    }

    private int getHorseArmorIndex(ItemStack var1) {
        if (var1 == null) {
            return 0;
        } else {
            Item item = var1.getItem();
            if (item == Items.iron_horse_armor) {
                return 1;
            } else if (item == Items.golden_horse_armor) {
                return 2;
            } else {
                return item == Items.diamond_horse_armor ? 3 : 0;
            }
        }
    }

    public boolean isEatingHaystack() {
        return this.getHorseWatchableBoolean(32);
    }

    public boolean isRearing() {
        return this.getHorseWatchableBoolean(64);
    }

    public boolean func_110205_ce() {
        return this.getHorseWatchableBoolean(16);
    }

    public boolean getHasReproduced() {
        return this.hasReproduced;
    }

    public void setHorseArmorStack(ItemStack var1) {
        this.dataWatcher.updateObject(22, this.getHorseArmorIndex(var1));
        this.func_110230_cF();
    }

    public void func_110242_l(boolean var1) {
        this.setHorseWatchableBoolean(16, var1);
    }

    public void setChested(boolean var1) {
        this.setHorseWatchableBoolean(8, var1);
    }

    public void setHasReproduced(boolean var1) {
        this.hasReproduced = var1;
    }

    public void setHorseSaddled(boolean var1) {
        this.setHorseWatchableBoolean(4, var1);
    }

    public int getTemper() {
        return this.temper;
    }

    public void setTemper(int var1) {
        this.temper = var1;
    }

    public int increaseTemper(int var1) {
        int i = MathHelper.clamp_int(this.getTemper() + var1, 0, this.getMaxTemper());
        this.setTemper(i);
        return i;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        Entity entity = var1.getEntity();
        return this.riddenByEntity != null && this.riddenByEntity.equals(entity) ? false : super.attackEntityFrom(var1, var2);
    }

    @Override
    public int getTotalArmorValue() {
        return armorValues[this.func_110241_cb()];
    }

    @Override
    public boolean canBePushed() {
        return this.riddenByEntity == null;
    }

    public boolean prepareChunkForSpawn() {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posZ);
        this.worldObj.getBiomeGenForCoords(i, j);
        return true;
    }

    public void dropChests() {
        if (!this.worldObj.isRemote && this.isChested()) {
            this.dropItem(Item.getItemFromBlock(Blocks.chest), 1);
            this.setChested(false);
        }
    }

    private void func_110266_cB() {
        this.openHorseMouth();
        this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
    }

    @Override
    protected void fall(float var1) {
        if (var1 > 1.0F) {
            this.playSound("mob.horse.land", 0.4F, 1.0F);
        }

        int i = MathHelper.ceiling_float_int(var1 * 0.5F - 3.0F);
        if (i > 0) {
            this.attackEntityFrom(DamageSource.fall, i);
            if (this.riddenByEntity != null) {
                this.riddenByEntity.attackEntityFrom(DamageSource.fall, i);
            }

            Block block = this.worldObj
                .getBlock(
                    MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY - 0.2 - this.prevRotationYaw), MathHelper.floor_double(this.posZ)
                );
            if (block.getMaterial() != Material.air) {
                Block.SoundType block$soundtype = block.stepSound;
                this.worldObj
                    .playSoundAtEntity(
                        this, block$soundtype.getStepSound(), block$soundtype.getVolume() * 0.5F, block$soundtype.getFrequency() * (12.0F / 16.0F)
                    );
            }
        }
    }

    private int func_110225_cC() {
        int i = this.getHorseType();
        return !this.isChested() || i != 1 && i != 2 ? 2 : 17;
    }

    private void func_110226_cD() {
        AnimalChest animalchest = this.horseChest;
        this.horseChest = new AnimalChest("HorseChest", this.func_110225_cC());
        this.horseChest.func_110133_a(this.getCommandSenderName());
        if (animalchest != null) {
            animalchest.func_110132_b(this);
            int i = Math.min(animalchest.getSizeInventory(), this.horseChest.getSizeInventory());

            for (int j = 0; j < i; j++) {
                ItemStack itemstack = animalchest.getStackInSlot(j);
                if (itemstack != null) {
                    this.horseChest.setInventorySlotContents(j, itemstack.copy());
                }
            }

            Object object = null;
        }

        this.horseChest.func_110134_a(this);
        this.func_110232_cE();
    }

    private void func_110232_cE() {
        if (!this.worldObj.isRemote) {
            this.setHorseSaddled(this.horseChest.getStackInSlot(0) != null);
            if (this.canWearArmor()) {
                this.setHorseArmorStack(this.horseChest.getStackInSlot(1));
            }
        }
    }

    @Override
    public void onInventoryChanged(InventoryBasic var1) {
        int i = this.func_110241_cb();
        boolean flag = this.isHorseSaddled();
        this.func_110232_cE();
        if (this.ticksExisted > 20) {
            if (i == 0 && i != this.func_110241_cb()) {
                this.playSound("mob.horse.armor", 0.5F, 1.0F);
            } else if (i != this.func_110241_cb()) {
                this.playSound("mob.horse.armor", 0.5F, 1.0F);
            }

            if (!flag && this.isHorseSaddled()) {
                this.playSound("mob.horse.leather", 0.5F, 1.0F);
            }
        }
    }

    @Override
    public boolean getCanSpawnHere() {
        this.prepareChunkForSpawn();
        return super.getCanSpawnHere();
    }

    protected EntityHorse getClosestHorse(Entity var1, double var2) {
        double d0 = Double.MAX_VALUE;
        Entity entity = null;

        for (Entity entity1 : (Iterable<Entity>) (Iterable) this.worldObj.getEntitiesWithinAABBExcludingEntity(var1, var1.boundingBox.addCoord(var2, var2, var2), horseBreedingSelector)) {
            double d1 = entity1.getDistanceSq(var1.posX, var1.posY, var1.posZ);
            if (d1 < d0) {
                entity = entity1;
                d0 = d1;
            }
        }

        return (EntityHorse)entity;
    }

    public double getHorseJumpStrength() {
        return this.getEntityAttribute(horseJumpStrength).getAttributeValue();
    }

    @Override
    protected String getDeathSound() {
        this.openHorseMouth();
        int i = this.getHorseType();
        if (i == 3) {
            return "mob.horse.zombie.death";
        } else if (i == 4) {
            return "mob.horse.skeleton.death";
        } else {
            return i != 1 && i != 2 ? "mob.horse.death" : "mob.horse.donkey.death";
        }
    }

    @Override
    protected Item getDropItem() {
        boolean flag = this.rand.nextInt(4) == 0;
        int i = this.getHorseType();
        if (i == 4) {
            return Items.bone;
        } else if (i == 3) {
            return flag ? Item.getItemById(0) : Items.rotten_flesh;
        } else {
            return Items.leather;
        }
    }

    @Override
    protected String getHurtSound() {
        this.openHorseMouth();
        if (this.rand.nextInt(3) == 0) {
            this.makeHorseRear();
        }

        int i = this.getHorseType();
        if (i == 3) {
            return "mob.horse.zombie.hit";
        } else if (i == 4) {
            return "mob.horse.skeleton.hit";
        } else {
            return i != 1 && i != 2 ? "mob.horse.hit" : "mob.horse.donkey.hit";
        }
    }

    public boolean isHorseSaddled() {
        return this.getHorseWatchableBoolean(4);
    }

    @Override
    protected String getLivingSound() {
        this.openHorseMouth();
        if (this.rand.nextInt(10) == 0 && !this.isMovementBlocked()) {
            this.makeHorseRear();
        }

        int i = this.getHorseType();
        if (i == 3) {
            return "mob.horse.zombie.idle";
        } else if (i == 4) {
            return "mob.horse.skeleton.idle";
        } else {
            return i != 1 && i != 2 ? "mob.horse.idle" : "mob.horse.donkey.idle";
        }
    }

    protected String getAngrySoundName() {
        this.openHorseMouth();
        this.makeHorseRear();
        int i = this.getHorseType();
        if (i == 3 || i == 4) {
            return null;
        } else {
            return i != 1 && i != 2 ? "mob.horse.angry" : "mob.horse.donkey.angry";
        }
    }

    @Override
    protected void playStepSound(int var1, int var2, int var3, Block var4) {
        Block.SoundType block$soundtype = var4.stepSound;
        if (this.worldObj.getBlock(var1, var2 + 1, var3) == Blocks.snow_layer) {
            block$soundtype = Blocks.snow_layer.stepSound;
        }

        if (!var4.getMaterial().isLiquid()) {
            int i = this.getHorseType();
            if (this.riddenByEntity != null && i != 1 && i != 2) {
                this.gallopTime++;
                if (this.gallopTime > 5 && this.gallopTime % 3 == 0) {
                    this.playSound("mob.horse.gallop", block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
                    if (i == 0 && this.rand.nextInt(10) == 0) {
                        this.playSound("mob.horse.breathe", block$soundtype.getVolume() * 0.6F, block$soundtype.getFrequency());
                    }
                } else if (this.gallopTime <= 5) {
                    this.playSound("mob.horse.wood", block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
                }
            } else if (block$soundtype == Block.soundTypeWood) {
                this.playSound("mob.horse.wood", block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
            } else {
                this.playSound("mob.horse.soft", block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
            }
        }
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getAttributeMap().registerAttribute(horseJumpStrength);
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(53.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.225F);
    }

    @Override
    public int getMaxSpawnedInChunk() {
        return 6;
    }

    public int getMaxTemper() {
        return 100;
    }

    @Override
    protected float getSoundVolume() {
        return 0.8F;
    }

    @Override
    public int getTalkInterval() {
        return 400;
    }

    public boolean func_110239_cn() {
        return this.getHorseType() == 0 || this.func_110241_cb() > 0;
    }

    private void func_110230_cF() {
        this.field_110286_bQ = null;
    }

    private void setHorseTexturePaths() {
        this.field_110286_bQ = "horse/";
        this.field_110280_bR[0] = null;
        this.field_110280_bR[1] = null;
        this.field_110280_bR[2] = null;
        int i = this.getHorseType();
        int j = this.getHorseVariant();
        if (i == 0) {
            int k = j & 0xFF;
            int l = (j & 0xFF00) >> 8;
            this.field_110280_bR[0] = horseTextures[k];
            this.field_110286_bQ = this.field_110286_bQ + field_110269_bA[k];
            this.field_110280_bR[1] = horseMarkingTextures[l];
            this.field_110286_bQ = this.field_110286_bQ + field_110292_bC[l];
        } else {
            this.field_110280_bR[0] = "";
            this.field_110286_bQ = this.field_110286_bQ + "_" + i + "_";
        }

        int i1 = this.func_110241_cb();
        this.field_110280_bR[2] = horseArmorTextures[i1];
        this.field_110286_bQ = this.field_110286_bQ + field_110273_bx[i1];
    }

    public String getHorseTexture() {
        if (this.field_110286_bQ == null) {
            this.setHorseTexturePaths();
        }

        return this.field_110286_bQ;
    }

    public String[] getVariantTexturePaths() {
        if (this.field_110286_bQ == null) {
            this.setHorseTexturePaths();
        }

        return this.field_110280_bR;
    }

    public void openGUI(EntityPlayer var1) {
        if (!this.worldObj.isRemote && (this.riddenByEntity == null || this.riddenByEntity == var1) && this.isTame()) {
            this.horseChest.func_110133_a(this.getCommandSenderName());
            var1.displayGUIHorse(this, this.horseChest);
        }
    }

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        if (itemstack != null && itemstack.getItem() == Items.spawn_egg) {
            return super.interact(var1);
        }

        if (!this.isTame() && this.isUndead()) {
            return false;
        }

        if (this.isTame() && this.isAdultHorse() && var1.isSneaking()) {
            this.openGUI(var1);
            return true;
        }

        if (this.func_110253_bW() && this.riddenByEntity != null) {
            return super.interact(var1);
        }

        if (itemstack != null) {
            boolean flag = false;
            if (this.canWearArmor()) {
                byte b0 = -1;
                if (itemstack.getItem() == Items.iron_horse_armor) {
                    b0 = 1;
                } else if (itemstack.getItem() == Items.golden_horse_armor) {
                    b0 = 2;
                } else if (itemstack.getItem() == Items.diamond_horse_armor) {
                    b0 = 3;
                }

                if (b0 >= 0) {
                    if (!this.isTame()) {
                        this.makeHorseRearWithSound();
                        return true;
                    }

                    this.openGUI(var1);
                    return true;
                }
            }

            if (!flag && !this.isUndead()) {
                float f = 0.0F;
                short short1 = 0;
                byte b1 = 0;
                if (itemstack.getItem() == Items.wheat) {
                    f = 2.0F;
                    short1 = 60;
                    b1 = 3;
                } else if (itemstack.getItem() == Items.sugar) {
                    f = 1.0F;
                    short1 = 30;
                    b1 = 3;
                } else if (itemstack.getItem() == Items.bread) {
                    f = 7.0F;
                    short1 = 180;
                    b1 = 3;
                } else if (Block.getBlockFromItem(itemstack.getItem()) == Blocks.hay_block) {
                    f = 20.0F;
                    short1 = 180;
                } else if (itemstack.getItem() == Items.apple) {
                    f = 3.0F;
                    short1 = 60;
                    b1 = 3;
                } else if (itemstack.getItem() == Items.golden_carrot) {
                    f = 4.0F;
                    short1 = 60;
                    b1 = 5;
                    if (this.isTame() && this.getGrowingAge() == 0) {
                        flag = true;
                        this.setInLove(var1);
                    }
                } else if (itemstack.getItem() == Items.golden_apple) {
                    f = 10.0F;
                    short1 = 240;
                    b1 = 10;
                    if (this.isTame() && this.getGrowingAge() == 0) {
                        flag = true;
                        this.setInLove(var1);
                    }
                }

                if (this.getHealth() < this.getMaxHealth() && f > 0.0F) {
                    this.heal(f);
                    flag = true;
                }

                if (!this.isAdultHorse() && short1 > 0) {
                    this.addGrowth(short1);
                    flag = true;
                }

                if (b1 > 0 && (flag || !this.isTame()) && b1 < this.getMaxTemper()) {
                    flag = true;
                    this.increaseTemper(b1);
                }

                if (flag) {
                    this.func_110266_cB();
                }
            }

            if (!this.isTame() && !flag) {
                if (itemstack != null && itemstack.interactWithEntity(var1, this)) {
                    return true;
                }

                this.makeHorseRearWithSound();
                return true;
            }

            if (!flag && this.canCarryChest() && !this.isChested() && itemstack.getItem() == Item.getItemFromBlock(Blocks.chest)) {
                this.setChested(true);
                this.playSound("mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                flag = true;
                this.func_110226_cD();
            }

            if (!flag && this.func_110253_bW() && !this.isHorseSaddled() && itemstack.getItem() == Items.saddle) {
                this.openGUI(var1);
                return true;
            }

            if (flag) {
                if (!var1.capabilities.isCreativeMode && --itemstack.stackSize == 0) {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
                }

                return true;
            }
        }

        if (!this.func_110253_bW() || this.riddenByEntity != null) {
            return super.interact(var1);
        }

        if (itemstack != null && itemstack.interactWithEntity(var1, this)) {
            return true;
        }

        this.func_110237_h(var1);
        return true;
    }

    private void func_110237_h(EntityPlayer var1) {
        var1.rotationYaw = this.rotationYaw;
        var1.rotationPitch = this.rotationPitch;
        this.setEatingHaystack(false);
        this.setRearing(false);
        if (!this.worldObj.isRemote) {
            var1.mountEntity(this);
        }
    }

    public boolean canWearArmor() {
        return this.getHorseType() == 0;
    }

    public boolean canCarryChest() {
        int i = this.getHorseType();
        return i == 2 || i == 1;
    }

    @Override
    protected boolean isMovementBlocked() {
        return this.riddenByEntity != null && this.isHorseSaddled() ? true : this.isEatingHaystack() || this.isRearing();
    }

    public boolean isUndead() {
        int i = this.getHorseType();
        return i == 3 || i == 4;
    }

    public boolean isSterile() {
        return this.isUndead() || this.getHorseType() == 2;
    }

    @Override
    public boolean isBreedingItem(ItemStack var1) {
        return false;
    }

    private void func_110210_cH() {
        this.field_110278_bp = 1;
    }

    @Override
    public void onDeath(DamageSource var1) {
        super.onDeath(var1);
        if (!this.worldObj.isRemote) {
            this.dropChestItems();
        }
    }

    @Override
    public void onLivingUpdate() {
        if (this.rand.nextInt(200) == 0) {
            this.func_110210_cH();
        }

        super.onLivingUpdate();
        if (!this.worldObj.isRemote) {
            if (this.rand.nextInt(900) == 0 && this.deathTime == 0) {
                this.heal(1.0F);
            }

            if (!this.isEatingHaystack()
                && this.riddenByEntity == null
                && this.rand.nextInt(300) == 0
                && this.worldObj.getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY) - 1, MathHelper.floor_double(this.posZ))
                    == Blocks.grass) {
                this.setEatingHaystack(true);
            }

            if (this.isEatingHaystack() && ++this.eatingHaystackCounter > 50) {
                this.eatingHaystackCounter = 0;
                this.setEatingHaystack(false);
            }

            if (this.func_110205_ce() && !this.isAdultHorse() && !this.isEatingHaystack()) {
                EntityHorse entityhorse = this.getClosestHorse(this, 16.0);
                if (entityhorse != null && this.getDistanceSqToEntity(entityhorse) > 4.0) {
                    PathEntity pathentity = this.worldObj.getPathEntityToEntity(this, entityhorse, 16.0F, true, false, false, true);
                    this.setPathToEntity(pathentity);
                }
            }
        }
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.worldObj.isRemote && this.dataWatcher.hasObjectChanged()) {
            this.dataWatcher.func_111144_e();
            this.func_110230_cF();
        }

        if (this.openMouthCounter > 0 && ++this.openMouthCounter > 30) {
            this.openMouthCounter = 0;
            this.setHorseWatchableBoolean(128, false);
        }

        if (!this.worldObj.isRemote && this.jumpRearingCounter > 0 && ++this.jumpRearingCounter > 20) {
            this.jumpRearingCounter = 0;
            this.setRearing(false);
        }

        if (this.field_110278_bp > 0 && ++this.field_110278_bp > 8) {
            this.field_110278_bp = 0;
        }

        if (this.field_110279_bq > 0) {
            this.field_110279_bq++;
            if (this.field_110279_bq > 300) {
                this.field_110279_bq = 0;
            }
        }

        this.prevHeadLean = this.headLean;
        if (this.isEatingHaystack()) {
            this.headLean = this.headLean + ((1.0F - this.headLean) * 0.4F + 0.05F);
            if (this.headLean > 1.0F) {
                this.headLean = 1.0F;
            }
        } else {
            this.headLean = this.headLean + ((0.0F - this.headLean) * 0.4F - 0.05F);
            if (this.headLean < 0.0F) {
                this.headLean = 0.0F;
            }
        }

        this.prevRearingAmount = this.rearingAmount;
        if (this.isRearing()) {
            this.prevHeadLean = this.headLean = 0.0F;
            this.rearingAmount = this.rearingAmount + ((1.0F - this.rearingAmount) * 0.4F + 0.05F);
            if (this.rearingAmount > 1.0F) {
                this.rearingAmount = 1.0F;
            }
        } else {
            this.field_110294_bI = false;
            this.rearingAmount = this.rearingAmount
                + ((0.8F * this.rearingAmount * this.rearingAmount * this.rearingAmount - this.rearingAmount) * 0.6F - 0.05F);
            if (this.rearingAmount < 0.0F) {
                this.rearingAmount = 0.0F;
            }
        }

        this.prevMouthOpenness = this.mouthOpenness;
        if (this.getHorseWatchableBoolean(128)) {
            this.mouthOpenness = this.mouthOpenness + ((1.0F - this.mouthOpenness) * 0.7F + 0.05F);
            if (this.mouthOpenness > 1.0F) {
                this.mouthOpenness = 1.0F;
            }
        } else {
            this.mouthOpenness = this.mouthOpenness + ((0.0F - this.mouthOpenness) * 0.7F - 0.05F);
            if (this.mouthOpenness < 0.0F) {
                this.mouthOpenness = 0.0F;
            }
        }
    }

    private void openHorseMouth() {
        if (!this.worldObj.isRemote) {
            this.openMouthCounter = 1;
            this.setHorseWatchableBoolean(128, true);
        }
    }

    private boolean canMate() {
        return this.riddenByEntity == null
            && this.ridingEntity == null
            && this.isTame()
            && this.isAdultHorse()
            && !this.isSterile()
            && this.getHealth() >= this.getMaxHealth();
    }

    @Override
    public void setEating(boolean var1) {
        this.setHorseWatchableBoolean(32, var1);
    }

    public void setEatingHaystack(boolean var1) {
        this.setEating(var1);
    }

    public void setRearing(boolean var1) {
        if (var1) {
            this.setEatingHaystack(false);
        }

        this.setHorseWatchableBoolean(64, var1);
    }

    private void makeHorseRear() {
        if (!this.worldObj.isRemote) {
            this.jumpRearingCounter = 1;
            this.setRearing(true);
        }
    }

    public void makeHorseRearWithSound() {
        this.makeHorseRear();
        String s = this.getAngrySoundName();
        if (s != null) {
            this.playSound(s, this.getSoundVolume(), this.getSoundPitch());
        }
    }

    public void dropChestItems() {
        this.dropItemsInChest(this, this.horseChest);
        this.dropChests();
    }

    private void dropItemsInChest(Entity var1, AnimalChest var2) {
        if (var2 != null && !this.worldObj.isRemote) {
            for (int i = 0; i < var2.getSizeInventory(); i++) {
                ItemStack itemstack = var2.getStackInSlot(i);
                if (itemstack != null) {
                    this.entityDropItem(itemstack, 0.0F);
                }
            }
        }
    }

    public boolean setTamedBy(EntityPlayer var1) {
        this.func_110213_b(var1.getCommandSenderName());
        this.setHorseTamed(true);
        return true;
    }

    @Override
    public void moveEntityWithHeading(float var1, float var2) {
        if (this.riddenByEntity != null && this.isHorseSaddled()) {
            this.prevRotationYaw = this.rotationYaw = this.riddenByEntity.rotationYaw;
            this.rotationPitch = this.riddenByEntity.rotationPitch * 0.5F;
            this.setRotation(this.rotationYaw, this.rotationPitch);
            this.rotationYawHead = this.renderYawOffset = this.rotationYaw;
            var1 = ((EntityLivingBase)this.riddenByEntity).moveStrafing * 0.5F;
            var2 = ((EntityLivingBase)this.riddenByEntity).moveForward;
            if (var2 <= 0.0F) {
                var2 *= 0.25F;
                this.gallopTime = 0;
            }

            if (this.onGround && this.jumpPower == 0.0F && this.isRearing() && !this.field_110294_bI) {
                var1 = 0.0F;
                var2 = 0.0F;
            }

            if (this.jumpPower > 0.0F && !this.isHorseJumping() && this.onGround) {
                this.motionY = this.getHorseJumpStrength() * this.jumpPower;
                if (this.isPotionActive(Potion.jump)) {
                    this.motionY = this.motionY + (this.getActivePotionEffect(Potion.jump).getAmplifier() + 1) * 0.1F;
                }

                this.setHorseJumping(true);
                this.isAirBorne = true;
                if (var2 > 0.0F) {
                    float f = MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F);
                    float f1 = MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F);
                    this.motionX = this.motionX + -0.4F * f * this.jumpPower;
                    this.motionZ = this.motionZ + 0.4F * f1 * this.jumpPower;
                    this.playSound("mob.horse.jump", 0.4F, 1.0F);
                }

                this.jumpPower = 0.0F;
            }

            this.stepHeight = 1.0F;
            this.jumpMovementFactor = this.getAIMoveSpeed() * 0.1F;
            if (!this.worldObj.isRemote) {
                this.setAIMoveSpeed((float)this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue());
                super.moveEntityWithHeading(var1, var2);
            }

            if (this.onGround) {
                this.jumpPower = 0.0F;
                this.setHorseJumping(false);
            }

            this.prevLimbSwingAmount = this.limbSwingAmount;
            double d1 = this.posX - this.prevPosX;
            double d0 = this.posZ - this.prevPosZ;
            float f2 = MathHelper.sqrt_double(d1 * d1 + d0 * d0) * 4.0F;
            if (f2 > 1.0F) {
                f2 = 1.0F;
            }

            this.limbSwingAmount = this.limbSwingAmount + (f2 - this.limbSwingAmount) * 0.4F;
            this.limbSwing = this.limbSwing + this.limbSwingAmount;
        } else {
            this.stepHeight = 0.5F;
            this.jumpMovementFactor = 0.02F;
            super.moveEntityWithHeading(var1, var2);
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setBoolean("EatingHaystack", this.isEatingHaystack());
        var1.setBoolean("ChestedHorse", this.isChested());
        var1.setBoolean("HasReproduced", this.getHasReproduced());
        var1.setBoolean("Bred", this.func_110205_ce());
        var1.setInteger("Type", this.getHorseType());
        var1.setInteger("Variant", this.getHorseVariant());
        var1.setInteger("Temper", this.getTemper());
        var1.setBoolean("Tame", this.isTame());
        var1.setString("OwnerName", this.func_142019_cb());
        if (this.isChested()) {
            NBTTagList nbttaglist = new NBTTagList();

            for (int i = 2; i < this.horseChest.getSizeInventory(); i++) {
                ItemStack itemstack = this.horseChest.getStackInSlot(i);
                if (itemstack != null) {
                    NBTTagCompound nbttagcompound = new NBTTagCompound();
                    nbttagcompound.setByte("Slot", (byte)i);
                    itemstack.writeToNBT(nbttagcompound);
                    nbttaglist.appendTag(nbttagcompound);
                }
            }

            var1.setTag("Items", nbttaglist);
        }

        if (this.horseChest.getStackInSlot(1) != null) {
            var1.setTag("ArmorItem", this.horseChest.getStackInSlot(1).writeToNBT(new NBTTagCompound()));
        }

        if (this.horseChest.getStackInSlot(0) != null) {
            var1.setTag("SaddleItem", this.horseChest.getStackInSlot(0).writeToNBT(new NBTTagCompound()));
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.setEatingHaystack(var1.getBoolean("EatingHaystack"));
        this.func_110242_l(var1.getBoolean("Bred"));
        this.setChested(var1.getBoolean("ChestedHorse"));
        this.setHasReproduced(var1.getBoolean("HasReproduced"));
        this.setHorseType(var1.getInteger("Type"));
        this.setHorseVariant(var1.getInteger("Variant"));
        this.setTemper(var1.getInteger("Temper"));
        this.setHorseTamed(var1.getBoolean("Tame"));
        if (var1.hasKey("OwnerName", 8)) {
            this.func_110213_b(var1.getString("OwnerName"));
        }

        IAttributeInstance iattributeinstance = this.getAttributeMap().getAttributeInstanceByName("Speed");
        if (iattributeinstance != null) {
            this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(iattributeinstance.getBaseValue() * 0.25);
        }

        if (this.isChested()) {
            NBTTagList nbttaglist = var1.getTagList("Items", 10);
            this.func_110226_cD();

            for (int i = 0; i < nbttaglist.tagCount(); i++) {
                NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
                int j = nbttagcompound.getByte("Slot") & 255;
                if (j >= 2 && j < this.horseChest.getSizeInventory()) {
                    this.horseChest.setInventorySlotContents(j, ItemStack.loadItemStackFromNBT(nbttagcompound));
                }
            }
        }

        if (var1.hasKey("ArmorItem", 10)) {
            ItemStack itemstack = ItemStack.loadItemStackFromNBT(var1.getCompoundTag("ArmorItem"));
            if (itemstack != null && func_146085_a(itemstack.getItem())) {
                this.horseChest.setInventorySlotContents(1, itemstack);
            }
        }

        if (var1.hasKey("SaddleItem", 10)) {
            ItemStack itemstack1 = ItemStack.loadItemStackFromNBT(var1.getCompoundTag("SaddleItem"));
            if (itemstack1 != null && itemstack1.getItem() == Items.saddle) {
                this.horseChest.setInventorySlotContents(0, itemstack1);
            }
        } else if (var1.getBoolean("Saddle")) {
            this.horseChest.setInventorySlotContents(0, new ItemStack(Items.saddle));
        }

        this.func_110232_cE();
    }

    @Override
    public boolean canMateWith(EntityAnimal var1) {
        if (var1 == this) {
            return false;
        } else if (var1.getClass() != this.getClass()) {
            return false;
        } else {
            EntityHorse entityhorse = (EntityHorse)var1;
            if (this.canMate() && entityhorse.canMate()) {
                int i = this.getHorseType();
                int j = entityhorse.getHorseType();
                return i == j || i == 0 && j == 1 || i == 1 && j == 0;
            } else {
                return false;
            }
        }
    }

    @Override
    public EntityAgeable createChild(EntityAgeable var1) {
        EntityHorse entityhorse = (EntityHorse)var1;
        EntityHorse entityhorse1 = new EntityHorse(this.worldObj);
        int i = this.getHorseType();
        int j = entityhorse.getHorseType();
        int k = 0;
        if (i == j) {
            k = i;
        } else if (i == 0 && j == 1 || i == 1 && j == 0) {
            k = 2;
        }

        if (k == 0) {
            int i1 = this.rand.nextInt(9);
            int l;
            if (i1 < 4) {
                l = this.getHorseVariant() & 0xFF;
            } else if (i1 < 8) {
                l = entityhorse.getHorseVariant() & 0xFF;
            } else {
                l = this.rand.nextInt(7);
            }

            int j1 = this.rand.nextInt(5);
            if (j1 < 2) {
                l |= this.getHorseVariant() & 0xFF00;
            } else if (j1 < 4) {
                l |= entityhorse.getHorseVariant() & 0xFF00;
            } else {
                l |= this.rand.nextInt(5) << 8 & 0xFF00;
            }

            entityhorse1.setHorseVariant(l);
        }

        entityhorse1.setHorseType(k);
        double d1 = this.getEntityAttribute(SharedMonsterAttributes.maxHealth).getBaseValue()
            + var1.getEntityAttribute(SharedMonsterAttributes.maxHealth).getBaseValue()
            + this.func_110267_cL();
        entityhorse1.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(d1 / 3.0);
        double d2 = this.getEntityAttribute(horseJumpStrength).getBaseValue()
            + var1.getEntityAttribute(horseJumpStrength).getBaseValue()
            + this.func_110245_cM();
        entityhorse1.getEntityAttribute(horseJumpStrength).setBaseValue(d2 / 3.0);
        double d0 = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getBaseValue()
            + var1.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getBaseValue()
            + this.func_110203_cN();
        entityhorse1.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(d0 / 3.0);
        return entityhorse1;
    }

    @Override
    public IEntityLivingData onSpawnWithEgg(IEntityLivingData var1) {
        var1 = super.onSpawnWithEgg(var1);
        int i = 0;
        int j = 0;
        if (var1 instanceof EntityHorse.GroupData) {
            i = ((EntityHorse.GroupData)var1).field_111107_a;
            j = ((EntityHorse.GroupData)var1).field_111106_b & 0xFF | this.rand.nextInt(5) << 8;
        } else {
            if (this.rand.nextInt(10) == 0) {
                i = 1;
            } else {
                int k = this.rand.nextInt(7);
                int l = this.rand.nextInt(5);
                i = 0;
                j = k | l << 8;
            }

            var1 = new EntityHorse.GroupData(i, j);
        }

        this.setHorseType(i);
        this.setHorseVariant(j);
        if (this.rand.nextInt(5) == 0) {
            this.setGrowingAge(-24000);
        }

        if (i != 4 && i != 3) {
            this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.func_110267_cL());
            if (i == 0) {
                this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(this.func_110203_cN());
            } else {
                this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.175F);
            }
        } else {
            this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(15.0);
            this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.2F);
        }

        if (i != 2 && i != 1) {
            this.getEntityAttribute(horseJumpStrength).setBaseValue(this.func_110245_cM());
        } else {
            this.getEntityAttribute(horseJumpStrength).setBaseValue(0.5);
        }

        this.setHealth(this.getMaxHealth());
        return var1;
    }

    public float getGrassEatingAmount(float var1) {
        return this.prevHeadLean + (this.headLean - this.prevHeadLean) * var1;
    }

    public float getRearingAmount(float var1) {
        return this.prevRearingAmount + (this.rearingAmount - this.prevRearingAmount) * var1;
    }

    public float func_110201_q(float var1) {
        return this.prevMouthOpenness + (this.mouthOpenness - this.prevMouthOpenness) * var1;
    }

    @Override
    protected boolean isAIEnabled() {
        return true;
    }

    public void setJumpPower(int var1) {
        if (this.isHorseSaddled()) {
            if (var1 < 0) {
                var1 = 0;
            } else {
                this.field_110294_bI = true;
                this.makeHorseRear();
            }

            if (var1 >= 90) {
                this.jumpPower = 1.0F;
            } else {
                this.jumpPower = 0.4F + 0.4F * var1 / 90.0F;
            }
        }
    }

    protected void spawnHorseParticles(boolean var1) {
        String s = var1 ? "heart" : "smoke";

        for (int i = 0; i < 7; i++) {
            double d0 = this.rand.nextGaussian() * 0.02;
            double d1 = this.rand.nextGaussian() * 0.02;
            double d2 = this.rand.nextGaussian() * 0.02;
            this.worldObj
                .spawnParticle(
                    s,
                    this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    this.posY + 0.5 + this.rand.nextFloat() * this.height,
                    this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    d0,
                    d1,
                    d2
                );
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 7) {
            this.spawnHorseParticles(true);
        } else if (var1 == 6) {
            this.spawnHorseParticles(false);
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    @Override
    public void updateRiderPosition() {
        super.updateRiderPosition();
        if (this.prevRearingAmount > 0.0F) {
            float f = MathHelper.sin(this.renderYawOffset * (float)Math.PI / 180.0F);
            float f1 = MathHelper.cos(this.renderYawOffset * (float)Math.PI / 180.0F);
            float f2 = 0.7F * this.prevRearingAmount;
            float f3 = 0.15F * this.prevRearingAmount;
            this.riddenByEntity
                .setPosition(this.posX + f2 * f, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset() + f3, this.posZ - f2 * f1);
            if (this.riddenByEntity instanceof EntityLivingBase) {
                ((EntityLivingBase)this.riddenByEntity).renderYawOffset = this.renderYawOffset;
            }
        }
    }

    private float func_110267_cL() {
        return 15.0F + this.rand.nextInt(8) + this.rand.nextInt(9);
    }

    private double func_110245_cM() {
        return 0.4F + this.rand.nextDouble() * 0.2 + this.rand.nextDouble() * 0.2 + this.rand.nextDouble() * 0.2;
    }

    private double func_110203_cN() {
        return (0.45F + this.rand.nextDouble() * 0.3 + this.rand.nextDouble() * 0.3 + this.rand.nextDouble() * 0.3) * 0.25;
    }

    public static boolean func_146085_a(Item var0) {
        return var0 == Items.iron_horse_armor || var0 == Items.golden_horse_armor || var0 == Items.diamond_horse_armor;
    }

    @Override
    public boolean isOnLadder() {
        return false;
    }

    public static class GroupData implements IEntityLivingData {
        public int field_111107_a;
        public int field_111106_b;

        public GroupData(int var1, int var2) {
            this.field_111107_a = var1;
            this.field_111106_b = var2;
        }
    }
}
