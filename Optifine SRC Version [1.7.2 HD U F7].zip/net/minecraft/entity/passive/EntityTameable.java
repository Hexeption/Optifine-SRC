package net.minecraft.entity.passive;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityOwnable;
import net.minecraft.entity.ai.EntityAISit;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.scoreboard.Team;
import net.minecraft.world.World;

public abstract class EntityTameable extends EntityAnimal implements IEntityOwnable {
    protected EntityAISit aiSit = new EntityAISit(this);

    public EntityTameable(World var1) {
        super(var1);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, (byte)0);
        this.dataWatcher.addObject(17, "");
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        if (this.func_70905_p() == null) {
            var1.setString("Owner", "");
        } else {
            var1.setString("Owner", this.func_70905_p());
        }

        var1.setBoolean("Sitting", this.isSitting());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        String s = var1.getString("Owner");
        if (s.length() > 0) {
            this.func_70910_a(s);
            this.setTamed(true);
        }

        this.aiSit.setSitting(var1.getBoolean("Sitting"));
        this.setSitting(var1.getBoolean("Sitting"));
    }

    protected void playTameEffect(boolean var1) {
        String s = "heart";
        if (!var1) {
            s = "smoke";
        }

        for (int i = 0; i < 7; i++) {
            double d0 = this.rand.nextGaussian() * 0.02;
            double d1 = this.rand.nextGaussian() * 0.02;
            double d2 = this.rand.nextGaussian() * 0.02;
            this.worldObj
                .spawnParticle(
                    s,
                    this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    this.posY + 0.5 + this.rand.nextFloat() * this.height,
                    this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    d0,
                    d1,
                    d2
                );
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 7) {
            this.playTameEffect(true);
        } else if (var1 == 6) {
            this.playTameEffect(false);
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    public boolean isTamed() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 4) != 0;
    }

    public void setTamed(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var1) {
            this.dataWatcher.updateObject(16, (byte)(b0 | 4));
        } else {
            this.dataWatcher.updateObject(16, (byte)(b0 & -5));
        }
    }

    public boolean isSitting() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
    }

    public void setSitting(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var1) {
            this.dataWatcher.updateObject(16, (byte)(b0 | 1));
        } else {
            this.dataWatcher.updateObject(16, (byte)(b0 & -2));
        }
    }

    @Override
    public String func_70905_p() {
        return this.dataWatcher.getWatchableObjectString(17);
    }

    public void func_70910_a(String var1) {
        this.dataWatcher.updateObject(17, var1);
    }

    public EntityLivingBase getOwner() {
        return this.worldObj.getPlayerEntityByName(this.func_70905_p());
    }

    public EntityAISit getAISit() {
        return this.aiSit;
    }

    public boolean func_142018_a(EntityLivingBase var1, EntityLivingBase var2) {
        return true;
    }

    @Override
    public Team getTeam() {
        if (this.isTamed()) {
            EntityLivingBase entitylivingbase = this.getOwner();
            if (entitylivingbase != null) {
                return entitylivingbase.getTeam();
            }
        }

        return super.getTeam();
    }

    @Override
    public boolean isOnSameTeam(EntityLivingBase var1) {
        if (this.isTamed()) {
            EntityLivingBase entitylivingbase = this.getOwner();
            if (var1 == entitylivingbase) {
                return true;
            }

            if (entitylivingbase != null) {
                return entitylivingbase.isOnSameTeam(var1);
            }
        }

        return super.isOnSameTeam(var1);
    }
}
