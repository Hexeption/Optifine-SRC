package net.minecraft.entity;

public interface IEntityOwnable {
    String func_70905_p();

    Entity getOwner();
}
