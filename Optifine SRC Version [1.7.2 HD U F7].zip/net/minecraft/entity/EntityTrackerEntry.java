package net.minecraft.entity;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.entity.ai.attributes.ServersideAttributeMap;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderEye;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityPainting;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.entity.projectile.EntityWitherSkull;
import net.minecraft.init.Items;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S04PacketEntityEquipment;
import net.minecraft.network.play.server.S0APacketUseBed;
import net.minecraft.network.play.server.S0CPacketSpawnPlayer;
import net.minecraft.network.play.server.S0EPacketSpawnObject;
import net.minecraft.network.play.server.S0FPacketSpawnMob;
import net.minecraft.network.play.server.S10PacketSpawnPainting;
import net.minecraft.network.play.server.S11PacketSpawnExperienceOrb;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraft.network.play.server.S19PacketEntityHeadLook;
import net.minecraft.network.play.server.S1BPacketEntityAttach;
import net.minecraft.network.play.server.S1CPacketEntityMetadata;
import net.minecraft.network.play.server.S1DPacketEntityEffect;
import net.minecraft.network.play.server.S20PacketEntityProperties;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MathHelper;
import net.minecraft.world.storage.MapData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityTrackerEntry {
    private static final Logger logger = LogManager.getLogger();
    public Entity trackedEntity;
    public int trackingDistanceThreshold;
    public int updateFrequency;
    public int encodedPosX;
    public int encodedPosY;
    public int encodedPosZ;
    public int encodedRotationYaw;
    public int encodedRotationPitch;
    public int lastHeadMotion;
    public double lastTrackedEntityMotionX;
    public double lastTrackedEntityMotionY;
    public double motionZ;
    public int updateCounter;
    private double lastTrackedEntityPosX;
    private double lastTrackedEntityPosY;
    private double lastTrackedEntityPosZ;
    private boolean firstUpdateDone;
    private boolean sendVelocityUpdates;
    private int ticksSinceLastForcedTeleport;
    private Entity field_85178_v;
    private boolean ridingEntity;
    public boolean playerEntitiesUpdated;
    public Set trackingPlayers = new HashSet();

    public EntityTrackerEntry(Entity var1, int var2, int var3, boolean var4) {
        this.trackedEntity = var1;
        this.trackingDistanceThreshold = var2;
        this.updateFrequency = var3;
        this.sendVelocityUpdates = var4;
        this.encodedPosX = MathHelper.floor_double(var1.posX * 32.0);
        this.encodedPosY = MathHelper.floor_double(var1.posY * 32.0);
        this.encodedPosZ = MathHelper.floor_double(var1.posZ * 32.0);
        this.encodedRotationYaw = MathHelper.floor_float(var1.rotationYaw * 256.0F / 360.0F);
        this.encodedRotationPitch = MathHelper.floor_float(var1.rotationPitch * 256.0F / 360.0F);
        this.lastHeadMotion = MathHelper.floor_float(var1.getRotationYawHead() * 256.0F / 360.0F);
    }

    @Override
    public boolean equals(Object var1) {
        return var1 instanceof EntityTrackerEntry ? ((EntityTrackerEntry)var1).trackedEntity.getEntityId() == this.trackedEntity.getEntityId() : false;
    }

    @Override
    public int hashCode() {
        return this.trackedEntity.getEntityId();
    }

    public void updatePlayerList(List var1) {
        this.playerEntitiesUpdated = false;
        if (!this.firstUpdateDone
            || this.trackedEntity.getDistanceSq(this.lastTrackedEntityPosX, this.lastTrackedEntityPosY, this.lastTrackedEntityPosZ) > 16.0) {
            this.lastTrackedEntityPosX = this.trackedEntity.posX;
            this.lastTrackedEntityPosY = this.trackedEntity.posY;
            this.lastTrackedEntityPosZ = this.trackedEntity.posZ;
            this.firstUpdateDone = true;
            this.playerEntitiesUpdated = true;
            this.updatePlayerEntities(var1);
        }

        if (this.field_85178_v != this.trackedEntity.ridingEntity || this.trackedEntity.ridingEntity != null && this.updateCounter % 60 == 0) {
            this.field_85178_v = this.trackedEntity.ridingEntity;
            this.func_151259_a(new S1BPacketEntityAttach(0, this.trackedEntity, this.trackedEntity.ridingEntity));
        }

        if (this.trackedEntity instanceof EntityItemFrame && this.updateCounter % 10 == 0) {
            EntityItemFrame entityitemframe = (EntityItemFrame)this.trackedEntity;
            ItemStack itemstack = entityitemframe.getDisplayedItem();
            if (itemstack != null && itemstack.getItem() instanceof ItemMap) {
                MapData mapdata = Items.filled_map.getMapData(itemstack, this.trackedEntity.worldObj);

                for (EntityPlayer entityplayer : (Iterable<EntityPlayer>) (Iterable) var1) {
                    EntityPlayerMP entityplayermp = (EntityPlayerMP)entityplayer;
                    mapdata.updateVisiblePlayers(entityplayermp, itemstack);
                    Packet packet1 = Items.filled_map.createMapDataPacket(itemstack, this.trackedEntity.worldObj, entityplayermp);
                    if (packet1 != null) {
                        entityplayermp.playerNetServerHandler.sendPacket(packet1);
                    }
                }
            }

            this.sendMetadataToAllAssociatedPlayers();
        } else if (this.updateCounter % this.updateFrequency == 0 || this.trackedEntity.isAirBorne || this.trackedEntity.getDataWatcher().hasObjectChanged()) {
            if (this.trackedEntity.ridingEntity == null) {
                this.ticksSinceLastForcedTeleport++;
                int l1 = this.trackedEntity.myEntitySize.multiplyBy32AndRound(this.trackedEntity.posX);
                int j2 = MathHelper.floor_double(this.trackedEntity.posY * 32.0);
                int k2 = this.trackedEntity.myEntitySize.multiplyBy32AndRound(this.trackedEntity.posZ);
                int k = MathHelper.floor_float(this.trackedEntity.rotationYaw * 256.0F / 360.0F);
                int l = MathHelper.floor_float(this.trackedEntity.rotationPitch * 256.0F / 360.0F);
                int i1 = l1 - this.encodedPosX;
                int j1 = j2 - this.encodedPosY;
                int k1 = k2 - this.encodedPosZ;
                Packet packet = null;
                boolean flag1 = Math.abs(i1) >= 4 || Math.abs(j1) >= 4 || Math.abs(k1) >= 4 || this.updateCounter % 60 == 0;
                boolean flag2 = Math.abs(k - this.encodedRotationYaw) >= 4 || Math.abs(l - this.encodedRotationPitch) >= 4;
                if (this.updateCounter > 0 || this.trackedEntity instanceof EntityArrow) {
                    if (i1 < -128
                        || i1 >= 128
                        || j1 < -128
                        || j1 >= 128
                        || k1 < -128
                        || k1 >= 128
                        || this.ticksSinceLastForcedTeleport > 400
                        || this.ridingEntity) {
                        this.ticksSinceLastForcedTeleport = 0;
                        packet = new S18PacketEntityTeleport(this.trackedEntity.getEntityId(), l1, j2, k2, (byte)k, (byte)l);
                    } else if (flag1 && flag2) {
                        packet = new S14PacketEntity.S17PacketEntityLookMove(this.trackedEntity.getEntityId(), (byte)i1, (byte)j1, (byte)k1, (byte)k, (byte)l);
                    } else if (flag1) {
                        packet = new S14PacketEntity.S15PacketEntityRelMove(this.trackedEntity.getEntityId(), (byte)i1, (byte)j1, (byte)k1);
                    } else if (flag2) {
                        packet = new S14PacketEntity.S16PacketEntityLook(this.trackedEntity.getEntityId(), (byte)k, (byte)l);
                    }
                }

                if (this.sendVelocityUpdates) {
                    double d0 = this.trackedEntity.motionX - this.lastTrackedEntityMotionX;
                    double d1 = this.trackedEntity.motionY - this.lastTrackedEntityMotionY;
                    double d2 = this.trackedEntity.motionZ - this.motionZ;
                    double d3 = 0.02;
                    double d4 = d0 * d0 + d1 * d1 + d2 * d2;
                    if (d4 > d3 * d3 || d4 > 0.0 && this.trackedEntity.motionX == 0.0 && this.trackedEntity.motionY == 0.0 && this.trackedEntity.motionZ == 0.0
                        )
                     {
                        this.lastTrackedEntityMotionX = this.trackedEntity.motionX;
                        this.lastTrackedEntityMotionY = this.trackedEntity.motionY;
                        this.motionZ = this.trackedEntity.motionZ;
                        this.func_151259_a(
                            new S12PacketEntityVelocity(
                                this.trackedEntity.getEntityId(), this.lastTrackedEntityMotionX, this.lastTrackedEntityMotionY, this.motionZ
                            )
                        );
                    }
                }

                if (packet != null) {
                    this.func_151259_a(packet);
                }

                this.sendMetadataToAllAssociatedPlayers();
                if (flag1) {
                    this.encodedPosX = l1;
                    this.encodedPosY = j2;
                    this.encodedPosZ = k2;
                }

                if (flag2) {
                    this.encodedRotationYaw = k;
                    this.encodedRotationPitch = l;
                }

                this.ridingEntity = false;
            } else {
                int i = MathHelper.floor_float(this.trackedEntity.rotationYaw * 256.0F / 360.0F);
                int j = MathHelper.floor_float(this.trackedEntity.rotationPitch * 256.0F / 360.0F);
                boolean flag = Math.abs(i - this.encodedRotationYaw) >= 4 || Math.abs(j - this.encodedRotationPitch) >= 4;
                if (flag) {
                    this.func_151259_a(new S14PacketEntity.S16PacketEntityLook(this.trackedEntity.getEntityId(), (byte)i, (byte)j));
                    this.encodedRotationYaw = i;
                    this.encodedRotationPitch = j;
                }

                this.encodedPosX = this.trackedEntity.myEntitySize.multiplyBy32AndRound(this.trackedEntity.posX);
                this.encodedPosY = MathHelper.floor_double(this.trackedEntity.posY * 32.0);
                this.encodedPosZ = this.trackedEntity.myEntitySize.multiplyBy32AndRound(this.trackedEntity.posZ);
                this.sendMetadataToAllAssociatedPlayers();
                this.ridingEntity = true;
            }

            int i2 = MathHelper.floor_float(this.trackedEntity.getRotationYawHead() * 256.0F / 360.0F);
            if (Math.abs(i2 - this.lastHeadMotion) >= 4) {
                this.func_151259_a(new S19PacketEntityHeadLook(this.trackedEntity, (byte)i2));
                this.lastHeadMotion = i2;
            }

            this.trackedEntity.isAirBorne = false;
        }

        this.updateCounter++;
        if (this.trackedEntity.velocityChanged) {
            this.func_151261_b(new S12PacketEntityVelocity(this.trackedEntity));
            this.trackedEntity.velocityChanged = false;
        }
    }

    private void sendMetadataToAllAssociatedPlayers() {
        DataWatcher datawatcher = this.trackedEntity.getDataWatcher();
        if (datawatcher.hasObjectChanged()) {
            this.func_151261_b(new S1CPacketEntityMetadata(this.trackedEntity.getEntityId(), datawatcher, false));
        }

        if (this.trackedEntity instanceof EntityLivingBase) {
            ServersideAttributeMap serversideattributemap = (ServersideAttributeMap)((EntityLivingBase)this.trackedEntity).getAttributeMap();
            Set set = serversideattributemap.getAttributeInstanceSet();
            if (!set.isEmpty()) {
                this.func_151261_b(new S20PacketEntityProperties(this.trackedEntity.getEntityId(), set));
            }

            set.clear();
        }
    }

    public void func_151259_a(Packet var1) {
        for (EntityPlayerMP entityplayermp : (Iterable<EntityPlayerMP>) (Iterable) this.trackingPlayers) {
            entityplayermp.playerNetServerHandler.sendPacket(var1);
        }
    }

    public void func_151261_b(Packet var1) {
        this.func_151259_a(var1);
        if (this.trackedEntity instanceof EntityPlayerMP) {
            ((EntityPlayerMP)this.trackedEntity).playerNetServerHandler.sendPacket(var1);
        }
    }

    public void sendDestroyEntityPacketToTrackedPlayers() {
        for (EntityPlayerMP entityplayermp : (Iterable<EntityPlayerMP>) (Iterable) this.trackingPlayers) {
            entityplayermp.destroyedItemsNetCache.add(this.trackedEntity.getEntityId());
        }
    }

    public void removeFromTrackedPlayers(EntityPlayerMP var1) {
        if (this.trackingPlayers.contains(var1)) {
            var1.destroyedItemsNetCache.add(this.trackedEntity.getEntityId());
            this.trackingPlayers.remove(var1);
        }
    }

    public void updatePlayerEntity(EntityPlayerMP var1) {
        if (var1 != this.trackedEntity) {
            double d0 = var1.posX - this.encodedPosX / 32;
            double d1 = var1.posZ - this.encodedPosZ / 32;
            if (d0 >= -this.trackingDistanceThreshold
                && d0 <= this.trackingDistanceThreshold
                && d1 >= -this.trackingDistanceThreshold
                && d1 <= this.trackingDistanceThreshold) {
                if (!this.trackingPlayers.contains(var1) && (this.isPlayerWatchingThisChunk(var1) || this.trackedEntity.forceSpawn)) {
                    this.trackingPlayers.add(var1);
                    Packet packet = this.func_151260_c();
                    var1.playerNetServerHandler.sendPacket(packet);
                    if (!this.trackedEntity.getDataWatcher().getIsBlank()) {
                        var1.playerNetServerHandler
                            .sendPacket(new S1CPacketEntityMetadata(this.trackedEntity.getEntityId(), this.trackedEntity.getDataWatcher(), true));
                    }

                    if (this.trackedEntity instanceof EntityLivingBase) {
                        ServersideAttributeMap serversideattributemap = (ServersideAttributeMap)((EntityLivingBase)this.trackedEntity).getAttributeMap();
                        Collection collection = serversideattributemap.getWatchedAttributes();
                        if (!collection.isEmpty()) {
                            var1.playerNetServerHandler.sendPacket(new S20PacketEntityProperties(this.trackedEntity.getEntityId(), collection));
                        }
                    }

                    this.lastTrackedEntityMotionX = this.trackedEntity.motionX;
                    this.lastTrackedEntityMotionY = this.trackedEntity.motionY;
                    this.motionZ = this.trackedEntity.motionZ;
                    if (this.sendVelocityUpdates && !(packet instanceof S0FPacketSpawnMob)) {
                        var1.playerNetServerHandler
                            .sendPacket(
                                new S12PacketEntityVelocity(
                                    this.trackedEntity.getEntityId(), this.trackedEntity.motionX, this.trackedEntity.motionY, this.trackedEntity.motionZ
                                )
                            );
                    }

                    if (this.trackedEntity.ridingEntity != null) {
                        var1.playerNetServerHandler.sendPacket(new S1BPacketEntityAttach(0, this.trackedEntity, this.trackedEntity.ridingEntity));
                    }

                    if (this.trackedEntity instanceof EntityLiving && ((EntityLiving)this.trackedEntity).getLeashedToEntity() != null) {
                        var1.playerNetServerHandler
                            .sendPacket(new S1BPacketEntityAttach(1, this.trackedEntity, ((EntityLiving)this.trackedEntity).getLeashedToEntity()));
                    }

                    if (this.trackedEntity instanceof EntityLivingBase) {
                        for (int i = 0; i < 5; i++) {
                            ItemStack itemstack = ((EntityLivingBase)this.trackedEntity).getEquipmentInSlot(i);
                            if (itemstack != null) {
                                var1.playerNetServerHandler.sendPacket(new S04PacketEntityEquipment(this.trackedEntity.getEntityId(), i, itemstack));
                            }
                        }
                    }

                    if (this.trackedEntity instanceof EntityPlayer) {
                        EntityPlayer entityplayer = (EntityPlayer)this.trackedEntity;
                        if (entityplayer.isPlayerSleeping()) {
                            var1.playerNetServerHandler
                                .sendPacket(
                                    new S0APacketUseBed(
                                        entityplayer,
                                        MathHelper.floor_double(this.trackedEntity.posX),
                                        MathHelper.floor_double(this.trackedEntity.posY),
                                        MathHelper.floor_double(this.trackedEntity.posZ)
                                    )
                                );
                        }
                    }

                    if (this.trackedEntity instanceof EntityLivingBase) {
                        EntityLivingBase entitylivingbase = (EntityLivingBase)this.trackedEntity;

                        for (PotionEffect potioneffect : (Iterable<PotionEffect>) (Iterable) entitylivingbase.getActivePotionEffects()) {
                            var1.playerNetServerHandler.sendPacket(new S1DPacketEntityEffect(this.trackedEntity.getEntityId(), potioneffect));
                        }
                    }
                }
            } else if (this.trackingPlayers.contains(var1)) {
                this.trackingPlayers.remove(var1);
                var1.destroyedItemsNetCache.add(this.trackedEntity.getEntityId());
            }
        }
    }

    private boolean isPlayerWatchingThisChunk(EntityPlayerMP var1) {
        return var1.getServerForPlayer().getPlayerManager().isPlayerWatchingChunk(var1, this.trackedEntity.chunkCoordX, this.trackedEntity.chunkCoordZ);
    }

    public void updatePlayerEntities(List var1) {
        for (int i = 0; i < var1.size(); i++) {
            this.updatePlayerEntity((EntityPlayerMP)var1.get(i));
        }
    }

    private Packet func_151260_c() {
        if (this.trackedEntity.isDead) {
            logger.warn("Fetching addPacket for removed entity");
        }

        if (this.trackedEntity instanceof EntityItem) {
            return new S0EPacketSpawnObject(this.trackedEntity, 2, 1);
        }

        if (this.trackedEntity instanceof EntityPlayerMP) {
            return new S0CPacketSpawnPlayer((EntityPlayer)this.trackedEntity);
        }

        if (this.trackedEntity instanceof EntityMinecart) {
            EntityMinecart entityminecart = (EntityMinecart)this.trackedEntity;
            return new S0EPacketSpawnObject(this.trackedEntity, 10, entityminecart.getMinecartType());
        }

        if (this.trackedEntity instanceof EntityBoat) {
            return new S0EPacketSpawnObject(this.trackedEntity, 1);
        }

        if (this.trackedEntity instanceof IAnimals || this.trackedEntity instanceof EntityDragon) {
            this.lastHeadMotion = MathHelper.floor_float(this.trackedEntity.getRotationYawHead() * 256.0F / 360.0F);
            return new S0FPacketSpawnMob((EntityLivingBase)this.trackedEntity);
        }

        if (this.trackedEntity instanceof EntityFishHook) {
            EntityPlayer entityplayer = ((EntityFishHook)this.trackedEntity).angler;
            return new S0EPacketSpawnObject(this.trackedEntity, 90, entityplayer != null ? entityplayer.getEntityId() : this.trackedEntity.getEntityId());
        }

        if (this.trackedEntity instanceof EntityArrow) {
            Entity entity = ((EntityArrow)this.trackedEntity).shootingEntity;
            return new S0EPacketSpawnObject(this.trackedEntity, 60, entity != null ? entity.getEntityId() : this.trackedEntity.getEntityId());
        }

        if (this.trackedEntity instanceof EntitySnowball) {
            return new S0EPacketSpawnObject(this.trackedEntity, 61);
        }

        if (this.trackedEntity instanceof EntityPotion) {
            return new S0EPacketSpawnObject(this.trackedEntity, 73, ((EntityPotion)this.trackedEntity).getPotionDamage());
        }

        if (this.trackedEntity instanceof EntityExpBottle) {
            return new S0EPacketSpawnObject(this.trackedEntity, 75);
        }

        if (this.trackedEntity instanceof EntityEnderPearl) {
            return new S0EPacketSpawnObject(this.trackedEntity, 65);
        }

        if (this.trackedEntity instanceof EntityEnderEye) {
            return new S0EPacketSpawnObject(this.trackedEntity, 72);
        }

        if (this.trackedEntity instanceof EntityFireworkRocket) {
            return new S0EPacketSpawnObject(this.trackedEntity, 76);
        }

        if (this.trackedEntity instanceof EntityFireball) {
            EntityFireball entityfireball = (EntityFireball)this.trackedEntity;
            S0EPacketSpawnObject s0epacketspawnobject2 = null;
            byte b0 = 63;
            if (this.trackedEntity instanceof EntitySmallFireball) {
                b0 = 64;
            } else if (this.trackedEntity instanceof EntityWitherSkull) {
                b0 = 66;
            }

            if (entityfireball.shootingEntity != null) {
                s0epacketspawnobject2 = new S0EPacketSpawnObject(this.trackedEntity, b0, ((EntityFireball)this.trackedEntity).shootingEntity.getEntityId());
            } else {
                s0epacketspawnobject2 = new S0EPacketSpawnObject(this.trackedEntity, b0, 0);
            }

            s0epacketspawnobject2.func_149003_d((int)(entityfireball.accelerationX * 8000.0));
            s0epacketspawnobject2.func_149000_e((int)(entityfireball.accelerationY * 8000.0));
            s0epacketspawnobject2.func_149007_f((int)(entityfireball.accelerationZ * 8000.0));
            return s0epacketspawnobject2;
        } else if (this.trackedEntity instanceof EntityEgg) {
            return new S0EPacketSpawnObject(this.trackedEntity, 62);
        } else if (this.trackedEntity instanceof EntityTNTPrimed) {
            return new S0EPacketSpawnObject(this.trackedEntity, 50);
        } else if (this.trackedEntity instanceof EntityEnderCrystal) {
            return new S0EPacketSpawnObject(this.trackedEntity, 51);
        } else if (this.trackedEntity instanceof EntityFallingBlock) {
            EntityFallingBlock entityfallingblock = (EntityFallingBlock)this.trackedEntity;
            return new S0EPacketSpawnObject(this.trackedEntity, 70, Block.getIdFromBlock(entityfallingblock.getBlock()) | entityfallingblock.metadata << 16);
        } else if (this.trackedEntity instanceof EntityPainting) {
            return new S10PacketSpawnPainting((EntityPainting)this.trackedEntity);
        } else if (this.trackedEntity instanceof EntityItemFrame) {
            EntityItemFrame entityitemframe = (EntityItemFrame)this.trackedEntity;
            S0EPacketSpawnObject s0epacketspawnobject1 = new S0EPacketSpawnObject(this.trackedEntity, 71, entityitemframe.hangingDirection);
            s0epacketspawnobject1.func_148996_a(MathHelper.floor_float(entityitemframe.field_146063_b * 32));
            s0epacketspawnobject1.func_148995_b(MathHelper.floor_float(entityitemframe.field_146064_c * 32));
            s0epacketspawnobject1.func_149005_c(MathHelper.floor_float(entityitemframe.field_146062_d * 32));
            return s0epacketspawnobject1;
        } else if (this.trackedEntity instanceof EntityLeashKnot) {
            EntityLeashKnot entityleashknot = (EntityLeashKnot)this.trackedEntity;
            S0EPacketSpawnObject s0epacketspawnobject = new S0EPacketSpawnObject(this.trackedEntity, 77);
            s0epacketspawnobject.func_148996_a(MathHelper.floor_float(entityleashknot.field_146063_b * 32));
            s0epacketspawnobject.func_148995_b(MathHelper.floor_float(entityleashknot.field_146064_c * 32));
            s0epacketspawnobject.func_149005_c(MathHelper.floor_float(entityleashknot.field_146062_d * 32));
            return s0epacketspawnobject;
        } else if (this.trackedEntity instanceof EntityXPOrb) {
            return new S11PacketSpawnExperienceOrb((EntityXPOrb)this.trackedEntity);
        } else {
            throw new IllegalArgumentException("Don't know how to add " + this.trackedEntity.getClass() + "!");
        }
    }

    public void removeTrackedPlayerSymmetric(EntityPlayerMP var1) {
        if (this.trackingPlayers.contains(var1)) {
            this.trackingPlayers.remove(var1);
            var1.destroyedItemsNetCache.add(this.trackedEntity.getEntityId());
        }
    }
}
