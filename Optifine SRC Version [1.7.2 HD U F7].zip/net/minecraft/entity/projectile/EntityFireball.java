package net.minecraft.entity.projectile;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public abstract class EntityFireball extends Entity {
    private int field_145795_e = -1;
    private int field_145793_f = -1;
    private int field_145794_g = -1;
    private Block field_145796_h;
    private boolean inGround;
    public EntityLivingBase shootingEntity;
    private int ticksAlive;
    private int ticksInAir;
    public double accelerationX;
    public double accelerationY;
    public double accelerationZ;

    public EntityFireball(World var1) {
        super(var1);
        this.setSize(1.0F, 1.0F);
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public boolean isInRangeToRenderDist(double var1) {
        double d0 = this.boundingBox.getAverageEdgeLength() * 4.0;
        d0 *= 64.0;
        return var1 < d0 * d0;
    }

    public EntityFireball(World var1, double var2, double var4, double var6, double var8, double var10, double var12) {
        super(var1);
        this.setSize(1.0F, 1.0F);
        this.setLocationAndAngles(var2, var4, var6, this.rotationYaw, this.rotationPitch);
        this.setPosition(var2, var4, var6);
        double d0 = MathHelper.sqrt_double(var8 * var8 + var10 * var10 + var12 * var12);
        this.accelerationX = var8 / d0 * 0.1;
        this.accelerationY = var10 / d0 * 0.1;
        this.accelerationZ = var12 / d0 * 0.1;
    }

    public EntityFireball(World var1, EntityLivingBase var2, double var3, double var5, double var7) {
        super(var1);
        this.shootingEntity = var2;
        this.setSize(1.0F, 1.0F);
        this.setLocationAndAngles(var2.posX, var2.posY, var2.posZ, var2.rotationYaw, var2.rotationPitch);
        this.setPosition(this.posX, this.posY, this.posZ);
        this.yOffset = 0.0F;
        this.motionX = this.motionY = this.motionZ = 0.0;
        var3 += this.rand.nextGaussian() * 0.4;
        var5 += this.rand.nextGaussian() * 0.4;
        var7 += this.rand.nextGaussian() * 0.4;
        double d0 = MathHelper.sqrt_double(var3 * var3 + var5 * var5 + var7 * var7);
        this.accelerationX = var3 / d0 * 0.1;
        this.accelerationY = var5 / d0 * 0.1;
        this.accelerationZ = var7 / d0 * 0.1;
    }

    @Override
    public void onUpdate() {
        if (this.worldObj.isRemote
            || (this.shootingEntity == null || !this.shootingEntity.isDead) && this.worldObj.blockExists((int)this.posX, (int)this.posY, (int)this.posZ)) {
            super.onUpdate();
            this.setFire(1);
            if (this.inGround) {
                if (this.worldObj.getBlock(this.field_145795_e, this.field_145793_f, this.field_145794_g) == this.field_145796_h) {
                    this.ticksAlive++;
                    if (this.ticksAlive == 600) {
                        this.setDead();
                    }

                    return;
                }

                this.inGround = false;
                this.motionX = this.motionX * (this.rand.nextFloat() * 0.2F);
                this.motionY = this.motionY * (this.rand.nextFloat() * 0.2F);
                this.motionZ = this.motionZ * (this.rand.nextFloat() * 0.2F);
                this.ticksAlive = 0;
                this.ticksInAir = 0;
            } else {
                this.ticksInAir++;
            }

            Vec3 vec3 = this.worldObj.func_82732_R().func_72345_a(this.posX, this.posY, this.posZ);
            Vec3 vec31 = this.worldObj.func_82732_R().func_72345_a(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
            MovingObjectPosition movingobjectposition = this.worldObj.rayTraceBlocks(vec3, vec31);
            vec3 = this.worldObj.func_82732_R().func_72345_a(this.posX, this.posY, this.posZ);
            vec31 = this.worldObj.func_82732_R().func_72345_a(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
            if (movingobjectposition != null) {
                vec31 = this.worldObj
                    .func_82732_R()
                    .func_72345_a(movingobjectposition.hitVec.xCoord, movingobjectposition.hitVec.yCoord, movingobjectposition.hitVec.zCoord);
            }

            Entity entity = null;
            List list = this.worldObj
                .getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0, 1.0, 1.0));
            double d0 = 0.0;

            for (int i = 0; i < list.size(); i++) {
                Entity entity1 = (Entity)list.get(i);
                if (entity1.canBeCollidedWith() && (!entity1.isEntityEqual(this.shootingEntity) || this.ticksInAir >= 25)) {
                    float f = 0.3F;
                    AxisAlignedBB axisalignedbb = entity1.boundingBox.expand(f, f, f);
                    MovingObjectPosition movingobjectposition1 = axisalignedbb.calculateIntercept(vec3, vec31);
                    if (movingobjectposition1 != null) {
                        double d1 = vec3.distanceTo(movingobjectposition1.hitVec);
                        if (d1 < d0 || d0 == 0.0) {
                            entity = entity1;
                            d0 = d1;
                        }
                    }
                }
            }

            if (entity != null) {
                movingobjectposition = new MovingObjectPosition(entity);
            }

            if (movingobjectposition != null) {
                this.onImpact(movingobjectposition);
            }

            this.posX = this.posX + this.motionX;
            this.posY = this.posY + this.motionY;
            this.posZ = this.posZ + this.motionZ;
            float f1 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
            this.rotationYaw = (float)(Math.atan2(this.motionZ, this.motionX) * 180.0 / (float)Math.PI) + 90.0F;
            this.rotationPitch = (float)(Math.atan2(f1, this.motionY) * 180.0 / (float)Math.PI) - 90.0F;

            while (this.rotationPitch - this.prevRotationPitch < -180.0F) {
                this.prevRotationPitch -= 360.0F;
            }

            while (this.rotationPitch - this.prevRotationPitch >= 180.0F) {
                this.prevRotationPitch += 360.0F;
            }

            while (this.rotationYaw - this.prevRotationYaw < -180.0F) {
                this.prevRotationYaw -= 360.0F;
            }

            while (this.rotationYaw - this.prevRotationYaw >= 180.0F) {
                this.prevRotationYaw += 360.0F;
            }

            this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
            this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
            float f2 = this.getMotionFactor();
            if (this.isInWater()) {
                for (int j = 0; j < 4; j++) {
                    float f3 = 0.25F;
                    this.worldObj
                        .spawnParticle(
                            "bubble",
                            this.posX - this.motionX * f3,
                            this.posY - this.motionY * f3,
                            this.posZ - this.motionZ * f3,
                            this.motionX,
                            this.motionY,
                            this.motionZ
                        );
                }

                f2 = 0.8F;
            }

            this.motionX = this.motionX + this.accelerationX;
            this.motionY = this.motionY + this.accelerationY;
            this.motionZ = this.motionZ + this.accelerationZ;
            this.motionX *= f2;
            this.motionY *= f2;
            this.motionZ *= f2;
            this.worldObj.spawnParticle("smoke", this.posX, this.posY + 0.5, this.posZ, 0.0, 0.0, 0.0);
            this.setPosition(this.posX, this.posY, this.posZ);
        } else {
            this.setDead();
        }
    }

    protected float getMotionFactor() {
        return 0.95F;
    }

    protected abstract void onImpact(MovingObjectPosition var1);

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setShort("xTile", (short)this.field_145795_e);
        var1.setShort("yTile", (short)this.field_145793_f);
        var1.setShort("zTile", (short)this.field_145794_g);
        var1.setByte("inTile", (byte)Block.getIdFromBlock(this.field_145796_h));
        var1.setByte("inGround", (byte)(this.inGround ? 1 : 0));
        var1.setTag("direction", this.newDoubleNBTList(this.motionX, this.motionY, this.motionZ));
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        this.field_145795_e = var1.getShort("xTile");
        this.field_145793_f = var1.getShort("yTile");
        this.field_145794_g = var1.getShort("zTile");
        this.field_145796_h = Block.getBlockById(var1.getByte("inTile") & 255);
        this.inGround = var1.getByte("inGround") == 1;
        if (var1.hasKey("direction", 9)) {
            NBTTagList nbttaglist = var1.getTagList("direction", 6);
            this.motionX = nbttaglist.getDoubleAt(0);
            this.motionY = nbttaglist.getDoubleAt(1);
            this.motionZ = nbttaglist.getDoubleAt(2);
        } else {
            this.setDead();
        }
    }

    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    @Override
    public float getCollisionBorderSize() {
        return 1.0F;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable()) {
            return false;
        }

        this.setBeenAttacked();
        if (var1.getEntity() != null) {
            Vec3 vec3 = var1.getEntity().getLookVec();
            if (vec3 != null) {
                this.motionX = vec3.xCoord;
                this.motionY = vec3.yCoord;
                this.motionZ = vec3.zCoord;
                this.accelerationX = this.motionX * 0.1;
                this.accelerationY = this.motionY * 0.1;
                this.accelerationZ = this.motionZ * 0.1;
            }

            if (var1.getEntity() instanceof EntityLivingBase) {
                this.shootingEntity = (EntityLivingBase)var1.getEntity();
            }

            return true;
        } else {
            return false;
        }
    }

    @Override
    public float getShadowSize() {
        return 0.0F;
    }

    @Override
    public float getBrightness(float var1) {
        return 1.0F;
    }

    @Override
    public int getBrightnessForRender(float var1) {
        return 15728880;
    }
}
