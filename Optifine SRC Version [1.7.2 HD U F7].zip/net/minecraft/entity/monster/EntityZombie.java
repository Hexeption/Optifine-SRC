package net.minecraft.entity.monster;

import java.util.Calendar;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIBreakDoor;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMoveThroughVillage;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class EntityZombie extends EntityMob {
    protected static final IAttribute field_110186_bp = new RangedAttribute("zombie.spawnReinforcements", 0.0, 0.0, 1.0)
        .setDescription("Spawn Reinforcements Chance");
    private static final UUID babySpeedBoostUUID = UUID.fromString("B9766B59-9566-4402-BC1F-2EE2A276D836");
    private static final AttributeModifier babySpeedBoostModifier = new AttributeModifier(babySpeedBoostUUID, "Baby speed boost", 0.5, 1);
    private final EntityAIBreakDoor field_146075_bs = new EntityAIBreakDoor(this);
    private int conversionTime;
    private boolean field_146076_bu = false;
    private float field_146074_bv = -1.0F;
    private float field_146073_bw;

    public EntityZombie(World var1) {
        super(var1);
        this.getNavigator().setBreakDoors(true);
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0, false));
        this.tasks.addTask(4, new EntityAIAttackOnCollide(this, EntityVillager.class, 1.0, true));
        this.tasks.addTask(5, new EntityAIMoveTowardsRestriction(this, 1.0));
        this.tasks.addTask(6, new EntityAIMoveThroughVillage(this, 1.0, false));
        this.tasks.addTask(7, new EntityAIWander(this, 1.0));
        this.tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(8, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityVillager.class, 0, false));
        this.setSize(0.6F, 1.8F);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23F);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0);
        this.getAttributeMap().registerAttribute(field_110186_bp).setBaseValue(this.rand.nextDouble() * 0.1F);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.getDataWatcher().addObject(12, (byte)0);
        this.getDataWatcher().addObject(13, (byte)0);
        this.getDataWatcher().addObject(14, (byte)0);
    }

    @Override
    public int getTotalArmorValue() {
        int i = super.getTotalArmorValue() + 2;
        if (i > 20) {
            i = 20;
        }

        return i;
    }

    @Override
    protected boolean isAIEnabled() {
        return true;
    }

    public boolean func_146072_bX() {
        return this.field_146076_bu;
    }

    public void func_146070_a(boolean var1) {
        if (this.field_146076_bu != var1) {
            this.field_146076_bu = var1;
            if (var1) {
                this.tasks.addTask(1, this.field_146075_bs);
            } else {
                this.tasks.removeTask(this.field_146075_bs);
            }
        }
    }

    @Override
    public boolean isChild() {
        return this.getDataWatcher().getWatchableObjectByte(12) == 1;
    }

    @Override
    protected int getExperiencePoints(EntityPlayer var1) {
        if (this.isChild()) {
            this.experienceValue = (int)(this.experienceValue * 2.5F);
        }

        return super.getExperiencePoints(var1);
    }

    public void setChild(boolean var1) {
        this.getDataWatcher().updateObject(12, (byte)(var1 ? 1 : 0));
        if (this.worldObj != null && !this.worldObj.isRemote) {
            IAttributeInstance iattributeinstance = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
            iattributeinstance.removeModifier(babySpeedBoostModifier);
            if (var1) {
                iattributeinstance.applyModifier(babySpeedBoostModifier);
            }
        }

        this.func_146071_k(var1);
    }

    public boolean isVillager() {
        return this.getDataWatcher().getWatchableObjectByte(13) == 1;
    }

    public void setVillager(boolean var1) {
        this.getDataWatcher().updateObject(13, (byte)(var1 ? 1 : 0));
    }

    @Override
    public void onLivingUpdate() {
        if (this.worldObj.isDaytime() && !this.worldObj.isRemote && !this.isChild()) {
            float f = this.getBrightness(1.0F);
            if (f > 0.5F
                && this.rand.nextFloat() * 30.0F < (f - 0.4F) * 2.0F
                && this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))) {
                boolean flag = true;
                ItemStack itemstack = this.getEquipmentInSlot(4);
                if (itemstack != null) {
                    if (itemstack.isItemStackDamageable()) {
                        itemstack.setMetadata(itemstack.getCurrentDurability() + this.rand.nextInt(2));
                        if (itemstack.getCurrentDurability() >= itemstack.getMaxDurability()) {
                            this.renderBrokenItemStack(itemstack);
                            this.setCurrentItemOrArmor(4, null);
                        }
                    }

                    flag = false;
                }

                if (flag) {
                    this.setFire(8);
                }
            }
        }

        super.onLivingUpdate();
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (!super.attackEntityFrom(var1, var2)) {
            return false;
        }

        EntityLivingBase entitylivingbase = this.getAttackTarget();
        if (entitylivingbase == null && this.getEntityToAttack() instanceof EntityLivingBase) {
            entitylivingbase = (EntityLivingBase)this.getEntityToAttack();
        }

        if (entitylivingbase == null && var1.getEntity() instanceof EntityLivingBase) {
            entitylivingbase = (EntityLivingBase)var1.getEntity();
        }

        if (entitylivingbase != null
            && this.worldObj.difficultySetting == EnumDifficulty.HARD
            && this.rand.nextFloat() < this.getEntityAttribute(field_110186_bp).getAttributeValue()) {
            int i = MathHelper.floor_double(this.posX);
            int j = MathHelper.floor_double(this.posY);
            int k = MathHelper.floor_double(this.posZ);
            EntityZombie entityzombie = new EntityZombie(this.worldObj);

            for (int l = 0; l < 50; l++) {
                int i1 = i + MathHelper.getRandomIntegerInRange(this.rand, 7, 40) * MathHelper.getRandomIntegerInRange(this.rand, -1, 1);
                int j1 = j + MathHelper.getRandomIntegerInRange(this.rand, 7, 40) * MathHelper.getRandomIntegerInRange(this.rand, -1, 1);
                int k1 = k + MathHelper.getRandomIntegerInRange(this.rand, 7, 40) * MathHelper.getRandomIntegerInRange(this.rand, -1, 1);
                if (World.doesBlockHaveSolidTopSurface(this.worldObj, i1, j1 - 1, k1) && this.worldObj.getBlockLightValue(i1, j1, k1) < 10) {
                    entityzombie.setPosition(i1, j1, k1);
                    if (this.worldObj.checkNoEntityCollision(entityzombie.boundingBox)
                        && this.worldObj.getCollidingBoundingBoxes(entityzombie, entityzombie.boundingBox).isEmpty()
                        && !this.worldObj.isAnyLiquid(entityzombie.boundingBox)) {
                        this.worldObj.spawnEntityInWorld(entityzombie);
                        entityzombie.setAttackTarget(entitylivingbase);
                        entityzombie.onSpawnWithEgg(null);
                        this.getEntityAttribute(field_110186_bp).applyModifier(new AttributeModifier("Zombie reinforcement caller charge", -0.05F, 0));
                        entityzombie.getEntityAttribute(field_110186_bp).applyModifier(new AttributeModifier("Zombie reinforcement callee charge", -0.05F, 0));
                        break;
                    }
                }
            }
        }

        return true;
    }

    @Override
    public void onUpdate() {
        if (!this.worldObj.isRemote && this.isConverting()) {
            int i = this.getConversionTimeBoost();
            this.conversionTime -= i;
            if (this.conversionTime <= 0) {
                this.convertToVillager();
            }
        }

        super.onUpdate();
    }

    @Override
    public boolean attackEntityAsMob(Entity var1) {
        boolean flag = super.attackEntityAsMob(var1);
        if (flag) {
            int i = this.worldObj.difficultySetting.getDifficultyId();
            if (this.getHeldItem() == null && this.isBurning() && this.rand.nextFloat() < i * 0.3F) {
                var1.setFire(2 * i);
            }
        }

        return flag;
    }

    @Override
    protected String getLivingSound() {
        return "mob.zombie.say";
    }

    @Override
    protected String getHurtSound() {
        return "mob.zombie.hurt";
    }

    @Override
    protected String getDeathSound() {
        return "mob.zombie.death";
    }

    @Override
    protected void playStepSound(int var1, int var2, int var3, Block var4) {
        this.playSound("mob.zombie.step", 0.15F, 1.0F);
    }

    @Override
    protected Item getDropItem() {
        return Items.rotten_flesh;
    }

    @Override
    public EnumCreatureAttribute getCreatureAttribute() {
        return EnumCreatureAttribute.UNDEAD;
    }

    @Override
    protected void dropRareDrop(int var1) {
        switch (this.rand.nextInt(3)) {
            case 0:
                this.dropItem(Items.iron_ingot, 1);
                break;
            case 1:
                this.dropItem(Items.carrot, 1);
                break;
            case 2:
                this.dropItem(Items.potato, 1);
        }
    }

    @Override
    protected void addRandomArmor() {
        super.addRandomArmor();
        if (this.rand.nextFloat() < (this.worldObj.difficultySetting == EnumDifficulty.HARD ? 0.05F : 0.01F)) {
            int i = this.rand.nextInt(3);
            if (i == 0) {
                this.setCurrentItemOrArmor(0, new ItemStack(Items.iron_sword));
            } else {
                this.setCurrentItemOrArmor(0, new ItemStack(Items.iron_shovel));
            }
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        if (this.isChild()) {
            var1.setBoolean("IsBaby", true);
        }

        if (this.isVillager()) {
            var1.setBoolean("IsVillager", true);
        }

        var1.setInteger("ConversionTime", this.isConverting() ? this.conversionTime : -1);
        var1.setBoolean("CanBreakDoors", this.func_146072_bX());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        if (var1.getBoolean("IsBaby")) {
            this.setChild(true);
        }

        if (var1.getBoolean("IsVillager")) {
            this.setVillager(true);
        }

        if (var1.hasKey("ConversionTime", 99) && var1.getInteger("ConversionTime") > -1) {
            this.startConversion(var1.getInteger("ConversionTime"));
        }

        this.func_146070_a(var1.getBoolean("CanBreakDoors"));
    }

    @Override
    public void onKillEntity(EntityLivingBase var1) {
        super.onKillEntity(var1);
        if ((this.worldObj.difficultySetting == EnumDifficulty.NORMAL || this.worldObj.difficultySetting == EnumDifficulty.HARD)
            && var1 instanceof EntityVillager) {
            if (this.rand.nextBoolean()) {
                return;
            }

            EntityZombie entityzombie = new EntityZombie(this.worldObj);
            entityzombie.copyLocationAndAnglesFrom(var1);
            this.worldObj.removeEntity(var1);
            entityzombie.onSpawnWithEgg(null);
            entityzombie.setVillager(true);
            if (var1.isChild()) {
                entityzombie.setChild(true);
            }

            this.worldObj.spawnEntityInWorld(entityzombie);
            this.worldObj.playAuxSFXAtEntity(null, 1016, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
        }
    }

    @Override
    public IEntityLivingData onSpawnWithEgg(IEntityLivingData var1) {
        var1 = super.onSpawnWithEgg(var1);
        float f = this.worldObj.getTensionFactorForBlock(this.posX, this.posY, this.posZ);
        this.setCanPickUpLoot(this.rand.nextFloat() < 0.55F * f);
        if (var1 == null) {
            var1 = new EntityZombie.GroupData(this.worldObj.rand.nextFloat() < 0.05F, this.worldObj.rand.nextFloat() < 0.05F);
        }

        if (var1 instanceof EntityZombie.GroupData) {
            EntityZombie.GroupData entityzombie$groupdata = (EntityZombie.GroupData)var1;
            if (entityzombie$groupdata.field_142046_b) {
                this.setVillager(true);
            }

            if (entityzombie$groupdata.field_142048_a) {
                this.setChild(true);
            }
        }

        this.func_146070_a(this.rand.nextFloat() < f * 0.1F);
        this.addRandomArmor();
        this.enchantEquipment();
        if (this.getEquipmentInSlot(4) == null) {
            Calendar calendar = this.worldObj.getCurrentDate();
            if (calendar.get(2) + 1 == 10 && calendar.get(5) == 31 && this.rand.nextFloat() < 0.25F) {
                this.setCurrentItemOrArmor(4, new ItemStack(this.rand.nextFloat() < 0.1F ? Blocks.lit_pumpkin : Blocks.pumpkin));
                this.equipmentDropChances[4] = 0.0F;
            }
        }

        this.getEntityAttribute(SharedMonsterAttributes.knockbackResistance)
            .applyModifier(new AttributeModifier("Random spawn bonus", this.rand.nextDouble() * 0.05F, 0));
        double d0 = this.rand.nextDouble() * 1.5 * this.worldObj.getTensionFactorForBlock(this.posX, this.posY, this.posZ);
        if (d0 > 1.0) {
            this.getEntityAttribute(SharedMonsterAttributes.followRange).applyModifier(new AttributeModifier("Random zombie-spawn bonus", d0, 2));
        }

        if (this.rand.nextFloat() < f * 0.05F) {
            this.getEntityAttribute(field_110186_bp).applyModifier(new AttributeModifier("Leader zombie bonus", this.rand.nextDouble() * 0.25 + 0.5, 0));
            this.getEntityAttribute(SharedMonsterAttributes.maxHealth)
                .applyModifier(new AttributeModifier("Leader zombie bonus", this.rand.nextDouble() * 3.0 + 1.0, 2));
            this.func_146070_a(true);
        }

        return var1;
    }

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.getCurrentEquippedItem();
        if (itemstack != null
            && itemstack.getItem() == Items.golden_apple
            && itemstack.getMetadata() == 0
            && this.isVillager()
            && this.isPotionActive(Potion.weakness)) {
            if (!var1.capabilities.isCreativeMode) {
                itemstack.stackSize--;
            }

            if (itemstack.stackSize <= 0) {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
            }

            if (!this.worldObj.isRemote) {
                this.startConversion(this.rand.nextInt(2401) + 3600);
            }

            return true;
        } else {
            return false;
        }
    }

    protected void startConversion(int var1) {
        this.conversionTime = var1;
        this.getDataWatcher().updateObject(14, (byte)1);
        this.removePotionEffect(Potion.weakness.id);
        this.addPotionEffect(new PotionEffect(Potion.damageBoost.id, var1, Math.min(this.worldObj.difficultySetting.getDifficultyId() - 1, 0)));
        this.worldObj.setEntityState(this, (byte)16);
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 16) {
            this.worldObj
                .playSound(
                    this.posX + 0.5,
                    this.posY + 0.5,
                    this.posZ + 0.5,
                    "mob.zombie.remedy",
                    1.0F + this.rand.nextFloat(),
                    this.rand.nextFloat() * 0.7F + 0.3F,
                    false
                );
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    @Override
    protected boolean canDespawn() {
        return !this.isConverting();
    }

    public boolean isConverting() {
        return this.getDataWatcher().getWatchableObjectByte(14) == 1;
    }

    protected void convertToVillager() {
        EntityVillager entityvillager = new EntityVillager(this.worldObj);
        entityvillager.copyLocationAndAnglesFrom(this);
        entityvillager.onSpawnWithEgg(null);
        entityvillager.setLookingForHome();
        if (this.isChild()) {
            entityvillager.setGrowingAge(-24000);
        }

        this.worldObj.removeEntity(this);
        this.worldObj.spawnEntityInWorld(entityvillager);
        entityvillager.addPotionEffect(new PotionEffect(Potion.confusion.id, 200, 0));
        this.worldObj.playAuxSFXAtEntity(null, 1017, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
    }

    protected int getConversionTimeBoost() {
        int i = 1;
        if (this.rand.nextFloat() < 0.01F) {
            int j = 0;

            for (int k = (int)this.posX - 4; k < (int)this.posX + 4 && j < 14; k++) {
                for (int l = (int)this.posY - 4; l < (int)this.posY + 4 && j < 14; l++) {
                    for (int i1 = (int)this.posZ - 4; i1 < (int)this.posZ + 4 && j < 14; i1++) {
                        Block block = this.worldObj.getBlock(k, l, i1);
                        if (block == Blocks.iron_bars || block == Blocks.bed) {
                            if (this.rand.nextFloat() < 0.3F) {
                                i++;
                            }

                            j++;
                        }
                    }
                }
            }
        }

        return i;
    }

    public void func_146071_k(boolean var1) {
        this.func_146069_a(var1 ? 0.5F : 1.0F);
    }

    @Override
    protected final void setSize(float var1, float var2) {
        boolean flag = this.field_146074_bv > 0.0F && this.field_146073_bw > 0.0F;
        this.field_146074_bv = var1;
        this.field_146073_bw = var2;
        if (!flag) {
            this.func_146069_a(1.0F);
        }
    }

    protected final void func_146069_a(float var1) {
        super.setSize(this.field_146074_bv * var1, this.field_146073_bw * var1);
    }

    class GroupData implements IEntityLivingData {
        public boolean field_142048_a = false;
        public boolean field_142046_b = false;

        private GroupData(boolean var2, boolean var3) {
            this.field_142048_a = var2;
            this.field_142046_b = var3;
        }
    }
}
