package net.minecraft.entity;

import java.util.UUID;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.ai.EntityJumpHelper;
import net.minecraft.entity.ai.EntityLookHelper;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.ai.EntitySenses;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.play.server.S1BPacketEntityAttach;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.stats.AchievementList;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.BiomeGenBase;
import optifine.BlockPos;
import optifine.Reflector;

public abstract class EntityLiving extends EntityLivingBase {
    public int livingSoundTime;
    protected int experienceValue;
    private EntityLookHelper lookHelper;
    private EntityMoveHelper moveHelper;
    private EntityJumpHelper jumpHelper;
    private EntityBodyHelper bodyHelper;
    private PathNavigate navigator;
    protected final EntityAITasks tasks;
    protected final EntityAITasks targetTasks;
    private EntityLivingBase attackTarget;
    private EntitySenses senses;
    private ItemStack[] equipment = new ItemStack[5];
    protected float[] equipmentDropChances = new float[5];
    private boolean canPickUpLoot;
    private boolean persistenceRequired;
    protected float defaultPitch;
    private Entity currentTarget;
    protected int numTicksToChaseTarget;
    private boolean isLeashed;
    private Entity leashedToEntity;
    private NBTTagCompound leashNBTTag;
    private static final String __OBFID = "CL_00001550";
    public int randomMobsId = 0;
    public BiomeGenBase spawnBiome = null;
    public BlockPos spawnPosition = null;

    public EntityLiving(World par1World) {
        super(par1World);
        this.tasks = new EntityAITasks(par1World != null && par1World.theProfiler != null ? par1World.theProfiler : null);
        this.targetTasks = new EntityAITasks(par1World != null && par1World.theProfiler != null ? par1World.theProfiler : null);
        this.lookHelper = new EntityLookHelper(this);
        this.moveHelper = new EntityMoveHelper(this);
        this.jumpHelper = new EntityJumpHelper(this);
        this.bodyHelper = new EntityBodyHelper(this);
        this.navigator = new PathNavigate(this, par1World);
        this.senses = new EntitySenses(this);

        for (int i = 0; i < this.equipmentDropChances.length; i++) {
            this.equipmentDropChances[i] = 0.085F;
        }

        UUID uuid = this.getUniqueID();
        long j = uuid.getLeastSignificantBits();
        this.randomMobsId = (int)(j & 2147483647L);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.followRange).setBaseValue(16.0);
    }

    public EntityLookHelper getLookHelper() {
        return this.lookHelper;
    }

    public EntityMoveHelper getMoveHelper() {
        return this.moveHelper;
    }

    public EntityJumpHelper getJumpHelper() {
        return this.jumpHelper;
    }

    public PathNavigate getNavigator() {
        return this.navigator;
    }

    public EntitySenses getEntitySenses() {
        return this.senses;
    }

    public EntityLivingBase getAttackTarget() {
        return this.attackTarget;
    }

    public void setAttackTarget(EntityLivingBase par1EntityLivingBase) {
        this.attackTarget = par1EntityLivingBase;
        Reflector.callVoid(Reflector.ForgeHooks_onLivingSetAttackTarget, this, par1EntityLivingBase);
    }

    public boolean canAttackClass(Class par1Class) {
        return EntityCreeper.class != par1Class && EntityGhast.class != par1Class;
    }

    public void eatGrassBonus() {
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(11, (byte)0);
        this.dataWatcher.addObject(10, "");
    }

    public int getTalkInterval() {
        return 80;
    }

    public void playLivingSound() {
        String s = this.getLivingSound();
        if (s != null) {
            this.playSound(s, this.getSoundVolume(), this.getSoundPitch());
        }
    }

    @Override
    public void onEntityUpdate() {
        super.onEntityUpdate();
        this.worldObj.theProfiler.startSection("mobBaseTick");
        if (this.isEntityAlive() && this.rand.nextInt(1000) < this.livingSoundTime++) {
            this.livingSoundTime = -this.getTalkInterval();
            this.playLivingSound();
        }

        this.worldObj.theProfiler.endSection();
    }

    @Override
    protected int getExperiencePoints(EntityPlayer par1EntityPlayer) {
        if (this.experienceValue > 0) {
            int i = this.experienceValue;
            ItemStack[] aitemstack = this.getInventory();

            for (int j = 0; j < aitemstack.length; j++) {
                if (aitemstack[j] != null && this.equipmentDropChances[j] <= 1.0F) {
                    i += 1 + this.rand.nextInt(3);
                }
            }

            return i;
        } else {
            return this.experienceValue;
        }
    }

    public void spawnExplosionParticle() {
        for (int i = 0; i < 20; i++) {
            double d0 = this.rand.nextGaussian() * 0.02;
            double d1 = this.rand.nextGaussian() * 0.02;
            double d2 = this.rand.nextGaussian() * 0.02;
            double d3 = 10.0;
            this.worldObj
                .spawnParticle(
                    "explode",
                    this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width - d0 * d3,
                    this.posY + this.rand.nextFloat() * this.height - d1 * d3,
                    this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width - d2 * d3,
                    d0,
                    d1,
                    d2
                );
        }
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (!this.worldObj.isRemote) {
            this.updateLeashedState();
        }
    }

    @Override
    protected float func_110146_f(float par1, float par2) {
        if (this.isAIEnabled()) {
            this.bodyHelper.updateRenderAngles();
            return par2;
        } else {
            return super.func_110146_f(par1, par2);
        }
    }

    protected String getLivingSound() {
        return null;
    }

    protected Item getDropItem() {
        return Item.getItemById(0);
    }

    @Override
    protected void dropFewItems(boolean par1, int par2) {
        Item item = this.getDropItem();
        if (item != null) {
            int i = this.rand.nextInt(3);
            if (par2 > 0) {
                i += this.rand.nextInt(par2 + 1);
            }

            for (int j = 0; j < i; j++) {
                this.dropItem(item, 1);
            }
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setBoolean("CanPickUpLoot", this.canPickUpLoot());
        par1NBTTagCompound.setBoolean("PersistenceRequired", this.persistenceRequired);
        NBTTagList nbttaglist = new NBTTagList();

        for (int i = 0; i < this.equipment.length; i++) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            if (this.equipment[i] != null) {
                this.equipment[i].writeToNBT(nbttagcompound);
            }

            nbttaglist.appendTag(nbttagcompound);
        }

        par1NBTTagCompound.setTag("Equipment", nbttaglist);
        NBTTagList nbttaglist1 = new NBTTagList();

        for (int j = 0; j < this.equipmentDropChances.length; j++) {
            nbttaglist1.appendTag(new NBTTagFloat(this.equipmentDropChances[j]));
        }

        par1NBTTagCompound.setTag("DropChances", nbttaglist1);
        par1NBTTagCompound.setString("CustomName", this.getCustomNameTag());
        par1NBTTagCompound.setBoolean("CustomNameVisible", this.getAlwaysRenderNameTag());
        par1NBTTagCompound.setBoolean("Leashed", this.isLeashed);
        if (this.leashedToEntity != null) {
            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            if (this.leashedToEntity instanceof EntityLivingBase) {
                nbttagcompound1.setLong("UUIDMost", this.leashedToEntity.getUniqueID().getMostSignificantBits());
                nbttagcompound1.setLong("UUIDLeast", this.leashedToEntity.getUniqueID().getLeastSignificantBits());
            } else if (this.leashedToEntity instanceof EntityHanging) {
                EntityHanging entityhanging = (EntityHanging)this.leashedToEntity;
                nbttagcompound1.setInteger("X", entityhanging.field_146063_b);
                nbttagcompound1.setInteger("Y", entityhanging.field_146064_c);
                nbttagcompound1.setInteger("Z", entityhanging.field_146062_d);
            }

            par1NBTTagCompound.setTag("Leash", nbttagcompound1);
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
        super.readEntityFromNBT(par1NBTTagCompound);
        this.setCanPickUpLoot(par1NBTTagCompound.getBoolean("CanPickUpLoot"));
        this.persistenceRequired = par1NBTTagCompound.getBoolean("PersistenceRequired");
        if (par1NBTTagCompound.hasKey("CustomName", 8) && par1NBTTagCompound.getString("CustomName").length() > 0) {
            this.setCustomNameTag(par1NBTTagCompound.getString("CustomName"));
        }

        this.setAlwaysRenderNameTag(par1NBTTagCompound.getBoolean("CustomNameVisible"));
        if (par1NBTTagCompound.hasKey("Equipment", 9)) {
            NBTTagList nbttaglist = par1NBTTagCompound.getTagList("Equipment", 10);

            for (int i = 0; i < this.equipment.length; i++) {
                this.equipment[i] = ItemStack.loadItemStackFromNBT(nbttaglist.getCompoundTagAt(i));
            }
        }

        if (par1NBTTagCompound.hasKey("DropChances", 9)) {
            NBTTagList nbttaglist1 = par1NBTTagCompound.getTagList("DropChances", 5);

            for (int j = 0; j < nbttaglist1.tagCount(); j++) {
                this.equipmentDropChances[j] = nbttaglist1.getFloatAt(j);
            }
        }

        this.isLeashed = par1NBTTagCompound.getBoolean("Leashed");
        if (this.isLeashed && par1NBTTagCompound.hasKey("Leash", 10)) {
            this.leashNBTTag = par1NBTTagCompound.getCompoundTag("Leash");
        }
    }

    public void setMoveForward(float par1) {
        this.moveForward = par1;
    }

    @Override
    public void setAIMoveSpeed(float par1) {
        super.setAIMoveSpeed(par1);
        this.setMoveForward(par1);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        this.worldObj.theProfiler.startSection("looting");
        if (!this.worldObj.isRemote && this.canPickUpLoot() && !this.dead && this.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) {
            for (EntityItem entityitem : this.worldObj.getEntitiesWithinAABB(EntityItem.class, this.boundingBox.expand(1.0, 0.0, 1.0))) {
                if (!entityitem.isDead && entityitem.getEntityItem() != null) {
                    ItemStack itemstack = entityitem.getEntityItem();
                    int i = getArmorPosition(itemstack);
                    if (i > -1) {
                        boolean flag = true;
                        ItemStack itemstack1 = this.getEquipmentInSlot(i);
                        if (itemstack1 != null) {
                            if (i == 0) {
                                if (itemstack.getItem() instanceof ItemSword && !(itemstack1.getItem() instanceof ItemSword)) {
                                    flag = true;
                                } else if (itemstack.getItem() instanceof ItemSword && itemstack1.getItem() instanceof ItemSword) {
                                    ItemSword itemsword = (ItemSword)itemstack.getItem();
                                    ItemSword itemsword1 = (ItemSword)itemstack1.getItem();
                                    if (itemsword.func_150931_i() == itemsword1.func_150931_i()) {
                                        flag = itemstack.getMetadata() > itemstack1.getMetadata() || itemstack.hasTagCompound() && !itemstack1.hasTagCompound();
                                    } else {
                                        flag = itemsword.func_150931_i() > itemsword1.func_150931_i();
                                    }
                                } else {
                                    flag = false;
                                }
                            } else if (itemstack.getItem() instanceof ItemArmor && !(itemstack1.getItem() instanceof ItemArmor)) {
                                flag = true;
                            } else if (itemstack.getItem() instanceof ItemArmor && itemstack1.getItem() instanceof ItemArmor) {
                                ItemArmor itemarmor = (ItemArmor)itemstack.getItem();
                                ItemArmor itemarmor1 = (ItemArmor)itemstack1.getItem();
                                if (itemarmor.damageReduceAmount == itemarmor1.damageReduceAmount) {
                                    flag = itemstack.getMetadata() > itemstack1.getMetadata() || itemstack.hasTagCompound() && !itemstack1.hasTagCompound();
                                } else {
                                    flag = itemarmor.damageReduceAmount > itemarmor1.damageReduceAmount;
                                }
                            } else {
                                flag = false;
                            }
                        }

                        if (flag) {
                            if (itemstack1 != null && this.rand.nextFloat() - 0.1F < this.equipmentDropChances[i]) {
                                this.entityDropItem(itemstack1, 0.0F);
                            }

                            if (itemstack.getItem() == Items.diamond && entityitem.getThrower() != null) {
                                EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(entityitem.getThrower());
                                if (entityplayer != null) {
                                    entityplayer.triggerAchievement(AchievementList.field_150966_x);
                                }
                            }

                            this.setCurrentItemOrArmor(i, itemstack);
                            this.equipmentDropChances[i] = 2.0F;
                            this.persistenceRequired = true;
                            this.onItemPickup(entityitem, 1);
                            entityitem.setDead();
                        }
                    }
                }
            }
        }

        this.worldObj.theProfiler.endSection();
    }

    @Override
    protected boolean isAIEnabled() {
        return false;
    }

    protected boolean canDespawn() {
        return true;
    }

    public void despawnEntity() {
        Object object = null;
        Object object1 = Reflector.getFieldValue(Reflector.Event_Result_DEFAULT);
        Object object2 = Reflector.getFieldValue(Reflector.Event_Result_DENY);
        if (this.persistenceRequired) {
            this.entityAge = 0;
        } else {
            if ((this.entityAge & 31) == 31) {
                object = Reflector.call(Reflector.ForgeEventFactory_canEntityDespawn, this);
                if (object != object1) {
                    if (object == object2) {
                        this.entityAge = 0;
                    } else {
                        this.setDead();
                    }

                    return;
                }
            }

            EntityPlayer entityplayer = this.worldObj.getClosestPlayerToEntity(this, -1.0);
            if (entityplayer != null) {
                double d0 = entityplayer.posX - this.posX;
                double d1 = entityplayer.posY - this.posY;
                double d2 = entityplayer.posZ - this.posZ;
                double d3 = d0 * d0 + d1 * d1 + d2 * d2;
                if (this.canDespawn() && d3 > 16384.0) {
                    this.setDead();
                }

                if (this.entityAge > 600 && this.rand.nextInt(800) == 0 && d3 > 1024.0 && this.canDespawn()) {
                    this.setDead();
                } else if (d3 < 1024.0) {
                    this.entityAge = 0;
                }
            }
        }
    }

    @Override
    protected void updateAITasks() {
        this.entityAge++;
        this.worldObj.theProfiler.startSection("checkDespawn");
        this.despawnEntity();
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("sensing");
        this.senses.clearSensingCache();
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("targetSelector");
        this.targetTasks.onUpdateTasks();
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("goalSelector");
        this.tasks.onUpdateTasks();
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("navigation");
        this.navigator.onUpdateNavigation();
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("mob tick");
        this.updateAITick();
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.startSection("controls");
        this.worldObj.theProfiler.startSection("move");
        this.moveHelper.onUpdateMoveHelper();
        this.worldObj.theProfiler.endStartSection("look");
        this.lookHelper.onUpdateLook();
        this.worldObj.theProfiler.endStartSection("jump");
        this.jumpHelper.doJump();
        this.worldObj.theProfiler.endSection();
        this.worldObj.theProfiler.endSection();
    }

    @Override
    protected void updateEntityActionState() {
        super.updateEntityActionState();
        this.moveStrafing = 0.0F;
        this.moveForward = 0.0F;
        this.despawnEntity();
        float f = 8.0F;
        if (this.rand.nextFloat() < 0.02F) {
            EntityPlayer entityplayer = this.worldObj.getClosestPlayerToEntity(this, f);
            if (entityplayer != null) {
                this.currentTarget = entityplayer;
                this.numTicksToChaseTarget = 10 + this.rand.nextInt(20);
            } else {
                this.randomYawVelocity = (this.rand.nextFloat() - 0.5F) * 20.0F;
            }
        }

        if (this.currentTarget != null) {
            this.faceEntity(this.currentTarget, 10.0F, this.getVerticalFaceSpeed());
            if (this.numTicksToChaseTarget-- <= 0 || this.currentTarget.isDead || this.currentTarget.getDistanceSqToEntity(this) > f * f) {
                this.currentTarget = null;
            }
        } else {
            if (this.rand.nextFloat() < 0.05F) {
                this.randomYawVelocity = (this.rand.nextFloat() - 0.5F) * 20.0F;
            }

            this.rotationYaw = this.rotationYaw + this.randomYawVelocity;
            this.rotationPitch = this.defaultPitch;
        }

        boolean flag1 = this.isInWater();
        boolean flag = this.handleLavaMovement();
        if (flag1 || flag) {
            this.isJumping = this.rand.nextFloat() < 0.8F;
        }
    }

    public int getVerticalFaceSpeed() {
        return 40;
    }

    public void faceEntity(Entity par1Entity, float par2, float par3) {
        double d0 = par1Entity.posX - this.posX;
        double d1 = par1Entity.posZ - this.posZ;
        double d2;
        if (par1Entity instanceof EntityLivingBase) {
            EntityLivingBase entitylivingbase = (EntityLivingBase)par1Entity;
            d2 = entitylivingbase.posY + entitylivingbase.getEyeHeight() - (this.posY + this.getEyeHeight());
        } else {
            d2 = (par1Entity.boundingBox.minY + par1Entity.boundingBox.maxY) / 2.0 - (this.posY + this.getEyeHeight());
        }

        double d3 = MathHelper.sqrt_double(d0 * d0 + d1 * d1);
        float f = (float)(Math.atan2(d1, d0) * 180.0 / Math.PI) - 90.0F;
        float f1 = (float)(-(Math.atan2(d2, d3) * 180.0 / Math.PI));
        this.rotationPitch = this.updateRotation(this.rotationPitch, f1, par3);
        this.rotationYaw = this.updateRotation(this.rotationYaw, f, par2);
    }

    private float updateRotation(float par1, float par2, float par3) {
        float f = MathHelper.wrapAngleTo180_float(par2 - par1);
        if (f > par3) {
            f = par3;
        }

        if (f < -par3) {
            f = -par3;
        }

        return par1 + f;
    }

    public boolean getCanSpawnHere() {
        return this.worldObj.checkNoEntityCollision(this.boundingBox)
            && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).isEmpty()
            && !this.worldObj.isAnyLiquid(this.boundingBox);
    }

    public float getRenderSizeModifier() {
        return 1.0F;
    }

    public int getMaxSpawnedInChunk() {
        return 4;
    }

    @Override
    public int getMaxFallHeight() {
        if (this.getAttackTarget() == null) {
            return 3;
        }

        int i = (int)(this.getHealth() - this.getMaxHealth() * 0.33F);
        i -= (3 - this.worldObj.difficultySetting.getDifficultyId()) * 4;
        if (i < 0) {
            i = 0;
        }

        return i + 3;
    }

    @Override
    public ItemStack getHeldItem() {
        return this.equipment[0];
    }

    @Override
    public ItemStack getEquipmentInSlot(int par1) {
        return this.equipment[par1];
    }

    public ItemStack func_130225_q(int par1) {
        return this.equipment[par1 + 1];
    }

    @Override
    public void setCurrentItemOrArmor(int par1, ItemStack par2ItemStack) {
        this.equipment[par1] = par2ItemStack;
    }

    @Override
    public ItemStack[] getInventory() {
        return this.equipment;
    }

    @Override
    protected void dropEquipment(boolean par1, int par2) {
        for (int i = 0; i < this.getInventory().length; i++) {
            ItemStack itemstack = this.getEquipmentInSlot(i);
            boolean flag = this.equipmentDropChances[i] > 1.0F;
            if (itemstack != null && (par1 || flag) && this.rand.nextFloat() - par2 * 0.01F < this.equipmentDropChances[i]) {
                if (!flag && itemstack.isItemStackDamageable()) {
                    int j = Math.max(itemstack.getMaxDurability() - 25, 1);
                    int k = itemstack.getMaxDurability() - this.rand.nextInt(this.rand.nextInt(j) + 1);
                    if (k > j) {
                        k = j;
                    }

                    if (k < 1) {
                        k = 1;
                    }

                    itemstack.setMetadata(k);
                }

                this.entityDropItem(itemstack, 0.0F);
            }
        }
    }

    protected void addRandomArmor() {
        if (this.rand.nextFloat() < 0.15F * this.worldObj.getTensionFactorForBlock(this.posX, this.posY, this.posZ)) {
            int i = this.rand.nextInt(2);
            float f = this.worldObj.difficultySetting == EnumDifficulty.HARD ? 0.1F : 0.25F;
            if (this.rand.nextFloat() < 0.095F) {
                i++;
            }

            if (this.rand.nextFloat() < 0.095F) {
                i++;
            }

            if (this.rand.nextFloat() < 0.095F) {
                i++;
            }

            for (int j = 3; j >= 0; j--) {
                ItemStack itemstack = this.func_130225_q(j);
                if (j < 3 && this.rand.nextFloat() < f) {
                    break;
                }

                if (itemstack == null) {
                    Item item = getArmorItemForSlot(j + 1, i);
                    if (item != null) {
                        this.setCurrentItemOrArmor(j + 1, new ItemStack(item));
                    }
                }
            }
        }
    }

    public static int getArmorPosition(ItemStack par0ItemStack) {
        if (par0ItemStack.getItem() == Item.getItemFromBlock(Blocks.pumpkin) || par0ItemStack.getItem() == Items.skull) {
            return 4;
        }

        if (par0ItemStack.getItem() instanceof ItemArmor) {
            switch (((ItemArmor)par0ItemStack.getItem()).armorType) {
                case 0:
                    return 4;
                case 1:
                    return 3;
                case 2:
                    return 2;
                case 3:
                    return 1;
            }
        }

        return 0;
    }

    public static Item getArmorItemForSlot(int par0, int par1) {
        switch (par0) {
            case 4:
                if (par1 == 0) {
                    return Items.leather_helmet;
                } else if (par1 == 1) {
                    return Items.golden_helmet;
                } else if (par1 == 2) {
                    return Items.chainmail_helmet;
                } else if (par1 == 3) {
                    return Items.iron_helmet;
                } else if (par1 == 4) {
                    return Items.diamond_helmet;
                }
            case 3:
                if (par1 == 0) {
                    return Items.leather_chestplate;
                } else if (par1 == 1) {
                    return Items.golden_chestplate;
                } else if (par1 == 2) {
                    return Items.chainmail_chestplate;
                } else if (par1 == 3) {
                    return Items.iron_chestplate;
                } else if (par1 == 4) {
                    return Items.diamond_chestplate;
                }
            case 2:
                if (par1 == 0) {
                    return Items.leather_leggings;
                } else if (par1 == 1) {
                    return Items.golden_leggings;
                } else if (par1 == 2) {
                    return Items.chainmail_leggings;
                } else if (par1 == 3) {
                    return Items.iron_leggings;
                } else if (par1 == 4) {
                    return Items.diamond_leggings;
                }
            case 1:
                if (par1 == 0) {
                    return Items.leather_boots;
                } else if (par1 == 1) {
                    return Items.golden_boots;
                } else if (par1 == 2) {
                    return Items.chainmail_boots;
                } else if (par1 == 3) {
                    return Items.iron_boots;
                } else if (par1 == 4) {
                    return Items.diamond_boots;
                }
            default:
                return null;
        }
    }

    protected void enchantEquipment() {
        float f = this.worldObj.getTensionFactorForBlock(this.posX, this.posY, this.posZ);
        if (this.getHeldItem() != null && this.rand.nextFloat() < 0.25F * f) {
            EnchantmentHelper.addRandomEnchantment(this.rand, this.getHeldItem(), (int)(5.0F + f * this.rand.nextInt(18)));
        }

        for (int i = 0; i < 4; i++) {
            ItemStack itemstack = this.func_130225_q(i);
            if (itemstack != null && this.rand.nextFloat() < 0.5F * f) {
                EnchantmentHelper.addRandomEnchantment(this.rand, itemstack, (int)(5.0F + f * this.rand.nextInt(18)));
            }
        }
    }

    public IEntityLivingData onSpawnWithEgg(IEntityLivingData par1EntityLivingData) {
        this.getEntityAttribute(SharedMonsterAttributes.followRange)
            .applyModifier(new AttributeModifier("Random spawn bonus", this.rand.nextGaussian() * 0.05, 1));
        return par1EntityLivingData;
    }

    public boolean canBeSteered() {
        return false;
    }

    @Override
    public String getCommandSenderName() {
        return this.hasCustomNameTag() ? this.getCustomNameTag() : super.getCommandSenderName();
    }

    public void enablePersistence() {
        this.persistenceRequired = true;
    }

    public void setCustomNameTag(String par1Str) {
        this.dataWatcher.updateObject(10, par1Str);
    }

    public String getCustomNameTag() {
        return this.dataWatcher.getWatchableObjectString(10);
    }

    public boolean hasCustomNameTag() {
        return this.dataWatcher.getWatchableObjectString(10).length() > 0;
    }

    public void setAlwaysRenderNameTag(boolean par1) {
        this.dataWatcher.updateObject(11, (byte)(par1 ? 1 : 0));
    }

    public boolean getAlwaysRenderNameTag() {
        return this.dataWatcher.getWatchableObjectByte(11) == 1;
    }

    @Override
    public boolean getAlwaysRenderNameTagForRender() {
        return this.getAlwaysRenderNameTag();
    }

    public void setEquipmentDropChance(int par1, float par2) {
        this.equipmentDropChances[par1] = par2;
    }

    public boolean canPickUpLoot() {
        return this.canPickUpLoot;
    }

    public void setCanPickUpLoot(boolean par1) {
        this.canPickUpLoot = par1;
    }

    public boolean isNoDespawnRequired() {
        return this.persistenceRequired;
    }

    @Override
    public final boolean interactFirst(EntityPlayer par1EntityPlayer) {
        if (this.getLeashed() && this.getLeashedToEntity() == par1EntityPlayer) {
            this.clearLeashed(true, !par1EntityPlayer.capabilities.isCreativeMode);
            return true;
        }

        ItemStack itemstack = par1EntityPlayer.inventory.getCurrentItem();
        if (itemstack != null && itemstack.getItem() == Items.lead && this.allowLeashing()) {
            if (!(this instanceof EntityTameable) || !((EntityTameable)this).isTamed()) {
                this.setLeashedToEntity(par1EntityPlayer, true);
                itemstack.stackSize--;
                return true;
            }

            if (par1EntityPlayer.getCommandSenderName().equalsIgnoreCase(((EntityTameable)this).func_70905_p())) {
                this.setLeashedToEntity(par1EntityPlayer, true);
                itemstack.stackSize--;
                return true;
            }
        }

        return this.interact(par1EntityPlayer) ? true : super.interactFirst(par1EntityPlayer);
    }

    protected boolean interact(EntityPlayer par1EntityPlayer) {
        return false;
    }

    protected void updateLeashedState() {
        if (this.leashNBTTag != null) {
            this.recreateLeash();
        }

        if (this.isLeashed && (this.leashedToEntity == null || this.leashedToEntity.isDead)) {
            this.clearLeashed(true, true);
        }
    }

    public void clearLeashed(boolean par1, boolean par2) {
        if (this.isLeashed) {
            this.isLeashed = false;
            this.leashedToEntity = null;
            if (!this.worldObj.isRemote && par2) {
                this.dropItem(Items.lead, 1);
            }

            if (!this.worldObj.isRemote && par1 && this.worldObj instanceof WorldServer) {
                ((WorldServer)this.worldObj).getEntityTracker().sendToAllTrackingEntity(this, new S1BPacketEntityAttach(1, this, (Entity)null));
            }
        }
    }

    public boolean allowLeashing() {
        return !this.getLeashed() && !(this instanceof IMob);
    }

    public boolean getLeashed() {
        return this.isLeashed;
    }

    public Entity getLeashedToEntity() {
        return this.leashedToEntity;
    }

    public void setLeashedToEntity(Entity par1Entity, boolean par2) {
        this.isLeashed = true;
        this.leashedToEntity = par1Entity;
        if (!this.worldObj.isRemote && par2 && this.worldObj instanceof WorldServer) {
            ((WorldServer)this.worldObj).getEntityTracker().sendToAllTrackingEntity(this, new S1BPacketEntityAttach(1, this, this.leashedToEntity));
        }
    }

    private void recreateLeash() {
        if (this.isLeashed && this.leashNBTTag != null) {
            if (this.leashNBTTag.hasKey("UUIDMost", 4) && this.leashNBTTag.hasKey("UUIDLeast", 4)) {
                UUID uuid = new UUID(this.leashNBTTag.getLong("UUIDMost"), this.leashNBTTag.getLong("UUIDLeast"));

                for (EntityLivingBase entitylivingbase : this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, this.boundingBox.expand(10.0, 10.0, 10.0))) {
                    if (entitylivingbase.getUniqueID().equals(uuid)) {
                        this.leashedToEntity = entitylivingbase;
                        break;
                    }
                }
            } else if (this.leashNBTTag.hasKey("X", 99) && this.leashNBTTag.hasKey("Y", 99) && this.leashNBTTag.hasKey("Z", 99)) {
                int i = this.leashNBTTag.getInteger("X");
                int j = this.leashNBTTag.getInteger("Y");
                int k = this.leashNBTTag.getInteger("Z");
                EntityLeashKnot entityleashknot = EntityLeashKnot.getKnotForBlock(this.worldObj, i, j, k);
                if (entityleashknot == null) {
                    entityleashknot = EntityLeashKnot.func_110129_a(this.worldObj, i, j, k);
                }

                this.leashedToEntity = entityleashknot;
            } else {
                this.clearLeashed(false, true);
            }
        }

        this.leashNBTTag = null;
    }
}
