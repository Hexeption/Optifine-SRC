package net.minecraft.village;

import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.SpawnerAnimals;
import net.minecraft.world.World;

public class VillageSiege {
    private World worldObj;
    private boolean field_75535_b;
    private int field_75536_c = -1;
    private int field_75533_d;
    private int field_75534_e;
    private Village theVillage;
    private int field_75532_g;
    private int field_75538_h;
    private int field_75539_i;

    public VillageSiege(World var1) {
        this.worldObj = var1;
    }

    public void tick() {
        boolean flag = false;
        if (flag) {
            if (this.field_75536_c == 2) {
                this.field_75533_d = 100;
                return;
            }
        } else {
            if (this.worldObj.isDaytime()) {
                this.field_75536_c = 0;
                return;
            }

            if (this.field_75536_c == 2) {
                return;
            }

            if (this.field_75536_c == 0) {
                float f = this.worldObj.getCelestialAngle(0.0F);
                if (f < 0.5 || f > 0.501) {
                    return;
                }

                this.field_75536_c = this.worldObj.rand.nextInt(10) == 0 ? 1 : 2;
                this.field_75535_b = false;
                if (this.field_75536_c == 2) {
                    return;
                }
            }
        }

        if (!this.field_75535_b) {
            if (!this.func_75529_b()) {
                return;
            }

            this.field_75535_b = true;
        }

        if (this.field_75534_e > 0) {
            this.field_75534_e--;
        } else {
            this.field_75534_e = 2;
            if (this.field_75533_d > 0) {
                this.spawnZombie();
                this.field_75533_d--;
            } else {
                this.field_75536_c = 2;
            }
        }
    }

    private boolean func_75529_b() {
        for (EntityPlayer entityplayer : (Iterable<EntityPlayer>) (Iterable) this.worldObj.playerEntities) {
            this.theVillage = this.worldObj.villageCollectionObj.findNearestVillage((int)entityplayer.posX, (int)entityplayer.posY, (int)entityplayer.posZ, 1);
            if (this.theVillage != null
                && this.theVillage.getNumVillageDoors() >= 10
                && this.theVillage.getTicksSinceLastDoorAdding() >= 20
                && this.theVillage.getNumVillagers() >= 20) {
                ChunkCoordinates chunkcoordinates = this.theVillage.getCenter();
                float f = this.theVillage.getVillageRadius();
                boolean flag = false;

                for (int i = 0; i < 10; i++) {
                    this.field_75532_g = chunkcoordinates.posX + (int)(MathHelper.cos(this.worldObj.rand.nextFloat() * (float)Math.PI * 2.0F) * f * 0.9);
                    this.field_75538_h = chunkcoordinates.posY;
                    this.field_75539_i = chunkcoordinates.posZ + (int)(MathHelper.sin(this.worldObj.rand.nextFloat() * (float)Math.PI * 2.0F) * f * 0.9);
                    flag = false;

                    for (Village village : (Iterable<Village>) (Iterable) this.worldObj.villageCollectionObj.getVillageList()) {
                        if (village != this.theVillage && village.isInRange(this.field_75532_g, this.field_75538_h, this.field_75539_i)) {
                            flag = true;
                            break;
                        }
                    }

                    if (!flag) {
                        break;
                    }
                }

                if (flag) {
                    return false;
                }

                Vec3 vec3 = this.func_75527_a(this.field_75532_g, this.field_75538_h, this.field_75539_i);
                if (vec3 != null) {
                    this.field_75534_e = 0;
                    this.field_75533_d = 20;
                    return true;
                }
            }
        }

        return false;
    }

    private boolean spawnZombie() {
        Vec3 vec3 = this.func_75527_a(this.field_75532_g, this.field_75538_h, this.field_75539_i);
        if (vec3 == null) {
            return false;
        }

        EntityZombie entityzombie;
        try {
            entityzombie = new EntityZombie(this.worldObj);
            entityzombie.onSpawnWithEgg(null);
            entityzombie.setVillager(false);
        } catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }

        entityzombie.setLocationAndAngles(vec3.xCoord, vec3.yCoord, vec3.zCoord, this.worldObj.rand.nextFloat() * 360.0F, 0.0F);
        this.worldObj.spawnEntityInWorld(entityzombie);
        ChunkCoordinates chunkcoordinates = this.theVillage.getCenter();
        entityzombie.setHomeArea(chunkcoordinates.posX, chunkcoordinates.posY, chunkcoordinates.posZ, this.theVillage.getVillageRadius());
        return true;
    }

    private Vec3 func_75527_a(int var1, int var2, int var3) {
        for (int i = 0; i < 10; i++) {
            int j = var1 + this.worldObj.rand.nextInt(16) - 8;
            int k = var2 + this.worldObj.rand.nextInt(6) - 3;
            int l = var3 + this.worldObj.rand.nextInt(16) - 8;
            if (this.theVillage.isInRange(j, k, l) && SpawnerAnimals.canCreatureTypeSpawnAtLocation(EnumCreatureType.monster, this.worldObj, j, k, l)) {
                this.worldObj.func_82732_R().func_72345_a(j, k, l);
            }
        }

        return null;
    }
}
