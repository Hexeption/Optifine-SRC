package net.minecraft.network;

import com.google.common.base.Charsets;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import java.net.InetSocketAddress;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LegacyPingHandler extends ChannelInboundHandlerAdapter {
    private static final Logger LOGGER = LogManager.getLogger();
    private NetworkSystem networkSystem;

    public LegacyPingHandler(NetworkSystem networkSystemIn) {
        this.networkSystem = networkSystemIn;
    }

    @Override
    public void channelRead(ChannelHandlerContext p_1, Object p_2) throws Exception {
        ByteBuf bytebuf = (ByteBuf)p_2;
        bytebuf.markReaderIndex();
        boolean flag = true;

        try {
            try {
                if (bytebuf.readUnsignedByte() != 254) {
                    return;
                }

                InetSocketAddress inetsocketaddress = (InetSocketAddress)p_1.channel().remoteAddress();
                MinecraftServer minecraftserver = this.networkSystem.getServer();
                int i = bytebuf.readableBytes();
                switch (i) {
                    case 0:
                        LOGGER.debug("Ping: (<1.3.x) from {}:{}", inetsocketaddress.getAddress(), inetsocketaddress.getPort());
                        String s2 = String.format(
                            "%s\u00a7%d\u00a7%d", minecraftserver.getMOTD(), minecraftserver.getCurrentPlayerCount(), minecraftserver.getMaxPlayers()
                        );
                        this.writeAndFlush(p_1, this.getStringBuffer(s2));
                        break;
                    case 1:
                        if (bytebuf.readUnsignedByte() != 1) {
                            return;
                        }

                        LOGGER.debug("Ping: (1.4-1.5.x) from {}:{}", inetsocketaddress.getAddress(), inetsocketaddress.getPort());
                        String s1 = String.format(
                            "\u00a71\u0000%d\u0000%s\u0000%s\u0000%d\u0000%d",
                            127,
                            minecraftserver.getMinecraftVersion(),
                            minecraftserver.getMOTD(),
                            minecraftserver.getCurrentPlayerCount(),
                            minecraftserver.getMaxPlayers()
                        );
                        this.writeAndFlush(p_1, this.getStringBuffer(s1));
                        break;
                    default:
                        boolean flag1 = bytebuf.readUnsignedByte() == 1;
                        flag1 &= bytebuf.readUnsignedByte() == 250;
                        flag1 &= "MC|PingHost".equals(new String(bytebuf.readBytes(bytebuf.readShort() * 2).array(), Charsets.UTF_16BE));
                        int j = bytebuf.readUnsignedShort();
                        flag1 &= bytebuf.readUnsignedByte() >= 73;
                        flag1 &= 3 + bytebuf.readBytes(bytebuf.readShort() * 2).array().length + 4 == j;
                        flag1 &= bytebuf.readInt() <= 65535;
                        flag1 &= bytebuf.readableBytes() == 0;
                        if (!flag1) {
                            return;
                        }

                        LOGGER.debug("Ping: (1.6) from {}:{}", inetsocketaddress.getAddress(), inetsocketaddress.getPort());
                        String s = String.format(
                            "\u00a71\u0000%d\u0000%s\u0000%s\u0000%d\u0000%d",
                            127,
                            minecraftserver.getMinecraftVersion(),
                            minecraftserver.getMOTD(),
                            minecraftserver.getCurrentPlayerCount(),
                            minecraftserver.getMaxPlayers()
                        );
                        ByteBuf bytebuf1 = this.getStringBuffer(s);

                        try {
                            this.writeAndFlush(p_1, bytebuf1);
                        } finally {
                            bytebuf1.release();
                        }
                }

                bytebuf.release();
                flag = false;
            } catch (RuntimeException runtimeexception) {
            }
        } finally {
            if (flag) {
                bytebuf.resetReaderIndex();
                p_1.channel().pipeline().remove("legacy_query");
                p_1.fireChannelRead(p_2);
            }
        }
    }

    private void writeAndFlush(ChannelHandlerContext ctx, ByteBuf data) {
        ctx.pipeline().firstContext().writeAndFlush(data).addListener(ChannelFutureListener.CLOSE);
    }

    private ByteBuf getStringBuffer(String string) {
        ByteBuf bytebuf = Unpooled.buffer();
        bytebuf.writeByte(255);
        char[] achar = string.toCharArray();
        bytebuf.writeShort(achar.length);

        for (char c0 : achar) {
            bytebuf.writeChar(c0);
        }

        return bytebuf;
    }
}
