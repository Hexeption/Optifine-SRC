package net.minecraft.network.play.server;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.util.LinkedList;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import optifine.Config;

public class SPacketChunkData implements Packet<INetHandlerPlayClient> {
    private int chunkX;
    private int chunkZ;
    private int availableSections;
    private byte[] buffer;
    private boolean loadChunk;
    private static LinkedList<byte[]> cacheBytes = new LinkedList<>();

    public SPacketChunkData() {
    }

    public SPacketChunkData(Chunk chunkIn, boolean p_i46941_2_, int p_i46941_3_) {
        this.chunkX = chunkIn.xPosition;
        this.chunkZ = chunkIn.zPosition;
        this.loadChunk = p_i46941_2_;
        boolean flag = !chunkIn.getWorld().provider.getHasNoSky();
        this.buffer = allocateBytes(calculateChunkSize(chunkIn, p_i46941_2_, flag, p_i46941_3_));
        this.availableSections = extractChunkData(new PacketBuffer(this.getWriteBuffer()), chunkIn, p_i46941_2_, flag, p_i46941_3_);
    }

    @Override
    public void readPacketData(PacketBuffer buf) throws IOException {
        this.chunkX = buf.readInt();
        this.chunkZ = buf.readInt();
        this.loadChunk = buf.readBoolean();
        this.availableSections = buf.readVarIntFromBuffer();
        int i = buf.readVarIntFromBuffer();
        if (i > 2097152) {
            throw new RuntimeException("Chunk Packet trying to allocate too much memory on read.");
        }

        this.buffer = new byte[i];
        buf.readBytes(this.buffer);
    }

    @Override
    public void writePacketData(PacketBuffer buf) throws IOException {
        buf.writeInt(this.chunkX);
        buf.writeInt(this.chunkZ);
        buf.writeBoolean(this.loadChunk);
        buf.writeVarIntToBuffer(this.availableSections);
        buf.writeVarIntToBuffer(this.buffer.length);
        buf.writeBytes(this.buffer);
    }

    public void processPacket(INetHandlerPlayClient handler) {
        handler.handleChunkData(this);
        freeBytes(this.buffer);
    }

    public PacketBuffer getReadBuffer() {
        return new PacketBuffer(Unpooled.wrappedBuffer(this.buffer));
    }

    private ByteBuf getWriteBuffer() {
        ByteBuf bytebuf = Unpooled.wrappedBuffer(this.buffer);
        bytebuf.writerIndex(0);
        return bytebuf;
    }

    public static int extractChunkData(PacketBuffer p_186947_0_, Chunk p_186947_1_, boolean p_186947_2_, boolean p_186947_3_, int p_186947_4_) {
        int i = 0;
        ExtendedBlockStorage[] aextendedblockstorage = p_186947_1_.getBlockStorageArray();
        int j = 0;

        for (int k = aextendedblockstorage.length; j < k; j++) {
            ExtendedBlockStorage extendedblockstorage = aextendedblockstorage[j];
            if (extendedblockstorage != Chunk.NULL_BLOCK_STORAGE && (!p_186947_2_ || !extendedblockstorage.isEmpty()) && (p_186947_4_ & 1 << j) != 0) {
                i |= 1 << j;
                extendedblockstorage.getData().write(p_186947_0_);
                p_186947_0_.writeBytes(extendedblockstorage.getBlocklightArray().getData());
                if (p_186947_3_) {
                    p_186947_0_.writeBytes(extendedblockstorage.getSkylightArray().getData());
                }
            }
        }

        if (p_186947_2_) {
            p_186947_0_.writeBytes(p_186947_1_.getBiomeArray());
        }

        return i;
    }

    protected static int calculateChunkSize(Chunk p_186944_0_, boolean p_186944_1_, boolean p_186944_2_, int p_186944_3_) {
        int i = 0;
        ExtendedBlockStorage[] aextendedblockstorage = p_186944_0_.getBlockStorageArray();
        int j = 0;

        for (int k = aextendedblockstorage.length; j < k; j++) {
            ExtendedBlockStorage extendedblockstorage = aextendedblockstorage[j];
            if (extendedblockstorage != Chunk.NULL_BLOCK_STORAGE && (!p_186944_1_ || !extendedblockstorage.isEmpty()) && (p_186944_3_ & 1 << j) != 0) {
                i += extendedblockstorage.getData().getSerializedSize();
                i += extendedblockstorage.getBlocklightArray().getData().length;
                if (p_186944_2_) {
                    i += extendedblockstorage.getSkylightArray().getData().length;
                }
            }
        }

        if (p_186944_1_) {
            i += p_186944_0_.getBiomeArray().length;
        }

        return i;
    }

    public int getChunkX() {
        return this.chunkX;
    }

    public int getChunkZ() {
        return this.chunkZ;
    }

    public int getExtractedSize() {
        return this.availableSections;
    }

    public boolean doChunkLoad() {
        return this.loadChunk;
    }

    private static byte[] allocateBytes(int size) {
        synchronized (cacheBytes) {
            byte[] abyte = pollBytes(cacheBytes, size);
            if (abyte == null || abyte.length < size) {
                abyte = new byte[size];
            }

            return abyte;
        }
    }

    private static byte[] pollBytes(LinkedList<byte[]> list, int minSize) {
        byte[] abyte = null;
        int i = Integer.MAX_VALUE;

        for (byte[] abyte1 : list) {
            if (abyte1.length >= minSize && abyte1.length <= i) {
                abyte = abyte1;
                i = abyte1.length;
            }
        }

        if (abyte == null) {
            if (list.size() > 0) {
                abyte = list.removeLast();
            }
        } else {
            list.remove(abyte);
        }

        return abyte;
    }

    public static void freeBytes(byte[] bytes) {
        synchronized (cacheBytes) {
            int i = Config.getGameSettings().renderDistanceChunks * 2 + 1;
            if (cacheBytes.size() < i) {
                cacheBytes.add(bytes);
            }
        }
    }
}
