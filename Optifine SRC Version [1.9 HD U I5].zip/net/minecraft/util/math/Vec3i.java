package net.minecraft.util.math;

import com.google.common.base.Objects;

public class Vec3i implements Comparable<Vec3i> {
    public static final Vec3i NULL_VECTOR = new Vec3i(0, 0, 0);
    private final int x;
    private final int y;
    private final int z;

    public Vec3i(int xIn, int yIn, int zIn) {
        this.x = xIn;
        this.y = yIn;
        this.z = zIn;
    }

    public Vec3i(double xIn, double yIn, double zIn) {
        this(MathHelper.floor_double(xIn), MathHelper.floor_double(yIn), MathHelper.floor_double(zIn));
    }

    @Override
    public boolean equals(Object p_1) {
        if (this == p_1) {
            return true;
        } else if (!(p_1 instanceof Vec3i)) {
            return false;
        } else {
            Vec3i vec3i = (Vec3i)p_1;
            if (this.getX() != vec3i.getX()) {
                return false;
            } else {
                return this.getY() != vec3i.getY() ? false : this.getZ() == vec3i.getZ();
            }
        }
    }

    @Override
    public int hashCode() {
        return (this.getY() + this.getZ() * 31) * 31 + this.getX();
    }

    public int compareTo(Vec3i p_1) {
        if (this.getY() == p_1.getY()) {
            return this.getZ() == p_1.getZ() ? this.getX() - p_1.getX() : this.getZ() - p_1.getZ();
        } else {
            return this.getY() - p_1.getY();
        }
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    public Vec3i crossProduct(Vec3i vec) {
        return new Vec3i(
            this.getY() * vec.getZ() - this.getZ() * vec.getY(),
            this.getZ() * vec.getX() - this.getX() * vec.getZ(),
            this.getX() * vec.getY() - this.getY() * vec.getX()
        );
    }

    public double getDistance(int p_185332_1_, int p_185332_2_, int p_185332_3_) {
        double d0 = this.getX() - p_185332_1_;
        double d1 = this.getY() - p_185332_2_;
        double d2 = this.getZ() - p_185332_3_;
        return Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
    }

    public double distanceSq(double toX, double toY, double toZ) {
        double d0 = this.getX() - toX;
        double d1 = this.getY() - toY;
        double d2 = this.getZ() - toZ;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public double distanceSqToCenter(double xIn, double yIn, double zIn) {
        double d0 = this.getX() + 0.5 - xIn;
        double d1 = this.getY() + 0.5 - yIn;
        double d2 = this.getZ() + 0.5 - zIn;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public double distanceSq(Vec3i to) {
        return this.distanceSq(to.getX(), to.getY(), to.getZ());
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("x", this.getX()).add("y", this.getY()).add("z", this.getZ()).toString();
    }
}
