package net.minecraft.util.text;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map.Entry;
import net.minecraft.util.EnumTypeAdapterFactory;
import net.minecraft.util.JsonUtils;

public interface ITextComponent extends Iterable<ITextComponent> {
    ITextComponent setStyle(Style var1);

    Style getStyle();

    ITextComponent appendText(String var1);

    ITextComponent appendSibling(ITextComponent var1);

    String getUnformattedComponentText();

    String getUnformattedText();

    String getFormattedText();

    List<ITextComponent> getSiblings();

    ITextComponent createCopy();

    class Serializer implements JsonDeserializer<ITextComponent>, JsonSerializer<ITextComponent> {
        private static final Gson GSON;

        public ITextComponent deserialize(JsonElement p_1, Type p_2, JsonDeserializationContext p_3) throws JsonParseException {
            if (p_1.isJsonPrimitive()) {
                return new TextComponentString(p_1.getAsString());
            }

            if (!p_1.isJsonObject()) {
                if (p_1.isJsonArray()) {
                    JsonArray jsonarray1 = p_1.getAsJsonArray();
                    ITextComponent itextcomponent1 = null;

                    for (JsonElement jsonelement : jsonarray1) {
                        ITextComponent itextcomponent2 = this.deserialize(jsonelement, jsonelement.getClass(), p_3);
                        if (itextcomponent1 == null) {
                            itextcomponent1 = itextcomponent2;
                        } else {
                            itextcomponent1.appendSibling(itextcomponent2);
                        }
                    }

                    return itextcomponent1;
                } else {
                    throw new JsonParseException("Don't know how to turn " + p_1.toString() + " into a Component");
                }
            } else {
                JsonObject jsonobject = p_1.getAsJsonObject();
                ITextComponent itextcomponent;
                if (jsonobject.has("text")) {
                    itextcomponent = new TextComponentString(jsonobject.get("text").getAsString());
                } else if (jsonobject.has("translate")) {
                    String s = jsonobject.get("translate").getAsString();
                    if (jsonobject.has("with")) {
                        JsonArray jsonarray = jsonobject.getAsJsonArray("with");
                        Object[] aobject = new Object[jsonarray.size()];

                        for (int i = 0; i < aobject.length; i++) {
                            aobject[i] = this.deserialize(jsonarray.get(i), p_2, p_3);
                            if (aobject[i] instanceof TextComponentString) {
                                TextComponentString textcomponentstring = (TextComponentString)aobject[i];
                                if (textcomponentstring.getStyle().isEmpty() && textcomponentstring.getSiblings().isEmpty()) {
                                    aobject[i] = textcomponentstring.getText();
                                }
                            }
                        }

                        itextcomponent = new TextComponentTranslation(s, aobject);
                    } else {
                        itextcomponent = new TextComponentTranslation(s);
                    }
                } else if (jsonobject.has("score")) {
                    JsonObject jsonobject1 = jsonobject.getAsJsonObject("score");
                    if (!jsonobject1.has("name") || !jsonobject1.has("objective")) {
                        throw new JsonParseException("A score component needs a least a name and an objective");
                    }

                    itextcomponent = new TextComponentScore(JsonUtils.getString(jsonobject1, "name"), JsonUtils.getString(jsonobject1, "objective"));
                    if (jsonobject1.has("value")) {
                        ((TextComponentScore)itextcomponent).setValue(JsonUtils.getString(jsonobject1, "value"));
                    }
                } else {
                    if (!jsonobject.has("selector")) {
                        throw new JsonParseException("Don't know how to turn " + p_1.toString() + " into a Component");
                    }

                    itextcomponent = new TextComponentSelector(JsonUtils.getString(jsonobject, "selector"));
                }

                if (jsonobject.has("extra")) {
                    JsonArray jsonarray2 = jsonobject.getAsJsonArray("extra");
                    if (jsonarray2.size() <= 0) {
                        throw new JsonParseException("Unexpected empty array of components");
                    }

                    for (int j = 0; j < jsonarray2.size(); j++) {
                        itextcomponent.appendSibling(this.deserialize(jsonarray2.get(j), p_2, p_3));
                    }
                }

                itextcomponent.setStyle(p_3.deserialize(p_1, Style.class));
                return itextcomponent;
            }
        }

        private void serializeChatStyle(Style style, JsonObject object, JsonSerializationContext ctx) {
            JsonElement jsonelement = ctx.serialize(style);
            if (jsonelement.isJsonObject()) {
                JsonObject jsonobject = (JsonObject)jsonelement;

                for (Entry<String, JsonElement> entry : jsonobject.entrySet()) {
                    object.add(entry.getKey(), entry.getValue());
                }
            }
        }

        public JsonElement serialize(ITextComponent p_1, Type p_2, JsonSerializationContext p_3) {
            JsonObject jsonobject = new JsonObject();
            if (!p_1.getStyle().isEmpty()) {
                this.serializeChatStyle(p_1.getStyle(), jsonobject, p_3);
            }

            if (!p_1.getSiblings().isEmpty()) {
                JsonArray jsonarray = new JsonArray();

                for (ITextComponent itextcomponent : p_1.getSiblings()) {
                    jsonarray.add(this.serialize(itextcomponent, itextcomponent.getClass(), p_3));
                }

                jsonobject.add("extra", jsonarray);
            }

            if (p_1 instanceof TextComponentString) {
                jsonobject.addProperty("text", ((TextComponentString)p_1).getText());
            } else if (p_1 instanceof TextComponentTranslation) {
                TextComponentTranslation textcomponenttranslation = (TextComponentTranslation)p_1;
                jsonobject.addProperty("translate", textcomponenttranslation.getKey());
                if (textcomponenttranslation.getFormatArgs() != null && textcomponenttranslation.getFormatArgs().length > 0) {
                    JsonArray jsonarray1 = new JsonArray();

                    for (Object object : textcomponenttranslation.getFormatArgs()) {
                        if (object instanceof ITextComponent) {
                            jsonarray1.add(this.serialize((ITextComponent)object, object.getClass(), p_3));
                        } else {
                            jsonarray1.add(new JsonPrimitive(String.valueOf(object)));
                        }
                    }

                    jsonobject.add("with", jsonarray1);
                }
            } else if (p_1 instanceof TextComponentScore) {
                TextComponentScore textcomponentscore = (TextComponentScore)p_1;
                JsonObject jsonobject1 = new JsonObject();
                jsonobject1.addProperty("name", textcomponentscore.getName());
                jsonobject1.addProperty("objective", textcomponentscore.getObjective());
                jsonobject1.addProperty("value", textcomponentscore.getUnformattedComponentText());
                jsonobject.add("score", jsonobject1);
            } else {
                if (!(p_1 instanceof TextComponentSelector)) {
                    throw new IllegalArgumentException("Don't know how to serialize " + p_1 + " as a Component");
                }

                TextComponentSelector textcomponentselector = (TextComponentSelector)p_1;
                jsonobject.addProperty("selector", textcomponentselector.getSelector());
            }

            return jsonobject;
        }

        public static String componentToJson(ITextComponent component) {
            return GSON.toJson(component);
        }

        public static ITextComponent jsonToComponent(String json) {
            return JsonUtils.gsonDeserialize(GSON, json, ITextComponent.class, false);
        }

        public static ITextComponent fromJsonLenient(String json) {
            return JsonUtils.gsonDeserialize(GSON, json, ITextComponent.class, true);
        }

        static {
            GsonBuilder gsonbuilder = new GsonBuilder();
            gsonbuilder.registerTypeHierarchyAdapter(ITextComponent.class, new ITextComponent.Serializer());
            gsonbuilder.registerTypeHierarchyAdapter(Style.class, new Style.Serializer());
            gsonbuilder.registerTypeAdapterFactory(new EnumTypeAdapterFactory());
            GSON = gsonbuilder.create();
        }
    }
}
