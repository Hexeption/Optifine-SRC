package net.minecraft.pathfinding;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class PathNavigateGround extends PathNavigate {
    private boolean shouldAvoidSun;

    public PathNavigateGround(EntityLiving entitylivingIn, World worldIn) {
        super(entitylivingIn, worldIn);
    }

    @Override
    protected PathFinder getPathFinder() {
        this.nodeProcessor = new WalkNodeProcessor();
        this.nodeProcessor.setCanEnterDoors(true);
        return new PathFinder(this.nodeProcessor);
    }

    @Override
    protected boolean canNavigate() {
        return this.theEntity.onGround || this.getCanSwim() && this.isInLiquid() || this.theEntity.isRiding();
    }

    @Override
    protected Vec3d getEntityPosition() {
        return new Vec3d(this.theEntity.posX, this.getPathablePosY(), this.theEntity.posZ);
    }

    @Override
    public PathEntity getPathToPos(BlockPos pos) {
        if (this.worldObj.getBlockState(pos).getMaterial() == Material.AIR) {
            BlockPos blockpos = pos.down();

            while (blockpos.getY() > 0 && this.worldObj.getBlockState(blockpos).getMaterial() == Material.AIR) {
                blockpos = blockpos.down();
            }

            if (blockpos.getY() > 0) {
                return super.getPathToPos(blockpos.up());
            }

            while (blockpos.getY() < this.worldObj.getHeight() && this.worldObj.getBlockState(blockpos).getMaterial() == Material.AIR) {
                blockpos = blockpos.up();
            }

            pos = blockpos;
        }

        if (!this.worldObj.getBlockState(pos).getMaterial().isSolid()) {
            return super.getPathToPos(pos);
        }

        BlockPos blockpos1 = pos.up();

        while (blockpos1.getY() < this.worldObj.getHeight() && this.worldObj.getBlockState(blockpos1).getMaterial().isSolid()) {
            blockpos1 = blockpos1.up();
        }

        return super.getPathToPos(blockpos1);
    }

    @Override
    public PathEntity getPathToEntityLiving(Entity entityIn) {
        BlockPos blockpos = new BlockPos(entityIn);
        return this.getPathToPos(blockpos);
    }

    private int getPathablePosY() {
        if (this.theEntity.isInWater() && this.getCanSwim()) {
            int i = (int)this.theEntity.getEntityBoundingBox().minY;
            Block block = this.worldObj
                .getBlockState(new BlockPos(MathHelper.floor_double(this.theEntity.posX), i, MathHelper.floor_double(this.theEntity.posZ)))
                .getBlock();
            int j = 0;

            while (block == Blocks.FLOWING_WATER || block == Blocks.WATER) {
                block = this.worldObj
                    .getBlockState(new BlockPos(MathHelper.floor_double(this.theEntity.posX), ++i, MathHelper.floor_double(this.theEntity.posZ)))
                    .getBlock();
                if (++j > 16) {
                    return (int)this.theEntity.getEntityBoundingBox().minY;
                }
            }

            return i;
        } else {
            return (int)(this.theEntity.getEntityBoundingBox().minY + 0.5);
        }
    }

    @Override
    protected void removeSunnyPath() {
        super.removeSunnyPath();

        for (int i = 0; i < this.currentPath.getCurrentPathLength(); i++) {
            PathPoint pathpoint = this.currentPath.getPathPointFromIndex(i);
            PathPoint pathpoint1 = i + 1 < this.currentPath.getCurrentPathLength() ? this.currentPath.getPathPointFromIndex(i + 1) : null;
            IBlockState iblockstate = this.worldObj.getBlockState(new BlockPos(pathpoint.xCoord, pathpoint.yCoord, pathpoint.zCoord));
            Block block = iblockstate.getBlock();
            if (block == Blocks.CAULDRON) {
                this.currentPath.setPoint(i, pathpoint.cloneMove(pathpoint.xCoord, pathpoint.yCoord + 1, pathpoint.zCoord));
                if (pathpoint1 != null && pathpoint.yCoord >= pathpoint1.yCoord) {
                    this.currentPath.setPoint(i + 1, pathpoint1.cloneMove(pathpoint1.xCoord, pathpoint.yCoord + 1, pathpoint1.zCoord));
                }
            }
        }

        if (this.shouldAvoidSun) {
            if (this.worldObj
                .canSeeSky(
                    new BlockPos(
                        MathHelper.floor_double(this.theEntity.posX),
                        (int)(this.theEntity.getEntityBoundingBox().minY + 0.5),
                        MathHelper.floor_double(this.theEntity.posZ)
                    )
                )) {
                return;
            }

            for (int j = 0; j < this.currentPath.getCurrentPathLength(); j++) {
                PathPoint pathpoint2 = this.currentPath.getPathPointFromIndex(j);
                if (this.worldObj.canSeeSky(new BlockPos(pathpoint2.xCoord, pathpoint2.yCoord, pathpoint2.zCoord))) {
                    this.currentPath.setCurrentPathLength(j - 1);
                    return;
                }
            }
        }
    }

    @Override
    protected boolean isDirectPathBetweenPoints(Vec3d posVec31, Vec3d posVec32, int sizeX, int sizeY, int sizeZ) {
        int i = MathHelper.floor_double(posVec31.xCoord);
        int j = MathHelper.floor_double(posVec31.zCoord);
        double d0 = posVec32.xCoord - posVec31.xCoord;
        double d1 = posVec32.zCoord - posVec31.zCoord;
        double d2 = d0 * d0 + d1 * d1;
        if (d2 < 1.0E-8) {
            return false;
        }

        double d3 = 1.0 / Math.sqrt(d2);
        d0 *= d3;
        d1 *= d3;
        sizeX += 2;
        sizeZ += 2;
        if (!this.isSafeToStandAt(i, (int)posVec31.yCoord, j, sizeX, sizeY, sizeZ, posVec31, d0, d1)) {
            return false;
        }

        sizeX -= 2;
        sizeZ -= 2;
        double d4 = 1.0 / Math.abs(d0);
        double d5 = 1.0 / Math.abs(d1);
        double d6 = i - posVec31.xCoord;
        double d7 = j - posVec31.zCoord;
        if (d0 >= 0.0) {
            d6++;
        }

        if (d1 >= 0.0) {
            d7++;
        }

        d6 /= d0;
        d7 /= d1;
        int k = d0 < 0.0 ? -1 : 1;
        int l = d1 < 0.0 ? -1 : 1;
        int i1 = MathHelper.floor_double(posVec32.xCoord);
        int j1 = MathHelper.floor_double(posVec32.zCoord);
        int k1 = i1 - i;
        int l1 = j1 - j;

        while (k1 * k > 0 || l1 * l > 0) {
            if (d6 < d7) {
                d6 += d4;
                i += k;
                k1 = i1 - i;
            } else {
                d7 += d5;
                j += l;
                l1 = j1 - j;
            }

            if (!this.isSafeToStandAt(i, (int)posVec31.yCoord, j, sizeX, sizeY, sizeZ, posVec31, d0, d1)) {
                return false;
            }
        }

        return true;
    }

    private boolean isSafeToStandAt(int x, int y, int z, int sizeX, int sizeY, int sizeZ, Vec3d vec31, double p_179683_8_, double p_179683_10_) {
        int i = x - sizeX / 2;
        int j = z - sizeZ / 2;
        if (!this.isPositionClear(i, y, j, sizeX, sizeY, sizeZ, vec31, p_179683_8_, p_179683_10_)) {
            return false;
        }

        for (int k = i; k < i + sizeX; k++) {
            for (int l = j; l < j + sizeZ; l++) {
                double d0 = k + 0.5 - vec31.xCoord;
                double d1 = l + 0.5 - vec31.zCoord;
                if (!(d0 * p_179683_8_ + d1 * p_179683_10_ < 0.0)) {
                    PathNodeType pathnodetype = this.nodeProcessor.getPathNodeType(this.worldObj, k, y - 1, l, this.theEntity, sizeX, sizeY, sizeZ, true, true);
                    if (pathnodetype == PathNodeType.WATER) {
                        return false;
                    }

                    if (pathnodetype == PathNodeType.LAVA) {
                        return false;
                    }

                    if (pathnodetype == PathNodeType.OPEN) {
                        return false;
                    }

                    pathnodetype = this.nodeProcessor.getPathNodeType(this.worldObj, k, y, l, this.theEntity, sizeX, sizeY, sizeZ, true, true);
                    float f = this.theEntity.getPathPriority(pathnodetype);
                    if (f < 0.0F || f >= 8.0F) {
                        return false;
                    }

                    if (pathnodetype == PathNodeType.DAMAGE_FIRE || pathnodetype == PathNodeType.DANGER_FIRE || pathnodetype == PathNodeType.DAMAGE_OTHER) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private boolean isPositionClear(
        int p_179692_1_,
        int p_179692_2_,
        int p_179692_3_,
        int p_179692_4_,
        int p_179692_5_,
        int p_179692_6_,
        Vec3d p_179692_7_,
        double p_179692_8_,
        double p_179692_10_
    ) {
        for (BlockPos blockpos : BlockPos.getAllInBox(
            new BlockPos(p_179692_1_, p_179692_2_, p_179692_3_),
            new BlockPos(p_179692_1_ + p_179692_4_ - 1, p_179692_2_ + p_179692_5_ - 1, p_179692_3_ + p_179692_6_ - 1)
        )) {
            double d0 = blockpos.getX() + 0.5 - p_179692_7_.xCoord;
            double d1 = blockpos.getZ() + 0.5 - p_179692_7_.zCoord;
            if (!(d0 * p_179692_8_ + d1 * p_179692_10_ < 0.0)) {
                Block block = this.worldObj.getBlockState(blockpos).getBlock();
                if (!block.isPassable(this.worldObj, blockpos)) {
                    return false;
                }
            }
        }

        return true;
    }

    public void setBreakDoors(boolean canBreakDoors) {
        this.nodeProcessor.setCanBreakDoors(canBreakDoors);
    }

    public void setEnterDoors(boolean enterDoors) {
        this.nodeProcessor.setCanEnterDoors(enterDoors);
    }

    public boolean getEnterDoors() {
        return this.nodeProcessor.getCanEnterDoors();
    }

    public void setCanSwim(boolean canSwim) {
        this.nodeProcessor.setCanSwim(canSwim);
    }

    public boolean getCanSwim() {
        return this.nodeProcessor.getCanSwim();
    }

    public void setAvoidSun(boolean avoidSun) {
        this.shouldAvoidSun = avoidSun;
    }
}
