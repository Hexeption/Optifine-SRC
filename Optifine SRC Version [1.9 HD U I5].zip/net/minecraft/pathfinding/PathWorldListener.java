package net.minecraft.pathfinding;

import java.util.WeakHashMap;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldEventListener;
import net.minecraft.world.World;

public class PathWorldListener implements IWorldEventListener {
    private static final Object PRESENT = new Object();
    private final WeakHashMap<PathNavigate, Object> cache = new WeakHashMap<>();

    public void addPathNavigation(PathNavigate p_184379_1_) {
        this.cache.put(p_184379_1_, PRESENT);
    }

    @Override
    public void notifyBlockUpdate(World worldIn, BlockPos pos, IBlockState oldState, IBlockState newState, int flags) {
        if (this.didBlockChange(worldIn, pos, oldState, newState)) {
            PathNavigate[] apathnavigate = this.cache.keySet().toArray(new PathNavigate[0]);

            for (PathNavigate pathnavigate : apathnavigate) {
                if (pathnavigate != null && !pathnavigate.canUpdatePathOnTimeout()) {
                    PathEntity pathentity = pathnavigate.getPath();
                    if (pathentity != null && !pathentity.isFinished() && pathentity.getCurrentPathLength() != 0) {
                        PathPoint pathpoint = pathnavigate.currentPath.getFinalPathPoint();
                        double d0 = pos.distanceSq(
                            (pathpoint.xCoord + pathnavigate.theEntity.posX) / 2.0,
                            (pathpoint.yCoord + pathnavigate.theEntity.posY) / 2.0,
                            (pathpoint.zCoord + pathnavigate.theEntity.posZ) / 2.0
                        );
                        int i = (pathentity.getCurrentPathLength() - pathentity.getCurrentPathIndex())
                            * (pathentity.getCurrentPathLength() - pathentity.getCurrentPathIndex());
                        if (d0 < i) {
                            pathnavigate.updatePath();
                        }
                    }
                }
            }
        }
    }

    protected boolean didBlockChange(World worldIn, BlockPos pos, IBlockState oldState, IBlockState newState) {
        AxisAlignedBB axisalignedbb = oldState.getCollisionBoundingBox(worldIn, pos);
        AxisAlignedBB axisalignedbb1 = newState.getCollisionBoundingBox(worldIn, pos);
        return axisalignedbb != axisalignedbb1 && (axisalignedbb == null || !axisalignedbb.equals(axisalignedbb1));
    }

    @Override
    public void notifyLightSet(BlockPos pos) {
    }

    @Override
    public void markBlockRangeForRenderUpdate(int x1, int y1, int z1, int x2, int y2, int z2) {
    }

    @Override
    public void playSoundToAllNearExcept(
        EntityPlayer player, SoundEvent soundIn, SoundCategory category, double x, double y, double z, float volume, float pitch
    ) {
    }

    @Override
    public void spawnParticle(
        int particleID, boolean ignoreRange, double xCoord, double yCoord, double zCoord, double xSpeed, double ySpeed, double zSpeed, int... parameters
    ) {
    }

    @Override
    public void onEntityAdded(Entity entityIn) {
    }

    @Override
    public void onEntityRemoved(Entity entityIn) {
    }

    @Override
    public void playRecord(SoundEvent soundIn, BlockPos pos) {
    }

    @Override
    public void broadcastSound(int soundID, BlockPos pos, int data) {
    }

    @Override
    public void playEvent(EntityPlayer player, int type, BlockPos blockPosIn, int data) {
    }

    @Override
    public void sendBlockBreakProgress(int breakerId, BlockPos pos, int progress) {
    }
}
