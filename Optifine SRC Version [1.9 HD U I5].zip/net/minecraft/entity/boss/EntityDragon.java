package net.minecraft.entity.boss;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.dragon.phase.IPhase;
import net.minecraft.entity.boss.dragon.phase.PhaseList;
import net.minecraft.entity.boss.dragon.phase.PhaseManager;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.Path;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldProviderEnd;
import net.minecraft.world.end.DragonFightManager;
import net.minecraft.world.gen.feature.WorldGenEndPodium;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityDragon extends EntityLiving implements IEntityMultiPart, IMob {
    private static final Logger LOGGER = LogManager.getLogger();
    public static final DataParameter<Integer> PHASE = EntityDataManager.createKey(EntityDragon.class, DataSerializers.VARINT);
    public double[][] ringBuffer = new double[64][3];
    public int ringBufferIndex = -1;
    public EntityDragonPart[] dragonPartArray;
    public EntityDragonPart dragonPartHead;
    public EntityDragonPart dragonPartNeck;
    public EntityDragonPart dragonPartBody;
    public EntityDragonPart dragonPartTail1;
    public EntityDragonPart dragonPartTail2;
    public EntityDragonPart dragonPartTail3;
    public EntityDragonPart dragonPartWing1;
    public EntityDragonPart dragonPartWing2;
    public float prevAnimTime;
    public float animTime;
    public boolean slowed;
    public int deathTicks;
    public EntityEnderCrystal healingEnderCrystal;
    private final DragonFightManager fightManager;
    private final PhaseManager phaseManager;
    private int growlTime = 200;
    private int sittingDamageReceived;
    private final PathPoint[] pathPoints = new PathPoint[24];
    private final int[] neighbors = new int[24];
    private final Path pathFindQueue = new Path();

    public EntityDragon(World worldIn) {
        super(worldIn);
        this.dragonPartArray = new EntityDragonPart[]{
            this.dragonPartHead = new EntityDragonPart(this, "head", 6.0F, 6.0F),
            this.dragonPartNeck = new EntityDragonPart(this, "neck", 6.0F, 6.0F),
            this.dragonPartBody = new EntityDragonPart(this, "body", 8.0F, 8.0F),
            this.dragonPartTail1 = new EntityDragonPart(this, "tail", 4.0F, 4.0F),
            this.dragonPartTail2 = new EntityDragonPart(this, "tail", 4.0F, 4.0F),
            this.dragonPartTail3 = new EntityDragonPart(this, "tail", 4.0F, 4.0F),
            this.dragonPartWing1 = new EntityDragonPart(this, "wing", 4.0F, 4.0F),
            this.dragonPartWing2 = new EntityDragonPart(this, "wing", 4.0F, 4.0F)
        };
        this.setHealth(this.getMaxHealth());
        this.setSize(16.0F, 8.0F);
        this.noClip = true;
        this.isImmuneToFire = true;
        this.growlTime = 100;
        this.ignoreFrustumCheck = true;
        if (!worldIn.isRemote && worldIn.provider instanceof WorldProviderEnd) {
            this.fightManager = ((WorldProviderEnd)worldIn.provider).getDragonFightManager();
        } else {
            this.fightManager = null;
        }

        this.phaseManager = new PhaseManager(this);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(200.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.getDataManager().register(PHASE, PhaseList.HOVER.getId());
    }

    public double[] getMovementOffsets(int p_70974_1_, float p_70974_2_) {
        if (this.getHealth() <= 0.0F) {
            p_70974_2_ = 0.0F;
        }

        p_70974_2_ = 1.0F - p_70974_2_;
        int i = this.ringBufferIndex - p_70974_1_ & 63;
        int j = this.ringBufferIndex - p_70974_1_ - 1 & 63;
        double[] adouble = new double[3];
        double d0 = this.ringBuffer[i][0];
        double d1 = MathHelper.wrapDegrees(this.ringBuffer[j][0] - d0);
        adouble[0] = d0 + d1 * p_70974_2_;
        d0 = this.ringBuffer[i][1];
        d1 = this.ringBuffer[j][1] - d0;
        adouble[1] = d0 + d1 * p_70974_2_;
        adouble[2] = this.ringBuffer[i][2] + (this.ringBuffer[j][2] - this.ringBuffer[i][2]) * p_70974_2_;
        return adouble;
    }

    @Override
    public void onLivingUpdate() {
        if (this.worldObj.isRemote) {
            this.setHealth(this.getHealth());
            if (!this.isSilent()) {
                float f = MathHelper.cos(this.animTime * ((float)Math.PI * 2.0F));
                float f1 = MathHelper.cos(this.prevAnimTime * ((float)Math.PI * 2.0F));
                if (f1 <= -0.3F && f >= -0.3F) {
                    this.worldObj
                        .playSound(
                            this.posX,
                            this.posY,
                            this.posZ,
                            SoundEvents.ENTITY_ENDERDRAGON_FLAP,
                            this.getSoundCategory(),
                            5.0F,
                            0.8F + this.rand.nextFloat() * 0.3F,
                            false
                        );
                }

                if (!this.phaseManager.getCurrentPhase().getIsStationary() && --this.growlTime < 0) {
                    this.worldObj
                        .playSound(
                            this.posX,
                            this.posY,
                            this.posZ,
                            SoundEvents.ENTITY_ENDERDRAGON_GROWL,
                            this.getSoundCategory(),
                            2.5F,
                            0.8F + this.rand.nextFloat() * 0.3F,
                            false
                        );
                    this.growlTime = 200 + this.rand.nextInt(200);
                }
            }
        }

        this.prevAnimTime = this.animTime;
        if (this.getHealth() <= 0.0F) {
            float f13 = (this.rand.nextFloat() - 0.5F) * 8.0F;
            float f15 = (this.rand.nextFloat() - 0.5F) * 4.0F;
            float f17 = (this.rand.nextFloat() - 0.5F) * 8.0F;
            this.worldObj.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, this.posX + f13, this.posY + 2.0 + f15, this.posZ + f17, 0.0, 0.0, 0.0);
        } else {
            this.updateDragonEnderCrystal();
            float f12 = 0.2F / (MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ) * 10.0F + 1.0F);
            f12 *= (float)Math.pow(2.0, this.motionY);
            if (this.phaseManager.getCurrentPhase().getIsStationary()) {
                this.animTime += 0.1F;
            } else if (this.slowed) {
                this.animTime += f12 * 0.5F;
            } else {
                this.animTime += f12;
            }

            this.rotationYaw = MathHelper.wrapDegrees(this.rotationYaw);
            if (this.isAIDisabled()) {
                this.animTime = 0.5F;
            } else {
                if (this.ringBufferIndex < 0) {
                    for (int i = 0; i < this.ringBuffer.length; i++) {
                        this.ringBuffer[i][0] = this.rotationYaw;
                        this.ringBuffer[i][1] = this.posY;
                    }
                }

                if (++this.ringBufferIndex == this.ringBuffer.length) {
                    this.ringBufferIndex = 0;
                }

                this.ringBuffer[this.ringBufferIndex][0] = this.rotationYaw;
                this.ringBuffer[this.ringBufferIndex][1] = this.posY;
                if (this.worldObj.isRemote) {
                    if (this.newPosRotationIncrements > 0) {
                        double d5 = this.posX + (this.interpTargetX - this.posX) / this.newPosRotationIncrements;
                        double d0 = this.posY + (this.interpTargetY - this.posY) / this.newPosRotationIncrements;
                        double d1 = this.posZ + (this.interpTargetZ - this.posZ) / this.newPosRotationIncrements;
                        double d2 = MathHelper.wrapDegrees(this.interpTargetYaw - this.rotationYaw);
                        this.rotationYaw = (float)(this.rotationYaw + d2 / this.newPosRotationIncrements);
                        this.rotationPitch = (float)(this.rotationPitch + (this.interpTargetPitch - this.rotationPitch) / this.newPosRotationIncrements);
                        this.newPosRotationIncrements--;
                        this.setPosition(d5, d0, d1);
                        this.setRotation(this.rotationYaw, this.rotationPitch);
                    }

                    this.phaseManager.getCurrentPhase().doClientRenderEffects();
                } else {
                    IPhase iphase = this.phaseManager.getCurrentPhase();
                    iphase.doLocalUpdate();
                    if (this.phaseManager.getCurrentPhase() != iphase) {
                        iphase = this.phaseManager.getCurrentPhase();
                        iphase.doLocalUpdate();
                    }

                    Vec3d vec3d = iphase.getTargetLocation();
                    if (vec3d != null) {
                        double d6 = vec3d.xCoord - this.posX;
                        double d7 = vec3d.yCoord - this.posY;
                        double d8 = vec3d.zCoord - this.posZ;
                        double d3 = d6 * d6 + d7 * d7 + d8 * d8;
                        float f6 = iphase.getMaxRiseOrFall();
                        d7 = MathHelper.clamp_double(d7 / MathHelper.sqrt_double(d6 * d6 + d8 * d8), -f6, f6);
                        this.motionY += d7 * 0.1F;
                        this.rotationYaw = MathHelper.wrapDegrees(this.rotationYaw);
                        double d4 = MathHelper.clamp_double(
                            MathHelper.wrapDegrees(180.0 - MathHelper.atan2(d6, d8) * (180.0F / (float)Math.PI) - this.rotationYaw), -50.0, 50.0
                        );
                        Vec3d vec3d1 = new Vec3d(vec3d.xCoord - this.posX, vec3d.yCoord - this.posY, vec3d.zCoord - this.posZ).normalize();
                        Vec3d vec3d2 = new Vec3d(
                                MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180.0F)),
                                this.motionY,
                                -MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180.0F))
                            )
                            .normalize();
                        float f8 = Math.max(((float)vec3d2.dotProduct(vec3d1) + 0.5F) / 1.5F, 0.0F);
                        this.randomYawVelocity *= 0.8F;
                        this.randomYawVelocity = (float)(this.randomYawVelocity + d4 * iphase.getYawFactor());
                        this.rotationYaw = this.rotationYaw + this.randomYawVelocity * 0.1F;
                        float f9 = (float)(2.0 / (d3 + 1.0));
                        float f10 = 0.06F;
                        this.moveRelative(0.0F, -1.0F, f10 * (f8 * f9 + (1.0F - f9)));
                        if (this.slowed) {
                            this.moveEntity(this.motionX * 0.8F, this.motionY * 0.8F, this.motionZ * 0.8F);
                        } else {
                            this.moveEntity(this.motionX, this.motionY, this.motionZ);
                        }

                        Vec3d vec3d3 = new Vec3d(this.motionX, this.motionY, this.motionZ).normalize();
                        float f11 = ((float)vec3d3.dotProduct(vec3d2) + 1.0F) / 2.0F;
                        f11 = 0.8F + 0.15F * f11;
                        this.motionX *= f11;
                        this.motionZ *= f11;
                        this.motionY *= 0.91F;
                    }
                }

                this.renderYawOffset = this.rotationYaw;
                this.dragonPartHead.width = this.dragonPartHead.height = 1.0F;
                this.dragonPartNeck.width = this.dragonPartNeck.height = 3.0F;
                this.dragonPartTail1.width = this.dragonPartTail1.height = 2.0F;
                this.dragonPartTail2.width = this.dragonPartTail2.height = 2.0F;
                this.dragonPartTail3.width = this.dragonPartTail3.height = 2.0F;
                this.dragonPartBody.height = 3.0F;
                this.dragonPartBody.width = 5.0F;
                this.dragonPartWing1.height = 2.0F;
                this.dragonPartWing1.width = 4.0F;
                this.dragonPartWing2.height = 3.0F;
                this.dragonPartWing2.width = 4.0F;
                float f14 = (float)(this.getMovementOffsets(5, 1.0F)[1] - this.getMovementOffsets(10, 1.0F)[1]) * 10.0F * ((float)Math.PI / 180.0F);
                float f16 = MathHelper.cos(f14);
                float f18 = MathHelper.sin(f14);
                float f2 = this.rotationYaw * ((float)Math.PI / 180.0F);
                float f19 = MathHelper.sin(f2);
                float f3 = MathHelper.cos(f2);
                this.dragonPartBody.onUpdate();
                this.dragonPartBody.setLocationAndAngles(this.posX + f19 * 0.5F, this.posY, this.posZ - f3 * 0.5F, 0.0F, 0.0F);
                this.dragonPartWing1.onUpdate();
                this.dragonPartWing1.setLocationAndAngles(this.posX + f3 * 4.5F, this.posY + 2.0, this.posZ + f19 * 4.5F, 0.0F, 0.0F);
                this.dragonPartWing2.onUpdate();
                this.dragonPartWing2.setLocationAndAngles(this.posX - f3 * 4.5F, this.posY + 2.0, this.posZ - f19 * 4.5F, 0.0F, 0.0F);
                if (!this.worldObj.isRemote && this.hurtTime == 0) {
                    this.collideWithEntities(
                        this.worldObj
                            .getEntitiesWithinAABBExcludingEntity(
                                this, this.dragonPartWing1.getEntityBoundingBox().expand(4.0, 2.0, 4.0).offset(0.0, -2.0, 0.0)
                            )
                    );
                    this.collideWithEntities(
                        this.worldObj
                            .getEntitiesWithinAABBExcludingEntity(
                                this, this.dragonPartWing2.getEntityBoundingBox().expand(4.0, 2.0, 4.0).offset(0.0, -2.0, 0.0)
                            )
                    );
                    this.attackEntitiesInList(
                        this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.dragonPartHead.getEntityBoundingBox().expandXyz(1.0))
                    );
                    this.attackEntitiesInList(
                        this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.dragonPartNeck.getEntityBoundingBox().expandXyz(1.0))
                    );
                }

                double[] adouble = this.getMovementOffsets(5, 1.0F);
                float f4 = MathHelper.sin(this.rotationYaw * ((float)Math.PI / 180.0F) - this.randomYawVelocity * 0.01F);
                float f20 = MathHelper.cos(this.rotationYaw * ((float)Math.PI / 180.0F) - this.randomYawVelocity * 0.01F);
                this.dragonPartHead.onUpdate();
                this.dragonPartNeck.onUpdate();
                float f5 = this.getHeadYOffset(1.0F);
                this.dragonPartHead.setLocationAndAngles(this.posX + f4 * 6.5F * f16, this.posY + f5 + f18 * 6.5F, this.posZ - f20 * 6.5F * f16, 0.0F, 0.0F);
                this.dragonPartNeck.setLocationAndAngles(this.posX + f4 * 5.5F * f16, this.posY + f5 + f18 * 5.5F, this.posZ - f20 * 5.5F * f16, 0.0F, 0.0F);

                for (int j = 0; j < 3; j++) {
                    EntityDragonPart entitydragonpart = null;
                    if (j == 0) {
                        entitydragonpart = this.dragonPartTail1;
                    }

                    if (j == 1) {
                        entitydragonpart = this.dragonPartTail2;
                    }

                    if (j == 2) {
                        entitydragonpart = this.dragonPartTail3;
                    }

                    double[] adouble1 = this.getMovementOffsets(12 + j * 2, 1.0F);
                    float f21 = this.rotationYaw * ((float)Math.PI / 180.0F) + this.simplifyAngle(adouble1[0] - adouble[0]) * ((float)Math.PI / 180.0F);
                    float f22 = MathHelper.sin(f21);
                    float f7 = MathHelper.cos(f21);
                    float f23 = 1.5F;
                    float f24 = (j + 1) * 2.0F;
                    entitydragonpart.onUpdate();
                    entitydragonpart.setLocationAndAngles(
                        this.posX - (f19 * f23 + f22 * f24) * f16,
                        this.posY + (adouble1[1] - adouble[1]) - (f24 + f23) * f18 + 1.5,
                        this.posZ + (f3 * f23 + f7 * f24) * f16,
                        0.0F,
                        0.0F
                    );
                }

                if (!this.worldObj.isRemote) {
                    this.slowed = this.destroyBlocksInAABB(this.dragonPartHead.getEntityBoundingBox())
                        | this.destroyBlocksInAABB(this.dragonPartNeck.getEntityBoundingBox())
                        | this.destroyBlocksInAABB(this.dragonPartBody.getEntityBoundingBox());
                    if (this.fightManager != null) {
                        this.fightManager.dragonUpdate(this);
                    }
                }
            }
        }
    }

    private float getHeadYOffset(float p_184662_1_) {
        double d0 = 0.0;
        if (this.phaseManager.getCurrentPhase().getIsStationary()) {
            d0 = -1.0;
        } else {
            double[] adouble = this.getMovementOffsets(5, 1.0F);
            double[] adouble1 = this.getMovementOffsets(0, 1.0F);
            d0 = adouble[1] - adouble1[0];
        }

        return (float)d0;
    }

    private void updateDragonEnderCrystal() {
        if (this.healingEnderCrystal != null) {
            if (this.healingEnderCrystal.isDead) {
                this.healingEnderCrystal = null;
            } else if (this.ticksExisted % 10 == 0 && this.getHealth() < this.getMaxHealth()) {
                this.setHealth(this.getHealth() + 1.0F);
            }
        }

        if (this.rand.nextInt(10) == 0) {
            List<EntityEnderCrystal> list = this.worldObj.getEntitiesWithinAABB(EntityEnderCrystal.class, this.getEntityBoundingBox().expandXyz(32.0));
            EntityEnderCrystal entityendercrystal = null;
            double d0 = Double.MAX_VALUE;

            for (EntityEnderCrystal entityendercrystal1 : list) {
                double d1 = entityendercrystal1.getDistanceSqToEntity(this);
                if (d1 < d0) {
                    d0 = d1;
                    entityendercrystal = entityendercrystal1;
                }
            }

            this.healingEnderCrystal = entityendercrystal;
        }
    }

    private void collideWithEntities(List<Entity> p_70970_1_) {
        double d0 = (this.dragonPartBody.getEntityBoundingBox().minX + this.dragonPartBody.getEntityBoundingBox().maxX) / 2.0;
        double d1 = (this.dragonPartBody.getEntityBoundingBox().minZ + this.dragonPartBody.getEntityBoundingBox().maxZ) / 2.0;

        for (Entity entity : p_70970_1_) {
            if (entity instanceof EntityLivingBase) {
                double d2 = entity.posX - d0;
                double d3 = entity.posZ - d1;
                double d4 = d2 * d2 + d3 * d3;
                entity.addVelocity(d2 / d4 * 4.0, 0.2F, d3 / d4 * 4.0);
                if (!this.phaseManager.getCurrentPhase().getIsStationary() && ((EntityLivingBase)entity).getRevengeTimer() < entity.ticksExisted - 2) {
                    entity.attackEntityFrom(DamageSource.causeMobDamage(this), 5.0F);
                    this.applyEnchantments(this, entity);
                }
            }
        }
    }

    private void attackEntitiesInList(List<Entity> p_70971_1_) {
        for (int i = 0; i < p_70971_1_.size(); i++) {
            Entity entity = p_70971_1_.get(i);
            if (entity instanceof EntityLivingBase) {
                entity.attackEntityFrom(DamageSource.causeMobDamage(this), 10.0F);
                this.applyEnchantments(this, entity);
            }
        }
    }

    private float simplifyAngle(double p_70973_1_) {
        return (float)MathHelper.wrapDegrees(p_70973_1_);
    }

    private boolean destroyBlocksInAABB(AxisAlignedBB p_70972_1_) {
        int i = MathHelper.floor_double(p_70972_1_.minX);
        int j = MathHelper.floor_double(p_70972_1_.minY);
        int k = MathHelper.floor_double(p_70972_1_.minZ);
        int l = MathHelper.floor_double(p_70972_1_.maxX);
        int i1 = MathHelper.floor_double(p_70972_1_.maxY);
        int j1 = MathHelper.floor_double(p_70972_1_.maxZ);
        boolean flag = false;
        boolean flag1 = false;

        for (int k1 = i; k1 <= l; k1++) {
            for (int l1 = j; l1 <= i1; l1++) {
                for (int i2 = k; i2 <= j1; i2++) {
                    BlockPos blockpos = new BlockPos(k1, l1, i2);
                    IBlockState iblockstate = this.worldObj.getBlockState(blockpos);
                    Block block = iblockstate.getBlock();
                    if (iblockstate.getMaterial() != Material.AIR && iblockstate.getMaterial() != Material.FIRE) {
                        if (!this.worldObj.getGameRules().getBoolean("mobGriefing")) {
                            flag = true;
                        } else if (block == Blocks.BARRIER
                            || block == Blocks.OBSIDIAN
                            || block == Blocks.END_STONE
                            || block == Blocks.BEDROCK
                            || block == Blocks.END_PORTAL
                            || block == Blocks.END_PORTAL_FRAME) {
                            flag = true;
                        } else if (block != Blocks.COMMAND_BLOCK
                            && block != Blocks.REPEATING_COMMAND_BLOCK
                            && block != Blocks.CHAIN_COMMAND_BLOCK
                            && block != Blocks.IRON_BARS
                            && block != Blocks.END_GATEWAY) {
                            flag1 = this.worldObj.setBlockToAir(blockpos) || flag1;
                        } else {
                            flag = true;
                        }
                    }
                }
            }
        }

        if (flag1) {
            double d0 = p_70972_1_.minX + (p_70972_1_.maxX - p_70972_1_.minX) * this.rand.nextFloat();
            double d1 = p_70972_1_.minY + (p_70972_1_.maxY - p_70972_1_.minY) * this.rand.nextFloat();
            double d2 = p_70972_1_.minZ + (p_70972_1_.maxZ - p_70972_1_.minZ) * this.rand.nextFloat();
            this.worldObj.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, d0, d1, d2, 0.0, 0.0, 0.0);
        }

        return flag;
    }

    @Override
    public boolean attackEntityFromPart(EntityDragonPart dragonPart, DamageSource source, float damage) {
        damage = this.phaseManager.getCurrentPhase().getAdjustedDamage(dragonPart, source, damage);
        if (dragonPart != this.dragonPartHead) {
            damage = damage / 4.0F + Math.min(damage, 1.0F);
        }

        if (damage < 0.01F) {
            return false;
        }

        if (source.getEntity() instanceof EntityPlayer || source.isExplosion()) {
            float f = this.getHealth();
            this.attackDragonFrom(source, damage);
            if (this.getHealth() <= 0.0F && !this.phaseManager.getCurrentPhase().getIsStationary()) {
                this.setHealth(1.0F);
                this.phaseManager.setPhase(PhaseList.DYING);
            }

            if (this.phaseManager.getCurrentPhase().getIsStationary()) {
                this.sittingDamageReceived = (int)(this.sittingDamageReceived + (f - this.getHealth()));
                if (this.sittingDamageReceived > 0.25F * this.getMaxHealth()) {
                    this.sittingDamageReceived = 0;
                    this.phaseManager.setPhase(PhaseList.TAKEOFF);
                }
            }
        }

        return true;
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (source instanceof EntityDamageSource && ((EntityDamageSource)source).getIsThornsDamage()) {
            this.attackEntityFromPart(this.dragonPartBody, source, amount);
        }

        return false;
    }

    protected boolean attackDragonFrom(DamageSource source, float amount) {
        return super.attackEntityFrom(source, amount);
    }

    @Override
    public void onKillCommand() {
        this.setDead();
        if (this.fightManager != null) {
            this.fightManager.dragonUpdate(this);
            this.fightManager.processDragonDeath(this);
        }
    }

    @Override
    protected void onDeathUpdate() {
        if (this.fightManager != null) {
            this.fightManager.dragonUpdate(this);
        }

        this.deathTicks++;
        if (this.deathTicks >= 180 && this.deathTicks <= 200) {
            float f = (this.rand.nextFloat() - 0.5F) * 8.0F;
            float f1 = (this.rand.nextFloat() - 0.5F) * 4.0F;
            float f2 = (this.rand.nextFloat() - 0.5F) * 8.0F;
            this.worldObj.spawnParticle(EnumParticleTypes.EXPLOSION_HUGE, this.posX + f, this.posY + 2.0 + f1, this.posZ + f2, 0.0, 0.0, 0.0);
        }

        boolean flag = this.worldObj.getGameRules().getBoolean("doMobLoot");
        int i = 500;
        if (this.fightManager != null && !this.fightManager.hasPreviouslyKilledDragon()) {
            i = 12000;
        }

        if (!this.worldObj.isRemote) {
            if (this.deathTicks > 150 && this.deathTicks % 5 == 0 && flag) {
                this.dropExperience(MathHelper.floor_float(i * 0.08F));
            }

            if (this.deathTicks == 1) {
                this.worldObj.playBroadcastSound(1028, new BlockPos(this), 0);
            }
        }

        this.moveEntity(0.0, 0.1F, 0.0);
        this.renderYawOffset = this.rotationYaw += 20.0F;
        if (this.deathTicks == 200 && !this.worldObj.isRemote) {
            if (flag) {
                this.dropExperience(MathHelper.floor_float(i * 0.2F));
            }

            if (this.fightManager != null) {
                this.fightManager.processDragonDeath(this);
            }

            this.setDead();
        }
    }

    private void dropExperience(int p_184668_1_) {
        while (p_184668_1_ > 0) {
            int i = EntityXPOrb.getXPSplit(p_184668_1_);
            p_184668_1_ -= i;
            this.worldObj.spawnEntityInWorld(new EntityXPOrb(this.worldObj, this.posX, this.posY, this.posZ, i));
        }
    }

    public int initPathPoints() {
        if (this.pathPoints[0] == null) {
            int i = 0;
            int j = 0;
            int k = 0;
            int l = 0;

            for (int i1 = 0; i1 < 24; i1++) {
                int j1 = 5;
                l = i1;
                if (i1 < 12) {
                    i = (int)(60.0F * MathHelper.cos(2.0F * (-((float)Math.PI) + (float) (Math.PI / 12) * l)));
                    k = (int)(60.0F * MathHelper.sin(2.0F * (-((float)Math.PI) + (float) (Math.PI / 12) * l)));
                } else if (i1 < 20) {
                    l -= 12;
                    i = (int)(40.0F * MathHelper.cos(2.0F * (-((float)Math.PI) + (float)Math.PI * 0.125F * l)));
                    k = (int)(40.0F * MathHelper.sin(2.0F * (-((float)Math.PI) + (float)Math.PI * 0.125F * l)));
                    j1 += 10;
                } else {
                    l -= 20;
                    i = (int)(20.0F * MathHelper.cos(2.0F * (-((float)Math.PI) + (float)Math.PI * 0.25F * l)));
                    k = (int)(20.0F * MathHelper.sin(2.0F * (-((float)Math.PI) + (float)Math.PI * 0.25F * l)));
                }

                j = Math.max(this.worldObj.getSeaLevel() + 10, this.worldObj.getTopSolidOrLiquidBlock(new BlockPos(i, 0, k)).getY() + j1);
                this.pathPoints[i1] = new PathPoint(i, j, k);
            }

            this.neighbors[0] = 6146;
            this.neighbors[1] = 8197;
            this.neighbors[2] = 8202;
            this.neighbors[3] = 16404;
            this.neighbors[4] = 32808;
            this.neighbors[5] = 32848;
            this.neighbors[6] = 65696;
            this.neighbors[7] = 131392;
            this.neighbors[8] = 131712;
            this.neighbors[9] = 263424;
            this.neighbors[10] = 526848;
            this.neighbors[11] = 525313;
            this.neighbors[12] = 1581057;
            this.neighbors[13] = 3166214;
            this.neighbors[14] = 2138120;
            this.neighbors[15] = 6373424;
            this.neighbors[16] = 4358208;
            this.neighbors[17] = 12910976;
            this.neighbors[18] = 9044480;
            this.neighbors[19] = 9706496;
            this.neighbors[20] = 15216640;
            this.neighbors[21] = 13688832;
            this.neighbors[22] = 11763712;
            this.neighbors[23] = 8257536;
        }

        return this.getNearestPpIdx(this.posX, this.posY, this.posZ);
    }

    public int getNearestPpIdx(double x, double y, double z) {
        float f = 10000.0F;
        int i = 0;
        PathPoint pathpoint = new PathPoint(MathHelper.floor_double(x), MathHelper.floor_double(y), MathHelper.floor_double(z));
        int j = 0;
        if (this.fightManager == null || this.fightManager.getNumAliveCrystals() == 0) {
            j = 12;
        }

        for (int k = j; k < 24; k++) {
            if (this.pathPoints[k] != null) {
                float f1 = this.pathPoints[k].distanceToSquared(pathpoint);
                if (f1 < f) {
                    f = f1;
                    i = k;
                }
            }
        }

        return i;
    }

    public PathEntity findPath(int startIdx, int finishIdx, PathPoint andThen) {
        for (int i = 0; i < 24; i++) {
            PathPoint pathpoint = this.pathPoints[i];
            pathpoint.visited = false;
            pathpoint.distanceToTarget = 0.0F;
            pathpoint.totalPathDistance = 0.0F;
            pathpoint.distanceToNext = 0.0F;
            pathpoint.previous = null;
            pathpoint.index = -1;
        }

        PathPoint pathpoint4 = this.pathPoints[startIdx];
        PathPoint pathpoint5 = this.pathPoints[finishIdx];
        pathpoint4.totalPathDistance = 0.0F;
        pathpoint4.distanceToNext = pathpoint4.distanceTo(pathpoint5);
        pathpoint4.distanceToTarget = pathpoint4.distanceToNext;
        this.pathFindQueue.clearPath();
        this.pathFindQueue.addPoint(pathpoint4);
        PathPoint pathpoint1 = pathpoint4;
        int j = 0;
        if (this.fightManager == null || this.fightManager.getNumAliveCrystals() == 0) {
            j = 12;
        }

        while (!this.pathFindQueue.isPathEmpty()) {
            PathPoint pathpoint2 = this.pathFindQueue.dequeue();
            if (pathpoint2.equals(pathpoint5)) {
                if (andThen != null) {
                    andThen.previous = pathpoint5;
                    pathpoint5 = andThen;
                }

                return this.makePath(pathpoint4, pathpoint5);
            }

            if (pathpoint2.distanceTo(pathpoint5) < pathpoint1.distanceTo(pathpoint5)) {
                pathpoint1 = pathpoint2;
            }

            pathpoint2.visited = true;
            int k = 0;

            for (int l = 0; l < 24; l++) {
                if (this.pathPoints[l] == pathpoint2) {
                    k = l;
                    break;
                }
            }

            for (int i1 = j; i1 < 24; i1++) {
                if ((this.neighbors[k] & 1 << i1) > 0) {
                    PathPoint pathpoint3 = this.pathPoints[i1];
                    if (!pathpoint3.visited) {
                        float f = pathpoint2.totalPathDistance + pathpoint2.distanceTo(pathpoint3);
                        if (!pathpoint3.isAssigned() || f < pathpoint3.totalPathDistance) {
                            pathpoint3.previous = pathpoint2;
                            pathpoint3.totalPathDistance = f;
                            pathpoint3.distanceToNext = pathpoint3.distanceTo(pathpoint5);
                            if (pathpoint3.isAssigned()) {
                                this.pathFindQueue.changeDistance(pathpoint3, pathpoint3.totalPathDistance + pathpoint3.distanceToNext);
                            } else {
                                pathpoint3.distanceToTarget = pathpoint3.totalPathDistance + pathpoint3.distanceToNext;
                                this.pathFindQueue.addPoint(pathpoint3);
                            }
                        }
                    }
                }
            }
        }

        if (pathpoint1 == pathpoint4) {
            return null;
        }

        LOGGER.debug("Failed to find path from {} to {}", startIdx, finishIdx);
        if (andThen != null) {
            andThen.previous = pathpoint1;
            pathpoint1 = andThen;
        }

        return this.makePath(pathpoint4, pathpoint1);
    }

    private PathEntity makePath(PathPoint start, PathPoint finish) {
        int i = 1;

        for (PathPoint pathpoint = finish; pathpoint.previous != null; pathpoint = pathpoint.previous) {
            i++;
        }

        PathPoint[] apathpoint = new PathPoint[i];
        PathPoint pathpoint1 = finish;

        for (apathpoint[--i] = pathpoint1; pathpoint1.previous != null; apathpoint[--i] = pathpoint1) {
            pathpoint1 = pathpoint1.previous;
        }

        return new PathEntity(apathpoint);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        compound.setInteger("DragonPhase", this.phaseManager.getCurrentPhase().getPhaseList().getId());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        if (compound.hasKey("DragonPhase")) {
            this.phaseManager.setPhase(PhaseList.getById(compound.getInteger("DragonPhase")));
        }
    }

    @Override
    protected void despawnEntity() {
    }

    @Override
    public Entity[] getParts() {
        return this.dragonPartArray;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public World getWorld() {
        return this.worldObj;
    }

    @Override
    public SoundCategory getSoundCategory() {
        return SoundCategory.HOSTILE;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_ENDERDRAGON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound() {
        return SoundEvents.ENTITY_ENDERDRAGON_HURT;
    }

    @Override
    protected float getSoundVolume() {
        return 5.0F;
    }

    public float getHeadPartYOffset(int p_184667_1_, double[] p_184667_2_, double[] p_184667_3_) {
        IPhase iphase = this.phaseManager.getCurrentPhase();
        PhaseList<? extends IPhase> phaselist = iphase.getPhaseList();
        double d0;
        if (phaselist == PhaseList.LANDING || phaselist == PhaseList.TAKEOFF) {
            BlockPos blockpos = this.worldObj.getTopSolidOrLiquidBlock(WorldGenEndPodium.END_PODIUM_LOCATION);
            float f = Math.max(MathHelper.sqrt_double(this.getDistanceSqToCenter(blockpos)) / 4.0F, 1.0F);
            d0 = p_184667_1_ / f;
        } else if (iphase.getIsStationary()) {
            d0 = p_184667_1_;
        } else if (p_184667_1_ == 6) {
            d0 = 0.0;
        } else {
            d0 = p_184667_3_[1] - p_184667_2_[1];
        }

        return (float)d0;
    }

    public Vec3d getHeadLookVec(float p_184665_1_) {
        IPhase iphase = this.phaseManager.getCurrentPhase();
        PhaseList<? extends IPhase> phaselist = iphase.getPhaseList();
        Vec3d vec3d;
        if (phaselist == PhaseList.LANDING || phaselist == PhaseList.TAKEOFF) {
            BlockPos blockpos = this.worldObj.getTopSolidOrLiquidBlock(WorldGenEndPodium.END_PODIUM_LOCATION);
            float f5 = Math.max(MathHelper.sqrt_double(this.getDistanceSqToCenter(blockpos)) / 4.0F, 1.0F);
            float f2 = 6.0F / f5;
            float f3 = this.rotationPitch;
            float f4 = 1.5F;
            this.rotationPitch = -f2 * f4 * 5.0F;
            vec3d = this.getLook(p_184665_1_);
            this.rotationPitch = f3;
        } else if (iphase.getIsStationary()) {
            float f = this.rotationPitch;
            float f1 = 1.5F;
            this.rotationPitch = -6.0F * f1 * 5.0F;
            vec3d = this.getLook(p_184665_1_);
            this.rotationPitch = f;
        } else {
            vec3d = this.getLook(p_184665_1_);
        }

        return vec3d;
    }

    public void onCrystalDestroyed(EntityEnderCrystal crystal, BlockPos pos, DamageSource dmgSrc) {
        EntityPlayer entityplayer;
        if (dmgSrc.getEntity() instanceof EntityPlayer) {
            entityplayer = (EntityPlayer)dmgSrc.getEntity();
        } else {
            entityplayer = this.worldObj.getNearestAttackablePlayer(pos, 64.0, 64.0);
        }

        if (crystal == this.healingEnderCrystal) {
            this.attackEntityFromPart(this.dragonPartHead, DamageSource.causeExplosionDamage(entityplayer), 10.0F);
        }

        this.phaseManager.getCurrentPhase().onCrystalDestroyed(crystal, pos, dmgSrc, entityplayer);
    }

    @Override
    public void notifyDataManagerChange(DataParameter<?> key) {
        if (PHASE.equals(key) && this.worldObj.isRemote) {
            this.phaseManager.setPhase(PhaseList.getById(this.getDataManager().get(PHASE)));
        }

        super.notifyDataManagerChange(key);
    }

    public PhaseManager getPhaseManager() {
        return this.phaseManager;
    }

    public DragonFightManager getFightManager() {
        return this.fightManager;
    }

    @Override
    public void addPotionEffect(PotionEffect potioneffectIn) {
    }

    @Override
    protected boolean canBeRidden(Entity entityIn) {
        return false;
    }

    @Override
    public boolean isNonBoss() {
        return false;
    }
}
