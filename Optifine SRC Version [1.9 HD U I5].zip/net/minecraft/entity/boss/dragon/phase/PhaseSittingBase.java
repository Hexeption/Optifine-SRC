package net.minecraft.entity.boss.dragon.phase;

import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.DamageSource;

public abstract class PhaseSittingBase extends PhaseBase {
    public PhaseSittingBase(EntityDragon p_i46794_1_) {
        super(p_i46794_1_);
    }

    @Override
    public boolean getIsStationary() {
        return true;
    }

    @Override
    public float getAdjustedDamage(EntityDragonPart pt, DamageSource src, float damage) {
        if (src.getSourceOfDamage() instanceof EntityArrow) {
            src.getSourceOfDamage().setFire(1);
            return 0.0F;
        } else {
            return super.getAdjustedDamage(pt, src, damage);
        }
    }
}
