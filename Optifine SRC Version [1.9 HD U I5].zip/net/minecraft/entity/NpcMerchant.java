package net.minecraft.entity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryMerchant;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;

public class NpcMerchant implements IMerchant {
    private InventoryMerchant theMerchantInventory;
    private EntityPlayer customer;
    private MerchantRecipeList recipeList;
    private ITextComponent name;

    public NpcMerchant(EntityPlayer customerIn, ITextComponent nameIn) {
        this.customer = customerIn;
        this.name = nameIn;
        this.theMerchantInventory = new InventoryMerchant(customerIn, this);
    }

    @Override
    public EntityPlayer getCustomer() {
        return this.customer;
    }

    @Override
    public void setCustomer(EntityPlayer player) {
    }

    @Override
    public MerchantRecipeList getRecipes(EntityPlayer player) {
        return this.recipeList;
    }

    @Override
    public void setRecipes(MerchantRecipeList recipeList) {
        this.recipeList = recipeList;
    }

    @Override
    public void useRecipe(MerchantRecipe recipe) {
        recipe.incrementToolUses();
    }

    @Override
    public void verifySellingItem(ItemStack stack) {
    }

    @Override
    public ITextComponent getDisplayName() {
        return this.name != null ? this.name : new TextComponentTranslation("entity.Villager.name");
    }
}
