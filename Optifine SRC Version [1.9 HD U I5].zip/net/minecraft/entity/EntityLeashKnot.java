package net.minecraft.entity;

import net.minecraft.block.BlockFence;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class EntityLeashKnot extends EntityHanging {
    public EntityLeashKnot(World worldIn) {
        super(worldIn);
    }

    public EntityLeashKnot(World worldIn, BlockPos hangingPositionIn) {
        super(worldIn, hangingPositionIn);
        this.setPosition(hangingPositionIn.getX() + 0.5, hangingPositionIn.getY() + 0.5, hangingPositionIn.getZ() + 0.5);
        float f = 2.0F / 16.0F;
        float f1 = 3.0F / 16.0F;
        float f2 = 0.25F;
        this.setEntityBoundingBox(
            new AxisAlignedBB(
                this.posX - 0.1875, this.posY - 0.25 + 0.125, this.posZ - 0.1875, this.posX + 0.1875, this.posY + 0.25 + 0.125, this.posZ + 0.1875
            )
        );
    }

    @Override
    public void setPosition(double x, double y, double z) {
        super.setPosition(MathHelper.floor_double(x) + 0.5, MathHelper.floor_double(y) + 0.5, MathHelper.floor_double(z) + 0.5);
    }

    @Override
    protected void updateBoundingBox() {
        this.posX = this.hangingPosition.getX() + 0.5;
        this.posY = this.hangingPosition.getY() + 0.5;
        this.posZ = this.hangingPosition.getZ() + 0.5;
    }

    @Override
    public void updateFacingWithBoundingBox(EnumFacing facingDirectionIn) {
    }

    @Override
    public int getWidthPixels() {
        return 9;
    }

    @Override
    public int getHeightPixels() {
        return 9;
    }

    @Override
    public float getEyeHeight() {
        return -(1.0F / 16.0F);
    }

    @Override
    public boolean isInRangeToRenderDist(double distance) {
        return distance < 1024.0;
    }

    @Override
    public void onBroken(Entity brokenEntity) {
        this.playSound(SoundEvents.ENTITY_LEASHKNOT_BREAK, 1.0F, 1.0F);
    }

    @Override
    public boolean writeToNBTOptional(NBTTagCompound compound) {
        return false;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
    }

    @Override
    public boolean processInitialInteract(EntityPlayer player, ItemStack stack, EnumHand hand) {
        if (this.worldObj.isRemote) {
            return true;
        }

        boolean flag = false;
        if (stack != null && stack.getItem() == Items.LEAD) {
            double d0 = 7.0;

            for (EntityLiving entityliving : this.worldObj
                .getEntitiesWithinAABB(
                    EntityLiving.class, new AxisAlignedBB(this.posX - d0, this.posY - d0, this.posZ - d0, this.posX + d0, this.posY + d0, this.posZ + d0)
                )) {
                if (entityliving.getLeashed() && entityliving.getLeashedToEntity() == player) {
                    entityliving.setLeashedToEntity(this, true);
                    flag = true;
                }
            }
        }

        if (!flag) {
            this.setDead();
            if (player.capabilities.isCreativeMode) {
                double d1 = 7.0;

                for (EntityLiving entityliving1 : this.worldObj
                    .getEntitiesWithinAABB(
                        EntityLiving.class, new AxisAlignedBB(this.posX - d1, this.posY - d1, this.posZ - d1, this.posX + d1, this.posY + d1, this.posZ + d1)
                    )) {
                    if (entityliving1.getLeashed() && entityliving1.getLeashedToEntity() == this) {
                        entityliving1.clearLeashed(true, false);
                    }
                }
            }
        }

        return true;
    }

    @Override
    public boolean onValidSurface() {
        return this.worldObj.getBlockState(this.hangingPosition).getBlock() instanceof BlockFence;
    }

    public static EntityLeashKnot createKnot(World worldIn, BlockPos fence) {
        EntityLeashKnot entityleashknot = new EntityLeashKnot(worldIn, fence);
        entityleashknot.forceSpawn = true;
        worldIn.spawnEntityInWorld(entityleashknot);
        entityleashknot.playPlaceSound();
        return entityleashknot;
    }

    public static EntityLeashKnot getKnotForPosition(World worldIn, BlockPos pos) {
        int i = pos.getX();
        int j = pos.getY();
        int k = pos.getZ();

        for (EntityLeashKnot entityleashknot : worldIn.getEntitiesWithinAABB(
            EntityLeashKnot.class, new AxisAlignedBB(i - 1.0, j - 1.0, k - 1.0, i + 1.0, j + 1.0, k + 1.0)
        )) {
            if (entityleashknot.getHangingPosition().equals(pos)) {
                return entityleashknot;
            }
        }

        return null;
    }

    @Override
    public void playPlaceSound() {
        this.playSound(SoundEvents.ENTITY_LEASHKNOT_PLACE, 1.0F, 1.0F);
    }
}
