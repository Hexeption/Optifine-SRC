package net.minecraft.entity.passive;

import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public enum HorseType {
    NONE(0),
    IRON(5, "iron", "meo"),
    GOLD(7, "gold", "goo"),
    DIAMOND(11, "diamond", "dio");

    private final String textureName;
    private final String hash;
    private final int protection;

    HorseType(int armorStrengthIn) {
        this.protection = armorStrengthIn;
        this.textureName = null;
        this.hash = "";
    }

    HorseType(int armorStrengthIn, String p_i46800_4_, String p_i46800_5_) {
        this.protection = armorStrengthIn;
        this.textureName = "textures/entity/horse/armor/horse_armor_" + p_i46800_4_ + ".png";
        this.hash = p_i46800_5_;
    }

    public int getOrdinal() {
        return this.ordinal();
    }

    public String getHash() {
        return this.hash;
    }

    public int getProtection() {
        return this.protection;
    }

    public String getTextureName() {
        return this.textureName;
    }

    public static HorseType getByOrdinal(int ordinal) {
        return values()[ordinal];
    }

    public static HorseType getByItemStack(ItemStack stack) {
        return stack == null ? NONE : getByItem(stack.getItem());
    }

    public static HorseType getByItem(Item itemIn) {
        if (itemIn == Items.IRON_HORSE_ARMOR) {
            return IRON;
        } else if (itemIn == Items.GOLDEN_HORSE_ARMOR) {
            return GOLD;
        } else {
            return itemIn == Items.DIAMOND_HORSE_ARMOR ? DIAMOND : NONE;
        }
    }

    public static boolean isHorseArmor(Item itemIn) {
        return getByItem(itemIn) != NONE;
    }
}
