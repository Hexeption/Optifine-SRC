package net.minecraft.enchantment;

import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public enum EnumEnchantmentType {
    ALL,
    ARMOR,
    ARMOR_FEET,
    ARMOR_LEGS,
    ARMOR_CHEST,
    ARMOR_HEAD,
    WEAPON,
    DIGGER,
    FISHING_ROD,
    BREAKABLE,
    BOW;

    public boolean canEnchantItem(Item itemIn) {
        if (this == ALL) {
            return true;
        }

        if (this == BREAKABLE && itemIn.isDamageable()) {
            return true;
        }

        if (itemIn instanceof ItemArmor) {
            if (this == ARMOR) {
                return true;
            } else {
                ItemArmor itemarmor = (ItemArmor)itemIn;
                if (itemarmor.armorType == EntityEquipmentSlot.HEAD) {
                    return this == ARMOR_HEAD;
                } else if (itemarmor.armorType == EntityEquipmentSlot.LEGS) {
                    return this == ARMOR_LEGS;
                } else if (itemarmor.armorType == EntityEquipmentSlot.CHEST) {
                    return this == ARMOR_CHEST;
                } else {
                    return itemarmor.armorType == EntityEquipmentSlot.FEET ? this == ARMOR_FEET : false;
                }
            }
        } else if (itemIn instanceof ItemSword) {
            return this == WEAPON;
        } else if (itemIn instanceof ItemTool) {
            return this == DIGGER;
        } else if (itemIn instanceof ItemBow) {
            return this == BOW;
        } else {
            return itemIn instanceof ItemFishingRod ? this == FISHING_ROD : false;
        }
    }
}
