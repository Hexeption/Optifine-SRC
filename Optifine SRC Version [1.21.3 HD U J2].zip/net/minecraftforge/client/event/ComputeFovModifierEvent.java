package net.minecraftforge.client.event;

import net.minecraftforge.eventbus.api.Event;

public class ComputeFovModifierEvent extends Event {
    public float getFovModifier() {
        return 0.0F;
    }

    public float getScale() {
        return 0.0F;
    }

    public float getNewFovModifier() {
        return 0.0F;
    }
}
