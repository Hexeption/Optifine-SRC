package net.minecraftforge.client.extensions;

import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.resources.ResourceLocation;

public interface IForgeModelBaker {
    BakedModel bake(ResourceLocation var1, ModelState var2);
}
