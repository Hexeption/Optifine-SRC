package net.minecraft.entity.passive;

import javax.annotation.Nullable;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.ai.EntityAIFollowGroupLeader;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class EntityTropicalFish extends AbstractFish {
   private static final DataParameter<Integer> VARIANT = EntityDataManager.<Integer>createKey(EntityTropicalFish.class, DataSerializers.VARINT);
   private static final ResourceLocation[] BODY_TEXTURES = new ResourceLocation[]{new ResourceLocation("textures/entity/fish/tropical_a.png"), new ResourceLocation("textures/entity/fish/tropical_b.png")};
   private static final ResourceLocation[] PATTERN_TEXTURES_A = new ResourceLocation[]{new ResourceLocation("textures/entity/fish/tropical_a_pattern_1.png"), new ResourceLocation("textures/entity/fish/tropical_a_pattern_2.png"), new ResourceLocation("textures/entity/fish/tropical_a_pattern_3.png"), new ResourceLocation("textures/entity/fish/tropical_a_pattern_4.png"), new ResourceLocation("textures/entity/fish/tropical_a_pattern_5.png"), new ResourceLocation("textures/entity/fish/tropical_a_pattern_6.png")};
   private static final ResourceLocation[] PATTERN_TEXTURES_B = new ResourceLocation[]{new ResourceLocation("textures/entity/fish/tropical_b_pattern_1.png"), new ResourceLocation("textures/entity/fish/tropical_b_pattern_2.png"), new ResourceLocation("textures/entity/fish/tropical_b_pattern_3.png"), new ResourceLocation("textures/entity/fish/tropical_b_pattern_4.png"), new ResourceLocation("textures/entity/fish/tropical_b_pattern_5.png"), new ResourceLocation("textures/entity/fish/tropical_b_pattern_6.png")};
   private static final int[] SPECIAL_VARIANTS = new int[]{pack(1, 1, 1, 7), pack(1, 0, 7, 7), pack(0, 1, 7, 3), pack(0, 4, 0, 7), pack(0, 1, 11, 7), pack(0, 0, 1, 0), pack(0, 5, 6, 3), pack(1, 3, 10, 4), pack(1, 5, 0, 14), pack(0, 5, 0, 4), pack(1, 2, 0, 7), pack(1, 5, 0, 1), pack(0, 3, 9, 6), pack(0, 4, 5, 3), pack(1, 4, 14, 0), pack(0, 2, 7, 14), pack(1, 3, 14, 0), pack(1, 0, 0, 4), pack(0, 1, 0, 0), pack(0, 0, 14, 0), pack(1, 1, 4, 4), pack(0, 3, 0, 7)};
   private boolean field_204228_bA = true;

   private static int pack(int size, int pattern, int bodyColor, int patternColor) {
      return size & 255 | (pattern & 255) << 8 | (bodyColor & 255) << 16 | (patternColor & 255) << 24;
   }

   public EntityTropicalFish(World p_i48879_1_) {
      super(EntityType.TROPICAL_FISH, p_i48879_1_);
      this.setSize(0.5F, 0.4F);
   }

   protected void registerData() {
      super.registerData();
      this.dataManager.register(VARIANT, 0);
   }

   public void writeAdditional(NBTTagCompound compound) {
      super.writeAdditional(compound);
      compound.putInt("Variant", this.getVariant());
   }

   public void readAdditional(NBTTagCompound compound) {
      super.readAdditional(compound);
      this.setVariant(compound.getInt("Variant"));
   }

   public void setVariant(int p_204215_1_) {
      this.dataManager.set(VARIANT, p_204215_1_);
   }

   public boolean func_204209_c(int p_204209_1_) {
      return !this.field_204228_bA;
   }

   public int getVariant() {
      return this.dataManager.get(VARIANT);
   }

   protected void initEntityAI() {
      super.initEntityAI();
      this.tasks.addTask(5, new EntityAIFollowGroupLeader(this));
   }

   protected void setBucketData(ItemStack bucket) {
      super.setBucketData(bucket);
      NBTTagCompound nbttagcompound = bucket.getOrCreateTag();
      nbttagcompound.putInt("BucketVariantTag", this.getVariant());
   }

   protected ItemStack getFishBucket() {
      return new ItemStack(Items.TROPICAL_FISH_BUCKET);
   }

   @Nullable
   protected ResourceLocation getLootTable() {
      return LootTableList.ENTITIES_TROPICAL_FISH;
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.ENTITY_TROPICAL_FISH_AMBIENT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.ENTITY_TROPICAL_FISH_DEATH;
   }

   protected SoundEvent getHurtSound(DamageSource damageSourceIn) {
      return SoundEvents.ENTITY_TROPICAL_FISH_HURT;
   }

   protected SoundEvent getFlopSound() {
      return SoundEvents.ENTITY_TROPICAL_FISH_FLOP;
   }

   @OnlyIn(Dist.CLIENT)
   private int getBodyColor() {
      return (this.getVariant() & 16711680) >> 16;
   }

   @OnlyIn(Dist.CLIENT)
   public float[] func_204219_dC() {
      return EnumDyeColor.byId(this.getBodyColor()).getColorComponentValues();
   }

   @OnlyIn(Dist.CLIENT)
   private int getPatternColor() {
      return (this.getVariant() & -16777216) >> 24;
   }

   @OnlyIn(Dist.CLIENT)
   public float[] func_204222_dD() {
      return EnumDyeColor.byId(this.getPatternColor()).getColorComponentValues();
   }

   @OnlyIn(Dist.CLIENT)
   public int getSize() {
      return Math.min(this.getVariant() & 255, 1);
   }

   @OnlyIn(Dist.CLIENT)
   private int getPattern() {
      return Math.min((this.getVariant() & '\uff00') >> 8, 5);
   }

   @OnlyIn(Dist.CLIENT)
   public ResourceLocation getPatternTexture() {
      return this.getSize() == 0 ? PATTERN_TEXTURES_A[this.getPattern()] : PATTERN_TEXTURES_B[this.getPattern()];
   }

   @OnlyIn(Dist.CLIENT)
   public ResourceLocation getBodyTexture() {
      return BODY_TEXTURES[this.getSize()];
   }

   @Nullable
   public IEntityLivingData onInitialSpawn(DifficultyInstance difficulty, @Nullable IEntityLivingData entityLivingData, @Nullable NBTTagCompound itemNbt) {
      entityLivingData = super.onInitialSpawn(difficulty, entityLivingData, itemNbt);
      if (itemNbt != null && itemNbt.contains("BucketVariantTag", 3)) {
         this.setVariant(itemNbt.getInt("BucketVariantTag"));
         return entityLivingData;
      } else {
         int i;
         int j;
         int k;
         int l;
         if (entityLivingData instanceof EntityTropicalFish.GroupData) {
            EntityTropicalFish.GroupData entitytropicalfish$groupdata = (EntityTropicalFish.GroupData)entityLivingData;
            i = entitytropicalfish$groupdata.size;
            j = entitytropicalfish$groupdata.pattern;
            k = entitytropicalfish$groupdata.bodyColor;
            l = entitytropicalfish$groupdata.patternColor;
         } else if ((double)this.rand.nextFloat() < 0.9D) {
            int i1 = SPECIAL_VARIANTS[this.rand.nextInt(SPECIAL_VARIANTS.length)];
            i = i1 & 255;
            j = (i1 & '\uff00') >> 8;
            k = (i1 & 16711680) >> 16;
            l = (i1 & -16777216) >> 24;
            entityLivingData = new EntityTropicalFish.GroupData(i, j, k, l);
         } else {
            this.field_204228_bA = false;
            i = this.rand.nextInt(2);
            j = this.rand.nextInt(6);
            k = this.rand.nextInt(15);
            l = this.rand.nextInt(15);
         }

         this.setVariant(i | j << 8 | k << 16 | l << 24);
         return entityLivingData;
      }
   }

   static class GroupData implements IEntityLivingData {
      private final int size;
      private final int pattern;
      private final int bodyColor;
      private final int patternColor;

      private GroupData(int p_i48880_1_, int p_i48880_2_, int p_i48880_3_, int p_i48880_4_) {
         this.size = p_i48880_1_;
         this.pattern = p_i48880_2_;
         this.bodyColor = p_i48880_3_;
         this.patternColor = p_i48880_4_;
      }
   }
}
