package net.minecraft.entity;

import net.optifine.Config;

import com.google.common.collect.Maps;
import java.util.Arrays;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.BlockAbstractSkull;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.ai.EntityJumpHelper;
import net.minecraft.entity.ai.EntityLookHelper;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.ai.EntitySenses;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.fluid.Fluid;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.Particles;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.server.SPacketEntityAttach;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.pathfinding.PathNodeType;
import net.minecraft.scoreboard.Team;
import net.minecraft.tags.Tag;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTable;
import net.optifine.reflect.Reflector;

public abstract class EntityLiving extends EntityLivingBase {
    private static final DataParameter<Byte> AI_FLAGS = EntityDataManager.createKey(EntityLiving.class, DataSerializers.BYTE);
    public int livingSoundTime;
    protected int experienceValue;
    protected EntityLookHelper lookHelper;
    protected EntityMoveHelper moveHelper;
    protected EntityJumpHelper jumpHelper;
    private final EntityBodyHelper bodyHelper;
    protected PathNavigate navigator;
    protected final EntityAITasks tasks;
    protected final EntityAITasks targetTasks;
    private EntityLivingBase attackTarget;
    private final EntitySenses senses;
    private final NonNullList<ItemStack> inventoryHands = NonNullList.withSize(2, ItemStack.EMPTY);
    protected float[] inventoryHandsDropChances = new float[2];
    private final NonNullList<ItemStack> inventoryArmor = NonNullList.withSize(4, ItemStack.EMPTY);
    protected float[] inventoryArmorDropChances = new float[4];
    private boolean canPickUpLoot;
    private boolean persistenceRequired;
    private final Map<PathNodeType, Float> mapPathPriority = Maps.newEnumMap(PathNodeType.class);
    private ResourceLocation deathLootTable;
    private long deathLootTableSeed;
    private boolean isLeashed;
    private Entity leashHolder;
    private NBTTagCompound leashNBTTag;
    private UUID teamUuid = null;
    private String teamUuidString = null;

    protected EntityLiving(EntityType<?> p_i48576_1_, World p_i48576_2_) {
        super(p_i48576_1_, p_i48576_2_);
        this.tasks = new EntityAITasks(p_i48576_2_ != null && p_i48576_2_.profiler != null ? p_i48576_2_.profiler : null);
        this.targetTasks = new EntityAITasks(p_i48576_2_ != null && p_i48576_2_.profiler != null ? p_i48576_2_.profiler : null);
        this.lookHelper = new EntityLookHelper(this);
        this.moveHelper = new EntityMoveHelper(this);
        this.jumpHelper = new EntityJumpHelper(this);
        this.bodyHelper = this.createBodyHelper();
        this.navigator = this.createNavigator(p_i48576_2_);
        this.senses = new EntitySenses(this);
        Arrays.fill(this.inventoryArmorDropChances, 0.085F);
        Arrays.fill(this.inventoryHandsDropChances, 0.085F);
        if (p_i48576_2_ != null && !p_i48576_2_.isRemote) {
            this.initEntityAI();
        }
    }

    protected void initEntityAI() {
    }

    @Override
    protected void registerAttributes() {
        super.registerAttributes();
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(16.0);
    }

    protected PathNavigate createNavigator(World worldIn) {
        return new PathNavigateGround(this, worldIn);
    }

    public float getPathPriority(PathNodeType nodeType) {
        Float f = this.mapPathPriority.get(nodeType);
        return f == null ? nodeType.getPriority() : f;
    }

    public void setPathPriority(PathNodeType nodeType, float priority) {
        this.mapPathPriority.put(nodeType, priority);
    }

    protected EntityBodyHelper createBodyHelper() {
        return new EntityBodyHelper(this);
    }

    public EntityLookHelper getLookHelper() {
        return this.lookHelper;
    }

    public EntityMoveHelper getMoveHelper() {
        return this.moveHelper;
    }

    public EntityJumpHelper getJumpHelper() {
        return this.jumpHelper;
    }

    public PathNavigate getNavigator() {
        return this.navigator;
    }

    public EntitySenses getEntitySenses() {
        return this.senses;
    }

    @Nullable
    public EntityLivingBase getAttackTarget() {
        return this.attackTarget;
    }

    public void setAttackTarget(@Nullable EntityLivingBase entitylivingbaseIn) {
        this.attackTarget = entitylivingbaseIn;
        Reflector.callVoid(Reflector.ForgeHooks_onLivingSetAttackTarget, this, entitylivingbaseIn);
    }

    public boolean canAttackClass(Class<? extends EntityLivingBase> cls) {
        return cls != EntityGhast.class;
    }

    public void eatGrassBonus() {
    }

    @Override
    protected void registerData() {
        super.registerData();
        this.dataManager.register(AI_FLAGS, (byte)0);
    }

    public int getTalkInterval() {
        return 80;
    }

    public void playAmbientSound() {
        SoundEvent soundevent = this.getAmbientSound();
        if (soundevent != null) {
            this.playSound(soundevent, this.getSoundVolume(), this.getSoundPitch());
        }
    }

    @Override
    public void baseTick() {
        super.baseTick();
        this.world.profiler.startSection("mobBaseTick");
        if (this.isAlive() && this.rand.nextInt(1000) < this.livingSoundTime++) {
            this.applyEntityAI();
            this.playAmbientSound();
        }

        this.world.profiler.endSection();
    }

    @Override
    protected void playHurtSound(DamageSource source) {
        this.applyEntityAI();
        super.playHurtSound(source);
    }

    private void applyEntityAI() {
        this.livingSoundTime = -this.getTalkInterval();
    }

    @Override
    protected int getExperiencePoints(EntityPlayer player) {
        if (this.experienceValue > 0) {
            int i = this.experienceValue;

            for (int j = 0; j < this.inventoryArmor.size(); j++) {
                if (!this.inventoryArmor.get(j).isEmpty() && this.inventoryArmorDropChances[j] <= 1.0F) {
                    i += 1 + this.rand.nextInt(3);
                }
            }

            for (int k = 0; k < this.inventoryHands.size(); k++) {
                if (!this.inventoryHands.get(k).isEmpty() && this.inventoryHandsDropChances[k] <= 1.0F) {
                    i += 1 + this.rand.nextInt(3);
                }
            }

            return i;
        } else {
            return this.experienceValue;
        }
    }

    public void spawnExplosionParticle() {
        if (this.world.isRemote) {
            for (int i = 0; i < 20; i++) {
                double d0 = this.rand.nextGaussian() * 0.02;
                double d1 = this.rand.nextGaussian() * 0.02;
                double d2 = this.rand.nextGaussian() * 0.02;
                double d3 = 10.0;
                this.world
                    .spawnParticle(
                        Particles.POOF,
                        this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width - d0 * 10.0,
                        this.posY + this.rand.nextFloat() * this.height - d1 * 10.0,
                        this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width - d2 * 10.0,
                        d0,
                        d1,
                        d2
                    );
            }
        } else {
            this.world.setEntityState(this, (byte)20);
        }
    }

    @Override
    public void handleStatusUpdate(byte id) {
        if (id == 20) {
            this.spawnExplosionParticle();
        } else {
            super.handleStatusUpdate(id);
        }
    }

    @Override
    public void tick() {
        if (Config.isSmoothWorld() && this.canSkipUpdate()) {
            this.onUpdateMinimal();
        } else {
            super.tick();
            if (!this.world.isRemote) {
                this.updateLeashedState();
                if (this.ticksExisted % 5 == 0) {
                    boolean flag = !(this.getControllingPassenger() instanceof EntityLiving);
                    boolean flag1 = !(this.getRidingEntity() instanceof EntityBoat);
                    this.tasks.setControlFlag(1, flag);
                    this.tasks.setControlFlag(4, flag && flag1);
                    this.tasks.setControlFlag(2, flag);
                }
            }
        }
    }

    @Override
    protected float updateDistance(float p_110146_1_, float p_110146_2_) {
        this.bodyHelper.updateRenderAngles();
        return p_110146_2_;
    }

    @Nullable
    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Nullable
    protected Item getDropItem() {
        return null;
    }

    @Override
    protected void dropFewItems(boolean wasRecentlyHit, int lootingModifier) {
        Item item = this.getDropItem();
        if (item != null) {
            int i = this.rand.nextInt(3);
            if (lootingModifier > 0) {
                i += this.rand.nextInt(lootingModifier + 1);
            }

            for (int j = 0; j < i; j++) {
                this.entityDropItem(item);
            }
        }
    }

    @Override
    public void writeAdditional(NBTTagCompound compound) {
        super.writeAdditional(compound);
        compound.putBoolean("CanPickUpLoot", this.canPickUpLoot());
        compound.putBoolean("PersistenceRequired", this.persistenceRequired);
        NBTTagList nbttaglist = new NBTTagList();

        for (ItemStack itemstack : this.inventoryArmor) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            if (!itemstack.isEmpty()) {
                itemstack.write(nbttagcompound);
            }

            nbttaglist.add(nbttagcompound);
        }

        compound.put("ArmorItems", nbttaglist);
        NBTTagList nbttaglist1 = new NBTTagList();

        for (ItemStack itemstack1 : this.inventoryHands) {
            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            if (!itemstack1.isEmpty()) {
                itemstack1.write(nbttagcompound1);
            }

            nbttaglist1.add(nbttagcompound1);
        }

        compound.put("HandItems", nbttaglist1);
        NBTTagList nbttaglist2 = new NBTTagList();

        for (float f : this.inventoryArmorDropChances) {
            nbttaglist2.add(new NBTTagFloat(f));
        }

        compound.put("ArmorDropChances", nbttaglist2);
        NBTTagList nbttaglist3 = new NBTTagList();

        for (float f1 : this.inventoryHandsDropChances) {
            nbttaglist3.add(new NBTTagFloat(f1));
        }

        compound.put("HandDropChances", nbttaglist3);
        compound.putBoolean("Leashed", this.isLeashed);
        if (this.leashHolder != null) {
            NBTTagCompound nbttagcompound2 = new NBTTagCompound();
            if (this.leashHolder instanceof EntityLivingBase) {
                UUID uuid = this.leashHolder.getUniqueID();
                nbttagcompound2.putUniqueId("UUID", uuid);
            } else if (this.leashHolder instanceof EntityHanging) {
                BlockPos blockpos = ((EntityHanging)this.leashHolder).getHangingPosition();
                nbttagcompound2.putInt("X", blockpos.getX());
                nbttagcompound2.putInt("Y", blockpos.getY());
                nbttagcompound2.putInt("Z", blockpos.getZ());
            }

            compound.put("Leash", nbttagcompound2);
        }

        compound.putBoolean("LeftHanded", this.isLeftHanded());
        if (this.deathLootTable != null) {
            compound.putString("DeathLootTable", this.deathLootTable.toString());
            if (this.deathLootTableSeed != 0L) {
                compound.putLong("DeathLootTableSeed", this.deathLootTableSeed);
            }
        }

        if (this.isAIDisabled()) {
            compound.putBoolean("NoAI", this.isAIDisabled());
        }
    }

    @Override
    public void readAdditional(NBTTagCompound compound) {
        super.readAdditional(compound);
        if (compound.contains("CanPickUpLoot", 1)) {
            this.setCanPickUpLoot(compound.getBoolean("CanPickUpLoot"));
        }

        this.persistenceRequired = compound.getBoolean("PersistenceRequired");
        if (compound.contains("ArmorItems", 9)) {
            NBTTagList nbttaglist = compound.getList("ArmorItems", 10);

            for (int i = 0; i < this.inventoryArmor.size(); i++) {
                this.inventoryArmor.set(i, ItemStack.read(nbttaglist.getCompound(i)));
            }
        }

        if (compound.contains("HandItems", 9)) {
            NBTTagList nbttaglist1 = compound.getList("HandItems", 10);

            for (int j = 0; j < this.inventoryHands.size(); j++) {
                this.inventoryHands.set(j, ItemStack.read(nbttaglist1.getCompound(j)));
            }
        }

        if (compound.contains("ArmorDropChances", 9)) {
            NBTTagList nbttaglist2 = compound.getList("ArmorDropChances", 5);

            for (int k = 0; k < nbttaglist2.size(); k++) {
                this.inventoryArmorDropChances[k] = nbttaglist2.getFloat(k);
            }
        }

        if (compound.contains("HandDropChances", 9)) {
            NBTTagList nbttaglist3 = compound.getList("HandDropChances", 5);

            for (int l = 0; l < nbttaglist3.size(); l++) {
                this.inventoryHandsDropChances[l] = nbttaglist3.getFloat(l);
            }
        }

        this.isLeashed = compound.getBoolean("Leashed");
        if (this.isLeashed && compound.contains("Leash", 10)) {
            this.leashNBTTag = compound.getCompound("Leash");
        }

        this.setLeftHanded(compound.getBoolean("LeftHanded"));
        if (compound.contains("DeathLootTable", 8)) {
            this.deathLootTable = new ResourceLocation(compound.getString("DeathLootTable"));
            this.deathLootTableSeed = compound.getLong("DeathLootTableSeed");
        }

        this.setNoAI(compound.getBoolean("NoAI"));
    }

    @Nullable
    protected ResourceLocation getLootTable() {
        return null;
    }

    @Override
    protected void dropLoot(boolean wasRecentlyHit, int lootingModifier, DamageSource source) {
        ResourceLocation resourcelocation = this.deathLootTable;
        if (resourcelocation == null) {
            resourcelocation = this.getLootTable();
        }

        if (resourcelocation != null) {
            LootTable loottable = this.world.getServer().getLootTableManager().getLootTableFromLocation(resourcelocation);
            this.deathLootTable = null;
            LootContext.Builder lootcontext$builder = new LootContext.Builder((WorldServer)this.world)
                .withLootedEntity(this)
                .withDamageSource(source)
                .withPosition(new BlockPos(this));
            if (wasRecentlyHit && this.attackingPlayer != null) {
                lootcontext$builder = lootcontext$builder.withPlayer(this.attackingPlayer).withLuck(this.attackingPlayer.getLuck());
            }

            for (ItemStack itemstack : loottable.generateLootForPools(
                this.deathLootTableSeed == 0L ? this.rand : new Random(this.deathLootTableSeed), lootcontext$builder.build()
            )) {
                this.entityDropItem(itemstack);
            }

            this.dropEquipment(wasRecentlyHit, lootingModifier);
        } else {
            super.dropLoot(wasRecentlyHit, lootingModifier, source);
        }
    }

    public void setMoveForward(float amount) {
        this.moveForward = amount;
    }

    public void setMoveVertical(float amount) {
        this.moveVertical = amount;
    }

    public void setMoveStrafing(float amount) {
        this.moveStrafing = amount;
    }

    @Override
    public void setAIMoveSpeed(float speedIn) {
        super.setAIMoveSpeed(speedIn);
        this.setMoveForward(speedIn);
    }

    @Override
    public void livingTick() {
        super.livingTick();
        this.world.profiler.startSection("looting");
        boolean flag = this.world.getGameRules().getBoolean("mobGriefing");
        if (Reflector.ForgeEventFactory_getMobGriefingEvent.exists()) {
            flag = Reflector.callBoolean(Reflector.ForgeEventFactory_getMobGriefingEvent, this.world, this);
        }

        if (!this.world.isRemote && this.canPickUpLoot() && !this.dead && flag) {
            for (EntityItem entityitem : this.world.getEntitiesWithinAABB(EntityItem.class, this.getBoundingBox().grow(1.0, 0.0, 1.0))) {
                if (!entityitem.removed && !entityitem.getItem().isEmpty() && !entityitem.cannotPickup()) {
                    this.updateEquipmentIfNeeded(entityitem);
                }
            }
        }

        this.world.profiler.endSection();
    }

    protected void updateEquipmentIfNeeded(EntityItem itemEntity) {
        ItemStack itemstack = itemEntity.getItem();
        EntityEquipmentSlot entityequipmentslot = getSlotForItemStack(itemstack);
        ItemStack itemstack1 = this.getItemStackFromSlot(entityequipmentslot);
        boolean flag = this.shouldExchangeEquipment(itemstack, itemstack1, entityequipmentslot);
        if (flag && this.canEquipItem(itemstack)) {
            double d0 = this.getDropChance(entityequipmentslot);
            if (!itemstack1.isEmpty() && this.rand.nextFloat() - 0.1F < d0) {
                this.entityDropItem(itemstack1);
            }

            this.setItemStackToSlot(entityequipmentslot, itemstack);
            switch (entityequipmentslot.getSlotType()) {
                case HAND:
                    this.inventoryHandsDropChances[entityequipmentslot.getIndex()] = 2.0F;
                    break;
                case ARMOR:
                    this.inventoryArmorDropChances[entityequipmentslot.getIndex()] = 2.0F;
            }

            this.persistenceRequired = true;
            this.onItemPickup(itemEntity, itemstack.getCount());
            itemEntity.remove();
        }
    }

    protected boolean shouldExchangeEquipment(ItemStack candidate, ItemStack existing, EntityEquipmentSlot p_208003_3_) {
        boolean flag = true;
        if (!existing.isEmpty()) {
            if (p_208003_3_.getSlotType() == EntityEquipmentSlot.Type.HAND) {
                if (candidate.getItem() instanceof ItemSword && !(existing.getItem() instanceof ItemSword)) {
                    flag = true;
                } else if (candidate.getItem() instanceof ItemSword && existing.getItem() instanceof ItemSword) {
                    ItemSword itemsword = (ItemSword)candidate.getItem();
                    ItemSword itemsword1 = (ItemSword)existing.getItem();
                    if (itemsword.getAttackDamage() == itemsword1.getAttackDamage()) {
                        flag = candidate.getDamage() < existing.getDamage() || candidate.hasTag() && !existing.hasTag();
                    } else {
                        flag = itemsword.getAttackDamage() > itemsword1.getAttackDamage();
                    }
                } else if (candidate.getItem() instanceof ItemBow && existing.getItem() instanceof ItemBow) {
                    flag = candidate.hasTag() && !existing.hasTag();
                } else {
                    flag = false;
                }
            } else if (candidate.getItem() instanceof ItemArmor && !(existing.getItem() instanceof ItemArmor)) {
                flag = true;
            } else if (candidate.getItem() instanceof ItemArmor
                && existing.getItem() instanceof ItemArmor
                && !EnchantmentHelper.hasBindingCurse(existing)) {
                ItemArmor itemarmor = (ItemArmor)candidate.getItem();
                ItemArmor itemarmor1 = (ItemArmor)existing.getItem();
                if (itemarmor.getDamageReduceAmount() == itemarmor1.getDamageReduceAmount()) {
                    flag = candidate.getDamage() < existing.getDamage() || candidate.hasTag() && !existing.hasTag();
                } else {
                    flag = itemarmor.getDamageReduceAmount() > itemarmor1.getDamageReduceAmount();
                }
            } else {
                flag = false;
            }
        }

        return flag;
    }

    protected boolean canEquipItem(ItemStack stack) {
        return true;
    }

    protected boolean canDespawn() {
        return true;
    }

    protected void checkDespawn() {
        Object object = null;
        Object object1 = Reflector.getFieldValue(Reflector.Event_Result_DEFAULT);
        Object object2 = Reflector.getFieldValue(Reflector.Event_Result_DENY);
        if (this.persistenceRequired) {
            this.idleTime = 0;
        } else if ((this.idleTime & 31) != 31 || (object = Reflector.call(Reflector.ForgeEventFactory_canEntityDespawn, this)) == object1) {
            Entity entity = this.world.getClosestPlayerToEntity(this, -1.0);
            if (entity != null) {
                double d0 = entity.posX - this.posX;
                double d1 = entity.posY - this.posY;
                double d2 = entity.posZ - this.posZ;
                double d3 = d0 * d0 + d1 * d1 + d2 * d2;
                if (this.canDespawn() && d3 > 16384.0) {
                    this.remove();
                }

                if (this.idleTime > 600 && this.rand.nextInt(800) == 0 && d3 > 1024.0 && this.canDespawn()) {
                    this.remove();
                } else if (d3 < 1024.0) {
                    this.idleTime = 0;
                }
            }
        } else if (object == object2) {
            this.idleTime = 0;
        } else {
            this.remove();
        }
    }

    @Override
    protected final void updateEntityActionState() {
        this.idleTime++;
        this.world.profiler.startSection("checkDespawn");
        this.checkDespawn();
        this.world.profiler.endSection();
        this.world.profiler.startSection("sensing");
        this.senses.tick();
        this.world.profiler.endSection();
        this.world.profiler.startSection("targetSelector");
        this.targetTasks.tick();
        this.world.profiler.endSection();
        this.world.profiler.startSection("goalSelector");
        this.tasks.tick();
        this.world.profiler.endSection();
        this.world.profiler.startSection("navigation");
        this.navigator.tick();
        this.world.profiler.endSection();
        this.world.profiler.startSection("mob tick");
        this.updateAITasks();
        this.world.profiler.endSection();
        if (this.isPassenger() && this.getRidingEntity() instanceof EntityLiving) {
            EntityLiving entityliving = (EntityLiving)this.getRidingEntity();
            entityliving.getNavigator().setPath(this.getNavigator().getPath(), 1.5);
            entityliving.getMoveHelper().read(this.getMoveHelper());
        }

        this.world.profiler.startSection("controls");
        this.world.profiler.startSection("move");
        this.moveHelper.tick();
        this.world.profiler.endStartSection("look");
        this.lookHelper.tick();
        this.world.profiler.endStartSection("jump");
        this.jumpHelper.tick();
        this.world.profiler.endSection();
        this.world.profiler.endSection();
    }

    protected void updateAITasks() {
    }

    public int getVerticalFaceSpeed() {
        return 40;
    }

    public int getHorizontalFaceSpeed() {
        return 10;
    }

    public void faceEntity(Entity entityIn, float maxYawIncrease, float maxPitchIncrease) {
        double d0 = entityIn.posX - this.posX;
        double d1 = entityIn.posZ - this.posZ;
        double d2;
        if (entityIn instanceof EntityLivingBase) {
            EntityLivingBase entitylivingbase = (EntityLivingBase)entityIn;
            d2 = entitylivingbase.posY + entitylivingbase.getEyeHeight() - (this.posY + this.getEyeHeight());
        } else {
            d2 = (entityIn.getBoundingBox().minY + entityIn.getBoundingBox().maxY) / 2.0 - (this.posY + this.getEyeHeight());
        }

        double d3 = MathHelper.sqrt(d0 * d0 + d1 * d1);
        float f = (float)(MathHelper.atan2(d1, d0) * (180.0 / Math.PI)) - 90.0F;
        float f1 = (float)(-(MathHelper.atan2(d2, d3) * (180.0 / Math.PI)));
        this.rotationPitch = this.updateRotation(this.rotationPitch, f1, maxPitchIncrease);
        this.rotationYaw = this.updateRotation(this.rotationYaw, f, maxYawIncrease);
    }

    private float updateRotation(float angle, float targetAngle, float maxIncrease) {
        float f = MathHelper.wrapDegrees(targetAngle - angle);
        if (f > maxIncrease) {
            f = maxIncrease;
        }

        if (f < -maxIncrease) {
            f = -maxIncrease;
        }

        return angle + f;
    }

    public final boolean getCanSpawnHere() {
        return this.canSpawn(this.world);
    }

    public boolean canSpawn(IWorld worldIn) {
        IBlockState iblockstate = worldIn.getBlockState(new BlockPos(this).down());
        return iblockstate.canEntitySpawn(this);
    }

    public final boolean isNotColliding() {
        return this.isNotColliding(this.world);
    }

    public boolean isNotColliding(IWorldReaderBase worldIn) {
        return !worldIn.containsAnyLiquid(this.getBoundingBox())
            && worldIn.isCollisionBoxesEmpty(this, this.getBoundingBox())
            && worldIn.checkNoEntityCollision(this, this.getBoundingBox());
    }

    public float getRenderSizeModifier() {
        return 1.0F;
    }

    public int getMaxSpawnedInChunk() {
        return 4;
    }

    public boolean func_204209_c(int p_204209_1_) {
        return false;
    }

    @Override
    public int getMaxFallHeight() {
        if (this.getAttackTarget() == null) {
            return 3;
        }

        int i = (int)(this.getHealth() - this.getMaxHealth() * 0.33F);
        i -= (3 - this.world.getDifficulty().getId()) * 4;
        if (i < 0) {
            i = 0;
        }

        return i + 3;
    }

    @Override
    public Iterable<ItemStack> getHeldEquipment() {
        return this.inventoryHands;
    }

    @Override
    public Iterable<ItemStack> getArmorInventoryList() {
        return this.inventoryArmor;
    }

    @Override
    public ItemStack getItemStackFromSlot(EntityEquipmentSlot slotIn) {
        switch (slotIn.getSlotType()) {
            case HAND:
                return this.inventoryHands.get(slotIn.getIndex());
            case ARMOR:
                return this.inventoryArmor.get(slotIn.getIndex());
            default:
                return ItemStack.EMPTY;
        }
    }

    @Override
    public void setItemStackToSlot(EntityEquipmentSlot slotIn, ItemStack stack) {
        switch (slotIn.getSlotType()) {
            case HAND:
                this.inventoryHands.set(slotIn.getIndex(), stack);
                break;
            case ARMOR:
                this.inventoryArmor.set(slotIn.getIndex(), stack);
        }
    }

    @Override
    protected void dropEquipment(boolean wasRecentlyHit, int lootingModifier) {
        for (EntityEquipmentSlot entityequipmentslot : EntityEquipmentSlot.values()) {
            ItemStack itemstack = this.getItemStackFromSlot(entityequipmentslot);
            double d0 = this.getDropChance(entityequipmentslot);
            boolean flag = d0 > 1.0;
            if (!itemstack.isEmpty()
                && !EnchantmentHelper.hasVanishingCurse(itemstack)
                && (wasRecentlyHit || flag)
                && this.rand.nextFloat() - lootingModifier * 0.01F < d0) {
                if (!flag && itemstack.isDamageable()) {
                    itemstack.setDamage(
                        itemstack.getMaxDamage() - this.rand.nextInt(1 + this.rand.nextInt(Math.max(itemstack.getMaxDamage() - 3, 1)))
                    );
                }

                this.entityDropItem(itemstack);
            }
        }
    }

    protected double getDropChance(EntityEquipmentSlot p_205712_1_) {
        double d0;
        switch (p_205712_1_.getSlotType()) {
            case HAND:
                d0 = this.inventoryHandsDropChances[p_205712_1_.getIndex()];
                break;
            case ARMOR:
                d0 = this.inventoryArmorDropChances[p_205712_1_.getIndex()];
                break;
            default:
                d0 = 0.0;
        }

        return d0;
    }

    protected void setEquipmentBasedOnDifficulty(DifficultyInstance difficulty) {
        if (this.rand.nextFloat() < 0.15F * difficulty.getClampedAdditionalDifficulty()) {
            int i = this.rand.nextInt(2);
            float f = this.world.getDifficulty() == EnumDifficulty.HARD ? 0.1F : 0.25F;
            if (this.rand.nextFloat() < 0.095F) {
                i++;
            }

            if (this.rand.nextFloat() < 0.095F) {
                i++;
            }

            if (this.rand.nextFloat() < 0.095F) {
                i++;
            }

            boolean flag = true;

            for (EntityEquipmentSlot entityequipmentslot : EntityEquipmentSlot.values()) {
                if (entityequipmentslot.getSlotType() == EntityEquipmentSlot.Type.ARMOR) {
                    ItemStack itemstack = this.getItemStackFromSlot(entityequipmentslot);
                    if (!flag && this.rand.nextFloat() < f) {
                        break;
                    }

                    flag = false;
                    if (itemstack.isEmpty()) {
                        Item item = getArmorByChance(entityequipmentslot, i);
                        if (item != null) {
                            this.setItemStackToSlot(entityequipmentslot, new ItemStack(item));
                        }
                    }
                }
            }
        }
    }

    public static EntityEquipmentSlot getSlotForItemStack(ItemStack stack) {
        if (Reflector.ForgeItem_getEquipmentSlot.exists()) {
            EntityEquipmentSlot entityequipmentslot = (EntityEquipmentSlot)Reflector.call(
                stack.getItem(), Reflector.ForgeItem_getEquipmentSlot, stack
            );
            if (entityequipmentslot != null) {
                return entityequipmentslot;
            }
        }

        Item item = stack.getItem();
        if (item != Blocks.CARVED_PUMPKIN.asItem()
            && (!(item instanceof ItemBlock) || !(((ItemBlock)item).getBlock() instanceof BlockAbstractSkull))) {
            if (item instanceof ItemArmor) {
                return ((ItemArmor)item).getEquipmentSlot();
            }

            if (item == Items.ELYTRA) {
                return EntityEquipmentSlot.CHEST;
            }

            boolean flag = stack.getItem() == Items.SHIELD;
            if (Reflector.ForgeItem_isShield.exists()) {
                flag = Reflector.callBoolean(stack.getItem(), Reflector.ForgeItem_isShield, stack, null);
            }

            return flag ? EntityEquipmentSlot.OFFHAND : EntityEquipmentSlot.MAINHAND;
        } else {
            return EntityEquipmentSlot.HEAD;
        }
    }

    @Nullable
    public static Item getArmorByChance(EntityEquipmentSlot slotIn, int chance) {
        switch (slotIn) {
            case HEAD:
                if (chance == 0) {
                    return Items.LEATHER_HELMET;
                } else if (chance == 1) {
                    return Items.GOLDEN_HELMET;
                } else if (chance == 2) {
                    return Items.CHAINMAIL_HELMET;
                } else if (chance == 3) {
                    return Items.IRON_HELMET;
                } else if (chance == 4) {
                    return Items.DIAMOND_HELMET;
                }
            case CHEST:
                if (chance == 0) {
                    return Items.LEATHER_CHESTPLATE;
                } else if (chance == 1) {
                    return Items.GOLDEN_CHESTPLATE;
                } else if (chance == 2) {
                    return Items.CHAINMAIL_CHESTPLATE;
                } else if (chance == 3) {
                    return Items.IRON_CHESTPLATE;
                } else if (chance == 4) {
                    return Items.DIAMOND_CHESTPLATE;
                }
            case LEGS:
                if (chance == 0) {
                    return Items.LEATHER_LEGGINGS;
                } else if (chance == 1) {
                    return Items.GOLDEN_LEGGINGS;
                } else if (chance == 2) {
                    return Items.CHAINMAIL_LEGGINGS;
                } else if (chance == 3) {
                    return Items.IRON_LEGGINGS;
                } else if (chance == 4) {
                    return Items.DIAMOND_LEGGINGS;
                }
            case FEET:
                if (chance == 0) {
                    return Items.LEATHER_BOOTS;
                } else if (chance == 1) {
                    return Items.GOLDEN_BOOTS;
                } else if (chance == 2) {
                    return Items.CHAINMAIL_BOOTS;
                } else if (chance == 3) {
                    return Items.IRON_BOOTS;
                } else if (chance == 4) {
                    return Items.DIAMOND_BOOTS;
                }
            default:
                return null;
        }
    }

    protected void setEnchantmentBasedOnDifficulty(DifficultyInstance difficulty) {
        float f = difficulty.getClampedAdditionalDifficulty();
        if (!this.getHeldItemMainhand().isEmpty() && this.rand.nextFloat() < 0.25F * f) {
            this.setItemStackToSlot(
                EntityEquipmentSlot.MAINHAND,
                EnchantmentHelper.addRandomEnchantment(this.rand, this.getHeldItemMainhand(), (int)(5.0F + f * this.rand.nextInt(18)), false)
            );
        }

        for (EntityEquipmentSlot entityequipmentslot : EntityEquipmentSlot.values()) {
            if (entityequipmentslot.getSlotType() == EntityEquipmentSlot.Type.ARMOR) {
                ItemStack itemstack = this.getItemStackFromSlot(entityequipmentslot);
                if (!itemstack.isEmpty() && this.rand.nextFloat() < 0.5F * f) {
                    this.setItemStackToSlot(
                        entityequipmentslot,
                        EnchantmentHelper.addRandomEnchantment(this.rand, itemstack, (int)(5.0F + f * this.rand.nextInt(18)), false)
                    );
                }
            }
        }
    }

    @Nullable
    public IEntityLivingData onInitialSpawn(DifficultyInstance difficulty, @Nullable IEntityLivingData entityLivingData, @Nullable NBTTagCompound itemNbt) {
        this.getAttribute(SharedMonsterAttributes.FOLLOW_RANGE)
            .applyModifier(new AttributeModifier("Random spawn bonus", this.rand.nextGaussian() * 0.05, 1));
        if (this.rand.nextFloat() < 0.05F) {
            this.setLeftHanded(true);
        } else {
            this.setLeftHanded(false);
        }

        return entityLivingData;
    }

    public boolean canBeSteered() {
        return false;
    }

    public void enablePersistence() {
        this.persistenceRequired = true;
    }

    public void setDropChance(EntityEquipmentSlot slotIn, float chance) {
        switch (slotIn.getSlotType()) {
            case HAND:
                this.inventoryHandsDropChances[slotIn.getIndex()] = chance;
                break;
            case ARMOR:
                this.inventoryArmorDropChances[slotIn.getIndex()] = chance;
        }
    }

    public boolean canPickUpLoot() {
        return this.canPickUpLoot;
    }

    public void setCanPickUpLoot(boolean canPickup) {
        this.canPickUpLoot = canPickup;
    }

    public boolean isNoDespawnRequired() {
        return this.persistenceRequired;
    }

    @Override
    public final boolean processInitialInteract(EntityPlayer player, EnumHand hand) {
        if (this.getLeashed() && this.getLeashHolder() == player) {
            this.clearLeashed(true, !player.abilities.isCreativeMode);
            return true;
        } else {
            ItemStack itemstack = player.getHeldItem(hand);
            if (itemstack.getItem() == Items.LEAD && this.canBeLeashedTo(player)) {
                this.setLeashHolder(player, true);
                itemstack.shrink(1);
                return true;
            } else {
                return this.processInteract(player, hand) ? true : super.processInitialInteract(player, hand);
            }
        }
    }

    protected boolean processInteract(EntityPlayer player, EnumHand hand) {
        return false;
    }

    protected void updateLeashedState() {
        if (this.leashNBTTag != null) {
            this.recreateLeash();
        }

        if (this.isLeashed) {
            if (!this.isAlive()) {
                this.clearLeashed(true, true);
            }

            if (this.leashHolder == null || this.leashHolder.removed) {
                this.clearLeashed(true, true);
            }
        }
    }

    public void clearLeashed(boolean sendPacket, boolean dropLead) {
        if (this.isLeashed) {
            this.isLeashed = false;
            this.leashHolder = null;
            if (!this.world.isRemote && dropLead) {
                this.entityDropItem(Items.LEAD);
            }

            if (!this.world.isRemote && sendPacket && this.world instanceof WorldServer) {
                ((WorldServer)this.world).getEntityTracker().sendToTracking(this, new SPacketEntityAttach(this, (Entity)null));
            }
        }
    }

    public boolean canBeLeashedTo(EntityPlayer player) {
        return !this.getLeashed() && !(this instanceof IMob);
    }

    public boolean getLeashed() {
        return this.isLeashed;
    }

    public Entity getLeashHolder() {
        return this.leashHolder;
    }

    public void setLeashHolder(Entity entityIn, boolean sendAttachNotification) {
        this.isLeashed = true;
        this.leashHolder = entityIn;
        if (!this.world.isRemote && sendAttachNotification && this.world instanceof WorldServer) {
            ((WorldServer)this.world).getEntityTracker().sendToTracking(this, new SPacketEntityAttach(this, this.leashHolder));
        }

        if (this.isPassenger()) {
            this.stopRiding();
        }
    }

    @Override
    public boolean startRiding(Entity entityIn, boolean force) {
        boolean flag = super.startRiding(entityIn, force);
        if (flag && this.getLeashed()) {
            this.clearLeashed(true, true);
        }

        return flag;
    }

    private void recreateLeash() {
        if (this.isLeashed && this.leashNBTTag != null) {
            if (this.leashNBTTag.hasUniqueId("UUID")) {
                UUID uuid = this.leashNBTTag.getUniqueId("UUID");

                for (EntityLivingBase entitylivingbase : this.world.getEntitiesWithinAABB(EntityLivingBase.class, this.getBoundingBox().grow(10.0))) {
                    if (entitylivingbase.getUniqueID().equals(uuid)) {
                        this.setLeashHolder(entitylivingbase, true);
                        break;
                    }
                }
            } else if (this.leashNBTTag.contains("X", 99)
                && this.leashNBTTag.contains("Y", 99)
                && this.leashNBTTag.contains("Z", 99)) {
                BlockPos blockpos = new BlockPos(
                    this.leashNBTTag.getInt("X"), this.leashNBTTag.getInt("Y"), this.leashNBTTag.getInt("Z")
                );
                EntityLeashKnot entityleashknot = EntityLeashKnot.getKnotForPosition(this.world, blockpos);
                if (entityleashknot == null) {
                    entityleashknot = EntityLeashKnot.createKnot(this.world, blockpos);
                }

                this.setLeashHolder(entityleashknot, true);
            } else {
                this.clearLeashed(false, true);
            }
        }

        this.leashNBTTag = null;
    }

    @Override
    public boolean replaceItemInInventory(int inventorySlot, ItemStack itemStackIn) {
        EntityEquipmentSlot entityequipmentslot;
        if (inventorySlot == 98) {
            entityequipmentslot = EntityEquipmentSlot.MAINHAND;
        } else if (inventorySlot == 99) {
            entityequipmentslot = EntityEquipmentSlot.OFFHAND;
        } else if (inventorySlot == 100 + EntityEquipmentSlot.HEAD.getIndex()) {
            entityequipmentslot = EntityEquipmentSlot.HEAD;
        } else if (inventorySlot == 100 + EntityEquipmentSlot.CHEST.getIndex()) {
            entityequipmentslot = EntityEquipmentSlot.CHEST;
        } else if (inventorySlot == 100 + EntityEquipmentSlot.LEGS.getIndex()) {
            entityequipmentslot = EntityEquipmentSlot.LEGS;
        } else {
            if (inventorySlot != 100 + EntityEquipmentSlot.FEET.getIndex()) {
                return false;
            }

            entityequipmentslot = EntityEquipmentSlot.FEET;
        }

        if (!itemStackIn.isEmpty() && !isItemStackInSlot(entityequipmentslot, itemStackIn) && entityequipmentslot != EntityEquipmentSlot.HEAD) {
            return false;
        }

        this.setItemStackToSlot(entityequipmentslot, itemStackIn);
        return true;
    }

    @Override
    public boolean canPassengerSteer() {
        return this.canBeSteered() && super.canPassengerSteer();
    }

    public static boolean isItemStackInSlot(EntityEquipmentSlot slotIn, ItemStack stack) {
        EntityEquipmentSlot entityequipmentslot = getSlotForItemStack(stack);
        return entityequipmentslot == slotIn
            || entityequipmentslot == EntityEquipmentSlot.MAINHAND && slotIn == EntityEquipmentSlot.OFFHAND
            || entityequipmentslot == EntityEquipmentSlot.OFFHAND && slotIn == EntityEquipmentSlot.MAINHAND;
    }

    @Override
    public boolean isServerWorld() {
        return super.isServerWorld() && !this.isAIDisabled();
    }

    public void setNoAI(boolean disable) {
        byte b0 = this.dataManager.get(AI_FLAGS);
        this.dataManager.set(AI_FLAGS, disable ? (byte)(b0 | 1) : (byte)(b0 & -2));
    }

    public void setLeftHanded(boolean leftHanded) {
        byte b0 = this.dataManager.get(AI_FLAGS);
        this.dataManager.set(AI_FLAGS, leftHanded ? (byte)(b0 | 2) : (byte)(b0 & -3));
    }

    public boolean isAIDisabled() {
        return (this.dataManager.get(AI_FLAGS) & 1) != 0;
    }

    public boolean isLeftHanded() {
        return (this.dataManager.get(AI_FLAGS) & 2) != 0;
    }

    @Override
    public EnumHandSide getPrimaryHand() {
        return this.isLeftHanded() ? EnumHandSide.LEFT : EnumHandSide.RIGHT;
    }

    private boolean canSkipUpdate() {
        if (this.isChild()) {
            return false;
        }

        if (this.hurtTime > 0) {
            return false;
        }

        if (this.ticksExisted < 20) {
            return false;
        }

        World world = this.getEntityWorld();
        if (world == null) {
            return false;
        }

        if (world.playerEntities.size() != 1) {
            return false;
        }

        Entity entity = world.playerEntities.get(0);
        double d0 = Math.max(Math.abs(this.posX - entity.posX) - 16.0, 0.0);
        double d1 = Math.max(Math.abs(this.posZ - entity.posZ) - 16.0, 0.0);
        double d2 = d0 * d0 + d1 * d1;
        return !this.isInRangeToRenderDist(d2);
    }

    private void onUpdateMinimal() {
        this.idleTime++;
        if (this instanceof EntityMob) {
            float f = this.getBrightness();
            if (f > 0.5F) {
                this.idleTime += 2;
            }
        }

        this.checkDespawn();
    }

    @Override
    public Team getTeam() {
        UUID uuid = this.getUniqueID();
        if (this.teamUuid != uuid) {
            this.teamUuid = uuid;
            this.teamUuidString = uuid.toString();
        }

        return this.world.getScoreboard().getPlayersTeam(this.teamUuidString);
    }

    @Override
    public boolean attackEntityAsMob(Entity entityIn) {
        float f = (float)this.getAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getValue();
        int i = 0;
        if (entityIn instanceof EntityLivingBase) {
            f += EnchantmentHelper.getModifierForCreature(this.getHeldItemMainhand(), ((EntityLivingBase)entityIn).getCreatureAttribute());
            i += EnchantmentHelper.getKnockbackModifier(this);
        }

        boolean flag = entityIn.attackEntityFrom(DamageSource.causeMobDamage(this), f);
        if (flag) {
            if (i > 0 && entityIn instanceof EntityLivingBase) {
                ((EntityLivingBase)entityIn)
                    .knockBack(
                        this,
                        i * 0.5F,
                        MathHelper.sin(this.rotationYaw * (float) (Math.PI / 180.0)),
                        -MathHelper.cos(this.rotationYaw * (float) (Math.PI / 180.0))
                    );
                this.motionX *= 0.6;
                this.motionZ *= 0.6;
            }

            int j = EnchantmentHelper.getFireAspectModifier(this);
            if (j > 0) {
                entityIn.setFire(j * 4);
            }

            if (entityIn instanceof EntityPlayer) {
                EntityPlayer entityplayer = (EntityPlayer)entityIn;
                ItemStack itemstack = this.getHeldItemMainhand();
                ItemStack itemstack1 = entityplayer.isHandActive() ? entityplayer.getActiveItemStack() : ItemStack.EMPTY;
                if (!itemstack.isEmpty()
                    && !itemstack1.isEmpty()
                    && itemstack.getItem() instanceof ItemAxe
                    && itemstack1.getItem() == Items.SHIELD) {
                    float f1 = 0.25F + EnchantmentHelper.getEfficiencyModifier(this) * 0.05F;
                    if (this.rand.nextFloat() < f1) {
                        entityplayer.getCooldownTracker().setCooldown(Items.SHIELD, 100);
                        this.world.setEntityState(entityplayer, (byte)30);
                    }
                }
            }

            this.applyEnchantments(this, entityIn);
        }

        return flag;
    }

    protected boolean isInDaylight() {
        if (this.world.isDaytime() && !this.world.isRemote) {
            float f = this.getBrightness();
            BlockPos blockpos = this.getRidingEntity() instanceof EntityBoat
                ? new BlockPos(this.posX, Math.round(this.posY), this.posZ).up()
                : new BlockPos(this.posX, Math.round(this.posY), this.posZ);
            if (f > 0.5F && this.rand.nextFloat() * 30.0F < (f - 0.4F) * 2.0F && this.world.canSeeSky(blockpos)) {
                return true;
            }
        }

        return false;
    }

    @Override
    protected void handleFluidJump(Tag<Fluid> p_180466_1_) {
        if (this.getNavigator().getCanSwim()) {
            super.handleFluidJump(p_180466_1_);
        } else {
            this.motionY += 0.3F;
        }
    }
}
