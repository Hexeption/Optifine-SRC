package net.minecraft.util.text;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.command.CommandSource;
import net.minecraft.command.arguments.EntitySelector;
import net.minecraft.command.arguments.EntitySelectorParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TextComponentSelector extends TextComponentBase {
   private static final Logger LOGGER = LogManager.getLogger();
   private final String selector;
   @Nullable
   private final EntitySelector field_197670_d;

   public TextComponentSelector(String selectorIn) {
      this.selector = selectorIn;
      EntitySelector entityselector = null;

      try {
         EntitySelectorParser entityselectorparser = new EntitySelectorParser(new StringReader(selectorIn));
         entityselector = entityselectorparser.parse();
      } catch (CommandSyntaxException commandsyntaxexception) {
         LOGGER.warn("Invalid selector component: {}", selectorIn, commandsyntaxexception.getMessage());
      }

      this.field_197670_d = entityselector;
   }

   public String getSelector() {
      return this.selector;
   }

   public ITextComponent createNames(CommandSource p_197668_1_) throws CommandSyntaxException {
      return (ITextComponent)(this.field_197670_d == null ? new TextComponentString("") : EntitySelector.joinNames(this.field_197670_d.select(p_197668_1_)));
   }

   public String getUnformattedComponentText() {
      return this.selector;
   }

   public TextComponentSelector createCopy() {
      TextComponentSelector textcomponentselector = new TextComponentSelector(this.selector);
      textcomponentselector.setStyle(this.getStyle().createShallowCopy());

      for(ITextComponent itextcomponent : this.getSiblings()) {
         textcomponentselector.appendSibling(itextcomponent.createCopy());
      }

      return textcomponentselector;
   }

   public boolean equals(Object p_equals_1_) {
      if (this == p_equals_1_) {
         return true;
      } else if (!(p_equals_1_ instanceof TextComponentSelector)) {
         return false;
      } else {
         TextComponentSelector textcomponentselector = (TextComponentSelector)p_equals_1_;
         return this.selector.equals(textcomponentselector.selector) && super.equals(p_equals_1_);
      }
   }

   public String toString() {
      return "SelectorComponent{pattern='" + this.selector + '\'' + ", siblings=" + this.siblings + ", style=" + this.getStyle() + '}';
   }
}
