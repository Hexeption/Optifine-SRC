package net.minecraft.util;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import java.io.File;
import java.util.List;
import java.util.concurrent.ThreadFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.chunk.storage.AnvilChunkLoader;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.WorldInfo;
import net.minecraft.world.storage.WorldSavedDataStorage;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WorldOptimizer {
   private static final Logger LOGGER = LogManager.getLogger();
   private static final ThreadFactory THREAD_FACTORY = (new ThreadFactoryBuilder()).setDaemon(true).build();
   private final ISaveHandler worldStorage;
   private final WorldSavedDataStorage field_212222_d;
   private final Thread thread;
   private boolean active = true;
   private boolean field_212225_g = false;
   private float progressOverworld;
   private float progressNether;
   private float progressEnd;
   private int stepsOverworld;
   private int stepsNether;
   private int stepsEnd;
   private float totalProgress;
   private int totalChunks;
   private int converted = 0;
   private int skipped = 0;
   private ITextComponent statusText = new TextComponentTranslation("optimizeWorld.stage.counting", new Object[0]);
   private final String worldName;

   public WorldOptimizer(String p_i49804_1_, ISaveFormat p_i49804_2_, WorldInfo p_i49804_3_) {
      this.worldName = p_i49804_3_.getWorldName();
      this.worldStorage = p_i49804_2_.getSaveLoader(p_i49804_1_, (MinecraftServer)null);
      this.worldStorage.saveWorldInfo(p_i49804_3_);
      this.field_212222_d = new WorldSavedDataStorage(this.worldStorage);
      this.thread = THREAD_FACTORY.newThread(this::optimize);
      this.thread.setUncaughtExceptionHandler(this::handleException);
      this.thread.start();
   }

   private void handleException(Thread p_212206_1_, Throwable p_212206_2_) {
      LOGGER.error("Error upgrading world", p_212206_2_);
      this.active = false;
      this.statusText = new TextComponentTranslation("optimizeWorld.stage.failed", new Object[0]);
   }

   public void cancel() {
      this.active = false;

      try {
         this.thread.join();
      } catch (InterruptedException var2) {
         ;
      }

   }

   private void optimize() {
      File file1 = this.worldStorage.getWorldDirectory();
      WorldChunkEnumerator worldchunkenumerator = new WorldChunkEnumerator(file1);
      worldchunkenumerator.buildChunkPosLists();
      AnvilChunkLoader anvilchunkloader = new AnvilChunkLoader(file1, this.worldStorage.getFixer());
      AnvilChunkLoader anvilchunkloader1 = new AnvilChunkLoader(new File(file1, "DIM-1"), this.worldStorage.getFixer());
      AnvilChunkLoader anvilchunkloader2 = new AnvilChunkLoader(new File(file1, "DIM1"), this.worldStorage.getFixer());
      long i = Util.milliTime();
      List<ChunkPos> list = worldchunkenumerator.getOverworldChunks();
      List<ChunkPos> list1 = worldchunkenumerator.getNetherChunks();
      List<ChunkPos> list2 = worldchunkenumerator.getEndChunks();
      this.totalChunks = worldchunkenumerator.getOverworldChunks().size() + worldchunkenumerator.getNetherChunks().size() + worldchunkenumerator.getEndChunks().size();
      float f = (float)(list.size() + list1.size() + list2.size());
      this.statusText = new TextComponentTranslation("optimizeWorld.stage.upgrading", new Object[0]);

      while(this.active) {
         boolean flag = false;
         if (this.stepsOverworld < list.size()) {
            if (anvilchunkloader.convert(list.get(this.stepsOverworld++), DimensionType.OVERWORLD, this.field_212222_d)) {
               ++this.converted;
            } else {
               ++this.skipped;
            }

            flag = true;
         }

         if (this.stepsNether < list1.size()) {
            if (anvilchunkloader1.convert(list1.get(this.stepsNether++), DimensionType.NETHER, this.field_212222_d)) {
               ++this.converted;
            } else {
               ++this.skipped;
            }

            flag = true;
         }

         if (this.stepsEnd < list2.size()) {
            if (anvilchunkloader2.convert(list2.get(this.stepsEnd++), DimensionType.THE_END, this.field_212222_d)) {
               ++this.converted;
            } else {
               ++this.skipped;
            }

            flag = true;
         }

         if (f > 0.0F) {
            this.progressOverworld = (float)this.stepsOverworld / f;
            this.progressNether = (float)this.stepsNether / f;
            this.progressEnd = (float)this.stepsEnd / f;
         } else {
            this.progressOverworld = 0.33333334F;
            this.progressNether = 0.33333334F;
            this.progressEnd = 0.33333334F;
         }

         this.totalProgress = this.progressOverworld + this.progressNether + this.progressEnd;
         if (!flag) {
            this.active = false;
         }
      }

      this.statusText = new TextComponentTranslation("optimizeWorld.stage.finished", new Object[0]);
      i = Util.milliTime() - i;
      LOGGER.info("World optimizaton finished after {} ms", (long)i);
      anvilchunkloader.flush();
      anvilchunkloader1.flush();
      anvilchunkloader2.flush();
      this.field_212222_d.saveAllData();
      this.worldStorage.flush();
      this.field_212225_g = true;
   }

   public boolean isFinished() {
      return this.field_212225_g;
   }

   @OnlyIn(Dist.CLIENT)
   public float getOverworldProgress() {
      return this.progressOverworld;
   }

   @OnlyIn(Dist.CLIENT)
   public float getNetherProgress() {
      return this.progressNether;
   }

   @OnlyIn(Dist.CLIENT)
   public float getEndProgress() {
      return this.progressEnd;
   }

   @OnlyIn(Dist.CLIENT)
   public float getTotalProgress() {
      return this.totalProgress;
   }

   public int getTotalChunks() {
      return this.totalChunks;
   }

   public int getConverted() {
      return this.converted;
   }

   public int getSkipped() {
      return this.skipped;
   }

   public ITextComponent getStatusText() {
      return this.statusText;
   }

   @OnlyIn(Dist.CLIENT)
   public String getWorldName() {
      return this.worldName;
   }
}
