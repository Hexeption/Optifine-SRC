package net.minecraft.util.math;

import net.minecraft.entity.Entity;

public class ChunkPos {
    public final int x;
    public final int z;
    private int cachedHashCode = 0;

    public ChunkPos(int p_i1947_1_, int p_i1947_2_) {
        this.x = p_i1947_1_;
        this.z = p_i1947_2_;
    }

    public ChunkPos(BlockPos p_i46717_1_) {
        this.x = p_i46717_1_.getX() >> 4;
        this.z = p_i46717_1_.getZ() >> 4;
    }

    public ChunkPos(long p_i48713_1_) {
        this.x = (int)p_i48713_1_;
        this.z = (int)(p_i48713_1_ >> 32);
    }

    public long asLong() {
        return asLong(this.x, this.z);
    }

    public static long asLong(int x, int z) {
        return x & 4294967295L | (z & 4294967295L) << 32;
    }

    @Override
    public int hashCode() {
        if (this.cachedHashCode != 0) {
            return this.cachedHashCode;
        }

        int i = 1664525 * this.x + 1013904223;
        int j = 1664525 * (this.z ^ -559038737) + 1013904223;
        this.cachedHashCode = i ^ j;
        return this.cachedHashCode;
    }

    @Override
    public boolean equals(Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        }

        if (!(p_equals_1_ instanceof ChunkPos)) {
            return false;
        }

        ChunkPos chunkpos = (ChunkPos)p_equals_1_;
        return this.x == chunkpos.x && this.z == chunkpos.z;
    }

    public double getDistanceSq(Entity entityIn) {
        double d0 = this.x * 16 + 8;
        double d1 = this.z * 16 + 8;
        double d2 = d0 - entityIn.posX;
        double d3 = d1 - entityIn.posZ;
        return d2 * d2 + d3 * d3;
    }

    public int getXStart() {
        return this.x << 4;
    }

    public int getZStart() {
        return this.z << 4;
    }

    public int getXEnd() {
        return (this.x << 4) + 15;
    }

    public int getZEnd() {
        return (this.z << 4) + 15;
    }

    public BlockPos getBlock(int x, int y, int z) {
        return new BlockPos((this.x << 4) + x, y, (this.z << 4) + z);
    }

    @Override
    public String toString() {
        return "[" + this.x + ", " + this.z + "]";
    }

    public BlockPos asBlockPos() {
        return new BlockPos(this.x << 4, 0, this.z << 4);
    }
}
