package net.minecraft.util.math.shapes;

import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.doubles.DoubleList;
import java.util.List;
import net.minecraft.util.AxisRotation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public abstract class VoxelShape {
   protected final VoxelShapePart part;

   VoxelShape(VoxelShapePart part) {
      this.part = part;
   }

   public double getStart(EnumFacing.Axis axis) {
      return this.getValue(axis, this.part.getStart(axis));
   }

   public double getEnd(EnumFacing.Axis axis) {
      return this.getValue(axis, this.part.getEnd(axis));
   }

   public AxisAlignedBB getBoundingBox() {
      if (this.isEmpty()) {
         throw new UnsupportedOperationException("No bounds for empty shape.");
      } else {
         return new AxisAlignedBB(this.getStart(EnumFacing.Axis.X), this.getStart(EnumFacing.Axis.Y), this.getStart(EnumFacing.Axis.Z), this.getEnd(EnumFacing.Axis.X), this.getEnd(EnumFacing.Axis.Y), this.getEnd(EnumFacing.Axis.Z));
      }
   }

   protected double getValue(EnumFacing.Axis axis, int index) {
      if (index < 0) {
         return -1.7976931348623157E308D;
      } else {
         return index > this.part.getSize(axis) ? Double.MAX_VALUE : this.getValueUnchecked(axis, index);
      }
   }

   protected double getValueUnchecked(EnumFacing.Axis axis, int index) {
      return this.getValues(axis).getDouble(index);
   }

   protected abstract DoubleList getValues(EnumFacing.Axis axis);

   public boolean isEmpty() {
      return this.part.isEmpty();
   }

   public VoxelShape withOffset(double xOffset, double yOffset, double zOffset) {
      return (VoxelShape)(this.isEmpty() ? ShapeUtils.empty() : new VoxelShapeArray(this.part, new OffsetDoubleList(this.getValues(EnumFacing.Axis.X), xOffset), new OffsetDoubleList(this.getValues(EnumFacing.Axis.Y), yOffset), new OffsetDoubleList(this.getValues(EnumFacing.Axis.Z), zOffset)));
   }

   public VoxelShape simplify() {
      VoxelShape[] avoxelshape = new VoxelShape[]{ShapeUtils.empty()};
      this.forEachBox((p_197763_1_, p_197763_3_, p_197763_5_, p_197763_7_, p_197763_9_, p_197763_11_) -> {
         avoxelshape[0] = ShapeUtils.combine(avoxelshape[0], ShapeUtils.create(p_197763_1_, p_197763_3_, p_197763_5_, p_197763_7_, p_197763_9_, p_197763_11_), IBooleanFunction.OR);
      });
      return avoxelshape[0];
   }

   @OnlyIn(Dist.CLIENT)
   public void forEachEdge(ShapeUtils.LineConsumer action) {
      this.part.forEachEdge((p_197750_2_, p_197750_3_, p_197750_4_, p_197750_5_, p_197750_6_, p_197750_7_) -> {
         action.consume(this.getValueUnchecked(EnumFacing.Axis.X, p_197750_2_), this.getValueUnchecked(EnumFacing.Axis.Y, p_197750_3_), this.getValueUnchecked(EnumFacing.Axis.Z, p_197750_4_), this.getValueUnchecked(EnumFacing.Axis.X, p_197750_5_), this.getValueUnchecked(EnumFacing.Axis.Y, p_197750_6_), this.getValueUnchecked(EnumFacing.Axis.Z, p_197750_7_));
      }, true);
   }

   public void forEachBox(ShapeUtils.LineConsumer action) {
      this.part.forEachBox((p_197765_2_, p_197765_3_, p_197765_4_, p_197765_5_, p_197765_6_, p_197765_7_) -> {
         action.consume(this.getValueUnchecked(EnumFacing.Axis.X, p_197765_2_), this.getValueUnchecked(EnumFacing.Axis.Y, p_197765_3_), this.getValueUnchecked(EnumFacing.Axis.Z, p_197765_4_), this.getValueUnchecked(EnumFacing.Axis.X, p_197765_5_), this.getValueUnchecked(EnumFacing.Axis.Y, p_197765_6_), this.getValueUnchecked(EnumFacing.Axis.Z, p_197765_7_));
      }, true);
   }

   public List<AxisAlignedBB> toBoundingBoxList() {
      List<AxisAlignedBB> list = Lists.<AxisAlignedBB>newArrayList();
      this.forEachBox((p_203431_1_, p_203431_3_, p_203431_5_, p_203431_7_, p_203431_9_, p_203431_11_) -> {
         list.add(new AxisAlignedBB(p_203431_1_, p_203431_3_, p_203431_5_, p_203431_7_, p_203431_9_, p_203431_11_));
      });
      return list;
   }

   @OnlyIn(Dist.CLIENT)
   public double min(EnumFacing.Axis axis, double p_197764_2_, double p_197764_4_) {
      EnumFacing.Axis enumfacing$axis = AxisRotation.FORWARD.rotate(axis);
      EnumFacing.Axis enumfacing$axis1 = AxisRotation.BACKWARD.rotate(axis);
      int i = this.getClosestIndex(enumfacing$axis, p_197764_2_);
      int j = this.getClosestIndex(enumfacing$axis1, p_197764_4_);
      return this.getValue(axis, this.part.firstFilled(axis, i, j));
   }

   @OnlyIn(Dist.CLIENT)
   public double max(EnumFacing.Axis p_197760_1_, double p_197760_2_, double p_197760_4_) {
      EnumFacing.Axis enumfacing$axis = AxisRotation.FORWARD.rotate(p_197760_1_);
      EnumFacing.Axis enumfacing$axis1 = AxisRotation.BACKWARD.rotate(p_197760_1_);
      int i = this.getClosestIndex(enumfacing$axis, p_197760_2_);
      int j = this.getClosestIndex(enumfacing$axis1, p_197760_4_);
      return this.getValue(p_197760_1_, this.part.lastFilled(p_197760_1_, i, j));
   }

   public int getClosestIndex(EnumFacing.Axis axis, double position) {
      return MathHelper.binarySearch(0, this.part.getSize(axis) + 1, (p_197761_4_) -> {
         return position < this.getValue(axis, p_197761_4_);
      }) - 1;
   }

   public boolean contains(double x, double y, double z) {
      return this.part.contains(this.getClosestIndex(EnumFacing.Axis.X, x), this.getClosestIndex(EnumFacing.Axis.Y, y), this.getClosestIndex(EnumFacing.Axis.Z, z));
   }

   public String toString() {
      return this.isEmpty() ? "EMPTY" : "VoxelShape[" + this.getBoundingBox() + "]";
   }
}
