package net.minecraft.util.math.shapes;

import it.unimi.dsi.fastutil.doubles.AbstractDoubleList;
import it.unimi.dsi.fastutil.doubles.DoubleList;

public class SimpleDoubleMerger extends AbstractDoubleList implements IDoubleListMerger {
   private final DoubleList list;

   public SimpleDoubleMerger(DoubleList list) {
      this.list = list;
   }

   public int size() {
      return this.list.size();
   }

   public boolean forMergedIndexes(IDoubleListMerger.Consumer consumer) {
      for(int i = 0; i <= this.size(); ++i) {
         if (!consumer.merge(i, i, i)) {
            return false;
         }
      }

      return true;
   }

   public double getDouble(int p_getDouble_1_) {
      return this.list.getDouble(p_getDouble_1_);
   }
}
