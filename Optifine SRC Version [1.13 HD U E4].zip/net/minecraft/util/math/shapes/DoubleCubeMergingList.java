package net.minecraft.util.math.shapes;

import com.google.common.math.IntMath;

public final class DoubleCubeMergingList extends DoubleRangeList implements IDoubleListMerger {
   private final int firstSize;
   private final int secondSize;
   private final int gcd;

   DoubleCubeMergingList(int firstSize, int secondSize) {
      super((int)ShapeUtils.lcm(firstSize, secondSize));
      this.firstSize = firstSize;
      this.secondSize = secondSize;
      this.gcd = IntMath.gcd(firstSize, secondSize);
   }

   public boolean forMergedIndexes(IDoubleListMerger.Consumer consumer) {
      int i = this.firstSize / this.gcd;
      int j = this.secondSize / this.gcd;

      for(int k = 0; k <= this.size(); ++k) {
         if (!consumer.merge(k / j, k / i, k)) {
            return false;
         }
      }

      return true;
   }
}
