package net.minecraft.util.registry;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import javax.annotation.Nullable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public interface IRegistry<K, V> extends Iterable<V> {
   @Nullable
   @OnlyIn(Dist.CLIENT)
   V get(K name);

   void put(K key, V value);

   @OnlyIn(Dist.CLIENT)
   boolean isEmpty();

   default Stream<V> stream() {
      return StreamSupport.<V>stream(this.spliterator(), false);
   }
}
