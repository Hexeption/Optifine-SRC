package net.minecraft.util.registry;

import com.google.common.collect.HashBiMap;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.util.IObjectIntIterable;
import net.minecraft.util.IntIdentityHashBiMap;

public class RegistryNamespaced<K, V> extends RegistrySimple<K, V> implements IObjectIntIterable<V> {
   protected final IntIdentityHashBiMap<V> underlyingIntegerMap = new IntIdentityHashBiMap<V>(256);
   protected final Map<V, K> inverseObjectRegistry;
   private int nextFreeId;

   public RegistryNamespaced() {
      this.inverseObjectRegistry = ((HashBiMap<K, V>)this.registryObjects).inverse();
   }

   public void register(int id, K key, V value) {
      this.underlyingIntegerMap.put(value, id);
      super.put(key, value);
      if (this.nextFreeId <= id) {
         this.nextFreeId = id + 1;
      }

   }

   public void put(K key, V value) {
      this.register(this.nextFreeId, key, value);
   }

   protected Map<K, V> createUnderlyingMap() {
      return HashBiMap.<K, V>create();
   }

   @Nullable
   public V get(@Nullable K name) {
      return (V)super.get(name);
   }

   @Nullable
   public K getKey(V value) {
      return this.inverseObjectRegistry.get(value);
   }

   public boolean containsKey(K key) {
      return super.containsKey(key);
   }

   public int getId(@Nullable V value) {
      return this.underlyingIntegerMap.getId(value);
   }

   @Nullable
   public V get(int id) {
      return this.underlyingIntegerMap.get(id);
   }

   public Iterator<V> iterator() {
      return this.underlyingIntegerMap.iterator();
   }
}
