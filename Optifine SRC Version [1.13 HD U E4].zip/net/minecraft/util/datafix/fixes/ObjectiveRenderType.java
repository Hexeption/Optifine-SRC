package net.minecraft.util.datafix.fixes;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.Dynamic;
import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.util.Pair;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.scoreboard.IScoreCriteria;
import net.minecraft.util.datafix.TypeReferences;

public class ObjectiveRenderType extends DataFix {
   public ObjectiveRenderType(Schema p_i49781_1_, boolean p_i49781_2_) {
      super(p_i49781_1_, p_i49781_2_);
   }

   private static IScoreCriteria.EnumRenderType getRenderType(String p_211858_0_) {
      return p_211858_0_.equals("health") ? IScoreCriteria.EnumRenderType.HEARTS : IScoreCriteria.EnumRenderType.INTEGER;
   }

   protected TypeRewriteRule makeRule() {
      Type<Pair<String, Dynamic<?>>> type = DSL.named(TypeReferences.OBJECTIVE.typeName(), DSL.remainderType());
      if (!Objects.equals(type, this.getInputSchema().getType(TypeReferences.OBJECTIVE))) {
         throw new IllegalStateException("Objective type is not what was expected.");
      } else {
         return this.fixTypeEverywhere("ObjectiveRenderTypeFix", type, (p_211859_0_) -> {
            return (p_211860_0_) -> {
               return p_211860_0_.mapSecond((p_211857_0_) -> {
                  Optional<String> optional = p_211857_0_.get("RenderType").<String>flatMap(Dynamic::getStringValue);
                  if (!optional.isPresent()) {
                     String s = p_211857_0_.getString("CriteriaName");
                     IScoreCriteria.EnumRenderType iscorecriteria$enumrendertype = getRenderType(s);
                     return p_211857_0_.set("RenderType", p_211857_0_.createString(iscorecriteria$enumrendertype.getId()));
                  } else {
                     return p_211857_0_;
                  }
               });
            };
         });
      }
   }
}
