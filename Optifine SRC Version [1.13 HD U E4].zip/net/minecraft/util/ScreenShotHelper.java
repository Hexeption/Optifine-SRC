package net.minecraft.util;

import net.optifine.Config;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.Nullable;
import net.minecraft.client.GameSettings;
import net.minecraft.client.MainWindow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ScreenShotHelper {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss");

    public static ITextComponent saveScreenshot(File gameDirectory, int width, int height, Framebuffer buffer) {
        return saveScreenshot(gameDirectory, (String)null, width, height, buffer);
    }

    public static ITextComponent saveScreenshot(File gameDirectory, @Nullable String screenshotName, int width, int height, Framebuffer buffer) {
        Minecraft minecraft = Config.getMinecraft();
        MainWindow mainwindow = minecraft.mainWindow;
        GameSettings gamesettings = Config.getGameSettings();
        int i = mainwindow.getFramebufferWidth();
        int j = mainwindow.getFramebufferHeight();
        int k = gamesettings.guiScale;
        int l = mainwindow.getScaleFactor(minecraft.gameSettings.guiScale);
        int i1 = Config.getScreenshotSize();
        boolean flag = OpenGlHelper.isFramebufferEnabled() && i1 > 1;
        if (flag) {
            gamesettings.guiScale = l * i1;
            mainwindow.resizeFramebuffer(i * i1, j * i1);
            GlStateManager.pushMatrix();
            GlStateManager.clear(16640);
            minecraft.getFramebuffer().bindFramebuffer(true);
            GlStateManager.enableTexture2D();
            minecraft.entityRenderer.updateCameraAndRender(minecraft.getRenderPartialTicks(), System.nanoTime(), true);
        }

        try {
            NativeImage nativeimage = createScreenshot(width, height, buffer);
            if (flag) {
                minecraft.getFramebuffer().unbindFramebuffer();
                GlStateManager.popMatrix();
                Config.getGameSettings().guiScale = k;
                mainwindow.resizeFramebuffer(i, j);
            }

            Throwable throwable = null;

            TextComponentTranslation textcomponenttranslation;
            try {
                File file1 = new File(gameDirectory, "screenshots");
                file1.mkdir();
                File file2;
                if (screenshotName == null) {
                    file2 = getTimestampedPNGFileForDirectory(file1);
                } else {
                    file2 = new File(file1, screenshotName);
                }

                nativeimage.write(file2);
                ITextComponent itextcomponent = new TextComponentString(file2.getName())
                    .applyTextStyle(TextFormatting.UNDERLINE)
                    .applyTextStyle(
                        p_lambda$saveScreenshot$0_1_ -> p_lambda$saveScreenshot$0_1_.setClickEvent(
                            new ClickEvent(ClickEvent.Action.OPEN_FILE, file2.getAbsolutePath())
                        )
                    );
                textcomponenttranslation = new TextComponentTranslation("screenshot.success", itextcomponent);
            } catch (Throwable throwable2) {
                throwable = throwable2;
                throw throwable2;
            } finally {
                if (nativeimage != null) {
                    if (throwable != null) {
                        try {
                            nativeimage.close();
                        } catch (Throwable throwable1) {
                            throwable.addSuppressed(throwable1);
                        }
                    } else {
                        nativeimage.close();
                    }
                }
            }

            return textcomponenttranslation;
        } catch (Exception exception) {
            LOGGER.warn("Couldn't save screenshot", exception);
            return new TextComponentTranslation("screenshot.failure", exception.getMessage());
        }
    }

    public static NativeImage createScreenshot(int width, int height, Framebuffer framebufferIn) {
        if (OpenGlHelper.isFramebufferEnabled()) {
            width = framebufferIn.framebufferTextureWidth;
            height = framebufferIn.framebufferTextureHeight;
        }

        NativeImage nativeimage = new NativeImage(width, height, false);
        if (OpenGlHelper.isFramebufferEnabled()) {
            GlStateManager.bindTexture(framebufferIn.framebufferTexture);
            nativeimage.downloadFromTexture(0, true);
        } else {
            nativeimage.downloadFromFramebuffer(true);
        }

        nativeimage.flip();
        return nativeimage;
    }

    private static File getTimestampedPNGFileForDirectory(File gameDirectory) {
        String s = DATE_FORMAT.format(new Date());
        int i = 1;

        while (true) {
            File file1 = new File(gameDirectory, s + (i == 1 ? "" : "_" + i) + ".png");
            if (!file1.exists()) {
                return file1;
            }

            i++;
        }
    }
}
