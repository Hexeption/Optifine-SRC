package net.minecraft.pathfinding;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockRailBase;
import net.minecraft.block.BlockWall;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLiving;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;

public class WalkNodeProcessor extends NodeProcessor {
    private float avoidsWater;

    @Override
    public void initProcessor(IBlockAccess sourceIn, EntityLiving mob) {
        super.initProcessor(sourceIn, mob);
        this.avoidsWater = mob.getPathPriority(PathNodeType.WATER);
    }

    @Override
    public void postProcess() {
        super.postProcess();
        this.entity.setPathPriority(PathNodeType.WATER, this.avoidsWater);
    }

    @Override
    public PathPoint getStart() {
        int i;
        if (this.getCanSwim() && this.entity.isInWater()) {
            i = (int)this.entity.getEntityBoundingBox().minY;
            BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos(
                MathHelper.floor_double(this.entity.posX), i, MathHelper.floor_double(this.entity.posZ)
            );

            for (Block block = this.blockaccess.getBlockState(blockpos$mutableblockpos).getBlock();
                block == Blocks.FLOWING_WATER || block == Blocks.WATER;
                block = this.blockaccess.getBlockState(blockpos$mutableblockpos).getBlock()
            ) {
                blockpos$mutableblockpos.setPos(MathHelper.floor_double(this.entity.posX), ++i, MathHelper.floor_double(this.entity.posZ));
            }
        } else if (!this.entity.onGround) {
            BlockPos blockpos = new BlockPos(this.entity);

            while (
                (
                        this.blockaccess.getBlockState(blockpos).getMaterial() == Material.AIR
                            || this.blockaccess.getBlockState(blockpos).getBlock().isPassable(this.blockaccess, blockpos)
                    )
                    && blockpos.getY() > 0
            ) {
                blockpos = blockpos.down();
            }

            i = blockpos.up().getY();
        } else {
            i = MathHelper.floor_double(this.entity.getEntityBoundingBox().minY + 0.5);
        }

        BlockPos blockpos2 = new BlockPos(this.entity);
        PathNodeType pathnodetype1 = this.getPathNodeType(this.entity, blockpos2.getX(), i, blockpos2.getZ());
        if (this.entity.getPathPriority(pathnodetype1) < 0.0F) {
            Set<BlockPos> set = new HashSet<>();
            set.add(new BlockPos(this.entity.getEntityBoundingBox().minX, i, this.entity.getEntityBoundingBox().minZ));
            set.add(new BlockPos(this.entity.getEntityBoundingBox().minX, i, this.entity.getEntityBoundingBox().maxZ));
            set.add(new BlockPos(this.entity.getEntityBoundingBox().maxX, i, this.entity.getEntityBoundingBox().minZ));
            set.add(new BlockPos(this.entity.getEntityBoundingBox().maxX, i, this.entity.getEntityBoundingBox().maxZ));

            for (BlockPos blockpos1 : set) {
                PathNodeType pathnodetype = this.getPathNodeType(this.entity, blockpos1);
                if (this.entity.getPathPriority(pathnodetype) >= 0.0F) {
                    return this.openPoint(blockpos1.getX(), blockpos1.getY(), blockpos1.getZ());
                }
            }
        }

        return this.openPoint(blockpos2.getX(), i, blockpos2.getZ());
    }

    @Override
    public PathPoint getPathPointToCoords(double x, double y, double z) {
        return this.openPoint(
            MathHelper.floor_double(x - this.entity.width / 2.0F), MathHelper.floor_double(y), MathHelper.floor_double(z - this.entity.width / 2.0F)
        );
    }

    @Override
    public int findPathOptions(PathPoint[] pathOptions, PathPoint currentPoint, PathPoint targetPoint, float maxDistance) {
        int i = 0;
        int j = 0;
        PathNodeType pathnodetype = this.getPathNodeType(this.entity, currentPoint.xCoord, currentPoint.yCoord + 1, currentPoint.zCoord);
        if (this.entity.getPathPriority(pathnodetype) >= 0.0F) {
            j = 1;
        }

        BlockPos blockpos = new BlockPos(currentPoint.xCoord, currentPoint.yCoord, currentPoint.zCoord).down();
        double d0 = currentPoint.yCoord - (1.0 - this.blockaccess.getBlockState(blockpos).getBoundingBox(this.blockaccess, blockpos).maxY);
        PathPoint pathpoint = this.getSafePoint(currentPoint.xCoord, currentPoint.yCoord, currentPoint.zCoord + 1, j, d0, EnumFacing.SOUTH);
        PathPoint pathpoint1 = this.getSafePoint(currentPoint.xCoord - 1, currentPoint.yCoord, currentPoint.zCoord, j, d0, EnumFacing.WEST);
        PathPoint pathpoint2 = this.getSafePoint(currentPoint.xCoord + 1, currentPoint.yCoord, currentPoint.zCoord, j, d0, EnumFacing.EAST);
        PathPoint pathpoint3 = this.getSafePoint(currentPoint.xCoord, currentPoint.yCoord, currentPoint.zCoord - 1, j, d0, EnumFacing.NORTH);
        if (pathpoint != null && !pathpoint.visited && pathpoint.distanceTo(targetPoint) < maxDistance) {
            pathOptions[i++] = pathpoint;
        }

        if (pathpoint1 != null && !pathpoint1.visited && pathpoint1.distanceTo(targetPoint) < maxDistance) {
            pathOptions[i++] = pathpoint1;
        }

        if (pathpoint2 != null && !pathpoint2.visited && pathpoint2.distanceTo(targetPoint) < maxDistance) {
            pathOptions[i++] = pathpoint2;
        }

        if (pathpoint3 != null && !pathpoint3.visited && pathpoint3.distanceTo(targetPoint) < maxDistance) {
            pathOptions[i++] = pathpoint3;
        }

        boolean flag = pathpoint3 == null || pathpoint3.nodeType == PathNodeType.OPEN || pathpoint3.costMalus != 0.0F;
        boolean flag1 = pathpoint == null || pathpoint.nodeType == PathNodeType.OPEN || pathpoint.costMalus != 0.0F;
        boolean flag2 = pathpoint2 == null || pathpoint2.nodeType == PathNodeType.OPEN || pathpoint2.costMalus != 0.0F;
        boolean flag3 = pathpoint1 == null || pathpoint1.nodeType == PathNodeType.OPEN || pathpoint1.costMalus != 0.0F;
        if (flag && flag3) {
            PathPoint pathpoint4 = this.getSafePoint(currentPoint.xCoord - 1, currentPoint.yCoord, currentPoint.zCoord - 1, j, d0, EnumFacing.NORTH);
            if (pathpoint4 != null && !pathpoint4.visited && pathpoint4.distanceTo(targetPoint) < maxDistance) {
                pathOptions[i++] = pathpoint4;
            }
        }

        if (flag && flag2) {
            PathPoint pathpoint5 = this.getSafePoint(currentPoint.xCoord + 1, currentPoint.yCoord, currentPoint.zCoord - 1, j, d0, EnumFacing.NORTH);
            if (pathpoint5 != null && !pathpoint5.visited && pathpoint5.distanceTo(targetPoint) < maxDistance) {
                pathOptions[i++] = pathpoint5;
            }
        }

        if (flag1 && flag3) {
            PathPoint pathpoint6 = this.getSafePoint(currentPoint.xCoord - 1, currentPoint.yCoord, currentPoint.zCoord + 1, j, d0, EnumFacing.SOUTH);
            if (pathpoint6 != null && !pathpoint6.visited && pathpoint6.distanceTo(targetPoint) < maxDistance) {
                pathOptions[i++] = pathpoint6;
            }
        }

        if (flag1 && flag2) {
            PathPoint pathpoint7 = this.getSafePoint(currentPoint.xCoord + 1, currentPoint.yCoord, currentPoint.zCoord + 1, j, d0, EnumFacing.SOUTH);
            if (pathpoint7 != null && !pathpoint7.visited && pathpoint7.distanceTo(targetPoint) < maxDistance) {
                pathOptions[i++] = pathpoint7;
            }
        }

        return i;
    }

    private PathPoint getSafePoint(int x, int y, int z, int p_186332_4_, double p_186332_5_, EnumFacing facing) {
        PathPoint pathpoint = null;
        BlockPos blockpos = new BlockPos(x, y, z);
        BlockPos blockpos1 = blockpos.down();
        double d0 = y - (1.0 - this.blockaccess.getBlockState(blockpos1).getBoundingBox(this.blockaccess, blockpos1).maxY);
        if (d0 - p_186332_5_ > 1.0) {
            return null;
        }

        PathNodeType pathnodetype = this.getPathNodeType(this.entity, x, y, z);
        float f = this.entity.getPathPriority(pathnodetype);
        double d1 = this.entity.width / 2.0;
        if (f >= 0.0F) {
            pathpoint = this.openPoint(x, y, z);
            pathpoint.nodeType = pathnodetype;
            pathpoint.costMalus = Math.max(pathpoint.costMalus, f);
        }

        if (pathnodetype == PathNodeType.WALKABLE) {
            return pathpoint;
        }

        if (pathpoint == null && p_186332_4_ > 0 && pathnodetype != PathNodeType.FENCE && pathnodetype != PathNodeType.TRAPDOOR) {
            pathpoint = this.getSafePoint(x, y + 1, z, p_186332_4_ - 1, p_186332_5_, facing);
            if (pathpoint != null && (pathpoint.nodeType == PathNodeType.OPEN || pathpoint.nodeType == PathNodeType.WALKABLE)) {
                double d2 = x - facing.getFrontOffsetX() + 0.5;
                double d3 = z - facing.getFrontOffsetZ() + 0.5;
                AxisAlignedBB axisalignedbb = new AxisAlignedBB(d2 - d1, y + 0.001, d3 - d1, d2 + d1, y + this.entity.height, d3 + d1);
                AxisAlignedBB axisalignedbb1 = this.blockaccess.getBlockState(blockpos).getBoundingBox(this.blockaccess, blockpos);
                AxisAlignedBB axisalignedbb2 = axisalignedbb.addCoord(0.0, axisalignedbb1.maxY - 0.002, 0.0);
                if (this.entity.worldObj.collidesWithAnyBlock(axisalignedbb2)) {
                    pathpoint = null;
                }
            }
        }

        if (pathnodetype == PathNodeType.OPEN) {
            AxisAlignedBB axisalignedbb3 = new AxisAlignedBB(x - d1 + 0.5, y + 0.001, z - d1 + 0.5, x + d1 + 0.5, y + this.entity.height, z + d1 + 0.5);
            if (this.entity.worldObj.collidesWithAnyBlock(axisalignedbb3)) {
                return null;
            }

            int i = 0;

            while (y > 0 && pathnodetype == PathNodeType.OPEN) {
                y--;
                if (i++ >= this.entity.getMaxFallHeight()) {
                    return null;
                }

                pathnodetype = this.getPathNodeType(this.entity, x, y, z);
                f = this.entity.getPathPriority(pathnodetype);
                if (pathnodetype != PathNodeType.OPEN && f >= 0.0F) {
                    pathpoint = this.openPoint(x, y, z);
                    pathpoint.nodeType = pathnodetype;
                    pathpoint.costMalus = Math.max(pathpoint.costMalus, f);
                    break;
                }

                if (f < 0.0F) {
                    return null;
                }
            }
        }

        return pathpoint;
    }

    @Override
    public PathNodeType getPathNodeType(
        IBlockAccess blockaccessIn,
        int x,
        int y,
        int z,
        EntityLiving entitylivingIn,
        int xSize,
        int ySize,
        int zSize,
        boolean canBreakDoorsIn,
        boolean canEnterDoorsIn
    ) {
        EnumSet<PathNodeType> enumset = EnumSet.noneOf(PathNodeType.class);
        PathNodeType pathnodetype = PathNodeType.BLOCKED;
        double d0 = entitylivingIn.width / 2.0;
        BlockPos blockpos = new BlockPos(entitylivingIn);

        for (int i = x; i < x + xSize; i++) {
            for (int j = y; j < y + ySize; j++) {
                for (int k = z; k < z + zSize; k++) {
                    PathNodeType pathnodetype1 = getPathNodeType(blockaccessIn, i, j, k);
                    if (pathnodetype1 == PathNodeType.DOOR_WOOD_CLOSED && canBreakDoorsIn && canEnterDoorsIn) {
                        pathnodetype1 = PathNodeType.WALKABLE;
                    }

                    if (pathnodetype1 == PathNodeType.DOOR_OPEN && !canEnterDoorsIn) {
                        pathnodetype1 = PathNodeType.BLOCKED;
                    }

                    if (pathnodetype1 == PathNodeType.RAIL
                        && !(blockaccessIn.getBlockState(blockpos).getBlock() instanceof BlockRailBase)
                        && !(blockaccessIn.getBlockState(blockpos.down()).getBlock() instanceof BlockRailBase)) {
                        pathnodetype1 = PathNodeType.FENCE;
                    }

                    if (i == x && j == y && k == z) {
                        pathnodetype = pathnodetype1;
                    }

                    if (j > y && pathnodetype1 != PathNodeType.OPEN) {
                        AxisAlignedBB axisalignedbb = new AxisAlignedBB(
                            i - d0 + 0.5, y + 0.001, k - d0 + 0.5, i + d0 + 0.5, y + entitylivingIn.height, k + d0 + 0.5
                        );
                        if (!entitylivingIn.worldObj.collidesWithAnyBlock(axisalignedbb)) {
                            pathnodetype1 = PathNodeType.OPEN;
                        }
                    }

                    enumset.add(pathnodetype1);
                }
            }
        }

        if (enumset.contains(PathNodeType.FENCE)) {
            return PathNodeType.FENCE;
        }

        PathNodeType pathnodetype2 = PathNodeType.BLOCKED;

        for (PathNodeType pathnodetype3 : enumset) {
            if (entitylivingIn.getPathPriority(pathnodetype3) < 0.0F) {
                return pathnodetype3;
            }

            if (entitylivingIn.getPathPriority(pathnodetype3) >= entitylivingIn.getPathPriority(pathnodetype2)) {
                pathnodetype2 = pathnodetype3;
            }
        }

        return pathnodetype == PathNodeType.OPEN && entitylivingIn.getPathPriority(pathnodetype2) == 0.0F ? PathNodeType.OPEN : pathnodetype2;
    }

    private PathNodeType getPathNodeType(EntityLiving entitylivingIn, BlockPos pos) {
        return this.getPathNodeType(
            this.blockaccess,
            pos.getX(),
            pos.getY(),
            pos.getZ(),
            entitylivingIn,
            this.entitySizeX,
            this.entitySizeY,
            this.entitySizeZ,
            this.getCanBreakDoors(),
            this.getCanEnterDoors()
        );
    }

    private PathNodeType getPathNodeType(EntityLiving entitylivingIn, int x, int y, int z) {
        return this.getPathNodeType(
            this.blockaccess, x, y, z, entitylivingIn, this.entitySizeX, this.entitySizeY, this.entitySizeZ, this.getCanBreakDoors(), this.getCanEnterDoors()
        );
    }

    public static PathNodeType getPathNodeType(IBlockAccess p_186330_0_, int x, int y, int z) {
        BlockPos blockpos = new BlockPos(x, y, z);
        IBlockState iblockstate = p_186330_0_.getBlockState(blockpos);
        Block block = iblockstate.getBlock();
        Material material = iblockstate.getMaterial();
        PathNodeType pathnodetype = PathNodeType.BLOCKED;
        if (block == Blocks.TRAPDOOR || block == Blocks.IRON_TRAPDOOR || block == Blocks.WATERLILY) {
            return PathNodeType.TRAPDOOR;
        }

        if (block == Blocks.FIRE) {
            return PathNodeType.DAMAGE_FIRE;
        }

        if (block == Blocks.CACTUS) {
            return PathNodeType.DAMAGE_CACTUS;
        }

        if (block instanceof BlockDoor && material == Material.WOOD && !iblockstate.getValue(BlockDoor.OPEN)) {
            return PathNodeType.DOOR_WOOD_CLOSED;
        }

        if (block instanceof BlockDoor && material == Material.IRON && !iblockstate.getValue(BlockDoor.OPEN)) {
            return PathNodeType.DOOR_IRON_CLOSED;
        }

        if (block instanceof BlockDoor && iblockstate.getValue(BlockDoor.OPEN)) {
            return PathNodeType.DOOR_OPEN;
        }

        if (block instanceof BlockRailBase) {
            return PathNodeType.RAIL;
        }

        if (!(block instanceof BlockFence)
            && !(block instanceof BlockWall)
            && (!(block instanceof BlockFenceGate) || iblockstate.getValue(BlockFenceGate.OPEN))) {
            if (material == Material.AIR) {
                pathnodetype = PathNodeType.OPEN;
            } else {
                if (material == Material.WATER) {
                    return PathNodeType.WATER;
                }

                if (material == Material.LAVA) {
                    return PathNodeType.LAVA;
                }
            }

            if (block.isPassable(p_186330_0_, blockpos) && pathnodetype == PathNodeType.BLOCKED) {
                pathnodetype = PathNodeType.OPEN;
            }

            if (pathnodetype == PathNodeType.OPEN && y >= 1) {
                PathNodeType pathnodetype1 = getPathNodeType(p_186330_0_, x, y - 1, z);
                pathnodetype = pathnodetype1 != PathNodeType.WALKABLE
                        && pathnodetype1 != PathNodeType.OPEN
                        && pathnodetype1 != PathNodeType.WATER
                        && pathnodetype1 != PathNodeType.LAVA
                    ? PathNodeType.WALKABLE
                    : PathNodeType.OPEN;
            }

            if (pathnodetype == PathNodeType.WALKABLE) {
                for (int j = x - 1; j <= x + 1; j++) {
                    for (int i = z - 1; i <= z + 1; i++) {
                        if (j != x || i != z) {
                            Block block1 = p_186330_0_.getBlockState(new BlockPos(j, y, i)).getBlock();
                            if (block1 == Blocks.CACTUS) {
                                pathnodetype = PathNodeType.DANGER_CACTUS;
                            } else if (block1 == Blocks.FIRE) {
                                pathnodetype = PathNodeType.DANGER_FIRE;
                            }
                        }
                    }
                }
            }

            return pathnodetype;
        } else {
            return PathNodeType.FENCE;
        }
    }
}
