package net.minecraftforge.client.event;

public class RenderLevelStageEvent {
    public static class Stage {
        public static RenderLevelStageEvent.Stage AFTER_SKY = null;
        public static RenderLevelStageEvent.Stage AFTER_SOLID_BLOCKS = null;
        public static RenderLevelStageEvent.Stage AFTER_CUTOUT_MIPPED_BLOCKS_BLOCKS = null;
        public static RenderLevelStageEvent.Stage AFTER_CUTOUT_BLOCKS = null;
        public static RenderLevelStageEvent.Stage AFTER_ENTITIES = null;
        public static RenderLevelStageEvent.Stage AFTER_BLOCK_ENTITIES = null;
        public static RenderLevelStageEvent.Stage AFTER_TRANSLUCENT_BLOCKS = null;
        public static RenderLevelStageEvent.Stage AFTER_TRIPWIRE_BLOCKS = null;
        public static RenderLevelStageEvent.Stage AFTER_PARTICLES = null;
        public static RenderLevelStageEvent.Stage AFTER_WEATHER = null;
    }
}
