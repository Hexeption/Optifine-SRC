package net.minecraftforge.common.extensions;

import net.minecraft.nbt.CompoundTag;

public interface IForgeBlockEntity {
    CompoundTag getPersistentData();

    default void requestModelDataUpdate() {
    }

    default void onChunkUnloaded() {
    }
}
