package net.minecraft.village;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class MerchantRecipe {
    private ItemStack itemToBuy;
    private ItemStack secondItemToBuy;
    private ItemStack itemToSell;
    private int toolUses;
    private int maxTradeUses;
    private boolean rewardsExp;

    public MerchantRecipe(NBTTagCompound var1) {
        this.readFromTags(var1);
    }

    public MerchantRecipe(ItemStack var1, ItemStack var2, ItemStack var3) {
        this(var1, var2, var3, 0, 7);
    }

    public MerchantRecipe(ItemStack var1, ItemStack var2, ItemStack var3, int var4, int var5) {
        this.itemToBuy = var1;
        this.secondItemToBuy = var2;
        this.itemToSell = var3;
        this.toolUses = var4;
        this.maxTradeUses = var5;
        this.rewardsExp = true;
    }

    public MerchantRecipe(ItemStack var1, ItemStack var2) {
        this(var1, null, var2);
    }

    public MerchantRecipe(ItemStack var1, Item var2) {
        this(var1, new ItemStack(var2));
    }

    public ItemStack getItemToBuy() {
        return this.itemToBuy;
    }

    public ItemStack getSecondItemToBuy() {
        return this.secondItemToBuy;
    }

    public boolean hasSecondItemToBuy() {
        return this.secondItemToBuy != null;
    }

    public ItemStack getItemToSell() {
        return this.itemToSell;
    }

    public int getToolUses() {
        return this.toolUses;
    }

    public int getMaxTradeUses() {
        return this.maxTradeUses;
    }

    public void incrementToolUses() {
        this.toolUses++;
    }

    public void increaseMaxTradeUses(int var1) {
        this.maxTradeUses += var1;
    }

    public boolean isRecipeDisabled() {
        return this.toolUses >= this.maxTradeUses;
    }

    public void compensateToolUses() {
        this.toolUses = this.maxTradeUses;
    }

    public boolean getRewardsExp() {
        return this.rewardsExp;
    }

    public void readFromTags(NBTTagCompound var1) {
        NBTTagCompound nbttagcompound = var1.getCompoundTag("buy");
        this.itemToBuy = ItemStack.loadItemStackFromNBT(nbttagcompound);
        NBTTagCompound nbttagcompound1 = var1.getCompoundTag("sell");
        this.itemToSell = ItemStack.loadItemStackFromNBT(nbttagcompound1);
        if (var1.hasKey("buyB", 10)) {
            this.secondItemToBuy = ItemStack.loadItemStackFromNBT(var1.getCompoundTag("buyB"));
        }

        if (var1.hasKey("uses", 99)) {
            this.toolUses = var1.getInteger("uses");
        }

        if (var1.hasKey("maxUses", 99)) {
            this.maxTradeUses = var1.getInteger("maxUses");
        } else {
            this.maxTradeUses = 7;
        }

        if (var1.hasKey("rewardExp", 1)) {
            this.rewardsExp = var1.getBoolean("rewardExp");
        } else {
            this.rewardsExp = true;
        }
    }

    public NBTTagCompound writeToTags() {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        nbttagcompound.setTag("buy", this.itemToBuy.writeToNBT(new NBTTagCompound()));
        nbttagcompound.setTag("sell", this.itemToSell.writeToNBT(new NBTTagCompound()));
        if (this.secondItemToBuy != null) {
            nbttagcompound.setTag("buyB", this.secondItemToBuy.writeToNBT(new NBTTagCompound()));
        }

        nbttagcompound.setInteger("uses", this.toolUses);
        nbttagcompound.setInteger("maxUses", this.maxTradeUses);
        nbttagcompound.setBoolean("rewardExp", this.rewardsExp);
        return nbttagcompound;
    }
}
