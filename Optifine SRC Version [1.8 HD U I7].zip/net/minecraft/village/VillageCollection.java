package net.minecraft.village;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.material.Material;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldSavedData;

public class VillageCollection extends WorldSavedData {
    private World worldObj;
    private final List villagerPositionsList = Lists.newArrayList();
    private final List newDoors = Lists.newArrayList();
    private final List villageList = Lists.newArrayList();
    private int tickCounter;

    public VillageCollection(String var1) {
        super(var1);
    }

    public VillageCollection(World var1) {
        super(fileNameForProvider(var1.provider));
        this.worldObj = var1;
        this.markDirty();
    }

    public void setWorldsForAll(World var1) {
        this.worldObj = var1;

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            village.setWorld(var1);
        }
    }

    public void addToVillagerPositionList(BlockPos var1) {
        if (this.villagerPositionsList.size() <= 64) {
            if (!this.positionInList(var1)) {
                this.villagerPositionsList.add(var1);
            }
        }
    }

    public void tick() {
        this.tickCounter++;

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            village.tick(this.tickCounter);
        }

        this.removeAnnihilatedVillages();
        this.dropOldestVillagerPosition();
        this.addNewDoorsToVillageOrCreateVillage();
        if (this.tickCounter % 400 == 0) {
            this.markDirty();
        }
    }

    private void removeAnnihilatedVillages() {
        Iterator iterator = this.villageList.iterator();

        while (iterator.hasNext()) {
            Village village = (Village)iterator.next();
            if (village.isAnnihilated()) {
                iterator.remove();
                this.markDirty();
            }
        }
    }

    public List getVillageList() {
        return this.villageList;
    }

    public Village getNearestVillage(BlockPos var1, int var2) {
        Village village = null;
        double d0 = Float.MAX_VALUE;

        for (Village village1 : (Iterable<Village>) (Iterable) this.villageList) {
            double d1 = village1.getCenter().distanceSq(var1);
            if (!(d1 >= d0)) {
                float f = var2 + village1.getVillageRadius();
                if (!(d1 > f * f)) {
                    village = village1;
                    d0 = d1;
                }
            }
        }

        return village;
    }

    private void dropOldestVillagerPosition() {
        if (!this.villagerPositionsList.isEmpty()) {
            this.addDoorsAround((BlockPos)this.villagerPositionsList.remove(0));
        }
    }

    private void addNewDoorsToVillageOrCreateVillage() {
        for (int i = 0; i < this.newDoors.size(); i++) {
            VillageDoorInfo villagedoorinfo = (VillageDoorInfo)this.newDoors.get(i);
            Village village = this.getNearestVillage(villagedoorinfo.getDoorBlockPos(), 32);
            if (village == null) {
                village = new Village(this.worldObj);
                this.villageList.add(village);
                this.markDirty();
            }

            village.addVillageDoorInfo(villagedoorinfo);
        }

        this.newDoors.clear();
    }

    private void addDoorsAround(BlockPos var1) {
        byte b0 = 16;
        byte b1 = 4;
        byte b2 = 16;

        for (int i = -b0; i < b0; i++) {
            for (int j = -b1; j < b1; j++) {
                for (int k = -b2; k < b2; k++) {
                    BlockPos blockpos = var1.add(i, j, k);
                    if (this.isWoodDoor(blockpos)) {
                        VillageDoorInfo villagedoorinfo = this.checkDoorExistence(blockpos);
                        if (villagedoorinfo == null) {
                            this.addToNewDoorsList(blockpos);
                        } else {
                            villagedoorinfo.func_179849_a(this.tickCounter);
                        }
                    }
                }
            }
        }
    }

    private VillageDoorInfo checkDoorExistence(BlockPos var1) {
        for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.newDoors) {
            if (villagedoorinfo.getDoorBlockPos().getX() == var1.getX()
                && villagedoorinfo.getDoorBlockPos().getZ() == var1.getZ()
                && Math.abs(villagedoorinfo.getDoorBlockPos().getY() - var1.getY()) <= 1) {
                return villagedoorinfo;
            }
        }

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            VillageDoorInfo villagedoorinfo1 = village.getExistedDoor(var1);
            if (villagedoorinfo1 != null) {
                return villagedoorinfo1;
            }
        }

        return null;
    }

    private void addToNewDoorsList(BlockPos var1) {
        EnumFacing enumfacing = BlockDoor.getFacing(this.worldObj, var1);
        EnumFacing enumfacing1 = enumfacing.getOpposite();
        int i = this.countBlocksCanSeeSky(var1, enumfacing, 5);
        int j = this.countBlocksCanSeeSky(var1, enumfacing1, i + 1);
        if (i != j) {
            this.newDoors.add(new VillageDoorInfo(var1, i < j ? enumfacing : enumfacing1, this.tickCounter));
        }
    }

    private int countBlocksCanSeeSky(BlockPos var1, EnumFacing var2, int var3) {
        int i = 0;

        for (int j = 1; j <= 5; j++) {
            if (this.worldObj.canSeeSky(var1.offset(var2, j))) {
                if (++i >= var3) {
                    return i;
                }
            }
        }

        return i;
    }

    private boolean positionInList(BlockPos var1) {
        for (BlockPos blockpos : (Iterable<BlockPos>) (Iterable) this.villagerPositionsList) {
            if (blockpos.equals(var1)) {
                return true;
            }
        }

        return false;
    }

    private boolean isWoodDoor(BlockPos var1) {
        Block block = this.worldObj.getBlockState(var1).getBlock();
        return block instanceof BlockDoor ? block.getMaterial() == Material.wood : false;
    }

    @Override
    public void readFromNBT(NBTTagCompound var1) {
        this.tickCounter = var1.getInteger("Tick");
        NBTTagList nbttaglist = var1.getTagList("Villages", 10);

        for (int i = 0; i < nbttaglist.tagCount(); i++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            Village village = new Village();
            village.readVillageDataFromNBT(nbttagcompound);
            this.villageList.add(village);
        }
    }

    @Override
    public void writeToNBT(NBTTagCompound var1) {
        var1.setInteger("Tick", this.tickCounter);
        NBTTagList nbttaglist = new NBTTagList();

        for (Village village : (Iterable<Village>) (Iterable) this.villageList) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            village.writeVillageDataToNBT(nbttagcompound);
            nbttaglist.appendTag(nbttagcompound);
        }

        var1.setTag("Villages", nbttaglist);
    }

    public static String fileNameForProvider(WorldProvider var0) {
        return "villages" + var0.getInternalNameSuffix();
    }
}
