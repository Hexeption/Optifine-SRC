package net.minecraft.village;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class Village {
    private World worldObj;
    private final List villageDoorInfoList = Lists.newArrayList();
    private BlockPos centerHelper = BlockPos.ORIGIN;
    private BlockPos center = BlockPos.ORIGIN;
    private int villageRadius;
    private int lastAddDoorTimestamp;
    private int tickCounter;
    private int numVillagers;
    private int noBreedTicks;
    private TreeMap playerReputation = new TreeMap();
    private List villageAgressors = Lists.newArrayList();
    private int numIronGolems;

    public Village() {
    }

    public Village(World var1) {
        this.worldObj = var1;
    }

    public void setWorld(World var1) {
        this.worldObj = var1;
    }

    public void tick(int var1) {
        this.tickCounter = var1;
        this.removeDeadAndOutOfRangeDoors();
        this.removeDeadAndOldAgressors();
        if (var1 % 20 == 0) {
            this.updateNumVillagers();
        }

        if (var1 % 30 == 0) {
            this.updateNumIronGolems();
        }

        int i = this.numVillagers / 10;
        if (this.numIronGolems < i && this.villageDoorInfoList.size() > 20 && this.worldObj.rand.nextInt(7000) == 0) {
            Vec3 vec3 = this.func_179862_a(this.center, 2, 4, 2);
            if (vec3 != null) {
                EntityIronGolem entityirongolem = new EntityIronGolem(this.worldObj);
                entityirongolem.setPosition(vec3.xCoord, vec3.yCoord, vec3.zCoord);
                this.worldObj.spawnEntityInWorld(entityirongolem);
                this.numIronGolems++;
            }
        }
    }

    private Vec3 func_179862_a(BlockPos var1, int var2, int var3, int var4) {
        for (int i = 0; i < 10; i++) {
            BlockPos blockpos = var1.add(this.worldObj.rand.nextInt(16) - 8, this.worldObj.rand.nextInt(6) - 3, this.worldObj.rand.nextInt(16) - 8);
            if (this.func_179866_a(blockpos) && this.func_179861_a(new BlockPos(var2, var3, var4), blockpos)) {
                return new Vec3(blockpos.getX(), blockpos.getY(), blockpos.getZ());
            }
        }

        return null;
    }

    private boolean func_179861_a(BlockPos var1, BlockPos var2) {
        if (!World.doesBlockHaveSolidTopSurface(this.worldObj, var2.down())) {
            return false;
        }

        int i = var2.getX() - var1.getX() / 2;
        int j = var2.getZ() - var1.getZ() / 2;

        for (int k = i; k < i + var1.getX(); k++) {
            for (int l = var2.getY(); l < var2.getY() + var1.getY(); l++) {
                for (int i1 = j; i1 < j + var1.getZ(); i1++) {
                    if (this.worldObj.getBlockState(new BlockPos(k, l, i1)).getBlock().isNormalCube()) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private void updateNumIronGolems() {
        List list = this.worldObj
            .getEntitiesWithinAABB(
                EntityIronGolem.class,
                new AxisAlignedBB(
                    this.center.getX() - this.villageRadius,
                    this.center.getY() - 4,
                    this.center.getZ() - this.villageRadius,
                    this.center.getX() + this.villageRadius,
                    this.center.getY() + 4,
                    this.center.getZ() + this.villageRadius
                )
            );
        this.numIronGolems = list.size();
    }

    private void updateNumVillagers() {
        List list = this.worldObj
            .getEntitiesWithinAABB(
                EntityVillager.class,
                new AxisAlignedBB(
                    this.center.getX() - this.villageRadius,
                    this.center.getY() - 4,
                    this.center.getZ() - this.villageRadius,
                    this.center.getX() + this.villageRadius,
                    this.center.getY() + 4,
                    this.center.getZ() + this.villageRadius
                )
            );
        this.numVillagers = list.size();
        if (this.numVillagers == 0) {
            this.playerReputation.clear();
        }
    }

    public BlockPos getCenter() {
        return this.center;
    }

    public int getVillageRadius() {
        return this.villageRadius;
    }

    public int getNumVillageDoors() {
        return this.villageDoorInfoList.size();
    }

    public int getTicksSinceLastDoorAdding() {
        return this.tickCounter - this.lastAddDoorTimestamp;
    }

    public int getNumVillagers() {
        return this.numVillagers;
    }

    public boolean func_179866_a(BlockPos var1) {
        return this.center.distanceSq(var1) < this.villageRadius * this.villageRadius;
    }

    public List getVillageDoorInfoList() {
        return this.villageDoorInfoList;
    }

    public VillageDoorInfo getNearestDoor(BlockPos var1) {
        VillageDoorInfo villagedoorinfo = null;
        int i = Integer.MAX_VALUE;

        for (VillageDoorInfo villagedoorinfo1 : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            int j = villagedoorinfo1.getDistanceToDoorBlockSq(var1);
            if (j < i) {
                villagedoorinfo = villagedoorinfo1;
                i = j;
            }
        }

        return villagedoorinfo;
    }

    public VillageDoorInfo getDoorInfo(BlockPos var1) {
        VillageDoorInfo villagedoorinfo = null;
        int i = Integer.MAX_VALUE;

        for (VillageDoorInfo villagedoorinfo1 : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            int j = villagedoorinfo1.getDistanceToDoorBlockSq(var1);
            if (j > 256) {
                j *= 1000;
            } else {
                j = villagedoorinfo1.getDoorOpeningRestrictionCounter();
            }

            if (j < i) {
                villagedoorinfo = villagedoorinfo1;
                i = j;
            }
        }

        return villagedoorinfo;
    }

    public VillageDoorInfo getExistedDoor(BlockPos var1) {
        if (this.center.distanceSq(var1) > this.villageRadius * this.villageRadius) {
            return null;
        }

        for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            if (villagedoorinfo.getDoorBlockPos().getX() == var1.getX()
                && villagedoorinfo.getDoorBlockPos().getZ() == var1.getZ()
                && Math.abs(villagedoorinfo.getDoorBlockPos().getY() - var1.getY()) <= 1) {
                return villagedoorinfo;
            }
        }

        return null;
    }

    public void addVillageDoorInfo(VillageDoorInfo var1) {
        this.villageDoorInfoList.add(var1);
        this.centerHelper = this.centerHelper.add(var1.getDoorBlockPos());
        this.updateVillageRadiusAndCenter();
        this.lastAddDoorTimestamp = var1.getInsidePosY();
    }

    public boolean isAnnihilated() {
        return this.villageDoorInfoList.isEmpty();
    }

    public void addOrRenewAgressor(EntityLivingBase var1) {
        for (Village.VillageAggressor village$villageaggressor : (Iterable<Village.VillageAggressor>) (Iterable) this.villageAgressors) {
            if (village$villageaggressor.agressor == var1) {
                village$villageaggressor.agressionTime = this.tickCounter;
                return;
            }
        }

        this.villageAgressors.add(new Village.VillageAggressor(var1, this.tickCounter));
    }

    public EntityLivingBase findNearestVillageAggressor(EntityLivingBase var1) {
        double d0 = Double.MAX_VALUE;
        Village.VillageAggressor village$villageaggressor = null;

        for (int i = 0; i < this.villageAgressors.size(); i++) {
            Village.VillageAggressor village$villageaggressor1 = (Village.VillageAggressor)this.villageAgressors.get(i);
            double d1 = village$villageaggressor1.agressor.getDistanceSqToEntity(var1);
            if (!(d1 > d0)) {
                village$villageaggressor = village$villageaggressor1;
                d0 = d1;
            }
        }

        return village$villageaggressor != null ? village$villageaggressor.agressor : null;
    }

    public EntityPlayer getNearestTargetPlayer(EntityLivingBase var1) {
        double d0 = Double.MAX_VALUE;
        EntityPlayer entityplayer = null;

        for (String s : (Iterable<String>) (Iterable) this.playerReputation.keySet()) {
            if (this.isPlayerReputationTooLow(s)) {
                EntityPlayer entityplayer1 = this.worldObj.getPlayerEntityByName(s);
                if (entityplayer1 != null) {
                    double d1 = entityplayer1.getDistanceSqToEntity(var1);
                    if (!(d1 > d0)) {
                        entityplayer = entityplayer1;
                        d0 = d1;
                    }
                }
            }
        }

        return entityplayer;
    }

    private void removeDeadAndOldAgressors() {
        Iterator iterator = this.villageAgressors.iterator();

        while (iterator.hasNext()) {
            Village.VillageAggressor village$villageaggressor = (Village.VillageAggressor)iterator.next();
            if (!village$villageaggressor.agressor.isEntityAlive() || Math.abs(this.tickCounter - village$villageaggressor.agressionTime) > 300) {
                iterator.remove();
            }
        }
    }

    private void removeDeadAndOutOfRangeDoors() {
        boolean flag = false;
        boolean flag1 = this.worldObj.rand.nextInt(50) == 0;
        Iterator iterator = this.villageDoorInfoList.iterator();

        while (iterator.hasNext()) {
            VillageDoorInfo villagedoorinfo = (VillageDoorInfo)iterator.next();
            if (flag1) {
                villagedoorinfo.resetDoorOpeningRestrictionCounter();
            }

            if (!this.isWoodDoor(villagedoorinfo.getDoorBlockPos()) || Math.abs(this.tickCounter - villagedoorinfo.getInsidePosY()) > 1200) {
                this.centerHelper = this.centerHelper.add(villagedoorinfo.getDoorBlockPos().multiply(-1));
                flag = true;
                villagedoorinfo.setIsDetachedFromVillageFlag(true);
                iterator.remove();
            }
        }

        if (flag) {
            this.updateVillageRadiusAndCenter();
        }
    }

    private boolean isWoodDoor(BlockPos var1) {
        Block block = this.worldObj.getBlockState(var1).getBlock();
        return block instanceof BlockDoor ? block.getMaterial() == Material.wood : false;
    }

    private void updateVillageRadiusAndCenter() {
        int i = this.villageDoorInfoList.size();
        if (i == 0) {
            this.center = new BlockPos(0, 0, 0);
            this.villageRadius = 0;
        } else {
            this.center = new BlockPos(this.centerHelper.getX() / i, this.centerHelper.getY() / i, this.centerHelper.getZ() / i);
            int j = 0;

            for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
                j = Math.max(villagedoorinfo.getDistanceToDoorBlockSq(this.center), j);
            }

            this.villageRadius = Math.max(32, (int)Math.sqrt(j) + 1);
        }
    }

    public int getReputationForPlayer(String var1) {
        Integer integer = (Integer)this.playerReputation.get(var1);
        return integer != null ? integer : 0;
    }

    public int setReputationForPlayer(String var1, int var2) {
        int i = this.getReputationForPlayer(var1);
        int j = MathHelper.clamp_int(i + var2, -30, 10);
        this.playerReputation.put(var1, j);
        return j;
    }

    public boolean isPlayerReputationTooLow(String var1) {
        return this.getReputationForPlayer(var1) <= -15;
    }

    public void readVillageDataFromNBT(NBTTagCompound var1) {
        this.numVillagers = var1.getInteger("PopSize");
        this.villageRadius = var1.getInteger("Radius");
        this.numIronGolems = var1.getInteger("Golems");
        this.lastAddDoorTimestamp = var1.getInteger("Stable");
        this.tickCounter = var1.getInteger("Tick");
        this.noBreedTicks = var1.getInteger("MTick");
        this.center = new BlockPos(var1.getInteger("CX"), var1.getInteger("CY"), var1.getInteger("CZ"));
        this.centerHelper = new BlockPos(var1.getInteger("ACX"), var1.getInteger("ACY"), var1.getInteger("ACZ"));
        NBTTagList nbttaglist = var1.getTagList("Doors", 10);

        for (int i = 0; i < nbttaglist.tagCount(); i++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            VillageDoorInfo villagedoorinfo = new VillageDoorInfo(
                new BlockPos(nbttagcompound.getInteger("X"), nbttagcompound.getInteger("Y"), nbttagcompound.getInteger("Z")),
                nbttagcompound.getInteger("IDX"),
                nbttagcompound.getInteger("IDZ"),
                nbttagcompound.getInteger("TS")
            );
            this.villageDoorInfoList.add(villagedoorinfo);
        }

        NBTTagList nbttaglist1 = var1.getTagList("Players", 10);

        for (int j = 0; j < nbttaglist1.tagCount(); j++) {
            NBTTagCompound nbttagcompound1 = nbttaglist1.getCompoundTagAt(j);
            this.playerReputation.put(nbttagcompound1.getString("Name"), nbttagcompound1.getInteger("S"));
        }
    }

    public void writeVillageDataToNBT(NBTTagCompound var1) {
        var1.setInteger("PopSize", this.numVillagers);
        var1.setInteger("Radius", this.villageRadius);
        var1.setInteger("Golems", this.numIronGolems);
        var1.setInteger("Stable", this.lastAddDoorTimestamp);
        var1.setInteger("Tick", this.tickCounter);
        var1.setInteger("MTick", this.noBreedTicks);
        var1.setInteger("CX", this.center.getX());
        var1.setInteger("CY", this.center.getY());
        var1.setInteger("CZ", this.center.getZ());
        var1.setInteger("ACX", this.centerHelper.getX());
        var1.setInteger("ACY", this.centerHelper.getY());
        var1.setInteger("ACZ", this.centerHelper.getZ());
        NBTTagList nbttaglist = new NBTTagList();

        for (VillageDoorInfo villagedoorinfo : (Iterable<VillageDoorInfo>) (Iterable) this.villageDoorInfoList) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            nbttagcompound.setInteger("X", villagedoorinfo.getDoorBlockPos().getX());
            nbttagcompound.setInteger("Y", villagedoorinfo.getDoorBlockPos().getY());
            nbttagcompound.setInteger("Z", villagedoorinfo.getDoorBlockPos().getZ());
            nbttagcompound.setInteger("IDX", villagedoorinfo.getInsideOffsetX());
            nbttagcompound.setInteger("IDZ", villagedoorinfo.getInsideOffsetZ());
            nbttagcompound.setInteger("TS", villagedoorinfo.getInsidePosY());
            nbttaglist.appendTag(nbttagcompound);
        }

        var1.setTag("Doors", nbttaglist);
        NBTTagList nbttaglist1 = new NBTTagList();

        for (String s : (Iterable<String>) (Iterable) this.playerReputation.keySet()) {
            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            nbttagcompound1.setString("Name", s);
            nbttagcompound1.setInteger("S", (Integer)this.playerReputation.get(s));
            nbttaglist1.appendTag(nbttagcompound1);
        }

        var1.setTag("Players", nbttaglist1);
    }

    public void endMatingSeason() {
        this.noBreedTicks = this.tickCounter;
    }

    public boolean isMatingSeason() {
        return this.noBreedTicks == 0 || this.tickCounter - this.noBreedTicks >= 3600;
    }

    public void setDefaultPlayerReputation(int var1) {
        for (String s : (Iterable<String>) (Iterable) this.playerReputation.keySet()) {
            this.setReputationForPlayer(s, var1);
        }
    }

    class VillageAggressor {
        public EntityLivingBase agressor;
        public int agressionTime;

        VillageAggressor(EntityLivingBase var2, int var3) {
            this.agressor = var2;
            this.agressionTime = var3;
        }
    }
}
