package net.minecraft.village;

import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.PacketBuffer;

public class MerchantRecipeList extends ArrayList {
    public MerchantRecipeList() {
    }

    public MerchantRecipeList(NBTTagCompound var1) {
        this.readRecipiesFromTags(var1);
    }

    public MerchantRecipe canRecipeBeUsed(ItemStack var1, ItemStack var2, int var3) {
        if (var3 > 0 && var3 < this.size()) {
            MerchantRecipe merchantrecipe1 = (MerchantRecipe)this.get(var3);
            return !ItemStack.areItemsEqual(var1, merchantrecipe1.getItemToBuy())
                    || (var2 != null || merchantrecipe1.hasSecondItemToBuy())
                        && (!merchantrecipe1.hasSecondItemToBuy() || !ItemStack.areItemsEqual(var2, merchantrecipe1.getSecondItemToBuy()))
                    || var1.stackSize < merchantrecipe1.getItemToBuy().stackSize
                    || merchantrecipe1.hasSecondItemToBuy() && var2.stackSize < merchantrecipe1.getSecondItemToBuy().stackSize
                ? null
                : merchantrecipe1;
        }

        for (int i = 0; i < this.size(); i++) {
            MerchantRecipe merchantrecipe = (MerchantRecipe)this.get(i);
            if (ItemStack.areItemsEqual(var1, merchantrecipe.getItemToBuy())
                && var1.stackSize >= merchantrecipe.getItemToBuy().stackSize
                && (
                    !merchantrecipe.hasSecondItemToBuy() && var2 == null
                        || merchantrecipe.hasSecondItemToBuy()
                            && ItemStack.areItemsEqual(var2, merchantrecipe.getSecondItemToBuy())
                            && var2.stackSize >= merchantrecipe.getSecondItemToBuy().stackSize
                )) {
                return merchantrecipe;
            }
        }

        return null;
    }

    public void writeToBuf(PacketBuffer var1) {
        var1.writeByte((byte)(this.size() & 0xFF));

        for (int i = 0; i < this.size(); i++) {
            MerchantRecipe merchantrecipe = (MerchantRecipe)this.get(i);
            var1.writeItemStackToBuffer(merchantrecipe.getItemToBuy());
            var1.writeItemStackToBuffer(merchantrecipe.getItemToSell());
            ItemStack itemstack = merchantrecipe.getSecondItemToBuy();
            var1.writeBoolean(itemstack != null);
            if (itemstack != null) {
                var1.writeItemStackToBuffer(itemstack);
            }

            var1.writeBoolean(merchantrecipe.isRecipeDisabled());
            var1.writeInt(merchantrecipe.getToolUses());
            var1.writeInt(merchantrecipe.getMaxTradeUses());
        }
    }

    public static MerchantRecipeList readFromBuf(PacketBuffer var0) throws IOException {
        MerchantRecipeList merchantrecipelist = new MerchantRecipeList();
        int i = var0.readByte() & 255;

        for (int j = 0; j < i; j++) {
            ItemStack itemstack = var0.readItemStackFromBuffer();
            ItemStack itemstack1 = var0.readItemStackFromBuffer();
            ItemStack itemstack2 = null;
            if (var0.readBoolean()) {
                itemstack2 = var0.readItemStackFromBuffer();
            }

            boolean flag = var0.readBoolean();
            int k = var0.readInt();
            int l = var0.readInt();
            MerchantRecipe merchantrecipe = new MerchantRecipe(itemstack, itemstack2, itemstack1, k, l);
            if (flag) {
                merchantrecipe.compensateToolUses();
            }

            merchantrecipelist.add(merchantrecipe);
        }

        return merchantrecipelist;
    }

    public void readRecipiesFromTags(NBTTagCompound var1) {
        NBTTagList nbttaglist = var1.getTagList("Recipes", 10);

        for (int i = 0; i < nbttaglist.tagCount(); i++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            this.add(new MerchantRecipe(nbttagcompound));
        }
    }

    public NBTTagCompound getRecipiesAsTags() {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        NBTTagList nbttaglist = new NBTTagList();

        for (int i = 0; i < this.size(); i++) {
            MerchantRecipe merchantrecipe = (MerchantRecipe)this.get(i);
            nbttaglist.appendTag(merchantrecipe.writeToTags());
        }

        nbttagcompound.setTag("Recipes", nbttaglist);
        return nbttagcompound;
    }
}
