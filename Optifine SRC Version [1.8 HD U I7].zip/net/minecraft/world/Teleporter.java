package net.minecraft.world;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockPortal;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.LongHashMap;
import net.minecraft.util.MathHelper;

public class Teleporter {
    private final WorldServer worldServerInstance;
    private final Random random;
    private final LongHashMap destinationCoordinateCache = new LongHashMap();
    private final List destinationCoordinateKeys = Lists.newArrayList();

    public Teleporter(WorldServer var1) {
        this.worldServerInstance = var1;
        this.random = new Random(var1.getSeed());
    }

    public void placeInPortal(Entity var1, float var2) {
        if (this.worldServerInstance.provider.getDimensionId() != 1) {
            if (!this.placeInExistingPortal(var1, var2)) {
                this.makePortal(var1);
                this.placeInExistingPortal(var1, var2);
            }
        } else {
            int i = MathHelper.floor_double(var1.posX);
            int j = MathHelper.floor_double(var1.posY) - 1;
            int k = MathHelper.floor_double(var1.posZ);
            byte b0 = 1;
            byte b1 = 0;

            for (int l = -2; l <= 2; l++) {
                for (int i1 = -2; i1 <= 2; i1++) {
                    for (int j1 = -1; j1 < 3; j1++) {
                        int k1 = i + i1 * b0 + l * b1;
                        int l1 = j + j1;
                        int i2 = k + i1 * b1 - l * b0;
                        boolean flag = j1 < 0;
                        this.worldServerInstance
                            .setBlockState(new BlockPos(k1, l1, i2), flag ? Blocks.obsidian.getDefaultState() : Blocks.air.getDefaultState());
                    }
                }
            }

            var1.setLocationAndAngles(i, j, k, var1.rotationYaw, 0.0F);
            var1.motionX = var1.motionY = var1.motionZ = 0.0;
        }
    }

    public boolean placeInExistingPortal(Entity var1, float var2) {
        short short1 = 128;
        double d0 = -1.0;
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posZ);
        boolean flag = true;
        BlockPos blockpos = BlockPos.ORIGIN;
        long k = ChunkCoordIntPair.chunkXZ2Int(i, j);
        if (this.destinationCoordinateCache.containsItem(k)) {
            Teleporter.PortalPosition teleporter$portalposition = (Teleporter.PortalPosition)this.destinationCoordinateCache.getValueByKey(k);
            d0 = 0.0;
            blockpos = teleporter$portalposition;
            teleporter$portalposition.lastUpdateTime = this.worldServerInstance.getTotalWorldTime();
            flag = false;
        } else {
            BlockPos blockpos5 = new BlockPos(var1);

            for (int l = -128; l <= 128; l++) {
                for (int i1 = -128; i1 <= 128; i1++) {
                    BlockPos blockpos1 = blockpos5.add(l, this.worldServerInstance.getActualHeight() - 1 - blockpos5.getY(), i1);

                    while (blockpos1.getY() >= 0) {
                        BlockPos blockpos2 = blockpos1.down();
                        if (this.worldServerInstance.getBlockState(blockpos1).getBlock() == Blocks.portal) {
                            while (true) {
                                WorldServer worldserver = this.worldServerInstance;
                                blockpos2 = blockpos1.down();
                                if (worldserver.getBlockState(blockpos2).getBlock() != Blocks.portal) {
                                    double d1 = blockpos1.distanceSq(blockpos5);
                                    if (d0 < 0.0 || d1 < d0) {
                                        d0 = d1;
                                        blockpos = blockpos1;
                                    }
                                    break;
                                }

                                blockpos1 = blockpos2;
                            }
                        }

                        blockpos1 = blockpos2;
                    }
                }
            }
        }

        if (d0 >= 0.0) {
            if (flag) {
                this.destinationCoordinateCache.add(k, new Teleporter.PortalPosition(blockpos, this.worldServerInstance.getTotalWorldTime()));
                this.destinationCoordinateKeys.add(k);
            }

            double d4 = blockpos.getX() + 0.5;
            double d5 = blockpos.getY() + 0.5;
            double d6 = blockpos.getZ() + 0.5;
            EnumFacing enumfacing = null;
            if (this.worldServerInstance.getBlockState(blockpos.west()).getBlock() == Blocks.portal) {
                enumfacing = EnumFacing.NORTH;
            }

            if (this.worldServerInstance.getBlockState(blockpos.east()).getBlock() == Blocks.portal) {
                enumfacing = EnumFacing.SOUTH;
            }

            if (this.worldServerInstance.getBlockState(blockpos.north()).getBlock() == Blocks.portal) {
                enumfacing = EnumFacing.EAST;
            }

            if (this.worldServerInstance.getBlockState(blockpos.south()).getBlock() == Blocks.portal) {
                enumfacing = EnumFacing.WEST;
            }

            EnumFacing enumfacing1 = EnumFacing.getHorizontal(var1.getTeleportDirection());
            if (enumfacing != null) {
                EnumFacing enumfacing2 = enumfacing.rotateYCCW();
                BlockPos blockpos3 = blockpos.offset(enumfacing);
                boolean flag1 = this.func_180265_a(blockpos3);
                boolean flag2 = this.func_180265_a(blockpos3.offset(enumfacing2));
                if (flag2 && flag1) {
                    blockpos = blockpos.offset(enumfacing2);
                    enumfacing = enumfacing.getOpposite();
                    enumfacing2 = enumfacing2.getOpposite();
                    BlockPos blockpos4 = blockpos.offset(enumfacing);
                    flag1 = this.func_180265_a(blockpos4);
                    flag2 = this.func_180265_a(blockpos4.offset(enumfacing2));
                }

                float f5 = 0.5F;
                float f = 0.5F;
                if (!flag2 && flag1) {
                    f5 = 1.0F;
                } else if (flag2 && !flag1) {
                    f5 = 0.0F;
                } else if (flag2) {
                    f = 0.0F;
                }

                d4 = blockpos.getX() + 0.5;
                d5 = blockpos.getY() + 0.5;
                d6 = blockpos.getZ() + 0.5;
                d4 += enumfacing2.getFrontOffsetX() * f5 + enumfacing.getFrontOffsetX() * f;
                d6 += enumfacing2.getFrontOffsetZ() * f5 + enumfacing.getFrontOffsetZ() * f;
                float f1 = 0.0F;
                float f2 = 0.0F;
                float f3 = 0.0F;
                float f4 = 0.0F;
                if (enumfacing == enumfacing1) {
                    f1 = 1.0F;
                    f2 = 1.0F;
                } else if (enumfacing == enumfacing1.getOpposite()) {
                    f1 = -1.0F;
                    f2 = -1.0F;
                } else if (enumfacing == enumfacing1.rotateY()) {
                    f3 = 1.0F;
                    f4 = -1.0F;
                } else {
                    f3 = -1.0F;
                    f4 = 1.0F;
                }

                double d2 = var1.motionX;
                double d3 = var1.motionZ;
                var1.motionX = d2 * f1 + d3 * f4;
                var1.motionZ = d2 * f3 + d3 * f2;
                var1.rotationYaw = var2 - enumfacing1.getHorizontalIndex() * 90 + enumfacing.getHorizontalIndex() * 90;
            } else {
                var1.motionX = var1.motionY = var1.motionZ = 0.0;
            }

            var1.setLocationAndAngles(d4, d5, d6, var1.rotationYaw, var1.rotationPitch);
            return true;
        } else {
            return false;
        }
    }

    private boolean func_180265_a(BlockPos var1) {
        return !this.worldServerInstance.isAirBlock(var1) || !this.worldServerInstance.isAirBlock(var1.up());
    }

    public boolean makePortal(Entity var1) {
        byte b0 = 16;
        double d0 = -1.0;
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posY);
        int k = MathHelper.floor_double(var1.posZ);
        int l = i;
        int i1 = j;
        int j1 = k;
        int k1 = 0;
        int l1 = this.random.nextInt(4);

        for (int i2 = i - b0; i2 <= i + b0; i2++) {
            double d1 = i2 + 0.5 - var1.posX;

            for (int k2 = k - b0; k2 <= k + b0; k2++) {
                double d2 = k2 + 0.5 - var1.posZ;

                label296:
                for (int i3 = this.worldServerInstance.getActualHeight() - 1; i3 >= 0; i3--) {
                    if (this.worldServerInstance.isAirBlock(new BlockPos(i2, i3, k2))) {
                        while (i3 > 0 && this.worldServerInstance.isAirBlock(new BlockPos(i2, i3 - 1, k2))) {
                            i3--;
                        }

                        for (int j3 = l1; j3 < l1 + 4; j3++) {
                            int k3 = j3 % 2;
                            int l3 = 1 - k3;
                            if (j3 % 4 >= 2) {
                                k3 = -k3;
                                l3 = -l3;
                            }

                            for (int i4 = 0; i4 < 3; i4++) {
                                for (int j4 = 0; j4 < 4; j4++) {
                                    for (int k4 = -1; k4 < 4; k4++) {
                                        int l4 = i2 + (j4 - 1) * k3 + i4 * l3;
                                        int i5 = i3 + k4;
                                        int j5 = k2 + (j4 - 1) * l3 - i4 * k3;
                                        if (k4 < 0 && !this.worldServerInstance.getBlockState(new BlockPos(l4, i5, j5)).getBlock().getMaterial().isSolid()
                                            || k4 >= 0 && !this.worldServerInstance.isAirBlock(new BlockPos(l4, i5, j5))) {
                                            continue label296;
                                        }
                                    }
                                }
                            }

                            double d5 = i3 + 0.5 - var1.posY;
                            double d7 = d1 * d1 + d5 * d5 + d2 * d2;
                            if (d0 < 0.0 || d7 < d0) {
                                d0 = d7;
                                l = i2;
                                i1 = i3;
                                j1 = k2;
                                k1 = j3 % 4;
                            }
                        }
                    }
                }
            }
        }

        if (d0 < 0.0) {
            for (int k5 = i - b0; k5 <= i + b0; k5++) {
                double d3 = k5 + 0.5 - var1.posX;

                for (int j6 = k - b0; j6 <= k + b0; j6++) {
                    double d4 = j6 + 0.5 - var1.posZ;

                    label233:
                    for (int i7 = this.worldServerInstance.getActualHeight() - 1; i7 >= 0; i7--) {
                        if (this.worldServerInstance.isAirBlock(new BlockPos(k5, i7, j6))) {
                            while (i7 > 0 && this.worldServerInstance.isAirBlock(new BlockPos(k5, i7 - 1, j6))) {
                                i7--;
                            }

                            for (int k7 = l1; k7 < l1 + 2; k7++) {
                                int j8 = k7 % 2;
                                int j9 = 1 - j8;

                                for (int j10 = 0; j10 < 4; j10++) {
                                    for (int j11 = -1; j11 < 4; j11++) {
                                        int j12 = k5 + (j10 - 1) * j8;
                                        int i13 = i7 + j11;
                                        int j13 = j6 + (j10 - 1) * j9;
                                        if (j11 < 0 && !this.worldServerInstance.getBlockState(new BlockPos(j12, i13, j13)).getBlock().getMaterial().isSolid()
                                            || j11 >= 0 && !this.worldServerInstance.isAirBlock(new BlockPos(j12, i13, j13))) {
                                            continue label233;
                                        }
                                    }
                                }

                                double d6 = i7 + 0.5 - var1.posY;
                                double d8 = d3 * d3 + d6 * d6 + d4 * d4;
                                if (d0 < 0.0 || d8 < d0) {
                                    d0 = d8;
                                    l = k5;
                                    i1 = i7;
                                    j1 = j6;
                                    k1 = k7 % 2;
                                }
                            }
                        }
                    }
                }
            }
        }

        int l5 = k1;
        int i6 = l;
        int j2 = i1;
        int k6 = j1;
        int l6 = l5 % 2;
        int l2 = 1 - l6;
        if (l5 % 4 >= 2) {
            l6 = -l6;
            l2 = -l2;
        }

        if (d0 < 0.0) {
            i1 = MathHelper.clamp_int(i1, 70, this.worldServerInstance.getActualHeight() - 10);
            j2 = i1;

            for (int j7 = -1; j7 <= 1; j7++) {
                for (int l7 = 1; l7 < 3; l7++) {
                    for (int k8 = -1; k8 < 3; k8++) {
                        int k9 = i6 + (l7 - 1) * l6 + j7 * l2;
                        int k10 = j2 + k8;
                        int k11 = k6 + (l7 - 1) * l2 - j7 * l6;
                        boolean flag = k8 < 0;
                        this.worldServerInstance
                            .setBlockState(new BlockPos(k9, k10, k11), flag ? Blocks.obsidian.getDefaultState() : Blocks.air.getDefaultState());
                    }
                }
            }
        }

        IBlockState iblockstate = Blocks.portal.getDefaultState().withProperty(BlockPortal.AXIS, l6 != 0 ? EnumFacing.Axis.X : EnumFacing.Axis.Z);

        for (int i8 = 0; i8 < 4; i8++) {
            for (int l8 = 0; l8 < 4; l8++) {
                for (int l9 = -1; l9 < 4; l9++) {
                    int l10 = i6 + (l8 - 1) * l6;
                    int l11 = j2 + l9;
                    int k12 = k6 + (l8 - 1) * l2;
                    boolean flag1 = l8 == 0 || l8 == 3 || l9 == -1 || l9 == 3;
                    this.worldServerInstance.setBlockState(new BlockPos(l10, l11, k12), flag1 ? Blocks.obsidian.getDefaultState() : iblockstate, 2);
                }
            }

            for (int i9 = 0; i9 < 4; i9++) {
                for (int i10 = -1; i10 < 4; i10++) {
                    int i11 = i6 + (i9 - 1) * l6;
                    int i12 = j2 + i10;
                    int l12 = k6 + (i9 - 1) * l2;
                    this.worldServerInstance
                        .notifyNeighborsOfStateChange(
                            new BlockPos(i11, i12, l12), this.worldServerInstance.getBlockState(new BlockPos(i11, i12, l12)).getBlock()
                        );
                }
            }
        }

        return true;
    }

    public void removeStalePortalLocations(long var1) {
        if (var1 % 100L == 0L) {
            Iterator iterator = this.destinationCoordinateKeys.iterator();
            long i = var1 - 600L;

            while (iterator.hasNext()) {
                Long olong = (Long)iterator.next();
                Teleporter.PortalPosition teleporter$portalposition = (Teleporter.PortalPosition)this.destinationCoordinateCache.getValueByKey(olong);
                if (teleporter$portalposition == null || teleporter$portalposition.lastUpdateTime < i) {
                    iterator.remove();
                    this.destinationCoordinateCache.remove(olong);
                }
            }
        }
    }

    public class PortalPosition extends BlockPos {
        public long lastUpdateTime;

        public PortalPosition(BlockPos var2, long var3) {
            super(var2.getX(), var2.getY(), var2.getZ());
            this.lastUpdateTime = var3;
        }
    }
}
