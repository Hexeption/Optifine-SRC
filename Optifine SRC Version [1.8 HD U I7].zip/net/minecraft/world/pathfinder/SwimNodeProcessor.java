package net.minecraft.world.pathfinder;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;

public class SwimNodeProcessor extends NodeProcessor {
    @Override
    public void initProcessor(IBlockAccess var1, Entity var2) {
        super.initProcessor(var1, var2);
    }

    @Override
    public void postProcess() {
        super.postProcess();
    }

    @Override
    public PathPoint getPathPointTo(Entity var1) {
        return this.openPoint(
            MathHelper.floor_double(var1.getEntityBoundingBox().minX),
            MathHelper.floor_double(var1.getEntityBoundingBox().minY + 0.5),
            MathHelper.floor_double(var1.getEntityBoundingBox().minZ)
        );
    }

    @Override
    public PathPoint getPathPointToCoords(Entity var1, double var2, double var4, double var6) {
        return this.openPoint(
            MathHelper.floor_double(var2 - var1.width / 2.0F), MathHelper.floor_double(var4 + 0.5), MathHelper.floor_double(var6 - var1.width / 2.0F)
        );
    }

    @Override
    public int findPathOptions(PathPoint[] var1, Entity var2, PathPoint var3, PathPoint var4, float var5) {
        int i = 0;

        for (EnumFacing enumfacing : EnumFacing.values()) {
            PathPoint pathpoint = this.getSafePoint(
                var2, var3.xCoord + enumfacing.getFrontOffsetX(), var3.yCoord + enumfacing.getFrontOffsetY(), var3.zCoord + enumfacing.getFrontOffsetZ()
            );
            if (pathpoint != null && !pathpoint.visited && pathpoint.distanceTo(var4) < var5) {
                var1[i++] = pathpoint;
            }
        }

        return i;
    }

    private PathPoint getSafePoint(Entity var1, int var2, int var3, int var4) {
        int i = this.func_176186_b(var1, var2, var3, var4);
        return i == -1 ? this.openPoint(var2, var3, var4) : null;
    }

    private int func_176186_b(Entity var1, int var2, int var3, int var4) {
        for (int i = var2; i < var2 + this.entitySizeX; i++) {
            for (int j = var3; j < var3 + this.entitySizeY; j++) {
                for (int k = var4; k < var4 + this.entitySizeZ; k++) {
                    BlockPos blockpos = new BlockPos(i, j, k);
                    Block block = this.blockaccess.getBlockState(blockpos).getBlock();
                    if (block.getMaterial() != Material.water) {
                        return 0;
                    }
                }
            }
        }

        return -1;
    }
}
