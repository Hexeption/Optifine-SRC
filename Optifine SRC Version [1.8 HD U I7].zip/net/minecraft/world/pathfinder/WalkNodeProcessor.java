package net.minecraft.world.pathfinder;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockRailBase;
import net.minecraft.block.BlockWall;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;

public class WalkNodeProcessor extends NodeProcessor {
    private boolean canEnterDoors;
    private boolean canBreakDoors;
    private boolean avoidsWater;
    private boolean canSwim;
    private boolean shouldAvoidWater;

    @Override
    public void initProcessor(IBlockAccess var1, Entity var2) {
        super.initProcessor(var1, var2);
        this.shouldAvoidWater = this.avoidsWater;
    }

    @Override
    public void postProcess() {
        super.postProcess();
        this.avoidsWater = this.shouldAvoidWater;
    }

    @Override
    public PathPoint getPathPointTo(Entity var1) {
        int i;
        if (this.canSwim && var1.isInWater()) {
            i = (int)var1.getEntityBoundingBox().minY;
            Block block = this.blockaccess.getBlockState(new BlockPos(MathHelper.floor_double(var1.posX), i, MathHelper.floor_double(var1.posZ))).getBlock();

            while (block == Blocks.flowing_water || block == Blocks.water) {
                block = this.blockaccess.getBlockState(new BlockPos(MathHelper.floor_double(var1.posX), ++i, MathHelper.floor_double(var1.posZ))).getBlock();
            }

            this.avoidsWater = false;
        } else {
            i = MathHelper.floor_double(var1.getEntityBoundingBox().minY + 0.5);
        }

        return this.openPoint(MathHelper.floor_double(var1.getEntityBoundingBox().minX), i, MathHelper.floor_double(var1.getEntityBoundingBox().minZ));
    }

    @Override
    public PathPoint getPathPointToCoords(Entity var1, double var2, double var4, double var6) {
        return this.openPoint(
            MathHelper.floor_double(var2 - var1.width / 2.0F), MathHelper.floor_double(var4), MathHelper.floor_double(var6 - var1.width / 2.0F)
        );
    }

    @Override
    public int findPathOptions(PathPoint[] var1, Entity var2, PathPoint var3, PathPoint var4, float var5) {
        int i = 0;
        byte b0 = 0;
        if (this.getVerticalOffset(var2, var3.xCoord, var3.yCoord + 1, var3.zCoord) == 1) {
            b0 = 1;
        }

        PathPoint pathpoint = this.getSafePoint(var2, var3.xCoord, var3.yCoord, var3.zCoord + 1, b0);
        PathPoint pathpoint1 = this.getSafePoint(var2, var3.xCoord - 1, var3.yCoord, var3.zCoord, b0);
        PathPoint pathpoint2 = this.getSafePoint(var2, var3.xCoord + 1, var3.yCoord, var3.zCoord, b0);
        PathPoint pathpoint3 = this.getSafePoint(var2, var3.xCoord, var3.yCoord, var3.zCoord - 1, b0);
        if (pathpoint != null && !pathpoint.visited && pathpoint.distanceTo(var4) < var5) {
            var1[i++] = pathpoint;
        }

        if (pathpoint1 != null && !pathpoint1.visited && pathpoint1.distanceTo(var4) < var5) {
            var1[i++] = pathpoint1;
        }

        if (pathpoint2 != null && !pathpoint2.visited && pathpoint2.distanceTo(var4) < var5) {
            var1[i++] = pathpoint2;
        }

        if (pathpoint3 != null && !pathpoint3.visited && pathpoint3.distanceTo(var4) < var5) {
            var1[i++] = pathpoint3;
        }

        return i;
    }

    private PathPoint getSafePoint(Entity var1, int var2, int var3, int var4, int var5) {
        PathPoint pathpoint = null;
        int i = this.getVerticalOffset(var1, var2, var3, var4);
        if (i == 2) {
            return this.openPoint(var2, var3, var4);
        }

        if (i == 1) {
            pathpoint = this.openPoint(var2, var3, var4);
        }

        if (pathpoint == null && var5 > 0 && i != -3 && i != -4 && this.getVerticalOffset(var1, var2, var3 + var5, var4) == 1) {
            pathpoint = this.openPoint(var2, var3 + var5, var4);
            var3 += var5;
        }

        if (pathpoint != null) {
            int j = 0;
            int k = 0;

            while (var3 > 0) {
                k = this.getVerticalOffset(var1, var2, var3 - 1, var4);
                if (this.avoidsWater && k == -1) {
                    return null;
                }

                if (k != 1) {
                    break;
                }

                if (j++ >= var1.getMaxFallHeight()) {
                    return null;
                }

                if (--var3 <= 0) {
                    return null;
                }

                pathpoint = this.openPoint(var2, var3, var4);
            }

            if (k == -2) {
                return null;
            }
        }

        return pathpoint;
    }

    private int getVerticalOffset(Entity var1, int var2, int var3, int var4) {
        return func_176170_a(
            this.blockaccess,
            var1,
            var2,
            var3,
            var4,
            this.entitySizeX,
            this.entitySizeY,
            this.entitySizeZ,
            this.avoidsWater,
            this.canBreakDoors,
            this.canEnterDoors
        );
    }

    public static int func_176170_a(
        IBlockAccess var0, Entity var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8, boolean var9, boolean var10
    ) {
        boolean flag = false;
        BlockPos blockpos = new BlockPos(var1);

        for (int i = var2; i < var2 + var5; i++) {
            for (int j = var3; j < var3 + var6; j++) {
                for (int k = var4; k < var4 + var7; k++) {
                    BlockPos blockpos1 = new BlockPos(i, j, k);
                    Block block = var0.getBlockState(blockpos1).getBlock();
                    if (block.getMaterial() != Material.air) {
                        if (block == Blocks.trapdoor || block == Blocks.iron_trapdoor) {
                            flag = true;
                        } else if (block != Blocks.flowing_water && block != Blocks.water) {
                            if (!var10 && block instanceof BlockDoor && block.getMaterial() == Material.wood) {
                                return 0;
                            }
                        } else {
                            if (var8) {
                                return -1;
                            }

                            flag = true;
                        }

                        if (var1.worldObj.getBlockState(blockpos1).getBlock() instanceof BlockRailBase) {
                            if (!(var1.worldObj.getBlockState(blockpos).getBlock() instanceof BlockRailBase)
                                && !(var1.worldObj.getBlockState(blockpos.down()).getBlock() instanceof BlockRailBase)) {
                                return -3;
                            }
                        } else if (!block.isPassable(var0, blockpos1) && (!var9 || !(block instanceof BlockDoor) || block.getMaterial() != Material.wood)) {
                            if (block instanceof BlockFence || block instanceof BlockFenceGate || block instanceof BlockWall) {
                                return -3;
                            }

                            if (block == Blocks.trapdoor || block == Blocks.iron_trapdoor) {
                                return -4;
                            }

                            Material material = block.getMaterial();
                            if (material != Material.lava) {
                                return 0;
                            }

                            if (!var1.isInLava()) {
                                return -2;
                            }
                        }
                    }
                }
            }
        }

        return flag ? 2 : 1;
    }

    public void setEnterDoors(boolean var1) {
        this.canEnterDoors = var1;
    }

    public void setBreakDoors(boolean var1) {
        this.canBreakDoors = var1;
    }

    public void setAvoidsWater(boolean var1) {
        this.avoidsWater = var1;
    }

    public void setCanSwim(boolean var1) {
        this.canSwim = var1;
    }

    public boolean getEnterDoors() {
        return this.canEnterDoors;
    }

    public boolean getCanSwim() {
        return this.canSwim;
    }

    public boolean getAvoidsWater() {
        return this.avoidsWater;
    }
}
