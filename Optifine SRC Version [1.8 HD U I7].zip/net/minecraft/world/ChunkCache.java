package net.minecraft.world;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;

public class ChunkCache implements IBlockAccess {
    protected int chunkX;
    protected int chunkZ;
    protected Chunk[][] chunkArray;
    protected boolean hasExtendedLevels;
    protected World worldObj;

    public ChunkCache(World var1, BlockPos var2, BlockPos var3, int var4) {
        this.worldObj = var1;
        this.chunkX = var2.getX() - var4 >> 4;
        this.chunkZ = var2.getZ() - var4 >> 4;
        int i = var3.getX() + var4 >> 4;
        int j = var3.getZ() + var4 >> 4;
        this.chunkArray = new Chunk[i - this.chunkX + 1][j - this.chunkZ + 1];
        this.hasExtendedLevels = true;

        for (int k = this.chunkX; k <= i; k++) {
            for (int l = this.chunkZ; l <= j; l++) {
                this.chunkArray[k - this.chunkX][l - this.chunkZ] = var1.getChunkFromChunkCoords(k, l);
            }
        }

        for (int i1 = var2.getX() >> 4; i1 <= var3.getX() >> 4; i1++) {
            for (int j1 = var2.getZ() >> 4; j1 <= var3.getZ() >> 4; j1++) {
                Chunk chunk = this.chunkArray[i1 - this.chunkX][j1 - this.chunkZ];
                if (chunk != null && !chunk.getAreLevelsEmpty(var2.getY(), var3.getY())) {
                    this.hasExtendedLevels = false;
                }
            }
        }
    }

    @Override
    public boolean extendedLevelsInChunkCache() {
        return this.hasExtendedLevels;
    }

    @Override
    public TileEntity getTileEntity(BlockPos var1) {
        int i = (var1.getX() >> 4) - this.chunkX;
        int j = (var1.getZ() >> 4) - this.chunkZ;
        return this.chunkArray[i][j].getTileEntity(var1, Chunk.EnumCreateEntityType.IMMEDIATE);
    }

    @Override
    public int getCombinedLight(BlockPos var1, int var2) {
        int i = this.getLightForExt(EnumSkyBlock.SKY, var1);
        int j = this.getLightForExt(EnumSkyBlock.BLOCK, var1);
        if (j < var2) {
            j = var2;
        }

        return i << 20 | j << 4;
    }

    @Override
    public IBlockState getBlockState(BlockPos var1) {
        if (var1.getY() >= 0 && var1.getY() < 256) {
            int i = (var1.getX() >> 4) - this.chunkX;
            int j = (var1.getZ() >> 4) - this.chunkZ;
            if (i >= 0 && i < this.chunkArray.length && j >= 0 && j < this.chunkArray[i].length) {
                Chunk chunk = this.chunkArray[i][j];
                if (chunk != null) {
                    return chunk.getBlockState(var1);
                }
            }
        }

        return Blocks.air.getDefaultState();
    }

    @Override
    public BiomeGenBase getBiomeGenForCoords(BlockPos var1) {
        return this.worldObj.getBiomeGenForCoords(var1);
    }

    private int getLightForExt(EnumSkyBlock var1, BlockPos var2) {
        if (var1 == EnumSkyBlock.SKY && this.worldObj.provider.getHasNoSky()) {
            return 0;
        }

        if (var2.getY() >= 0 && var2.getY() < 256) {
            if (this.getBlockState(var2).getBlock().getUseNeighborBrightness()) {
                int l = 0;

                for (EnumFacing enumfacing : EnumFacing.values()) {
                    int k = this.getLightFor(var1, var2.offset(enumfacing));
                    if (k > l) {
                        l = k;
                    }

                    if (l >= 15) {
                        return l;
                    }
                }

                return l;
            } else {
                int i = (var2.getX() >> 4) - this.chunkX;
                int j = (var2.getZ() >> 4) - this.chunkZ;
                return this.chunkArray[i][j].getLightFor(var1, var2);
            }
        } else {
            return var1.defaultLightValue;
        }
    }

    @Override
    public boolean isAirBlock(BlockPos var1) {
        return this.getBlockState(var1).getBlock().getMaterial() == Material.air;
    }

    public int getLightFor(EnumSkyBlock var1, BlockPos var2) {
        if (var2.getY() >= 0 && var2.getY() < 256) {
            int i = (var2.getX() >> 4) - this.chunkX;
            int j = (var2.getZ() >> 4) - this.chunkZ;
            return this.chunkArray[i][j].getLightFor(var1, var2);
        } else {
            return var1.defaultLightValue;
        }
    }

    @Override
    public int getStrongPower(BlockPos var1, EnumFacing var2) {
        IBlockState iblockstate = this.getBlockState(var1);
        return iblockstate.getBlock().isProvidingStrongPower(this, var1, iblockstate, var2);
    }

    @Override
    public WorldType getWorldType() {
        return this.worldObj.getWorldType();
    }
}
