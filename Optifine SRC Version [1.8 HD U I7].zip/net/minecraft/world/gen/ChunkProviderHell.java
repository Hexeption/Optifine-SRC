package net.minecraft.world.gen;

import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockHelper;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.MathHelper;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenFire;
import net.minecraft.world.gen.feature.WorldGenGlowStone1;
import net.minecraft.world.gen.feature.WorldGenGlowStone2;
import net.minecraft.world.gen.feature.WorldGenHellLava;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraft.world.gen.structure.MapGenNetherBridge;

public class ChunkProviderHell implements IChunkProvider {
    private final World worldObj;
    private final boolean field_177466_i;
    private final Random hellRNG;
    private double[] slowsandNoise = new double[256];
    private double[] gravelNoise = new double[256];
    private double[] netherrackExclusivityNoise = new double[256];
    private double[] noiseField;
    private final NoiseGeneratorOctaves netherNoiseGen1;
    private final NoiseGeneratorOctaves netherNoiseGen2;
    private final NoiseGeneratorOctaves netherNoiseGen3;
    private final NoiseGeneratorOctaves slowsandGravelNoiseGen;
    private final NoiseGeneratorOctaves netherrackExculsivityNoiseGen;
    public final NoiseGeneratorOctaves netherNoiseGen6;
    public final NoiseGeneratorOctaves netherNoiseGen7;
    private final WorldGenFire field_177470_t = new WorldGenFire();
    private final WorldGenGlowStone1 field_177469_u = new WorldGenGlowStone1();
    private final WorldGenGlowStone2 field_177468_v = new WorldGenGlowStone2();
    private final WorldGenerator field_177467_w = new WorldGenMinable(Blocks.quartz_ore.getDefaultState(), 14, BlockHelper.forBlock(Blocks.netherrack));
    private final WorldGenHellLava field_177473_x = new WorldGenHellLava(Blocks.flowing_lava, true);
    private final WorldGenHellLava field_177472_y = new WorldGenHellLava(Blocks.flowing_lava, false);
    private final GeneratorBushFeature field_177471_z = new GeneratorBushFeature(Blocks.brown_mushroom);
    private final GeneratorBushFeature field_177465_A = new GeneratorBushFeature(Blocks.red_mushroom);
    private final MapGenNetherBridge genNetherBridge = new MapGenNetherBridge();
    private final MapGenBase netherCaveGenerator = new MapGenCavesHell();
    double[] noiseData1;
    double[] noiseData2;
    double[] noiseData3;
    double[] noiseData4;
    double[] noiseData5;

    public ChunkProviderHell(World var1, boolean var2, long var3) {
        this.worldObj = var1;
        this.field_177466_i = var2;
        this.hellRNG = new Random(var3);
        this.netherNoiseGen1 = new NoiseGeneratorOctaves(this.hellRNG, 16);
        this.netherNoiseGen2 = new NoiseGeneratorOctaves(this.hellRNG, 16);
        this.netherNoiseGen3 = new NoiseGeneratorOctaves(this.hellRNG, 8);
        this.slowsandGravelNoiseGen = new NoiseGeneratorOctaves(this.hellRNG, 4);
        this.netherrackExculsivityNoiseGen = new NoiseGeneratorOctaves(this.hellRNG, 4);
        this.netherNoiseGen6 = new NoiseGeneratorOctaves(this.hellRNG, 10);
        this.netherNoiseGen7 = new NoiseGeneratorOctaves(this.hellRNG, 16);
    }

    public void func_180515_a(int var1, int var2, ChunkPrimer var3) {
        byte b0 = 4;
        byte b1 = 32;
        int i = b0 + 1;
        byte b2 = 17;
        int j = b0 + 1;
        this.noiseField = this.initializeNoiseField(this.noiseField, var1 * b0, 0, var2 * b0, i, b2, j);

        for (int k = 0; k < b0; k++) {
            for (int l = 0; l < b0; l++) {
                for (int i1 = 0; i1 < 16; i1++) {
                    double d0 = 0.125;
                    double d1 = this.noiseField[((k + 0) * j + l + 0) * b2 + i1 + 0];
                    double d2 = this.noiseField[((k + 0) * j + l + 1) * b2 + i1 + 0];
                    double d3 = this.noiseField[((k + 1) * j + l + 0) * b2 + i1 + 0];
                    double d4 = this.noiseField[((k + 1) * j + l + 1) * b2 + i1 + 0];
                    double d5 = (this.noiseField[((k + 0) * j + l + 0) * b2 + i1 + 1] - d1) * d0;
                    double d6 = (this.noiseField[((k + 0) * j + l + 1) * b2 + i1 + 1] - d2) * d0;
                    double d7 = (this.noiseField[((k + 1) * j + l + 0) * b2 + i1 + 1] - d3) * d0;
                    double d8 = (this.noiseField[((k + 1) * j + l + 1) * b2 + i1 + 1] - d4) * d0;

                    for (int j1 = 0; j1 < 8; j1++) {
                        double d9 = 0.25;
                        double d10 = d1;
                        double d11 = d2;
                        double d12 = (d3 - d1) * d9;
                        double d13 = (d4 - d2) * d9;

                        for (int k1 = 0; k1 < 4; k1++) {
                            double d14 = 0.25;
                            double d15 = d10;
                            double d16 = (d11 - d10) * d14;

                            for (int l1 = 0; l1 < 4; l1++) {
                                IBlockState iblockstate = null;
                                if (i1 * 8 + j1 < b1) {
                                    iblockstate = Blocks.lava.getDefaultState();
                                }

                                if (d15 > 0.0) {
                                    iblockstate = Blocks.netherrack.getDefaultState();
                                }

                                int i2 = k1 + k * 4;
                                int j2 = j1 + i1 * 8;
                                int k2 = l1 + l * 4;
                                var3.setBlockState(i2, j2, k2, iblockstate);
                                d15 += d16;
                            }

                            d10 += d12;
                            d11 += d13;
                        }

                        d1 += d5;
                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                    }
                }
            }
        }
    }

    public void func_180516_b(int var1, int var2, ChunkPrimer var3) {
        byte b0 = 64;
        double d0 = 1.0 / 32.0;
        this.slowsandNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.slowsandNoise, var1 * 16, var2 * 16, 0, 16, 16, 1, d0, d0, 1.0);
        this.gravelNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.gravelNoise, var1 * 16, 109, var2 * 16, 16, 1, 16, d0, 1.0, d0);
        this.netherrackExclusivityNoise = this.netherrackExculsivityNoiseGen
            .generateNoiseOctaves(this.netherrackExclusivityNoise, var1 * 16, var2 * 16, 0, 16, 16, 1, d0 * 2.0, d0 * 2.0, d0 * 2.0);

        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                boolean flag = this.slowsandNoise[i + j * 16] + this.hellRNG.nextDouble() * 0.2 > 0.0;
                boolean flag1 = this.gravelNoise[i + j * 16] + this.hellRNG.nextDouble() * 0.2 > 0.0;
                int k = (int)(this.netherrackExclusivityNoise[i + j * 16] / 3.0 + 3.0 + this.hellRNG.nextDouble() * 0.25);
                int l = -1;
                IBlockState iblockstate = Blocks.netherrack.getDefaultState();
                IBlockState iblockstate1 = Blocks.netherrack.getDefaultState();

                for (int i1 = 127; i1 >= 0; i1--) {
                    if (i1 < 127 - this.hellRNG.nextInt(5) && i1 > this.hellRNG.nextInt(5)) {
                        IBlockState iblockstate2 = var3.getBlockState(j, i1, i);
                        if (iblockstate2.getBlock() == null || iblockstate2.getBlock().getMaterial() == Material.air) {
                            l = -1;
                        } else if (iblockstate2.getBlock() == Blocks.netherrack) {
                            if (l == -1) {
                                if (k <= 0) {
                                    iblockstate = null;
                                    iblockstate1 = Blocks.netherrack.getDefaultState();
                                } else if (i1 >= b0 - 4 && i1 <= b0 + 1) {
                                    iblockstate = Blocks.netherrack.getDefaultState();
                                    iblockstate1 = Blocks.netherrack.getDefaultState();
                                    if (flag1) {
                                        iblockstate = Blocks.gravel.getDefaultState();
                                        iblockstate1 = Blocks.netherrack.getDefaultState();
                                    }

                                    if (flag) {
                                        iblockstate = Blocks.soul_sand.getDefaultState();
                                        iblockstate1 = Blocks.soul_sand.getDefaultState();
                                    }
                                }

                                if (i1 < b0 && (iblockstate == null || iblockstate.getBlock().getMaterial() == Material.air)) {
                                    iblockstate = Blocks.lava.getDefaultState();
                                }

                                l = k;
                                if (i1 >= b0 - 1) {
                                    var3.setBlockState(j, i1, i, iblockstate);
                                } else {
                                    var3.setBlockState(j, i1, i, iblockstate1);
                                }
                            } else if (l > 0) {
                                l--;
                                var3.setBlockState(j, i1, i, iblockstate1);
                            }
                        }
                    } else {
                        var3.setBlockState(j, i1, i, Blocks.bedrock.getDefaultState());
                    }
                }
            }
        }
    }

    @Override
    public Chunk provideChunk(int var1, int var2) {
        this.hellRNG.setSeed(var1 * 341873128712L + var2 * 132897987541L);
        ChunkPrimer chunkprimer = new ChunkPrimer();
        this.func_180515_a(var1, var2, chunkprimer);
        this.func_180516_b(var1, var2, chunkprimer);
        this.netherCaveGenerator.generate(this, this.worldObj, var1, var2, chunkprimer);
        if (this.field_177466_i) {
            this.genNetherBridge.generate(this, this.worldObj, var1, var2, chunkprimer);
        }

        Chunk chunk = new Chunk(this.worldObj, chunkprimer, var1, var2);
        BiomeGenBase[] abiomegenbase = this.worldObj.getWorldChunkManager().loadBlockGeneratorData(null, var1 * 16, var2 * 16, 16, 16);
        byte[] abyte = chunk.getBiomeArray();

        for (int i = 0; i < abyte.length; i++) {
            abyte[i] = (byte)abiomegenbase[i].biomeID;
        }

        chunk.resetRelightChecks();
        return chunk;
    }

    private double[] initializeNoiseField(double[] var1, int var2, int var3, int var4, int var5, int var6, int var7) {
        if (var1 == null) {
            var1 = new double[var5 * var6 * var7];
        }

        double d0 = 684.412;
        double d1 = 2053.236;
        this.noiseData4 = this.netherNoiseGen6.generateNoiseOctaves(this.noiseData4, var2, var3, var4, var5, 1, var7, 1.0, 0.0, 1.0);
        this.noiseData5 = this.netherNoiseGen7.generateNoiseOctaves(this.noiseData5, var2, var3, var4, var5, 1, var7, 100.0, 0.0, 100.0);
        this.noiseData1 = this.netherNoiseGen3.generateNoiseOctaves(this.noiseData1, var2, var3, var4, var5, var6, var7, d0 / 80.0, d1 / 60.0, d0 / 80.0);
        this.noiseData2 = this.netherNoiseGen1.generateNoiseOctaves(this.noiseData2, var2, var3, var4, var5, var6, var7, d0, d1, d0);
        this.noiseData3 = this.netherNoiseGen2.generateNoiseOctaves(this.noiseData3, var2, var3, var4, var5, var6, var7, d0, d1, d0);
        int i = 0;
        double[] adouble = new double[var6];

        for (int j = 0; j < var6; j++) {
            adouble[j] = Math.cos(j * Math.PI * 6.0 / var6) * 2.0;
            double d2 = j;
            if (j > var6 / 2) {
                d2 = var6 - 1 - j;
            }

            if (d2 < 4.0) {
                d2 = 4.0 - d2;
                adouble[j] -= d2 * d2 * d2 * 10.0;
            }
        }

        for (int l = 0; l < var5; l++) {
            for (int i1 = 0; i1 < var7; i1++) {
                double d3 = 0.0;

                for (int k = 0; k < var6; k++) {
                    double d4 = 0.0;
                    double d5 = adouble[k];
                    double d6 = this.noiseData2[i] / 512.0;
                    double d7 = this.noiseData3[i] / 512.0;
                    double d8 = (this.noiseData1[i] / 10.0 + 1.0) / 2.0;
                    if (d8 < 0.0) {
                        d4 = d6;
                    } else if (d8 > 1.0) {
                        d4 = d7;
                    } else {
                        d4 = d6 + (d7 - d6) * d8;
                    }

                    d4 -= d5;
                    if (k > var6 - 4) {
                        double d9 = (k - (var6 - 4)) / 3.0F;
                        d4 = d4 * (1.0 - d9) + -10.0 * d9;
                    }

                    if (k < d3) {
                        double d10 = (d3 - k) / 4.0;
                        d10 = MathHelper.clamp_double(d10, 0.0, 1.0);
                        d4 = d4 * (1.0 - d10) + -10.0 * d10;
                    }

                    var1[i] = d4;
                    i++;
                }
            }
        }

        return var1;
    }

    @Override
    public boolean chunkExists(int var1, int var2) {
        return true;
    }

    @Override
    public void populate(IChunkProvider var1, int var2, int var3) {
        BlockFalling.fallInstantly = true;
        BlockPos blockpos = new BlockPos(var2 * 16, 0, var3 * 16);
        ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(var2, var3);
        this.genNetherBridge.generateStructure(this.worldObj, this.hellRNG, chunkcoordintpair);

        for (int i = 0; i < 8; i++) {
            this.field_177472_y
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16) + 8, this.hellRNG.nextInt(120) + 4, this.hellRNG.nextInt(16) + 8));
        }

        for (int j = 0; j < this.hellRNG.nextInt(this.hellRNG.nextInt(10) + 1) + 1; j++) {
            this.field_177470_t
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16) + 8, this.hellRNG.nextInt(120) + 4, this.hellRNG.nextInt(16) + 8));
        }

        for (int k = 0; k < this.hellRNG.nextInt(this.hellRNG.nextInt(10) + 1); k++) {
            this.field_177469_u
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16) + 8, this.hellRNG.nextInt(120) + 4, this.hellRNG.nextInt(16) + 8));
        }

        for (int l = 0; l < 10; l++) {
            this.field_177468_v
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16) + 8, this.hellRNG.nextInt(128), this.hellRNG.nextInt(16) + 8));
        }

        if (this.hellRNG.nextBoolean()) {
            this.field_177471_z
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16) + 8, this.hellRNG.nextInt(128), this.hellRNG.nextInt(16) + 8));
        }

        if (this.hellRNG.nextBoolean()) {
            this.field_177465_A
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16) + 8, this.hellRNG.nextInt(128), this.hellRNG.nextInt(16) + 8));
        }

        for (int i1 = 0; i1 < 16; i1++) {
            this.field_177467_w
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16), this.hellRNG.nextInt(108) + 10, this.hellRNG.nextInt(16)));
        }

        for (int j1 = 0; j1 < 16; j1++) {
            this.field_177473_x
                .generate(this.worldObj, this.hellRNG, blockpos.add(this.hellRNG.nextInt(16), this.hellRNG.nextInt(108) + 10, this.hellRNG.nextInt(16)));
        }

        BlockFalling.fallInstantly = false;
    }

    @Override
    public boolean func_177460_a(IChunkProvider var1, Chunk var2, int var3, int var4) {
        return false;
    }

    @Override
    public boolean saveChunks(boolean var1, IProgressUpdate var2) {
        return true;
    }

    @Override
    public void saveExtraData() {
    }

    @Override
    public boolean unloadQueuedChunks() {
        return false;
    }

    @Override
    public boolean canSave() {
        return true;
    }

    @Override
    public String makeString() {
        return "HellRandomLevelSource";
    }

    @Override
    public List getPossibleCreatures(EnumCreatureType var1, BlockPos var2) {
        if (var1 == EnumCreatureType.MONSTER) {
            if (this.genNetherBridge.func_175795_b(var2)) {
                return this.genNetherBridge.getSpawnList();
            }

            if (this.genNetherBridge.func_175796_a(this.worldObj, var2) && this.worldObj.getBlockState(var2.down()).getBlock() == Blocks.nether_brick) {
                return this.genNetherBridge.getSpawnList();
            }
        }

        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(var2);
        return biomegenbase.getSpawnableList(var1);
    }

    @Override
    public BlockPos getStrongholdGen(World var1, String var2, BlockPos var3) {
        return null;
    }

    @Override
    public int getLoadedChunkCount() {
        return 0;
    }

    @Override
    public void recreateStructures(Chunk var1, int var2, int var3) {
        this.genNetherBridge.generate(this, this.worldObj, var2, var3, null);
    }

    @Override
    public Chunk provideChunk(BlockPos var1) {
        return this.provideChunk(var1.getX() >> 4, var1.getZ() >> 4);
    }
}
