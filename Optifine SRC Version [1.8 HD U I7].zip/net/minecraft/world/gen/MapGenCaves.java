package net.minecraft.world.gen;

import com.google.common.base.Objects;
import java.util.Random;
import net.minecraft.block.BlockSand;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkPrimer;

public class MapGenCaves extends MapGenBase {
    protected void func_180703_a(long var1, int var3, int var4, ChunkPrimer var5, double var6, double var8, double var10) {
        this.func_180702_a(var1, var3, var4, var5, var6, var8, var10, 1.0F + this.rand.nextFloat() * 6.0F, 0.0F, 0.0F, -1, -1, 0.5);
    }

    protected void func_180702_a(
        long var1,
        int var3,
        int var4,
        ChunkPrimer var5,
        double var6,
        double var8,
        double var10,
        float var12,
        float var13,
        float var14,
        int var15,
        int var16,
        double var17
    ) {
        double d0 = var3 * 16 + 8;
        double d1 = var4 * 16 + 8;
        float f = 0.0F;
        float f1 = 0.0F;
        Random random = new Random(var1);
        if (var16 <= 0) {
            int i = this.range * 16 - 16;
            var16 = i - random.nextInt(i / 4);
        }

        boolean flag2 = false;
        if (var15 == -1) {
            var15 = var16 / 2;
            flag2 = true;
        }

        int j = random.nextInt(var16 / 2) + var16 / 4;
        boolean flag = random.nextInt(6) == 0;

        while (var15 < var16) {
            double d2 = 1.5 + MathHelper.sin(var15 * (float)Math.PI / var16) * var12 * 1.0F;
            double d3 = d2 * var17;
            float f2 = MathHelper.cos(var14);
            float f3 = MathHelper.sin(var14);
            var6 += MathHelper.cos(var13) * f2;
            var8 += f3;
            var10 += MathHelper.sin(var13) * f2;
            if (flag) {
                var14 *= 0.92F;
            } else {
                var14 *= 0.7F;
            }

            var14 += f1 * 0.1F;
            var13 += f * 0.1F;
            f1 *= 0.9F;
            f *= 12.0F / 16.0F;
            f1 += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 2.0F;
            f += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 4.0F;
            if (!flag2 && var15 == j && var12 > 1.0F && var16 > 0) {
                this.func_180702_a(
                    random.nextLong(),
                    var3,
                    var4,
                    var5,
                    var6,
                    var8,
                    var10,
                    random.nextFloat() * 0.5F + 0.5F,
                    var13 - (float)Math.PI * 0.5F,
                    var14 / 3.0F,
                    var15,
                    var16,
                    1.0
                );
                this.func_180702_a(
                    random.nextLong(),
                    var3,
                    var4,
                    var5,
                    var6,
                    var8,
                    var10,
                    random.nextFloat() * 0.5F + 0.5F,
                    var13 + (float)Math.PI * 0.5F,
                    var14 / 3.0F,
                    var15,
                    var16,
                    1.0
                );
                return;
            }

            if (flag2 || random.nextInt(4) != 0) {
                double d4 = var6 - d0;
                double d5 = var10 - d1;
                double d6 = var16 - var15;
                double d7 = var12 + 2.0F + 16.0F;
                if (d4 * d4 + d5 * d5 - d6 * d6 > d7 * d7) {
                    return;
                }

                if (!(var6 < d0 - 16.0 - d2 * 2.0) && !(var10 < d1 - 16.0 - d2 * 2.0) && !(var6 > d0 + 16.0 + d2 * 2.0) && !(var10 > d1 + 16.0 + d2 * 2.0)) {
                    int j2 = MathHelper.floor_double(var6 - d2) - var3 * 16 - 1;
                    int k = MathHelper.floor_double(var6 + d2) - var3 * 16 + 1;
                    int k2 = MathHelper.floor_double(var8 - d3) - 1;
                    int l = MathHelper.floor_double(var8 + d3) + 1;
                    int l2 = MathHelper.floor_double(var10 - d2) - var4 * 16 - 1;
                    int i1 = MathHelper.floor_double(var10 + d2) - var4 * 16 + 1;
                    if (j2 < 0) {
                        j2 = 0;
                    }

                    if (k > 16) {
                        k = 16;
                    }

                    if (k2 < 1) {
                        k2 = 1;
                    }

                    if (l > 248) {
                        l = 248;
                    }

                    if (l2 < 0) {
                        l2 = 0;
                    }

                    if (i1 > 16) {
                        i1 = 16;
                    }

                    boolean flag3 = false;

                    for (int j1 = j2; !flag3 && j1 < k; j1++) {
                        for (int k1 = l2; !flag3 && k1 < i1; k1++) {
                            for (int l1 = l + 1; !flag3 && l1 >= k2 - 1; l1--) {
                                if (l1 >= 0 && l1 < 256) {
                                    IBlockState iblockstate = var5.getBlockState(j1, l1, k1);
                                    if (iblockstate.getBlock() == Blocks.flowing_water || iblockstate.getBlock() == Blocks.water) {
                                        flag3 = true;
                                    }

                                    if (l1 != k2 - 1 && j1 != j2 && j1 != k - 1 && k1 != l2 && k1 != i1 - 1) {
                                        l1 = k2;
                                    }
                                }
                            }
                        }
                    }

                    if (!flag3) {
                        for (int i3 = j2; i3 < k; i3++) {
                            double d10 = (i3 + var3 * 16 + 0.5 - var6) / d2;

                            for (int j3 = l2; j3 < i1; j3++) {
                                double d8 = (j3 + var4 * 16 + 0.5 - var10) / d2;
                                boolean flag1 = false;
                                if (d10 * d10 + d8 * d8 < 1.0) {
                                    for (int i2 = l; i2 > k2; i2--) {
                                        double d9 = (i2 - 1 + 0.5 - var8) / d3;
                                        if (d9 > -0.7 && d10 * d10 + d9 * d9 + d8 * d8 < 1.0) {
                                            IBlockState iblockstate1 = var5.getBlockState(i3, i2, j3);
                                            IBlockState iblockstate2 = Objects.firstNonNull(var5.getBlockState(i3, i2 + 1, j3), Blocks.air.getDefaultState());
                                            if (iblockstate1.getBlock() == Blocks.grass || iblockstate1.getBlock() == Blocks.mycelium) {
                                                flag1 = true;
                                            }

                                            if (this.func_175793_a(iblockstate1, iblockstate2)) {
                                                if (i2 - 1 < 10) {
                                                    var5.setBlockState(i3, i2, j3, Blocks.lava.getDefaultState());
                                                } else {
                                                    var5.setBlockState(i3, i2, j3, Blocks.air.getDefaultState());
                                                    if (iblockstate2.getBlock() == Blocks.sand) {
                                                        var5.setBlockState(
                                                            i3,
                                                            i2 + 1,
                                                            j3,
                                                            iblockstate2.getValue(BlockSand.VARIANT) == BlockSand.EnumType.RED_SAND
                                                                ? Blocks.red_sandstone.getDefaultState()
                                                                : Blocks.sandstone.getDefaultState()
                                                        );
                                                    }

                                                    if (flag1 && var5.getBlockState(i3, i2 - 1, j3).getBlock() == Blocks.dirt) {
                                                        var5.setBlockState(
                                                            i3,
                                                            i2 - 1,
                                                            j3,
                                                            this.worldObj
                                                                .getBiomeGenForCoords(new BlockPos(i3 + var3 * 16, 0, j3 + var4 * 16))
                                                                .topBlock
                                                                .getBlock()
                                                                .getDefaultState()
                                                        );
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (flag2) {
                            break;
                        }
                    }
                }
            }

            var15++;
        }
    }

    protected boolean func_175793_a(IBlockState var1, IBlockState var2) {
        if (var1.getBlock() == Blocks.stone) {
            return true;
        } else if (var1.getBlock() == Blocks.dirt) {
            return true;
        } else if (var1.getBlock() == Blocks.grass) {
            return true;
        } else if (var1.getBlock() == Blocks.hardened_clay) {
            return true;
        } else if (var1.getBlock() == Blocks.stained_hardened_clay) {
            return true;
        } else if (var1.getBlock() == Blocks.sandstone) {
            return true;
        } else if (var1.getBlock() == Blocks.red_sandstone) {
            return true;
        } else if (var1.getBlock() == Blocks.mycelium) {
            return true;
        } else {
            return var1.getBlock() == Blocks.snow_layer
                ? true
                : (var1.getBlock() == Blocks.sand || var1.getBlock() == Blocks.gravel) && var2.getBlock().getMaterial() != Material.water;
        }
    }

    @Override
    protected void recursiveGenerate(World var1, int var2, int var3, int var4, int var5, ChunkPrimer var6) {
        int i = this.rand.nextInt(this.rand.nextInt(this.rand.nextInt(15) + 1) + 1);
        if (this.rand.nextInt(7) != 0) {
            i = 0;
        }

        for (int j = 0; j < i; j++) {
            double d0 = var2 * 16 + this.rand.nextInt(16);
            double d1 = this.rand.nextInt(this.rand.nextInt(120) + 8);
            double d2 = var3 * 16 + this.rand.nextInt(16);
            int k = 1;
            if (this.rand.nextInt(4) == 0) {
                this.func_180703_a(this.rand.nextLong(), var4, var5, var6, d0, d1, d2);
                k += this.rand.nextInt(4);
            }

            for (int l = 0; l < k; l++) {
                float f = this.rand.nextFloat() * (float)Math.PI * 2.0F;
                float f1 = (this.rand.nextFloat() - 0.5F) * 2.0F / 8.0F;
                float f2 = this.rand.nextFloat() * 2.0F + this.rand.nextFloat();
                if (this.rand.nextInt(10) == 0) {
                    f2 *= this.rand.nextFloat() * this.rand.nextFloat() * 3.0F + 1.0F;
                }

                this.func_180702_a(this.rand.nextLong(), var4, var5, var6, d0, d1, d2, f2, f, f1, 0, 0, 1.0);
            }
        }
    }
}
