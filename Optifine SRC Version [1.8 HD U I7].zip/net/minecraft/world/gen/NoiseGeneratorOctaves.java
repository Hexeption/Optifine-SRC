package net.minecraft.world.gen;

import java.util.Random;
import net.minecraft.util.MathHelper;

public class NoiseGeneratorOctaves extends NoiseGenerator {
    private NoiseGeneratorImproved[] generatorCollection;
    private int octaves;

    public NoiseGeneratorOctaves(Random var1, int var2) {
        this.octaves = var2;
        this.generatorCollection = new NoiseGeneratorImproved[var2];

        for (int i = 0; i < var2; i++) {
            this.generatorCollection[i] = new NoiseGeneratorImproved(var1);
        }
    }

    public double[] generateNoiseOctaves(double[] var1, int var2, int var3, int var4, int var5, int var6, int var7, double var8, double var10, double var12) {
        if (var1 == null) {
            var1 = new double[var5 * var6 * var7];
        } else {
            for (int i = 0; i < var1.length; i++) {
                var1[i] = 0.0;
            }
        }

        double d3 = 1.0;

        for (int j = 0; j < this.octaves; j++) {
            double d0 = var2 * d3 * var8;
            double d1 = var3 * d3 * var10;
            double d2 = var4 * d3 * var12;
            long k = MathHelper.floor_double_long(d0);
            long l = MathHelper.floor_double_long(d2);
            d0 -= k;
            d2 -= l;
            k %= 16777216L;
            l %= 16777216L;
            d0 += k;
            d2 += l;
            this.generatorCollection[j].populateNoiseArray(var1, d0, d1, d2, var5, var6, var7, var8 * d3, var10 * d3, var12 * d3, d3);
            d3 /= 2.0;
        }

        return var1;
    }

    public double[] generateNoiseOctaves(double[] var1, int var2, int var3, int var4, int var5, double var6, double var8, double var10) {
        return this.generateNoiseOctaves(var1, var2, 10, var3, var4, 1, var5, var6, 1.0, var8);
    }
}
