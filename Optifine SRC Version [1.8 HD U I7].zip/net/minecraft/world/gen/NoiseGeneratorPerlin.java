package net.minecraft.world.gen;

import java.util.Random;

public class NoiseGeneratorPerlin extends NoiseGenerator {
    private NoiseGeneratorSimplex[] field_151603_a;
    private int field_151602_b;

    public NoiseGeneratorPerlin(Random var1, int var2) {
        this.field_151602_b = var2;
        this.field_151603_a = new NoiseGeneratorSimplex[var2];

        for (int i = 0; i < var2; i++) {
            this.field_151603_a[i] = new NoiseGeneratorSimplex(var1);
        }
    }

    public double func_151601_a(double var1, double var3) {
        double d0 = 0.0;
        double d1 = 1.0;

        for (int i = 0; i < this.field_151602_b; i++) {
            d0 += this.field_151603_a[i].func_151605_a(var1 * d1, var3 * d1) / d1;
            d1 /= 2.0;
        }

        return d0;
    }

    public double[] func_151599_a(double[] var1, double var2, double var4, int var6, int var7, double var8, double var10, double var12) {
        return this.func_151600_a(var1, var2, var4, var6, var7, var8, var10, var12, 0.5);
    }

    public double[] func_151600_a(double[] var1, double var2, double var4, int var6, int var7, double var8, double var10, double var12, double var14) {
        if (var1 != null && var1.length >= var6 * var7) {
            for (int i = 0; i < var1.length; i++) {
                var1[i] = 0.0;
            }
        } else {
            var1 = new double[var6 * var7];
        }

        double d1 = 1.0;
        double d0 = 1.0;

        for (int j = 0; j < this.field_151602_b; j++) {
            this.field_151603_a[j].func_151606_a(var1, var2, var4, var6, var7, var8 * d0 * d1, var10 * d0 * d1, 0.55 / d1);
            d0 *= var12;
            d1 *= var14;
        }

        return var1;
    }
}
