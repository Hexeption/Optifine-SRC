package net.minecraft.world;

import net.minecraft.util.MathHelper;

public class DifficultyInstance {
    private final EnumDifficulty worldDifficulty;
    private final float additionalDifficulty;

    public DifficultyInstance(EnumDifficulty var1, long var2, long var4, float var6) {
        this.worldDifficulty = var1;
        this.additionalDifficulty = this.calculateAdditionalDifficulty(var1, var2, var4, var6);
    }

    public float getAdditionalDifficulty() {
        return this.additionalDifficulty;
    }

    public float getClampedAdditionalDifficulty() {
        if (this.additionalDifficulty < 2.0F) {
            return 0.0F;
        } else {
            return this.additionalDifficulty > 4.0F ? 1.0F : (this.additionalDifficulty - 2.0F) / 2.0F;
        }
    }

    private float calculateAdditionalDifficulty(EnumDifficulty var1, long var2, long var4, float var6) {
        if (var1 == EnumDifficulty.PEACEFUL) {
            return 0.0F;
        }

        boolean flag = var1 == EnumDifficulty.HARD;
        float f = 12.0F / 16.0F;
        float f1 = MathHelper.clamp_float(((float)var2 + -72000.0F) / 1440000.0F, 0.0F, 1.0F) * 0.25F;
        f += f1;
        float f2 = 0.0F;
        f2 += MathHelper.clamp_float((float)var4 / 3600000.0F, 0.0F, 1.0F) * (flag ? 1.0F : 12.0F / 16.0F);
        f2 += MathHelper.clamp_float(var6 * 0.25F, 0.0F, f1);
        if (var1 == EnumDifficulty.EASY) {
            f2 *= 0.5F;
        }

        f += f2;
        return var1.getDifficultyId() * f;
    }
}
