package net.minecraft.world;

public class ColorizerFoliage {
    private static int[] foliageBuffer = new int[65536];

    public static void setFoliageBiomeColorizer(int[] var0) {
        foliageBuffer = var0;
    }

    public static int getFoliageColor(double var0, double var2) {
        var2 *= var0;
        int i = (int)((1.0 - var0) * 255.0);
        int j = (int)((1.0 - var2) * 255.0);
        return foliageBuffer[j << 8 | i];
    }

    public static int getFoliageColorPine() {
        return 6396257;
    }

    public static int getFoliageColorBirch() {
        return 8431445;
    }

    public static int getFoliageColorBasic() {
        return 4764952;
    }
}
