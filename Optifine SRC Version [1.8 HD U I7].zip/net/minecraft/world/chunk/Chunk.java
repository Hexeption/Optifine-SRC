package net.minecraft.world.chunk;

import com.google.common.base.Predicate;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ClassInheritanceMultiMap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import net.minecraft.world.gen.ChunkProviderDebug;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Chunk {
    private static final Logger logger = LogManager.getLogger();
    private final ExtendedBlockStorage[] storageArrays = new ExtendedBlockStorage[16];
    private final byte[] blockBiomeArray = new byte[256];
    private final int[] precipitationHeightMap = new int[256];
    private final boolean[] updateSkylightColumns = new boolean[256];
    private boolean isChunkLoaded;
    private final World worldObj;
    private final int[] heightMap;
    public final int xPosition;
    public final int zPosition;
    private boolean isGapLightingUpdated;
    private final Map chunkTileEntityMap = Maps.newHashMap();
    private final ClassInheritanceMultiMap[] entityLists;
    private boolean isTerrainPopulated;
    private boolean isLightPopulated;
    private boolean field_150815_m;
    private boolean isModified;
    private boolean hasEntities;
    private long lastSaveTime;
    private int heightMapMinimum;
    private long inhabitedTime;
    private int queuedLightChecks = 4096;
    private ConcurrentLinkedQueue tileEntityPosQueue = Queues.newConcurrentLinkedQueue();

    public Chunk(World var1, int var2, int var3) {
        this.entityLists = new ClassInheritanceMultiMap[16];
        this.worldObj = var1;
        this.xPosition = var2;
        this.zPosition = var3;
        this.heightMap = new int[256];

        for (int i = 0; i < this.entityLists.length; i++) {
            this.entityLists[i] = new ClassInheritanceMultiMap(Entity.class);
        }

        Arrays.fill(this.precipitationHeightMap, -999);
        Arrays.fill(this.blockBiomeArray, (byte)-1);
    }

    public Chunk(World var1, ChunkPrimer var2, int var3, int var4) {
        this(var1, var3, var4);
        short short1 = 256;
        boolean flag = !var1.provider.getHasNoSky();

        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                for (int k = 0; k < short1; k++) {
                    int l = i * short1 * 16 | j * short1 | k;
                    IBlockState iblockstate = var2.getBlockState(l);
                    if (iblockstate.getBlock().getMaterial() != Material.air) {
                        int i1 = k >> 4;
                        if (this.storageArrays[i1] == null) {
                            this.storageArrays[i1] = new ExtendedBlockStorage(i1 << 4, flag);
                        }

                        this.storageArrays[i1].set(i, k & 15, j, iblockstate);
                    }
                }
            }
        }
    }

    public boolean isAtLocation(int var1, int var2) {
        return var1 == this.xPosition && var2 == this.zPosition;
    }

    public int getHeight(BlockPos var1) {
        return this.getHeightValue(var1.getX() & 15, var1.getZ() & 15);
    }

    public int getHeightValue(int var1, int var2) {
        return this.heightMap[var2 << 4 | var1];
    }

    public int getTopFilledSegment() {
        for (int i = this.storageArrays.length - 1; i >= 0; i--) {
            if (this.storageArrays[i] != null) {
                return this.storageArrays[i].getYLocation();
            }
        }

        return 0;
    }

    public ExtendedBlockStorage[] getBlockStorageArray() {
        return this.storageArrays;
    }

    protected void generateHeightMap() {
        int i = this.getTopFilledSegment();
        this.heightMapMinimum = Integer.MAX_VALUE;

        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                this.precipitationHeightMap[j + (k << 4)] = -999;

                for (int l = i + 16; l > 0; l--) {
                    Block block = this.getBlock0(j, l - 1, k);
                    if (block.getLightOpacity() != 0) {
                        this.heightMap[k << 4 | j] = l;
                        if (l < this.heightMapMinimum) {
                            this.heightMapMinimum = l;
                        }
                        break;
                    }
                }
            }
        }

        this.isModified = true;
    }

    public void generateSkylightMap() {
        int i = this.getTopFilledSegment();
        this.heightMapMinimum = Integer.MAX_VALUE;

        for (int j = 0; j < 16; j++) {
            for (int k = 0; k < 16; k++) {
                this.precipitationHeightMap[j + (k << 4)] = -999;

                for (int l = i + 16; l > 0; l--) {
                    if (this.getBlockLightOpacity(j, l - 1, k) != 0) {
                        this.heightMap[k << 4 | j] = l;
                        if (l < this.heightMapMinimum) {
                            this.heightMapMinimum = l;
                        }
                        break;
                    }
                }

                if (!this.worldObj.provider.getHasNoSky()) {
                    int k1 = 15;
                    int i1 = i + 16 - 1;

                    while (true) {
                        int j1 = this.getBlockLightOpacity(j, i1, k);
                        if (j1 == 0 && k1 != 15) {
                            j1 = 1;
                        }

                        k1 -= j1;
                        if (k1 > 0) {
                            ExtendedBlockStorage extendedblockstorage = this.storageArrays[i1 >> 4];
                            if (extendedblockstorage != null) {
                                extendedblockstorage.setExtSkylightValue(j, i1 & 15, k, k1);
                                this.worldObj.notifyLightSet(new BlockPos((this.xPosition << 4) + j, i1, (this.zPosition << 4) + k));
                            }
                        }

                        if (--i1 <= 0 || k1 <= 0) {
                            break;
                        }
                    }
                }
            }
        }

        this.isModified = true;
    }

    private void propagateSkylightOcclusion(int var1, int var2) {
        this.updateSkylightColumns[var1 + var2 * 16] = true;
        this.isGapLightingUpdated = true;
    }

    private void recheckGaps(boolean var1) {
        this.worldObj.theProfiler.startSection("recheckGaps");
        if (this.worldObj.isAreaLoaded(new BlockPos(this.xPosition * 16 + 8, 0, this.zPosition * 16 + 8), 16)) {
            for (int i = 0; i < 16; i++) {
                for (int j = 0; j < 16; j++) {
                    if (this.updateSkylightColumns[i + j * 16]) {
                        this.updateSkylightColumns[i + j * 16] = false;
                        int k = this.getHeightValue(i, j);
                        int l = this.xPosition * 16 + i;
                        int i1 = this.zPosition * 16 + j;
                        int j1 = Integer.MAX_VALUE;

                        for (EnumFacing enumfacing : (Iterable<EnumFacing>) (Iterable) EnumFacing.Plane.HORIZONTAL) {
                            j1 = Math.min(j1, this.worldObj.getChunksLowestHorizon(l + enumfacing.getFrontOffsetX(), i1 + enumfacing.getFrontOffsetZ()));
                        }

                        this.checkSkylightNeighborHeight(l, i1, j1);

                        for (EnumFacing enumfacing1 : (Iterable<EnumFacing>) (Iterable) EnumFacing.Plane.HORIZONTAL) {
                            this.checkSkylightNeighborHeight(l + enumfacing1.getFrontOffsetX(), i1 + enumfacing1.getFrontOffsetZ(), k);
                        }

                        if (var1) {
                            this.worldObj.theProfiler.endSection();
                            return;
                        }
                    }
                }
            }

            this.isGapLightingUpdated = false;
        }

        this.worldObj.theProfiler.endSection();
    }

    private void checkSkylightNeighborHeight(int var1, int var2, int var3) {
        int i = this.worldObj.getHeight(new BlockPos(var1, 0, var2)).getY();
        if (i > var3) {
            this.updateSkylightNeighborHeight(var1, var2, var3, i + 1);
        } else if (i < var3) {
            this.updateSkylightNeighborHeight(var1, var2, i, var3 + 1);
        }
    }

    private void updateSkylightNeighborHeight(int var1, int var2, int var3, int var4) {
        if (var4 > var3 && this.worldObj.isAreaLoaded(new BlockPos(var1, 0, var2), 16)) {
            for (int i = var3; i < var4; i++) {
                this.worldObj.checkLightFor(EnumSkyBlock.SKY, new BlockPos(var1, i, var2));
            }

            this.isModified = true;
        }
    }

    private void relightBlock(int var1, int var2, int var3) {
        int i = this.heightMap[var3 << 4 | var1] & 0xFF;
        int j = i;
        if (var2 > i) {
            j = var2;
        }

        while (j > 0 && this.getBlockLightOpacity(var1, j - 1, var3) == 0) {
            j--;
        }

        if (j != i) {
            this.worldObj.markBlocksDirtyVertical(var1 + this.xPosition * 16, var3 + this.zPosition * 16, j, i);
            this.heightMap[var3 << 4 | var1] = j;
            int k = this.xPosition * 16 + var1;
            int l = this.zPosition * 16 + var3;
            if (!this.worldObj.provider.getHasNoSky()) {
                if (j < i) {
                    for (int k1 = j; k1 < i; k1++) {
                        ExtendedBlockStorage extendedblockstorage2 = this.storageArrays[k1 >> 4];
                        if (extendedblockstorage2 != null) {
                            extendedblockstorage2.setExtSkylightValue(var1, k1 & 15, var3, 15);
                            this.worldObj.notifyLightSet(new BlockPos((this.xPosition << 4) + var1, k1, (this.zPosition << 4) + var3));
                        }
                    }
                } else {
                    for (int i1 = i; i1 < j; i1++) {
                        ExtendedBlockStorage extendedblockstorage = this.storageArrays[i1 >> 4];
                        if (extendedblockstorage != null) {
                            extendedblockstorage.setExtSkylightValue(var1, i1 & 15, var3, 0);
                            this.worldObj.notifyLightSet(new BlockPos((this.xPosition << 4) + var1, i1, (this.zPosition << 4) + var3));
                        }
                    }
                }

                int l1 = 15;

                while (j > 0 && l1 > 0) {
                    int j2 = this.getBlockLightOpacity(var1, --j, var3);
                    if (j2 == 0) {
                        j2 = 1;
                    }

                    l1 -= j2;
                    if (l1 < 0) {
                        l1 = 0;
                    }

                    ExtendedBlockStorage extendedblockstorage1 = this.storageArrays[j >> 4];
                    if (extendedblockstorage1 != null) {
                        extendedblockstorage1.setExtSkylightValue(var1, j & 15, var3, l1);
                    }
                }
            }

            int i2 = this.heightMap[var3 << 4 | var1];
            int k2 = i;
            int l2 = i2;
            if (l2 < k2) {
                int j1 = k2;
                k2 = l2;
                l2 = j1;
            }

            if (i2 < this.heightMapMinimum) {
                this.heightMapMinimum = i2;
            }

            if (!this.worldObj.provider.getHasNoSky()) {
                for (EnumFacing enumfacing : (Iterable<EnumFacing>) (Iterable) EnumFacing.Plane.HORIZONTAL) {
                    this.updateSkylightNeighborHeight(k + enumfacing.getFrontOffsetX(), l + enumfacing.getFrontOffsetZ(), k2, l2);
                }

                this.updateSkylightNeighborHeight(k, l, k2, l2);
            }

            this.isModified = true;
        }
    }

    public int getBlockLightOpacity(BlockPos var1) {
        return this.getBlock(var1).getLightOpacity();
    }

    private int getBlockLightOpacity(int var1, int var2, int var3) {
        return this.getBlock0(var1, var2, var3).getLightOpacity();
    }

    private Block getBlock0(int var1, int var2, int var3) {
        Block block = Blocks.air;
        if (var2 >= 0 && var2 >> 4 < this.storageArrays.length) {
            ExtendedBlockStorage extendedblockstorage = this.storageArrays[var2 >> 4];
            if (extendedblockstorage != null) {
                try {
                    block = extendedblockstorage.getBlockByExtId(var1, var2 & 15, var3);
                } catch (Throwable throwable) {
                    CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Getting block");
                    throw new ReportedException(crashreport);
                }
            }
        }

        return block;
    }

    public Block getBlock(final int var1, final int var2, final int var3) {
        try {
            return this.getBlock0(var1 & 15, var2, var3 & 15);
        } catch (ReportedException reportedexception) {
            CrashReportCategory crashreportcategory = reportedexception.getCrashReport().makeCategory("Block being got");
            crashreportcategory.addCrashSectionCallable("Location", new Callable() {
                public String call() {
                    return CrashReportCategory.getCoordinateInfo(new BlockPos(Chunk.this.xPosition * 16 + var1, var2, Chunk.this.zPosition * 16 + var3));
                }
            });
            throw reportedexception;
        }
    }

    public Block getBlock(final BlockPos var1) {
        try {
            return this.getBlock0(var1.getX() & 15, var1.getY(), var1.getZ() & 15);
        } catch (ReportedException reportedexception) {
            CrashReportCategory crashreportcategory = reportedexception.getCrashReport().makeCategory("Block being got");
            crashreportcategory.addCrashSectionCallable("Location", new Callable() {
                public String call() {
                    return CrashReportCategory.getCoordinateInfo(var1);
                }
            });
            throw reportedexception;
        }
    }

    public IBlockState getBlockState(final BlockPos var1) {
        if (this.worldObj.getWorldType() == WorldType.DEBUG_WORLD) {
            IBlockState iblockstate = null;
            if (var1.getY() == 60) {
                iblockstate = Blocks.barrier.getDefaultState();
            }

            if (var1.getY() == 70) {
                iblockstate = ChunkProviderDebug.func_177461_b(var1.getX(), var1.getZ());
            }

            return iblockstate == null ? Blocks.air.getDefaultState() : iblockstate;
        } else {
            try {
                if (var1.getY() >= 0 && var1.getY() >> 4 < this.storageArrays.length) {
                    ExtendedBlockStorage extendedblockstorage = this.storageArrays[var1.getY() >> 4];
                    if (extendedblockstorage != null) {
                        int j = var1.getX() & 15;
                        int k = var1.getY() & 15;
                        int i = var1.getZ() & 15;
                        return extendedblockstorage.get(j, k, i);
                    }
                }

                return Blocks.air.getDefaultState();
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Getting block state");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being got");
                crashreportcategory.addCrashSectionCallable("Location", new Callable() {
                    public String call() {
                        return CrashReportCategory.getCoordinateInfo(var1);
                    }
                });
                throw new ReportedException(crashreport);
            }
        }
    }

    private int getBlockMetadata(int var1, int var2, int var3) {
        if (var2 >> 4 >= this.storageArrays.length) {
            return 0;
        }

        ExtendedBlockStorage extendedblockstorage = this.storageArrays[var2 >> 4];
        return extendedblockstorage != null ? extendedblockstorage.getExtBlockMetadata(var1, var2 & 15, var3) : 0;
    }

    public int getBlockMetadata(BlockPos var1) {
        return this.getBlockMetadata(var1.getX() & 15, var1.getY(), var1.getZ() & 15);
    }

    public IBlockState setBlockState(BlockPos var1, IBlockState var2) {
        int i = var1.getX() & 15;
        int j = var1.getY();
        int k = var1.getZ() & 15;
        int l = k << 4 | i;
        if (j >= this.precipitationHeightMap[l] - 1) {
            this.precipitationHeightMap[l] = -999;
        }

        int i1 = this.heightMap[l];
        IBlockState iblockstate = this.getBlockState(var1);
        if (iblockstate == var2) {
            return null;
        }

        Block block = var2.getBlock();
        Block block1 = iblockstate.getBlock();
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[j >> 4];
        boolean flag = false;
        if (extendedblockstorage == null) {
            if (block == Blocks.air) {
                return null;
            }

            extendedblockstorage = this.storageArrays[j >> 4] = new ExtendedBlockStorage(j >> 4 << 4, !this.worldObj.provider.getHasNoSky());
            flag = j >= i1;
        }

        extendedblockstorage.set(i, j & 15, k, var2);
        if (block1 != block) {
            if (!this.worldObj.isRemote) {
                block1.breakBlock(this.worldObj, var1, iblockstate);
            } else if (block1 instanceof ITileEntityProvider) {
                this.worldObj.removeTileEntity(var1);
            }
        }

        if (extendedblockstorage.getBlockByExtId(i, j & 15, k) != block) {
            return null;
        }

        if (flag) {
            this.generateSkylightMap();
        } else {
            int j1 = block.getLightOpacity();
            int k1 = block1.getLightOpacity();
            if (j1 > 0) {
                if (j >= i1) {
                    this.relightBlock(i, j + 1, k);
                }
            } else if (j == i1 - 1) {
                this.relightBlock(i, j, k);
            }

            if (j1 != k1 && (j1 < k1 || this.getLightFor(EnumSkyBlock.SKY, var1) > 0 || this.getLightFor(EnumSkyBlock.BLOCK, var1) > 0)) {
                this.propagateSkylightOcclusion(i, k);
            }
        }

        if (block1 instanceof ITileEntityProvider) {
            TileEntity tileentity = this.getTileEntity(var1, Chunk.EnumCreateEntityType.CHECK);
            if (tileentity != null) {
                tileentity.updateContainingBlockInfo();
            }
        }

        if (!this.worldObj.isRemote && block1 != block) {
            block.onBlockAdded(this.worldObj, var1, var2);
        }

        if (block instanceof ITileEntityProvider) {
            TileEntity tileentity1 = this.getTileEntity(var1, Chunk.EnumCreateEntityType.CHECK);
            if (tileentity1 == null) {
                tileentity1 = ((ITileEntityProvider)block).createNewTileEntity(this.worldObj, block.getMetaFromState(var2));
                this.worldObj.setTileEntity(var1, tileentity1);
            }

            if (tileentity1 != null) {
                tileentity1.updateContainingBlockInfo();
            }
        }

        this.isModified = true;
        return iblockstate;
    }

    public int getLightFor(EnumSkyBlock var1, BlockPos var2) {
        int i = var2.getX() & 15;
        int j = var2.getY();
        int k = var2.getZ() & 15;
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[j >> 4];
        if (extendedblockstorage == null) {
            return this.canSeeSky(var2) ? var1.defaultLightValue : 0;
        } else if (var1 == EnumSkyBlock.SKY) {
            return this.worldObj.provider.getHasNoSky() ? 0 : extendedblockstorage.getExtSkylightValue(i, j & 15, k);
        } else {
            return var1 == EnumSkyBlock.BLOCK ? extendedblockstorage.getExtBlocklightValue(i, j & 15, k) : var1.defaultLightValue;
        }
    }

    public void setLightFor(EnumSkyBlock var1, BlockPos var2, int var3) {
        int i = var2.getX() & 15;
        int j = var2.getY();
        int k = var2.getZ() & 15;
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[j >> 4];
        if (extendedblockstorage == null) {
            extendedblockstorage = this.storageArrays[j >> 4] = new ExtendedBlockStorage(j >> 4 << 4, !this.worldObj.provider.getHasNoSky());
            this.generateSkylightMap();
        }

        this.isModified = true;
        if (var1 == EnumSkyBlock.SKY) {
            if (!this.worldObj.provider.getHasNoSky()) {
                extendedblockstorage.setExtSkylightValue(i, j & 15, k, var3);
            }
        } else if (var1 == EnumSkyBlock.BLOCK) {
            extendedblockstorage.setExtBlocklightValue(i, j & 15, k, var3);
        }
    }

    public int getLightSubtracted(BlockPos var1, int var2) {
        int i = var1.getX() & 15;
        int j = var1.getY();
        int k = var1.getZ() & 15;
        ExtendedBlockStorage extendedblockstorage = this.storageArrays[j >> 4];
        if (extendedblockstorage == null) {
            return !this.worldObj.provider.getHasNoSky() && var2 < EnumSkyBlock.SKY.defaultLightValue ? EnumSkyBlock.SKY.defaultLightValue - var2 : 0;
        }

        int l = this.worldObj.provider.getHasNoSky() ? 0 : extendedblockstorage.getExtSkylightValue(i, j & 15, k);
        l -= var2;
        int i1 = extendedblockstorage.getExtBlocklightValue(i, j & 15, k);
        if (i1 > l) {
            l = i1;
        }

        return l;
    }

    public void addEntity(Entity var1) {
        this.hasEntities = true;
        int i = MathHelper.floor_double(var1.posX / 16.0);
        int j = MathHelper.floor_double(var1.posZ / 16.0);
        if (i != this.xPosition || j != this.zPosition) {
            logger.warn("Wrong location! (" + i + ", " + j + ") should be (" + this.xPosition + ", " + this.zPosition + "), " + var1, new Object[]{var1});
            var1.setDead();
        }

        int k = MathHelper.floor_double(var1.posY / 16.0);
        if (k < 0) {
            k = 0;
        }

        if (k >= this.entityLists.length) {
            k = this.entityLists.length - 1;
        }

        var1.addedToChunk = true;
        var1.chunkCoordX = this.xPosition;
        var1.chunkCoordY = k;
        var1.chunkCoordZ = this.zPosition;
        this.entityLists[k].add(var1);
    }

    public void removeEntity(Entity var1) {
        this.removeEntityAtIndex(var1, var1.chunkCoordY);
    }

    public void removeEntityAtIndex(Entity var1, int var2) {
        if (var2 < 0) {
            var2 = 0;
        }

        if (var2 >= this.entityLists.length) {
            var2 = this.entityLists.length - 1;
        }

        this.entityLists[var2].remove(var1);
    }

    public boolean canSeeSky(BlockPos var1) {
        int i = var1.getX() & 15;
        int j = var1.getY();
        int k = var1.getZ() & 15;
        return j >= this.heightMap[k << 4 | i];
    }

    private TileEntity createNewTileEntity(BlockPos var1) {
        Block block = this.getBlock(var1);
        return !block.hasTileEntity() ? null : ((ITileEntityProvider)block).createNewTileEntity(this.worldObj, this.getBlockMetadata(var1));
    }

    public TileEntity getTileEntity(BlockPos var1, Chunk.EnumCreateEntityType var2) {
        TileEntity tileentity = (TileEntity)this.chunkTileEntityMap.get(var1);
        if (tileentity == null) {
            if (var2 == Chunk.EnumCreateEntityType.IMMEDIATE) {
                tileentity = this.createNewTileEntity(var1);
                this.worldObj.setTileEntity(var1, tileentity);
            } else if (var2 == Chunk.EnumCreateEntityType.QUEUED) {
                this.tileEntityPosQueue.add(var1);
            }
        } else if (tileentity.isInvalid()) {
            this.chunkTileEntityMap.remove(var1);
            return null;
        }

        return tileentity;
    }

    public void addTileEntity(TileEntity var1) {
        this.addTileEntity(var1.getPos(), var1);
        if (this.isChunkLoaded) {
            this.worldObj.addTileEntity(var1);
        }
    }

    public void addTileEntity(BlockPos var1, TileEntity var2) {
        var2.setWorldObj(this.worldObj);
        var2.setPos(var1);
        if (this.getBlock(var1) instanceof ITileEntityProvider) {
            if (this.chunkTileEntityMap.containsKey(var1)) {
                ((TileEntity)this.chunkTileEntityMap.get(var1)).invalidate();
            }

            var2.validate();
            this.chunkTileEntityMap.put(var1, var2);
        }
    }

    public void removeTileEntity(BlockPos var1) {
        if (this.isChunkLoaded) {
            TileEntity tileentity = (TileEntity)this.chunkTileEntityMap.remove(var1);
            if (tileentity != null) {
                tileentity.invalidate();
            }
        }
    }

    public void onChunkLoad() {
        this.isChunkLoaded = true;
        this.worldObj.addTileEntities(this.chunkTileEntityMap.values());

        for (int i = 0; i < this.entityLists.length; i++) {
            for (Entity entity : (Iterable<Entity>) (Iterable) this.entityLists[i]) {
                entity.onChunkLoad();
            }

            this.worldObj.loadEntities(this.entityLists[i]);
        }
    }

    public void onChunkUnload() {
        this.isChunkLoaded = false;

        for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) this.chunkTileEntityMap.values()) {
            this.worldObj.markTileEntityForRemoval(tileentity);
        }

        for (int i = 0; i < this.entityLists.length; i++) {
            this.worldObj.unloadEntities(this.entityLists[i]);
        }
    }

    public void setChunkModified() {
        this.isModified = true;
    }

    public void getEntitiesWithinAABBForEntity(Entity var1, AxisAlignedBB var2, List var3, Predicate var4) {
        int i = MathHelper.floor_double((var2.minY - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxY + 2.0) / 16.0);
        i = MathHelper.clamp_int(i, 0, this.entityLists.length - 1);
        j = MathHelper.clamp_int(j, 0, this.entityLists.length - 1);

        for (int k = i; k <= j; k++) {
            for (Entity entity : (Iterable<Entity>) (Iterable) this.entityLists[k]) {
                if (entity != var1 && entity.getEntityBoundingBox().intersectsWith(var2) && (var4 == null || var4.apply(entity))) {
                    var3.add(entity);
                    Entity[] aentity = entity.getParts();
                    if (aentity != null) {
                        for (int l = 0; l < aentity.length; l++) {
                            entity = aentity[l];
                            if (entity != var1 && entity.getEntityBoundingBox().intersectsWith(var2) && (var4 == null || var4.apply(entity))) {
                                var3.add(entity);
                            }
                        }
                    }
                }
            }
        }
    }

    public void getEntitiesOfTypeWithinAAAB(Class var1, AxisAlignedBB var2, List var3, Predicate var4) {
        int i = MathHelper.floor_double((var2.minY - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxY + 2.0) / 16.0);
        i = MathHelper.clamp_int(i, 0, this.entityLists.length - 1);
        j = MathHelper.clamp_int(j, 0, this.entityLists.length - 1);

        for (int k = i; k <= j; k++) {
            for (Entity entity : (Iterable<Entity>) (Iterable) this.entityLists[k].getByClass(var1)) {
                if (entity.getEntityBoundingBox().intersectsWith(var2) && (var4 == null || var4.apply(entity))) {
                    var3.add(entity);
                }
            }
        }
    }

    public boolean needsSaving(boolean var1) {
        if (var1) {
            if (this.hasEntities && this.worldObj.getTotalWorldTime() != this.lastSaveTime || this.isModified) {
                return true;
            }
        } else if (this.hasEntities && this.worldObj.getTotalWorldTime() >= this.lastSaveTime + 600L) {
            return true;
        }

        return this.isModified;
    }

    public Random getRandomWithSeed(long var1) {
        return new Random(
            this.worldObj.getSeed()
                    + this.xPosition * this.xPosition * 4987142
                    + this.xPosition * 5947611
                    + this.zPosition * this.zPosition * 4392871L
                    + this.zPosition * 389711
                ^ var1
        );
    }

    public boolean isEmpty() {
        return false;
    }

    public void populateChunk(IChunkProvider var1, IChunkProvider var2, int var3, int var4) {
        boolean flag = var1.chunkExists(var3, var4 - 1);
        boolean flag1 = var1.chunkExists(var3 + 1, var4);
        boolean flag2 = var1.chunkExists(var3, var4 + 1);
        boolean flag3 = var1.chunkExists(var3 - 1, var4);
        boolean flag4 = var1.chunkExists(var3 - 1, var4 - 1);
        boolean flag5 = var1.chunkExists(var3 + 1, var4 + 1);
        boolean flag6 = var1.chunkExists(var3 - 1, var4 + 1);
        boolean flag7 = var1.chunkExists(var3 + 1, var4 - 1);
        if (flag1 && flag2 && flag5) {
            if (!this.isTerrainPopulated) {
                var1.populate(var2, var3, var4);
            } else {
                var1.func_177460_a(var2, this, var3, var4);
            }
        }

        if (flag3 && flag2 && flag6) {
            Chunk chunk = var1.provideChunk(var3 - 1, var4);
            if (!chunk.isTerrainPopulated) {
                var1.populate(var2, var3 - 1, var4);
            } else {
                var1.func_177460_a(var2, chunk, var3 - 1, var4);
            }
        }

        if (flag && flag1 && flag7) {
            Chunk chunk1 = var1.provideChunk(var3, var4 - 1);
            if (!chunk1.isTerrainPopulated) {
                var1.populate(var2, var3, var4 - 1);
            } else {
                var1.func_177460_a(var2, chunk1, var3, var4 - 1);
            }
        }

        if (flag4 && flag && flag3) {
            Chunk chunk2 = var1.provideChunk(var3 - 1, var4 - 1);
            if (!chunk2.isTerrainPopulated) {
                var1.populate(var2, var3 - 1, var4 - 1);
            } else {
                var1.func_177460_a(var2, chunk2, var3 - 1, var4 - 1);
            }
        }
    }

    public BlockPos getPrecipitationHeight(BlockPos var1) {
        int i = var1.getX() & 15;
        int j = var1.getZ() & 15;
        int k = i | j << 4;
        BlockPos blockpos = new BlockPos(var1.getX(), this.precipitationHeightMap[k], var1.getZ());
        if (blockpos.getY() == -999) {
            int l = this.getTopFilledSegment() + 15;
            blockpos = new BlockPos(var1.getX(), l, var1.getZ());
            int i1 = -1;

            while (blockpos.getY() > 0 && i1 == -1) {
                Block block = this.getBlock(blockpos);
                Material material = block.getMaterial();
                if (!material.blocksMovement() && !material.isLiquid()) {
                    blockpos = blockpos.down();
                } else {
                    i1 = blockpos.getY() + 1;
                }
            }

            this.precipitationHeightMap[k] = i1;
        }

        return new BlockPos(var1.getX(), this.precipitationHeightMap[k], var1.getZ());
    }

    public void func_150804_b(boolean var1) {
        if (this.isGapLightingUpdated && !this.worldObj.provider.getHasNoSky() && !var1) {
            this.recheckGaps(this.worldObj.isRemote);
        }

        this.field_150815_m = true;
        if (!this.isLightPopulated && this.isTerrainPopulated) {
            this.func_150809_p();
        }

        while (!this.tileEntityPosQueue.isEmpty()) {
            BlockPos blockpos = (BlockPos)this.tileEntityPosQueue.poll();
            if (this.getTileEntity(blockpos, Chunk.EnumCreateEntityType.CHECK) == null && this.getBlock(blockpos).hasTileEntity()) {
                TileEntity tileentity = this.createNewTileEntity(blockpos);
                this.worldObj.setTileEntity(blockpos, tileentity);
                this.worldObj.markBlockRangeForRenderUpdate(blockpos, blockpos);
            }
        }
    }

    public boolean isPopulated() {
        return this.field_150815_m && this.isTerrainPopulated && this.isLightPopulated;
    }

    public ChunkCoordIntPair getChunkCoordIntPair() {
        return new ChunkCoordIntPair(this.xPosition, this.zPosition);
    }

    public boolean getAreLevelsEmpty(int var1, int var2) {
        if (var1 < 0) {
            var1 = 0;
        }

        if (var2 >= 256) {
            var2 = 255;
        }

        for (int i = var1; i <= var2; i += 16) {
            ExtendedBlockStorage extendedblockstorage = this.storageArrays[i >> 4];
            if (extendedblockstorage != null && !extendedblockstorage.isEmpty()) {
                return false;
            }
        }

        return true;
    }

    public void setStorageArrays(ExtendedBlockStorage[] var1) {
        if (this.storageArrays.length != var1.length) {
            logger.warn("Could not set level chunk sections, array length is " + var1.length + " instead of " + this.storageArrays.length);
        } else {
            for (int i = 0; i < this.storageArrays.length; i++) {
                this.storageArrays[i] = var1[i];
            }
        }
    }

    public void fillChunk(byte[] var1, int var2, boolean var3) {
        int i = 0;
        boolean flag = !this.worldObj.provider.getHasNoSky();

        for (int j = 0; j < this.storageArrays.length; j++) {
            if ((var2 & 1 << j) != 0) {
                if (this.storageArrays[j] == null) {
                    this.storageArrays[j] = new ExtendedBlockStorage(j << 4, flag);
                }

                char[] achar = this.storageArrays[j].getData();

                for (int k = 0; k < achar.length; k++) {
                    achar[k] = (char)((var1[i + 1] & 255) << 8 | var1[i] & 0xFF);
                    i += 2;
                }
            } else if (var3 && this.storageArrays[j] != null) {
                this.storageArrays[j] = null;
            }
        }

        for (int l = 0; l < this.storageArrays.length; l++) {
            if ((var2 & 1 << l) != 0 && this.storageArrays[l] != null) {
                NibbleArray nibblearray = this.storageArrays[l].getBlocklightArray();
                System.arraycopy(var1, i, nibblearray.getData(), 0, nibblearray.getData().length);
                i += nibblearray.getData().length;
            }
        }

        if (flag) {
            for (int i1 = 0; i1 < this.storageArrays.length; i1++) {
                if ((var2 & 1 << i1) != 0 && this.storageArrays[i1] != null) {
                    NibbleArray nibblearray1 = this.storageArrays[i1].getSkylightArray();
                    System.arraycopy(var1, i, nibblearray1.getData(), 0, nibblearray1.getData().length);
                    i += nibblearray1.getData().length;
                }
            }
        }

        if (var3) {
            System.arraycopy(var1, i, this.blockBiomeArray, 0, this.blockBiomeArray.length);
            i += this.blockBiomeArray.length;
        }

        for (int j1 = 0; j1 < this.storageArrays.length; j1++) {
            if (this.storageArrays[j1] != null && (var2 & 1 << j1) != 0) {
                this.storageArrays[j1].removeInvalidBlocks();
            }
        }

        this.isLightPopulated = true;
        this.isTerrainPopulated = true;
        this.generateHeightMap();

        for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) this.chunkTileEntityMap.values()) {
            tileentity.updateContainingBlockInfo();
        }
    }

    public BiomeGenBase getBiome(BlockPos var1, WorldChunkManager var2) {
        int i = var1.getX() & 15;
        int j = var1.getZ() & 15;
        int k = this.blockBiomeArray[j << 4 | i] & 255;
        if (k == 255) {
            BiomeGenBase biomegenbase = var2.getBiomeGenerator(var1, BiomeGenBase.plains);
            k = biomegenbase.biomeID;
            this.blockBiomeArray[j << 4 | i] = (byte)(k & 0xFF);
        }

        BiomeGenBase biomegenbase1 = BiomeGenBase.getBiome(k);
        return biomegenbase1 == null ? BiomeGenBase.plains : biomegenbase1;
    }

    public byte[] getBiomeArray() {
        return this.blockBiomeArray;
    }

    public void setBiomeArray(byte[] var1) {
        if (this.blockBiomeArray.length != var1.length) {
            logger.warn("Could not set level chunk biomes, array length is " + var1.length + " instead of " + this.blockBiomeArray.length);
        } else {
            for (int i = 0; i < this.blockBiomeArray.length; i++) {
                this.blockBiomeArray[i] = var1[i];
            }
        }
    }

    public void resetRelightChecks() {
        this.queuedLightChecks = 0;
    }

    public void enqueueRelightChecks() {
        BlockPos blockpos = new BlockPos(this.xPosition << 4, 0, this.zPosition << 4);

        for (int i = 0; i < 8; i++) {
            if (this.queuedLightChecks >= 4096) {
                return;
            }

            int j = this.queuedLightChecks % 16;
            int k = this.queuedLightChecks / 16 % 16;
            int l = this.queuedLightChecks / 256;
            this.queuedLightChecks++;

            for (int i1 = 0; i1 < 16; i1++) {
                BlockPos blockpos1 = blockpos.add(k, (j << 4) + i1, l);
                boolean flag = i1 == 0 || i1 == 15 || k == 0 || k == 15 || l == 0 || l == 15;
                if (this.storageArrays[j] == null && flag
                    || this.storageArrays[j] != null && this.storageArrays[j].getBlockByExtId(k, i1, l).getMaterial() == Material.air) {
                    for (EnumFacing enumfacing : EnumFacing.values()) {
                        BlockPos blockpos2 = blockpos1.offset(enumfacing);
                        if (this.worldObj.getBlockState(blockpos2).getBlock().getLightValue() > 0) {
                            this.worldObj.checkLight(blockpos2);
                        }
                    }

                    this.worldObj.checkLight(blockpos1);
                }
            }
        }
    }

    public void func_150809_p() {
        this.isTerrainPopulated = true;
        this.isLightPopulated = true;
        BlockPos blockpos = new BlockPos(this.xPosition << 4, 0, this.zPosition << 4);
        if (!this.worldObj.provider.getHasNoSky()) {
            if (this.worldObj.isAreaLoaded(blockpos.add(-1, 0, -1), blockpos.add(16, 63, 16))) {
                label44:
                for (int i = 0; i < 16; i++) {
                    for (int j = 0; j < 16; j++) {
                        if (!this.func_150811_f(i, j)) {
                            this.isLightPopulated = false;
                            break label44;
                        }
                    }
                }

                if (this.isLightPopulated) {
                    for (EnumFacing enumfacing : (Iterable<EnumFacing>) (Iterable) EnumFacing.Plane.HORIZONTAL) {
                        int k = enumfacing.getAxisDirection() == EnumFacing.AxisDirection.POSITIVE ? 16 : 1;
                        this.worldObj.getChunkFromBlockCoords(blockpos.offset(enumfacing, k)).func_180700_a(enumfacing.getOpposite());
                    }

                    this.func_177441_y();
                }
            } else {
                this.isLightPopulated = false;
            }
        }
    }

    private void func_177441_y() {
        for (int i = 0; i < this.updateSkylightColumns.length; i++) {
            this.updateSkylightColumns[i] = true;
        }

        this.recheckGaps(false);
    }

    private void func_180700_a(EnumFacing var1) {
        if (this.isTerrainPopulated) {
            if (var1 == EnumFacing.EAST) {
                for (int i = 0; i < 16; i++) {
                    this.func_150811_f(15, i);
                }
            } else if (var1 == EnumFacing.WEST) {
                for (int j = 0; j < 16; j++) {
                    this.func_150811_f(0, j);
                }
            } else if (var1 == EnumFacing.SOUTH) {
                for (int k = 0; k < 16; k++) {
                    this.func_150811_f(k, 15);
                }
            } else if (var1 == EnumFacing.NORTH) {
                for (int l = 0; l < 16; l++) {
                    this.func_150811_f(l, 0);
                }
            }
        }
    }

    private boolean func_150811_f(int var1, int var2) {
        BlockPos blockpos = new BlockPos(this.xPosition << 4, 0, this.zPosition << 4);
        int i = this.getTopFilledSegment();
        boolean flag = false;
        boolean flag1 = false;

        int j;
        for (j = i + 16 - 1; j > 63 || j > 0 && !flag1; j--) {
            BlockPos blockpos1 = blockpos.add(var1, j, var2);
            int k = this.getBlockLightOpacity(blockpos1);
            if (k == 255 && j < 63) {
                flag1 = true;
            }

            if (!flag && k > 0) {
                flag = true;
            } else if (flag && k == 0 && !this.worldObj.checkLight(blockpos1)) {
                return false;
            }
        }

        for (; j > 0; j--) {
            BlockPos blockpos2 = blockpos.add(var1, j, var2);
            if (this.getBlock(blockpos2).getLightValue() > 0) {
                this.worldObj.checkLight(blockpos2);
            }
        }

        return true;
    }

    public boolean isLoaded() {
        return this.isChunkLoaded;
    }

    public void setChunkLoaded(boolean var1) {
        this.isChunkLoaded = var1;
    }

    public World getWorld() {
        return this.worldObj;
    }

    public int[] getHeightMap() {
        return this.heightMap;
    }

    public void setHeightMap(int[] var1) {
        if (this.heightMap.length != var1.length) {
            logger.warn("Could not set level chunk heightmap, array length is " + var1.length + " instead of " + this.heightMap.length);
        } else {
            for (int i = 0; i < this.heightMap.length; i++) {
                this.heightMap[i] = var1[i];
            }
        }
    }

    public Map getTileEntityMap() {
        return this.chunkTileEntityMap;
    }

    public ClassInheritanceMultiMap[] getEntityLists() {
        return this.entityLists;
    }

    public boolean isTerrainPopulated() {
        return this.isTerrainPopulated;
    }

    public void setTerrainPopulated(boolean var1) {
        this.isTerrainPopulated = var1;
    }

    public boolean isLightPopulated() {
        return this.isLightPopulated;
    }

    public void setLightPopulated(boolean var1) {
        this.isLightPopulated = var1;
    }

    public void setModified(boolean var1) {
        this.isModified = var1;
    }

    public void setHasEntities(boolean var1) {
        this.hasEntities = var1;
    }

    public void setLastSaveTime(long var1) {
        this.lastSaveTime = var1;
    }

    public int getLowestHeight() {
        return this.heightMapMinimum;
    }

    public long getInhabitedTime() {
        return this.inhabitedTime;
    }

    public void setInhabitedTime(long var1) {
        this.inhabitedTime = var1;
    }

    public enum EnumCreateEntityType {
        IMMEDIATE,
        QUEUED,
        CHECK;
    }
}
