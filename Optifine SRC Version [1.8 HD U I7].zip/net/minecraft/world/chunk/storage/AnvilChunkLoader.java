package net.minecraft.world.chunk.storage;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.MinecraftException;
import net.minecraft.world.NextTickListEntry;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.NibbleArray;
import net.minecraft.world.storage.IThreadedFileIO;
import net.minecraft.world.storage.ThreadedFileIOBase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AnvilChunkLoader implements IChunkLoader, IThreadedFileIO {
    private static final Logger logger = LogManager.getLogger();
    private List chunksToRemove = Lists.newArrayList();
    private Set pendingAnvilChunksCoordinates = Sets.newHashSet();
    private Object syncLockObject = new Object();
    private final File chunkSaveLocation;

    public AnvilChunkLoader(File var1) {
        this.chunkSaveLocation = var1;
    }

    @Override
    public Chunk loadChunk(World var1, int var2, int var3) throws IOException {
        NBTTagCompound nbttagcompound = null;
        ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(var2, var3);
        synchronized (this.syncLockObject) {
            if (this.pendingAnvilChunksCoordinates.contains(chunkcoordintpair)) {
                for (int i = 0; i < this.chunksToRemove.size(); i++) {
                    if (((AnvilChunkLoader.PendingChunk)this.chunksToRemove.get(i)).chunkCoordinate.equals(chunkcoordintpair)) {
                        nbttagcompound = ((AnvilChunkLoader.PendingChunk)this.chunksToRemove.get(i)).nbtTags;
                        break;
                    }
                }
            }
        }

        if (nbttagcompound == null) {
            DataInputStream datainputstream = RegionFileCache.getChunkInputStream(this.chunkSaveLocation, var2, var3);
            if (datainputstream == null) {
                return null;
            }

            nbttagcompound = CompressedStreamTools.read(datainputstream);
        }

        return this.checkedReadChunkFromNBT(var1, var2, var3, nbttagcompound);
    }

    protected Chunk checkedReadChunkFromNBT(World var1, int var2, int var3, NBTTagCompound var4) {
        if (!var4.hasKey("Level", 10)) {
            logger.error("Chunk file at " + var2 + "," + var3 + " is missing level data, skipping");
            return null;
        }

        if (!var4.getCompoundTag("Level").hasKey("Sections", 9)) {
            logger.error("Chunk file at " + var2 + "," + var3 + " is missing block data, skipping");
            return null;
        }

        Chunk chunk = this.readChunkFromNBT(var1, var4.getCompoundTag("Level"));
        if (!chunk.isAtLocation(var2, var3)) {
            logger.error(
                "Chunk file at "
                    + var2
                    + ","
                    + var3
                    + " is in the wrong location; relocating. (Expected "
                    + var2
                    + ", "
                    + var3
                    + ", got "
                    + chunk.xPosition
                    + ", "
                    + chunk.zPosition
                    + ")"
            );
            var4.setInteger("xPos", var2);
            var4.setInteger("zPos", var3);
            chunk = this.readChunkFromNBT(var1, var4.getCompoundTag("Level"));
        }

        return chunk;
    }

    @Override
    public void saveChunk(World var1, Chunk var2) throws IOException, MinecraftException {
        var1.checkSessionLock();

        try {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            NBTTagCompound nbttagcompound1 = new NBTTagCompound();
            nbttagcompound.setTag("Level", nbttagcompound1);
            this.writeChunkToNBT(var2, var1, nbttagcompound1);
            this.addChunkToPending(var2.getChunkCoordIntPair(), nbttagcompound);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    protected void addChunkToPending(ChunkCoordIntPair var1, NBTTagCompound var2) {
        synchronized (this.syncLockObject) {
            if (this.pendingAnvilChunksCoordinates.contains(var1)) {
                for (int i = 0; i < this.chunksToRemove.size(); i++) {
                    if (((AnvilChunkLoader.PendingChunk)this.chunksToRemove.get(i)).chunkCoordinate.equals(var1)) {
                        this.chunksToRemove.set(i, new AnvilChunkLoader.PendingChunk(var1, var2));
                        return;
                    }
                }
            }

            this.chunksToRemove.add(new AnvilChunkLoader.PendingChunk(var1, var2));
            this.pendingAnvilChunksCoordinates.add(var1);
            ThreadedFileIOBase.getThreadedIOInstance().queueIO(this);
        }
    }

    @Override
    public boolean writeNextIO() {
        AnvilChunkLoader.PendingChunk anvilchunkloader$pendingchunk = null;
        synchronized (this.syncLockObject) {
            if (this.chunksToRemove.isEmpty()) {
                return false;
            }

            anvilchunkloader$pendingchunk = (AnvilChunkLoader.PendingChunk)this.chunksToRemove.remove(0);
            this.pendingAnvilChunksCoordinates.remove(anvilchunkloader$pendingchunk.chunkCoordinate);
        }

        if (anvilchunkloader$pendingchunk != null) {
            try {
                this.writeChunkNBTTags(anvilchunkloader$pendingchunk);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

        return true;
    }

    private void writeChunkNBTTags(AnvilChunkLoader.PendingChunk var1) throws IOException {
        DataOutputStream dataoutputstream = RegionFileCache.getChunkOutputStream(
            this.chunkSaveLocation, var1.chunkCoordinate.chunkXPos, var1.chunkCoordinate.chunkZPos
        );
        CompressedStreamTools.write(var1.nbtTags, dataoutputstream);
        dataoutputstream.close();
    }

    @Override
    public void saveExtraChunkData(World var1, Chunk var2) {
    }

    @Override
    public void chunkTick() {
    }

    @Override
    public void saveExtraData() {
        while (this.writeNextIO()) {
        }
    }

    private void writeChunkToNBT(Chunk var1, World var2, NBTTagCompound var3) {
        var3.setByte("V", (byte)1);
        var3.setInteger("xPos", var1.xPosition);
        var3.setInteger("zPos", var1.zPosition);
        var3.setLong("LastUpdate", var2.getTotalWorldTime());
        var3.setIntArray("HeightMap", var1.getHeightMap());
        var3.setBoolean("TerrainPopulated", var1.isTerrainPopulated());
        var3.setBoolean("LightPopulated", var1.isLightPopulated());
        var3.setLong("InhabitedTime", var1.getInhabitedTime());
        ExtendedBlockStorage[] aextendedblockstorage = var1.getBlockStorageArray();
        NBTTagList nbttaglist = new NBTTagList();
        boolean flag = !var2.provider.getHasNoSky();

        for (ExtendedBlockStorage extendedblockstorage : aextendedblockstorage) {
            if (extendedblockstorage != null) {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Y", (byte)(extendedblockstorage.getYLocation() >> 4 & 0xFF));
                byte[] abyte = new byte[extendedblockstorage.getData().length];
                NibbleArray nibblearray = new NibbleArray();
                NibbleArray nibblearray1 = null;

                for (int i = 0; i < extendedblockstorage.getData().length; i++) {
                    char c0 = extendedblockstorage.getData()[i];
                    int j = i & 15;
                    int k = i >> 8 & 15;
                    int l = i >> 4 & 15;
                    if (c0 >> '\f' != 0) {
                        if (nibblearray1 == null) {
                            nibblearray1 = new NibbleArray();
                        }

                        nibblearray1.set(j, k, l, c0 >> '\f');
                    }

                    abyte[i] = (byte)(c0 >> 4 & 0xFF);
                    nibblearray.set(j, k, l, c0 & 15);
                }

                nbttagcompound.setByteArray("Blocks", abyte);
                nbttagcompound.setByteArray("Data", nibblearray.getData());
                if (nibblearray1 != null) {
                    nbttagcompound.setByteArray("Add", nibblearray1.getData());
                }

                nbttagcompound.setByteArray("BlockLight", extendedblockstorage.getBlocklightArray().getData());
                if (flag) {
                    nbttagcompound.setByteArray("SkyLight", extendedblockstorage.getSkylightArray().getData());
                } else {
                    nbttagcompound.setByteArray("SkyLight", new byte[extendedblockstorage.getBlocklightArray().getData().length]);
                }

                nbttaglist.appendTag(nbttagcompound);
            }
        }

        var3.setTag("Sections", nbttaglist);
        var3.setByteArray("Biomes", var1.getBiomeArray());
        var1.setHasEntities(false);
        NBTTagList nbttaglist1 = new NBTTagList();

        for (int i1 = 0; i1 < var1.getEntityLists().length; i1++) {
            for (Entity entity : (Iterable<Entity>) (Iterable) var1.getEntityLists()[i1]) {
                NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                if (entity.writeToNBTOptional(nbttagcompound1)) {
                    var1.setHasEntities(true);
                    nbttaglist1.appendTag(nbttagcompound1);
                }
            }
        }

        var3.setTag("Entities", nbttaglist1);
        NBTTagList nbttaglist2 = new NBTTagList();

        for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) var1.getTileEntityMap().values()) {
            NBTTagCompound nbttagcompound2 = new NBTTagCompound();
            tileentity.writeToNBT(nbttagcompound2);
            nbttaglist2.appendTag(nbttagcompound2);
        }

        var3.setTag("TileEntities", nbttaglist2);
        List list = var2.getPendingBlockUpdates(var1, false);
        if (list != null) {
            long j1 = var2.getTotalWorldTime();
            NBTTagList nbttaglist3 = new NBTTagList();

            for (NextTickListEntry nextticklistentry : (Iterable<NextTickListEntry>) (Iterable) list) {
                NBTTagCompound nbttagcompound3 = new NBTTagCompound();
                ResourceLocation resourcelocation = (ResourceLocation)Block.blockRegistry.getNameForObject(nextticklistentry.getBlock());
                nbttagcompound3.setString("i", resourcelocation == null ? "" : resourcelocation.toString());
                nbttagcompound3.setInteger("x", nextticklistentry.position.getX());
                nbttagcompound3.setInteger("y", nextticklistentry.position.getY());
                nbttagcompound3.setInteger("z", nextticklistentry.position.getZ());
                nbttagcompound3.setInteger("t", (int)(nextticklistentry.scheduledTime - j1));
                nbttagcompound3.setInteger("p", nextticklistentry.priority);
                nbttaglist3.appendTag(nbttagcompound3);
            }

            var3.setTag("TileTicks", nbttaglist3);
        }
    }

    private Chunk readChunkFromNBT(World var1, NBTTagCompound var2) {
        int i = var2.getInteger("xPos");
        int j = var2.getInteger("zPos");
        Chunk chunk = new Chunk(var1, i, j);
        chunk.setHeightMap(var2.getIntArray("HeightMap"));
        chunk.setTerrainPopulated(var2.getBoolean("TerrainPopulated"));
        chunk.setLightPopulated(var2.getBoolean("LightPopulated"));
        chunk.setInhabitedTime(var2.getLong("InhabitedTime"));
        NBTTagList nbttaglist = var2.getTagList("Sections", 10);
        byte b0 = 16;
        ExtendedBlockStorage[] aextendedblockstorage = new ExtendedBlockStorage[b0];
        boolean flag = !var1.provider.getHasNoSky();

        for (int k = 0; k < nbttaglist.tagCount(); k++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(k);
            byte b1 = nbttagcompound.getByte("Y");
            ExtendedBlockStorage extendedblockstorage = new ExtendedBlockStorage(b1 << 4, flag);
            byte[] abyte = nbttagcompound.getByteArray("Blocks");
            NibbleArray nibblearray = new NibbleArray(nbttagcompound.getByteArray("Data"));
            NibbleArray nibblearray1 = nbttagcompound.hasKey("Add", 7) ? new NibbleArray(nbttagcompound.getByteArray("Add")) : null;
            char[] achar = new char[abyte.length];

            for (int l = 0; l < achar.length; l++) {
                int i1 = l & 15;
                int j1 = l >> 8 & 15;
                int k1 = l >> 4 & 15;
                int l1 = nibblearray1 != null ? nibblearray1.get(i1, j1, k1) : 0;
                achar[l] = (char)(l1 << 12 | (abyte[l] & 255) << 4 | nibblearray.get(i1, j1, k1));
            }

            extendedblockstorage.setData(achar);
            extendedblockstorage.setBlocklightArray(new NibbleArray(nbttagcompound.getByteArray("BlockLight")));
            if (flag) {
                extendedblockstorage.setSkylightArray(new NibbleArray(nbttagcompound.getByteArray("SkyLight")));
            }

            extendedblockstorage.removeInvalidBlocks();
            aextendedblockstorage[b1] = extendedblockstorage;
        }

        chunk.setStorageArrays(aextendedblockstorage);
        if (var2.hasKey("Biomes", 7)) {
            chunk.setBiomeArray(var2.getByteArray("Biomes"));
        }

        NBTTagList nbttaglist1 = var2.getTagList("Entities", 10);
        if (nbttaglist1 != null) {
            for (int i2 = 0; i2 < nbttaglist1.tagCount(); i2++) {
                NBTTagCompound nbttagcompound1 = nbttaglist1.getCompoundTagAt(i2);
                Entity entity = EntityList.createEntityFromNBT(nbttagcompound1, var1);
                chunk.setHasEntities(true);
                if (entity != null) {
                    chunk.addEntity(entity);
                    Entity entity1 = entity;

                    for (NBTTagCompound nbttagcompound4 = nbttagcompound1;
                        nbttagcompound4.hasKey("Riding", 10);
                        nbttagcompound4 = nbttagcompound4.getCompoundTag("Riding")
                    ) {
                        Entity entity2 = EntityList.createEntityFromNBT(nbttagcompound4.getCompoundTag("Riding"), var1);
                        if (entity2 != null) {
                            chunk.addEntity(entity2);
                            entity1.mountEntity(entity2);
                        }

                        entity1 = entity2;
                    }
                }
            }
        }

        NBTTagList nbttaglist2 = var2.getTagList("TileEntities", 10);
        if (nbttaglist2 != null) {
            for (int j2 = 0; j2 < nbttaglist2.tagCount(); j2++) {
                NBTTagCompound nbttagcompound2 = nbttaglist2.getCompoundTagAt(j2);
                TileEntity tileentity = TileEntity.createAndLoadEntity(nbttagcompound2);
                if (tileentity != null) {
                    chunk.addTileEntity(tileentity);
                }
            }
        }

        if (var2.hasKey("TileTicks", 9)) {
            NBTTagList nbttaglist3 = var2.getTagList("TileTicks", 10);
            if (nbttaglist3 != null) {
                for (int k2 = 0; k2 < nbttaglist3.tagCount(); k2++) {
                    NBTTagCompound nbttagcompound3 = nbttaglist3.getCompoundTagAt(k2);
                    Block block;
                    if (nbttagcompound3.hasKey("i", 8)) {
                        block = Block.getBlockFromName(nbttagcompound3.getString("i"));
                    } else {
                        block = Block.getBlockById(nbttagcompound3.getInteger("i"));
                    }

                    var1.scheduleBlockUpdate(
                        new BlockPos(nbttagcompound3.getInteger("x"), nbttagcompound3.getInteger("y"), nbttagcompound3.getInteger("z")),
                        block,
                        nbttagcompound3.getInteger("t"),
                        nbttagcompound3.getInteger("p")
                    );
                }
            }
        }

        return chunk;
    }

    static class PendingChunk {
        public final ChunkCoordIntPair chunkCoordinate;
        public final NBTTagCompound nbtTags;

        public PendingChunk(ChunkCoordIntPair var1, NBTTagCompound var2) {
            this.chunkCoordinate = var1;
            this.nbtTags = var2;
        }
    }
}
