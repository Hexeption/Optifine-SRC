package net.minecraft.world.chunk.storage;

import com.google.common.collect.Lists;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.List;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;
import net.minecraft.server.MinecraftServer;

public class RegionFile {
    private static final byte[] emptySector = new byte[4096];
    private final File fileName;
    private RandomAccessFile dataFile;
    private final int[] offsets = new int[1024];
    private final int[] chunkTimestamps = new int[1024];
    private List sectorFree;
    private int sizeDelta;
    private long lastModified;

    public RegionFile(File var1) {
        this.fileName = var1;
        this.sizeDelta = 0;

        try {
            if (var1.exists()) {
                this.lastModified = var1.lastModified();
            }

            this.dataFile = new RandomAccessFile(var1, "rw");
            if (this.dataFile.length() < 4096L) {
                for (int i = 0; i < 1024; i++) {
                    this.dataFile.writeInt(0);
                }

                for (int i1 = 0; i1 < 1024; i1++) {
                    this.dataFile.writeInt(0);
                }

                this.sizeDelta += 8192;
            }

            if ((this.dataFile.length() & 4095L) != 0L) {
                for (int j1 = 0; j1 < (this.dataFile.length() & 4095L); j1++) {
                    this.dataFile.write(0);
                }
            }

            int k1 = (int)this.dataFile.length() / 4096;
            this.sectorFree = Lists.newArrayListWithCapacity(k1);

            for (int j = 0; j < k1; j++) {
                this.sectorFree.add(true);
            }

            this.sectorFree.set(0, false);
            this.sectorFree.set(1, false);
            this.dataFile.seek(0L);

            for (int l1 = 0; l1 < 1024; l1++) {
                int k = this.dataFile.readInt();
                this.offsets[l1] = k;
                if (k != 0 && (k >> 8) + (k & 0xFF) <= this.sectorFree.size()) {
                    for (int l = 0; l < (k & 0xFF); l++) {
                        this.sectorFree.set((k >> 8) + l, false);
                    }
                }
            }

            for (int i2 = 0; i2 < 1024; i2++) {
                int j2 = this.dataFile.readInt();
                this.chunkTimestamps[i2] = j2;
            }
        } catch (IOException ioexception) {
            ioexception.printStackTrace();
        }
    }

    public synchronized DataInputStream getChunkDataInputStream(int var1, int var2) {
        if (this.outOfBounds(var1, var2)) {
            return null;
        }

        try {
            int i = this.getOffset(var1, var2);
            if (i == 0) {
                return null;
            } else {
                int j = i >> 8;
                int k = i & 0xFF;
                if (j + k > this.sectorFree.size()) {
                    return null;
                } else {
                    this.dataFile.seek(j * 4096);
                    int l = this.dataFile.readInt();
                    if (l > 4096 * k) {
                        return null;
                    } else if (l <= 0) {
                        return null;
                    } else {
                        byte b0 = this.dataFile.readByte();
                        if (b0 == 1) {
                            byte[] abyte1 = new byte[l - 1];
                            this.dataFile.read(abyte1);
                            return new DataInputStream(new BufferedInputStream(new GZIPInputStream(new ByteArrayInputStream(abyte1))));
                        } else if (b0 == 2) {
                            byte[] abyte = new byte[l - 1];
                            this.dataFile.read(abyte);
                            return new DataInputStream(new BufferedInputStream(new InflaterInputStream(new ByteArrayInputStream(abyte))));
                        } else {
                            return null;
                        }
                    }
                }
            }
        } catch (IOException ioexception) {
            return null;
        }
    }

    public DataOutputStream getChunkDataOutputStream(int var1, int var2) {
        return this.outOfBounds(var1, var2) ? null : new DataOutputStream(new DeflaterOutputStream(new RegionFile.ChunkBuffer(var1, var2)));
    }

    protected synchronized void write(int var1, int var2, byte[] var3, int var4) {
        try {
            int i = this.getOffset(var1, var2);
            int j = i >> 8;
            int k = i & 0xFF;
            int l = (var4 + 5) / 4096 + 1;
            if (l >= 256) {
                return;
            }

            if (j != 0 && k == l) {
                this.write(j, var3, var4);
            } else {
                for (int i1 = 0; i1 < k; i1++) {
                    this.sectorFree.set(j + i1, true);
                }

                int l1 = this.sectorFree.indexOf(true);
                int j1 = 0;
                if (l1 != -1) {
                    for (int k1 = l1; k1 < this.sectorFree.size(); k1++) {
                        if (j1 != 0) {
                            if ((Boolean)this.sectorFree.get(k1)) {
                                j1++;
                            } else {
                                j1 = 0;
                            }
                        } else if ((Boolean)this.sectorFree.get(k1)) {
                            l1 = k1;
                            j1 = 1;
                        }

                        if (j1 >= l) {
                            break;
                        }
                    }
                }

                if (j1 >= l) {
                    j = l1;
                    this.setOffset(var1, var2, j << 8 | l);

                    for (int j2 = 0; j2 < l; j2++) {
                        this.sectorFree.set(j + j2, false);
                    }

                    this.write(j, var3, var4);
                } else {
                    this.dataFile.seek(this.dataFile.length());
                    j = this.sectorFree.size();

                    for (int i2 = 0; i2 < l; i2++) {
                        this.dataFile.write(emptySector);
                        this.sectorFree.add(false);
                    }

                    this.sizeDelta += 4096 * l;
                    this.write(j, var3, var4);
                    this.setOffset(var1, var2, j << 8 | l);
                }
            }

            this.setChunkTimestamp(var1, var2, (int)(MinecraftServer.getCurrentTimeMillis() / 1000L));
        } catch (IOException ioexception) {
            ioexception.printStackTrace();
        }
    }

    private void write(int var1, byte[] var2, int var3) throws IOException {
        this.dataFile.seek(var1 * 4096);
        this.dataFile.writeInt(var3 + 1);
        this.dataFile.writeByte(2);
        this.dataFile.write(var2, 0, var3);
    }

    private boolean outOfBounds(int var1, int var2) {
        return var1 < 0 || var1 >= 32 || var2 < 0 || var2 >= 32;
    }

    private int getOffset(int var1, int var2) {
        return this.offsets[var1 + var2 * 32];
    }

    public boolean isChunkSaved(int var1, int var2) {
        return this.getOffset(var1, var2) != 0;
    }

    private void setOffset(int var1, int var2, int var3) throws IOException {
        this.offsets[var1 + var2 * 32] = var3;
        this.dataFile.seek((var1 + var2 * 32) * 4);
        this.dataFile.writeInt(var3);
    }

    private void setChunkTimestamp(int var1, int var2, int var3) throws IOException {
        this.chunkTimestamps[var1 + var2 * 32] = var3;
        this.dataFile.seek(4096 + (var1 + var2 * 32) * 4);
        this.dataFile.writeInt(var3);
    }

    public void close() throws IOException {
        if (this.dataFile != null) {
            this.dataFile.close();
        }
    }

    class ChunkBuffer extends ByteArrayOutputStream {
        private int chunkX;
        private int chunkZ;

        public ChunkBuffer(int var2, int var3) {
            super(8096);
            this.chunkX = var2;
            this.chunkZ = var3;
        }

        @Override
        public void close() throws IOException {
            RegionFile.this.write(this.chunkX, this.chunkZ, this.buf, this.count);
        }
    }
}
