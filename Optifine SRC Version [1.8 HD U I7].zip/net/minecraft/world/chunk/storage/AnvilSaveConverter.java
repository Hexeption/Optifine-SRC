package net.minecraft.world.chunk.storage;

import com.google.common.collect.Lists;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.AnvilConverterException;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.biome.WorldChunkManagerHell;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.SaveFormatComparator;
import net.minecraft.world.storage.SaveFormatOld;
import net.minecraft.world.storage.WorldInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AnvilSaveConverter extends SaveFormatOld {
    private static final Logger logger = LogManager.getLogger();

    public AnvilSaveConverter(File var1) {
        super(var1);
    }

    @Override
    public String getName() {
        return "Anvil";
    }

    @Override
    public List getSaveList() throws AnvilConverterException {
        if (this.savesDirectory != null && this.savesDirectory.exists() && this.savesDirectory.isDirectory()) {
            ArrayList arraylist = Lists.newArrayList();
            File[] afile = this.savesDirectory.listFiles();

            for (File file1 : afile) {
                if (file1.isDirectory()) {
                    String s = file1.getName();
                    WorldInfo worldinfo = this.getWorldInfo(s);
                    if (worldinfo != null && (worldinfo.getSaveVersion() == 19132 || worldinfo.getSaveVersion() == 19133)) {
                        boolean flag = worldinfo.getSaveVersion() != this.getSaveVersion();
                        String s1 = worldinfo.getWorldName();
                        if (StringUtils.isEmpty(s1)) {
                            s1 = s;
                        }

                        long i = 0L;
                        arraylist.add(
                            new SaveFormatComparator(
                                s,
                                s1,
                                worldinfo.getLastTimePlayed(),
                                i,
                                worldinfo.getGameType(),
                                flag,
                                worldinfo.isHardcoreModeEnabled(),
                                worldinfo.areCommandsAllowed()
                            )
                        );
                    }
                }
            }

            return arraylist;
        } else {
            throw new AnvilConverterException("Unable to read or access folder where game worlds are saved!");
        }
    }

    protected int getSaveVersion() {
        return 19133;
    }

    @Override
    public void flushCache() {
        RegionFileCache.clearRegionFileReferences();
    }

    @Override
    public ISaveHandler getSaveLoader(String var1, boolean var2) {
        return new AnvilSaveHandler(this.savesDirectory, var1, var2);
    }

    @Override
    public boolean func_154334_a(String var1) {
        WorldInfo worldinfo = this.getWorldInfo(var1);
        return worldinfo != null && worldinfo.getSaveVersion() == 19132;
    }

    @Override
    public boolean isOldMapFormat(String var1) {
        WorldInfo worldinfo = this.getWorldInfo(var1);
        return worldinfo != null && worldinfo.getSaveVersion() != this.getSaveVersion();
    }

    @Override
    public boolean convertMapFormat(String var1, IProgressUpdate var2) {
        var2.setLoadingProgress(0);
        ArrayList arraylist = Lists.newArrayList();
        ArrayList arraylist1 = Lists.newArrayList();
        ArrayList arraylist2 = Lists.newArrayList();
        File file1 = new File(this.savesDirectory, var1);
        File file2 = new File(file1, "DIM-1");
        File file3 = new File(file1, "DIM1");
        logger.info("Scanning folders...");
        this.addRegionFilesToCollection(file1, arraylist);
        if (file2.exists()) {
            this.addRegionFilesToCollection(file2, arraylist1);
        }

        if (file3.exists()) {
            this.addRegionFilesToCollection(file3, arraylist2);
        }

        int i = arraylist.size() + arraylist1.size() + arraylist2.size();
        logger.info("Total conversion count is " + i);
        WorldInfo worldinfo = this.getWorldInfo(var1);
        WorldChunkManager worldchunkmanager = null;
        if (worldinfo.getTerrainType() == WorldType.FLAT) {
            worldchunkmanager = new WorldChunkManagerHell(BiomeGenBase.plains, 0.5F);
        } else {
            worldchunkmanager = new WorldChunkManager(worldinfo.getSeed(), worldinfo.getTerrainType(), worldinfo.getGeneratorOptions());
        }

        this.convertFile(new File(file1, "region"), arraylist, worldchunkmanager, 0, i, var2);
        this.convertFile(new File(file2, "region"), arraylist1, new WorldChunkManagerHell(BiomeGenBase.hell, 0.0F), arraylist.size(), i, var2);
        this.convertFile(
            new File(file3, "region"), arraylist2, new WorldChunkManagerHell(BiomeGenBase.sky, 0.0F), arraylist.size() + arraylist1.size(), i, var2
        );
        worldinfo.setSaveVersion(19133);
        if (worldinfo.getTerrainType() == WorldType.DEFAULT_1_1) {
            worldinfo.setTerrainType(WorldType.DEFAULT);
        }

        this.createFile(var1);
        ISaveHandler isavehandler = this.getSaveLoader(var1, false);
        isavehandler.saveWorldInfo(worldinfo);
        return true;
    }

    private void createFile(String var1) {
        File file1 = new File(this.savesDirectory, var1);
        if (!file1.exists()) {
            logger.warn("Unable to create level.dat_mcr backup");
        } else {
            File file2 = new File(file1, "level.dat");
            if (!file2.exists()) {
                logger.warn("Unable to create level.dat_mcr backup");
            } else {
                File file3 = new File(file1, "level.dat_mcr");
                if (!file2.renameTo(file3)) {
                    logger.warn("Unable to create level.dat_mcr backup");
                }
            }
        }
    }

    private void convertFile(File var1, Iterable var2, WorldChunkManager var3, int var4, int var5, IProgressUpdate var6) {
        for (File file1 : (Iterable<File>) (Iterable) var2) {
            this.convertChunks(var1, file1, var3, var4, var5, var6);
            var4++;
            int i = (int)Math.round(100.0 * var4 / var5);
            var6.setLoadingProgress(i);
        }
    }

    private void convertChunks(File var1, File var2, WorldChunkManager var3, int var4, int var5, IProgressUpdate var6) {
        try {
            String s = var2.getName();
            RegionFile regionfile = new RegionFile(var2);
            RegionFile regionfile1 = new RegionFile(new File(var1, s.substring(0, s.length() - ".mcr".length()) + ".mca"));

            for (int i = 0; i < 32; i++) {
                for (int j = 0; j < 32; j++) {
                    if (regionfile.isChunkSaved(i, j) && !regionfile1.isChunkSaved(i, j)) {
                        DataInputStream datainputstream = regionfile.getChunkDataInputStream(i, j);
                        if (datainputstream == null) {
                            logger.warn("Failed to fetch input stream");
                        } else {
                            NBTTagCompound nbttagcompound = CompressedStreamTools.read(datainputstream);
                            datainputstream.close();
                            NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("Level");
                            ChunkLoader.AnvilConverterData chunkloader$anvilconverterdata = ChunkLoader.load(nbttagcompound1);
                            NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                            NBTTagCompound nbttagcompound3 = new NBTTagCompound();
                            nbttagcompound2.setTag("Level", nbttagcompound3);
                            ChunkLoader.convertToAnvilFormat(chunkloader$anvilconverterdata, nbttagcompound3, var3);
                            DataOutputStream dataoutputstream = regionfile1.getChunkDataOutputStream(i, j);
                            CompressedStreamTools.write(nbttagcompound2, dataoutputstream);
                            dataoutputstream.close();
                        }
                    }
                }

                int k = (int)Math.round(100.0 * (var4 * 1024) / (var5 * 1024));
                int l = (int)Math.round(100.0 * ((i + 1) * 32 + var4 * 1024) / (var5 * 1024));
                if (l > k) {
                    var6.setLoadingProgress(l);
                }
            }

            regionfile.close();
            regionfile1.close();
        } catch (IOException ioexception) {
            ioexception.printStackTrace();
        }
    }

    private void addRegionFilesToCollection(File var1, Collection var2) {
        File file1 = new File(var1, "region");
        File[] afile = file1.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File var1, String var2x) {
                return var2x.endsWith(".mcr");
            }
        });
        if (afile != null) {
            Collections.addAll(var2, afile);
        }
    }
}
