package net.minecraft.world.chunk.storage;

import com.google.common.collect.Maps;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Map;

public class RegionFileCache {
    private static final Map regionsByFilename = Maps.newHashMap();

    public static synchronized RegionFile createOrLoadRegionFile(File var0, int var1, int var2) {
        File file1 = new File(var0, "region");
        File file2 = new File(file1, "r." + (var1 >> 5) + "." + (var2 >> 5) + ".mca");
        RegionFile regionfile = (RegionFile)regionsByFilename.get(file2);
        if (regionfile != null) {
            return regionfile;
        }

        if (!file1.exists()) {
            file1.mkdirs();
        }

        if (regionsByFilename.size() >= 256) {
            clearRegionFileReferences();
        }

        RegionFile regionfile1 = new RegionFile(file2);
        regionsByFilename.put(file2, regionfile1);
        return regionfile1;
    }

    public static synchronized void clearRegionFileReferences() {
        for (RegionFile regionfile : (Iterable<RegionFile>) (Iterable) regionsByFilename.values()) {
            try {
                if (regionfile != null) {
                    regionfile.close();
                }
            } catch (IOException ioexception) {
                ioexception.printStackTrace();
            }
        }

        regionsByFilename.clear();
    }

    public static DataInputStream getChunkInputStream(File var0, int var1, int var2) {
        RegionFile regionfile = createOrLoadRegionFile(var0, var1, var2);
        return regionfile.getChunkDataInputStream(var1 & 31, var2 & 31);
    }

    public static DataOutputStream getChunkOutputStream(File var0, int var1, int var2) {
        RegionFile regionfile = createOrLoadRegionFile(var0, var1, var2);
        return regionfile.getChunkDataOutputStream(var1 & 31, var2 & 31);
    }
}
