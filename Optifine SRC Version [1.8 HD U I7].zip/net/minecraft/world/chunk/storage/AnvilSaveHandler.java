package net.minecraft.world.chunk.storage;

import java.io.File;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldProviderEnd;
import net.minecraft.world.WorldProviderHell;
import net.minecraft.world.storage.SaveHandler;
import net.minecraft.world.storage.ThreadedFileIOBase;
import net.minecraft.world.storage.WorldInfo;

public class AnvilSaveHandler extends SaveHandler {
    public AnvilSaveHandler(File var1, String var2, boolean var3) {
        super(var1, var2, var3);
    }

    @Override
    public IChunkLoader getChunkLoader(WorldProvider var1) {
        File file1 = this.getWorldDirectory();
        if (var1 instanceof WorldProviderHell) {
            File file3 = new File(file1, "DIM-1");
            file3.mkdirs();
            return new AnvilChunkLoader(file3);
        } else if (var1 instanceof WorldProviderEnd) {
            File file2 = new File(file1, "DIM1");
            file2.mkdirs();
            return new AnvilChunkLoader(file2);
        } else {
            return new AnvilChunkLoader(file1);
        }
    }

    @Override
    public void saveWorldInfoWithPlayer(WorldInfo var1, NBTTagCompound var2) {
        var1.setSaveVersion(19133);
        super.saveWorldInfoWithPlayer(var1, var2);
    }

    @Override
    public void flush() {
        try {
            ThreadedFileIOBase.getThreadedIOInstance().waitForFinish();
        } catch (InterruptedException interruptedexception) {
            interruptedexception.printStackTrace();
        }

        RegionFileCache.clearRegionFileReferences();
    }
}
