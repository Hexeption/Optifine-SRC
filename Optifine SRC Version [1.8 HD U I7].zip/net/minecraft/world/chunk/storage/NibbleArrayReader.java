package net.minecraft.world.chunk.storage;

public class NibbleArrayReader {
    public final byte[] data;
    private final int depthBits;
    private final int depthBitsPlusFour;

    public NibbleArrayReader(byte[] var1, int var2) {
        this.data = var1;
        this.depthBits = var2;
        this.depthBitsPlusFour = var2 + 4;
    }

    public int get(int var1, int var2, int var3) {
        int i = var1 << this.depthBitsPlusFour | var3 << this.depthBits | var2;
        int j = i >> 1;
        int k = i & 1;
        return k == 0 ? this.data[j] & 15 : this.data[j] >> 4 & 15;
    }
}
