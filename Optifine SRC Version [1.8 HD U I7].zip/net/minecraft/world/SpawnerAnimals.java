package net.minecraft.world;

import com.google.common.collect.Sets;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntitySpawnPlacementRegistry;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.WeightedRandom;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;

public final class SpawnerAnimals {
    private static final int MOB_COUNT_DIV = (int)Math.pow(17.0, 2.0);
    private final Set eligibleChunksForSpawning = Sets.newHashSet();

    public int findChunksForSpawning(WorldServer var1, boolean var2, boolean var3, boolean var4) {
        if (!var2 && !var3) {
            return 0;
        }

        this.eligibleChunksForSpawning.clear();
        int i = 0;

        for (EntityPlayer entityplayer : (Iterable<EntityPlayer>) (Iterable) var1.playerEntities) {
            if (!entityplayer.isSpectator()) {
                int j = MathHelper.floor_double(entityplayer.posX / 16.0);
                int k = MathHelper.floor_double(entityplayer.posZ / 16.0);
                byte b0 = 8;

                for (int l = -b0; l <= b0; l++) {
                    for (int i1 = -b0; i1 <= b0; i1++) {
                        boolean flag = l == -b0 || l == b0 || i1 == -b0 || i1 == b0;
                        ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(l + j, i1 + k);
                        if (!this.eligibleChunksForSpawning.contains(chunkcoordintpair)) {
                            i++;
                            if (!flag && var1.getWorldBorder().contains(chunkcoordintpair)) {
                                this.eligibleChunksForSpawning.add(chunkcoordintpair);
                            }
                        }
                    }
                }
            }
        }

        int k3 = 0;
        BlockPos blockpos2 = var1.getSpawnPoint();

        for (EnumCreatureType enumcreaturetype : EnumCreatureType.values()) {
            if ((!enumcreaturetype.getPeacefulCreature() || var3)
                && (enumcreaturetype.getPeacefulCreature() || var2)
                && (!enumcreaturetype.getAnimal() || var4)) {
                int l3 = var1.countEntities(enumcreaturetype.getCreatureClass());
                int i4 = enumcreaturetype.getMaxNumberOfCreature() * i / MOB_COUNT_DIV;
                if (l3 <= i4) {
                    label129:
                    for (ChunkCoordIntPair chunkcoordintpair1 : (Iterable<ChunkCoordIntPair>) (Iterable) this.eligibleChunksForSpawning) {
                        BlockPos blockpos = getRandomChunkPosition(var1, chunkcoordintpair1.chunkXPos, chunkcoordintpair1.chunkZPos);
                        int j1 = blockpos.getX();
                        int k1 = blockpos.getY();
                        int l1 = blockpos.getZ();
                        Block block = var1.getBlockState(blockpos).getBlock();
                        if (!block.isNormalCube()) {
                            int i2 = 0;

                            for (int j2 = 0; j2 < 3; j2++) {
                                int k2 = j1;
                                int l2 = k1;
                                int i3 = l1;
                                byte b1 = 6;
                                BiomeGenBase.SpawnListEntry biomegenbase$spawnlistentry = null;
                                IEntityLivingData ientitylivingdata = null;

                                for (int j3 = 0; j3 < 4; j3++) {
                                    k2 += var1.rand.nextInt(b1) - var1.rand.nextInt(b1);
                                    l2 += var1.rand.nextInt(1) - var1.rand.nextInt(1);
                                    i3 += var1.rand.nextInt(b1) - var1.rand.nextInt(b1);
                                    BlockPos blockpos1 = new BlockPos(k2, l2, i3);
                                    float f = k2 + 0.5F;
                                    float f1 = i3 + 0.5F;
                                    if (!var1.isAnyPlayerWithinRangeAt(f, l2, f1, 24.0) && !(blockpos2.distanceSq(f, l2, f1) < 576.0)) {
                                        if (biomegenbase$spawnlistentry == null) {
                                            biomegenbase$spawnlistentry = var1.getSpawnListEntryForTypeAt(enumcreaturetype, blockpos1);
                                            if (biomegenbase$spawnlistentry == null) {
                                                break;
                                            }
                                        }

                                        if (var1.canCreatureTypeSpawnHere(enumcreaturetype, biomegenbase$spawnlistentry, blockpos1)
                                            && canCreatureTypeSpawnAtLocation(
                                                EntitySpawnPlacementRegistry.getPlacementForEntity(biomegenbase$spawnlistentry.entityClass), var1, blockpos1
                                            )) {
                                            EntityLiving entityliving;
                                            try {
                                                entityliving = (EntityLiving)biomegenbase$spawnlistentry.entityClass
                                                    .getConstructor(World.class)
                                                    .newInstance(var1);
                                            } catch (Exception exception) {
                                                exception.printStackTrace();
                                                return k3;
                                            }

                                            entityliving.setLocationAndAngles(f, l2, f1, var1.rand.nextFloat() * 360.0F, 0.0F);
                                            if (entityliving.getCanSpawnHere() && entityliving.isNotColliding()) {
                                                ientitylivingdata = entityliving.onInitialSpawn(
                                                    var1.getDifficultyForLocation(new BlockPos(entityliving)), ientitylivingdata
                                                );
                                                if (entityliving.isNotColliding()) {
                                                    i2++;
                                                    var1.spawnEntityInWorld(entityliving);
                                                }

                                                if (i2 >= entityliving.getMaxSpawnedInChunk()) {
                                                    continue label129;
                                                }
                                            }

                                            k3 += i2;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return k3;
    }

    protected static BlockPos getRandomChunkPosition(World var0, int var1, int var2) {
        Chunk chunk = var0.getChunkFromChunkCoords(var1, var2);
        int i = var1 * 16 + var0.rand.nextInt(16);
        int j = var2 * 16 + var0.rand.nextInt(16);
        int k = MathHelper.func_154354_b(chunk.getHeight(new BlockPos(i, 0, j)) + 1, 16);
        int l = var0.rand.nextInt(k > 0 ? k : chunk.getTopFilledSegment() + 16 - 1);
        return new BlockPos(i, l, j);
    }

    public static boolean canCreatureTypeSpawnAtLocation(EntityLiving.SpawnPlacementType var0, World var1, BlockPos var2) {
        if (!var1.getWorldBorder().contains(var2)) {
            return false;
        }

        Block block = var1.getBlockState(var2).getBlock();
        if (var0 == EntityLiving.SpawnPlacementType.IN_WATER) {
            return block.getMaterial().isLiquid()
                && var1.getBlockState(var2.down()).getBlock().getMaterial().isLiquid()
                && !var1.getBlockState(var2.up()).getBlock().isNormalCube();
        }

        BlockPos blockpos = var2.down();
        if (!World.doesBlockHaveSolidTopSurface(var1, blockpos)) {
            return false;
        }

        Block block1 = var1.getBlockState(blockpos).getBlock();
        boolean flag = block1 != Blocks.bedrock && block1 != Blocks.barrier;
        return flag && !block.isNormalCube() && !block.getMaterial().isLiquid() && !var1.getBlockState(var2.up()).getBlock().isNormalCube();
    }

    public static void performWorldGenSpawning(World var0, BiomeGenBase var1, int var2, int var3, int var4, int var5, Random var6) {
        List list = var1.getSpawnableList(EnumCreatureType.CREATURE);
        if (!list.isEmpty()) {
            while (var6.nextFloat() < var1.getSpawningChance()) {
                BiomeGenBase.SpawnListEntry biomegenbase$spawnlistentry = (BiomeGenBase.SpawnListEntry)WeightedRandom.getRandomItem(var0.rand, list);
                int i = biomegenbase$spawnlistentry.minGroupCount
                    + var6.nextInt(1 + biomegenbase$spawnlistentry.maxGroupCount - biomegenbase$spawnlistentry.minGroupCount);
                IEntityLivingData ientitylivingdata = null;
                int j = var2 + var6.nextInt(var4);
                int k = var3 + var6.nextInt(var5);
                int l = j;
                int i1 = k;

                for (int j1 = 0; j1 < i; j1++) {
                    boolean flag = false;

                    for (int k1 = 0; !flag && k1 < 4; k1++) {
                        BlockPos blockpos = var0.getTopSolidOrLiquidBlock(new BlockPos(j, 0, k));
                        if (canCreatureTypeSpawnAtLocation(EntityLiving.SpawnPlacementType.ON_GROUND, var0, blockpos)) {
                            EntityLiving entityliving;
                            try {
                                entityliving = (EntityLiving)biomegenbase$spawnlistentry.entityClass.getConstructor(World.class).newInstance(var0);
                            } catch (Exception exception) {
                                exception.printStackTrace();
                                continue;
                            }

                            entityliving.setLocationAndAngles(j + 0.5F, blockpos.getY(), k + 0.5F, var6.nextFloat() * 360.0F, 0.0F);
                            var0.spawnEntityInWorld(entityliving);
                            ientitylivingdata = entityliving.onInitialSpawn(var0.getDifficultyForLocation(new BlockPos(entityliving)), ientitylivingdata);
                            flag = true;
                        }

                        j += var6.nextInt(5) - var6.nextInt(5);

                        for (k += var6.nextInt(5) - var6.nextInt(5);
                            j < var2 || j >= var2 + var4 || k < var3 || k >= var3 + var4;
                            k = i1 + var6.nextInt(5) - var6.nextInt(5)
                        ) {
                            j = l + var6.nextInt(5) - var6.nextInt(5);
                        }
                    }
                }
            }
        }
    }
}
