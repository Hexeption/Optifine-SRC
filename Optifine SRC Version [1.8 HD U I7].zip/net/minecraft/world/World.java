package net.minecraft.world;

import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHopper;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.IEntitySelector;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.profiler.Profiler;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.gui.IUpdatePlayerListBox;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ReportedException;
import net.minecraft.util.Vec3;
import net.minecraft.village.VillageCollection;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldInfo;

public abstract class World implements IBlockAccess {
    protected boolean scheduledUpdatesAreImmediate;
    public final List loadedEntityList = Lists.newArrayList();
    protected final List unloadedEntityList = Lists.newArrayList();
    public final List loadedTileEntityList = Lists.newArrayList();
    public final List tickableTileEntities = Lists.newArrayList();
    private final List addedTileEntityList = Lists.newArrayList();
    private final List tileEntitiesToBeRemoved = Lists.newArrayList();
    public final List playerEntities = Lists.newArrayList();
    public final List weatherEffects = Lists.newArrayList();
    protected final IntHashMap entitiesById = new IntHashMap();
    private long cloudColour = 16777215L;
    private int skylightSubtracted;
    protected int updateLCG = new Random().nextInt();
    protected final int DIST_HASH_MAGIC = 1013904223;
    protected float prevRainingStrength;
    protected float rainingStrength;
    protected float prevThunderingStrength;
    protected float thunderingStrength;
    private int lastLightningBolt;
    public final Random rand = new Random();
    public final WorldProvider provider;
    protected List worldAccesses = Lists.newArrayList();
    protected IChunkProvider chunkProvider;
    protected final ISaveHandler saveHandler;
    protected WorldInfo worldInfo;
    protected boolean findingSpawnPoint;
    protected MapStorage mapStorage;
    protected VillageCollection villageCollectionObj;
    public final Profiler theProfiler;
    private final Calendar theCalendar = Calendar.getInstance();
    protected Scoreboard worldScoreboard = new Scoreboard();
    public final boolean isRemote;
    protected Set activeChunkSet = Sets.newHashSet();
    private int ambientTickCountdown = this.rand.nextInt(12000);
    protected boolean spawnHostileMobs = true;
    protected boolean spawnPeacefulMobs = true;
    private boolean processingLoadedTiles;
    private final WorldBorder worldBorder;
    int[] lightUpdateBlockList = new int[-Short.MIN_VALUE];

    protected World(ISaveHandler var1, WorldInfo var2, WorldProvider var3, Profiler var4, boolean var5) {
        this.saveHandler = var1;
        this.theProfiler = var4;
        this.worldInfo = var2;
        this.provider = var3;
        this.isRemote = var5;
        this.worldBorder = var3.getWorldBorder();
    }

    public World init() {
        return this;
    }

    @Override
    public BiomeGenBase getBiomeGenForCoords(final BlockPos var1) {
        if (this.isBlockLoaded(var1)) {
            Chunk chunk = this.getChunkFromBlockCoords(var1);

            try {
                return chunk.getBiome(var1, this.provider.getWorldChunkManager());
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Getting biome");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Coordinates of biome request");
                crashreportcategory.addCrashSectionCallable("Location", new Callable() {
                    public String call() {
                        return CrashReportCategory.getCoordinateInfo(var1);
                    }
                });
                throw new ReportedException(crashreport);
            }
        } else {
            return this.provider.getWorldChunkManager().getBiomeGenerator(var1, BiomeGenBase.plains);
        }
    }

    public WorldChunkManager getWorldChunkManager() {
        return this.provider.getWorldChunkManager();
    }

    protected abstract IChunkProvider createChunkProvider();

    public void initialize(WorldSettings var1) {
        this.worldInfo.setServerInitialized(true);
    }

    public void setInitialSpawnLocation() {
        this.setSpawnPoint(new BlockPos(8, 64, 8));
    }

    public Block getGroundAboveSeaLevel(BlockPos var1) {
        BlockPos blockpos = new BlockPos(var1.getX(), 63, var1.getZ());

        while (!this.isAirBlock(blockpos.up())) {
            blockpos = blockpos.up();
        }

        return this.getBlockState(blockpos).getBlock();
    }

    private boolean isValid(BlockPos var1) {
        return var1.getX() >= -30000000
            && var1.getZ() >= -30000000
            && var1.getX() < 30000000
            && var1.getZ() < 30000000
            && var1.getY() >= 0
            && var1.getY() < 256;
    }

    @Override
    public boolean isAirBlock(BlockPos var1) {
        return this.getBlockState(var1).getBlock().getMaterial() == Material.air;
    }

    public boolean isBlockLoaded(BlockPos var1) {
        return this.isBlockLoaded(var1, true);
    }

    public boolean isBlockLoaded(BlockPos var1, boolean var2) {
        return !this.isValid(var1) ? false : this.isChunkLoaded(var1.getX() >> 4, var1.getZ() >> 4, var2);
    }

    public boolean isAreaLoaded(BlockPos var1, int var2) {
        return this.isAreaLoaded(var1, var2, true);
    }

    public boolean isAreaLoaded(BlockPos var1, int var2, boolean var3) {
        return this.isAreaLoaded(var1.getX() - var2, var1.getY() - var2, var1.getZ() - var2, var1.getX() + var2, var1.getY() + var2, var1.getZ() + var2, var3);
    }

    public boolean isAreaLoaded(BlockPos var1, BlockPos var2) {
        return this.isAreaLoaded(var1, var2, true);
    }

    public boolean isAreaLoaded(BlockPos var1, BlockPos var2, boolean var3) {
        return this.isAreaLoaded(var1.getX(), var1.getY(), var1.getZ(), var2.getX(), var2.getY(), var2.getZ(), var3);
    }

    public boolean isAreaLoaded(StructureBoundingBox var1) {
        return this.isAreaLoaded(var1, true);
    }

    public boolean isAreaLoaded(StructureBoundingBox var1, boolean var2) {
        return this.isAreaLoaded(var1.minX, var1.minY, var1.minZ, var1.maxX, var1.maxY, var1.maxZ, var2);
    }

    private boolean isAreaLoaded(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7) {
        if (var5 >= 0 && var2 < 256) {
            var1 >>= 4;
            var3 >>= 4;
            var4 >>= 4;
            var6 >>= 4;

            for (int i = var1; i <= var4; i++) {
                for (int j = var3; j <= var6; j++) {
                    if (!this.isChunkLoaded(i, j, var7)) {
                        return false;
                    }
                }
            }

            return true;
        } else {
            return false;
        }
    }

    protected boolean isChunkLoaded(int var1, int var2, boolean var3) {
        return this.chunkProvider.chunkExists(var1, var2) && (var3 || !this.chunkProvider.provideChunk(var1, var2).isEmpty());
    }

    public Chunk getChunkFromBlockCoords(BlockPos var1) {
        return this.getChunkFromChunkCoords(var1.getX() >> 4, var1.getZ() >> 4);
    }

    public Chunk getChunkFromChunkCoords(int var1, int var2) {
        return this.chunkProvider.provideChunk(var1, var2);
    }

    public boolean setBlockState(BlockPos var1, IBlockState var2, int var3) {
        if (!this.isValid(var1)) {
            return false;
        }

        if (!this.isRemote && this.worldInfo.getTerrainType() == WorldType.DEBUG_WORLD) {
            return false;
        }

        Chunk chunk = this.getChunkFromBlockCoords(var1);
        Block block = var2.getBlock();
        IBlockState iblockstate = chunk.setBlockState(var1, var2);
        if (iblockstate == null) {
            return false;
        }

        Block block1 = iblockstate.getBlock();
        if (block.getLightOpacity() != block1.getLightOpacity() || block.getLightValue() != block1.getLightValue()) {
            this.theProfiler.startSection("checkLight");
            this.checkLight(var1);
            this.theProfiler.endSection();
        }

        if ((var3 & 2) != 0 && (!this.isRemote || (var3 & 4) == 0) && chunk.isPopulated()) {
            this.markBlockForUpdate(var1);
        }

        if (!this.isRemote && (var3 & 1) != 0) {
            this.notifyNeighborsRespectDebug(var1, iblockstate.getBlock());
            if (block.hasComparatorInputOverride()) {
                this.updateComparatorOutputLevel(var1, block);
            }
        }

        return true;
    }

    public boolean setBlockToAir(BlockPos var1) {
        return this.setBlockState(var1, Blocks.air.getDefaultState(), 3);
    }

    public boolean destroyBlock(BlockPos var1, boolean var2) {
        IBlockState iblockstate = this.getBlockState(var1);
        Block block = iblockstate.getBlock();
        if (block.getMaterial() == Material.air) {
            return false;
        }

        this.playAuxSFX(2001, var1, Block.getStateId(iblockstate));
        if (var2) {
            block.dropBlockAsItem(this, var1, iblockstate, 0);
        }

        return this.setBlockState(var1, Blocks.air.getDefaultState(), 3);
    }

    public boolean setBlockState(BlockPos var1, IBlockState var2) {
        return this.setBlockState(var1, var2, 3);
    }

    public void markBlockForUpdate(BlockPos var1) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).markBlockForUpdate(var1);
        }
    }

    public void notifyNeighborsRespectDebug(BlockPos var1, Block var2) {
        if (this.worldInfo.getTerrainType() != WorldType.DEBUG_WORLD) {
            this.notifyNeighborsOfStateChange(var1, var2);
        }
    }

    public void markBlocksDirtyVertical(int var1, int var2, int var3, int var4) {
        if (var3 > var4) {
            int i = var4;
            var4 = var3;
            var3 = i;
        }

        if (!this.provider.getHasNoSky()) {
            for (int j = var3; j <= var4; j++) {
                this.checkLightFor(EnumSkyBlock.SKY, new BlockPos(var1, j, var2));
            }
        }

        this.markBlockRangeForRenderUpdate(var1, var3, var2, var1, var4, var2);
    }

    public void markBlockRangeForRenderUpdate(BlockPos var1, BlockPos var2) {
        this.markBlockRangeForRenderUpdate(var1.getX(), var1.getY(), var1.getZ(), var2.getX(), var2.getY(), var2.getZ());
    }

    public void markBlockRangeForRenderUpdate(int var1, int var2, int var3, int var4, int var5, int var6) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).markBlockRangeForRenderUpdate(var1, var2, var3, var4, var5, var6);
        }
    }

    public void notifyNeighborsOfStateChange(BlockPos var1, Block var2) {
        this.notifyBlockOfStateChange(var1.west(), var2);
        this.notifyBlockOfStateChange(var1.east(), var2);
        this.notifyBlockOfStateChange(var1.down(), var2);
        this.notifyBlockOfStateChange(var1.up(), var2);
        this.notifyBlockOfStateChange(var1.north(), var2);
        this.notifyBlockOfStateChange(var1.south(), var2);
    }

    public void notifyNeighborsOfStateExcept(BlockPos var1, Block var2, EnumFacing var3) {
        if (var3 != EnumFacing.WEST) {
            this.notifyBlockOfStateChange(var1.west(), var2);
        }

        if (var3 != EnumFacing.EAST) {
            this.notifyBlockOfStateChange(var1.east(), var2);
        }

        if (var3 != EnumFacing.DOWN) {
            this.notifyBlockOfStateChange(var1.down(), var2);
        }

        if (var3 != EnumFacing.UP) {
            this.notifyBlockOfStateChange(var1.up(), var2);
        }

        if (var3 != EnumFacing.NORTH) {
            this.notifyBlockOfStateChange(var1.north(), var2);
        }

        if (var3 != EnumFacing.SOUTH) {
            this.notifyBlockOfStateChange(var1.south(), var2);
        }
    }

    public void notifyBlockOfStateChange(BlockPos var1, final Block var2) {
        if (!this.isRemote) {
            IBlockState iblockstate = this.getBlockState(var1);

            try {
                iblockstate.getBlock().onNeighborBlockChange(this, var1, iblockstate, var2);
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Exception while updating neighbours");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being updated");
                crashreportcategory.addCrashSectionCallable(
                    "Source block type",
                    new Callable() {
                        public String call() {
                            try {
                                return String.format(
                                    "ID #%d (%s // %s)", Block.getIdFromBlock(var2), var2.getUnlocalizedName(), var2.getClass().getCanonicalName()
                                );
                            } catch (Throwable throwable1) {
                                return "ID #" + Block.getIdFromBlock(var2);
                            }
                        }
                    }
                );
                CrashReportCategory.addBlockInfo(crashreportcategory, var1, iblockstate);
                throw new ReportedException(crashreport);
            }
        }
    }

    public boolean isBlockTickPending(BlockPos var1, Block var2) {
        return false;
    }

    public boolean canSeeSky(BlockPos var1) {
        return this.getChunkFromBlockCoords(var1).canSeeSky(var1);
    }

    public boolean canBlockSeeSky(BlockPos var1) {
        if (var1.getY() >= 63) {
            return this.canSeeSky(var1);
        }

        BlockPos blockpos = new BlockPos(var1.getX(), 63, var1.getZ());
        if (!this.canSeeSky(blockpos)) {
            return false;
        }

        for (BlockPos blockpos1 = blockpos.down(); blockpos1.getY() > var1.getY(); blockpos1 = blockpos1.down()) {
            Block block = this.getBlockState(blockpos1).getBlock();
            if (block.getLightOpacity() > 0 && !block.getMaterial().isLiquid()) {
                return false;
            }
        }

        return true;
    }

    public int getLight(BlockPos var1) {
        if (var1.getY() < 0) {
            return 0;
        }

        if (var1.getY() >= 256) {
            var1 = new BlockPos(var1.getX(), 255, var1.getZ());
        }

        return this.getChunkFromBlockCoords(var1).getLightSubtracted(var1, 0);
    }

    public int getLightFromNeighbors(BlockPos var1) {
        return this.getLight(var1, true);
    }

    public int getLight(BlockPos var1, boolean var2) {
        if (var1.getX() < -30000000 || var1.getZ() < -30000000 || var1.getX() >= 30000000 || var1.getZ() >= 30000000) {
            return 15;
        }

        if (var2 && this.getBlockState(var1).getBlock().getUseNeighborBrightness()) {
            int i1 = this.getLight(var1.up(), false);
            int i = this.getLight(var1.east(), false);
            int j = this.getLight(var1.west(), false);
            int k = this.getLight(var1.south(), false);
            int l = this.getLight(var1.north(), false);
            if (i > i1) {
                i1 = i;
            }

            if (j > i1) {
                i1 = j;
            }

            if (k > i1) {
                i1 = k;
            }

            if (l > i1) {
                i1 = l;
            }

            return i1;
        } else {
            if (var1.getY() < 0) {
                return 0;
            }

            if (var1.getY() >= 256) {
                var1 = new BlockPos(var1.getX(), 255, var1.getZ());
            }

            Chunk chunk = this.getChunkFromBlockCoords(var1);
            return chunk.getLightSubtracted(var1, this.skylightSubtracted);
        }
    }

    public BlockPos getHeight(BlockPos var1) {
        int i;
        if (var1.getX() >= -30000000 && var1.getZ() >= -30000000 && var1.getX() < 30000000 && var1.getZ() < 30000000) {
            if (this.isChunkLoaded(var1.getX() >> 4, var1.getZ() >> 4, true)) {
                i = this.getChunkFromChunkCoords(var1.getX() >> 4, var1.getZ() >> 4).getHeightValue(var1.getX() & 15, var1.getZ() & 15);
            } else {
                i = 0;
            }
        } else {
            i = 64;
        }

        return new BlockPos(var1.getX(), i, var1.getZ());
    }

    public int getChunksLowestHorizon(int var1, int var2) {
        if (var1 >= -30000000 && var2 >= -30000000 && var1 < 30000000 && var2 < 30000000) {
            if (!this.isChunkLoaded(var1 >> 4, var2 >> 4, true)) {
                return 0;
            }

            Chunk chunk = this.getChunkFromChunkCoords(var1 >> 4, var2 >> 4);
            return chunk.getLowestHeight();
        } else {
            return 64;
        }
    }

    public int getLightFromNeighborsFor(EnumSkyBlock var1, BlockPos var2) {
        if (this.provider.getHasNoSky() && var1 == EnumSkyBlock.SKY) {
            return 0;
        }

        if (var2.getY() < 0) {
            var2 = new BlockPos(var2.getX(), 0, var2.getZ());
        }

        if (!this.isValid(var2)) {
            return var1.defaultLightValue;
        }

        if (!this.isBlockLoaded(var2)) {
            return var1.defaultLightValue;
        }

        if (this.getBlockState(var2).getBlock().getUseNeighborBrightness()) {
            int i1 = this.getLightFor(var1, var2.up());
            int i = this.getLightFor(var1, var2.east());
            int j = this.getLightFor(var1, var2.west());
            int k = this.getLightFor(var1, var2.south());
            int l = this.getLightFor(var1, var2.north());
            if (i > i1) {
                i1 = i;
            }

            if (j > i1) {
                i1 = j;
            }

            if (k > i1) {
                i1 = k;
            }

            if (l > i1) {
                i1 = l;
            }

            return i1;
        } else {
            Chunk chunk = this.getChunkFromBlockCoords(var2);
            return chunk.getLightFor(var1, var2);
        }
    }

    public int getLightFor(EnumSkyBlock var1, BlockPos var2) {
        if (var2.getY() < 0) {
            var2 = new BlockPos(var2.getX(), 0, var2.getZ());
        }

        if (!this.isValid(var2)) {
            return var1.defaultLightValue;
        }

        if (!this.isBlockLoaded(var2)) {
            return var1.defaultLightValue;
        }

        Chunk chunk = this.getChunkFromBlockCoords(var2);
        return chunk.getLightFor(var1, var2);
    }

    public void setLightFor(EnumSkyBlock var1, BlockPos var2, int var3) {
        if (this.isValid(var2)) {
            if (this.isBlockLoaded(var2)) {
                Chunk chunk = this.getChunkFromBlockCoords(var2);
                chunk.setLightFor(var1, var2, var3);
                this.notifyLightSet(var2);
            }
        }
    }

    public void notifyLightSet(BlockPos var1) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).notifyLightSet(var1);
        }
    }

    @Override
    public int getCombinedLight(BlockPos var1, int var2) {
        int i = this.getLightFromNeighborsFor(EnumSkyBlock.SKY, var1);
        int j = this.getLightFromNeighborsFor(EnumSkyBlock.BLOCK, var1);
        if (j < var2) {
            j = var2;
        }

        return i << 20 | j << 4;
    }

    public float getLightBrightness(BlockPos var1) {
        return this.provider.getLightBrightnessTable()[this.getLightFromNeighbors(var1)];
    }

    @Override
    public IBlockState getBlockState(BlockPos var1) {
        if (!this.isValid(var1)) {
            return Blocks.air.getDefaultState();
        }

        Chunk chunk = this.getChunkFromBlockCoords(var1);
        return chunk.getBlockState(var1);
    }

    public boolean isDaytime() {
        return this.skylightSubtracted < 4;
    }

    public MovingObjectPosition rayTraceBlocks(Vec3 var1, Vec3 var2) {
        return this.rayTraceBlocks(var1, var2, false, false, false);
    }

    public MovingObjectPosition rayTraceBlocks(Vec3 var1, Vec3 var2, boolean var3) {
        return this.rayTraceBlocks(var1, var2, var3, false, false);
    }

    public MovingObjectPosition rayTraceBlocks(Vec3 var1, Vec3 var2, boolean var3, boolean var4, boolean var5) {
        if (Double.isNaN(var1.xCoord) || Double.isNaN(var1.yCoord) || Double.isNaN(var1.zCoord)) {
            return null;
        }

        if (!Double.isNaN(var2.xCoord) && !Double.isNaN(var2.yCoord) && !Double.isNaN(var2.zCoord)) {
            int i = MathHelper.floor_double(var2.xCoord);
            int j = MathHelper.floor_double(var2.yCoord);
            int k = MathHelper.floor_double(var2.zCoord);
            int l = MathHelper.floor_double(var1.xCoord);
            int i1 = MathHelper.floor_double(var1.yCoord);
            int j1 = MathHelper.floor_double(var1.zCoord);
            BlockPos blockpos = new BlockPos(l, i1, j1);
            new BlockPos(i, j, k);
            IBlockState iblockstate = this.getBlockState(blockpos);
            Block block = iblockstate.getBlock();
            if ((!var4 || block.getCollisionBoundingBox(this, blockpos, iblockstate) != null) && block.canCollideCheck(iblockstate, var3)) {
                MovingObjectPosition movingobjectposition = block.collisionRayTrace(this, blockpos, var1, var2);
                if (movingobjectposition != null) {
                    return movingobjectposition;
                }
            }

            MovingObjectPosition movingobjectposition2 = null;
            int k1 = 200;

            while (k1-- >= 0) {
                if (Double.isNaN(var1.xCoord) || Double.isNaN(var1.yCoord) || Double.isNaN(var1.zCoord)) {
                    return null;
                }

                if (l == i && i1 == j && j1 == k) {
                    return var5 ? movingobjectposition2 : null;
                }

                boolean flag2 = true;
                boolean flag = true;
                boolean flag1 = true;
                double d0 = 999.0;
                double d1 = 999.0;
                double d2 = 999.0;
                if (i > l) {
                    d0 = l + 1.0;
                } else if (i < l) {
                    d0 = l + 0.0;
                } else {
                    flag2 = false;
                }

                if (j > i1) {
                    d1 = i1 + 1.0;
                } else if (j < i1) {
                    d1 = i1 + 0.0;
                } else {
                    flag = false;
                }

                if (k > j1) {
                    d2 = j1 + 1.0;
                } else if (k < j1) {
                    d2 = j1 + 0.0;
                } else {
                    flag1 = false;
                }

                double d3 = 999.0;
                double d4 = 999.0;
                double d5 = 999.0;
                double d6 = var2.xCoord - var1.xCoord;
                double d7 = var2.yCoord - var1.yCoord;
                double d8 = var2.zCoord - var1.zCoord;
                if (flag2) {
                    d3 = (d0 - var1.xCoord) / d6;
                }

                if (flag) {
                    d4 = (d1 - var1.yCoord) / d7;
                }

                if (flag1) {
                    d5 = (d2 - var1.zCoord) / d8;
                }

                if (d3 == -0.0) {
                    d3 = -1.0E-4;
                }

                if (d4 == -0.0) {
                    d4 = -1.0E-4;
                }

                if (d5 == -0.0) {
                    d5 = -1.0E-4;
                }

                EnumFacing enumfacing;
                if (d3 < d4 && d3 < d5) {
                    enumfacing = i > l ? EnumFacing.WEST : EnumFacing.EAST;
                    var1 = new Vec3(d0, var1.yCoord + d7 * d3, var1.zCoord + d8 * d3);
                } else if (d4 < d5) {
                    enumfacing = j > i1 ? EnumFacing.DOWN : EnumFacing.UP;
                    var1 = new Vec3(var1.xCoord + d6 * d4, d1, var1.zCoord + d8 * d4);
                } else {
                    enumfacing = k > j1 ? EnumFacing.NORTH : EnumFacing.SOUTH;
                    var1 = new Vec3(var1.xCoord + d6 * d5, var1.yCoord + d7 * d5, d2);
                }

                l = MathHelper.floor_double(var1.xCoord) - (enumfacing == EnumFacing.EAST ? 1 : 0);
                i1 = MathHelper.floor_double(var1.yCoord) - (enumfacing == EnumFacing.UP ? 1 : 0);
                j1 = MathHelper.floor_double(var1.zCoord) - (enumfacing == EnumFacing.SOUTH ? 1 : 0);
                blockpos = new BlockPos(l, i1, j1);
                IBlockState iblockstate1 = this.getBlockState(blockpos);
                Block block1 = iblockstate1.getBlock();
                if (!var4 || block1.getCollisionBoundingBox(this, blockpos, iblockstate1) != null) {
                    if (block1.canCollideCheck(iblockstate1, var3)) {
                        MovingObjectPosition movingobjectposition1 = block1.collisionRayTrace(this, blockpos, var1, var2);
                        if (movingobjectposition1 != null) {
                            return movingobjectposition1;
                        }
                    } else {
                        movingobjectposition2 = new MovingObjectPosition(MovingObjectPosition.MovingObjectType.MISS, var1, enumfacing, blockpos);
                    }
                }
            }

            return var5 ? movingobjectposition2 : null;
        } else {
            return null;
        }
    }

    public void playSoundAtEntity(Entity var1, String var2, float var3, float var4) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playSound(var2, var1.posX, var1.posY, var1.posZ, var3, var4);
        }
    }

    public void playSoundToNearExcept(EntityPlayer var1, String var2, float var3, float var4) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playSoundToNearExcept(var1, var2, var1.posX, var1.posY, var1.posZ, var3, var4);
        }
    }

    public void playSoundEffect(double var1, double var3, double var5, String var7, float var8, float var9) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playSound(var7, var1, var3, var5, var8, var9);
        }
    }

    public void playSound(double var1, double var3, double var5, String var7, float var8, float var9, boolean var10) {
    }

    public void playRecord(BlockPos var1, String var2) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).playRecord(var2, var1);
        }
    }

    public void spawnParticle(EnumParticleTypes var1, double var2, double var4, double var6, double var8, double var10, double var12, int... var14) {
        this.spawnParticle(var1.getParticleID(), var1.getShouldIgnoreRange(), var2, var4, var6, var8, var10, var12, var14);
    }

    public void spawnParticle(
        EnumParticleTypes var1, boolean var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15
    ) {
        this.spawnParticle(var1.getParticleID(), var1.getShouldIgnoreRange() | var2, var3, var5, var7, var9, var11, var13, var15);
    }

    private void spawnParticle(int var1, boolean var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).spawnParticle(var1, var2, var3, var5, var7, var9, var11, var13, var15);
        }
    }

    public boolean addWeatherEffect(Entity var1) {
        this.weatherEffects.add(var1);
        return true;
    }

    public boolean spawnEntityInWorld(Entity var1) {
        int i = MathHelper.floor_double(var1.posX / 16.0);
        int j = MathHelper.floor_double(var1.posZ / 16.0);
        boolean flag = var1.forceSpawn;
        if (var1 instanceof EntityPlayer) {
            flag = true;
        }

        if (!flag && !this.isChunkLoaded(i, j, true)) {
            return false;
        }

        if (var1 instanceof EntityPlayer) {
            EntityPlayer entityplayer = (EntityPlayer)var1;
            this.playerEntities.add(entityplayer);
            this.updateAllPlayersSleepingFlag();
        }

        this.getChunkFromChunkCoords(i, j).addEntity(var1);
        this.loadedEntityList.add(var1);
        this.onEntityAdded(var1);
        return true;
    }

    protected void onEntityAdded(Entity var1) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).onEntityAdded(var1);
        }
    }

    protected void onEntityRemoved(Entity var1) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).onEntityRemoved(var1);
        }
    }

    public void removeEntity(Entity var1) {
        if (var1.riddenByEntity != null) {
            var1.riddenByEntity.mountEntity(null);
        }

        if (var1.ridingEntity != null) {
            var1.mountEntity(null);
        }

        var1.setDead();
        if (var1 instanceof EntityPlayer) {
            this.playerEntities.remove(var1);
            this.updateAllPlayersSleepingFlag();
            this.onEntityRemoved(var1);
        }
    }

    public void removePlayerEntityDangerously(Entity var1) {
        var1.setDead();
        if (var1 instanceof EntityPlayer) {
            this.playerEntities.remove(var1);
            this.updateAllPlayersSleepingFlag();
        }

        int i = var1.chunkCoordX;
        int j = var1.chunkCoordZ;
        if (var1.addedToChunk && this.isChunkLoaded(i, j, true)) {
            this.getChunkFromChunkCoords(i, j).removeEntity(var1);
        }

        this.loadedEntityList.remove(var1);
        this.onEntityRemoved(var1);
    }

    public void addWorldAccess(IWorldAccess var1) {
        this.worldAccesses.add(var1);
    }

    public void removeWorldAccess(IWorldAccess var1) {
        this.worldAccesses.remove(var1);
    }

    public List getCollidingBoundingBoxes(Entity var1, AxisAlignedBB var2) {
        ArrayList arraylist = Lists.newArrayList();
        int i = MathHelper.floor_double(var2.minX);
        int j = MathHelper.floor_double(var2.maxX + 1.0);
        int k = MathHelper.floor_double(var2.minY);
        int l = MathHelper.floor_double(var2.maxY + 1.0);
        int i1 = MathHelper.floor_double(var2.minZ);
        int j1 = MathHelper.floor_double(var2.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = i1; l1 < j1; l1++) {
                if (this.isBlockLoaded(new BlockPos(k1, 64, l1))) {
                    for (int i2 = k - 1; i2 < l; i2++) {
                        BlockPos blockpos = new BlockPos(k1, i2, l1);
                        boolean flag = var1.isOutsideBorder();
                        boolean flag1 = this.isInsideBorder(this.getWorldBorder(), var1);
                        if (flag && flag1) {
                            var1.setOutsideBorder(false);
                        } else if (!flag && !flag1) {
                            var1.setOutsideBorder(true);
                        }

                        IBlockState iblockstate;
                        if (!this.getWorldBorder().contains(blockpos) && flag1) {
                            iblockstate = Blocks.stone.getDefaultState();
                        } else {
                            iblockstate = this.getBlockState(blockpos);
                        }

                        iblockstate.getBlock().addCollisionBoxesToList(this, blockpos, iblockstate, var2, arraylist, var1);
                    }
                }
            }
        }

        double d0 = 0.25;
        List list = this.getEntitiesWithinAABBExcludingEntity(var1, var2.expand(d0, d0, d0));

        for (int j2 = 0; j2 < list.size(); j2++) {
            if (var1.riddenByEntity != list && var1.ridingEntity != list) {
                AxisAlignedBB axisalignedbb = ((Entity)list.get(j2)).getCollisionBoundingBox();
                if (axisalignedbb != null && axisalignedbb.intersectsWith(var2)) {
                    arraylist.add(axisalignedbb);
                }

                axisalignedbb = var1.getCollisionBox((Entity)list.get(j2));
                if (axisalignedbb != null && axisalignedbb.intersectsWith(var2)) {
                    arraylist.add(axisalignedbb);
                }
            }
        }

        return arraylist;
    }

    public boolean isInsideBorder(WorldBorder var1, Entity var2) {
        double d0 = var1.minX();
        double d1 = var1.minZ();
        double d2 = var1.maxX();
        double d3 = var1.maxZ();
        if (var2.isOutsideBorder()) {
            d0++;
            d1++;
            d2--;
            d3--;
        } else {
            d0--;
            d1--;
            d2++;
            d3++;
        }

        return var2.posX > d0 && var2.posX < d2 && var2.posZ > d1 && var2.posZ < d3;
    }

    public List func_147461_a(AxisAlignedBB var1) {
        ArrayList arraylist = Lists.newArrayList();
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = i1; l1 < j1; l1++) {
                if (this.isBlockLoaded(new BlockPos(k1, 64, l1))) {
                    for (int i2 = k - 1; i2 < l; i2++) {
                        BlockPos blockpos = new BlockPos(k1, i2, l1);
                        IBlockState iblockstate;
                        if (k1 >= -30000000 && k1 < 30000000 && l1 >= -30000000 && l1 < 30000000) {
                            iblockstate = this.getBlockState(blockpos);
                        } else {
                            iblockstate = Blocks.bedrock.getDefaultState();
                        }

                        iblockstate.getBlock().addCollisionBoxesToList(this, blockpos, iblockstate, var1, arraylist, null);
                    }
                }
            }
        }

        return arraylist;
    }

    public int calculateSkylightSubtracted(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = 1.0F - (MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.5F);
        f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
        f1 = 1.0F - f1;
        f1 = (float)(f1 * (1.0 - this.getRainStrength(var1) * 5.0F / 16.0));
        f1 = (float)(f1 * (1.0 - this.getThunderStrength(var1) * 5.0F / 16.0));
        f1 = 1.0F - f1;
        return (int)(f1 * 11.0F);
    }

    public float getSunBrightness(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = 1.0F - (MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.2F);
        f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
        f1 = 1.0F - f1;
        f1 = (float)(f1 * (1.0 - this.getRainStrength(var1) * 5.0F / 16.0));
        f1 = (float)(f1 * (1.0 - this.getThunderStrength(var1) * 5.0F / 16.0));
        return f1 * 0.8F + 0.2F;
    }

    public Vec3 getSkyColor(Entity var1, float var2) {
        float f = this.getCelestialAngle(var2);
        float f1 = MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.5F;
        f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posY);
        int k = MathHelper.floor_double(var1.posZ);
        BlockPos blockpos = new BlockPos(i, j, k);
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(blockpos);
        float f2 = biomegenbase.getFloatTemperature(blockpos);
        int l = biomegenbase.getSkyColorByTemp(f2);
        float f3 = (l >> 16 & 0xFF) / 255.0F;
        float f4 = (l >> 8 & 0xFF) / 255.0F;
        float f5 = (l & 0xFF) / 255.0F;
        f3 *= f1;
        f4 *= f1;
        f5 *= f1;
        float f6 = this.getRainStrength(var2);
        if (f6 > 0.0F) {
            float f7 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.6F;
            float f8 = 1.0F - f6 * (12.0F / 16.0F);
            f3 = f3 * f8 + f7 * (1.0F - f8);
            f4 = f4 * f8 + f7 * (1.0F - f8);
            f5 = f5 * f8 + f7 * (1.0F - f8);
        }

        float f10 = this.getThunderStrength(var2);
        if (f10 > 0.0F) {
            float f11 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.2F;
            float f9 = 1.0F - f10 * (12.0F / 16.0F);
            f3 = f3 * f9 + f11 * (1.0F - f9);
            f4 = f4 * f9 + f11 * (1.0F - f9);
            f5 = f5 * f9 + f11 * (1.0F - f9);
        }

        if (this.lastLightningBolt > 0) {
            float f12 = this.lastLightningBolt - var2;
            if (f12 > 1.0F) {
                f12 = 1.0F;
            }

            f12 *= 0.45F;
            f3 = f3 * (1.0F - f12) + 0.8F * f12;
            f4 = f4 * (1.0F - f12) + 0.8F * f12;
            f5 = f5 * (1.0F - f12) + 1.0F * f12;
        }

        return new Vec3(f3, f4, f5);
    }

    public float getCelestialAngle(float var1) {
        return this.provider.calculateCelestialAngle(this.worldInfo.getWorldTime(), var1);
    }

    public int getMoonPhase() {
        return this.provider.getMoonPhase(this.worldInfo.getWorldTime());
    }

    public float getCurrentMoonPhaseFactor() {
        return WorldProvider.moonPhaseFactors[this.provider.getMoonPhase(this.worldInfo.getWorldTime())];
    }

    public float getCelestialAngleRadians(float var1) {
        float f = this.getCelestialAngle(var1);
        return f * (float)Math.PI * 2.0F;
    }

    public Vec3 getCloudColour(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.5F;
        f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
        float f2 = (float)(this.cloudColour >> 16 & 255L) / 255.0F;
        float f3 = (float)(this.cloudColour >> 8 & 255L) / 255.0F;
        float f4 = (float)(this.cloudColour & 255L) / 255.0F;
        float f5 = this.getRainStrength(var1);
        if (f5 > 0.0F) {
            float f6 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.6F;
            float f7 = 1.0F - f5 * 0.95F;
            f2 = f2 * f7 + f6 * (1.0F - f7);
            f3 = f3 * f7 + f6 * (1.0F - f7);
            f4 = f4 * f7 + f6 * (1.0F - f7);
        }

        f2 *= f1 * 0.9F + 0.1F;
        f3 *= f1 * 0.9F + 0.1F;
        f4 *= f1 * 0.85F + 0.15F;
        float f9 = this.getThunderStrength(var1);
        if (f9 > 0.0F) {
            float f10 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.2F;
            float f8 = 1.0F - f9 * 0.95F;
            f2 = f2 * f8 + f10 * (1.0F - f8);
            f3 = f3 * f8 + f10 * (1.0F - f8);
            f4 = f4 * f8 + f10 * (1.0F - f8);
        }

        return new Vec3(f2, f3, f4);
    }

    public Vec3 getFogColor(float var1) {
        float f = this.getCelestialAngle(var1);
        return this.provider.getFogColor(f, var1);
    }

    public BlockPos getPrecipitationHeight(BlockPos var1) {
        return this.getChunkFromBlockCoords(var1).getPrecipitationHeight(var1);
    }

    public BlockPos getTopSolidOrLiquidBlock(BlockPos var1) {
        Chunk chunk = this.getChunkFromBlockCoords(var1);
        BlockPos blockpos = new BlockPos(var1.getX(), chunk.getTopFilledSegment() + 16, var1.getZ());

        while (blockpos.getY() >= 0) {
            BlockPos blockpos1 = blockpos.down();
            Material material = chunk.getBlock(blockpos1).getMaterial();
            if (material.blocksMovement() && material != Material.leaves) {
                break;
            }

            blockpos = blockpos1;
        }

        return blockpos;
    }

    public float getStarBrightness(float var1) {
        float f = this.getCelestialAngle(var1);
        float f1 = 1.0F - (MathHelper.cos(f * (float)Math.PI * 2.0F) * 2.0F + 0.25F);
        f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
        return f1 * f1 * 0.5F;
    }

    public void scheduleUpdate(BlockPos var1, Block var2, int var3) {
    }

    public void updateBlockTick(BlockPos var1, Block var2, int var3, int var4) {
    }

    public void scheduleBlockUpdate(BlockPos var1, Block var2, int var3, int var4) {
    }

    public void updateEntities() {
        this.theProfiler.startSection("entities");
        this.theProfiler.startSection("global");

        for (int i = 0; i < this.weatherEffects.size(); i++) {
            Entity entity = (Entity)this.weatherEffects.get(i);

            try {
                entity.ticksExisted++;
                entity.onUpdate();
            } catch (Throwable throwable2) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable2, "Ticking entity");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being ticked");
                if (entity == null) {
                    crashreportcategory.addCrashSection("Entity", "~~NULL~~");
                } else {
                    entity.addEntityCrashInfo(crashreportcategory);
                }

                throw new ReportedException(crashreport);
            }

            if (entity.isDead) {
                this.weatherEffects.remove(i--);
            }
        }

        this.theProfiler.endStartSection("remove");
        this.loadedEntityList.removeAll(this.unloadedEntityList);

        for (int k = 0; k < this.unloadedEntityList.size(); k++) {
            Entity entity1 = (Entity)this.unloadedEntityList.get(k);
            int j = entity1.chunkCoordX;
            int l1 = entity1.chunkCoordZ;
            if (entity1.addedToChunk && this.isChunkLoaded(j, l1, true)) {
                this.getChunkFromChunkCoords(j, l1).removeEntity(entity1);
            }
        }

        for (int l = 0; l < this.unloadedEntityList.size(); l++) {
            this.onEntityRemoved((Entity)this.unloadedEntityList.get(l));
        }

        this.unloadedEntityList.clear();
        this.theProfiler.endStartSection("regular");

        for (int i1 = 0; i1 < this.loadedEntityList.size(); i1++) {
            Entity entity2 = (Entity)this.loadedEntityList.get(i1);
            if (entity2.ridingEntity != null) {
                if (!entity2.ridingEntity.isDead && entity2.ridingEntity.riddenByEntity == entity2) {
                    continue;
                }

                entity2.ridingEntity.riddenByEntity = null;
                entity2.ridingEntity = null;
            }

            this.theProfiler.startSection("tick");
            if (!entity2.isDead) {
                try {
                    this.updateEntity(entity2);
                } catch (Throwable throwable1) {
                    CrashReport crashreport1 = CrashReport.makeCrashReport(throwable1, "Ticking entity");
                    CrashReportCategory crashreportcategory2 = crashreport1.makeCategory("Entity being ticked");
                    entity2.addEntityCrashInfo(crashreportcategory2);
                    throw new ReportedException(crashreport1);
                }
            }

            this.theProfiler.endSection();
            this.theProfiler.startSection("remove");
            if (entity2.isDead) {
                int k1 = entity2.chunkCoordX;
                int i2 = entity2.chunkCoordZ;
                if (entity2.addedToChunk && this.isChunkLoaded(k1, i2, true)) {
                    this.getChunkFromChunkCoords(k1, i2).removeEntity(entity2);
                }

                this.loadedEntityList.remove(i1--);
                this.onEntityRemoved(entity2);
            }

            this.theProfiler.endSection();
        }

        this.theProfiler.endStartSection("blockEntities");
        this.processingLoadedTiles = true;
        Iterator iterator = this.tickableTileEntities.iterator();

        while (iterator.hasNext()) {
            TileEntity tileentity = (TileEntity)iterator.next();
            if (!tileentity.isInvalid() && tileentity.hasWorldObj()) {
                BlockPos blockpos = tileentity.getPos();
                if (this.isBlockLoaded(blockpos) && this.worldBorder.contains(blockpos)) {
                    try {
                        ((IUpdatePlayerListBox)tileentity).update();
                    } catch (Throwable throwable) {
                        CrashReport crashreport2 = CrashReport.makeCrashReport(throwable, "Ticking block entity");
                        CrashReportCategory crashreportcategory1 = crashreport2.makeCategory("Block entity being ticked");
                        tileentity.addInfoToCrashReport(crashreportcategory1);
                        throw new ReportedException(crashreport2);
                    }
                }
            }

            if (tileentity.isInvalid()) {
                iterator.remove();
                this.loadedTileEntityList.remove(tileentity);
                if (this.isBlockLoaded(tileentity.getPos())) {
                    this.getChunkFromBlockCoords(tileentity.getPos()).removeTileEntity(tileentity.getPos());
                }
            }
        }

        this.processingLoadedTiles = false;
        if (!this.tileEntitiesToBeRemoved.isEmpty()) {
            this.tickableTileEntities.removeAll(this.tileEntitiesToBeRemoved);
            this.loadedTileEntityList.removeAll(this.tileEntitiesToBeRemoved);
            this.tileEntitiesToBeRemoved.clear();
        }

        this.theProfiler.endStartSection("pendingBlockEntities");
        if (!this.addedTileEntityList.isEmpty()) {
            for (int j1 = 0; j1 < this.addedTileEntityList.size(); j1++) {
                TileEntity tileentity1 = (TileEntity)this.addedTileEntityList.get(j1);
                if (!tileentity1.isInvalid()) {
                    if (!this.loadedTileEntityList.contains(tileentity1)) {
                        this.addTileEntity(tileentity1);
                    }

                    if (this.isBlockLoaded(tileentity1.getPos())) {
                        this.getChunkFromBlockCoords(tileentity1.getPos()).addTileEntity(tileentity1.getPos(), tileentity1);
                    }

                    this.markBlockForUpdate(tileentity1.getPos());
                }
            }

            this.addedTileEntityList.clear();
        }

        this.theProfiler.endSection();
        this.theProfiler.endSection();
    }

    public boolean addTileEntity(TileEntity var1) {
        boolean flag = this.loadedTileEntityList.add(var1);
        if (flag && var1 instanceof IUpdatePlayerListBox) {
            this.tickableTileEntities.add(var1);
        }

        return flag;
    }

    public void addTileEntities(Collection var1) {
        if (this.processingLoadedTiles) {
            this.addedTileEntityList.addAll(var1);
        } else {
            for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) var1) {
                this.loadedTileEntityList.add(tileentity);
                if (tileentity instanceof IUpdatePlayerListBox) {
                    this.tickableTileEntities.add(tileentity);
                }
            }
        }
    }

    public void updateEntity(Entity var1) {
        this.updateEntityWithOptionalForce(var1, true);
    }

    public void updateEntityWithOptionalForce(Entity var1, boolean var2) {
        int i = MathHelper.floor_double(var1.posX);
        int j = MathHelper.floor_double(var1.posZ);
        byte b0 = 32;
        if (!var2 || this.isAreaLoaded(i - b0, 0, j - b0, i + b0, 0, j + b0, true)) {
            var1.lastTickPosX = var1.posX;
            var1.lastTickPosY = var1.posY;
            var1.lastTickPosZ = var1.posZ;
            var1.prevRotationYaw = var1.rotationYaw;
            var1.prevRotationPitch = var1.rotationPitch;
            if (var2 && var1.addedToChunk) {
                var1.ticksExisted++;
                if (var1.ridingEntity != null) {
                    var1.updateRidden();
                } else {
                    var1.onUpdate();
                }
            }

            this.theProfiler.startSection("chunkCheck");
            if (Double.isNaN(var1.posX) || Double.isInfinite(var1.posX)) {
                var1.posX = var1.lastTickPosX;
            }

            if (Double.isNaN(var1.posY) || Double.isInfinite(var1.posY)) {
                var1.posY = var1.lastTickPosY;
            }

            if (Double.isNaN(var1.posZ) || Double.isInfinite(var1.posZ)) {
                var1.posZ = var1.lastTickPosZ;
            }

            if (Double.isNaN(var1.rotationPitch) || Double.isInfinite(var1.rotationPitch)) {
                var1.rotationPitch = var1.prevRotationPitch;
            }

            if (Double.isNaN(var1.rotationYaw) || Double.isInfinite(var1.rotationYaw)) {
                var1.rotationYaw = var1.prevRotationYaw;
            }

            int k = MathHelper.floor_double(var1.posX / 16.0);
            int l = MathHelper.floor_double(var1.posY / 16.0);
            int i1 = MathHelper.floor_double(var1.posZ / 16.0);
            if (!var1.addedToChunk || var1.chunkCoordX != k || var1.chunkCoordY != l || var1.chunkCoordZ != i1) {
                if (var1.addedToChunk && this.isChunkLoaded(var1.chunkCoordX, var1.chunkCoordZ, true)) {
                    this.getChunkFromChunkCoords(var1.chunkCoordX, var1.chunkCoordZ).removeEntityAtIndex(var1, var1.chunkCoordY);
                }

                if (this.isChunkLoaded(k, i1, true)) {
                    var1.addedToChunk = true;
                    this.getChunkFromChunkCoords(k, i1).addEntity(var1);
                } else {
                    var1.addedToChunk = false;
                }
            }

            this.theProfiler.endSection();
            if (var2 && var1.addedToChunk && var1.riddenByEntity != null) {
                if (!var1.riddenByEntity.isDead && var1.riddenByEntity.ridingEntity == var1) {
                    this.updateEntity(var1.riddenByEntity);
                } else {
                    var1.riddenByEntity.ridingEntity = null;
                    var1.riddenByEntity = null;
                }
            }
        }
    }

    public boolean checkNoEntityCollision(AxisAlignedBB var1) {
        return this.checkNoEntityCollision(var1, null);
    }

    public boolean checkNoEntityCollision(AxisAlignedBB var1, Entity var2) {
        List list = this.getEntitiesWithinAABBExcludingEntity(null, var1);

        for (int i = 0; i < list.size(); i++) {
            Entity entity = (Entity)list.get(i);
            if (!entity.isDead
                && entity.preventEntitySpawning
                && entity != var2
                && (var2 == null || var2.ridingEntity != entity && var2.riddenByEntity != entity)) {
                return false;
            }
        }

        return true;
    }

    public boolean checkBlockCollision(AxisAlignedBB var1) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ);

        for (int k1 = i; k1 <= j; k1++) {
            for (int l1 = k; l1 <= l; l1++) {
                for (int i2 = i1; i2 <= j1; i2++) {
                    Block block = this.getBlockState(new BlockPos(k1, l1, i2)).getBlock();
                    if (block.getMaterial() != Material.air) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean isAnyLiquid(AxisAlignedBB var1) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ);

        for (int k1 = i; k1 <= j; k1++) {
            for (int l1 = k; l1 <= l; l1++) {
                for (int i2 = i1; i2 <= j1; i2++) {
                    Block block = this.getBlockState(new BlockPos(k1, l1, i2)).getBlock();
                    if (block.getMaterial().isLiquid()) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean isFlammableWithin(AxisAlignedBB var1) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);
        if (this.isAreaLoaded(i, k, i1, j, l, j1, true)) {
            for (int k1 = i; k1 < j; k1++) {
                for (int l1 = k; l1 < l; l1++) {
                    for (int i2 = i1; i2 < j1; i2++) {
                        Block block = this.getBlockState(new BlockPos(k1, l1, i2)).getBlock();
                        if (block == Blocks.fire || block == Blocks.flowing_lava || block == Blocks.lava) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public boolean handleMaterialAcceleration(AxisAlignedBB var1, Material var2, Entity var3) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);
        if (!this.isAreaLoaded(i, k, i1, j, l, j1, true)) {
            return false;
        }

        boolean flag = false;
        Vec3 vec3 = new Vec3(0.0, 0.0, 0.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    BlockPos blockpos = new BlockPos(k1, l1, i2);
                    IBlockState iblockstate = this.getBlockState(blockpos);
                    Block block = iblockstate.getBlock();
                    if (block.getMaterial() == var2) {
                        double d0 = l1 + 1 - BlockLiquid.getLiquidHeightPercent((Integer)iblockstate.getValue(BlockLiquid.LEVEL));
                        if (l >= d0) {
                            flag = true;
                            vec3 = block.modifyAcceleration(this, blockpos, var3, vec3);
                        }
                    }
                }
            }
        }

        if (vec3.lengthVector() > 0.0 && var3.isPushedByWater()) {
            vec3 = vec3.normalize();
            double d1 = 0.014;
            var3.motionX = var3.motionX + vec3.xCoord * d1;
            var3.motionY = var3.motionY + vec3.yCoord * d1;
            var3.motionZ = var3.motionZ + vec3.zCoord * d1;
        }

        return flag;
    }

    public boolean isMaterialInBB(AxisAlignedBB var1, Material var2) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    if (this.getBlockState(new BlockPos(k1, l1, i2)).getBlock().getMaterial() == var2) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean isAABBInMaterial(AxisAlignedBB var1, Material var2) {
        int i = MathHelper.floor_double(var1.minX);
        int j = MathHelper.floor_double(var1.maxX + 1.0);
        int k = MathHelper.floor_double(var1.minY);
        int l = MathHelper.floor_double(var1.maxY + 1.0);
        int i1 = MathHelper.floor_double(var1.minZ);
        int j1 = MathHelper.floor_double(var1.maxZ + 1.0);

        for (int k1 = i; k1 < j; k1++) {
            for (int l1 = k; l1 < l; l1++) {
                for (int i2 = i1; i2 < j1; i2++) {
                    BlockPos blockpos = new BlockPos(k1, l1, i2);
                    IBlockState iblockstate = this.getBlockState(blockpos);
                    Block block = iblockstate.getBlock();
                    if (block.getMaterial() == var2) {
                        int j2 = (Integer)iblockstate.getValue(BlockLiquid.LEVEL);
                        double d0 = l1 + 1;
                        if (j2 < 8) {
                            d0 = l1 + 1 - j2 / 8.0;
                        }

                        if (d0 >= var1.minY) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public Explosion createExplosion(Entity var1, double var2, double var4, double var6, float var8, boolean var9) {
        return this.newExplosion(var1, var2, var4, var6, var8, false, var9);
    }

    public Explosion newExplosion(Entity var1, double var2, double var4, double var6, float var8, boolean var9, boolean var10) {
        Explosion explosion = new Explosion(this, var1, var2, var4, var6, var8, var9, var10);
        explosion.doExplosionA();
        explosion.doExplosionB(true);
        return explosion;
    }

    public float getBlockDensity(Vec3 var1, AxisAlignedBB var2) {
        double d0 = 1.0 / ((var2.maxX - var2.minX) * 2.0 + 1.0);
        double d1 = 1.0 / ((var2.maxY - var2.minY) * 2.0 + 1.0);
        double d2 = 1.0 / ((var2.maxZ - var2.minZ) * 2.0 + 1.0);
        if (!(d0 < 0.0) && !(d1 < 0.0) && !(d2 < 0.0)) {
            int i = 0;
            int j = 0;

            for (float f = 0.0F; f <= 1.0F; f = (float)(f + d0)) {
                for (float f1 = 0.0F; f1 <= 1.0F; f1 = (float)(f1 + d1)) {
                    for (float f2 = 0.0F; f2 <= 1.0F; f2 = (float)(f2 + d2)) {
                        double d3 = var2.minX + (var2.maxX - var2.minX) * f;
                        double d4 = var2.minY + (var2.maxY - var2.minY) * f1;
                        double d5 = var2.minZ + (var2.maxZ - var2.minZ) * f2;
                        if (this.rayTraceBlocks(new Vec3(d3, d4, d5), var1) == null) {
                            i++;
                        }

                        j++;
                    }
                }
            }

            return (float)i / j;
        } else {
            return 0.0F;
        }
    }

    public boolean extinguishFire(EntityPlayer var1, BlockPos var2, EnumFacing var3) {
        var2 = var2.offset(var3);
        if (this.getBlockState(var2).getBlock() == Blocks.fire) {
            this.playAuxSFXAtEntity(var1, 1004, var2, 0);
            this.setBlockToAir(var2);
            return true;
        } else {
            return false;
        }
    }

    public String getDebugLoadedEntities() {
        return "All: " + this.loadedEntityList.size();
    }

    public String getProviderName() {
        return this.chunkProvider.makeString();
    }

    @Override
    public TileEntity getTileEntity(BlockPos var1) {
        if (!this.isValid(var1)) {
            return null;
        }

        TileEntity tileentity = null;
        if (this.processingLoadedTiles) {
            for (int i = 0; i < this.addedTileEntityList.size(); i++) {
                TileEntity tileentity1 = (TileEntity)this.addedTileEntityList.get(i);
                if (!tileentity1.isInvalid() && tileentity1.getPos().equals(var1)) {
                    tileentity = tileentity1;
                    break;
                }
            }
        }

        if (tileentity == null) {
            tileentity = this.getChunkFromBlockCoords(var1).getTileEntity(var1, Chunk.EnumCreateEntityType.IMMEDIATE);
        }

        if (tileentity == null) {
            for (int j = 0; j < this.addedTileEntityList.size(); j++) {
                TileEntity tileentity2 = (TileEntity)this.addedTileEntityList.get(j);
                if (!tileentity2.isInvalid() && tileentity2.getPos().equals(var1)) {
                    tileentity = tileentity2;
                    break;
                }
            }
        }

        return tileentity;
    }

    public void setTileEntity(BlockPos var1, TileEntity var2) {
        if (var2 != null && !var2.isInvalid()) {
            if (this.processingLoadedTiles) {
                var2.setPos(var1);
                Iterator iterator = this.addedTileEntityList.iterator();

                while (iterator.hasNext()) {
                    TileEntity tileentity = (TileEntity)iterator.next();
                    if (tileentity.getPos().equals(var1)) {
                        tileentity.invalidate();
                        iterator.remove();
                    }
                }

                this.addedTileEntityList.add(var2);
            } else {
                this.addTileEntity(var2);
                this.getChunkFromBlockCoords(var1).addTileEntity(var1, var2);
            }
        }
    }

    public void removeTileEntity(BlockPos var1) {
        TileEntity tileentity = this.getTileEntity(var1);
        if (tileentity != null && this.processingLoadedTiles) {
            tileentity.invalidate();
            this.addedTileEntityList.remove(tileentity);
        } else {
            if (tileentity != null) {
                this.addedTileEntityList.remove(tileentity);
                this.loadedTileEntityList.remove(tileentity);
                this.tickableTileEntities.remove(tileentity);
            }

            this.getChunkFromBlockCoords(var1).removeTileEntity(var1);
        }
    }

    public void markTileEntityForRemoval(TileEntity var1) {
        this.tileEntitiesToBeRemoved.add(var1);
    }

    public boolean isBlockFullCube(BlockPos var1) {
        IBlockState iblockstate = this.getBlockState(var1);
        AxisAlignedBB axisalignedbb = iblockstate.getBlock().getCollisionBoundingBox(this, var1, iblockstate);
        return axisalignedbb != null && axisalignedbb.getAverageEdgeLength() >= 1.0;
    }

    public static boolean doesBlockHaveSolidTopSurface(IBlockAccess var0, BlockPos var1) {
        IBlockState iblockstate = var0.getBlockState(var1);
        Block block = iblockstate.getBlock();
        if (block.getMaterial().isOpaque() && block.isFullCube()) {
            return true;
        } else if (block instanceof BlockStairs) {
            return iblockstate.getValue(BlockStairs.HALF) == BlockStairs.EnumHalf.TOP;
        } else if (block instanceof BlockSlab) {
            return iblockstate.getValue(BlockSlab.HALF) == BlockSlab.EnumBlockHalf.TOP;
        } else if (block instanceof BlockHopper) {
            return true;
        } else {
            return block instanceof BlockSnow ? (Integer)iblockstate.getValue(BlockSnow.LAYERS) == 7 : false;
        }
    }

    public boolean isBlockNormalCube(BlockPos var1, boolean var2) {
        if (!this.isValid(var1)) {
            return var2;
        }

        Chunk chunk = this.chunkProvider.provideChunk(var1);
        if (chunk.isEmpty()) {
            return var2;
        }

        Block block = this.getBlockState(var1).getBlock();
        return block.getMaterial().isOpaque() && block.isFullCube();
    }

    public void calculateInitialSkylight() {
        int i = this.calculateSkylightSubtracted(1.0F);
        if (i != this.skylightSubtracted) {
            this.skylightSubtracted = i;
        }
    }

    public void setAllowedSpawnTypes(boolean var1, boolean var2) {
        this.spawnHostileMobs = var1;
        this.spawnPeacefulMobs = var2;
    }

    public void tick() {
        this.updateWeather();
    }

    protected void calculateInitialWeather() {
        if (this.worldInfo.isRaining()) {
            this.rainingStrength = 1.0F;
            if (this.worldInfo.isThundering()) {
                this.thunderingStrength = 1.0F;
            }
        }
    }

    protected void updateWeather() {
        if (!this.provider.getHasNoSky()) {
            if (!this.isRemote) {
                int i = this.worldInfo.getCleanWeatherTime();
                if (i > 0) {
                    this.worldInfo.setCleanWeatherTime(--i);
                    this.worldInfo.setThunderTime(this.worldInfo.isThundering() ? 1 : 2);
                    this.worldInfo.setRainTime(this.worldInfo.isRaining() ? 1 : 2);
                }

                int j = this.worldInfo.getThunderTime();
                if (j <= 0) {
                    if (this.worldInfo.isThundering()) {
                        this.worldInfo.setThunderTime(this.rand.nextInt(12000) + 3600);
                    } else {
                        this.worldInfo.setThunderTime(this.rand.nextInt(168000) + 12000);
                    }
                } else {
                    this.worldInfo.setThunderTime(--j);
                    if (j <= 0) {
                        this.worldInfo.setThundering(!this.worldInfo.isThundering());
                    }
                }

                this.prevThunderingStrength = this.thunderingStrength;
                if (this.worldInfo.isThundering()) {
                    this.thunderingStrength = (float)(this.thunderingStrength + 0.01);
                } else {
                    this.thunderingStrength = (float)(this.thunderingStrength - 0.01);
                }

                this.thunderingStrength = MathHelper.clamp_float(this.thunderingStrength, 0.0F, 1.0F);
                int k = this.worldInfo.getRainTime();
                if (k <= 0) {
                    if (this.worldInfo.isRaining()) {
                        this.worldInfo.setRainTime(this.rand.nextInt(12000) + 12000);
                    } else {
                        this.worldInfo.setRainTime(this.rand.nextInt(168000) + 12000);
                    }
                } else {
                    this.worldInfo.setRainTime(--k);
                    if (k <= 0) {
                        this.worldInfo.setRaining(!this.worldInfo.isRaining());
                    }
                }

                this.prevRainingStrength = this.rainingStrength;
                if (this.worldInfo.isRaining()) {
                    this.rainingStrength = (float)(this.rainingStrength + 0.01);
                } else {
                    this.rainingStrength = (float)(this.rainingStrength - 0.01);
                }

                this.rainingStrength = MathHelper.clamp_float(this.rainingStrength, 0.0F, 1.0F);
            }
        }
    }

    protected void setActivePlayerChunksAndCheckLight() {
        this.activeChunkSet.clear();
        this.theProfiler.startSection("buildList");

        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer = (EntityPlayer)this.playerEntities.get(i);
            int j = MathHelper.floor_double(entityplayer.posX / 16.0);
            int k = MathHelper.floor_double(entityplayer.posZ / 16.0);
            int l = this.getRenderDistanceChunks();

            for (int i1 = -l; i1 <= l; i1++) {
                for (int j1 = -l; j1 <= l; j1++) {
                    this.activeChunkSet.add(new ChunkCoordIntPair(i1 + j, j1 + k));
                }
            }
        }

        this.theProfiler.endSection();
        if (this.ambientTickCountdown > 0) {
            this.ambientTickCountdown--;
        }

        this.theProfiler.startSection("playerCheckLight");
        if (!this.playerEntities.isEmpty()) {
            int k1 = this.rand.nextInt(this.playerEntities.size());
            EntityPlayer entityplayer1 = (EntityPlayer)this.playerEntities.get(k1);
            int l1 = MathHelper.floor_double(entityplayer1.posX) + this.rand.nextInt(11) - 5;
            int i2 = MathHelper.floor_double(entityplayer1.posY) + this.rand.nextInt(11) - 5;
            int j2 = MathHelper.floor_double(entityplayer1.posZ) + this.rand.nextInt(11) - 5;
            this.checkLight(new BlockPos(l1, i2, j2));
        }

        this.theProfiler.endSection();
    }

    protected abstract int getRenderDistanceChunks();

    protected void playMoodSoundAndCheckLight(int var1, int var2, Chunk var3) {
        this.theProfiler.endStartSection("moodSound");
        if (this.ambientTickCountdown == 0 && !this.isRemote) {
            this.updateLCG = this.updateLCG * 3 + 1013904223;
            int i = this.updateLCG >> 2;
            int j = i & 15;
            int k = i >> 8 & 15;
            int l = i >> 16 & 0xFF;
            BlockPos blockpos = new BlockPos(j, l, k);
            Block block = var3.getBlock(blockpos);
            j += var1;
            k += var2;
            if (block.getMaterial() == Material.air && this.getLight(blockpos) <= this.rand.nextInt(8) && this.getLightFor(EnumSkyBlock.SKY, blockpos) <= 0) {
                EntityPlayer entityplayer = this.getClosestPlayer(j + 0.5, l + 0.5, k + 0.5, 8.0);
                if (entityplayer != null && entityplayer.getDistanceSq(j + 0.5, l + 0.5, k + 0.5) > 4.0) {
                    this.playSoundEffect(j + 0.5, l + 0.5, k + 0.5, "ambient.cave.cave", 0.7F, 0.8F + this.rand.nextFloat() * 0.2F);
                    this.ambientTickCountdown = this.rand.nextInt(12000) + 6000;
                }
            }
        }

        this.theProfiler.endStartSection("checkLight");
        var3.enqueueRelightChecks();
    }

    protected void updateBlocks() {
        this.setActivePlayerChunksAndCheckLight();
    }

    public void forceBlockUpdateTick(Block var1, BlockPos var2, Random var3) {
        this.scheduledUpdatesAreImmediate = true;
        var1.updateTick(this, var2, this.getBlockState(var2), var3);
        this.scheduledUpdatesAreImmediate = false;
    }

    public boolean canBlockFreezeWater(BlockPos var1) {
        return this.canBlockFreeze(var1, false);
    }

    public boolean canBlockFreezeNoWater(BlockPos var1) {
        return this.canBlockFreeze(var1, true);
    }

    public boolean canBlockFreeze(BlockPos var1, boolean var2) {
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1);
        float f = biomegenbase.getFloatTemperature(var1);
        if (f > 0.15F) {
            return false;
        }

        if (var1.getY() >= 0 && var1.getY() < 256 && this.getLightFor(EnumSkyBlock.BLOCK, var1) < 10) {
            IBlockState iblockstate = this.getBlockState(var1);
            Block block = iblockstate.getBlock();
            if ((block == Blocks.water || block == Blocks.flowing_water) && (Integer)iblockstate.getValue(BlockLiquid.LEVEL) == 0) {
                if (!var2) {
                    return true;
                }

                boolean flag = this.isWater(var1.west()) && this.isWater(var1.east()) && this.isWater(var1.north()) && this.isWater(var1.south());
                if (!flag) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isWater(BlockPos var1) {
        return this.getBlockState(var1).getBlock().getMaterial() == Material.water;
    }

    public boolean canSnowAt(BlockPos var1, boolean var2) {
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1);
        float f = biomegenbase.getFloatTemperature(var1);
        if (f > 0.15F) {
            return false;
        }

        if (!var2) {
            return true;
        }

        if (var1.getY() >= 0 && var1.getY() < 256 && this.getLightFor(EnumSkyBlock.BLOCK, var1) < 10) {
            Block block = this.getBlockState(var1).getBlock();
            if (block.getMaterial() == Material.air && Blocks.snow_layer.canPlaceBlockAt(this, var1)) {
                return true;
            }
        }

        return false;
    }

    public boolean checkLight(BlockPos var1) {
        boolean flag = false;
        if (!this.provider.getHasNoSky()) {
            flag |= this.checkLightFor(EnumSkyBlock.SKY, var1);
        }

        return flag | this.checkLightFor(EnumSkyBlock.BLOCK, var1);
    }

    private int getRawLight(BlockPos var1, EnumSkyBlock var2) {
        if (var2 == EnumSkyBlock.SKY && this.canSeeSky(var1)) {
            return 15;
        }

        Block block = this.getBlockState(var1).getBlock();
        int i = var2 == EnumSkyBlock.SKY ? 0 : block.getLightValue();
        int j = block.getLightOpacity();
        if (j >= 15 && block.getLightValue() > 0) {
            j = 1;
        }

        if (j < 1) {
            j = 1;
        }

        if (j >= 15) {
            return 0;
        }

        if (i >= 14) {
            return i;
        }

        for (EnumFacing enumfacing : EnumFacing.values()) {
            BlockPos blockpos = var1.offset(enumfacing);
            int k = this.getLightFor(var2, blockpos) - j;
            if (k > i) {
                i = k;
            }

            if (i >= 14) {
                return i;
            }
        }

        return i;
    }

    public boolean checkLightFor(EnumSkyBlock var1, BlockPos var2) {
        if (!this.isAreaLoaded(var2, 17, false)) {
            return false;
        }

        int i = 0;
        int j = 0;
        this.theProfiler.startSection("getBrightness");
        int k = this.getLightFor(var1, var2);
        int l = this.getRawLight(var2, var1);
        int i1 = var2.getX();
        int j1 = var2.getY();
        int k1 = var2.getZ();
        if (l > k) {
            this.lightUpdateBlockList[j++] = 133152;
        } else if (l < k) {
            this.lightUpdateBlockList[j++] = 133152 | k << 18;

            while (i < j) {
                int l1 = this.lightUpdateBlockList[i++];
                int i2 = (l1 & 63) - 32 + i1;
                int j2 = (l1 >> 6 & 63) - 32 + j1;
                int k2 = (l1 >> 12 & 63) - 32 + k1;
                int l2 = l1 >> 18 & 15;
                BlockPos blockpos = new BlockPos(i2, j2, k2);
                int i3 = this.getLightFor(var1, blockpos);
                if (i3 == l2) {
                    this.setLightFor(var1, blockpos, 0);
                    if (l2 > 0) {
                        int j3 = MathHelper.abs_int(i2 - i1);
                        int k3 = MathHelper.abs_int(j2 - j1);
                        int l3 = MathHelper.abs_int(k2 - k1);
                        if (j3 + k3 + l3 < 17) {
                            for (EnumFacing enumfacing : EnumFacing.values()) {
                                int i4 = i2 + enumfacing.getFrontOffsetX();
                                int j4 = j2 + enumfacing.getFrontOffsetY();
                                int k4 = k2 + enumfacing.getFrontOffsetZ();
                                BlockPos blockpos1 = new BlockPos(i4, j4, k4);
                                int l4 = Math.max(1, this.getBlockState(blockpos1).getBlock().getLightOpacity());
                                i3 = this.getLightFor(var1, blockpos1);
                                if (i3 == l2 - l4 && j < this.lightUpdateBlockList.length) {
                                    this.lightUpdateBlockList[j++] = i4 - i1 + 32 | j4 - j1 + 32 << 6 | k4 - k1 + 32 << 12 | l2 - l4 << 18;
                                }
                            }
                        }
                    }
                }
            }

            i = 0;
        }

        this.theProfiler.endSection();
        this.theProfiler.startSection("checkedPosition < toCheckCount");

        while (i < j) {
            int i5 = this.lightUpdateBlockList[i++];
            int j5 = (i5 & 63) - 32 + i1;
            int k5 = (i5 >> 6 & 63) - 32 + j1;
            int l5 = (i5 >> 12 & 63) - 32 + k1;
            BlockPos blockpos2 = new BlockPos(j5, k5, l5);
            int i6 = this.getLightFor(var1, blockpos2);
            int j6 = this.getRawLight(blockpos2, var1);
            if (j6 != i6) {
                this.setLightFor(var1, blockpos2, j6);
                if (j6 > i6) {
                    int k6 = Math.abs(j5 - i1);
                    int l6 = Math.abs(k5 - j1);
                    int i7 = Math.abs(l5 - k1);
                    boolean flag = j < this.lightUpdateBlockList.length - 6;
                    if (k6 + l6 + i7 < 17 && flag) {
                        if (this.getLightFor(var1, blockpos2.west()) < j6) {
                            this.lightUpdateBlockList[j++] = j5 - 1 - i1 + 32 + (k5 - j1 + 32 << 6) + (l5 - k1 + 32 << 12);
                        }

                        if (this.getLightFor(var1, blockpos2.east()) < j6) {
                            this.lightUpdateBlockList[j++] = j5 + 1 - i1 + 32 + (k5 - j1 + 32 << 6) + (l5 - k1 + 32 << 12);
                        }

                        if (this.getLightFor(var1, blockpos2.down()) < j6) {
                            this.lightUpdateBlockList[j++] = j5 - i1 + 32 + (k5 - 1 - j1 + 32 << 6) + (l5 - k1 + 32 << 12);
                        }

                        if (this.getLightFor(var1, blockpos2.up()) < j6) {
                            this.lightUpdateBlockList[j++] = j5 - i1 + 32 + (k5 + 1 - j1 + 32 << 6) + (l5 - k1 + 32 << 12);
                        }

                        if (this.getLightFor(var1, blockpos2.north()) < j6) {
                            this.lightUpdateBlockList[j++] = j5 - i1 + 32 + (k5 - j1 + 32 << 6) + (l5 - 1 - k1 + 32 << 12);
                        }

                        if (this.getLightFor(var1, blockpos2.south()) < j6) {
                            this.lightUpdateBlockList[j++] = j5 - i1 + 32 + (k5 - j1 + 32 << 6) + (l5 + 1 - k1 + 32 << 12);
                        }
                    }
                }
            }
        }

        this.theProfiler.endSection();
        return true;
    }

    public boolean tickUpdates(boolean var1) {
        return false;
    }

    public List getPendingBlockUpdates(Chunk var1, boolean var2) {
        return null;
    }

    public List func_175712_a(StructureBoundingBox var1, boolean var2) {
        return null;
    }

    public List getEntitiesWithinAABBExcludingEntity(Entity var1, AxisAlignedBB var2) {
        return this.getEntitiesInAABBexcluding(var1, var2, IEntitySelector.NOT_SPECTATING);
    }

    public List getEntitiesInAABBexcluding(Entity var1, AxisAlignedBB var2, Predicate var3) {
        ArrayList arraylist = Lists.newArrayList();
        int i = MathHelper.floor_double((var2.minX - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxX + 2.0) / 16.0);
        int k = MathHelper.floor_double((var2.minZ - 2.0) / 16.0);
        int l = MathHelper.floor_double((var2.maxZ + 2.0) / 16.0);

        for (int i1 = i; i1 <= j; i1++) {
            for (int j1 = k; j1 <= l; j1++) {
                if (this.isChunkLoaded(i1, j1, true)) {
                    this.getChunkFromChunkCoords(i1, j1).getEntitiesWithinAABBForEntity(var1, var2, arraylist, var3);
                }
            }
        }

        return arraylist;
    }

    public List getEntities(Class var1, Predicate var2) {
        ArrayList arraylist = Lists.newArrayList();

        for (Entity entity : (Iterable<Entity>) (Iterable) this.loadedEntityList) {
            if (var1.isAssignableFrom(entity.getClass()) && var2.apply(entity)) {
                arraylist.add(entity);
            }
        }

        return arraylist;
    }

    public List getPlayers(Class var1, Predicate var2) {
        ArrayList arraylist = Lists.newArrayList();

        for (Entity entity : (Iterable<Entity>) (Iterable) this.playerEntities) {
            if (var1.isAssignableFrom(entity.getClass()) && var2.apply(entity)) {
                arraylist.add(entity);
            }
        }

        return arraylist;
    }

    public <T extends Entity> List<T> getEntitiesWithinAABB(Class<? extends T> var1, AxisAlignedBB var2) {
        return this.getEntitiesWithinAABB(var1, var2, IEntitySelector.NOT_SPECTATING);
    }

    public <T extends Entity> List<T> getEntitiesWithinAABB(Class<? extends T> var1, AxisAlignedBB var2, Predicate var3) {
        int i = MathHelper.floor_double((var2.minX - 2.0) / 16.0);
        int j = MathHelper.floor_double((var2.maxX + 2.0) / 16.0);
        int k = MathHelper.floor_double((var2.minZ - 2.0) / 16.0);
        int l = MathHelper.floor_double((var2.maxZ + 2.0) / 16.0);
        ArrayList arraylist = Lists.newArrayList();

        for (int i1 = i; i1 <= j; i1++) {
            for (int j1 = k; j1 <= l; j1++) {
                if (this.isChunkLoaded(i1, j1, true)) {
                    this.getChunkFromChunkCoords(i1, j1).getEntitiesOfTypeWithinAAAB(var1, var2, arraylist, var3);
                }
            }
        }

        return arraylist;
    }

    public Entity findNearestEntityWithinAABB(Class var1, AxisAlignedBB var2, Entity var3) {
        List list = this.getEntitiesWithinAABB(var1, var2);
        Entity entity = null;
        double d0 = Double.MAX_VALUE;

        for (int i = 0; i < list.size(); i++) {
            Entity entity1 = (Entity)list.get(i);
            if (entity1 != var3 && IEntitySelector.NOT_SPECTATING.apply(entity1)) {
                double d1 = var3.getDistanceSqToEntity(entity1);
                if (!(d1 > d0)) {
                    entity = entity1;
                    d0 = d1;
                }
            }
        }

        return entity;
    }

    public Entity getEntityByID(int var1) {
        return (Entity)this.entitiesById.lookup(var1);
    }

    public List getLoadedEntityList() {
        return this.loadedEntityList;
    }

    public void markChunkDirty(BlockPos var1, TileEntity var2) {
        if (this.isBlockLoaded(var1)) {
            this.getChunkFromBlockCoords(var1).setChunkModified();
        }
    }

    public int countEntities(Class var1) {
        int i = 0;

        for (Entity entity : (Iterable<Entity>) (Iterable) this.loadedEntityList) {
            if ((!(entity instanceof EntityLiving) || !((EntityLiving)entity).isNoDespawnRequired()) && var1.isAssignableFrom(entity.getClass())) {
                i++;
            }
        }

        return i;
    }

    public void loadEntities(Collection var1) {
        this.loadedEntityList.addAll(var1);

        for (Entity entity : (Iterable<Entity>) (Iterable) var1) {
            this.onEntityAdded(entity);
        }
    }

    public void unloadEntities(Collection var1) {
        this.unloadedEntityList.addAll(var1);
    }

    public boolean canBlockBePlaced(Block var1, BlockPos var2, boolean var3, EnumFacing var4, Entity var5, ItemStack var6) {
        Block block = this.getBlockState(var2).getBlock();
        AxisAlignedBB axisalignedbb = var3 ? null : var1.getCollisionBoundingBox(this, var2, var1.getDefaultState());
        if (axisalignedbb != null && !this.checkNoEntityCollision(axisalignedbb, var5)) {
            return false;
        } else {
            return block.getMaterial() == Material.circuits && var1 == Blocks.anvil
                ? true
                : block.getMaterial().isReplaceable() && var1.canReplace(this, var2, var4, var6);
        }
    }

    @Override
    public int getStrongPower(BlockPos var1, EnumFacing var2) {
        IBlockState iblockstate = this.getBlockState(var1);
        return iblockstate.getBlock().isProvidingStrongPower(this, var1, iblockstate, var2);
    }

    @Override
    public WorldType getWorldType() {
        return this.worldInfo.getTerrainType();
    }

    public int getStrongPower(BlockPos var1) {
        int i = 0;
        i = Math.max(i, this.getStrongPower(var1.down(), EnumFacing.DOWN));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.getStrongPower(var1.up(), EnumFacing.UP));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.getStrongPower(var1.north(), EnumFacing.NORTH));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.getStrongPower(var1.south(), EnumFacing.SOUTH));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.getStrongPower(var1.west(), EnumFacing.WEST));
        if (i >= 15) {
            return i;
        }

        i = Math.max(i, this.getStrongPower(var1.east(), EnumFacing.EAST));
        return i >= 15 ? i : i;
    }

    public boolean isSidePowered(BlockPos var1, EnumFacing var2) {
        return this.getRedstonePower(var1, var2) > 0;
    }

    public int getRedstonePower(BlockPos var1, EnumFacing var2) {
        IBlockState iblockstate = this.getBlockState(var1);
        Block block = iblockstate.getBlock();
        return block.isNormalCube() ? this.getStrongPower(var1) : block.isProvidingWeakPower(this, var1, iblockstate, var2);
    }

    public boolean isBlockPowered(BlockPos var1) {
        if (this.getRedstonePower(var1.down(), EnumFacing.DOWN) > 0) {
            return true;
        } else if (this.getRedstonePower(var1.up(), EnumFacing.UP) > 0) {
            return true;
        } else if (this.getRedstonePower(var1.north(), EnumFacing.NORTH) > 0) {
            return true;
        } else if (this.getRedstonePower(var1.south(), EnumFacing.SOUTH) > 0) {
            return true;
        } else {
            return this.getRedstonePower(var1.west(), EnumFacing.WEST) > 0 ? true : this.getRedstonePower(var1.east(), EnumFacing.EAST) > 0;
        }
    }

    public int isBlockIndirectlyGettingPowered(BlockPos var1) {
        int i = 0;

        for (EnumFacing enumfacing : EnumFacing.values()) {
            int j = this.getRedstonePower(var1.offset(enumfacing), enumfacing);
            if (j >= 15) {
                return 15;
            }

            if (j > i) {
                i = j;
            }
        }

        return i;
    }

    public EntityPlayer getClosestPlayerToEntity(Entity var1, double var2) {
        return this.getClosestPlayer(var1.posX, var1.posY, var1.posZ, var2);
    }

    public EntityPlayer getClosestPlayer(double var1, double var3, double var5, double var7) {
        double d0 = -1.0;
        EntityPlayer entityplayer = null;

        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer1 = (EntityPlayer)this.playerEntities.get(i);
            if (IEntitySelector.NOT_SPECTATING.apply(entityplayer1)) {
                double d1 = entityplayer1.getDistanceSq(var1, var3, var5);
                if ((var7 < 0.0 || d1 < var7 * var7) && (d0 == -1.0 || d1 < d0)) {
                    d0 = d1;
                    entityplayer = entityplayer1;
                }
            }
        }

        return entityplayer;
    }

    public boolean isAnyPlayerWithinRangeAt(double var1, double var3, double var5, double var7) {
        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer = (EntityPlayer)this.playerEntities.get(i);
            if (IEntitySelector.NOT_SPECTATING.apply(entityplayer)) {
                double d0 = entityplayer.getDistanceSq(var1, var3, var5);
                if (var7 < 0.0 || d0 < var7 * var7) {
                    return true;
                }
            }
        }

        return false;
    }

    public EntityPlayer getPlayerEntityByName(String var1) {
        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer = (EntityPlayer)this.playerEntities.get(i);
            if (var1.equals(entityplayer.getCommandSenderName())) {
                return entityplayer;
            }
        }

        return null;
    }

    public EntityPlayer getPlayerEntityByUUID(UUID var1) {
        for (int i = 0; i < this.playerEntities.size(); i++) {
            EntityPlayer entityplayer = (EntityPlayer)this.playerEntities.get(i);
            if (var1.equals(entityplayer.getUniqueID())) {
                return entityplayer;
            }
        }

        return null;
    }

    public void sendQuittingDisconnectingPacket() {
    }

    public void checkSessionLock() throws MinecraftException {
        this.saveHandler.checkSessionLock();
    }

    public void setTotalWorldTime(long var1) {
        this.worldInfo.setWorldTotalTime(var1);
    }

    public long getSeed() {
        return this.worldInfo.getSeed();
    }

    public long getTotalWorldTime() {
        return this.worldInfo.getWorldTotalTime();
    }

    public long getWorldTime() {
        return this.worldInfo.getWorldTime();
    }

    public void setWorldTime(long var1) {
        this.worldInfo.setWorldTime(var1);
    }

    public BlockPos getSpawnPoint() {
        BlockPos blockpos = new BlockPos(this.worldInfo.getSpawnX(), this.worldInfo.getSpawnY(), this.worldInfo.getSpawnZ());
        if (!this.getWorldBorder().contains(blockpos)) {
            blockpos = this.getHeight(new BlockPos(this.getWorldBorder().getCenterX(), 0.0, this.getWorldBorder().getCenterZ()));
        }

        return blockpos;
    }

    public void setSpawnPoint(BlockPos var1) {
        this.worldInfo.setSpawn(var1);
    }

    public void joinEntityInSurroundings(Entity var1) {
        int i = MathHelper.floor_double(var1.posX / 16.0);
        int j = MathHelper.floor_double(var1.posZ / 16.0);
        byte b0 = 2;

        for (int k = i - b0; k <= i + b0; k++) {
            for (int l = j - b0; l <= j + b0; l++) {
                this.getChunkFromChunkCoords(k, l);
            }
        }

        if (!this.loadedEntityList.contains(var1)) {
            this.loadedEntityList.add(var1);
        }
    }

    public boolean isBlockModifiable(EntityPlayer var1, BlockPos var2) {
        return true;
    }

    public void setEntityState(Entity var1, byte var2) {
    }

    public IChunkProvider getChunkProvider() {
        return this.chunkProvider;
    }

    public void addBlockEvent(BlockPos var1, Block var2, int var3, int var4) {
        var2.onBlockEventReceived(this, var1, this.getBlockState(var1), var3, var4);
    }

    public ISaveHandler getSaveHandler() {
        return this.saveHandler;
    }

    public WorldInfo getWorldInfo() {
        return this.worldInfo;
    }

    public GameRules getGameRules() {
        return this.worldInfo.getGameRulesInstance();
    }

    public void updateAllPlayersSleepingFlag() {
    }

    public float getThunderStrength(float var1) {
        return (this.prevThunderingStrength + (this.thunderingStrength - this.prevThunderingStrength) * var1) * this.getRainStrength(var1);
    }

    public void setThunderStrength(float var1) {
        this.prevThunderingStrength = var1;
        this.thunderingStrength = var1;
    }

    public float getRainStrength(float var1) {
        return this.prevRainingStrength + (this.rainingStrength - this.prevRainingStrength) * var1;
    }

    public void setRainStrength(float var1) {
        this.prevRainingStrength = var1;
        this.rainingStrength = var1;
    }

    public boolean isThundering() {
        return this.getThunderStrength(1.0F) > 0.9;
    }

    public boolean isRaining() {
        return this.getRainStrength(1.0F) > 0.2;
    }

    public boolean canLightningStrike(BlockPos var1) {
        if (!this.isRaining()) {
            return false;
        } else if (!this.canSeeSky(var1)) {
            return false;
        } else if (this.getPrecipitationHeight(var1).getY() > var1.getY()) {
            return false;
        } else {
            BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1);
            if (biomegenbase.getEnableSnow()) {
                return false;
            } else {
                return this.canSnowAt(var1, false) ? false : biomegenbase.canSpawnLightningBolt();
            }
        }
    }

    public boolean isBlockinHighHumidity(BlockPos var1) {
        BiomeGenBase biomegenbase = this.getBiomeGenForCoords(var1);
        return biomegenbase.isHighHumidity();
    }

    public MapStorage getMapStorage() {
        return this.mapStorage;
    }

    public void setItemData(String var1, WorldSavedData var2) {
        this.mapStorage.setData(var1, var2);
    }

    public WorldSavedData loadItemData(Class var1, String var2) {
        return this.mapStorage.loadData(var1, var2);
    }

    public int getUniqueDataId(String var1) {
        return this.mapStorage.getUniqueDataId(var1);
    }

    public void playBroadcastSound(int var1, BlockPos var2, int var3) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            ((IWorldAccess)this.worldAccesses.get(i)).broadcastSound(var1, var2, var3);
        }
    }

    public void playAuxSFX(int var1, BlockPos var2, int var3) {
        this.playAuxSFXAtEntity(null, var1, var2, var3);
    }

    public void playAuxSFXAtEntity(EntityPlayer var1, int var2, BlockPos var3, int var4) {
        try {
            for (int i = 0; i < this.worldAccesses.size(); i++) {
                ((IWorldAccess)this.worldAccesses.get(i)).playAuxSFX(var1, var2, var3, var4);
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Playing level event");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Level event being played");
            crashreportcategory.addCrashSection("Block coordinates", CrashReportCategory.getCoordinateInfo(var3));
            crashreportcategory.addCrashSection("Event source", var1);
            crashreportcategory.addCrashSection("Event type", var2);
            crashreportcategory.addCrashSection("Event data", var4);
            throw new ReportedException(crashreport);
        }
    }

    public int getHeight() {
        return 256;
    }

    public int getActualHeight() {
        return this.provider.getHasNoSky() ? 128 : 256;
    }

    public Random setRandomSeed(int var1, int var2, int var3) {
        long i = var1 * 341873128712L + var2 * 132897987541L + this.getWorldInfo().getSeed() + var3;
        this.rand.setSeed(i);
        return this.rand;
    }

    public BlockPos getStrongholdPos(String var1, BlockPos var2) {
        return this.getChunkProvider().getStrongholdGen(this, var1, var2);
    }

    @Override
    public boolean extendedLevelsInChunkCache() {
        return false;
    }

    public double getHorizon() {
        return this.worldInfo.getTerrainType() == WorldType.FLAT ? 0.0 : 63.0;
    }

    public CrashReportCategory addWorldInfoToCrashReport(CrashReport var1) {
        CrashReportCategory crashreportcategory = var1.makeCategoryDepth("Affected level", 1);
        crashreportcategory.addCrashSection("Level name", this.worldInfo == null ? "????" : this.worldInfo.getWorldName());
        crashreportcategory.addCrashSectionCallable("All players", new Callable() {
            public String call() {
                return World.this.playerEntities.size() + " total; " + World.this.playerEntities.toString();
            }
        });
        crashreportcategory.addCrashSectionCallable("Chunk stats", new Callable() {
            public String call() {
                return World.this.chunkProvider.makeString();
            }
        });

        try {
            this.worldInfo.addToCrashReport(crashreportcategory);
        } catch (Throwable throwable) {
            crashreportcategory.addCrashSectionThrowable("Level Data Unobtainable", throwable);
        }

        return crashreportcategory;
    }

    public void sendBlockBreakProgress(int var1, BlockPos var2, int var3) {
        for (int i = 0; i < this.worldAccesses.size(); i++) {
            IWorldAccess iworldaccess = (IWorldAccess)this.worldAccesses.get(i);
            iworldaccess.sendBlockBreakProgress(var1, var2, var3);
        }
    }

    public Calendar getCurrentDate() {
        if (this.getTotalWorldTime() % 600L == 0L) {
            this.theCalendar.setTimeInMillis(MinecraftServer.getCurrentTimeMillis());
        }

        return this.theCalendar;
    }

    public void makeFireworks(double var1, double var3, double var5, double var7, double var9, double var11, NBTTagCompound var13) {
    }

    public Scoreboard getScoreboard() {
        return this.worldScoreboard;
    }

    public void updateComparatorOutputLevel(BlockPos var1, Block var2) {
        for (EnumFacing enumfacing : (Iterable<EnumFacing>) (Iterable) EnumFacing.Plane.HORIZONTAL) {
            BlockPos blockpos = var1.offset(enumfacing);
            if (this.isBlockLoaded(blockpos)) {
                IBlockState iblockstate = this.getBlockState(blockpos);
                if (Blocks.unpowered_comparator.isAssociated(iblockstate.getBlock())) {
                    iblockstate.getBlock().onNeighborBlockChange(this, blockpos, iblockstate, var2);
                } else if (iblockstate.getBlock().isNormalCube()) {
                    blockpos = blockpos.offset(enumfacing);
                    iblockstate = this.getBlockState(blockpos);
                    if (Blocks.unpowered_comparator.isAssociated(iblockstate.getBlock())) {
                        iblockstate.getBlock().onNeighborBlockChange(this, blockpos, iblockstate, var2);
                    }
                }
            }
        }
    }

    public DifficultyInstance getDifficultyForLocation(BlockPos var1) {
        long i = 0L;
        float f = 0.0F;
        if (this.isBlockLoaded(var1)) {
            f = this.getCurrentMoonPhaseFactor();
            i = this.getChunkFromBlockCoords(var1).getInhabitedTime();
        }

        return new DifficultyInstance(this.getDifficulty(), this.getWorldTime(), i, f);
    }

    public EnumDifficulty getDifficulty() {
        return this.getWorldInfo().getDifficulty();
    }

    public int getSkylightSubtracted() {
        return this.skylightSubtracted;
    }

    public void setSkylightSubtracted(int var1) {
        this.skylightSubtracted = var1;
    }

    public int getLastLightningBolt() {
        return this.lastLightningBolt;
    }

    public void setLastLightningBolt(int var1) {
        this.lastLightningBolt = var1;
    }

    public boolean isFindingSpawnPoint() {
        return this.findingSpawnPoint;
    }

    public VillageCollection getVillageCollection() {
        return this.villageCollectionObj;
    }

    public WorldBorder getWorldBorder() {
        return this.worldBorder;
    }

    public boolean isSpawnChunk(int var1, int var2) {
        BlockPos blockpos = this.getSpawnPoint();
        int i = var1 * 16 + 8 - blockpos.getX();
        int j = var2 * 16 + 8 - blockpos.getZ();
        short short1 = 128;
        return i >= -short1 && i <= short1 && j >= -short1 && j <= short1;
    }
}
