package net.minecraft.enchantment;

import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public enum EnumEnchantmentType {
    ALL,
    ARMOR,
    ARMOR_FEET,
    ARMOR_LEGS,
    ARMOR_TORSO,
    ARMOR_HEAD,
    WEAPON,
    DIGGER,
    FISHING_ROD,
    BREAKABLE,
    BOW;

    public boolean canEnchantItem(Item var1) {
        if (this == ALL) {
            return true;
        }

        if (this == BREAKABLE && var1.isDamageable()) {
            return true;
        }

        if (var1 instanceof ItemArmor) {
            if (this == ARMOR) {
                return true;
            } else {
                ItemArmor itemarmor = (ItemArmor)var1;
                if (itemarmor.armorType == 0) {
                    return this == ARMOR_HEAD;
                } else if (itemarmor.armorType == 2) {
                    return this == ARMOR_LEGS;
                } else if (itemarmor.armorType == 1) {
                    return this == ARMOR_TORSO;
                } else {
                    return itemarmor.armorType == 3 ? this == ARMOR_FEET : false;
                }
            }
        } else if (var1 instanceof ItemSword) {
            return this == WEAPON;
        } else if (var1 instanceof ItemTool) {
            return this == DIGGER;
        } else if (var1 instanceof ItemBow) {
            return this == BOW;
        } else {
            return var1 instanceof ItemFishingRod ? this == FISHING_ROD : false;
        }
    }
}
