package net.minecraft.util;

public class ChatAllowedCharacters {
    public static final char[] allowedCharactersArray = new char[]{'/', '\n', '\r', '\t', '\u0000', '\f', '`', '?', '*', '\\', '<', '>', '|', '"', ':'};

    public static boolean isAllowedCharacter(char var0) {
        return var0 != 167 && var0 >= ' ' && var0 != 127;
    }

    public static String filterAllowedCharacters(String var0) {
        StringBuilder stringbuilder = new StringBuilder();

        for (char c0 : var0.toCharArray()) {
            if (isAllowedCharacter(c0)) {
                stringbuilder.append(c0);
            }
        }

        return stringbuilder.toString();
    }
}
