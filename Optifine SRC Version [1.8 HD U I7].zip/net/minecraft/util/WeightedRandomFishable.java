package net.minecraft.util;

import java.util.Random;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;

public class WeightedRandomFishable extends WeightedRandom.Item {
    private final ItemStack returnStack;
    private float maxDamagePercent;
    private boolean enchantable;

    public WeightedRandomFishable(ItemStack var1, int var2) {
        super(var2);
        this.returnStack = var1;
    }

    public ItemStack getItemStack(Random var1) {
        ItemStack itemstack = this.returnStack.copy();
        if (this.maxDamagePercent > 0.0F) {
            int i = (int)(this.maxDamagePercent * this.returnStack.getMaxDamage());
            int j = itemstack.getMaxDamage() - var1.nextInt(var1.nextInt(i) + 1);
            if (j > i) {
                j = i;
            }

            if (j < 1) {
                j = 1;
            }

            itemstack.setItemDamage(j);
        }

        if (this.enchantable) {
            EnchantmentHelper.addRandomEnchantment(var1, itemstack, 30);
        }

        return itemstack;
    }

    public WeightedRandomFishable setMaxDamagePercent(float var1) {
        this.maxDamagePercent = var1;
        return this;
    }

    public WeightedRandomFishable setEnchantable() {
        this.enchantable = true;
        return this;
    }
}
