package net.minecraft.util;

import org.apache.commons.lang3.Validate;

public class ResourceLocation {
    protected final String resourceDomain;
    protected final String resourcePath;

    protected ResourceLocation(int var1, String... var2) {
        this.resourceDomain = org.apache.commons.lang3.StringUtils.isEmpty(var2[0]) ? "minecraft" : var2[0].toLowerCase();
        this.resourcePath = var2[1];
        Validate.notNull(this.resourcePath);
    }

    public ResourceLocation(String var1) {
        this(0, splitObjectName(var1));
    }

    public ResourceLocation(String var1, String var2) {
        this(0, var1, var2);
    }

    protected static String[] splitObjectName(String var0) {
        String[] astring = new String[]{null, var0};
        int i = var0.indexOf(58);
        if (i >= 0) {
            astring[1] = var0.substring(i + 1, var0.length());
            if (i > 1) {
                astring[0] = var0.substring(0, i);
            }
        }

        return astring;
    }

    public String getResourcePath() {
        return this.resourcePath;
    }

    public String getResourceDomain() {
        return this.resourceDomain;
    }

    @Override
    public String toString() {
        return this.resourceDomain + ':' + this.resourcePath;
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ResourceLocation)) {
            return false;
        }

        ResourceLocation resourcelocation = (ResourceLocation)var1;
        return this.resourceDomain.equals(resourcelocation.resourceDomain) && this.resourcePath.equals(resourcelocation.resourcePath);
    }

    @Override
    public int hashCode() {
        return 31 * this.resourceDomain.hashCode() + this.resourcePath.hashCode();
    }
}
