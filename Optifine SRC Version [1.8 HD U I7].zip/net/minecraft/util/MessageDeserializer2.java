package net.minecraft.util;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.CorruptedFrameException;
import java.util.List;
import net.minecraft.network.PacketBuffer;

public class MessageDeserializer2 extends ByteToMessageDecoder {
    @Override
    protected void decode(ChannelHandlerContext var1, ByteBuf var2, List var3) {
        var2.markReaderIndex();
        byte[] abyte = new byte[3];

        for (int i = 0; i < abyte.length; i++) {
            if (!var2.isReadable()) {
                var2.resetReaderIndex();
                return;
            }

            abyte[i] = var2.readByte();
            if (abyte[i] >= 0) {
                PacketBuffer packetbuffer = new PacketBuffer(Unpooled.wrappedBuffer(abyte));

                try {
                    int j = packetbuffer.readVarIntFromBuffer();
                    if (var2.readableBytes() >= j) {
                        var3.add(var2.readBytes(j));
                        return;
                    }

                    var2.resetReaderIndex();
                } finally {
                    packetbuffer.release();
                }

                return;
            }
        }

        throw new CorruptedFrameException("length wider than 21-bit");
    }
}
