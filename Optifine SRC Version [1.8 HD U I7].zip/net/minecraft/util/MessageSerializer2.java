package net.minecraft.util;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import net.minecraft.network.PacketBuffer;

public class MessageSerializer2 extends MessageToByteEncoder {
    protected void encode(ChannelHandlerContext var1, ByteBuf var2, ByteBuf var3) {
        int i = var2.readableBytes();
        int j = PacketBuffer.getVarIntSize(i);
        if (j > 3) {
            throw new IllegalArgumentException("unable to fit " + i + " into " + 3);
        }

        PacketBuffer packetbuffer = new PacketBuffer(var3);
        packetbuffer.ensureWritable(j + i);
        packetbuffer.writeVarIntToBuffer(i);
        packetbuffer.writeBytes(var2, var2.readerIndex(), i);
    }

    @Override
    protected void encode(ChannelHandlerContext var1, Object var2, ByteBuf var3) {
        this.encode(var1, (ByteBuf)var2, var3);
    }
}
