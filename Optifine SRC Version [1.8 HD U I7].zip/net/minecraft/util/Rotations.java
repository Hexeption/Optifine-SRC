package net.minecraft.util;

import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;

public class Rotations {
    protected final float x;
    protected final float y;
    protected final float z;

    public Rotations(float var1, float var2, float var3) {
        this.x = var1;
        this.y = var2;
        this.z = var3;
    }

    public Rotations(NBTTagList var1) {
        this.x = var1.getFloatAt(0);
        this.y = var1.getFloatAt(1);
        this.z = var1.getFloatAt(2);
    }

    public NBTTagList writeToNBT() {
        NBTTagList nbttaglist = new NBTTagList();
        nbttaglist.appendTag(new NBTTagFloat(this.x));
        nbttaglist.appendTag(new NBTTagFloat(this.y));
        nbttaglist.appendTag(new NBTTagFloat(this.z));
        return nbttaglist;
    }

    @Override
    public boolean equals(Object var1) {
        if (!(var1 instanceof Rotations)) {
            return false;
        }

        Rotations rotations = (Rotations)var1;
        return this.x == rotations.x && this.y == rotations.y && this.z == rotations.z;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public float getZ() {
        return this.z;
    }
}
