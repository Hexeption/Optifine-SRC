package net.minecraft.util;

import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.MinecraftServer;

public class ChatComponentScore extends ChatComponentStyle {
    private final String name;
    private final String objective;
    private String value = "";

    public ChatComponentScore(String var1, String var2) {
        this.name = var1;
        this.objective = var2;
    }

    public String getName() {
        return this.name;
    }

    public String getObjective() {
        return this.objective;
    }

    public void setValue(String var1) {
        this.value = var1;
    }

    @Override
    public String getUnformattedTextForChat() {
        MinecraftServer minecraftserver = MinecraftServer.getServer();
        if (minecraftserver != null && minecraftserver.isAnvilFileSet() && StringUtils.isNullOrEmpty(this.value)) {
            Scoreboard scoreboard = minecraftserver.worldServerForDimension(0).getScoreboard();
            ScoreObjective scoreobjective = scoreboard.getObjective(this.objective);
            if (scoreboard.entityHasObjective(this.name, scoreobjective)) {
                Score score = scoreboard.getValueFromObjective(this.name, scoreobjective);
                this.setValue(String.format("%d", score.getScorePoints()));
            } else {
                this.value = "";
            }
        }

        return this.value;
    }

    public ChatComponentScore createCopyImpl() {
        ChatComponentScore chatcomponentscore = new ChatComponentScore(this.name, this.objective);
        chatcomponentscore.setValue(this.value);
        chatcomponentscore.setChatStyle(this.getChatStyle().createShallowCopy());

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.getSiblings()) {
            chatcomponentscore.appendSibling(ichatcomponent.createCopy());
        }

        return chatcomponentscore;
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ChatComponentScore)) {
            return false;
        }

        ChatComponentScore chatcomponentscore = (ChatComponentScore)var1;
        return this.name.equals(chatcomponentscore.name) && this.objective.equals(chatcomponentscore.objective) && super.equals(var1);
    }

    @Override
    public String toString() {
        return "ScoreComponent{name='"
            + this.name
            + '\''
            + "objective='"
            + this.objective
            + '\''
            + ", siblings="
            + this.siblings
            + ", style="
            + this.getChatStyle()
            + '}';
    }

    @Override
    public IChatComponent createCopy() {
        return this.createCopyImpl();
    }
}
