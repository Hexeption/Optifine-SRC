package net.minecraft.util;

public class Vec3 {
    public final double xCoord;
    public final double yCoord;
    public final double zCoord;

    public Vec3(double var1, double var3, double var5) {
        if (var1 == -0.0) {
            var1 = 0.0;
        }

        if (var3 == -0.0) {
            var3 = 0.0;
        }

        if (var5 == -0.0) {
            var5 = 0.0;
        }

        this.xCoord = var1;
        this.yCoord = var3;
        this.zCoord = var5;
    }

    public Vec3 subtractReverse(Vec3 var1) {
        return new Vec3(var1.xCoord - this.xCoord, var1.yCoord - this.yCoord, var1.zCoord - this.zCoord);
    }

    public Vec3 normalize() {
        double d0 = MathHelper.sqrt_double(this.xCoord * this.xCoord + this.yCoord * this.yCoord + this.zCoord * this.zCoord);
        return d0 < 1.0E-4 ? new Vec3(0.0, 0.0, 0.0) : new Vec3(this.xCoord / d0, this.yCoord / d0, this.zCoord / d0);
    }

    public double dotProduct(Vec3 var1) {
        return this.xCoord * var1.xCoord + this.yCoord * var1.yCoord + this.zCoord * var1.zCoord;
    }

    public Vec3 crossProduct(Vec3 var1) {
        return new Vec3(
            this.yCoord * var1.zCoord - this.zCoord * var1.yCoord,
            this.zCoord * var1.xCoord - this.xCoord * var1.zCoord,
            this.xCoord * var1.yCoord - this.yCoord * var1.xCoord
        );
    }

    public Vec3 subtract(Vec3 var1) {
        return this.subtract(var1.xCoord, var1.yCoord, var1.zCoord);
    }

    public Vec3 subtract(double var1, double var3, double var5) {
        return this.addVector(-var1, -var3, -var5);
    }

    public Vec3 add(Vec3 var1) {
        return this.addVector(var1.xCoord, var1.yCoord, var1.zCoord);
    }

    public Vec3 addVector(double var1, double var3, double var5) {
        return new Vec3(this.xCoord + var1, this.yCoord + var3, this.zCoord + var5);
    }

    public double distanceTo(Vec3 var1) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        return MathHelper.sqrt_double(d0 * d0 + d1 * d1 + d2 * d2);
    }

    public double squareDistanceTo(Vec3 var1) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public double lengthVector() {
        return MathHelper.sqrt_double(this.xCoord * this.xCoord + this.yCoord * this.yCoord + this.zCoord * this.zCoord);
    }

    public Vec3 getIntermediateWithXValue(Vec3 var1, double var2) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        if (d0 * d0 < 1.0E-7F) {
            return null;
        }

        double d3 = (var2 - this.xCoord) / d0;
        return !(d3 < 0.0) && !(d3 > 1.0) ? new Vec3(this.xCoord + d0 * d3, this.yCoord + d1 * d3, this.zCoord + d2 * d3) : null;
    }

    public Vec3 getIntermediateWithYValue(Vec3 var1, double var2) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        if (d1 * d1 < 1.0E-7F) {
            return null;
        }

        double d3 = (var2 - this.yCoord) / d1;
        return !(d3 < 0.0) && !(d3 > 1.0) ? new Vec3(this.xCoord + d0 * d3, this.yCoord + d1 * d3, this.zCoord + d2 * d3) : null;
    }

    public Vec3 getIntermediateWithZValue(Vec3 var1, double var2) {
        double d0 = var1.xCoord - this.xCoord;
        double d1 = var1.yCoord - this.yCoord;
        double d2 = var1.zCoord - this.zCoord;
        if (d2 * d2 < 1.0E-7F) {
            return null;
        }

        double d3 = (var2 - this.zCoord) / d2;
        return !(d3 < 0.0) && !(d3 > 1.0) ? new Vec3(this.xCoord + d0 * d3, this.yCoord + d1 * d3, this.zCoord + d2 * d3) : null;
    }

    @Override
    public String toString() {
        return "(" + this.xCoord + ", " + this.yCoord + ", " + this.zCoord + ")";
    }

    public Vec3 rotatePitch(float var1) {
        float f = MathHelper.cos(var1);
        float f1 = MathHelper.sin(var1);
        double d0 = this.xCoord;
        double d1 = this.yCoord * f + this.zCoord * f1;
        double d2 = this.zCoord * f - this.yCoord * f1;
        return new Vec3(d0, d1, d2);
    }

    public Vec3 rotateYaw(float var1) {
        float f = MathHelper.cos(var1);
        float f1 = MathHelper.sin(var1);
        double d0 = this.xCoord * f + this.zCoord * f1;
        double d1 = this.yCoord;
        double d2 = this.zCoord * f - this.xCoord * f1;
        return new Vec3(d0, d1, d2);
    }
}
