package net.minecraft.util;

public class ChatComponentSelector extends ChatComponentStyle {
    private final String selector;

    public ChatComponentSelector(String var1) {
        this.selector = var1;
    }

    public String getSelector() {
        return this.selector;
    }

    @Override
    public String getUnformattedTextForChat() {
        return this.selector;
    }

    public ChatComponentSelector createCopyImpl() {
        ChatComponentSelector chatcomponentselector = new ChatComponentSelector(this.selector);
        chatcomponentselector.setChatStyle(this.getChatStyle().createShallowCopy());

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.getSiblings()) {
            chatcomponentselector.appendSibling(ichatcomponent.createCopy());
        }

        return chatcomponentselector;
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ChatComponentSelector)) {
            return false;
        }

        ChatComponentSelector chatcomponentselector = (ChatComponentSelector)var1;
        return this.selector.equals(chatcomponentselector.selector) && super.equals(var1);
    }

    @Override
    public String toString() {
        return "SelectorComponent{pattern='" + this.selector + '\'' + ", siblings=" + this.siblings + ", style=" + this.getChatStyle() + '}';
    }

    @Override
    public IChatComponent createCopy() {
        return this.createCopyImpl();
    }
}
