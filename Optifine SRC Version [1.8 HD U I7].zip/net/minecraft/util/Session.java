package net.minecraft.util;

import com.google.common.collect.Maps;
import com.mojang.authlib.GameProfile;
import com.mojang.util.UUIDTypeAdapter;
import java.util.Map;
import java.util.UUID;

public class Session {
    private final String username;
    private final String playerID;
    private final String token;
    private final Session.Type sessionType;

    public Session(String var1, String var2, String var3, String var4) {
        this.username = var1;
        this.playerID = var2;
        this.token = var3;
        this.sessionType = Session.Type.setSessionType(var4);
    }

    public String getSessionID() {
        return "token:" + this.token + ":" + this.playerID;
    }

    public String getPlayerID() {
        return this.playerID;
    }

    public String getUsername() {
        return this.username;
    }

    public String getToken() {
        return this.token;
    }

    public GameProfile getProfile() {
        try {
            UUID uuid = UUIDTypeAdapter.fromString(this.getPlayerID());
            return new GameProfile(uuid, this.getUsername());
        } catch (IllegalArgumentException illegalargumentexception) {
            return new GameProfile(null, this.getUsername());
        }
    }

    public Session.Type getSessionType() {
        return this.sessionType;
    }

    public enum Type {
        LEGACY("legacy"),
        MOJANG("mojang");

        private static final Map SESSION_TYPES = Maps.newHashMap();
        private final String sessionType;

        Type(String var3) {
            this.sessionType = var3;
        }

        public static Session.Type setSessionType(String var0) {
            return (Session.Type)SESSION_TYPES.get(var0.toLowerCase());
        }

        static {
            for (Session.Type session$type : values()) {
                SESSION_TYPES.put(session$type.sessionType, session$type);
            }
        }
    }
}
