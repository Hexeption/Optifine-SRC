package net.minecraft.util;

public class Util {
    public static Util.EnumOS getOSType() {
        String s = System.getProperty("os.name").toLowerCase();
        if (s.contains("win")) {
            return Util.EnumOS.WINDOWS;
        } else if (s.contains("mac")) {
            return Util.EnumOS.OSX;
        } else if (s.contains("solaris")) {
            return Util.EnumOS.SOLARIS;
        } else if (s.contains("sunos")) {
            return Util.EnumOS.SOLARIS;
        } else if (s.contains("linux")) {
            return Util.EnumOS.LINUX;
        } else {
            return s.contains("unix") ? Util.EnumOS.LINUX : Util.EnumOS.UNKNOWN;
        }
    }

    public enum EnumOS {
        LINUX,
        SOLARIS,
        WINDOWS,
        OSX,
        UNKNOWN;
    }
}
