package net.minecraft.util;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;

public class EnumTypeAdapterFactory implements TypeAdapterFactory {
    @Override
    public TypeAdapter create(Gson var1, TypeToken var2) {
        Class oclass = var2.getRawType();
        if (!oclass.isEnum()) {
            return null;
        }

        final HashMap hashmap = Maps.newHashMap();

        for (Object object : oclass.getEnumConstants()) {
            hashmap.put(this.func_151232_a(object), object);
        }

        return new TypeAdapter() {
            @Override
            public void write(JsonWriter var1, Object var2x) throws IOException {
                if (var2x == null) {
                    var1.nullValue();
                } else {
                    var1.value(EnumTypeAdapterFactory.this.func_151232_a(var2x));
                }
            }

            @Override
            public Object read(JsonReader var1) throws IOException {
                if (var1.peek() == JsonToken.NULL) {
                    var1.nextNull();
                    return null;
                } else {
                    return hashmap.get(var1.nextString());
                }
            }
        };
    }

    private String func_151232_a(Object var1) {
        return var1 instanceof Enum ? ((Enum)var1).name().toLowerCase(Locale.US) : var1.toString().toLowerCase(Locale.US);
    }
}
