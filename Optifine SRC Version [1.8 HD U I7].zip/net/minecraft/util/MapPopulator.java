package net.minecraft.util;

import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

public class MapPopulator {
    public static Map createMap(Iterable var0, Iterable var1) {
        return populateMap(var0, var1, Maps.newLinkedHashMap());
    }

    public static Map populateMap(Iterable var0, Iterable var1, Map var2) {
        Iterator iterator = var1.iterator();

        for (Object object : var0) {
            var2.put(object, iterator.next());
        }

        if (iterator.hasNext()) {
            throw new NoSuchElementException();
        } else {
            return var2;
        }
    }
}
