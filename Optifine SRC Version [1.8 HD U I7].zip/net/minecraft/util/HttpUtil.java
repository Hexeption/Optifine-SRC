package net.minecraft.util;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.ServerSocket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HttpUtil {
    public static final ListeningExecutorService field_180193_a = MoreExecutors.listeningDecorator(
        Executors.newCachedThreadPool(new ThreadFactoryBuilder().setDaemon(true).setNameFormat("Downloader %d").build())
    );
    private static final AtomicInteger downloadThreadsStarted = new AtomicInteger(0);
    private static final Logger logger = LogManager.getLogger();

    public static String buildPostString(Map var0) {
        StringBuilder stringbuilder = new StringBuilder();

        for (Entry entry : (Iterable<Entry>) (Iterable) var0.entrySet()) {
            if (stringbuilder.length() > 0) {
                stringbuilder.append('&');
            }

            try {
                stringbuilder.append(URLEncoder.encode((String)entry.getKey(), "UTF-8"));
            } catch (UnsupportedEncodingException unsupportedencodingexception1) {
                unsupportedencodingexception1.printStackTrace();
            }

            if (entry.getValue() != null) {
                stringbuilder.append('=');

                try {
                    stringbuilder.append(URLEncoder.encode(entry.getValue().toString(), "UTF-8"));
                } catch (UnsupportedEncodingException unsupportedencodingexception) {
                    unsupportedencodingexception.printStackTrace();
                }
            }
        }

        return stringbuilder.toString();
    }

    public static String postMap(URL var0, Map var1, boolean var2) {
        return post(var0, buildPostString(var1), var2);
    }

    private static String post(URL var0, String var1, boolean var2) {
        try {
            Proxy proxy = MinecraftServer.getServer() == null ? null : MinecraftServer.getServer().getServerProxy();
            if (proxy == null) {
                proxy = Proxy.NO_PROXY;
            }

            HttpURLConnection httpurlconnection = (HttpURLConnection)var0.openConnection(proxy);
            httpurlconnection.setRequestMethod("POST");
            httpurlconnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            httpurlconnection.setRequestProperty("Content-Length", "" + var1.getBytes().length);
            httpurlconnection.setRequestProperty("Content-Language", "en-US");
            httpurlconnection.setUseCaches(false);
            httpurlconnection.setDoInput(true);
            httpurlconnection.setDoOutput(true);
            DataOutputStream dataoutputstream = new DataOutputStream(httpurlconnection.getOutputStream());
            dataoutputstream.writeBytes(var1);
            dataoutputstream.flush();
            dataoutputstream.close();
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(httpurlconnection.getInputStream()));
            StringBuffer stringbuffer = new StringBuffer();

            while (true) {
                String s = bufferedreader.readLine();
                if (s == null) {
                    bufferedreader.close();
                    return stringbuffer.toString();
                }

                stringbuffer.append(s);
                stringbuffer.append('\r');
            }
        } catch (Exception exception) {
            if (!var2) {
                logger.error("Could not post to " + var0, exception);
            }

            return "";
        }
    }

    public static ListenableFuture downloadResourcePack(
        final File var0, final String var1, final Map var2, final int var3, final IProgressUpdate var4, final Proxy var5
    ) {
        return field_180193_a.submit(new Runnable() {
            @Override
            public void run() {
                InputStream inputstream = null;
                DataOutputStream dataoutputstream = null;
                if (var4 != null) {
                    var4.resetProgressAndMessage("Downloading Resource Pack");
                    var4.displayLoadingString("Making Request...");
                }

                try {
                    byte[] abyte = new byte[4096];
                    URL url = new URL(var1);
                    URLConnection urlconnection = url.openConnection(var5);
                    float f = 0.0F;
                    float f1 = var2.entrySet().size();

                    for (Entry entry : (Iterable<Entry>) (Iterable) var2.entrySet()) {
                        urlconnection.setRequestProperty((String)entry.getKey(), (String)entry.getValue());
                        if (var4 != null) {
                            f++;
                            var4.setLoadingProgress((int)(f / f1 * 100.0F));
                        }
                    }

                    inputstream = urlconnection.getInputStream();
                    f1 = urlconnection.getContentLength();
                    int i = urlconnection.getContentLength();
                    if (var4 != null) {
                        var4.displayLoadingString(String.format("Downloading file (%.2f MB)...", f1 / 1000.0F / 1000.0F));
                    }

                    if (var0.exists()) {
                        long j = var0.length();
                        if (j == i) {
                            if (var4 != null) {
                                var4.setDoneWorking();
                            }

                            return;
                        }

                        HttpUtil.logger.warn("Deleting " + var0 + " as it does not match what we currently have (" + i + " vs our " + j + ").");
                        FileUtils.deleteQuietly(var0);
                    } else if (var0.getParentFile() != null) {
                        var0.getParentFile().mkdirs();
                    }

                    dataoutputstream = new DataOutputStream(new FileOutputStream(var0));
                    if (var3 > 0 && f1 > var3) {
                        if (var4 != null) {
                            var4.setDoneWorking();
                        }

                        throw new IOException("Filesize is bigger than maximum allowed (file is " + f + ", limit is " + var3 + ")");
                    } else {
                        int k = 0;

                        while (true) {
                            k = inputstream.read(abyte);
                            if (k < 0) {
                                if (var4 != null) {
                                    var4.setDoneWorking();
                                }

                                return;
                            }

                            f += k;
                            if (var4 != null) {
                                var4.setLoadingProgress((int)(f / f1 * 100.0F));
                            }

                            if (var3 > 0 && f > var3) {
                                if (var4 != null) {
                                    var4.setDoneWorking();
                                }

                                throw new IOException("Filesize was bigger than maximum allowed (got >= " + f + ", limit was " + var3 + ")");
                            }

                            dataoutputstream.write(abyte, 0, k);
                        }
                    }
                } catch (Throwable throwable) {
                    throwable.printStackTrace();
                } finally {
                    IOUtils.closeQuietly(inputstream);
                    IOUtils.closeQuietly(dataoutputstream);
                }
            }
        });
    }

    public static int getSuitableLanPort() throws IOException {
        ServerSocket serversocket = null;
        int i = -1;

        try {
            serversocket = new ServerSocket(0);
            i = serversocket.getLocalPort();
        } finally {
            try {
                if (serversocket != null) {
                    serversocket.close();
                }
            } catch (IOException ioexception) {
            }
        }

        return i;
    }

    public static String get(URL var0) throws IOException {
        HttpURLConnection httpurlconnection = (HttpURLConnection)var0.openConnection();
        httpurlconnection.setRequestMethod("GET");
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(httpurlconnection.getInputStream()));
        StringBuilder stringbuilder = new StringBuilder();

        while (true) {
            String s = bufferedreader.readLine();
            if (s == null) {
                bufferedreader.close();
                return stringbuilder.toString();
            }

            stringbuilder.append(s);
            stringbuilder.append('\r');
        }
    }
}
