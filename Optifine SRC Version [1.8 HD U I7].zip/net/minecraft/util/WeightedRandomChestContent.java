package net.minecraft.util;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntityDispenser;

public class WeightedRandomChestContent extends WeightedRandom.Item {
    private ItemStack theItemId;
    private int minStackSize;
    private int maxStackSize;

    public WeightedRandomChestContent(Item var1, int var2, int var3, int var4, int var5) {
        super(var5);
        this.theItemId = new ItemStack(var1, 1, var2);
        this.minStackSize = var3;
        this.maxStackSize = var4;
    }

    public WeightedRandomChestContent(ItemStack var1, int var2, int var3, int var4) {
        super(var4);
        this.theItemId = var1;
        this.minStackSize = var2;
        this.maxStackSize = var3;
    }

    public static void generateChestContents(Random var0, List var1, IInventory var2, int var3) {
        for (int i = 0; i < var3; i++) {
            WeightedRandomChestContent weightedrandomchestcontent = (WeightedRandomChestContent)WeightedRandom.getRandomItem(var0, var1);
            int j = weightedrandomchestcontent.minStackSize
                + var0.nextInt(weightedrandomchestcontent.maxStackSize - weightedrandomchestcontent.minStackSize + 1);
            if (weightedrandomchestcontent.theItemId.getMaxStackSize() >= j) {
                ItemStack itemstack1 = weightedrandomchestcontent.theItemId.copy();
                itemstack1.stackSize = j;
                var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack1);
            } else {
                for (int k = 0; k < j; k++) {
                    ItemStack itemstack = weightedrandomchestcontent.theItemId.copy();
                    itemstack.stackSize = 1;
                    var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack);
                }
            }
        }
    }

    public static void generateDispenserContents(Random var0, List var1, TileEntityDispenser var2, int var3) {
        for (int i = 0; i < var3; i++) {
            WeightedRandomChestContent weightedrandomchestcontent = (WeightedRandomChestContent)WeightedRandom.getRandomItem(var0, var1);
            int j = weightedrandomchestcontent.minStackSize
                + var0.nextInt(weightedrandomchestcontent.maxStackSize - weightedrandomchestcontent.minStackSize + 1);
            if (weightedrandomchestcontent.theItemId.getMaxStackSize() >= j) {
                ItemStack itemstack1 = weightedrandomchestcontent.theItemId.copy();
                itemstack1.stackSize = j;
                var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack1);
            } else {
                for (int k = 0; k < j; k++) {
                    ItemStack itemstack = weightedrandomchestcontent.theItemId.copy();
                    itemstack.stackSize = 1;
                    var2.setInventorySlotContents(var0.nextInt(var2.getSizeInventory()), itemstack);
                }
            }
        }
    }

    public static List func_177629_a(List var0, WeightedRandomChestContent... var1) {
        ArrayList arraylist = Lists.newArrayList(var0);
        Collections.addAll(arraylist, var1);
        return arraylist;
    }
}
