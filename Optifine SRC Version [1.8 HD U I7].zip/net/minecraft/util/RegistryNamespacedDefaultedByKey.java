package net.minecraft.util;

import org.apache.commons.lang3.Validate;

public class RegistryNamespacedDefaultedByKey extends RegistryNamespaced {
    private final Object defaultValueKey;
    private Object defaultValue;

    public RegistryNamespacedDefaultedByKey(Object var1) {
        this.defaultValueKey = var1;
    }

    @Override
    public void register(int var1, Object var2, Object var3) {
        if (this.defaultValueKey.equals(var2)) {
            this.defaultValue = var3;
        }

        super.register(var1, var2, var3);
    }

    public void validateKey() {
        Validate.notNull(this.defaultValueKey);
    }

    @Override
    public Object getObject(Object var1) {
        Object object = super.getObject(var1);
        return object == null ? this.defaultValue : object;
    }

    @Override
    public Object getObjectById(int var1) {
        Object object = super.getObjectById(var1);
        return object == null ? this.defaultValue : object;
    }
}
