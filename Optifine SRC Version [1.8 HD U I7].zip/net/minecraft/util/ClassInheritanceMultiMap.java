package net.minecraft.util;

import com.google.common.collect.AbstractIterator;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Iterators;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.ClassUtils.Interfaces;

public class ClassInheritanceMultiMap extends AbstractSet {
    private final Multimap map = HashMultimap.create();
    private final Set knownKeys = Sets.newIdentityHashSet();
    private final Class baseClass;

    public ClassInheritanceMultiMap(Class var1) {
        this.baseClass = var1;
        this.knownKeys.add(var1);
    }

    public void createLookup(Class var1) {
        for (Object object : this.map.get(this.getLookupKey(var1, false))) {
            if (var1.isAssignableFrom(object.getClass())) {
                this.map.put(var1, object);
            }
        }

        this.knownKeys.add(var1);
    }

    protected Class getLookupKey(Class var1, boolean var2) {
        for (Class oclass : ClassUtils.hierarchy(var1, Interfaces.INCLUDE)) {
            if (this.knownKeys.contains(oclass)) {
                if (oclass == this.baseClass && var2) {
                    this.createLookup(var1);
                }

                return oclass;
            }
        }

        throw new IllegalArgumentException("Don't know how to search for " + var1);
    }

    @Override
    public boolean add(Object var1) {
        for (Class oclass : (Iterable<Class>) (Iterable) this.knownKeys) {
            if (oclass.isAssignableFrom(var1.getClass())) {
                this.map.put(oclass, var1);
            }
        }

        return true;
    }

    @Override
    public boolean remove(Object var1) {
        Object object = var1;
        boolean flag = false;

        for (Class oclass : (Iterable<Class>) (Iterable) this.knownKeys) {
            if (oclass.isAssignableFrom(object.getClass())) {
                flag |= this.map.remove(oclass, object);
            }
        }

        return flag;
    }

    public Iterable getByClass(final Class var1) {
        return new Iterable() {
            @Override
            public Iterator iterator() {
                Iterator iterator = ClassInheritanceMultiMap.this.map.get(ClassInheritanceMultiMap.this.getLookupKey(var1, true)).iterator();
                return Iterators.filter(iterator, var1);
            }
        };
    }

    @Override
    public Iterator iterator() {
        final Iterator iterator = this.map.get(this.baseClass).iterator();
        return new AbstractIterator() {
            @Override
            protected Object computeNext() {
                return !iterator.hasNext() ? this.endOfData() : iterator.next();
            }
        };
    }

    @Override
    public int size() {
        return this.map.get(this.baseClass).size();
    }
}
