package net.minecraft.util;

public class ChatComponentText extends ChatComponentStyle {
    private final String text;

    public ChatComponentText(String var1) {
        this.text = var1;
    }

    public String getChatComponentText_TextValue() {
        return this.text;
    }

    @Override
    public String getUnformattedTextForChat() {
        return this.text;
    }

    public ChatComponentText createCopy() {
        ChatComponentText chatcomponenttext = new ChatComponentText(this.text);
        chatcomponenttext.setChatStyle(this.getChatStyle().createShallowCopy());

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.getSiblings()) {
            chatcomponenttext.appendSibling(ichatcomponent.createCopy());
        }

        return chatcomponenttext;
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ChatComponentText)) {
            return false;
        }

        ChatComponentText chatcomponenttext = (ChatComponentText)var1;
        return this.text.equals(chatcomponenttext.getChatComponentText_TextValue()) && super.equals(var1);
    }

    @Override
    public String toString() {
        return "TextComponent{text='" + this.text + '\'' + ", siblings=" + this.siblings + ", style=" + this.getChatStyle() + '}';
    }
}
