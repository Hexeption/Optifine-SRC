package net.minecraft.util;

public class RegistryDefaulted extends RegistrySimple {
    private final Object defaultObject;

    public RegistryDefaulted(Object var1) {
        this.defaultObject = var1;
    }

    @Override
    public Object getObject(Object var1) {
        Object object = super.getObject(var1);
        return object == null ? this.defaultObject : object;
    }
}
