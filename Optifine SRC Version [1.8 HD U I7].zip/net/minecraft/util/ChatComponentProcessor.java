package net.minecraft.util;

import java.util.List;
import net.minecraft.command.CommandException;
import net.minecraft.command.EntityNotFoundException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.PlayerSelector;
import net.minecraft.entity.Entity;

public class ChatComponentProcessor {
    public static IChatComponent processComponent(ICommandSender var0, IChatComponent var1, Entity var2) throws CommandException {
        IChatComponent chatcomponentscore = null;
        if (var1 instanceof ChatComponentScore) {
            ChatComponentScore chatcomponentscore1 = (ChatComponentScore)var1;
            String s = chatcomponentscore1.getName();
            if (PlayerSelector.hasArguments(s)) {
                List list = PlayerSelector.matchEntities(var0, s, Entity.class);
                if (list.size() != 1) {
                    throw new EntityNotFoundException();
                }

                s = ((Entity)list.get(0)).getCommandSenderName();
            }

            chatcomponentscore = var2 != null && s.equals("*")
                ? new ChatComponentScore(var2.getCommandSenderName(), chatcomponentscore1.getObjective())
                : new ChatComponentScore(s, chatcomponentscore1.getObjective());
            ((ChatComponentScore) chatcomponentscore).setValue(chatcomponentscore1.getUnformattedTextForChat());
        } else if (var1 instanceof ChatComponentSelector) {
            String s1 = ((ChatComponentSelector)var1).getSelector();
            chatcomponentscore = PlayerSelector.matchEntitiesToChatComponent(var0, s1);
            if (chatcomponentscore == null) {
                chatcomponentscore = new ChatComponentText("");
            }
        } else if (var1 instanceof ChatComponentText) {
            chatcomponentscore = new ChatComponentText(((ChatComponentText)var1).getChatComponentText_TextValue());
        } else {
            if (!(var1 instanceof ChatComponentTranslation)) {
                return var1;
            }

            Object[] aobject = ((ChatComponentTranslation)var1).getFormatArgs();

            for (int i = 0; i < aobject.length; i++) {
                Object object = aobject[i];
                if (object instanceof IChatComponent) {
                    aobject[i] = processComponent(var0, (IChatComponent)object, var2);
                }
            }

            chatcomponentscore = new ChatComponentTranslation(((ChatComponentTranslation)var1).getKey(), aobject);
        }

        ChatStyle chatstyle = var1.getChatStyle();
        if (chatstyle != null) {
            chatcomponentscore.setChatStyle(chatstyle.createShallowCopy());
        }

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) var1.getSiblings()) {
            chatcomponentscore.appendSibling(processComponent(var0, ichatcomponent, var2));
        }

        return chatcomponentscore;
    }
}
