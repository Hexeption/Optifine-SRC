package net.minecraft.util;

import com.google.common.collect.AbstractIterator;
import java.util.Iterator;
import net.minecraft.entity.Entity;

public class BlockPos extends Vec3i {
    public static final BlockPos ORIGIN = new BlockPos(0, 0, 0);
    private static final int NUM_X_BITS = 1 + MathHelper.calculateLogBaseTwo(MathHelper.roundUpToPowerOfTwo(30000000));
    private static final int NUM_Z_BITS = NUM_X_BITS;
    private static final int NUM_Y_BITS = 64 - NUM_X_BITS - NUM_Z_BITS;
    private static final int Y_SHIFT = 0 + NUM_Z_BITS;
    private static final int X_SHIFT = Y_SHIFT + NUM_Y_BITS;
    private static final long X_MASK = (1L << NUM_X_BITS) - 1L;
    private static final long Y_MASK = (1L << NUM_Y_BITS) - 1L;
    private static final long Z_MASK = (1L << NUM_Z_BITS) - 1L;

    public BlockPos(int var1, int var2, int var3) {
        super(var1, var2, var3);
    }

    public BlockPos(double var1, double var3, double var5) {
        super(var1, var3, var5);
    }

    public BlockPos(Entity var1) {
        this(var1.posX, var1.posY, var1.posZ);
    }

    public BlockPos(Vec3 var1) {
        this(var1.xCoord, var1.yCoord, var1.zCoord);
    }

    public BlockPos(Vec3i var1) {
        this(var1.getX(), var1.getY(), var1.getZ());
    }

    public BlockPos add(double var1, double var3, double var5) {
        return new BlockPos(this.getX() + var1, this.getY() + var3, this.getZ() + var5);
    }

    public BlockPos add(int var1, int var2, int var3) {
        return new BlockPos(this.getX() + var1, this.getY() + var2, this.getZ() + var3);
    }

    public BlockPos add(Vec3i var1) {
        return new BlockPos(this.getX() + var1.getX(), this.getY() + var1.getY(), this.getZ() + var1.getZ());
    }

    public BlockPos subtract(Vec3i var1) {
        return new BlockPos(this.getX() - var1.getX(), this.getY() - var1.getY(), this.getZ() - var1.getZ());
    }

    public BlockPos multiply(int var1) {
        return new BlockPos(this.getX() * var1, this.getY() * var1, this.getZ() * var1);
    }

    public BlockPos up() {
        return this.up(1);
    }

    public BlockPos up(int var1) {
        return this.offset(EnumFacing.UP, var1);
    }

    public BlockPos down() {
        return this.down(1);
    }

    public BlockPos down(int var1) {
        return this.offset(EnumFacing.DOWN, var1);
    }

    public BlockPos north() {
        return this.north(1);
    }

    public BlockPos north(int var1) {
        return this.offset(EnumFacing.NORTH, var1);
    }

    public BlockPos south() {
        return this.south(1);
    }

    public BlockPos south(int var1) {
        return this.offset(EnumFacing.SOUTH, var1);
    }

    public BlockPos west() {
        return this.west(1);
    }

    public BlockPos west(int var1) {
        return this.offset(EnumFacing.WEST, var1);
    }

    public BlockPos east() {
        return this.east(1);
    }

    public BlockPos east(int var1) {
        return this.offset(EnumFacing.EAST, var1);
    }

    public BlockPos offset(EnumFacing var1) {
        return this.offset(var1, 1);
    }

    public BlockPos offset(EnumFacing var1, int var2) {
        return new BlockPos(
            this.getX() + var1.getFrontOffsetX() * var2, this.getY() + var1.getFrontOffsetY() * var2, this.getZ() + var1.getFrontOffsetZ() * var2
        );
    }

    public BlockPos crossProductBP(Vec3i var1) {
        return new BlockPos(
            this.getY() * var1.getZ() - this.getZ() * var1.getY(),
            this.getZ() * var1.getX() - this.getX() * var1.getZ(),
            this.getX() * var1.getY() - this.getY() * var1.getX()
        );
    }

    public long toLong() {
        return (this.getX() & X_MASK) << X_SHIFT | (this.getY() & Y_MASK) << Y_SHIFT | (this.getZ() & Z_MASK) << 0;
    }

    public static BlockPos fromLong(long var0) {
        int i = (int)(var0 << 64 - X_SHIFT - NUM_X_BITS >> 64 - NUM_X_BITS);
        int j = (int)(var0 << 64 - Y_SHIFT - NUM_Y_BITS >> 64 - NUM_Y_BITS);
        int k = (int)(var0 << 64 - NUM_Z_BITS >> 64 - NUM_Z_BITS);
        return new BlockPos(i, j, k);
    }

    public static Iterable getAllInBox(BlockPos var0, BlockPos var1) {
        final BlockPos blockpos = new BlockPos(Math.min(var0.getX(), var1.getX()), Math.min(var0.getY(), var1.getY()), Math.min(var0.getZ(), var1.getZ()));
        final BlockPos blockpos1 = new BlockPos(Math.max(var0.getX(), var1.getX()), Math.max(var0.getY(), var1.getY()), Math.max(var0.getZ(), var1.getZ()));
        return new Iterable() {
            @Override
            public Iterator iterator() {
                return new AbstractIterator() {
                    private BlockPos lastReturned = null;

                    protected BlockPos computeNext0() {
                        if (this.lastReturned == null) {
                            this.lastReturned = blockpos;
                            return this.lastReturned;
                        }

                        if (this.lastReturned.equals(blockpos1)) {
                            return (BlockPos)this.endOfData();
                        }

                        int i = this.lastReturned.getX();
                        int j = this.lastReturned.getY();
                        int k = this.lastReturned.getZ();
                        if (i < blockpos1.getX()) {
                            i++;
                        } else if (j < blockpos1.getY()) {
                            i = blockpos.getX();
                            j++;
                        } else if (k < blockpos1.getZ()) {
                            i = blockpos.getX();
                            j = blockpos.getY();
                            k++;
                        }

                        this.lastReturned = new BlockPos(i, j, k);
                        return this.lastReturned;
                    }

                    @Override
                    protected Object computeNext() {
                        return this.computeNext0();
                    }
                };
            }
        };
    }

    public static Iterable getAllInBoxMutable(BlockPos var0, BlockPos var1) {
        final BlockPos blockpos = new BlockPos(Math.min(var0.getX(), var1.getX()), Math.min(var0.getY(), var1.getY()), Math.min(var0.getZ(), var1.getZ()));
        final BlockPos blockpos1 = new BlockPos(Math.max(var0.getX(), var1.getX()), Math.max(var0.getY(), var1.getY()), Math.max(var0.getZ(), var1.getZ()));
        return new Iterable() {
            @Override
            public Iterator iterator() {
                return new AbstractIterator() {
                    private BlockPos.MutableBlockPos theBlockPos = null;

                    protected BlockPos.MutableBlockPos computeNext0() {
                        if (this.theBlockPos == null) {
                            this.theBlockPos = new BlockPos.MutableBlockPos(blockpos.getX(), blockpos.getY(), blockpos.getZ());
                            return this.theBlockPos;
                        }

                        if (this.theBlockPos.equals(blockpos1)) {
                            return (BlockPos.MutableBlockPos)this.endOfData();
                        }

                        int i = this.theBlockPos.getX();
                        int j = this.theBlockPos.getY();
                        int k = this.theBlockPos.getZ();
                        if (i < blockpos1.getX()) {
                            i++;
                        } else if (j < blockpos1.getY()) {
                            i = blockpos.getX();
                            j++;
                        } else if (k < blockpos1.getZ()) {
                            i = blockpos.getX();
                            j = blockpos.getY();
                            k++;
                        }

                        this.theBlockPos.x = i;
                        this.theBlockPos.y = j;
                        this.theBlockPos.z = k;
                        return this.theBlockPos;
                    }

                    @Override
                    protected Object computeNext() {
                        return this.computeNext0();
                    }
                };
            }
        };
    }

    @Override
    public Vec3i crossProduct(Vec3i var1) {
        return this.crossProductBP(var1);
    }

    public static final class MutableBlockPos extends BlockPos {
        public int x;
        public int y;
        public int z;

        private MutableBlockPos(int var1, int var2, int var3) {
            super(0, 0, 0);
            this.x = var1;
            this.y = var2;
            this.z = var3;
        }

        @Override
        public int getX() {
            return this.x;
        }

        @Override
        public int getY() {
            return this.y;
        }

        @Override
        public int getZ() {
            return this.z;
        }
    }
}
