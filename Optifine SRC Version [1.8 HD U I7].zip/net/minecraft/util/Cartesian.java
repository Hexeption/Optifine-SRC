package net.minecraft.util;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.UnmodifiableIterator;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class Cartesian {
    public static Iterable cartesianProduct(Class var0, Iterable var1) {
        return new Cartesian.Product(var0, (Iterable[])toArray(Iterable.class, var1));
    }

    public static Iterable cartesianProduct(Iterable var0) {
        return arraysAsLists(cartesianProduct(Object.class, var0));
    }

    private static Iterable arraysAsLists(Iterable var0) {
        return Iterables.transform(var0, new Cartesian.GetList());
    }

    private static Object[] toArray(Class var0, Iterable var1) {
        ArrayList arraylist = Lists.newArrayList();

        for (Object object : var1) {
            arraylist.add(object);
        }

        return arraylist.toArray(createArray(var0, arraylist.size()));
    }

    private static Object[] createArray(Class var0, int var1) {
        return (Object[])Array.newInstance(var0, var1);
    }

    static class GetList implements Function {
        private GetList() {
        }

        public List apply(Object[] var1) {
            return Arrays.asList(var1);
        }

        @Override
        public Object apply(Object var1) {
            return this.apply((Object[])var1);
        }
    }

    static class Product implements Iterable {
        private final Class clazz;
        private final Iterable[] iterables;

        private Product(Class var1, Iterable[] var2) {
            this.clazz = var1;
            this.iterables = var2;
        }

        @Override
        public Iterator iterator() {
            return this.iterables.length <= 0
                ? Collections.singletonList(Cartesian.createArray(this.clazz, 0)).iterator()
                : new Cartesian.Product.ProductIterator(this.clazz, this.iterables);
        }

        static class ProductIterator extends UnmodifiableIterator {
            private int index = -2;
            private final Iterable[] iterables;
            private final Iterator[] iterators;
            private final Object[] results;

            private ProductIterator(Class var1, Iterable[] var2) {
                this.iterables = var2;
                this.iterators = (Iterator[])Cartesian.createArray(Iterator.class, this.iterables.length);

                for (int i = 0; i < this.iterables.length; i++) {
                    this.iterators[i] = var2[i].iterator();
                }

                this.results = Cartesian.createArray(var1, this.iterators.length);
            }

            private void endOfData() {
                this.index = -1;
                Arrays.fill(this.iterators, null);
                Arrays.fill(this.results, null);
            }

            @Override
            public boolean hasNext() {
                if (this.index == -2) {
                    this.index = 0;

                    for (Iterator iterator1 : this.iterators) {
                        if (!iterator1.hasNext()) {
                            this.endOfData();
                            break;
                        }
                    }

                    return true;
                } else {
                    if (this.index >= this.iterators.length) {
                        for (this.index = this.iterators.length - 1; this.index >= 0; this.index--) {
                            Iterator iterator = this.iterators[this.index];
                            if (iterator.hasNext()) {
                                break;
                            }

                            if (this.index == 0) {
                                this.endOfData();
                                break;
                            }

                            iterator = this.iterables[this.index].iterator();
                            this.iterators[this.index] = iterator;
                            if (!iterator.hasNext()) {
                                this.endOfData();
                                break;
                            }
                        }
                    }

                    return this.index >= 0;
                }
            }

            public Object[] next0() {
                if (!this.hasNext()) {
                    throw new NoSuchElementException();
                }

                while (this.index < this.iterators.length) {
                    this.results[this.index] = this.iterators[this.index].next();
                    this.index++;
                }

                return (Object[])this.results.clone();
            }

            @Override
            public Object next() {
                return this.next0();
            }
        }
    }
}
