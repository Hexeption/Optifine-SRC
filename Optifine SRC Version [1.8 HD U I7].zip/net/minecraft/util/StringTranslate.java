package net.minecraft.util;

import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import java.io.IOException;
import java.io.InputStream;
import java.util.IllegalFormatException;
import java.util.Map;
import java.util.regex.Pattern;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;

public class StringTranslate {
    private static final Pattern numericVariablePattern = Pattern.compile("%(\\d+\\$)?[\\d\\.]*[df]");
    private static final Splitter equalSignSplitter = Splitter.on('=').limit(2);
    private static StringTranslate instance = new StringTranslate();
    private final Map languageList = Maps.newHashMap();
    private long lastUpdateTimeInMilliseconds;

    public StringTranslate() {
        try {
            InputStream inputstream = StringTranslate.class.getResourceAsStream("/assets/minecraft/lang/en_US.lang");

            for (String s : IOUtils.readLines(inputstream, Charsets.UTF_8)) {
                if (!s.isEmpty() && s.charAt(0) != '#') {
                    String[] astring = Iterables.toArray(equalSignSplitter.split(s), String.class);
                    if (astring != null && astring.length == 2) {
                        String s1 = astring[0];
                        String s2 = numericVariablePattern.matcher(astring[1]).replaceAll("%$1s");
                        this.languageList.put(s1, s2);
                    }
                }
            }

            this.lastUpdateTimeInMilliseconds = System.currentTimeMillis();
        } catch (IOException ioexception) {
        }
    }

    static StringTranslate getInstance() {
        return instance;
    }

    public static synchronized void replaceWith(Map var0) {
        instance.languageList.clear();
        instance.languageList.putAll(var0);
        instance.lastUpdateTimeInMilliseconds = System.currentTimeMillis();
    }

    public synchronized String translateKey(String var1) {
        return this.tryTranslateKey(var1);
    }

    public synchronized String translateKeyFormat(String var1, Object... var2) {
        String s = this.tryTranslateKey(var1);

        try {
            return String.format(s, var2);
        } catch (IllegalFormatException illegalformatexception) {
            return "Format error: " + s;
        }
    }

    private String tryTranslateKey(String var1) {
        String s = (String)this.languageList.get(var1);
        return s == null ? var1 : s;
    }

    public synchronized boolean isKeyTranslated(String var1) {
        return this.languageList.containsKey(var1);
    }

    public long getLastUpdateTimeInMilliseconds() {
        return this.lastUpdateTimeInMilliseconds;
    }
}
