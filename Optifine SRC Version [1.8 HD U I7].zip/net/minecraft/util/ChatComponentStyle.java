package net.minecraft.util;

import com.google.common.base.Function;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;

public abstract class ChatComponentStyle implements IChatComponent {
    protected List siblings = Lists.newArrayList();
    private ChatStyle style;

    @Override
    public IChatComponent appendSibling(IChatComponent var1) {
        var1.getChatStyle().setParentStyle(this.getChatStyle());
        this.siblings.add(var1);
        return this;
    }

    @Override
    public List getSiblings() {
        return this.siblings;
    }

    @Override
    public IChatComponent appendText(String var1) {
        return this.appendSibling(new ChatComponentText(var1));
    }

    @Override
    public IChatComponent setChatStyle(ChatStyle var1) {
        this.style = var1;

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.siblings) {
            ichatcomponent.getChatStyle().setParentStyle(this.getChatStyle());
        }

        return this;
    }

    @Override
    public ChatStyle getChatStyle() {
        if (this.style == null) {
            this.style = new ChatStyle();

            for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this.siblings) {
                ichatcomponent.getChatStyle().setParentStyle(this.style);
            }
        }

        return this.style;
    }

    @Override
    public Iterator iterator() {
        return Iterators.concat(Iterators.forArray(this), createDeepCopyIterator(this.siblings));
    }

    @Override
    public final String getUnformattedText() {
        StringBuilder stringbuilder = new StringBuilder();

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this) {
            stringbuilder.append(ichatcomponent.getUnformattedTextForChat());
        }

        return stringbuilder.toString();
    }

    @Override
    public final String getFormattedText() {
        StringBuilder stringbuilder = new StringBuilder();

        for (IChatComponent ichatcomponent : (Iterable<IChatComponent>) (Iterable) this) {
            stringbuilder.append(ichatcomponent.getChatStyle().getFormattingCode());
            stringbuilder.append(ichatcomponent.getUnformattedTextForChat());
            stringbuilder.append(EnumChatFormatting.RESET);
        }

        return stringbuilder.toString();
    }

    public static Iterator createDeepCopyIterator(Iterable var0) {
        Iterator iterator = Iterators.concat(Iterators.transform(var0.iterator(), new Function() {
            public Iterator apply(IChatComponent var1) {
                return var1.iterator();
            }

            @Override
            public Object apply(Object var1) {
                return this.apply((IChatComponent)var1);
            }
        }));
        return Iterators.transform(iterator, new Function() {
            public IChatComponent apply(IChatComponent var1) {
                IChatComponent ichatcomponent = var1.createCopy();
                ichatcomponent.setChatStyle(ichatcomponent.getChatStyle().createDeepCopy());
                return ichatcomponent;
            }

            @Override
            public Object apply(Object var1) {
                return this.apply((IChatComponent)var1);
            }
        });
    }

    @Override
    public boolean equals(Object var1) {
        if (this == var1) {
            return true;
        }

        if (!(var1 instanceof ChatComponentStyle)) {
            return false;
        }

        ChatComponentStyle chatcomponentstyle = (ChatComponentStyle)var1;
        return this.siblings.equals(chatcomponentstyle.siblings) && this.getChatStyle().equals(chatcomponentstyle.getChatStyle());
    }

    @Override
    public int hashCode() {
        return 31 * this.style.hashCode() + this.siblings.hashCode();
    }

    @Override
    public String toString() {
        return "BaseComponent{style=" + this.style + ", siblings=" + this.siblings + '}';
    }
}
