package net.minecraft.pathfinding;

public class Path {
    private PathPoint[] pathPoints = new PathPoint[1024];
    private int count;

    public PathPoint addPoint(PathPoint var1) {
        if (var1.index >= 0) {
            throw new IllegalStateException("OW KNOWS!");
        }

        if (this.count == this.pathPoints.length) {
            PathPoint[] apathpoint = new PathPoint[this.count << 1];
            System.arraycopy(this.pathPoints, 0, apathpoint, 0, this.count);
            this.pathPoints = apathpoint;
        }

        this.pathPoints[this.count] = var1;
        var1.index = this.count;
        this.sortBack(this.count++);
        return var1;
    }

    public void clearPath() {
        this.count = 0;
    }

    public PathPoint dequeue() {
        PathPoint pathpoint = this.pathPoints[0];
        this.pathPoints[0] = this.pathPoints[--this.count];
        this.pathPoints[this.count] = null;
        if (this.count > 0) {
            this.sortForward(0);
        }

        pathpoint.index = -1;
        return pathpoint;
    }

    public void changeDistance(PathPoint var1, float var2) {
        float f = var1.distanceToTarget;
        var1.distanceToTarget = var2;
        if (var2 < f) {
            this.sortBack(var1.index);
        } else {
            this.sortForward(var1.index);
        }
    }

    private void sortBack(int var1) {
        PathPoint pathpoint = this.pathPoints[var1];
        float f = pathpoint.distanceToTarget;

        while (var1 > 0) {
            int i = var1 - 1 >> 1;
            PathPoint pathpoint1 = this.pathPoints[i];
            if (!(f < pathpoint1.distanceToTarget)) {
                break;
            }

            this.pathPoints[var1] = pathpoint1;
            pathpoint1.index = var1;
            var1 = i;
        }

        this.pathPoints[var1] = pathpoint;
        pathpoint.index = var1;
    }

    private void sortForward(int var1) {
        PathPoint pathpoint = this.pathPoints[var1];
        float f = pathpoint.distanceToTarget;

        while (true) {
            int i = 1 + (var1 << 1);
            int j = i + 1;
            if (i >= this.count) {
                break;
            }

            PathPoint pathpoint1 = this.pathPoints[i];
            float f1 = pathpoint1.distanceToTarget;
            PathPoint pathpoint2;
            float f2;
            if (j >= this.count) {
                pathpoint2 = null;
                f2 = Float.POSITIVE_INFINITY;
            } else {
                pathpoint2 = this.pathPoints[j];
                f2 = pathpoint2.distanceToTarget;
            }

            if (f1 < f2) {
                if (!(f1 < f)) {
                    break;
                }

                this.pathPoints[var1] = pathpoint1;
                pathpoint1.index = var1;
                var1 = i;
            } else {
                if (!(f2 < f)) {
                    break;
                }

                this.pathPoints[var1] = pathpoint2;
                pathpoint2.index = var1;
                var1 = j;
            }
        }

        this.pathPoints[var1] = pathpoint;
        pathpoint.index = var1;
    }

    public boolean isPathEmpty() {
        return this.count == 0;
    }
}
