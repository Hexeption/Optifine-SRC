package net.minecraft.pathfinding;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.pathfinder.WalkNodeProcessor;

public class PathNavigateGround extends PathNavigate {
    protected WalkNodeProcessor nodeProcessor;
    private boolean shouldAvoidSun;

    public PathNavigateGround(EntityLiving var1, World var2) {
        super(var1, var2);
    }

    @Override
    protected PathFinder getPathFinder() {
        this.nodeProcessor = new WalkNodeProcessor();
        this.nodeProcessor.setEnterDoors(true);
        return new PathFinder(this.nodeProcessor);
    }

    @Override
    protected boolean canNavigate() {
        return this.theEntity.onGround
            || this.getCanSwim() && this.isInLiquid()
            || this.theEntity.isRiding() && this.theEntity instanceof EntityZombie && this.theEntity.ridingEntity instanceof EntityChicken;
    }

    @Override
    protected Vec3 getEntityPosition() {
        return new Vec3(this.theEntity.posX, this.getPathablePosY(), this.theEntity.posZ);
    }

    private int getPathablePosY() {
        if (this.theEntity.isInWater() && this.getCanSwim()) {
            int i = (int)this.theEntity.getEntityBoundingBox().minY;
            Block block = this.worldObj
                .getBlockState(new BlockPos(MathHelper.floor_double(this.theEntity.posX), i, MathHelper.floor_double(this.theEntity.posZ)))
                .getBlock();
            int j = 0;

            while (block == Blocks.flowing_water || block == Blocks.water) {
                block = this.worldObj
                    .getBlockState(new BlockPos(MathHelper.floor_double(this.theEntity.posX), ++i, MathHelper.floor_double(this.theEntity.posZ)))
                    .getBlock();
                if (++j > 16) {
                    return (int)this.theEntity.getEntityBoundingBox().minY;
                }
            }

            return i;
        } else {
            return (int)(this.theEntity.getEntityBoundingBox().minY + 0.5);
        }
    }

    @Override
    protected void removeSunnyPath() {
        super.removeSunnyPath();
        if (this.shouldAvoidSun) {
            if (this.worldObj
                .canSeeSky(
                    new BlockPos(
                        MathHelper.floor_double(this.theEntity.posX),
                        (int)(this.theEntity.getEntityBoundingBox().minY + 0.5),
                        MathHelper.floor_double(this.theEntity.posZ)
                    )
                )) {
                return;
            }

            for (int i = 0; i < this.currentPath.getCurrentPathLength(); i++) {
                PathPoint pathpoint = this.currentPath.getPathPointFromIndex(i);
                if (this.worldObj.canSeeSky(new BlockPos(pathpoint.xCoord, pathpoint.yCoord, pathpoint.zCoord))) {
                    this.currentPath.setCurrentPathLength(i - 1);
                    return;
                }
            }
        }
    }

    @Override
    protected boolean isDirectPathBetweenPoints(Vec3 var1, Vec3 var2, int var3, int var4, int var5) {
        int i = MathHelper.floor_double(var1.xCoord);
        int j = MathHelper.floor_double(var1.zCoord);
        double d0 = var2.xCoord - var1.xCoord;
        double d1 = var2.zCoord - var1.zCoord;
        double d2 = d0 * d0 + d1 * d1;
        if (d2 < 1.0E-8) {
            return false;
        }

        double d3 = 1.0 / Math.sqrt(d2);
        d0 *= d3;
        d1 *= d3;
        var3 += 2;
        var5 += 2;
        if (!this.isSafeToStandAt(i, (int)var1.yCoord, j, var3, var4, var5, var1, d0, d1)) {
            return false;
        }

        var3 -= 2;
        var5 -= 2;
        double d4 = 1.0 / Math.abs(d0);
        double d5 = 1.0 / Math.abs(d1);
        double d6 = i * 1 - var1.xCoord;
        double d7 = j * 1 - var1.zCoord;
        if (d0 >= 0.0) {
            d6++;
        }

        if (d1 >= 0.0) {
            d7++;
        }

        d6 /= d0;
        d7 /= d1;
        int k = d0 < 0.0 ? -1 : 1;
        int l = d1 < 0.0 ? -1 : 1;
        int i1 = MathHelper.floor_double(var2.xCoord);
        int j1 = MathHelper.floor_double(var2.zCoord);
        int k1 = i1 - i;
        int l1 = j1 - j;

        while (k1 * k > 0 || l1 * l > 0) {
            if (d6 < d7) {
                d6 += d4;
                i += k;
                k1 = i1 - i;
            } else {
                d7 += d5;
                j += l;
                l1 = j1 - j;
            }

            if (!this.isSafeToStandAt(i, (int)var1.yCoord, j, var3, var4, var5, var1, d0, d1)) {
                return false;
            }
        }

        return true;
    }

    private boolean isSafeToStandAt(int var1, int var2, int var3, int var4, int var5, int var6, Vec3 var7, double var8, double var10) {
        int i = var1 - var4 / 2;
        int j = var3 - var6 / 2;
        if (!this.isPositionClear(i, var2, j, var4, var5, var6, var7, var8, var10)) {
            return false;
        }

        for (int k = i; k < i + var4; k++) {
            for (int l = j; l < j + var6; l++) {
                double d0 = k + 0.5 - var7.xCoord;
                double d1 = l + 0.5 - var7.zCoord;
                if (!(d0 * var8 + d1 * var10 < 0.0)) {
                    Block block = this.worldObj.getBlockState(new BlockPos(k, var2 - 1, l)).getBlock();
                    Material material = block.getMaterial();
                    if (material == Material.air) {
                        return false;
                    }

                    if (material == Material.water && !this.theEntity.isInWater()) {
                        return false;
                    }

                    if (material == Material.lava) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private boolean isPositionClear(int var1, int var2, int var3, int var4, int var5, int var6, Vec3 var7, double var8, double var10) {
        for (BlockPos blockpos : (Iterable<BlockPos>) (Iterable) BlockPos.getAllInBox(new BlockPos(var1, var2, var3), new BlockPos(var1 + var4 - 1, var2 + var5 - 1, var3 + var6 - 1))) {
            double d0 = blockpos.getX() + 0.5 - var7.xCoord;
            double d1 = blockpos.getZ() + 0.5 - var7.zCoord;
            if (!(d0 * var8 + d1 * var10 < 0.0)) {
                Block block = this.worldObj.getBlockState(blockpos).getBlock();
                if (!block.isPassable(this.worldObj, blockpos)) {
                    return false;
                }
            }
        }

        return true;
    }

    public void setAvoidsWater(boolean var1) {
        this.nodeProcessor.setAvoidsWater(var1);
    }

    public boolean getAvoidsWater() {
        return this.nodeProcessor.getAvoidsWater();
    }

    public void setBreakDoors(boolean var1) {
        this.nodeProcessor.setBreakDoors(var1);
    }

    public void setEnterDoors(boolean var1) {
        this.nodeProcessor.setEnterDoors(var1);
    }

    public boolean getEnterDoors() {
        return this.nodeProcessor.getEnterDoors();
    }

    public void setCanSwim(boolean var1) {
        this.nodeProcessor.setCanSwim(var1);
    }

    public boolean getCanSwim() {
        return this.nodeProcessor.getCanSwim();
    }

    public void setAvoidSun(boolean var1) {
        this.shouldAvoidSun = var1;
    }
}
