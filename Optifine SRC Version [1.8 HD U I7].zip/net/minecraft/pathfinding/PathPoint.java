package net.minecraft.pathfinding;

import net.minecraft.util.MathHelper;

public class PathPoint {
    public final int xCoord;
    public final int yCoord;
    public final int zCoord;
    private final int hash;
    int index = -1;
    float totalPathDistance;
    float distanceToNext;
    float distanceToTarget;
    PathPoint previous;
    public boolean visited;

    public PathPoint(int var1, int var2, int var3) {
        this.xCoord = var1;
        this.yCoord = var2;
        this.zCoord = var3;
        this.hash = makeHash(var1, var2, var3);
    }

    public static int makeHash(int var0, int var1, int var2) {
        return var1 & 0xFF
            | (var0 & Short.MAX_VALUE) << 8
            | (var2 & Short.MAX_VALUE) << 24
            | (var0 < 0 ? Integer.MIN_VALUE : 0)
            | (var2 < 0 ? -Short.MIN_VALUE : 0);
    }

    public float distanceTo(PathPoint var1) {
        float f = var1.xCoord - this.xCoord;
        float f1 = var1.yCoord - this.yCoord;
        float f2 = var1.zCoord - this.zCoord;
        return MathHelper.sqrt_float(f * f + f1 * f1 + f2 * f2);
    }

    public float distanceToSquared(PathPoint var1) {
        float f = var1.xCoord - this.xCoord;
        float f1 = var1.yCoord - this.yCoord;
        float f2 = var1.zCoord - this.zCoord;
        return f * f + f1 * f1 + f2 * f2;
    }

    @Override
    public boolean equals(Object var1) {
        if (!(var1 instanceof PathPoint)) {
            return false;
        }

        PathPoint pathpoint = (PathPoint)var1;
        return this.hash == pathpoint.hash && this.xCoord == pathpoint.xCoord && this.yCoord == pathpoint.yCoord && this.zCoord == pathpoint.zCoord;
    }

    @Override
    public int hashCode() {
        return this.hash;
    }

    public boolean isAssigned() {
        return this.index >= 0;
    }

    @Override
    public String toString() {
        return this.xCoord + ", " + this.yCoord + ", " + this.zCoord;
    }
}
