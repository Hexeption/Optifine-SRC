package net.minecraft.pathfinding;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.World;

public abstract class PathNavigate {
    protected EntityLiving theEntity;
    protected World worldObj;
    protected PathEntity currentPath;
    protected double speed;
    private final IAttributeInstance pathSearchRange;
    private int totalTicks;
    private int ticksAtLastPos;
    private Vec3 lastPosCheck = new Vec3(0.0, 0.0, 0.0);
    private float heightRequirement = 1.0F;
    private final PathFinder pathFinder;

    public PathNavigate(EntityLiving var1, World var2) {
        this.theEntity = var1;
        this.worldObj = var2;
        this.pathSearchRange = var1.getEntityAttribute(SharedMonsterAttributes.followRange);
        this.pathFinder = this.getPathFinder();
    }

    protected abstract PathFinder getPathFinder();

    public void setSpeed(double var1) {
        this.speed = var1;
    }

    public float getPathSearchRange() {
        return (float)this.pathSearchRange.getAttributeValue();
    }

    public final PathEntity getPathToXYZ(double var1, double var3, double var5) {
        return this.getPathToPos(new BlockPos(MathHelper.floor_double(var1), (int)var3, MathHelper.floor_double(var5)));
    }

    public PathEntity getPathToPos(BlockPos var1) {
        if (!this.canNavigate()) {
            return null;
        }

        float f = this.getPathSearchRange();
        this.worldObj.theProfiler.startSection("pathfind");
        BlockPos blockpos = new BlockPos(this.theEntity);
        int i = (int)(f + 8.0F);
        ChunkCache chunkcache = new ChunkCache(this.worldObj, blockpos.add(-i, -i, -i), blockpos.add(i, i, i), 0);
        PathEntity pathentity = this.pathFinder.createEntityPathTo(chunkcache, this.theEntity, var1, f);
        this.worldObj.theProfiler.endSection();
        return pathentity;
    }

    public boolean tryMoveToXYZ(double var1, double var3, double var5, double var7) {
        PathEntity pathentity = this.getPathToXYZ(MathHelper.floor_double(var1), (int)var3, MathHelper.floor_double(var5));
        return this.setPath(pathentity, var7);
    }

    public void setHeightRequirement(float var1) {
        this.heightRequirement = var1;
    }

    public PathEntity getPathToEntityLiving(Entity var1) {
        if (!this.canNavigate()) {
            return null;
        }

        float f = this.getPathSearchRange();
        this.worldObj.theProfiler.startSection("pathfind");
        BlockPos blockpos = new BlockPos(this.theEntity).up();
        int i = (int)(f + 16.0F);
        ChunkCache chunkcache = new ChunkCache(this.worldObj, blockpos.add(-i, -i, -i), blockpos.add(i, i, i), 0);
        PathEntity pathentity = this.pathFinder.createEntityPathTo(chunkcache, this.theEntity, var1, f);
        this.worldObj.theProfiler.endSection();
        return pathentity;
    }

    public boolean tryMoveToEntityLiving(Entity var1, double var2) {
        PathEntity pathentity = this.getPathToEntityLiving(var1);
        return pathentity != null ? this.setPath(pathentity, var2) : false;
    }

    public boolean setPath(PathEntity var1, double var2) {
        if (var1 == null) {
            this.currentPath = null;
            return false;
        }

        if (!var1.isSamePath(this.currentPath)) {
            this.currentPath = var1;
        }

        this.removeSunnyPath();
        if (this.currentPath.getCurrentPathLength() == 0) {
            return false;
        }

        this.speed = var2;
        Vec3 vec3 = this.getEntityPosition();
        this.ticksAtLastPos = this.totalTicks;
        this.lastPosCheck = vec3;
        return true;
    }

    public PathEntity getPath() {
        return this.currentPath;
    }

    public void onUpdateNavigation() {
        this.totalTicks++;
        if (!this.noPath()) {
            if (this.canNavigate()) {
                this.pathFollow();
            } else if (this.currentPath != null && this.currentPath.getCurrentPathIndex() < this.currentPath.getCurrentPathLength()) {
                Vec3 vec3 = this.getEntityPosition();
                Vec3 vec31 = this.currentPath.getVectorFromIndex(this.theEntity, this.currentPath.getCurrentPathIndex());
                if (vec3.yCoord > vec31.yCoord
                    && !this.theEntity.onGround
                    && MathHelper.floor_double(vec3.xCoord) == MathHelper.floor_double(vec31.xCoord)
                    && MathHelper.floor_double(vec3.zCoord) == MathHelper.floor_double(vec31.zCoord)) {
                    this.currentPath.setCurrentPathIndex(this.currentPath.getCurrentPathIndex() + 1);
                }
            }

            if (!this.noPath()) {
                Vec3 vec32 = this.currentPath.getPosition(this.theEntity);
                if (vec32 != null) {
                    this.theEntity.getMoveHelper().setMoveTo(vec32.xCoord, vec32.yCoord, vec32.zCoord, this.speed);
                }
            }
        }
    }

    protected void pathFollow() {
        Vec3 vec3 = this.getEntityPosition();
        int i = this.currentPath.getCurrentPathLength();

        for (int j = this.currentPath.getCurrentPathIndex(); j < this.currentPath.getCurrentPathLength(); j++) {
            if (this.currentPath.getPathPointFromIndex(j).yCoord != (int)vec3.yCoord) {
                i = j;
                break;
            }
        }

        float f = this.theEntity.width * this.theEntity.width * this.heightRequirement;

        for (int k = this.currentPath.getCurrentPathIndex(); k < i; k++) {
            Vec3 vec31 = this.currentPath.getVectorFromIndex(this.theEntity, k);
            if (vec3.squareDistanceTo(vec31) < f) {
                this.currentPath.setCurrentPathIndex(k + 1);
            }
        }

        int j1 = MathHelper.ceiling_float_int(this.theEntity.width);
        int k1 = (int)this.theEntity.height + 1;
        int l = j1;

        for (int i1 = i - 1; i1 >= this.currentPath.getCurrentPathIndex(); i1--) {
            if (this.isDirectPathBetweenPoints(vec3, this.currentPath.getVectorFromIndex(this.theEntity, i1), j1, k1, l)) {
                this.currentPath.setCurrentPathIndex(i1);
                break;
            }
        }

        this.checkForStuck(vec3);
    }

    protected void checkForStuck(Vec3 var1) {
        if (this.totalTicks - this.ticksAtLastPos > 100) {
            if (var1.squareDistanceTo(this.lastPosCheck) < 2.25) {
                this.clearPathEntity();
            }

            this.ticksAtLastPos = this.totalTicks;
            this.lastPosCheck = var1;
        }
    }

    public boolean noPath() {
        return this.currentPath == null || this.currentPath.isFinished();
    }

    public void clearPathEntity() {
        this.currentPath = null;
    }

    protected abstract Vec3 getEntityPosition();

    protected abstract boolean canNavigate();

    protected boolean isInLiquid() {
        return this.theEntity.isInWater() || this.theEntity.isInLava();
    }

    protected void removeSunnyPath() {
    }

    protected abstract boolean isDirectPathBetweenPoints(Vec3 var1, Vec3 var2, int var3, int var4, int var5);
}
