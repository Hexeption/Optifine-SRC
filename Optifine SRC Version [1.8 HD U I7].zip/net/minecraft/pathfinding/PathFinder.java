package net.minecraft.pathfinding;

import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.pathfinder.NodeProcessor;

public class PathFinder {
    private Path path = new Path();
    private PathPoint[] pathOptions = new PathPoint[32];
    private NodeProcessor nodeProcessor;

    public PathFinder(NodeProcessor var1) {
        this.nodeProcessor = var1;
    }

    public PathEntity createEntityPathTo(IBlockAccess var1, Entity var2, Entity var3, float var4) {
        return this.createEntityPathTo(var1, var2, var3.posX, var3.getEntityBoundingBox().minY, var3.posZ, var4);
    }

    public PathEntity createEntityPathTo(IBlockAccess var1, Entity var2, BlockPos var3, float var4) {
        return this.createEntityPathTo(var1, var2, var3.getX() + 0.5F, var3.getY() + 0.5F, var3.getZ() + 0.5F, var4);
    }

    private PathEntity createEntityPathTo(IBlockAccess var1, Entity var2, double var3, double var5, double var7, float var9) {
        this.path.clearPath();
        this.nodeProcessor.initProcessor(var1, var2);
        PathPoint pathpoint = this.nodeProcessor.getPathPointTo(var2);
        PathPoint pathpoint1 = this.nodeProcessor.getPathPointToCoords(var2, var3, var5, var7);
        PathEntity pathentity = this.addToPath(var2, pathpoint, pathpoint1, var9);
        this.nodeProcessor.postProcess();
        return pathentity;
    }

    private PathEntity addToPath(Entity var1, PathPoint var2, PathPoint var3, float var4) {
        var2.totalPathDistance = 0.0F;
        var2.distanceToNext = var2.distanceToSquared(var3);
        var2.distanceToTarget = var2.distanceToNext;
        this.path.clearPath();
        this.path.addPoint(var2);
        PathPoint pathpoint = var2;

        while (!this.path.isPathEmpty()) {
            PathPoint pathpoint1 = this.path.dequeue();
            if (pathpoint1.equals(var3)) {
                return this.createEntityPath(var2, var3);
            }

            if (pathpoint1.distanceToSquared(var3) < pathpoint.distanceToSquared(var3)) {
                pathpoint = pathpoint1;
            }

            pathpoint1.visited = true;
            int i = this.nodeProcessor.findPathOptions(this.pathOptions, var1, pathpoint1, var3, var4);

            for (int j = 0; j < i; j++) {
                PathPoint pathpoint2 = this.pathOptions[j];
                float f = pathpoint1.totalPathDistance + pathpoint1.distanceToSquared(pathpoint2);
                if (f < var4 * 2.0F && (!pathpoint2.isAssigned() || f < pathpoint2.totalPathDistance)) {
                    pathpoint2.previous = pathpoint1;
                    pathpoint2.totalPathDistance = f;
                    pathpoint2.distanceToNext = pathpoint2.distanceToSquared(var3);
                    if (pathpoint2.isAssigned()) {
                        this.path.changeDistance(pathpoint2, pathpoint2.totalPathDistance + pathpoint2.distanceToNext);
                    } else {
                        pathpoint2.distanceToTarget = pathpoint2.totalPathDistance + pathpoint2.distanceToNext;
                        this.path.addPoint(pathpoint2);
                    }
                }
            }
        }

        return pathpoint == var2 ? null : this.createEntityPath(var2, pathpoint);
    }

    private PathEntity createEntityPath(PathPoint var1, PathPoint var2) {
        int i = 1;

        for (PathPoint pathpoint = var2; pathpoint.previous != null; pathpoint = pathpoint.previous) {
            i++;
        }

        PathPoint[] apathpoint = new PathPoint[i];
        PathPoint pathpoint1 = var2;

        for (apathpoint[--i] = pathpoint1; pathpoint1.previous != null; apathpoint[--i] = pathpoint1) {
            pathpoint1 = pathpoint1.previous;
        }

        return new PathEntity(apathpoint);
    }
}
