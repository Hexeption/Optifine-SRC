package net.minecraft.network;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Futures;
import io.netty.buffer.Unpooled;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.Callable;
import net.minecraft.block.material.Material;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityMinecartCommandBlock;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerBeacon;
import net.minecraft.inventory.ContainerMerchant;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemEditableBook;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemWritableBook;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C01PacketChatMessage;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0CPacketInput;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.client.C10PacketCreativeInventoryAction;
import net.minecraft.network.play.client.C11PacketEnchantItem;
import net.minecraft.network.play.client.C12PacketUpdateSign;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import net.minecraft.network.play.client.C14PacketTabComplete;
import net.minecraft.network.play.client.C15PacketClientSettings;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.network.play.client.C18PacketSpectate;
import net.minecraft.network.play.client.C19PacketResourcePackStatus;
import net.minecraft.network.play.server.S00PacketKeepAlive;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S07PacketRespawn;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.network.play.server.S32PacketConfirmTransaction;
import net.minecraft.network.play.server.S3APacketTabComplete;
import net.minecraft.network.play.server.S40PacketDisconnect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.gui.IUpdatePlayerListBox;
import net.minecraft.server.management.UserListBansEntry;
import net.minecraft.stats.AchievementList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.ReportedException;
import net.minecraft.world.WorldServer;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NetHandlerPlayServer implements INetHandlerPlayServer, IUpdatePlayerListBox {
    private static final Logger logger = LogManager.getLogger();
    public final NetworkManager netManager;
    private final MinecraftServer serverController;
    public EntityPlayerMP playerEntity;
    private int networkTickCount;
    private int field_175090_f;
    private int floatingTickCount;
    private boolean field_147366_g;
    private int field_147378_h;
    private long lastPingTime;
    private long lastSentPingPacket;
    private int chatSpamThresholdCount;
    private int itemDropThreshold;
    private IntHashMap field_147372_n = new IntHashMap();
    private double lastPosX;
    private double lastPosY;
    private double lastPosZ;
    private boolean hasMoved = true;

    public NetHandlerPlayServer(MinecraftServer var1, NetworkManager var2, EntityPlayerMP var3) {
        this.serverController = var1;
        this.netManager = var2;
        var2.setNetHandler(this);
        this.playerEntity = var3;
        var3.playerNetServerHandler = this;
    }

    @Override
    public void update() {
        this.field_147366_g = false;
        this.networkTickCount++;
        this.serverController.theProfiler.startSection("keepAlive");
        if (this.networkTickCount - this.lastSentPingPacket > 40L) {
            this.lastSentPingPacket = this.networkTickCount;
            this.lastPingTime = this.currentTimeMillis();
            this.field_147378_h = (int)this.lastPingTime;
            this.sendPacket(new S00PacketKeepAlive(this.field_147378_h));
        }

        this.serverController.theProfiler.endSection();
        if (this.chatSpamThresholdCount > 0) {
            this.chatSpamThresholdCount--;
        }

        if (this.itemDropThreshold > 0) {
            this.itemDropThreshold--;
        }

        if (this.playerEntity.getLastActiveTime() > 0L
            && this.serverController.getMaxPlayerIdleMinutes() > 0
            && MinecraftServer.getCurrentTimeMillis() - this.playerEntity.getLastActiveTime() > this.serverController.getMaxPlayerIdleMinutes() * 1000 * 60) {
            this.kickPlayerFromServer("You have been idle for too long!");
        }
    }

    public NetworkManager getNetworkManager() {
        return this.netManager;
    }

    public void kickPlayerFromServer(String var1) {
        final ChatComponentText chatcomponenttext = new ChatComponentText(var1);
        this.netManager.sendPacket(new S40PacketDisconnect(chatcomponenttext), new GenericFutureListener() {
            @Override
            public void operationComplete(Future var1) {
                NetHandlerPlayServer.this.netManager.closeChannel(chatcomponenttext);
            }
        });
        this.netManager.disableAutoRead();
        Futures.getUnchecked(this.serverController.addScheduledTask(new Runnable() {
            @Override
            public void run() {
                NetHandlerPlayServer.this.netManager.checkDisconnected();
            }
        }));
    }

    @Override
    public void processInput(C0CPacketInput var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.setEntityActionState(var1.getStrafeSpeed(), var1.getForwardSpeed(), var1.isJumping(), var1.isSneaking());
    }

    @Override
    public void processPlayer(C03PacketPlayer var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        this.field_147366_g = true;
        if (!this.playerEntity.playerConqueredTheEnd) {
            double d0 = this.playerEntity.posX;
            double d1 = this.playerEntity.posY;
            double d2 = this.playerEntity.posZ;
            double d3 = 0.0;
            double d4 = var1.getPositionX() - this.lastPosX;
            double d5 = var1.getPositionY() - this.lastPosY;
            double d6 = var1.getPositionZ() - this.lastPosZ;
            if (var1.isMoving()) {
                d3 = d4 * d4 + d5 * d5 + d6 * d6;
                if (!this.hasMoved && d3 < 0.25) {
                    this.hasMoved = true;
                }
            }

            if (this.hasMoved) {
                this.field_175090_f = this.networkTickCount;
                if (this.playerEntity.ridingEntity != null) {
                    float f4 = this.playerEntity.rotationYaw;
                    float f = this.playerEntity.rotationPitch;
                    this.playerEntity.ridingEntity.updateRiderPosition();
                    double d19 = this.playerEntity.posX;
                    double d20 = this.playerEntity.posY;
                    double d21 = this.playerEntity.posZ;
                    if (var1.getRotating()) {
                        f4 = var1.getYaw();
                        f = var1.getPitch();
                    }

                    this.playerEntity.onGround = var1.isOnGround();
                    this.playerEntity.onUpdateEntity();
                    this.playerEntity.setPositionAndRotation(d19, d20, d21, f4, f);
                    if (this.playerEntity.ridingEntity != null) {
                        this.playerEntity.ridingEntity.updateRiderPosition();
                    }

                    this.serverController.getConfigurationManager().serverUpdateMountedMovingPlayer(this.playerEntity);
                    if (this.playerEntity.ridingEntity != null) {
                        if (d3 > 4.0) {
                            Entity entity = this.playerEntity.ridingEntity;
                            this.playerEntity.playerNetServerHandler.sendPacket(new S18PacketEntityTeleport(entity));
                            this.setPlayerLocation(
                                this.playerEntity.posX,
                                this.playerEntity.posY,
                                this.playerEntity.posZ,
                                this.playerEntity.rotationYaw,
                                this.playerEntity.rotationPitch
                            );
                        }

                        this.playerEntity.ridingEntity.isAirBorne = true;
                    }

                    if (this.hasMoved) {
                        this.lastPosX = this.playerEntity.posX;
                        this.lastPosY = this.playerEntity.posY;
                        this.lastPosZ = this.playerEntity.posZ;
                    }

                    worldserver.updateEntity(this.playerEntity);
                    return;
                }

                if (this.playerEntity.isPlayerSleeping()) {
                    this.playerEntity.onUpdateEntity();
                    this.playerEntity
                        .setPositionAndRotation(this.lastPosX, this.lastPosY, this.lastPosZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
                    worldserver.updateEntity(this.playerEntity);
                    return;
                }

                double d7 = this.playerEntity.posY;
                this.lastPosX = this.playerEntity.posX;
                this.lastPosY = this.playerEntity.posY;
                this.lastPosZ = this.playerEntity.posZ;
                double d8 = this.playerEntity.posX;
                double d9 = this.playerEntity.posY;
                double d10 = this.playerEntity.posZ;
                float f1 = this.playerEntity.rotationYaw;
                float f2 = this.playerEntity.rotationPitch;
                if (var1.isMoving() && var1.getPositionY() == -999.0) {
                    var1.setMoving(false);
                }

                if (var1.isMoving()) {
                    d8 = var1.getPositionX();
                    d9 = var1.getPositionY();
                    d10 = var1.getPositionZ();
                    if (Math.abs(var1.getPositionX()) > 3.0E7 || Math.abs(var1.getPositionZ()) > 3.0E7) {
                        this.kickPlayerFromServer("Illegal position");
                        return;
                    }
                }

                if (var1.getRotating()) {
                    f1 = var1.getYaw();
                    f2 = var1.getPitch();
                }

                this.playerEntity.onUpdateEntity();
                this.playerEntity.setPositionAndRotation(this.lastPosX, this.lastPosY, this.lastPosZ, f1, f2);
                if (!this.hasMoved) {
                    return;
                }

                double d11 = d8 - this.playerEntity.posX;
                double d12 = d9 - this.playerEntity.posY;
                double d13 = d10 - this.playerEntity.posZ;
                double d14 = Math.min(Math.abs(d11), Math.abs(this.playerEntity.motionX));
                double d15 = Math.min(Math.abs(d12), Math.abs(this.playerEntity.motionY));
                double d16 = Math.min(Math.abs(d13), Math.abs(this.playerEntity.motionZ));
                double d17 = d14 * d14 + d15 * d15 + d16 * d16;
                if (d17 > 100.0
                    && (!this.serverController.isSinglePlayer() || !this.serverController.getServerOwner().equals(this.playerEntity.getCommandSenderName()))) {
                    logger.warn(
                        this.playerEntity.getCommandSenderName()
                            + " moved too quickly! "
                            + d11
                            + ","
                            + d12
                            + ","
                            + d13
                            + " ("
                            + d14
                            + ", "
                            + d15
                            + ", "
                            + d16
                            + ")"
                    );
                    this.setPlayerLocation(this.lastPosX, this.lastPosY, this.lastPosZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
                    return;
                }

                float f3 = 1.0F / 16.0F;
                boolean flag = worldserver.getCollidingBoundingBoxes(this.playerEntity, this.playerEntity.getEntityBoundingBox().contract(f3, f3, f3))
                    .isEmpty();
                if (this.playerEntity.onGround && !var1.isOnGround() && d12 > 0.0) {
                    this.playerEntity.jump();
                }

                this.playerEntity.moveEntity(d11, d12, d13);
                this.playerEntity.onGround = var1.isOnGround();
                double d18 = d12;
                d11 = d8 - this.playerEntity.posX;
                d12 = d9 - this.playerEntity.posY;
                if (d12 > -0.5 || d12 < 0.5) {
                    d12 = 0.0;
                }

                d13 = d10 - this.playerEntity.posZ;
                d17 = d11 * d11 + d12 * d12 + d13 * d13;
                boolean flag1 = false;
                if (d17 > 1.0 / 16.0 && !this.playerEntity.isPlayerSleeping() && !this.playerEntity.theItemInWorldManager.isCreative()) {
                    flag1 = true;
                    logger.warn(this.playerEntity.getCommandSenderName() + " moved wrongly!");
                }

                this.playerEntity.setPositionAndRotation(d8, d9, d10, f1, f2);
                this.playerEntity.addMovementStat(this.playerEntity.posX - d0, this.playerEntity.posY - d1, this.playerEntity.posZ - d2);
                if (!this.playerEntity.noClip) {
                    boolean flag2 = worldserver.getCollidingBoundingBoxes(this.playerEntity, this.playerEntity.getEntityBoundingBox().contract(f3, f3, f3))
                        .isEmpty();
                    if (flag && (flag1 || !flag2) && !this.playerEntity.isPlayerSleeping()) {
                        this.setPlayerLocation(this.lastPosX, this.lastPosY, this.lastPosZ, f1, f2);
                        return;
                    }
                }

                AxisAlignedBB axisalignedbb = this.playerEntity.getEntityBoundingBox().expand(f3, f3, f3).addCoord(0.0, -0.55, 0.0);
                if (this.serverController.isFlightAllowed() || this.playerEntity.capabilities.allowFlying || worldserver.checkBlockCollision(axisalignedbb)) {
                    this.floatingTickCount = 0;
                } else if (d18 >= -0.03125) {
                    this.floatingTickCount++;
                    if (this.floatingTickCount > 80) {
                        logger.warn(this.playerEntity.getCommandSenderName() + " was kicked for floating too long!");
                        this.kickPlayerFromServer("Flying is not enabled on this server");
                        return;
                    }
                }

                this.playerEntity.onGround = var1.isOnGround();
                this.serverController.getConfigurationManager().serverUpdateMountedMovingPlayer(this.playerEntity);
                this.playerEntity.handleFalling(this.playerEntity.posY - d7, var1.isOnGround());
            } else if (this.networkTickCount - this.field_175090_f > 20) {
                this.setPlayerLocation(this.lastPosX, this.lastPosY, this.lastPosZ, this.playerEntity.rotationYaw, this.playerEntity.rotationPitch);
            }
        }
    }

    public void setPlayerLocation(double var1, double var3, double var5, float var7, float var8) {
        this.setPlayerLocation(var1, var3, var5, var7, var8, Collections.emptySet());
    }

    public void setPlayerLocation(double var1, double var3, double var5, float var7, float var8, Set var9) {
        this.hasMoved = false;
        this.lastPosX = var1;
        this.lastPosY = var3;
        this.lastPosZ = var5;
        if (var9.contains(S08PacketPlayerPosLook.EnumFlags.X)) {
            this.lastPosX = this.lastPosX + this.playerEntity.posX;
        }

        if (var9.contains(S08PacketPlayerPosLook.EnumFlags.Y)) {
            this.lastPosY = this.lastPosY + this.playerEntity.posY;
        }

        if (var9.contains(S08PacketPlayerPosLook.EnumFlags.Z)) {
            this.lastPosZ = this.lastPosZ + this.playerEntity.posZ;
        }

        float f = var7;
        float f1 = var8;
        if (var9.contains(S08PacketPlayerPosLook.EnumFlags.Y_ROT)) {
            f += this.playerEntity.rotationYaw;
        }

        if (var9.contains(S08PacketPlayerPosLook.EnumFlags.X_ROT)) {
            f1 += this.playerEntity.rotationPitch;
        }

        this.playerEntity.setPositionAndRotation(this.lastPosX, this.lastPosY, this.lastPosZ, f, f1);
        this.playerEntity.playerNetServerHandler.sendPacket(new S08PacketPlayerPosLook(var1, var3, var5, var7, var8, var9));
    }

    @Override
    public void processPlayerDigging(C07PacketPlayerDigging var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        BlockPos blockpos = var1.getPosition();
        this.playerEntity.markPlayerActive();
        switch (var1.getStatus()) {
            case DROP_ITEM:
                if (!this.playerEntity.isSpectator()) {
                    this.playerEntity.dropOneItem(false);
                }

                return;
            case DROP_ALL_ITEMS:
                if (!this.playerEntity.isSpectator()) {
                    this.playerEntity.dropOneItem(true);
                }

                return;
            case RELEASE_USE_ITEM:
                this.playerEntity.stopUsingItem();
                return;
            case START_DESTROY_BLOCK:
            case ABORT_DESTROY_BLOCK:
            case STOP_DESTROY_BLOCK:
                double d0 = this.playerEntity.posX - (blockpos.getX() + 0.5);
                double d1 = this.playerEntity.posY - (blockpos.getY() + 0.5) + 1.5;
                double d2 = this.playerEntity.posZ - (blockpos.getZ() + 0.5);
                double d3 = d0 * d0 + d1 * d1 + d2 * d2;
                if (d3 > 36.0) {
                    return;
                } else if (blockpos.getY() >= this.serverController.getBuildLimit()) {
                    return;
                } else {
                    if (var1.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                        if (!this.serverController.isBlockProtected(worldserver, blockpos, this.playerEntity)
                            && worldserver.getWorldBorder().contains(blockpos)) {
                            this.playerEntity.theItemInWorldManager.onBlockClicked(blockpos, var1.getFacing());
                        } else {
                            this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(worldserver, blockpos));
                        }
                    } else {
                        if (var1.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                            this.playerEntity.theItemInWorldManager.blockRemoving(blockpos);
                        } else if (var1.getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK) {
                            this.playerEntity.theItemInWorldManager.cancelDestroyingBlock();
                        }

                        if (worldserver.getBlockState(blockpos).getBlock().getMaterial() != Material.air) {
                            this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(worldserver, blockpos));
                        }
                    }

                    return;
                }
            default:
                throw new IllegalArgumentException("Invalid player action");
        }
    }

    @Override
    public void processPlayerBlockPlacement(C08PacketPlayerBlockPlacement var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        ItemStack itemstack = this.playerEntity.inventory.getCurrentItem();
        boolean flag = false;
        BlockPos blockpos = var1.getPosition();
        EnumFacing enumfacing = EnumFacing.getFront(var1.getPlacedBlockDirection());
        this.playerEntity.markPlayerActive();
        if (var1.getPlacedBlockDirection() == 255) {
            if (itemstack == null) {
                return;
            }

            this.playerEntity.theItemInWorldManager.tryUseItem(this.playerEntity, worldserver, itemstack);
        } else if (blockpos.getY() < this.serverController.getBuildLimit() - 1
            || enumfacing != EnumFacing.UP && blockpos.getY() < this.serverController.getBuildLimit()) {
            if (this.hasMoved
                && this.playerEntity.getDistanceSq(blockpos.getX() + 0.5, blockpos.getY() + 0.5, blockpos.getZ() + 0.5) < 64.0
                && !this.serverController.isBlockProtected(worldserver, blockpos, this.playerEntity)
                && worldserver.getWorldBorder().contains(blockpos)) {
                this.playerEntity
                    .theItemInWorldManager
                    .activateBlockOrUseItem(
                        this.playerEntity,
                        worldserver,
                        itemstack,
                        blockpos,
                        enumfacing,
                        var1.getPlacedBlockOffsetX(),
                        var1.getPlacedBlockOffsetY(),
                        var1.getPlacedBlockOffsetZ()
                    );
            }

            flag = true;
        } else {
            ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation("build.tooHigh", this.serverController.getBuildLimit());
            chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.RED);
            this.playerEntity.playerNetServerHandler.sendPacket(new S02PacketChat(chatcomponenttranslation));
            flag = true;
        }

        if (flag) {
            this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(worldserver, blockpos));
            this.playerEntity.playerNetServerHandler.sendPacket(new S23PacketBlockChange(worldserver, blockpos.offset(enumfacing)));
        }

        itemstack = this.playerEntity.inventory.getCurrentItem();
        if (itemstack != null && itemstack.stackSize == 0) {
            this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem] = null;
            itemstack = null;
        }

        if (itemstack == null || itemstack.getMaxItemUseDuration() == 0) {
            this.playerEntity.isChangingQuantityOnly = true;
            this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem] = ItemStack.copyItemStack(
                this.playerEntity.inventory.mainInventory[this.playerEntity.inventory.currentItem]
            );
            Slot slot = this.playerEntity.openContainer.getSlotFromInventory(this.playerEntity.inventory, this.playerEntity.inventory.currentItem);
            this.playerEntity.openContainer.detectAndSendChanges();
            this.playerEntity.isChangingQuantityOnly = false;
            if (!ItemStack.areItemStacksEqual(this.playerEntity.inventory.getCurrentItem(), var1.getStack())) {
                this.sendPacket(new S2FPacketSetSlot(this.playerEntity.openContainer.windowId, slot.slotNumber, this.playerEntity.inventory.getCurrentItem()));
            }
        }
    }

    @Override
    public void handleSpectate(C18PacketSpectate var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        if (this.playerEntity.isSpectator()) {
            Entity entity = null;

            for (WorldServer worldserver : this.serverController.worldServers) {
                if (worldserver != null) {
                    entity = var1.getEntity(worldserver);
                    if (entity != null) {
                        break;
                    }
                }
            }

            if (entity != null) {
                this.playerEntity.setSpectatingEntity(this.playerEntity);
                this.playerEntity.mountEntity(null);
                if (entity.worldObj != this.playerEntity.worldObj) {
                    WorldServer worldserver1 = this.playerEntity.getServerForPlayer();
                    WorldServer worldserver2 = (WorldServer)entity.worldObj;
                    this.playerEntity.dimension = entity.dimension;
                    this.sendPacket(
                        new S07PacketRespawn(
                            this.playerEntity.dimension,
                            worldserver1.getDifficulty(),
                            worldserver1.getWorldInfo().getTerrainType(),
                            this.playerEntity.theItemInWorldManager.getGameType()
                        )
                    );
                    worldserver1.removePlayerEntityDangerously(this.playerEntity);
                    this.playerEntity.isDead = false;
                    this.playerEntity.setLocationAndAngles(entity.posX, entity.posY, entity.posZ, entity.rotationYaw, entity.rotationPitch);
                    if (this.playerEntity.isEntityAlive()) {
                        worldserver1.updateEntityWithOptionalForce(this.playerEntity, false);
                        worldserver2.spawnEntityInWorld(this.playerEntity);
                        worldserver2.updateEntityWithOptionalForce(this.playerEntity, false);
                    }

                    this.playerEntity.setWorld(worldserver2);
                    this.serverController.getConfigurationManager().preparePlayer(this.playerEntity, worldserver1);
                    this.playerEntity.setPositionAndUpdate(entity.posX, entity.posY, entity.posZ);
                    this.playerEntity.theItemInWorldManager.setWorld(worldserver2);
                    this.serverController.getConfigurationManager().updateTimeAndWeatherForPlayer(this.playerEntity, worldserver2);
                    this.serverController.getConfigurationManager().syncPlayerInventory(this.playerEntity);
                } else {
                    this.playerEntity.setPositionAndUpdate(entity.posX, entity.posY, entity.posZ);
                }
            }
        }
    }

    @Override
    public void handleResourcePackStatus(C19PacketResourcePackStatus var1) {
    }

    @Override
    public void onDisconnect(IChatComponent var1) {
        logger.info(this.playerEntity.getCommandSenderName() + " lost connection: " + var1);
        this.serverController.refreshStatusNextTick();
        ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation("multiplayer.player.left", this.playerEntity.getDisplayName());
        chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.YELLOW);
        this.serverController.getConfigurationManager().sendChatMsg(chatcomponenttranslation);
        this.playerEntity.mountEntityAndWakeUp();
        this.serverController.getConfigurationManager().playerLoggedOut(this.playerEntity);
        if (this.serverController.isSinglePlayer() && this.playerEntity.getCommandSenderName().equals(this.serverController.getServerOwner())) {
            logger.info("Stopping singleplayer server as player logged out");
            this.serverController.initiateShutdown();
        }
    }

    public void sendPacket(final Packet var1) {
        if (var1 instanceof S02PacketChat) {
            S02PacketChat s02packetchat = (S02PacketChat)var1;
            EntityPlayer.EnumChatVisibility entityplayer$enumchatvisibility = this.playerEntity.getChatVisibility();
            if (entityplayer$enumchatvisibility == EntityPlayer.EnumChatVisibility.HIDDEN) {
                return;
            }

            if (entityplayer$enumchatvisibility == EntityPlayer.EnumChatVisibility.SYSTEM && !s02packetchat.isChat()) {
                return;
            }
        }

        try {
            this.netManager.sendPacket(var1);
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Sending packet");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Packet being sent");
            crashreportcategory.addCrashSectionCallable("Packet class", new Callable() {
                public String call() {
                    return var1.getClass().getCanonicalName();
                }
            });
            throw new ReportedException(crashreport);
        }
    }

    @Override
    public void processHeldItemChange(C09PacketHeldItemChange var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        if (var1.getSlotId() >= 0 && var1.getSlotId() < InventoryPlayer.getHotbarSize()) {
            this.playerEntity.inventory.currentItem = var1.getSlotId();
            this.playerEntity.markPlayerActive();
        } else {
            logger.warn(this.playerEntity.getCommandSenderName() + " tried to set an invalid carried item");
        }
    }

    @Override
    public void processChatMessage(C01PacketChatMessage var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        if (this.playerEntity.getChatVisibility() == EntityPlayer.EnumChatVisibility.HIDDEN) {
            ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation("chat.cannotSend");
            chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.RED);
            this.sendPacket(new S02PacketChat(chatcomponenttranslation));
        } else {
            this.playerEntity.markPlayerActive();
            String s = var1.getMessage();
            s = StringUtils.normalizeSpace(s);

            for (int i = 0; i < s.length(); i++) {
                if (!ChatAllowedCharacters.isAllowedCharacter(s.charAt(i))) {
                    this.kickPlayerFromServer("Illegal characters in chat");
                    return;
                }
            }

            if (s.startsWith("/")) {
                this.handleSlashCommand(s);
            } else {
                ChatComponentTranslation chatcomponenttranslation1 = new ChatComponentTranslation("chat.type.text", this.playerEntity.getDisplayName(), s);
                this.serverController.getConfigurationManager().sendChatMsgImpl(chatcomponenttranslation1, false);
            }

            this.chatSpamThresholdCount += 20;
            if (this.chatSpamThresholdCount > 200 && !this.serverController.getConfigurationManager().canSendCommands(this.playerEntity.getGameProfile())) {
                this.kickPlayerFromServer("disconnect.spam");
            }
        }
    }

    private void handleSlashCommand(String var1) {
        this.serverController.getCommandManager().executeCommand(this.playerEntity, var1);
    }

    @Override
    public void handleAnimation(C0APacketAnimation var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.markPlayerActive();
        this.playerEntity.swingItem();
    }

    @Override
    public void processEntityAction(C0BPacketEntityAction var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.markPlayerActive();
        switch (var1.getAction()) {
            case START_SNEAKING:
                this.playerEntity.setSneaking(true);
                break;
            case STOP_SNEAKING:
                this.playerEntity.setSneaking(false);
                break;
            case START_SPRINTING:
                this.playerEntity.setSprinting(true);
                break;
            case STOP_SPRINTING:
                this.playerEntity.setSprinting(false);
                break;
            case STOP_SLEEPING:
                this.playerEntity.wakeUpPlayer(false, true, true);
                this.hasMoved = false;
                break;
            case RIDING_JUMP:
                if (this.playerEntity.ridingEntity instanceof EntityHorse) {
                    ((EntityHorse)this.playerEntity.ridingEntity).setJumpPower(var1.getAuxData());
                }
                break;
            case OPEN_INVENTORY:
                if (this.playerEntity.ridingEntity instanceof EntityHorse) {
                    ((EntityHorse)this.playerEntity.ridingEntity).openGUI(this.playerEntity);
                }
                break;
            default:
                throw new IllegalArgumentException("Invalid client command!");
        }
    }

    @Override
    public void processUseEntity(C02PacketUseEntity var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        Entity entity = var1.getEntityFromWorld(worldserver);
        this.playerEntity.markPlayerActive();
        if (entity != null) {
            boolean flag = this.playerEntity.canEntityBeSeen(entity);
            double d0 = 36.0;
            if (!flag) {
                d0 = 9.0;
            }

            if (this.playerEntity.getDistanceSqToEntity(entity) < d0) {
                if (var1.getAction() == C02PacketUseEntity.Action.INTERACT) {
                    this.playerEntity.interactWith(entity);
                } else if (var1.getAction() == C02PacketUseEntity.Action.INTERACT_AT) {
                    entity.interactAt(this.playerEntity, var1.getHitVec());
                } else if (var1.getAction() == C02PacketUseEntity.Action.ATTACK) {
                    if (entity instanceof EntityItem || entity instanceof EntityXPOrb || entity instanceof EntityArrow || entity == this.playerEntity) {
                        this.kickPlayerFromServer("Attempting to attack an invalid entity");
                        this.serverController.logWarning("Player " + this.playerEntity.getCommandSenderName() + " tried to attack an invalid entity");
                        return;
                    }

                    this.playerEntity.attackTargetEntityWithCurrentItem(entity);
                }
            }
        }
    }

    @Override
    public void processClientStatus(C16PacketClientStatus var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.markPlayerActive();
        C16PacketClientStatus.EnumState c16packetclientstatus$enumstate = var1.getStatus();
        switch (c16packetclientstatus$enumstate) {
            case PERFORM_RESPAWN:
                if (this.playerEntity.playerConqueredTheEnd) {
                    this.playerEntity = this.serverController.getConfigurationManager().recreatePlayerEntity(this.playerEntity, 0, true);
                } else if (this.playerEntity.getServerForPlayer().getWorldInfo().isHardcoreModeEnabled()) {
                    if (this.serverController.isSinglePlayer() && this.playerEntity.getCommandSenderName().equals(this.serverController.getServerOwner())) {
                        this.playerEntity.playerNetServerHandler.kickPlayerFromServer("You have died. Game over, man, it's game over!");
                        this.serverController.deleteWorldAndStopServer();
                    } else {
                        UserListBansEntry userlistbansentry = new UserListBansEntry(
                            this.playerEntity.getGameProfile(), null, "(You just lost the game)", null, "Death in Hardcore"
                        );
                        this.serverController.getConfigurationManager().getBannedPlayers().addEntry(userlistbansentry);
                        this.playerEntity.playerNetServerHandler.kickPlayerFromServer("You have died. Game over, man, it's game over!");
                    }
                } else {
                    if (this.playerEntity.getHealth() > 0.0F) {
                        return;
                    }

                    this.playerEntity = this.serverController.getConfigurationManager().recreatePlayerEntity(this.playerEntity, 0, false);
                }
                break;
            case REQUEST_STATS:
                this.playerEntity.getStatFile().func_150876_a(this.playerEntity);
                break;
            case OPEN_INVENTORY_ACHIEVEMENT:
                this.playerEntity.triggerAchievement(AchievementList.openInventory);
        }
    }

    @Override
    public void processCloseWindow(C0DPacketCloseWindow var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.closeContainer();
    }

    @Override
    public void processClickWindow(C0EPacketClickWindow var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.markPlayerActive();
        if (this.playerEntity.openContainer.windowId == var1.getWindowId() && this.playerEntity.openContainer.getCanCraft(this.playerEntity)) {
            if (this.playerEntity.isSpectator()) {
                ArrayList arraylist = Lists.newArrayList();

                for (int i = 0; i < this.playerEntity.openContainer.inventorySlots.size(); i++) {
                    arraylist.add(((Slot)this.playerEntity.openContainer.inventorySlots.get(i)).getStack());
                }

                this.playerEntity.updateCraftingInventory(this.playerEntity.openContainer, arraylist);
            } else {
                ItemStack itemstack = this.playerEntity.openContainer.slotClick(var1.getSlotId(), var1.getUsedButton(), var1.getMode(), this.playerEntity);
                if (ItemStack.areItemStacksEqual(var1.getClickedItem(), itemstack)) {
                    this.playerEntity.playerNetServerHandler.sendPacket(new S32PacketConfirmTransaction(var1.getWindowId(), var1.getActionNumber(), true));
                    this.playerEntity.isChangingQuantityOnly = true;
                    this.playerEntity.openContainer.detectAndSendChanges();
                    this.playerEntity.updateHeldItem();
                    this.playerEntity.isChangingQuantityOnly = false;
                } else {
                    this.field_147372_n.addKey(this.playerEntity.openContainer.windowId, var1.getActionNumber());
                    this.playerEntity.playerNetServerHandler.sendPacket(new S32PacketConfirmTransaction(var1.getWindowId(), var1.getActionNumber(), false));
                    this.playerEntity.openContainer.setCanCraft(this.playerEntity, false);
                    ArrayList arraylist1 = Lists.newArrayList();

                    for (int j = 0; j < this.playerEntity.openContainer.inventorySlots.size(); j++) {
                        arraylist1.add(((Slot)this.playerEntity.openContainer.inventorySlots.get(j)).getStack());
                    }

                    this.playerEntity.updateCraftingInventory(this.playerEntity.openContainer, arraylist1);
                }
            }
        }
    }

    @Override
    public void processEnchantItem(C11PacketEnchantItem var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.markPlayerActive();
        if (this.playerEntity.openContainer.windowId == var1.getWindowId()
            && this.playerEntity.openContainer.getCanCraft(this.playerEntity)
            && !this.playerEntity.isSpectator()) {
            this.playerEntity.openContainer.enchantItem(this.playerEntity, var1.getButton());
            this.playerEntity.openContainer.detectAndSendChanges();
        }
    }

    @Override
    public void processCreativeInventoryAction(C10PacketCreativeInventoryAction var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        if (this.playerEntity.theItemInWorldManager.isCreative()) {
            boolean flag = var1.getSlotId() < 0;
            ItemStack itemstack = var1.getStack();
            if (itemstack != null && itemstack.hasTagCompound() && itemstack.getTagCompound().hasKey("BlockEntityTag", 10)) {
                NBTTagCompound nbttagcompound = itemstack.getTagCompound().getCompoundTag("BlockEntityTag");
                if (nbttagcompound.hasKey("x") && nbttagcompound.hasKey("y") && nbttagcompound.hasKey("z")) {
                    BlockPos blockpos = new BlockPos(nbttagcompound.getInteger("x"), nbttagcompound.getInteger("y"), nbttagcompound.getInteger("z"));
                    TileEntity tileentity = this.playerEntity.worldObj.getTileEntity(blockpos);
                    if (tileentity != null) {
                        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                        tileentity.writeToNBT(nbttagcompound1);
                        nbttagcompound1.removeTag("x");
                        nbttagcompound1.removeTag("y");
                        nbttagcompound1.removeTag("z");
                        itemstack.setTagInfo("BlockEntityTag", nbttagcompound1);
                    }
                }
            }

            boolean flag1 = var1.getSlotId() >= 1 && var1.getSlotId() < 36 + InventoryPlayer.getHotbarSize();
            boolean flag2 = itemstack == null || itemstack.getItem() != null;
            boolean flag3 = itemstack == null || itemstack.getMetadata() >= 0 && itemstack.stackSize <= 64 && itemstack.stackSize > 0;
            if (flag1 && flag2 && flag3) {
                if (itemstack == null) {
                    this.playerEntity.inventoryContainer.putStackInSlot(var1.getSlotId(), null);
                } else {
                    this.playerEntity.inventoryContainer.putStackInSlot(var1.getSlotId(), itemstack);
                }

                this.playerEntity.inventoryContainer.setCanCraft(this.playerEntity, true);
            } else if (flag && flag2 && flag3 && this.itemDropThreshold < 200) {
                this.itemDropThreshold += 20;
                EntityItem entityitem = this.playerEntity.dropPlayerItemWithRandomChoice(itemstack, true);
                if (entityitem != null) {
                    entityitem.setAgeToCreativeDespawnTime();
                }
            }
        }
    }

    @Override
    public void processConfirmTransaction(C0FPacketConfirmTransaction var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        Short oshort = (Short)this.field_147372_n.lookup(this.playerEntity.openContainer.windowId);
        if (oshort != null
            && var1.getUid() == oshort
            && this.playerEntity.openContainer.windowId == var1.getWindowId()
            && !this.playerEntity.openContainer.getCanCraft(this.playerEntity)
            && !this.playerEntity.isSpectator()) {
            this.playerEntity.openContainer.setCanCraft(this.playerEntity, true);
        }
    }

    @Override
    public void processUpdateSign(C12PacketUpdateSign var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.markPlayerActive();
        WorldServer worldserver = this.serverController.worldServerForDimension(this.playerEntity.dimension);
        BlockPos blockpos = var1.getPosition();
        if (worldserver.isBlockLoaded(blockpos)) {
            TileEntity tileentity = worldserver.getTileEntity(blockpos);
            if (!(tileentity instanceof TileEntitySign)) {
                return;
            }

            TileEntitySign tileentitysign = (TileEntitySign)tileentity;
            if (!tileentitysign.getIsEditable() || tileentitysign.getPlayer() != this.playerEntity) {
                this.serverController.logWarning("Player " + this.playerEntity.getCommandSenderName() + " just tried to change non-editable sign");
                return;
            }

            System.arraycopy(var1.getLines(), 0, tileentitysign.signText, 0, 4);
            tileentitysign.markDirty();
            worldserver.markBlockForUpdate(blockpos);
        }
    }

    @Override
    public void processKeepAlive(C00PacketKeepAlive var1) {
        if (var1.getKey() == this.field_147378_h) {
            int i = (int)(this.currentTimeMillis() - this.lastPingTime);
            this.playerEntity.ping = (this.playerEntity.ping * 3 + i) / 4;
        }
    }

    private long currentTimeMillis() {
        return System.nanoTime() / 1000000L;
    }

    @Override
    public void processPlayerAbilities(C13PacketPlayerAbilities var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.capabilities.isFlying = var1.isFlying() && this.playerEntity.capabilities.allowFlying;
    }

    @Override
    public void processTabComplete(C14PacketTabComplete var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        ArrayList arraylist = Lists.newArrayList();

        for (String s : (Iterable<String>) (Iterable) this.serverController.getTabCompletions(this.playerEntity, var1.getMessage(), var1.getTargetBlock())) {
            arraylist.add(s);
        }

        this.playerEntity.playerNetServerHandler.sendPacket(new S3APacketTabComplete(((String[]) arraylist.toArray(new String[arraylist.size()]))));
    }

    @Override
    public void processClientSettings(C15PacketClientSettings var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        this.playerEntity.handleClientSettings(var1);
    }

    @Override
    public void processVanilla250Packet(C17PacketCustomPayload var1) {
        PacketThreadUtil.checkThreadAndEnqueue(var1, this, this.playerEntity.getServerForPlayer());
        if ("MC|BEdit".equals(var1.getChannelName())) {
            PacketBuffer packetbuffer3 = new PacketBuffer(Unpooled.wrappedBuffer(var1.getBufferData()));

            try {
                ItemStack itemstack1 = packetbuffer3.readItemStackFromBuffer();
                if (itemstack1 == null) {
                    return;
                }

                if (!ItemWritableBook.isNBTValid(itemstack1.getTagCompound())) {
                    throw new IOException("Invalid book tag!");
                }

                ItemStack itemstack3 = this.playerEntity.inventory.getCurrentItem();
                if (itemstack3 != null) {
                    if (itemstack1.getItem() == Items.writable_book && itemstack1.getItem() == itemstack3.getItem()) {
                        itemstack3.setTagInfo("pages", itemstack1.getTagCompound().getTagList("pages", 8));
                    }

                    return;
                }
            } catch (Exception exception3) {
                logger.error("Couldn't handle book info", exception3);
                return;
            } finally {
                packetbuffer3.release();
            }

            return;
        } else if ("MC|BSign".equals(var1.getChannelName())) {
            PacketBuffer packetbuffer2 = new PacketBuffer(Unpooled.wrappedBuffer(var1.getBufferData()));

            try {
                ItemStack itemstack = packetbuffer2.readItemStackFromBuffer();
                if (itemstack == null) {
                    return;
                }

                if (!ItemEditableBook.validBookTagContents(itemstack.getTagCompound())) {
                    throw new IOException("Invalid book tag!");
                }

                ItemStack itemstack2 = this.playerEntity.inventory.getCurrentItem();
                if (itemstack2 != null) {
                    if (itemstack.getItem() == Items.written_book && itemstack2.getItem() == Items.writable_book) {
                        itemstack2.setTagInfo("author", new NBTTagString(this.playerEntity.getCommandSenderName()));
                        itemstack2.setTagInfo("title", new NBTTagString(itemstack.getTagCompound().getString("title")));
                        itemstack2.setTagInfo("pages", itemstack.getTagCompound().getTagList("pages", 8));
                        itemstack2.setItem(Items.written_book);
                    }

                    return;
                }
            } catch (Exception exception4) {
                logger.error("Couldn't sign book", exception4);
                return;
            } finally {
                packetbuffer2.release();
            }

            return;
        } else if ("MC|TrSel".equals(var1.getChannelName())) {
            try {
                int i = var1.getBufferData().readInt();
                Container container = this.playerEntity.openContainer;
                if (container instanceof ContainerMerchant) {
                    ((ContainerMerchant)container).setCurrentRecipeIndex(i);
                }
            } catch (Exception exception2) {
                logger.error("Couldn't select trade", exception2);
            }
        } else if ("MC|AdvCdm".equals(var1.getChannelName())) {
            if (!this.serverController.isCommandBlockEnabled()) {
                this.playerEntity.addChatMessage(new ChatComponentTranslation("advMode.notEnabled"));
            } else if (this.playerEntity.canCommandSenderUseCommand(2, "") && this.playerEntity.capabilities.isCreativeMode) {
                PacketBuffer packetbuffer = var1.getBufferData();

                try {
                    byte b0 = packetbuffer.readByte();
                    CommandBlockLogic commandblocklogic = null;
                    if (b0 == 0) {
                        TileEntity tileentity = this.playerEntity
                            .worldObj
                            .getTileEntity(new BlockPos(packetbuffer.readInt(), packetbuffer.readInt(), packetbuffer.readInt()));
                        if (tileentity instanceof TileEntityCommandBlock) {
                            commandblocklogic = ((TileEntityCommandBlock)tileentity).getCommandBlockLogic();
                        }
                    } else if (b0 == 1) {
                        Entity entity = this.playerEntity.worldObj.getEntityByID(packetbuffer.readInt());
                        if (entity instanceof EntityMinecartCommandBlock) {
                            commandblocklogic = ((EntityMinecartCommandBlock)entity).getCommandBlockLogic();
                        }
                    }

                    String s1 = packetbuffer.readStringFromBuffer(packetbuffer.readableBytes());
                    boolean flag = packetbuffer.readBoolean();
                    if (commandblocklogic != null) {
                        commandblocklogic.setCommand(s1);
                        commandblocklogic.setTrackOutput(flag);
                        if (!flag) {
                            commandblocklogic.setLastOutput(null);
                        }

                        commandblocklogic.updateCommand();
                        this.playerEntity.addChatMessage(new ChatComponentTranslation("advMode.setCommand.success", s1));
                    }
                } catch (Exception exception1) {
                    logger.error("Couldn't set command block", exception1);
                } finally {
                    packetbuffer.release();
                }
            } else {
                this.playerEntity.addChatMessage(new ChatComponentTranslation("advMode.notAllowed"));
            }
        } else if ("MC|Beacon".equals(var1.getChannelName())) {
            if (this.playerEntity.openContainer instanceof ContainerBeacon) {
                try {
                    PacketBuffer packetbuffer1 = var1.getBufferData();
                    int j = packetbuffer1.readInt();
                    int k = packetbuffer1.readInt();
                    ContainerBeacon containerbeacon = (ContainerBeacon)this.playerEntity.openContainer;
                    Slot slot = containerbeacon.getSlot(0);
                    if (slot.getHasStack()) {
                        slot.decrStackSize(1);
                        IInventory iinventory = containerbeacon.func_180611_e();
                        iinventory.setField(1, j);
                        iinventory.setField(2, k);
                        iinventory.markDirty();
                    }
                } catch (Exception exception) {
                    logger.error("Couldn't set beacon", exception);
                }
            }
        } else if ("MC|ItemName".equals(var1.getChannelName()) && this.playerEntity.openContainer instanceof ContainerRepair) {
            ContainerRepair containerrepair = (ContainerRepair)this.playerEntity.openContainer;
            if (var1.getBufferData() != null && var1.getBufferData().readableBytes() >= 1) {
                String s = ChatAllowedCharacters.filterAllowedCharacters(var1.getBufferData().readStringFromBuffer(Short.MAX_VALUE));
                if (s.length() <= 30) {
                    containerrepair.updateItemName(s);
                }
            } else {
                containerrepair.updateItemName("");
            }
        }
    }
}
