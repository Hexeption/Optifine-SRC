package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import java.util.zip.Deflater;

public class NettyCompressionEncoder extends MessageToByteEncoder {
    private final byte[] buffer = new byte[8192];
    private final Deflater deflater;
    private int treshold;

    public NettyCompressionEncoder(int var1) {
        this.treshold = var1;
        this.deflater = new Deflater();
    }

    protected void compress(ChannelHandlerContext var1, ByteBuf var2, ByteBuf var3) {
        int i = var2.readableBytes();
        PacketBuffer packetbuffer = new PacketBuffer(var3);
        if (i < this.treshold) {
            packetbuffer.writeVarIntToBuffer(0);
            packetbuffer.writeBytes(var2);
        } else {
            byte[] abyte = new byte[i];
            var2.readBytes(abyte);
            packetbuffer.writeVarIntToBuffer(abyte.length);
            this.deflater.setInput(abyte, 0, i);
            this.deflater.finish();

            while (!this.deflater.finished()) {
                int j = this.deflater.deflate(this.buffer);
                packetbuffer.writeBytes(this.buffer, 0, j);
            }

            this.deflater.reset();
        }
    }

    public void setCompressionTreshold(int var1) {
        this.treshold = var1;
    }

    @Override
    protected void encode(ChannelHandlerContext var1, Object var2, ByteBuf var3) {
        this.compress(var1, (ByteBuf)var2, var3);
    }
}
