package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.DecoderException;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class NettyCompressionDecoder extends ByteToMessageDecoder {
    private final Inflater inflater;
    private int treshold;

    public NettyCompressionDecoder(int var1) {
        this.treshold = var1;
        this.inflater = new Inflater();
    }

    @Override
    protected void decode(ChannelHandlerContext var1, ByteBuf var2, List var3) throws DataFormatException {
        if (var2.readableBytes() != 0) {
            PacketBuffer packetbuffer = new PacketBuffer(var2);
            int i = packetbuffer.readVarIntFromBuffer();
            if (i == 0) {
                var3.add(packetbuffer.readBytes(packetbuffer.readableBytes()));
            } else {
                if (i < this.treshold) {
                    throw new DecoderException("Badly compressed packet - size of " + i + " is below server threshold of " + this.treshold);
                }

                if (i > 2097152) {
                    throw new DecoderException("Badly compressed packet - size of " + i + " is larger than protocol maximum of " + 2097152);
                }

                byte[] abyte = new byte[packetbuffer.readableBytes()];
                packetbuffer.readBytes(abyte);
                this.inflater.setInput(abyte);
                byte[] abyte1 = new byte[i];
                this.inflater.inflate(abyte1);
                var3.add(Unpooled.wrappedBuffer(abyte1));
                this.inflater.reset();
            }
        }
    }

    public void setCompressionTreshold(int var1) {
        this.treshold = var1;
    }
}
