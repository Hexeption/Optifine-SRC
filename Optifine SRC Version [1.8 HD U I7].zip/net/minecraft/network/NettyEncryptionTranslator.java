package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import javax.crypto.Cipher;
import javax.crypto.ShortBufferException;

public class NettyEncryptionTranslator {
    private final Cipher cipher;
    private byte[] field_150505_b = new byte[0];
    private byte[] field_150506_c = new byte[0];

    protected NettyEncryptionTranslator(Cipher var1) {
        this.cipher = var1;
    }

    private byte[] func_150502_a(ByteBuf var1) {
        int i = var1.readableBytes();
        if (this.field_150505_b.length < i) {
            this.field_150505_b = new byte[i];
        }

        var1.readBytes(this.field_150505_b, 0, i);
        return this.field_150505_b;
    }

    protected ByteBuf decipher(ChannelHandlerContext var1, ByteBuf var2) throws ShortBufferException {
        int i = var2.readableBytes();
        byte[] abyte = this.func_150502_a(var2);
        ByteBuf bytebuf = var1.alloc().heapBuffer(this.cipher.getOutputSize(i));
        bytebuf.writerIndex(this.cipher.update(abyte, 0, i, bytebuf.array(), bytebuf.arrayOffset()));
        return bytebuf;
    }

    protected void cipher(ByteBuf var1, ByteBuf var2) throws ShortBufferException {
        int i = var1.readableBytes();
        byte[] abyte = this.func_150502_a(var1);
        int j = this.cipher.getOutputSize(i);
        if (this.field_150506_c.length < j) {
            this.field_150506_c = new byte[j];
        }

        var2.writeBytes(this.field_150506_c, 0, this.cipher.update(abyte, 0, i, this.field_150506_c));
    }
}
