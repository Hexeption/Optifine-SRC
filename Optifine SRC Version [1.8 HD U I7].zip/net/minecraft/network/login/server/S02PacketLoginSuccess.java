package net.minecraft.network.login.server;

import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.util.UUID;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.login.INetHandlerLoginClient;

public class S02PacketLoginSuccess implements Packet {
    private GameProfile profile;

    public S02PacketLoginSuccess() {
    }

    public S02PacketLoginSuccess(GameProfile var1) {
        this.profile = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        String s = var1.readStringFromBuffer(36);
        String s1 = var1.readStringFromBuffer(16);
        UUID uuid = UUID.fromString(s);
        this.profile = new GameProfile(uuid, s1);
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        UUID uuid = this.profile.getId();
        var1.writeString(uuid == null ? "" : uuid.toString());
        var1.writeString(this.profile.getName());
    }

    public void processPacket(INetHandlerLoginClient var1) {
        var1.handleLoginSuccess(this);
    }

    public GameProfile getProfile() {
        return this.profile;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerLoginClient)var1);
    }
}
