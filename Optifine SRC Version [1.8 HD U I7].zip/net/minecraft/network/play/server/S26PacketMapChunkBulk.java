package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.chunk.Chunk;

public class S26PacketMapChunkBulk implements Packet {
    private int[] xPositions;
    private int[] zPositions;
    private S21PacketChunkData.Extracted[] chunksData;
    private boolean isOverworld;

    public S26PacketMapChunkBulk() {
    }

    public S26PacketMapChunkBulk(List var1) {
        int i = var1.size();
        this.xPositions = new int[i];
        this.zPositions = new int[i];
        this.chunksData = new S21PacketChunkData.Extracted[i];
        this.isOverworld = !((Chunk)var1.get(0)).getWorld().provider.getHasNoSky();

        for (int j = 0; j < i; j++) {
            Chunk chunk = (Chunk)var1.get(j);
            S21PacketChunkData.Extracted s21packetchunkdata$extracted = S21PacketChunkData.func_179756_a(chunk, true, this.isOverworld, 65535);
            this.xPositions[j] = chunk.xPosition;
            this.zPositions[j] = chunk.zPosition;
            this.chunksData[j] = s21packetchunkdata$extracted;
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.isOverworld = var1.readBoolean();
        int i = var1.readVarIntFromBuffer();
        this.xPositions = new int[i];
        this.zPositions = new int[i];
        this.chunksData = new S21PacketChunkData.Extracted[i];

        for (int j = 0; j < i; j++) {
            this.xPositions[j] = var1.readInt();
            this.zPositions[j] = var1.readInt();
            this.chunksData[j] = new S21PacketChunkData.Extracted();
            this.chunksData[j].dataSize = var1.readShort() & '\uffff';
            this.chunksData[j].data = new byte[S21PacketChunkData.func_180737_a(Integer.bitCount(this.chunksData[j].dataSize), this.isOverworld, true)];
        }

        for (int k = 0; k < i; k++) {
            var1.readBytes(this.chunksData[k].data);
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeBoolean(this.isOverworld);
        var1.writeVarIntToBuffer(this.chunksData.length);

        for (int i = 0; i < this.xPositions.length; i++) {
            var1.writeInt(this.xPositions[i]);
            var1.writeInt(this.zPositions[i]);
            var1.writeShort((short)(this.chunksData[i].dataSize & 65535));
        }

        for (int j = 0; j < this.xPositions.length; j++) {
            var1.writeBytes(this.chunksData[j].data);
        }
    }

    public void handleMapChunkBulk(INetHandlerPlayClient var1) {
        var1.handleMapChunkBulk(this);
    }

    public int getChunkX(int var1) {
        return this.xPositions[var1];
    }

    public int getChunkZ(int var1) {
        return this.zPositions[var1];
    }

    public int getChunkCount() {
        return this.xPositions.length;
    }

    public byte[] getChunkBytes(int var1) {
        return this.chunksData[var1].data;
    }

    public int getChunkSize(int var1) {
        return this.chunksData[var1].dataSize;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.handleMapChunkBulk((INetHandlerPlayClient)var1);
    }
}
