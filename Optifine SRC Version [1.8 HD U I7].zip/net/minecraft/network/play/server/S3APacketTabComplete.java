package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S3APacketTabComplete implements Packet {
    private String[] matches;

    public S3APacketTabComplete() {
    }

    public S3APacketTabComplete(String[] var1) {
        this.matches = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.matches = new String[var1.readVarIntFromBuffer()];

        for (int i = 0; i < this.matches.length; i++) {
            this.matches[i] = var1.readStringFromBuffer(Short.MAX_VALUE);
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeVarIntToBuffer(this.matches.length);

        for (String s : this.matches) {
            var1.writeString(s);
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleTabComplete(this);
    }

    public String[] func_149630_c() {
        return this.matches;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
