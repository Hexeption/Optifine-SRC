package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.List;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;

public class S27PacketExplosion implements Packet {
    private double posX;
    private double posY;
    private double posZ;
    private float strength;
    private List affectedBlockPositions;
    private float field_149152_f;
    private float field_149153_g;
    private float field_149159_h;

    public S27PacketExplosion() {
    }

    public S27PacketExplosion(double var1, double var3, double var5, float var7, List var8, Vec3 var9) {
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        this.strength = var7;
        this.affectedBlockPositions = Lists.newArrayList(var8);
        if (var9 != null) {
            this.field_149152_f = (float)var9.xCoord;
            this.field_149153_g = (float)var9.yCoord;
            this.field_149159_h = (float)var9.zCoord;
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.posX = var1.readFloat();
        this.posY = var1.readFloat();
        this.posZ = var1.readFloat();
        this.strength = var1.readFloat();
        int i = var1.readInt();
        this.affectedBlockPositions = Lists.newArrayListWithCapacity(i);
        int j = (int)this.posX;
        int k = (int)this.posY;
        int l = (int)this.posZ;

        for (int i1 = 0; i1 < i; i1++) {
            int j1 = var1.readByte() + j;
            int k1 = var1.readByte() + k;
            int l1 = var1.readByte() + l;
            this.affectedBlockPositions.add(new BlockPos(j1, k1, l1));
        }

        this.field_149152_f = var1.readFloat();
        this.field_149153_g = var1.readFloat();
        this.field_149159_h = var1.readFloat();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeFloat((float)this.posX);
        var1.writeFloat((float)this.posY);
        var1.writeFloat((float)this.posZ);
        var1.writeFloat(this.strength);
        var1.writeInt(this.affectedBlockPositions.size());
        int i = (int)this.posX;
        int j = (int)this.posY;
        int k = (int)this.posZ;

        for (BlockPos blockpos : (Iterable<BlockPos>) (Iterable) this.affectedBlockPositions) {
            int l = blockpos.getX() - i;
            int i1 = blockpos.getY() - j;
            int j1 = blockpos.getZ() - k;
            var1.writeByte(l);
            var1.writeByte(i1);
            var1.writeByte(j1);
        }

        var1.writeFloat(this.field_149152_f);
        var1.writeFloat(this.field_149153_g);
        var1.writeFloat(this.field_149159_h);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleExplosion(this);
    }

    public float func_149149_c() {
        return this.field_149152_f;
    }

    public float func_149144_d() {
        return this.field_149153_g;
    }

    public float func_149147_e() {
        return this.field_149159_h;
    }

    public double getX() {
        return this.posX;
    }

    public double getY() {
        return this.posY;
    }

    public double getZ() {
        return this.posZ;
    }

    public float getStrength() {
        return this.strength;
    }

    public List getAffectedBlockPositions() {
        return this.affectedBlockPositions;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
