package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S30PacketWindowItems implements Packet {
    private int windowId;
    private ItemStack[] itemStacks;

    public S30PacketWindowItems() {
    }

    public S30PacketWindowItems(int var1, List var2) {
        this.windowId = var1;
        this.itemStacks = new ItemStack[var2.size()];

        for (int i = 0; i < this.itemStacks.length; i++) {
            ItemStack itemstack = (ItemStack)var2.get(i);
            this.itemStacks[i] = itemstack == null ? null : itemstack.copy();
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.windowId = var1.readUnsignedByte();
        short short1 = var1.readShort();
        this.itemStacks = new ItemStack[short1];

        for (int i = 0; i < short1; i++) {
            this.itemStacks[i] = var1.readItemStackFromBuffer();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeByte(this.windowId);
        var1.writeShort(this.itemStacks.length);

        for (ItemStack itemstack : this.itemStacks) {
            var1.writeItemStackToBuffer(itemstack);
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleWindowItems(this);
    }

    public int func_148911_c() {
        return this.windowId;
    }

    public ItemStack[] getItemStacks() {
        return this.itemStacks;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
