package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.io.IOException;
import java.util.List;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.WorldSettings;

public class S38PacketPlayerListItem implements Packet {
    private S38PacketPlayerListItem.Action action;
    private final List players = Lists.newArrayList();

    public S38PacketPlayerListItem() {
    }

    public S38PacketPlayerListItem(S38PacketPlayerListItem.Action var1, EntityPlayerMP... var2) {
        this.action = var1;

        for (EntityPlayerMP entityplayermp : var2) {
            this.players
                .add(
                    new S38PacketPlayerListItem.AddPlayerData(
                        entityplayermp.getGameProfile(),
                        entityplayermp.ping,
                        entityplayermp.theItemInWorldManager.getGameType(),
                        entityplayermp.getTabListDisplayName()
                    )
                );
        }
    }

    public S38PacketPlayerListItem(S38PacketPlayerListItem.Action var1, Iterable var2) {
        this.action = var1;

        for (EntityPlayerMP entityplayermp : (Iterable<EntityPlayerMP>) (Iterable) var2) {
            this.players
                .add(
                    new S38PacketPlayerListItem.AddPlayerData(
                        entityplayermp.getGameProfile(),
                        entityplayermp.ping,
                        entityplayermp.theItemInWorldManager.getGameType(),
                        entityplayermp.getTabListDisplayName()
                    )
                );
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.action = (S38PacketPlayerListItem.Action)var1.readEnumValue(S38PacketPlayerListItem.Action.class);
        int i = var1.readVarIntFromBuffer();

        for (int j = 0; j < i; j++) {
            GameProfile gameprofile = null;
            int k = 0;
            WorldSettings.GameType worldsettings$gametype = null;
            IChatComponent ichatcomponent = null;
            switch (this.action) {
                case ADD_PLAYER:
                    gameprofile = new GameProfile(var1.readUuid(), var1.readStringFromBuffer(16));
                    int l = var1.readVarIntFromBuffer();
                    int i1 = 0;

                    for (; i1 < l; i1++) {
                        String s = var1.readStringFromBuffer(Short.MAX_VALUE);
                        String s1 = var1.readStringFromBuffer(Short.MAX_VALUE);
                        if (var1.readBoolean()) {
                            gameprofile.getProperties().put(s, new Property(s, s1, var1.readStringFromBuffer(Short.MAX_VALUE)));
                        } else {
                            gameprofile.getProperties().put(s, new Property(s, s1));
                        }
                    }

                    worldsettings$gametype = WorldSettings.GameType.getByID(var1.readVarIntFromBuffer());
                    k = var1.readVarIntFromBuffer();
                    if (var1.readBoolean()) {
                        ichatcomponent = var1.readChatComponent();
                    }
                    break;
                case UPDATE_GAME_MODE:
                    gameprofile = new GameProfile(var1.readUuid(), null);
                    worldsettings$gametype = WorldSettings.GameType.getByID(var1.readVarIntFromBuffer());
                    break;
                case UPDATE_LATENCY:
                    gameprofile = new GameProfile(var1.readUuid(), null);
                    k = var1.readVarIntFromBuffer();
                    break;
                case UPDATE_DISPLAY_NAME:
                    gameprofile = new GameProfile(var1.readUuid(), null);
                    if (var1.readBoolean()) {
                        ichatcomponent = var1.readChatComponent();
                    }
                    break;
                case REMOVE_PLAYER:
                    gameprofile = new GameProfile(var1.readUuid(), null);
            }

            this.players.add(new S38PacketPlayerListItem.AddPlayerData(gameprofile, k, worldsettings$gametype, ichatcomponent));
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeEnumValue(this.action);
        var1.writeVarIntToBuffer(this.players.size());

        for (S38PacketPlayerListItem.AddPlayerData s38packetplayerlistitem$addplayerdata : (Iterable<S38PacketPlayerListItem.AddPlayerData>) (Iterable) this.players) {
            switch (this.action) {
                case ADD_PLAYER:
                    var1.writeUuid(s38packetplayerlistitem$addplayerdata.getProfile().getId());
                    var1.writeString(s38packetplayerlistitem$addplayerdata.getProfile().getName());
                    var1.writeVarIntToBuffer(s38packetplayerlistitem$addplayerdata.getProfile().getProperties().size());

                    for (Property property : s38packetplayerlistitem$addplayerdata.getProfile().getProperties().values()) {
                        var1.writeString(property.getName());
                        var1.writeString(property.getValue());
                        if (property.hasSignature()) {
                            var1.writeBoolean(true);
                            var1.writeString(property.getSignature());
                        } else {
                            var1.writeBoolean(false);
                        }
                    }

                    var1.writeVarIntToBuffer(s38packetplayerlistitem$addplayerdata.getGameMode().getID());
                    var1.writeVarIntToBuffer(s38packetplayerlistitem$addplayerdata.getPing());
                    if (s38packetplayerlistitem$addplayerdata.getDisplayName() == null) {
                        var1.writeBoolean(false);
                    } else {
                        var1.writeBoolean(true);
                        var1.writeChatComponent(s38packetplayerlistitem$addplayerdata.getDisplayName());
                    }
                    break;
                case UPDATE_GAME_MODE:
                    var1.writeUuid(s38packetplayerlistitem$addplayerdata.getProfile().getId());
                    var1.writeVarIntToBuffer(s38packetplayerlistitem$addplayerdata.getGameMode().getID());
                    break;
                case UPDATE_LATENCY:
                    var1.writeUuid(s38packetplayerlistitem$addplayerdata.getProfile().getId());
                    var1.writeVarIntToBuffer(s38packetplayerlistitem$addplayerdata.getPing());
                    break;
                case UPDATE_DISPLAY_NAME:
                    var1.writeUuid(s38packetplayerlistitem$addplayerdata.getProfile().getId());
                    if (s38packetplayerlistitem$addplayerdata.getDisplayName() == null) {
                        var1.writeBoolean(false);
                    } else {
                        var1.writeBoolean(true);
                        var1.writeChatComponent(s38packetplayerlistitem$addplayerdata.getDisplayName());
                    }
                    break;
                case REMOVE_PLAYER:
                    var1.writeUuid(s38packetplayerlistitem$addplayerdata.getProfile().getId());
            }
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handlePlayerListItem(this);
    }

    public List func_179767_a() {
        return this.players;
    }

    public S38PacketPlayerListItem.Action func_179768_b() {
        return this.action;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }

    public enum Action {
        ADD_PLAYER,
        UPDATE_GAME_MODE,
        UPDATE_LATENCY,
        UPDATE_DISPLAY_NAME,
        REMOVE_PLAYER;
    }

    public class AddPlayerData {
        private final int ping;
        private final WorldSettings.GameType gamemode;
        private final GameProfile profile;
        private final IChatComponent displayName;

        public AddPlayerData(GameProfile var2, int var3, WorldSettings.GameType var4, IChatComponent var5) {
            this.profile = var2;
            this.ping = var3;
            this.gamemode = var4;
            this.displayName = var5;
        }

        public GameProfile getProfile() {
            return this.profile;
        }

        public int getPing() {
            return this.ping;
        }

        public WorldSettings.GameType getGameMode() {
            return this.gamemode;
        }

        public IChatComponent getDisplayName() {
            return this.displayName;
        }
    }
}
