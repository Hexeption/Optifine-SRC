package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;

public class S21PacketChunkData implements Packet {
    private int chunkX;
    private int chunkZ;
    private S21PacketChunkData.Extracted extractedData;
    private boolean field_149279_g;

    public S21PacketChunkData() {
    }

    public S21PacketChunkData(Chunk var1, boolean var2, int var3) {
        this.chunkX = var1.xPosition;
        this.chunkZ = var1.zPosition;
        this.field_149279_g = var2;
        this.extractedData = func_179756_a(var1, var2, !var1.getWorld().provider.getHasNoSky(), var3);
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.chunkX = var1.readInt();
        this.chunkZ = var1.readInt();
        this.field_149279_g = var1.readBoolean();
        this.extractedData = new S21PacketChunkData.Extracted();
        this.extractedData.dataSize = var1.readShort();
        this.extractedData.data = var1.readByteArray();
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeInt(this.chunkX);
        var1.writeInt(this.chunkZ);
        var1.writeBoolean(this.field_149279_g);
        var1.writeShort((short)(this.extractedData.dataSize & 65535));
        var1.writeByteArray(this.extractedData.data);
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleChunkData(this);
    }

    public byte[] func_149272_d() {
        return this.extractedData.data;
    }

    protected static int func_180737_a(int var0, boolean var1, boolean var2) {
        int i = var0 * 2 * 16 * 16 * 16;
        int j = var0 * 16 * 16 * 16 / 2;
        int k = var1 ? var0 * 16 * 16 * 16 / 2 : 0;
        int l = var2 ? 256 : 0;
        return i + j + k + l;
    }

    public static S21PacketChunkData.Extracted func_179756_a(Chunk var0, boolean var1, boolean var2, int var3) {
        ExtendedBlockStorage[] aextendedblockstorage = var0.getBlockStorageArray();
        S21PacketChunkData.Extracted s21packetchunkdata$extracted = new S21PacketChunkData.Extracted();
        ArrayList arraylist = Lists.newArrayList();

        for (int i = 0; i < aextendedblockstorage.length; i++) {
            ExtendedBlockStorage extendedblockstorage = aextendedblockstorage[i];
            if (extendedblockstorage != null && (!var1 || !extendedblockstorage.isEmpty()) && (var3 & 1 << i) != 0) {
                s21packetchunkdata$extracted.dataSize |= 1 << i;
                arraylist.add(extendedblockstorage);
            }
        }

        s21packetchunkdata$extracted.data = new byte[func_180737_a(Integer.bitCount(s21packetchunkdata$extracted.dataSize), var2, var1)];
        int j = 0;

        for (ExtendedBlockStorage extendedblockstorage1 : (Iterable<ExtendedBlockStorage>) (Iterable) arraylist) {
            char[] achar = extendedblockstorage1.getData();

            for (char c0 : achar) {
                s21packetchunkdata$extracted.data[j++] = (byte)(c0 & 0xFF);
                s21packetchunkdata$extracted.data[j++] = (byte)(c0 >> '\b' & 0xFF);
            }
        }

        for (ExtendedBlockStorage extendedblockstorage2 : (Iterable<ExtendedBlockStorage>) (Iterable) arraylist) {
            j = func_179757_a(extendedblockstorage2.getBlocklightArray().getData(), s21packetchunkdata$extracted.data, j);
        }

        if (var2) {
            for (ExtendedBlockStorage extendedblockstorage3 : (Iterable<ExtendedBlockStorage>) (Iterable) arraylist) {
                j = func_179757_a(extendedblockstorage3.getSkylightArray().getData(), s21packetchunkdata$extracted.data, j);
            }
        }

        if (var1) {
            func_179757_a(var0.getBiomeArray(), s21packetchunkdata$extracted.data, j);
        }

        return s21packetchunkdata$extracted;
    }

    private static int func_179757_a(byte[] var0, byte[] var1, int var2) {
        System.arraycopy(var0, 0, var1, var2, var0.length);
        return var2 + var0.length;
    }

    public int getChunkX() {
        return this.chunkX;
    }

    public int getChunkZ() {
        return this.chunkZ;
    }

    public int getExtractedSize() {
        return this.extractedData.dataSize;
    }

    public boolean func_149274_i() {
        return this.field_149279_g;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }

    public static class Extracted {
        public byte[] data;
        public int dataSize;
    }
}
