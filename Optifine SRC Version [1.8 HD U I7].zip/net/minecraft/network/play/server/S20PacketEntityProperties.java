package net.minecraft.network.play.server;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S20PacketEntityProperties implements Packet {
    private int entityId;
    private final List field_149444_b = Lists.newArrayList();

    public S20PacketEntityProperties() {
    }

    public S20PacketEntityProperties(int var1, Collection var2) {
        this.entityId = var1;

        for (IAttributeInstance iattributeinstance : (Iterable<IAttributeInstance>) (Iterable) var2) {
            this.field_149444_b
                .add(
                    new S20PacketEntityProperties.Snapshot(
                        iattributeinstance.getAttribute().getAttributeUnlocalizedName(), iattributeinstance.getBaseValue(), iattributeinstance.func_111122_c()
                    )
                );
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.entityId = var1.readVarIntFromBuffer();
        int i = var1.readInt();

        for (int j = 0; j < i; j++) {
            String s = var1.readStringFromBuffer(64);
            double d0 = var1.readDouble();
            ArrayList arraylist = Lists.newArrayList();
            int k = var1.readVarIntFromBuffer();

            for (int l = 0; l < k; l++) {
                UUID uuid = var1.readUuid();
                arraylist.add(new AttributeModifier(uuid, "Unknown synced attribute modifier", var1.readDouble(), var1.readByte()));
            }

            this.field_149444_b.add(new S20PacketEntityProperties.Snapshot(s, d0, arraylist));
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeVarIntToBuffer(this.entityId);
        var1.writeInt(this.field_149444_b.size());

        for (S20PacketEntityProperties.Snapshot s20packetentityproperties$snapshot : (Iterable<S20PacketEntityProperties.Snapshot>) (Iterable) this.field_149444_b) {
            var1.writeString(s20packetentityproperties$snapshot.func_151409_a());
            var1.writeDouble(s20packetentityproperties$snapshot.func_151410_b());
            var1.writeVarIntToBuffer(s20packetentityproperties$snapshot.func_151408_c().size());

            for (AttributeModifier attributemodifier : (Iterable<AttributeModifier>) (Iterable) s20packetentityproperties$snapshot.func_151408_c()) {
                var1.writeUuid(attributemodifier.getID());
                var1.writeDouble(attributemodifier.getAmount());
                var1.writeByte(attributemodifier.getOperation());
            }
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleEntityProperties(this);
    }

    public int getEntityId() {
        return this.entityId;
    }

    public List func_149441_d() {
        return this.field_149444_b;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }

    public class Snapshot {
        private final String field_151412_b;
        private final double field_151413_c;
        private final Collection field_151411_d;

        public Snapshot(String var2, double var3, Collection var5) {
            this.field_151412_b = var2;
            this.field_151413_c = var3;
            this.field_151411_d = var5;
        }

        public String func_151409_a() {
            return this.field_151412_b;
        }

        public double func_151410_b() {
            return this.field_151413_c;
        }

        public Collection func_151408_c() {
            return this.field_151411_d;
        }
    }
}
