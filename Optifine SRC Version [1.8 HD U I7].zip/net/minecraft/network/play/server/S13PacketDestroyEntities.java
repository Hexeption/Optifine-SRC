package net.minecraft.network.play.server;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;

public class S13PacketDestroyEntities implements Packet {
    private int[] entityIDs;

    public S13PacketDestroyEntities() {
    }

    public S13PacketDestroyEntities(int... var1) {
        this.entityIDs = var1;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.entityIDs = new int[var1.readVarIntFromBuffer()];

        for (int i = 0; i < this.entityIDs.length; i++) {
            this.entityIDs[i] = var1.readVarIntFromBuffer();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeVarIntToBuffer(this.entityIDs.length);

        for (int i = 0; i < this.entityIDs.length; i++) {
            var1.writeVarIntToBuffer(this.entityIDs[i]);
        }
    }

    public void processPacket(INetHandlerPlayClient var1) {
        var1.handleDestroyEntities(this);
    }

    public int[] getEntityIDs() {
        return this.entityIDs;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayClient)var1);
    }
}
