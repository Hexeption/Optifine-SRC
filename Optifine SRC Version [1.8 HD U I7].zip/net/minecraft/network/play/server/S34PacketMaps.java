package net.minecraft.network.play.server;

import java.io.IOException;
import java.util.Collection;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.util.Vec4b;
import net.minecraft.world.storage.MapData;

public class S34PacketMaps implements Packet {
    private int mapId;
    private byte mapScale;
    private Vec4b[] mapVisiblePlayersVec4b;
    private int mapMinX;
    private int mapMinY;
    private int mapMaxX;
    private int mapMaxY;
    private byte[] mapDataBytes;

    public S34PacketMaps() {
    }

    public S34PacketMaps(int var1, byte var2, Collection var3, byte[] var4, int var5, int var6, int var7, int var8) {
        this.mapId = var1;
        this.mapScale = var2;
        this.mapVisiblePlayersVec4b = ((Vec4b[]) var3.toArray(new Vec4b[var3.size()]));
        this.mapMinX = var5;
        this.mapMinY = var6;
        this.mapMaxX = var7;
        this.mapMaxY = var8;
        this.mapDataBytes = new byte[var7 * var8];

        for (int i = 0; i < var7; i++) {
            for (int j = 0; j < var8; j++) {
                this.mapDataBytes[i + j * var7] = var4[var5 + i + (var6 + j) * 128];
            }
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.mapId = var1.readVarIntFromBuffer();
        this.mapScale = var1.readByte();
        this.mapVisiblePlayersVec4b = new Vec4b[var1.readVarIntFromBuffer()];

        for (int i = 0; i < this.mapVisiblePlayersVec4b.length; i++) {
            short short1 = var1.readByte();
            this.mapVisiblePlayersVec4b[i] = new Vec4b((byte)(short1 >> 4 & 15), var1.readByte(), var1.readByte(), (byte)(short1 & 15));
        }

        this.mapMaxX = var1.readUnsignedByte();
        if (this.mapMaxX > 0) {
            this.mapMaxY = var1.readUnsignedByte();
            this.mapMinX = var1.readUnsignedByte();
            this.mapMinY = var1.readUnsignedByte();
            this.mapDataBytes = var1.readByteArray();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeVarIntToBuffer(this.mapId);
        var1.writeByte(this.mapScale);
        var1.writeVarIntToBuffer(this.mapVisiblePlayersVec4b.length);

        for (Vec4b vec4b : this.mapVisiblePlayersVec4b) {
            var1.writeByte((vec4b.func_176110_a() & 15) << 4 | vec4b.func_176111_d() & 15);
            var1.writeByte(vec4b.func_176112_b());
            var1.writeByte(vec4b.func_176113_c());
        }

        var1.writeByte(this.mapMaxX);
        if (this.mapMaxX > 0) {
            var1.writeByte(this.mapMaxY);
            var1.writeByte(this.mapMinX);
            var1.writeByte(this.mapMinY);
            var1.writeByteArray(this.mapDataBytes);
        }
    }

    public void handleClient(INetHandlerPlayClient var1) {
        var1.handleMaps(this);
    }

    public int getMapId() {
        return this.mapId;
    }

    public void setMapdataTo(MapData var1) {
        var1.scale = this.mapScale;
        var1.playersVisibleOnMap.clear();

        for (int i = 0; i < this.mapVisiblePlayersVec4b.length; i++) {
            Vec4b vec4b = this.mapVisiblePlayersVec4b[i];
            var1.playersVisibleOnMap.put("icon-" + i, vec4b);
        }

        for (int j = 0; j < this.mapMaxX; j++) {
            for (int k = 0; k < this.mapMaxY; k++) {
                var1.colors[this.mapMinX + j + (this.mapMinY + k) * 128] = this.mapDataBytes[j + k * this.mapMaxX];
            }
        }
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.handleClient((INetHandlerPlayClient)var1);
    }
}
