package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;

public class C17PacketCustomPayload implements Packet {
    private String channel;
    private PacketBuffer data;

    public C17PacketCustomPayload() {
    }

    public C17PacketCustomPayload(String var1, PacketBuffer var2) {
        this.channel = var1;
        this.data = var2;
        if (var2.writerIndex() > Short.MAX_VALUE) {
            throw new IllegalArgumentException("Payload may not be larger than 32767 bytes");
        }
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.channel = var1.readStringFromBuffer(20);
        int i = var1.readableBytes();
        if (i >= 0 && i <= Short.MAX_VALUE) {
            this.data = new PacketBuffer(var1.readBytes(i));
        } else {
            throw new IOException("Payload may not be larger than 32767 bytes");
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeString(this.channel);
        var1.writeBytes(this.data);
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processVanilla250Packet(this);
    }

    public String getChannelName() {
        return this.channel;
    }

    public PacketBuffer getBufferData() {
        return this.data;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
