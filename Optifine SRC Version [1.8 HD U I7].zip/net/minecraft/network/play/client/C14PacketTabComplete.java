package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.BlockPos;
import org.apache.commons.lang3.StringUtils;

public class C14PacketTabComplete implements Packet {
    private String message;
    private BlockPos targetBlock;

    public C14PacketTabComplete() {
    }

    public C14PacketTabComplete(String var1) {
        this(var1, null);
    }

    public C14PacketTabComplete(String var1, BlockPos var2) {
        this.message = var1;
        this.targetBlock = var2;
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.message = var1.readStringFromBuffer(Short.MAX_VALUE);
        boolean flag = var1.readBoolean();
        if (flag) {
            this.targetBlock = var1.readBlockPos();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeString(StringUtils.substring(this.message, 0, Short.MAX_VALUE));
        boolean flag = this.targetBlock != null;
        var1.writeBoolean(flag);
        if (flag) {
            var1.writeBlockPos(this.targetBlock);
        }
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processTabComplete(this);
    }

    public String getMessage() {
        return this.message;
    }

    public BlockPos getTargetBlock() {
        return this.targetBlock;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
