package net.minecraft.network.play.client;

import java.io.IOException;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IChatComponent;

public class C12PacketUpdateSign implements Packet {
    private BlockPos pos;
    private IChatComponent[] lines;

    public C12PacketUpdateSign() {
    }

    public C12PacketUpdateSign(BlockPos var1, IChatComponent[] var2) {
        this.pos = var1;
        this.lines = new IChatComponent[]{var2[0], var2[1], var2[2], var2[3]};
    }

    @Override
    public void readPacketData(PacketBuffer var1) throws IOException {
        this.pos = var1.readBlockPos();
        this.lines = new IChatComponent[4];

        for (int i = 0; i < 4; i++) {
            this.lines[i] = var1.readChatComponent();
        }
    }

    @Override
    public void writePacketData(PacketBuffer var1) throws IOException {
        var1.writeBlockPos(this.pos);

        for (int i = 0; i < 4; i++) {
            var1.writeChatComponent(this.lines[i]);
        }
    }

    public void processPacket(INetHandlerPlayServer var1) {
        var1.processUpdateSign(this);
    }

    public BlockPos getPosition() {
        return this.pos;
    }

    public IChatComponent[] getLines() {
        return this.lines;
    }

    @Override
    public void processPacket(INetHandler var1) {
        this.processPacket((INetHandlerPlayServer)var1);
    }
}
