package net.minecraft.init;

import com.mojang.authlib.GameProfile;
import java.io.PrintStream;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCommandBlock;
import net.minecraft.block.BlockDispenser;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockPumpkin;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockTNT;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import net.minecraft.dispenser.BehaviorProjectileDispense;
import net.minecraft.dispenser.IBehaviorDispenseItem;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.dispenser.IPosition;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemDye;
import net.minecraft.item.ItemMonsterPlacer;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.LoggingPrintStream;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Bootstrap {
    private static final PrintStream SYSOUT = System.out;
    private static boolean alreadyRegistered = false;
    private static final Logger LOGGER = LogManager.getLogger();

    public static boolean isRegistered() {
        return alreadyRegistered;
    }

    static void registerDispenserBehaviors() {
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.arrow, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                EntityArrow entityarrow = new EntityArrow(var1, var2.getX(), var2.getY(), var2.getZ());
                entityarrow.canBePickedUp = 1;
                return entityarrow;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.egg, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                return new EntityEgg(var1, var2.getX(), var2.getY(), var2.getZ());
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.snowball, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                return new EntitySnowball(var1, var2.getX(), var2.getY(), var2.getZ());
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.experience_bottle, new BehaviorProjectileDispense() {
            @Override
            protected IProjectile getProjectileEntity(World var1, IPosition var2) {
                return new EntityExpBottle(var1, var2.getX(), var2.getY(), var2.getZ());
            }

            @Override
            protected float func_82498_a() {
                return super.func_82498_a() * 0.5F;
            }

            @Override
            protected float func_82500_b() {
                return super.func_82500_b() * 1.25F;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.potionitem, new IBehaviorDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150843_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispense(IBlockSource var1, final ItemStack var2) {
                return ItemPotion.isSplash(var2.getMetadata()) ? (new BehaviorProjectileDispense() {
                    @Override
                    protected IProjectile getProjectileEntity(World var1, IPosition var2x) {
                        return new EntityPotion(var1, var2x.getX(), var2x.getY(), var2x.getZ(), var2.copy());
                    }

                    @Override
                    protected float func_82498_a() {
                        return super.func_82498_a() * 0.5F;
                    }

                    @Override
                    protected float func_82500_b() {
                        return super.func_82500_b() * 1.25F;
                    }
                }).dispense(var1, var2) : this.field_150843_b.dispense(var1, var2);
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.spawn_egg, new BehaviorDefaultDispenseItem() {
            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacing(var1.getBlockMetadata());
                double d0 = var1.getX() + enumfacing.getFrontOffsetX();
                double d1 = var1.getBlockPos().getY() + 0.2F;
                double d2 = var1.getZ() + enumfacing.getFrontOffsetZ();
                Entity entity = ItemMonsterPlacer.spawnCreature(var1.getWorld(), var2.getMetadata(), d0, d1, d2);
                if (entity instanceof EntityLivingBase && var2.hasDisplayName()) {
                    ((EntityLiving)entity).setCustomNameTag(var2.getDisplayName());
                }

                var2.splitStack(1);
                return var2;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.fireworks, new BehaviorDefaultDispenseItem() {
            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacing(var1.getBlockMetadata());
                double d0 = var1.getX() + enumfacing.getFrontOffsetX();
                double d1 = var1.getBlockPos().getY() + 0.2F;
                double d2 = var1.getZ() + enumfacing.getFrontOffsetZ();
                EntityFireworkRocket entityfireworkrocket = new EntityFireworkRocket(var1.getWorld(), d0, d1, d2, var2);
                var1.getWorld().spawnEntityInWorld(entityfireworkrocket);
                var2.splitStack(1);
                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                var1.getWorld().playAuxSFX(1002, var1.getBlockPos(), 0);
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.fire_charge, new BehaviorDefaultDispenseItem() {
            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacing(var1.getBlockMetadata());
                IPosition iposition = BlockDispenser.getDispensePosition(var1);
                double d0 = iposition.getX() + enumfacing.getFrontOffsetX() * 0.3F;
                double d1 = iposition.getY() + enumfacing.getFrontOffsetX() * 0.3F;
                double d2 = iposition.getZ() + enumfacing.getFrontOffsetZ() * 0.3F;
                World world = var1.getWorld();
                Random random = world.rand;
                double d3 = random.nextGaussian() * 0.05 + enumfacing.getFrontOffsetX();
                double d4 = random.nextGaussian() * 0.05 + enumfacing.getFrontOffsetY();
                double d5 = random.nextGaussian() * 0.05 + enumfacing.getFrontOffsetZ();
                world.spawnEntityInWorld(new EntitySmallFireball(world, d0, d1, d2, d3, d4, d5));
                var2.splitStack(1);
                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                var1.getWorld().playAuxSFX(1009, var1.getBlockPos(), 0);
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.boat, new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150842_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                EnumFacing enumfacing = BlockDispenser.getFacing(var1.getBlockMetadata());
                World world = var1.getWorld();
                double d0 = var1.getX() + enumfacing.getFrontOffsetX() * 1.125F;
                double d1 = var1.getY() + enumfacing.getFrontOffsetY() * 1.125F;
                double d2 = var1.getZ() + enumfacing.getFrontOffsetZ() * 1.125F;
                BlockPos blockpos = var1.getBlockPos().offset(enumfacing);
                Material material = world.getBlockState(blockpos).getBlock().getMaterial();
                double d3;
                if (Material.water.equals(material)) {
                    d3 = 1.0;
                } else {
                    if (!Material.air.equals(material) || !Material.water.equals(world.getBlockState(blockpos.down()).getBlock().getMaterial())) {
                        return this.field_150842_b.dispense(var1, var2);
                    }

                    d3 = 0.0;
                }

                EntityBoat entityboat = new EntityBoat(world, d0, d1 + d3, d2);
                world.spawnEntityInWorld(entityboat);
                var2.splitStack(1);
                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                var1.getWorld().playAuxSFX(1000, var1.getBlockPos(), 0);
            }
        });
        BehaviorDefaultDispenseItem behaviordefaultdispenseitem = new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150841_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                ItemBucket itembucket = (ItemBucket)var2.getItem();
                BlockPos blockpos = var1.getBlockPos().offset(BlockDispenser.getFacing(var1.getBlockMetadata()));
                if (itembucket.tryPlaceContainedLiquid(var1.getWorld(), blockpos)) {
                    var2.setItem(Items.bucket);
                    var2.stackSize = 1;
                    return var2;
                } else {
                    return this.field_150841_b.dispense(var1, var2);
                }
            }
        };
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.lava_bucket, behaviordefaultdispenseitem);
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.water_bucket, behaviordefaultdispenseitem);
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.bucket, new BehaviorDefaultDispenseItem() {
            private final BehaviorDefaultDispenseItem field_150840_b = new BehaviorDefaultDispenseItem();

            @Override
            public ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                World world = var1.getWorld();
                BlockPos blockpos = var1.getBlockPos().offset(BlockDispenser.getFacing(var1.getBlockMetadata()));
                IBlockState iblockstate = world.getBlockState(blockpos);
                Block block = iblockstate.getBlock();
                Material material = block.getMaterial();
                Item item;
                if (Material.water.equals(material) && block instanceof BlockLiquid && (Integer)iblockstate.getValue(BlockLiquid.LEVEL) == 0) {
                    item = Items.water_bucket;
                } else {
                    if (!Material.lava.equals(material) || !(block instanceof BlockLiquid) || (Integer)iblockstate.getValue(BlockLiquid.LEVEL) != 0) {
                        return super.dispenseStack(var1, var2);
                    }

                    item = Items.lava_bucket;
                }

                world.setBlockToAir(blockpos);
                if (--var2.stackSize == 0) {
                    var2.setItem(item);
                    var2.stackSize = 1;
                } else if (((TileEntityDispenser)var1.getBlockTileEntity()).addItemStack(new ItemStack(item)) < 0) {
                    this.field_150840_b.dispense(var1, new ItemStack(item));
                }

                return var2;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.flint_and_steel, new BehaviorDefaultDispenseItem() {
            private boolean field_150839_b = true;

            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                World world = var1.getWorld();
                BlockPos blockpos = var1.getBlockPos().offset(BlockDispenser.getFacing(var1.getBlockMetadata()));
                if (world.isAirBlock(blockpos)) {
                    world.setBlockState(blockpos, Blocks.fire.getDefaultState());
                    if (var2.attemptDamageItem(1, world.rand)) {
                        var2.stackSize = 0;
                    }
                } else if (world.getBlockState(blockpos).getBlock() == Blocks.tnt) {
                    Blocks.tnt.onBlockDestroyedByPlayer(world, blockpos, Blocks.tnt.getDefaultState().withProperty(BlockTNT.EXPLODE, true));
                    world.setBlockToAir(blockpos);
                } else {
                    this.field_150839_b = false;
                }

                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                if (this.field_150839_b) {
                    var1.getWorld().playAuxSFX(1000, var1.getBlockPos(), 0);
                } else {
                    var1.getWorld().playAuxSFX(1001, var1.getBlockPos(), 0);
                }
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.dye, new BehaviorDefaultDispenseItem() {
            private boolean field_150838_b = true;

            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                if (EnumDyeColor.WHITE == EnumDyeColor.byDyeDamage(var2.getMetadata())) {
                    World world = var1.getWorld();
                    BlockPos blockpos = var1.getBlockPos().offset(BlockDispenser.getFacing(var1.getBlockMetadata()));
                    if (ItemDye.applyBonemeal(var2, world, blockpos)) {
                        if (!world.isRemote) {
                            world.playAuxSFX(2005, blockpos, 0);
                        }
                    } else {
                        this.field_150838_b = false;
                    }

                    return var2;
                } else {
                    return super.dispenseStack(var1, var2);
                }
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                if (this.field_150838_b) {
                    var1.getWorld().playAuxSFX(1000, var1.getBlockPos(), 0);
                } else {
                    var1.getWorld().playAuxSFX(1001, var1.getBlockPos(), 0);
                }
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.getItemFromBlock(Blocks.tnt), new BehaviorDefaultDispenseItem() {
            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                World world = var1.getWorld();
                BlockPos blockpos = var1.getBlockPos().offset(BlockDispenser.getFacing(var1.getBlockMetadata()));
                EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, blockpos.getX() + 0.5, blockpos.getY(), blockpos.getZ() + 0.5, null);
                world.spawnEntityInWorld(entitytntprimed);
                world.playSoundAtEntity(entitytntprimed, "game.tnt.primed", 1.0F, 1.0F);
                var2.stackSize--;
                return var2;
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Items.skull, new BehaviorDefaultDispenseItem() {
            private boolean field_179240_b = true;

            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                World world = var1.getWorld();
                EnumFacing enumfacing = BlockDispenser.getFacing(var1.getBlockMetadata());
                BlockPos blockpos = var1.getBlockPos().offset(enumfacing);
                BlockSkull blockskull = Blocks.skull;
                if (!world.isAirBlock(blockpos) || !blockskull.canDispenserPlace(world, blockpos, var2)) {
                    this.field_179240_b = false;
                } else if (!world.isRemote) {
                    world.setBlockState(blockpos, blockskull.getDefaultState().withProperty(BlockSkull.FACING, EnumFacing.UP), 3);
                    TileEntity tileentity = world.getTileEntity(blockpos);
                    if (tileentity instanceof TileEntitySkull) {
                        if (var2.getMetadata() == 3) {
                            GameProfile gameprofile = null;
                            if (var2.hasTagCompound()) {
                                NBTTagCompound nbttagcompound = var2.getTagCompound();
                                if (nbttagcompound.hasKey("SkullOwner", 10)) {
                                    gameprofile = NBTUtil.readGameProfileFromNBT(nbttagcompound.getCompoundTag("SkullOwner"));
                                } else if (nbttagcompound.hasKey("SkullOwner", 8)) {
                                    gameprofile = new GameProfile(null, nbttagcompound.getString("SkullOwner"));
                                }
                            }

                            ((TileEntitySkull)tileentity).setPlayerProfile(gameprofile);
                        } else {
                            ((TileEntitySkull)tileentity).setType(var2.getMetadata());
                        }

                        ((TileEntitySkull)tileentity).setSkullRotation(enumfacing.getOpposite().getHorizontalIndex() * 4);
                        Blocks.skull.checkWitherSpawn(world, blockpos, (TileEntitySkull)tileentity);
                    }

                    var2.stackSize--;
                }

                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                if (this.field_179240_b) {
                    var1.getWorld().playAuxSFX(1000, var1.getBlockPos(), 0);
                } else {
                    var1.getWorld().playAuxSFX(1001, var1.getBlockPos(), 0);
                }
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.getItemFromBlock(Blocks.pumpkin), new BehaviorDefaultDispenseItem() {
            private boolean field_179241_b = true;

            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                World world = var1.getWorld();
                BlockPos blockpos = var1.getBlockPos().offset(BlockDispenser.getFacing(var1.getBlockMetadata()));
                BlockPumpkin blockpumpkin = (BlockPumpkin)Blocks.pumpkin;
                if (world.isAirBlock(blockpos) && blockpumpkin.canDispenserPlace(world, blockpos)) {
                    if (!world.isRemote) {
                        world.setBlockState(blockpos, blockpumpkin.getDefaultState(), 3);
                    }

                    var2.stackSize--;
                } else {
                    this.field_179241_b = false;
                }

                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
                if (this.field_179241_b) {
                    var1.getWorld().playAuxSFX(1000, var1.getBlockPos(), 0);
                } else {
                    var1.getWorld().playAuxSFX(1001, var1.getBlockPos(), 0);
                }
            }
        });
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.getItemFromBlock(Blocks.command_block), new BehaviorDefaultDispenseItem() {
            @Override
            protected ItemStack dispenseStack(IBlockSource var1, ItemStack var2) {
                World world = var1.getWorld();
                BlockPos blockpos = var1.getBlockPos().offset(BlockDispenser.getFacing(var1.getBlockMetadata()));
                if (world.isAirBlock(blockpos)) {
                    if (!world.isRemote) {
                        IBlockState iblockstate = Blocks.command_block.getDefaultState().withProperty(BlockCommandBlock.TRIGGERED, false);
                        world.setBlockState(blockpos, iblockstate, 3);
                        ItemBlock.setTileEntityNBT(world, blockpos, var2);
                        world.notifyNeighborsOfStateChange(var1.getBlockPos(), var1.getBlock());
                    }

                    var2.stackSize--;
                }

                return var2;
            }

            @Override
            protected void playDispenseSound(IBlockSource var1) {
            }

            @Override
            protected void spawnDispenseParticles(IBlockSource var1, EnumFacing var2) {
            }
        });
    }

    public static void register() {
        if (!alreadyRegistered) {
            alreadyRegistered = true;
            if (LOGGER.isDebugEnabled()) {
                redirectOutputToLog();
            }

            Block.registerBlocks();
            BlockFire.init();
            Item.registerItems();
            StatList.init();
            registerDispenserBehaviors();
        }
    }

    private static void redirectOutputToLog() {
        System.setErr(new LoggingPrintStream("STDERR", System.err));
        System.setOut(new LoggingPrintStream("STDOUT", SYSOUT));
    }

    public static void printToSYSOUT(String var0) {
        SYSOUT.println(var0);
    }
}
