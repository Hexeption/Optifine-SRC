package net.minecraft.nbt;

import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.util.Stack;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class JsonToNBT {
    private static final Logger logger = LogManager.getLogger();
    private static final Pattern field_179273_b = Pattern.compile("\\[[-+\\d|,\\s]+\\]");

    public static NBTTagCompound getTagFromJson(String var0) throws NBTException {
        var0 = var0.trim();
        if (!var0.startsWith("{")) {
            throw new NBTException("Invalid tag encountered, expected '{' as first char.");
        } else if (func_150310_b(var0) != 1) {
            throw new NBTException("Encountered multiple top tags, only one expected");
        } else {
            return (NBTTagCompound)func_150316_a("tag", var0).parse();
        }
    }

    static int func_150310_b(String var0) throws NBTException {
        int i = 0;
        boolean flag = false;
        Stack stack = new Stack();

        for (int j = 0; j < var0.length(); j++) {
            char c0 = var0.charAt(j);
            if (c0 == '"') {
                if (func_179271_b(var0, j)) {
                    if (!flag) {
                        throw new NBTException("Illegal use of \\\": " + var0);
                    }
                } else {
                    flag = !flag;
                }
            } else if (!flag) {
                if (c0 != '{' && c0 != '[') {
                    if (c0 == '}' && (stack.isEmpty() || (Character)stack.pop() != '{')) {
                        throw new NBTException("Unbalanced curly brackets {}: " + var0);
                    }

                    if (c0 == ']' && (stack.isEmpty() || (Character)stack.pop() != '[')) {
                        throw new NBTException("Unbalanced square brackets []: " + var0);
                    }
                } else {
                    if (stack.isEmpty()) {
                        i++;
                    }

                    stack.push(c0);
                }
            }
        }

        if (flag) {
            throw new NBTException("Unbalanced quotation: " + var0);
        }

        if (!stack.isEmpty()) {
            throw new NBTException("Unbalanced brackets: " + var0);
        }

        if (i == 0 && !var0.isEmpty()) {
            i = 1;
        }

        return i;
    }

    static JsonToNBT.Any func_179272_a(String... var0) throws NBTException {
        return func_150316_a(var0[0], var0[1]);
    }

    static JsonToNBT.Any func_150316_a(String var0, String var1) throws NBTException {
        var1 = var1.trim();
        if (var1.startsWith("{")) {
            var1 = var1.substring(1, var1.length() - 1);
            JsonToNBT.Compound jsontonbt$compound = new JsonToNBT.Compound(var0);

            while (var1.length() > 0) {
                String s1 = func_150314_a(var1, true);
                if (s1.length() > 0) {
                    boolean flag1 = false;
                    jsontonbt$compound.field_150491_b.add(func_179270_a(s1, flag1));
                }

                if (var1.length() < s1.length() + 1) {
                    break;
                }

                char c1 = var1.charAt(s1.length());
                if (c1 != ',' && c1 != '{' && c1 != '}' && c1 != '[' && c1 != ']') {
                    throw new NBTException("Unexpected token '" + c1 + "' at: " + var1.substring(s1.length()));
                }

                var1 = var1.substring(s1.length() + 1);
            }

            return jsontonbt$compound;
        } else if (var1.startsWith("[") && !field_179273_b.matcher(var1).matches()) {
            var1 = var1.substring(1, var1.length() - 1);
            JsonToNBT.List jsontonbt$list = new JsonToNBT.List(var0);

            while (var1.length() > 0) {
                String s = func_150314_a(var1, false);
                if (s.length() > 0) {
                    boolean flag = true;
                    jsontonbt$list.field_150492_b.add(func_179270_a(s, flag));
                }

                if (var1.length() < s.length() + 1) {
                    break;
                }

                char c0 = var1.charAt(s.length());
                if (c0 != ',' && c0 != '{' && c0 != '}' && c0 != '[' && c0 != ']') {
                    throw new NBTException("Unexpected token '" + c0 + "' at: " + var1.substring(s.length()));
                }

                var1 = var1.substring(s.length() + 1);
            }

            return jsontonbt$list;
        } else {
            return new JsonToNBT.Primitive(var0, var1);
        }
    }

    private static JsonToNBT.Any func_179270_a(String var0, boolean var1) throws NBTException {
        String s = func_150313_b(var0, var1);
        String s1 = func_150311_c(var0, var1);
        return func_179272_a(s, s1);
    }

    private static String func_150314_a(String var0, boolean var1) throws NBTException {
        int i = func_150312_a(var0, ':');
        int j = func_150312_a(var0, ',');
        if (var1) {
            if (i == -1) {
                throw new NBTException("Unable to locate name/value separator for string: " + var0);
            }

            if (j != -1 && j < i) {
                throw new NBTException("Name error at: " + var0);
            }
        } else if (i == -1 || i > j) {
            i = -1;
        }

        return func_179269_a(var0, i);
    }

    private static String func_179269_a(String var0, int var1) throws NBTException {
        Stack stack = new Stack();
        int i = var1 + 1;
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        int j = 0;

        while (i < var0.length()) {
            char c0 = var0.charAt(i);
            if (c0 == '"') {
                if (func_179271_b(var0, i)) {
                    if (!flag) {
                        throw new NBTException("Illegal use of \\\": " + var0);
                    }
                } else {
                    flag = !flag;
                    if (flag && !flag2) {
                        flag1 = true;
                    }

                    if (!flag) {
                        j = i;
                    }
                }
            } else if (!flag) {
                if (c0 != '{' && c0 != '[') {
                    if (c0 == '}' && (stack.isEmpty() || (Character)stack.pop() != '{')) {
                        throw new NBTException("Unbalanced curly brackets {}: " + var0);
                    }

                    if (c0 == ']' && (stack.isEmpty() || (Character)stack.pop() != '[')) {
                        throw new NBTException("Unbalanced square brackets []: " + var0);
                    }

                    if (c0 == ',' && stack.isEmpty()) {
                        return var0.substring(0, i);
                    }
                } else {
                    stack.push(c0);
                }
            }

            if (!Character.isWhitespace(c0)) {
                if (!flag && flag1 && j != i) {
                    return var0.substring(0, j + 1);
                }

                flag2 = true;
            }

            i++;
        }

        return var0.substring(0, i);
    }

    private static String func_150313_b(String var0, boolean var1) throws NBTException {
        if (var1) {
            var0 = var0.trim();
            if (var0.startsWith("{") || var0.startsWith("[")) {
                return "";
            }
        }

        int i = func_150312_a(var0, ':');
        if (i != -1) {
            return var0.substring(0, i).trim();
        } else if (var1) {
            return "";
        } else {
            throw new NBTException("Unable to locate name/value separator for string: " + var0);
        }
    }

    private static String func_150311_c(String var0, boolean var1) throws NBTException {
        if (var1) {
            var0 = var0.trim();
            if (var0.startsWith("{") || var0.startsWith("[")) {
                return var0;
            }
        }

        int i = func_150312_a(var0, ':');
        if (i != -1) {
            return var0.substring(i + 1).trim();
        } else if (var1) {
            return var0;
        } else {
            throw new NBTException("Unable to locate name/value separator for string: " + var0);
        }
    }

    private static int func_150312_a(String var0, char var1) {
        int i = 0;
        boolean flag = true;

        while (i < var0.length()) {
            char c0 = var0.charAt(i);
            if (c0 == '"') {
                if (!func_179271_b(var0, i)) {
                    flag = !flag;
                }
            } else if (flag) {
                if (c0 == var1) {
                    return i;
                }

                if (c0 == '{' || c0 == '[') {
                    return -1;
                }
            }

            i++;
        }

        return -1;
    }

    private static boolean func_179271_b(String var0, int var1) {
        return var1 > 0 && var0.charAt(var1 - 1) == '\\' && !func_179271_b(var0, var1 - 1);
    }

    abstract static class Any {
        protected String json;

        public abstract NBTBase parse();
    }

    static class Compound extends JsonToNBT.Any {
        protected java.util.List field_150491_b = Lists.newArrayList();

        public Compound(String var1) {
            this.json = var1;
        }

        @Override
        public NBTBase parse() {
            NBTTagCompound nbttagcompound = new NBTTagCompound();

            for (JsonToNBT.Any jsontonbt$any : (Iterable<JsonToNBT.Any>) (Iterable) this.field_150491_b) {
                nbttagcompound.setTag(jsontonbt$any.json, jsontonbt$any.parse());
            }

            return nbttagcompound;
        }
    }

    static class List extends JsonToNBT.Any {
        protected java.util.List field_150492_b = Lists.newArrayList();

        public List(String var1) {
            this.json = var1;
        }

        @Override
        public NBTBase parse() {
            NBTTagList nbttaglist = new NBTTagList();

            for (JsonToNBT.Any jsontonbt$any : (Iterable<JsonToNBT.Any>) (Iterable) this.field_150492_b) {
                nbttaglist.appendTag(jsontonbt$any.parse());
            }

            return nbttaglist;
        }
    }

    static class Primitive extends JsonToNBT.Any {
        private static final Pattern DOUBLE = Pattern.compile("[-+]?[0-9]*\\.?[0-9]+[d|D]");
        private static final Pattern FLOAT = Pattern.compile("[-+]?[0-9]*\\.?[0-9]+[f|F]");
        private static final Pattern BYTE = Pattern.compile("[-+]?[0-9]+[b|B]");
        private static final Pattern LONG = Pattern.compile("[-+]?[0-9]+[l|L]");
        private static final Pattern SHORT = Pattern.compile("[-+]?[0-9]+[s|S]");
        private static final Pattern INTEGER = Pattern.compile("[-+]?[0-9]+");
        private static final Pattern DOUBLE_UNTYPED = Pattern.compile("[-+]?[0-9]*\\.?[0-9]+");
        private static final Splitter SPLITTER = Splitter.on(',').omitEmptyStrings();
        protected String jsonValue;

        public Primitive(String var1, String var2) {
            this.json = var1;
            this.jsonValue = var2;
        }

        @Override
        public NBTBase parse() {
            try {
                if (DOUBLE.matcher(this.jsonValue).matches()) {
                    return new NBTTagDouble(Double.parseDouble(this.jsonValue.substring(0, this.jsonValue.length() - 1)));
                }

                if (FLOAT.matcher(this.jsonValue).matches()) {
                    return new NBTTagFloat(Float.parseFloat(this.jsonValue.substring(0, this.jsonValue.length() - 1)));
                }

                if (BYTE.matcher(this.jsonValue).matches()) {
                    return new NBTTagByte(Byte.parseByte(this.jsonValue.substring(0, this.jsonValue.length() - 1)));
                }

                if (LONG.matcher(this.jsonValue).matches()) {
                    return new NBTTagLong(Long.parseLong(this.jsonValue.substring(0, this.jsonValue.length() - 1)));
                }

                if (SHORT.matcher(this.jsonValue).matches()) {
                    return new NBTTagShort(Short.parseShort(this.jsonValue.substring(0, this.jsonValue.length() - 1)));
                }

                if (INTEGER.matcher(this.jsonValue).matches()) {
                    return new NBTTagInt(Integer.parseInt(this.jsonValue));
                }

                if (DOUBLE_UNTYPED.matcher(this.jsonValue).matches()) {
                    return new NBTTagDouble(Double.parseDouble(this.jsonValue));
                }

                if (this.jsonValue.equalsIgnoreCase("true") || this.jsonValue.equalsIgnoreCase("false")) {
                    return new NBTTagByte((byte)(Boolean.parseBoolean(this.jsonValue) ? 1 : 0));
                }
            } catch (NumberFormatException numberformatexception1) {
                this.jsonValue = this.jsonValue.replaceAll("\\\\\"", "\"");
                return new NBTTagString(this.jsonValue);
            }

            if (this.jsonValue.startsWith("[") && this.jsonValue.endsWith("]")) {
                String s = this.jsonValue.substring(1, this.jsonValue.length() - 1);
                String[] astring = Iterables.toArray(SPLITTER.split(s), String.class);

                try {
                    int[] aint = new int[astring.length];

                    for (int j = 0; j < astring.length; j++) {
                        aint[j] = Integer.parseInt(astring[j].trim());
                    }

                    return new NBTTagIntArray(aint);
                } catch (NumberFormatException numberformatexception) {
                    return new NBTTagString(this.jsonValue);
                }
            } else {
                if (this.jsonValue.startsWith("\"") && this.jsonValue.endsWith("\"")) {
                    this.jsonValue = this.jsonValue.substring(1, this.jsonValue.length() - 1);
                }

                this.jsonValue = this.jsonValue.replaceAll("\\\\\"", "\"");
                StringBuilder stringbuilder = new StringBuilder();

                for (int i = 0; i < this.jsonValue.length(); i++) {
                    if (i < this.jsonValue.length() - 1 && this.jsonValue.charAt(i) == '\\' && this.jsonValue.charAt(i + 1) == '\\') {
                        stringbuilder.append('\\');
                        i++;
                    } else {
                        stringbuilder.append(this.jsonValue.charAt(i));
                    }
                }

                return new NBTTagString(stringbuilder.toString());
            }
        }
    }
}
