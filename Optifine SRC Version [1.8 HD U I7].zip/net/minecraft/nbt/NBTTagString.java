package net.minecraft.nbt;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class NBTTagString extends NBTBase {
    private String data;

    public NBTTagString() {
        this.data = "";
    }

    public NBTTagString(String var1) {
        this.data = var1;
        if (var1 == null) {
            throw new IllegalArgumentException("Empty string not allowed");
        }
    }

    @Override
    void write(DataOutput var1) throws IOException {
        var1.writeUTF(this.data);
    }

    @Override
    void read(DataInput var1, int var2, NBTSizeTracker var3) throws IOException {
        this.data = var1.readUTF();
        var3.read(16 * this.data.length());
    }

    @Override
    public byte getId() {
        return 8;
    }

    @Override
    public String toString() {
        return "\"" + this.data.replace("\"", "\\\"") + "\"";
    }

    @Override
    public NBTBase copy() {
        return new NBTTagString(this.data);
    }

    @Override
    public boolean hasNoTags() {
        return this.data.isEmpty();
    }

    @Override
    public boolean equals(Object var1) {
        if (!super.equals(var1)) {
            return false;
        }

        NBTTagString nbttagstring = (NBTTagString)var1;
        return this.data == null && nbttagstring.data == null || this.data != null && this.data.equals(nbttagstring.data);
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ this.data.hashCode();
    }

    @Override
    public String getString() {
        return this.data;
    }
}
