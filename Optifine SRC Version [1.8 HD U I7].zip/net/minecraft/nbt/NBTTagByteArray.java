package net.minecraft.nbt;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

public class NBTTagByteArray extends NBTBase {
    private byte[] data;

    NBTTagByteArray() {
    }

    public NBTTagByteArray(byte[] var1) {
        this.data = var1;
    }

    @Override
    void write(DataOutput var1) throws IOException {
        var1.writeInt(this.data.length);
        var1.write(this.data);
    }

    @Override
    void read(DataInput var1, int var2, NBTSizeTracker var3) throws IOException {
        int i = var1.readInt();
        var3.read(8 * i);
        this.data = new byte[i];
        var1.readFully(this.data);
    }

    @Override
    public byte getId() {
        return 7;
    }

    @Override
    public String toString() {
        return "[" + this.data.length + " bytes]";
    }

    @Override
    public NBTBase copy() {
        byte[] abyte = new byte[this.data.length];
        System.arraycopy(this.data, 0, abyte, 0, this.data.length);
        return new NBTTagByteArray(abyte);
    }

    @Override
    public boolean equals(Object var1) {
        return super.equals(var1) ? Arrays.equals(this.data, ((NBTTagByteArray)var1).data) : false;
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ Arrays.hashCode(this.data);
    }

    public byte[] getByteArray() {
        return this.data;
    }
}
