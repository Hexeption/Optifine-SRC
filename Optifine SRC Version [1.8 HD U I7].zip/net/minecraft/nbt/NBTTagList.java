package net.minecraft.nbt;

import com.google.common.collect.Lists;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NBTTagList extends NBTBase {
    private static final Logger LOGGER = LogManager.getLogger();
    private List tagList = Lists.newArrayList();
    private byte tagType = 0;

    @Override
    void write(DataOutput var1) throws IOException {
        if (!this.tagList.isEmpty()) {
            this.tagType = ((NBTBase)this.tagList.get(0)).getId();
        } else {
            this.tagType = 0;
        }

        var1.writeByte(this.tagType);
        var1.writeInt(this.tagList.size());

        for (int i = 0; i < this.tagList.size(); i++) {
            ((NBTBase)this.tagList.get(i)).write(var1);
        }
    }

    @Override
    void read(DataInput var1, int var2, NBTSizeTracker var3) throws IOException {
        if (var2 > 512) {
            throw new RuntimeException("Tried to read NBT tag with too high complexity, depth > 512");
        }

        var3.read(8L);
        this.tagType = var1.readByte();
        int i = var1.readInt();
        this.tagList = Lists.newArrayList();

        for (int j = 0; j < i; j++) {
            NBTBase nbtbase = NBTBase.createNewByType(this.tagType);
            nbtbase.read(var1, var2 + 1, var3);
            this.tagList.add(nbtbase);
        }
    }

    @Override
    public byte getId() {
        return 9;
    }

    @Override
    public String toString() {
        String s = "[";
        int i = 0;

        for (NBTBase nbtbase : (Iterable<NBTBase>) (Iterable) this.tagList) {
            s = s + "" + i + ':' + nbtbase + ',';
            i++;
        }

        return s + "]";
    }

    public void appendTag(NBTBase var1) {
        if (this.tagType == 0) {
            this.tagType = var1.getId();
        } else if (this.tagType != var1.getId()) {
            LOGGER.warn("Adding mismatching tag types to tag list");
            return;
        }

        this.tagList.add(var1);
    }

    public void set(int var1, NBTBase var2) {
        if (var1 >= 0 && var1 < this.tagList.size()) {
            if (this.tagType == 0) {
                this.tagType = var2.getId();
            } else if (this.tagType != var2.getId()) {
                LOGGER.warn("Adding mismatching tag types to tag list");
                return;
            }

            this.tagList.set(var1, var2);
        } else {
            LOGGER.warn("index out of bounds to set tag in tag list");
        }
    }

    public NBTBase removeTag(int var1) {
        return (NBTBase)this.tagList.remove(var1);
    }

    @Override
    public boolean hasNoTags() {
        return this.tagList.isEmpty();
    }

    public NBTTagCompound getCompoundTagAt(int var1) {
        if (var1 >= 0 && var1 < this.tagList.size()) {
            NBTBase nbtbase = (NBTBase)this.tagList.get(var1);
            return nbtbase.getId() == 10 ? (NBTTagCompound)nbtbase : new NBTTagCompound();
        } else {
            return new NBTTagCompound();
        }
    }

    public int[] getIntArrayAt(int var1) {
        if (var1 >= 0 && var1 < this.tagList.size()) {
            NBTBase nbtbase = (NBTBase)this.tagList.get(var1);
            return nbtbase.getId() == 11 ? ((NBTTagIntArray)nbtbase).getIntArray() : new int[0];
        } else {
            return new int[0];
        }
    }

    public double getDoubleAt(int var1) {
        if (var1 >= 0 && var1 < this.tagList.size()) {
            NBTBase nbtbase = (NBTBase)this.tagList.get(var1);
            return nbtbase.getId() == 6 ? ((NBTTagDouble)nbtbase).getDouble() : 0.0;
        } else {
            return 0.0;
        }
    }

    public float getFloatAt(int var1) {
        if (var1 >= 0 && var1 < this.tagList.size()) {
            NBTBase nbtbase = (NBTBase)this.tagList.get(var1);
            return nbtbase.getId() == 5 ? ((NBTTagFloat)nbtbase).getFloat() : 0.0F;
        } else {
            return 0.0F;
        }
    }

    public String getStringTagAt(int var1) {
        if (var1 >= 0 && var1 < this.tagList.size()) {
            NBTBase nbtbase = (NBTBase)this.tagList.get(var1);
            return nbtbase.getId() == 8 ? nbtbase.getString() : nbtbase.toString();
        } else {
            return "";
        }
    }

    public NBTBase get(int var1) {
        return var1 >= 0 && var1 < this.tagList.size() ? (NBTBase)this.tagList.get(var1) : new NBTTagEnd();
    }

    public int tagCount() {
        return this.tagList.size();
    }

    @Override
    public NBTBase copy() {
        NBTTagList nbttaglist = new NBTTagList();
        nbttaglist.tagType = this.tagType;

        for (NBTBase nbtbase : (Iterable<NBTBase>) (Iterable) this.tagList) {
            NBTBase nbtbase1 = nbtbase.copy();
            nbttaglist.tagList.add(nbtbase1);
        }

        return nbttaglist;
    }

    @Override
    public boolean equals(Object var1) {
        if (super.equals(var1)) {
            NBTTagList nbttaglist = (NBTTagList)var1;
            if (this.tagType == nbttaglist.tagType) {
                return this.tagList.equals(nbttaglist.tagList);
            }
        }

        return false;
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ this.tagList.hashCode();
    }

    public int getTagType() {
        return this.tagType;
    }
}
