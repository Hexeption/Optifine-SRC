package net.minecraft.entity.item;

import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.AchievementList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityItem extends Entity {
    private static final Logger logger = LogManager.getLogger();
    private int age;
    private int delayBeforeCanPickup;
    private int health = 5;
    private String thrower;
    private String owner;
    public float hoverStart = (float)(Math.random() * Math.PI * 2.0);

    public EntityItem(World var1, double var2, double var4, double var6) {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.setPosition(var2, var4, var6);
        this.rotationYaw = (float)(Math.random() * 360.0);
        this.motionX = (float)(Math.random() * 0.2F - 0.1F);
        this.motionY = 0.2F;
        this.motionZ = (float)(Math.random() * 0.2F - 0.1F);
    }

    public EntityItem(World var1, double var2, double var4, double var6, ItemStack var8) {
        this(var1, var2, var4, var6);
        this.setEntityItemStack(var8);
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    public EntityItem(World var1) {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.setEntityItemStack(new ItemStack(Blocks.air, 0));
    }

    @Override
    protected void entityInit() {
        this.getDataWatcher().addObjectByDataType(10, 5);
    }

    @Override
    public void onUpdate() {
        if (this.getEntityItem() == null) {
            this.setDead();
        } else {
            super.onUpdate();
            if (this.delayBeforeCanPickup > 0 && this.delayBeforeCanPickup != Short.MAX_VALUE) {
                this.delayBeforeCanPickup--;
            }

            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
            this.motionY -= 0.04F;
            this.noClip = this.pushOutOfBlocks(this.posX, (this.getEntityBoundingBox().minY + this.getEntityBoundingBox().maxY) / 2.0, this.posZ);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            boolean flag = (int)this.prevPosX != (int)this.posX || (int)this.prevPosY != (int)this.posY || (int)this.prevPosZ != (int)this.posZ;
            if (flag || this.ticksExisted % 25 == 0) {
                if (this.worldObj.getBlockState(new BlockPos(this)).getBlock().getMaterial() == Material.lava) {
                    this.motionY = 0.2F;
                    this.motionX = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F;
                    this.motionZ = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F;
                    this.playSound("random.fizz", 0.4F, 2.0F + this.rand.nextFloat() * 0.4F);
                }

                if (!this.worldObj.isRemote) {
                    this.searchForOtherItemsNearby();
                }
            }

            float f = 0.98F;
            if (this.onGround) {
                f = this.worldObj
                        .getBlockState(
                            new BlockPos(
                                MathHelper.floor_double(this.posX),
                                MathHelper.floor_double(this.getEntityBoundingBox().minY) - 1,
                                MathHelper.floor_double(this.posZ)
                            )
                        )
                        .getBlock()
                        .slipperiness
                    * 0.98F;
            }

            this.motionX *= f;
            this.motionY *= 0.98F;
            this.motionZ *= f;
            if (this.onGround) {
                this.motionY *= -0.5;
            }

            if (this.age != Short.MIN_VALUE) {
                this.age++;
            }

            this.handleWaterMovement();
            if (!this.worldObj.isRemote && this.age >= 6000) {
                this.setDead();
            }
        }
    }

    private void searchForOtherItemsNearby() {
        for (EntityItem entityitem : this.worldObj.getEntitiesWithinAABB(EntityItem.class, this.getEntityBoundingBox().expand(0.5, 0.0, 0.5))) {
            this.combineItems(entityitem);
        }
    }

    private boolean combineItems(EntityItem var1) {
        if (var1 == this) {
            return false;
        }

        if (var1.isEntityAlive() && this.isEntityAlive()) {
            ItemStack itemstack = this.getEntityItem();
            ItemStack itemstack1 = var1.getEntityItem();
            if (this.delayBeforeCanPickup == Short.MAX_VALUE || var1.delayBeforeCanPickup == Short.MAX_VALUE) {
                return false;
            }

            if (this.age != Short.MIN_VALUE && var1.age != Short.MIN_VALUE) {
                if (itemstack1.getItem() != itemstack.getItem()) {
                    return false;
                }

                if (itemstack1.hasTagCompound() ^ itemstack.hasTagCompound()) {
                    return false;
                }

                if (itemstack1.hasTagCompound() && !itemstack1.getTagCompound().equals(itemstack.getTagCompound())) {
                    return false;
                }

                if (itemstack1.getItem() == null) {
                    return false;
                }

                if (itemstack1.getItem().getHasSubtypes() && itemstack1.getMetadata() != itemstack.getMetadata()) {
                    return false;
                }

                if (itemstack1.stackSize < itemstack.stackSize) {
                    return var1.combineItems(this);
                }

                if (itemstack1.stackSize + itemstack.stackSize > itemstack1.getMaxStackSize()) {
                    return false;
                }

                itemstack1.stackSize = itemstack1.stackSize + itemstack.stackSize;
                var1.delayBeforeCanPickup = Math.max(var1.delayBeforeCanPickup, this.delayBeforeCanPickup);
                var1.age = Math.min(var1.age, this.age);
                var1.setEntityItemStack(itemstack1);
                this.setDead();
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public void setAgeToCreativeDespawnTime() {
        this.age = 4800;
    }

    @Override
    public boolean handleWaterMovement() {
        if (this.worldObj.handleMaterialAcceleration(this.getEntityBoundingBox(), Material.water, this)) {
            if (!this.inWater && !this.firstUpdate) {
                this.resetHeight();
            }

            this.inWater = true;
        } else {
            this.inWater = false;
        }

        return this.inWater;
    }

    @Override
    protected void dealFireDamage(int var1) {
        this.attackEntityFrom(DamageSource.inFire, var1);
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        if (this.getEntityItem() != null && this.getEntityItem().getItem() == Items.nether_star && var1.isExplosion()) {
            return false;
        }

        this.setBeenAttacked();
        this.health = (int)(this.health - var2);
        if (this.health <= 0) {
            this.setDead();
        }

        return false;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        var1.setShort("Health", (byte)this.health);
        var1.setShort("Age", (short)this.age);
        var1.setShort("PickupDelay", (short)this.delayBeforeCanPickup);
        if (this.getThrower() != null) {
            var1.setString("Thrower", this.thrower);
        }

        if (this.getOwner() != null) {
            var1.setString("Owner", this.owner);
        }

        if (this.getEntityItem() != null) {
            var1.setTag("Item", this.getEntityItem().writeToNBT(new NBTTagCompound()));
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        this.health = var1.getShort("Health") & 255;
        this.age = var1.getShort("Age");
        if (var1.hasKey("PickupDelay")) {
            this.delayBeforeCanPickup = var1.getShort("PickupDelay");
        }

        if (var1.hasKey("Owner")) {
            this.owner = var1.getString("Owner");
        }

        if (var1.hasKey("Thrower")) {
            this.thrower = var1.getString("Thrower");
        }

        NBTTagCompound nbttagcompound = var1.getCompoundTag("Item");
        this.setEntityItemStack(ItemStack.loadItemStackFromNBT(nbttagcompound));
        if (this.getEntityItem() == null) {
            this.setDead();
        }
    }

    @Override
    public void onCollideWithPlayer(EntityPlayer var1) {
        if (!this.worldObj.isRemote) {
            ItemStack itemstack = this.getEntityItem();
            int i = itemstack.stackSize;
            if (this.delayBeforeCanPickup == 0
                && (this.owner == null || 6000 - this.age <= 200 || this.owner.equals(var1.getCommandSenderName()))
                && var1.inventory.addItemStackToInventory(itemstack)) {
                if (itemstack.getItem() == Item.getItemFromBlock(Blocks.log)) {
                    var1.triggerAchievement(AchievementList.mineWood);
                }

                if (itemstack.getItem() == Item.getItemFromBlock(Blocks.log2)) {
                    var1.triggerAchievement(AchievementList.mineWood);
                }

                if (itemstack.getItem() == Items.leather) {
                    var1.triggerAchievement(AchievementList.killCow);
                }

                if (itemstack.getItem() == Items.diamond) {
                    var1.triggerAchievement(AchievementList.diamonds);
                }

                if (itemstack.getItem() == Items.blaze_rod) {
                    var1.triggerAchievement(AchievementList.blazeRod);
                }

                if (itemstack.getItem() == Items.diamond && this.getThrower() != null) {
                    EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(this.getThrower());
                    if (entityplayer != null && entityplayer != var1) {
                        entityplayer.triggerAchievement(AchievementList.diamondsToYou);
                    }
                }

                if (!this.isSilent()) {
                    this.worldObj.playSoundAtEntity(var1, "random.pop", 0.2F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
                }

                var1.onItemPickup(this, i);
                if (itemstack.stackSize <= 0) {
                    this.setDead();
                }
            }
        }
    }

    @Override
    public String getCommandSenderName() {
        return this.hasCustomName() ? this.getCustomNameTag() : StatCollector.translateToLocal("item." + this.getEntityItem().getUnlocalizedName());
    }

    @Override
    public boolean canAttackWithItem() {
        return false;
    }

    @Override
    public void travelToDimension(int var1) {
        super.travelToDimension(var1);
        if (!this.worldObj.isRemote) {
            this.searchForOtherItemsNearby();
        }
    }

    public ItemStack getEntityItem() {
        ItemStack itemstack = this.getDataWatcher().getWatchableObjectItemStack(10);
        if (itemstack == null) {
            if (this.worldObj != null) {
                logger.error("Item entity " + this.getEntityId() + " has no item?!");
            }

            return new ItemStack(Blocks.stone);
        } else {
            return itemstack;
        }
    }

    public void setEntityItemStack(ItemStack var1) {
        this.getDataWatcher().updateObject(10, var1);
        this.getDataWatcher().setObjectWatched(10);
    }

    public String getOwner() {
        return this.owner;
    }

    public void setOwner(String var1) {
        this.owner = var1;
    }

    public String getThrower() {
        return this.thrower;
    }

    public void setThrower(String var1) {
        this.thrower = var1;
    }

    public int getAge() {
        return this.age;
    }

    public void setDefaultPickupDelay() {
        this.delayBeforeCanPickup = 10;
    }

    public void setNoPickupDelay() {
        this.delayBeforeCanPickup = 0;
    }

    public void setInfinitePickupDelay() {
        this.delayBeforeCanPickup = Short.MAX_VALUE;
    }

    public void setPickupDelay(int var1) {
        this.delayBeforeCanPickup = var1;
    }

    public boolean cannotPickup() {
        return this.delayBeforeCanPickup > 0;
    }

    public void setNoDespawn() {
        this.age = -6000;
    }

    public void func_174870_v() {
        this.setInfinitePickupDelay();
        this.age = 5999;
    }
}
