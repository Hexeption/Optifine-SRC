package net.minecraft.entity.item;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAnvil;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityFallingBlock extends Entity {
    private IBlockState fallTile;
    public int fallTime;
    public boolean shouldDropItem = true;
    private boolean canSetAsBlock;
    private boolean hurtEntities;
    private int fallHurtMax = 40;
    private float fallHurtAmount = 2.0F;
    public NBTTagCompound tileEntityData;

    public EntityFallingBlock(World var1) {
        super(var1);
    }

    public EntityFallingBlock(World var1, double var2, double var4, double var6, IBlockState var8) {
        super(var1);
        this.fallTile = var8;
        this.preventEntitySpawning = true;
        this.setSize(0.98F, 0.98F);
        this.setPosition(var2, var4, var6);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.prevPosX = var2;
        this.prevPosY = var4;
        this.prevPosZ = var6;
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public void onUpdate() {
        Block block = this.fallTile.getBlock();
        if (block.getMaterial() == Material.air) {
            this.setDead();
        } else {
            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
            if (this.fallTime++ == 0) {
                BlockPos blockpos = new BlockPos(this);
                if (this.worldObj.getBlockState(blockpos).getBlock() == block) {
                    this.worldObj.setBlockToAir(blockpos);
                } else if (!this.worldObj.isRemote) {
                    this.setDead();
                    return;
                }
            }

            this.motionY -= 0.04F;
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.98F;
            this.motionY *= 0.98F;
            this.motionZ *= 0.98F;
            if (!this.worldObj.isRemote) {
                BlockPos blockpos1 = new BlockPos(this);
                if (this.onGround) {
                    this.motionX *= 0.7F;
                    this.motionZ *= 0.7F;
                    this.motionY *= -0.5;
                    if (this.worldObj.getBlockState(blockpos1).getBlock() != Blocks.piston_extension) {
                        this.setDead();
                        if (!this.canSetAsBlock
                            && this.worldObj.canBlockBePlaced(block, blockpos1, true, EnumFacing.UP, null, null)
                            && !BlockFalling.canFallInto(this.worldObj, blockpos1.down())
                            && this.worldObj.setBlockState(blockpos1, this.fallTile, 3)) {
                            if (block instanceof BlockFalling) {
                                ((BlockFalling)block).onEndFalling(this.worldObj, blockpos1);
                            }

                            if (this.tileEntityData != null && block instanceof ITileEntityProvider) {
                                TileEntity tileentity = this.worldObj.getTileEntity(blockpos1);
                                if (tileentity != null) {
                                    NBTTagCompound nbttagcompound = new NBTTagCompound();
                                    tileentity.writeToNBT(nbttagcompound);

                                    for (String s : (Iterable<String>) (Iterable) this.tileEntityData.getKeySet()) {
                                        NBTBase nbtbase = this.tileEntityData.getTag(s);
                                        if (!s.equals("x") && !s.equals("y") && !s.equals("z")) {
                                            nbttagcompound.setTag(s, nbtbase.copy());
                                        }
                                    }

                                    tileentity.readFromNBT(nbttagcompound);
                                    tileentity.markDirty();
                                }
                            }
                        } else if (this.shouldDropItem && !this.canSetAsBlock && this.worldObj.getGameRules().getGameRuleBooleanValue("doTileDrops")) {
                            this.entityDropItem(new ItemStack(block, 1, block.damageDropped(this.fallTile)), 0.0F);
                        }
                    }
                } else if (this.fallTime > 100 && !this.worldObj.isRemote && (blockpos1.getY() < 1 || blockpos1.getY() > 256) || this.fallTime > 600) {
                    if (this.shouldDropItem && this.worldObj.getGameRules().getGameRuleBooleanValue("doTileDrops")) {
                        this.entityDropItem(new ItemStack(block, 1, block.damageDropped(this.fallTile)), 0.0F);
                    }

                    this.setDead();
                }
            }
        }
    }

    @Override
    public void fall(float var1, float var2) {
        Block block = this.fallTile.getBlock();
        if (this.hurtEntities) {
            int i = MathHelper.ceiling_float_int(var1 - 1.0F);
            if (i > 0) {
                ArrayList arraylist = Lists.newArrayList(this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox()));
                boolean flag = block == Blocks.anvil;
                DamageSource damagesource = flag ? DamageSource.anvil : DamageSource.fallingBlock;

                for (Entity entity : (Iterable<Entity>) (Iterable) arraylist) {
                    entity.attackEntityFrom(damagesource, Math.min(MathHelper.floor_float(i * this.fallHurtAmount), this.fallHurtMax));
                }

                if (flag && this.rand.nextFloat() < 0.05F + i * 0.05) {
                    int j = (Integer)this.fallTile.getValue(BlockAnvil.DAMAGE);
                    if (++j > 2) {
                        this.canSetAsBlock = true;
                    } else {
                        this.fallTile = this.fallTile.withProperty(BlockAnvil.DAMAGE, j);
                    }
                }
            }
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        Block block = this.fallTile != null ? this.fallTile.getBlock() : Blocks.air;
        ResourceLocation resourcelocation = (ResourceLocation)Block.blockRegistry.getNameForObject(block);
        var1.setString("Block", resourcelocation == null ? "" : resourcelocation.toString());
        var1.setByte("Data", (byte)block.getMetaFromState(this.fallTile));
        var1.setByte("Time", (byte)this.fallTime);
        var1.setBoolean("DropItem", this.shouldDropItem);
        var1.setBoolean("HurtEntities", this.hurtEntities);
        var1.setFloat("FallHurtAmount", this.fallHurtAmount);
        var1.setInteger("FallHurtMax", this.fallHurtMax);
        if (this.tileEntityData != null) {
            var1.setTag("TileEntityData", this.tileEntityData);
        }
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        int i = var1.getByte("Data") & 255;
        if (var1.hasKey("Block", 8)) {
            this.fallTile = Block.getBlockFromName(var1.getString("Block")).getStateFromMeta(i);
        } else if (var1.hasKey("TileID", 99)) {
            this.fallTile = Block.getBlockById(var1.getInteger("TileID")).getStateFromMeta(i);
        } else {
            this.fallTile = Block.getBlockById(var1.getByte("Tile") & 255).getStateFromMeta(i);
        }

        this.fallTime = var1.getByte("Time") & 255;
        Block block = this.fallTile.getBlock();
        if (var1.hasKey("HurtEntities", 99)) {
            this.hurtEntities = var1.getBoolean("HurtEntities");
            this.fallHurtAmount = var1.getFloat("FallHurtAmount");
            this.fallHurtMax = var1.getInteger("FallHurtMax");
        } else if (block == Blocks.anvil) {
            this.hurtEntities = true;
        }

        if (var1.hasKey("DropItem", 99)) {
            this.shouldDropItem = var1.getBoolean("DropItem");
        }

        if (var1.hasKey("TileEntityData", 10)) {
            this.tileEntityData = var1.getCompoundTag("TileEntityData");
        }

        if (block == null || block.getMaterial() == Material.air) {
            this.fallTile = Blocks.sand.getDefaultState();
        }
    }

    public World getWorldObj() {
        return this.worldObj;
    }

    public void setHurtEntities(boolean var1) {
        this.hurtEntities = var1;
    }

    @Override
    public boolean canRenderOnFire() {
        return false;
    }

    @Override
    public void addEntityCrashInfo(CrashReportCategory var1) {
        super.addEntityCrashInfo(var1);
        if (this.fallTile != null) {
            Block block = this.fallTile.getBlock();
            var1.addCrashSection("Immitating block ID", Block.getIdFromBlock(block));
            var1.addCrashSection("Immitating block data", block.getMetaFromState(this.fallTile));
        }
    }

    public IBlockState getBlock() {
        return this.fallTile;
    }
}
