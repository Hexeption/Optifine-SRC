package net.minecraft.entity.item;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRailBase;
import net.minecraft.block.BlockRailPowered;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EntityMinecartCommandBlock;
import net.minecraft.entity.ai.EntityMinecartMobSpawner;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.DamageSource;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Vec3;
import net.minecraft.world.IWorldNameable;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public abstract class EntityMinecart extends Entity implements IWorldNameable {
    private boolean isInReverse;
    private String entityName;
    private static final int[][][] matrix = new int[][][]{
        {{0, 0, -1}, {0, 0, 1}},
        {{-1, 0, 0}, {1, 0, 0}},
        {{-1, -1, 0}, {1, 0, 0}},
        {{-1, 0, 0}, {1, -1, 0}},
        {{0, 0, -1}, {0, -1, 1}},
        {{0, -1, -1}, {0, 0, 1}},
        {{0, 0, 1}, {1, 0, 0}},
        {{0, 0, 1}, {-1, 0, 0}},
        {{0, 0, -1}, {-1, 0, 0}},
        {{0, 0, -1}, {1, 0, 0}}
    };
    private int turnProgress;
    private double minecartX;
    private double minecartY;
    private double minecartZ;
    private double minecartYaw;
    private double minecartPitch;
    private double velocityX;
    private double velocityY;
    private double velocityZ;

    public EntityMinecart(World var1) {
        super(var1);
        this.preventEntitySpawning = true;
        this.setSize(0.98F, 0.7F);
    }

    public static EntityMinecart func_180458_a(World var0, double var1, double var3, double var5, EntityMinecart.EnumMinecartType var7) {
        switch (var7) {
            case CHEST:
                return new EntityMinecartChest(var0, var1, var3, var5);
            case FURNACE:
                return new EntityMinecartFurnace(var0, var1, var3, var5);
            case TNT:
                return new EntityMinecartTNT(var0, var1, var3, var5);
            case SPAWNER:
                return new EntityMinecartMobSpawner(var0, var1, var3, var5);
            case HOPPER:
                return new EntityMinecartHopper(var0, var1, var3, var5);
            case COMMAND_BLOCK:
                return new EntityMinecartCommandBlock(var0, var1, var3, var5);
            default:
                return new EntityMinecartEmpty(var0, var1, var3, var5);
        }
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    @Override
    protected void entityInit() {
        this.dataWatcher.addObject(17, new Integer(0));
        this.dataWatcher.addObject(18, new Integer(1));
        this.dataWatcher.addObject(19, new Float(0.0F));
        this.dataWatcher.addObject(20, new Integer(0));
        this.dataWatcher.addObject(21, new Integer(6));
        this.dataWatcher.addObject(22, (byte)0);
    }

    @Override
    public AxisAlignedBB getCollisionBox(Entity var1) {
        return var1.canBePushed() ? var1.getEntityBoundingBox() : null;
    }

    @Override
    public AxisAlignedBB getCollisionBoundingBox() {
        return null;
    }

    @Override
    public boolean canBePushed() {
        return true;
    }

    public EntityMinecart(World var1, double var2, double var4, double var6) {
        this(var1);
        this.setPosition(var2, var4, var6);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.prevPosX = var2;
        this.prevPosY = var4;
        this.prevPosZ = var6;
    }

    @Override
    public double getMountedYOffset() {
        return this.height * 0.5 - 0.2F;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.worldObj.isRemote || this.isDead) {
            return true;
        }

        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        this.setRollingDirection(-this.getRollingDirection());
        this.setRollingAmplitude(10);
        this.setBeenAttacked();
        this.setDamage(this.getDamage() + var2 * 10.0F);
        boolean flag = var1.getEntity() instanceof EntityPlayer && ((EntityPlayer)var1.getEntity()).capabilities.isCreativeMode;
        if (flag || this.getDamage() > 40.0F) {
            if (this.riddenByEntity != null) {
                this.riddenByEntity.mountEntity(null);
            }

            if (flag && !this.hasCustomName()) {
                this.setDead();
            } else {
                this.killMinecart(var1);
            }
        }

        return true;
    }

    public void killMinecart(DamageSource var1) {
        this.setDead();
        ItemStack itemstack = new ItemStack(Items.minecart, 1);
        if (this.entityName != null) {
            itemstack.setStackDisplayName(this.entityName);
        }

        this.entityDropItem(itemstack, 0.0F);
    }

    @Override
    public void performHurtAnimation() {
        this.setRollingDirection(-this.getRollingDirection());
        this.setRollingAmplitude(10);
        this.setDamage(this.getDamage() + this.getDamage() * 10.0F);
    }

    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }

    @Override
    public void setDead() {
        super.setDead();
    }

    @Override
    public void onUpdate() {
        if (this.getRollingAmplitude() > 0) {
            this.setRollingAmplitude(this.getRollingAmplitude() - 1);
        }

        if (this.getDamage() > 0.0F) {
            this.setDamage(this.getDamage() - 1.0F);
        }

        if (this.posY < -64.0) {
            this.kill();
        }

        if (!this.worldObj.isRemote && this.worldObj instanceof WorldServer) {
            this.worldObj.theProfiler.startSection("portal");
            MinecraftServer minecraftserver = ((WorldServer)this.worldObj).getMinecraftServer();
            int i = this.getMaxInPortalTime();
            if (this.inPortal) {
                if (minecraftserver.getAllowNether()) {
                    if (this.ridingEntity == null && this.portalCounter++ >= i) {
                        this.portalCounter = i;
                        this.timeUntilPortal = this.getPortalCooldown();
                        byte b0;
                        if (this.worldObj.provider.getDimensionId() == -1) {
                            b0 = 0;
                        } else {
                            b0 = -1;
                        }

                        this.travelToDimension(b0);
                    }

                    this.inPortal = false;
                }
            } else {
                if (this.portalCounter > 0) {
                    this.portalCounter -= 4;
                }

                if (this.portalCounter < 0) {
                    this.portalCounter = 0;
                }
            }

            if (this.timeUntilPortal > 0) {
                this.timeUntilPortal--;
            }

            this.worldObj.theProfiler.endSection();
        }

        if (this.worldObj.isRemote) {
            if (this.turnProgress > 0) {
                double d4 = this.posX + (this.minecartX - this.posX) / this.turnProgress;
                double d5 = this.posY + (this.minecartY - this.posY) / this.turnProgress;
                double d6 = this.posZ + (this.minecartZ - this.posZ) / this.turnProgress;
                double d1 = MathHelper.wrapAngleTo180_double(this.minecartYaw - this.rotationYaw);
                this.rotationYaw = (float)(this.rotationYaw + d1 / this.turnProgress);
                this.rotationPitch = (float)(this.rotationPitch + (this.minecartPitch - this.rotationPitch) / this.turnProgress);
                this.turnProgress--;
                this.setPosition(d4, d5, d6);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            } else {
                this.setPosition(this.posX, this.posY, this.posZ);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            }
        } else {
            this.prevPosX = this.posX;
            this.prevPosY = this.posY;
            this.prevPosZ = this.posZ;
            this.motionY -= 0.04F;
            int j = MathHelper.floor_double(this.posX);
            int k = MathHelper.floor_double(this.posY);
            int l = MathHelper.floor_double(this.posZ);
            if (BlockRailBase.isRailBlock(this.worldObj, new BlockPos(j, k - 1, l))) {
                k--;
            }

            BlockPos blockpos = new BlockPos(j, k, l);
            IBlockState iblockstate = this.worldObj.getBlockState(blockpos);
            if (BlockRailBase.isRailBlock(iblockstate)) {
                this.func_180460_a(blockpos, iblockstate);
                if (iblockstate.getBlock() == Blocks.activator_rail) {
                    this.onActivatorRailPass(j, k, l, (Boolean)iblockstate.getValue(BlockRailPowered.POWERED));
                }
            } else {
                this.moveDerailedMinecart();
            }

            this.doBlockCollisions();
            this.rotationPitch = 0.0F;
            double d0 = this.prevPosX - this.posX;
            double d2 = this.prevPosZ - this.posZ;
            if (d0 * d0 + d2 * d2 > 0.001) {
                this.rotationYaw = (float)(Math.atan2(d2, d0) * 180.0 / Math.PI);
                if (this.isInReverse) {
                    this.rotationYaw += 180.0F;
                }
            }

            double d3 = MathHelper.wrapAngleTo180_float(this.rotationYaw - this.prevRotationYaw);
            if (d3 < -170.0 || d3 >= 170.0) {
                this.rotationYaw += 180.0F;
                this.isInReverse = !this.isInReverse;
            }

            this.setRotation(this.rotationYaw, this.rotationPitch);

            for (Entity entity : (Iterable<Entity>) (Iterable) this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().expand(0.2F, 0.0, 0.2F))) {
                if (entity != this.riddenByEntity && entity.canBePushed() && entity instanceof EntityMinecart) {
                    entity.applyEntityCollision(this);
                }
            }

            if (this.riddenByEntity != null && this.riddenByEntity.isDead) {
                if (this.riddenByEntity.ridingEntity == this) {
                    this.riddenByEntity.ridingEntity = null;
                }

                this.riddenByEntity = null;
            }

            this.handleWaterMovement();
        }
    }

    protected double getMaximumSpeed() {
        return 0.4;
    }

    public void onActivatorRailPass(int var1, int var2, int var3, boolean var4) {
    }

    protected void moveDerailedMinecart() {
        double d0 = this.getMaximumSpeed();
        this.motionX = MathHelper.clamp_double(this.motionX, -d0, d0);
        this.motionZ = MathHelper.clamp_double(this.motionZ, -d0, d0);
        if (this.onGround) {
            this.motionX *= 0.5;
            this.motionY *= 0.5;
            this.motionZ *= 0.5;
        }

        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        if (!this.onGround) {
            this.motionX *= 0.95F;
            this.motionY *= 0.95F;
            this.motionZ *= 0.95F;
        }
    }

    protected void func_180460_a(BlockPos var1, IBlockState var2) {
        this.fallDistance = 0.0F;
        Vec3 vec3 = this.func_70489_a(this.posX, this.posY, this.posZ);
        this.posY = var1.getY();
        boolean flag = false;
        boolean flag1 = false;
        BlockRailBase blockrailbase = (BlockRailBase)var2.getBlock();
        if (blockrailbase == Blocks.golden_rail) {
            flag = (Boolean)var2.getValue(BlockRailPowered.POWERED);
            flag1 = !flag;
        }

        double d0 = 1.0 / 128.0;
        BlockRailBase.EnumRailDirection blockrailbase$enumraildirection = (BlockRailBase.EnumRailDirection)var2.getValue(blockrailbase.getShapeProperty());
        switch (blockrailbase$enumraildirection) {
            case ASCENDING_EAST:
                this.motionX -= 1.0 / 128.0;
                this.posY++;
                break;
            case ASCENDING_WEST:
                this.motionX += 1.0 / 128.0;
                this.posY++;
                break;
            case ASCENDING_NORTH:
                this.motionZ += 1.0 / 128.0;
                this.posY++;
                break;
            case ASCENDING_SOUTH:
                this.motionZ -= 1.0 / 128.0;
                this.posY++;
        }

        int[][] aint = matrix[blockrailbase$enumraildirection.getMetadata()];
        double d1 = aint[1][0] - aint[0][0];
        double d2 = aint[1][2] - aint[0][2];
        double d3 = Math.sqrt(d1 * d1 + d2 * d2);
        double d4 = this.motionX * d1 + this.motionZ * d2;
        if (d4 < 0.0) {
            d1 = -d1;
            d2 = -d2;
        }

        double d5 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        if (d5 > 2.0) {
            d5 = 2.0;
        }

        this.motionX = d5 * d1 / d3;
        this.motionZ = d5 * d2 / d3;
        if (this.riddenByEntity instanceof EntityLivingBase) {
            double d6 = ((EntityLivingBase)this.riddenByEntity).moveForward;
            if (d6 > 0.0) {
                double d7 = -Math.sin(this.riddenByEntity.rotationYaw * (float)Math.PI / 180.0F);
                double d8 = Math.cos(this.riddenByEntity.rotationYaw * (float)Math.PI / 180.0F);
                double d9 = this.motionX * this.motionX + this.motionZ * this.motionZ;
                if (d9 < 0.01) {
                    this.motionX += d7 * 0.1;
                    this.motionZ += d8 * 0.1;
                    flag1 = false;
                }
            }
        }

        if (flag1) {
            double d17 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (d17 < 0.03) {
                this.motionX *= 0.0;
                this.motionY *= 0.0;
                this.motionZ *= 0.0;
            } else {
                this.motionX *= 0.5;
                this.motionY *= 0.0;
                this.motionZ *= 0.5;
            }
        }

        double d18 = 0.0;
        double d19 = var1.getX() + 0.5 + aint[0][0] * 0.5;
        double d20 = var1.getZ() + 0.5 + aint[0][2] * 0.5;
        double d21 = var1.getX() + 0.5 + aint[1][0] * 0.5;
        double d10 = var1.getZ() + 0.5 + aint[1][2] * 0.5;
        d1 = d21 - d19;
        d2 = d10 - d20;
        if (d1 == 0.0) {
            this.posX = var1.getX() + 0.5;
            d18 = this.posZ - var1.getZ();
        } else if (d2 == 0.0) {
            this.posZ = var1.getZ() + 0.5;
            d18 = this.posX - var1.getX();
        } else {
            double d11 = this.posX - d19;
            double d12 = this.posZ - d20;
            d18 = (d11 * d1 + d12 * d2) * 2.0;
        }

        this.posX = d19 + d1 * d18;
        this.posZ = d20 + d2 * d18;
        this.setPosition(this.posX, this.posY, this.posZ);
        double d22 = this.motionX;
        double d23 = this.motionZ;
        if (this.riddenByEntity != null) {
            d22 *= 0.75;
            d23 *= 0.75;
        }

        double d13 = this.getMaximumSpeed();
        d22 = MathHelper.clamp_double(d22, -d13, d13);
        d23 = MathHelper.clamp_double(d23, -d13, d13);
        this.moveEntity(d22, 0.0, d23);
        if (aint[0][1] != 0 && MathHelper.floor_double(this.posX) - var1.getX() == aint[0][0] && MathHelper.floor_double(this.posZ) - var1.getZ() == aint[0][2]
            )
         {
            this.setPosition(this.posX, this.posY + aint[0][1], this.posZ);
        } else if (aint[1][1] != 0
            && MathHelper.floor_double(this.posX) - var1.getX() == aint[1][0]
            && MathHelper.floor_double(this.posZ) - var1.getZ() == aint[1][2]) {
            this.setPosition(this.posX, this.posY + aint[1][1], this.posZ);
        }

        this.applyDrag();
        Vec3 vec31 = this.func_70489_a(this.posX, this.posY, this.posZ);
        if (vec31 != null && vec3 != null) {
            double d14 = (vec3.yCoord - vec31.yCoord) * 0.05;
            d5 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (d5 > 0.0) {
                this.motionX = this.motionX / d5 * (d5 + d14);
                this.motionZ = this.motionZ / d5 * (d5 + d14);
            }

            this.setPosition(this.posX, vec31.yCoord, this.posZ);
        }

        int j = MathHelper.floor_double(this.posX);
        int i = MathHelper.floor_double(this.posZ);
        if (j != var1.getX() || i != var1.getZ()) {
            d5 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            this.motionX = d5 * (j - var1.getX());
            this.motionZ = d5 * (i - var1.getZ());
        }

        if (flag) {
            double d15 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            if (d15 > 0.01) {
                double d16 = 0.06;
                this.motionX = this.motionX + this.motionX / d15 * d16;
                this.motionZ = this.motionZ + this.motionZ / d15 * d16;
            } else if (blockrailbase$enumraildirection == BlockRailBase.EnumRailDirection.EAST_WEST) {
                if (this.worldObj.getBlockState(var1.west()).getBlock().isNormalCube()) {
                    this.motionX = 0.02;
                } else if (this.worldObj.getBlockState(var1.east()).getBlock().isNormalCube()) {
                    this.motionX = -0.02;
                }
            } else if (blockrailbase$enumraildirection == BlockRailBase.EnumRailDirection.NORTH_SOUTH) {
                if (this.worldObj.getBlockState(var1.north()).getBlock().isNormalCube()) {
                    this.motionZ = 0.02;
                } else if (this.worldObj.getBlockState(var1.south()).getBlock().isNormalCube()) {
                    this.motionZ = -0.02;
                }
            }
        }
    }

    protected void applyDrag() {
        if (this.riddenByEntity != null) {
            this.motionX *= 0.997F;
            this.motionY *= 0.0;
            this.motionZ *= 0.997F;
        } else {
            this.motionX *= 0.96F;
            this.motionY *= 0.0;
            this.motionZ *= 0.96F;
        }
    }

    @Override
    public void setPosition(double var1, double var3, double var5) {
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        float f = this.width / 2.0F;
        float f1 = this.height;
        this.setEntityBoundingBox(new AxisAlignedBB(var1 - f, var3, var5 - f, var1 + f, var3 + f1, var5 + f));
    }

    public Vec3 func_70495_a(double var1, double var3, double var5, double var7) {
        int i = MathHelper.floor_double(var1);
        int j = MathHelper.floor_double(var3);
        int k = MathHelper.floor_double(var5);
        if (BlockRailBase.isRailBlock(this.worldObj, new BlockPos(i, j - 1, k))) {
            j--;
        }

        IBlockState iblockstate = this.worldObj.getBlockState(new BlockPos(i, j, k));
        if (BlockRailBase.isRailBlock(iblockstate)) {
            BlockRailBase.EnumRailDirection blockrailbase$enumraildirection = (BlockRailBase.EnumRailDirection)iblockstate.getValue(
                ((BlockRailBase)iblockstate.getBlock()).getShapeProperty()
            );
            var3 = j;
            if (blockrailbase$enumraildirection.isAscending()) {
                var3 = j + 1;
            }

            int[][] aint = matrix[blockrailbase$enumraildirection.getMetadata()];
            double d0 = aint[1][0] - aint[0][0];
            double d1 = aint[1][2] - aint[0][2];
            double d2 = Math.sqrt(d0 * d0 + d1 * d1);
            d0 /= d2;
            d1 /= d2;
            var1 += d0 * var7;
            var5 += d1 * var7;
            if (aint[0][1] != 0 && MathHelper.floor_double(var1) - i == aint[0][0] && MathHelper.floor_double(var5) - k == aint[0][2]) {
                var3 += aint[0][1];
            } else if (aint[1][1] != 0 && MathHelper.floor_double(var1) - i == aint[1][0] && MathHelper.floor_double(var5) - k == aint[1][2]) {
                var3 += aint[1][1];
            }

            return this.func_70489_a(var1, var3, var5);
        } else {
            return null;
        }
    }

    public Vec3 func_70489_a(double var1, double var3, double var5) {
        int i = MathHelper.floor_double(var1);
        int j = MathHelper.floor_double(var3);
        int k = MathHelper.floor_double(var5);
        if (BlockRailBase.isRailBlock(this.worldObj, new BlockPos(i, j - 1, k))) {
            j--;
        }

        IBlockState iblockstate = this.worldObj.getBlockState(new BlockPos(i, j, k));
        if (BlockRailBase.isRailBlock(iblockstate)) {
            BlockRailBase.EnumRailDirection blockrailbase$enumraildirection = (BlockRailBase.EnumRailDirection)iblockstate.getValue(
                ((BlockRailBase)iblockstate.getBlock()).getShapeProperty()
            );
            int[][] aint = matrix[blockrailbase$enumraildirection.getMetadata()];
            double d0 = 0.0;
            double d1 = i + 0.5 + aint[0][0] * 0.5;
            double d2 = j + 1.0 / 16.0 + aint[0][1] * 0.5;
            double d3 = k + 0.5 + aint[0][2] * 0.5;
            double d4 = i + 0.5 + aint[1][0] * 0.5;
            double d5 = j + 1.0 / 16.0 + aint[1][1] * 0.5;
            double d6 = k + 0.5 + aint[1][2] * 0.5;
            double d7 = d4 - d1;
            double d8 = (d5 - d2) * 2.0;
            double d9 = d6 - d3;
            if (d7 == 0.0) {
                var1 = i + 0.5;
                d0 = var5 - k;
            } else if (d9 == 0.0) {
                var5 = k + 0.5;
                d0 = var1 - i;
            } else {
                double d10 = var1 - d1;
                double d11 = var5 - d3;
                d0 = (d10 * d7 + d11 * d9) * 2.0;
            }

            var1 = d1 + d7 * d0;
            var3 = d2 + d8 * d0;
            var5 = d3 + d9 * d0;
            if (d8 < 0.0) {
                var3++;
            }

            if (d8 > 0.0) {
                var3 += 0.5;
            }

            return new Vec3(var1, var3, var5);
        } else {
            return null;
        }
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        if (var1.getBoolean("CustomDisplayTile")) {
            int i = var1.getInteger("DisplayData");
            if (var1.hasKey("DisplayTile", 8)) {
                Block block = Block.getBlockFromName(var1.getString("DisplayTile"));
                if (block == null) {
                    this.func_174899_a(Blocks.air.getDefaultState());
                } else {
                    this.func_174899_a(block.getStateFromMeta(i));
                }
            } else {
                Block block1 = Block.getBlockById(var1.getInteger("DisplayTile"));
                if (block1 == null) {
                    this.func_174899_a(Blocks.air.getDefaultState());
                } else {
                    this.func_174899_a(block1.getStateFromMeta(i));
                }
            }

            this.setDisplayTileOffset(var1.getInteger("DisplayOffset"));
        }

        if (var1.hasKey("CustomName", 8) && var1.getString("CustomName").length() > 0) {
            this.entityName = var1.getString("CustomName");
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        if (this.hasDisplayTile()) {
            var1.setBoolean("CustomDisplayTile", true);
            IBlockState iblockstate = this.getDisplayTile();
            ResourceLocation resourcelocation = (ResourceLocation)Block.blockRegistry.getNameForObject(iblockstate.getBlock());
            var1.setString("DisplayTile", resourcelocation == null ? "" : resourcelocation.toString());
            var1.setInteger("DisplayData", iblockstate.getBlock().getMetaFromState(iblockstate));
            var1.setInteger("DisplayOffset", this.getDisplayTileOffset());
        }

        if (this.entityName != null && this.entityName.length() > 0) {
            var1.setString("CustomName", this.entityName);
        }
    }

    @Override
    public void applyEntityCollision(Entity var1) {
        if (!this.worldObj.isRemote) {
            if (!var1.noClip && !this.noClip) {
                if (var1 != this.riddenByEntity) {
                    if (var1 instanceof EntityLivingBase
                        && !(var1 instanceof EntityPlayer)
                        && !(var1 instanceof EntityIronGolem)
                        && this.getMinecartType() == EntityMinecart.EnumMinecartType.RIDEABLE
                        && this.motionX * this.motionX + this.motionZ * this.motionZ > 0.01
                        && this.riddenByEntity == null
                        && var1.ridingEntity == null) {
                        var1.mountEntity(this);
                    }

                    double d0 = var1.posX - this.posX;
                    double d1 = var1.posZ - this.posZ;
                    double d2 = d0 * d0 + d1 * d1;
                    if (d2 >= 1.0E-4F) {
                        d2 = MathHelper.sqrt_double(d2);
                        d0 /= d2;
                        d1 /= d2;
                        double d3 = 1.0 / d2;
                        if (d3 > 1.0) {
                            d3 = 1.0;
                        }

                        d0 *= d3;
                        d1 *= d3;
                        d0 *= 0.1F;
                        d1 *= 0.1F;
                        d0 *= 1.0F - this.entityCollisionReduction;
                        d1 *= 1.0F - this.entityCollisionReduction;
                        d0 *= 0.5;
                        d1 *= 0.5;
                        if (var1 instanceof EntityMinecart) {
                            double d4 = var1.posX - this.posX;
                            double d5 = var1.posZ - this.posZ;
                            Vec3 vec3 = new Vec3(d4, 0.0, d5).normalize();
                            Vec3 vec31 = new Vec3(
                                    MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F), 0.0, MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F)
                                )
                                .normalize();
                            double d6 = Math.abs(vec3.dotProduct(vec31));
                            if (d6 < 0.8F) {
                                return;
                            }

                            double d7 = var1.motionX + this.motionX;
                            double d8 = var1.motionZ + this.motionZ;
                            if (((EntityMinecart)var1).getMinecartType() == EntityMinecart.EnumMinecartType.FURNACE
                                && this.getMinecartType() != EntityMinecart.EnumMinecartType.FURNACE) {
                                this.motionX *= 0.2F;
                                this.motionZ *= 0.2F;
                                this.addVelocity(var1.motionX - d0, 0.0, var1.motionZ - d1);
                                var1.motionX *= 0.95F;
                                var1.motionZ *= 0.95F;
                            } else if (((EntityMinecart)var1).getMinecartType() != EntityMinecart.EnumMinecartType.FURNACE
                                && this.getMinecartType() == EntityMinecart.EnumMinecartType.FURNACE) {
                                var1.motionX *= 0.2F;
                                var1.motionZ *= 0.2F;
                                var1.addVelocity(this.motionX + d0, 0.0, this.motionZ + d1);
                                this.motionX *= 0.95F;
                                this.motionZ *= 0.95F;
                            } else {
                                d7 /= 2.0;
                                d8 /= 2.0;
                                this.motionX *= 0.2F;
                                this.motionZ *= 0.2F;
                                this.addVelocity(d7 - d0, 0.0, d8 - d1);
                                var1.motionX *= 0.2F;
                                var1.motionZ *= 0.2F;
                                var1.addVelocity(d7 + d0, 0.0, d8 + d1);
                            }
                        } else {
                            this.addVelocity(-d0, 0.0, -d1);
                            var1.addVelocity(d0 / 4.0, 0.0, d1 / 4.0);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
        this.minecartX = var1;
        this.minecartY = var3;
        this.minecartZ = var5;
        this.minecartYaw = var7;
        this.minecartPitch = var8;
        this.turnProgress = var9 + 2;
        this.motionX = this.velocityX;
        this.motionY = this.velocityY;
        this.motionZ = this.velocityZ;
    }

    @Override
    public void setVelocity(double var1, double var3, double var5) {
        this.velocityX = this.motionX = var1;
        this.velocityY = this.motionY = var3;
        this.velocityZ = this.motionZ = var5;
    }

    public void setDamage(float var1) {
        this.dataWatcher.updateObject(19, var1);
    }

    public float getDamage() {
        return this.dataWatcher.getWatchableObjectFloat(19);
    }

    public void setRollingAmplitude(int var1) {
        this.dataWatcher.updateObject(17, var1);
    }

    public int getRollingAmplitude() {
        return this.dataWatcher.getWatchableObjectInt(17);
    }

    public void setRollingDirection(int var1) {
        this.dataWatcher.updateObject(18, var1);
    }

    public int getRollingDirection() {
        return this.dataWatcher.getWatchableObjectInt(18);
    }

    public abstract EntityMinecart.EnumMinecartType getMinecartType();

    public IBlockState getDisplayTile() {
        return !this.hasDisplayTile() ? this.getDefaultDisplayTile() : Block.getStateById(this.getDataWatcher().getWatchableObjectInt(20));
    }

    public IBlockState getDefaultDisplayTile() {
        return Blocks.air.getDefaultState();
    }

    public int getDisplayTileOffset() {
        return !this.hasDisplayTile() ? this.getDefaultDisplayTileOffset() : this.getDataWatcher().getWatchableObjectInt(21);
    }

    public int getDefaultDisplayTileOffset() {
        return 6;
    }

    public void func_174899_a(IBlockState var1) {
        this.getDataWatcher().updateObject(20, Block.getStateId(var1));
        this.setHasDisplayTile(true);
    }

    public void setDisplayTileOffset(int var1) {
        this.getDataWatcher().updateObject(21, var1);
        this.setHasDisplayTile(true);
    }

    public boolean hasDisplayTile() {
        return this.getDataWatcher().getWatchableObjectByte(22) == 1;
    }

    public void setHasDisplayTile(boolean var1) {
        this.getDataWatcher().updateObject(22, (byte)(var1 ? 1 : 0));
    }

    @Override
    public void setCustomNameTag(String var1) {
        this.entityName = var1;
    }

    @Override
    public String getCommandSenderName() {
        return this.entityName != null ? this.entityName : super.getCommandSenderName();
    }

    @Override
    public boolean hasCustomName() {
        return this.entityName != null;
    }

    @Override
    public String getCustomNameTag() {
        return this.entityName;
    }

    @Override
    public IChatComponent getDisplayName() {
        if (this.hasCustomName()) {
            ChatComponentText chatcomponenttext = new ChatComponentText(this.entityName);
            chatcomponenttext.getChatStyle().setChatHoverEvent(this.getHoverEvent());
            chatcomponenttext.getChatStyle().setInsertion(this.getUniqueID().toString());
            return chatcomponenttext;
        } else {
            ChatComponentTranslation chatcomponenttranslation = new ChatComponentTranslation(this.getCommandSenderName());
            chatcomponenttranslation.getChatStyle().setChatHoverEvent(this.getHoverEvent());
            chatcomponenttranslation.getChatStyle().setInsertion(this.getUniqueID().toString());
            return chatcomponenttranslation;
        }
    }

    public enum EnumMinecartType {
        RIDEABLE(0, "MinecartRideable"),
        CHEST(1, "MinecartChest"),
        FURNACE(2, "MinecartFurnace"),
        TNT(3, "MinecartTNT"),
        SPAWNER(4, "MinecartSpawner"),
        HOPPER(5, "MinecartHopper"),
        COMMAND_BLOCK(6, "MinecartCommandBlock");

        private static final Map ID_LOOKUP = Maps.newHashMap();
        private final int networkID;
        private final String name;

        EnumMinecartType(int var3, String var4) {
            this.networkID = var3;
            this.name = var4;
        }

        public int getNetworkID() {
            return this.networkID;
        }

        public String getName() {
            return this.name;
        }

        public static EntityMinecart.EnumMinecartType byNetworkID(int var0) {
            EntityMinecart.EnumMinecartType entityminecart$enumminecarttype = (EntityMinecart.EnumMinecartType)ID_LOOKUP.get(var0);
            return entityminecart$enumminecarttype == null ? RIDEABLE : entityminecart$enumminecarttype;
        }

        static {
            for (EntityMinecart.EnumMinecartType entityminecart$enumminecarttype : values()) {
                ID_LOOKUP.put(entityminecart$enumminecarttype.getNetworkID(), entityminecart$enumminecarttype);
            }
        }
    }
}
