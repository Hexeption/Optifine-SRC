package net.minecraft.entity.item;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Rotations;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class EntityArmorStand extends EntityLivingBase {
    private static final Rotations DEFAULT_HEAD_ROTATION = new Rotations(0.0F, 0.0F, 0.0F);
    private static final Rotations DEFAULT_BODY_ROTATION = new Rotations(0.0F, 0.0F, 0.0F);
    private static final Rotations DEFAULT_LEFTARM_ROTATION = new Rotations(-10.0F, 0.0F, -10.0F);
    private static final Rotations DEFAULT_RIGHTARM_ROTATION = new Rotations(-15.0F, 0.0F, 10.0F);
    private static final Rotations DEFAULT_LEFTLEG_ROTATION = new Rotations(-1.0F, 0.0F, -1.0F);
    private static final Rotations DEFAULT_RIGHTLEG_ROTATION = new Rotations(1.0F, 0.0F, 1.0F);
    private final ItemStack[] contents = new ItemStack[5];
    private boolean canInteract;
    private long punchCooldown;
    private int disabledSlots;
    private Rotations headRotation = DEFAULT_HEAD_ROTATION;
    private Rotations bodyRotation = DEFAULT_BODY_ROTATION;
    private Rotations leftArmRotation = DEFAULT_LEFTARM_ROTATION;
    private Rotations rightArmRotation = DEFAULT_RIGHTARM_ROTATION;
    private Rotations leftLegRotation = DEFAULT_LEFTLEG_ROTATION;
    private Rotations rightLegRotation = DEFAULT_RIGHTLEG_ROTATION;

    public EntityArmorStand(World var1) {
        super(var1);
        this.setSilent(true);
        this.noClip = this.hasNoGravity();
        this.setSize(0.5F, 1.975F);
    }

    public EntityArmorStand(World var1, double var2, double var4, double var6) {
        this(var1);
        this.setPosition(var2, var4, var6);
    }

    @Override
    public boolean isServerWorld() {
        return super.isServerWorld() && !this.hasNoGravity();
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(10, (byte)0);
        this.dataWatcher.addObject(11, DEFAULT_HEAD_ROTATION);
        this.dataWatcher.addObject(12, DEFAULT_BODY_ROTATION);
        this.dataWatcher.addObject(13, DEFAULT_LEFTARM_ROTATION);
        this.dataWatcher.addObject(14, DEFAULT_RIGHTARM_ROTATION);
        this.dataWatcher.addObject(15, DEFAULT_LEFTLEG_ROTATION);
        this.dataWatcher.addObject(16, DEFAULT_RIGHTLEG_ROTATION);
    }

    @Override
    public ItemStack getHeldItem() {
        return this.contents[0];
    }

    @Override
    public ItemStack getEquipmentInSlot(int var1) {
        return this.contents[var1];
    }

    @Override
    public ItemStack getCurrentArmor(int var1) {
        return this.contents[var1 + 1];
    }

    @Override
    public void setCurrentItemOrArmor(int var1, ItemStack var2) {
        this.contents[var1] = var2;
    }

    @Override
    public ItemStack[] getInventory() {
        return this.contents;
    }

    @Override
    public boolean replaceItemInInventory(int var1, ItemStack var2) {
        int i;
        if (var1 == 99) {
            i = 0;
        } else {
            i = var1 - 100 + 1;
            if (i < 0 || i >= this.contents.length) {
                return false;
            }
        }

        if (var2 != null && EntityLiving.getArmorPosition(var2) != i && (i != 4 || !(var2.getItem() instanceof ItemBlock))) {
            return false;
        }

        this.setCurrentItemOrArmor(i, var2);
        return true;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        NBTTagList nbttaglist = new NBTTagList();

        for (int i = 0; i < this.contents.length; i++) {
            NBTTagCompound nbttagcompound = new NBTTagCompound();
            if (this.contents[i] != null) {
                this.contents[i].writeToNBT(nbttagcompound);
            }

            nbttaglist.appendTag(nbttagcompound);
        }

        var1.setTag("Equipment", nbttaglist);
        if (this.getAlwaysRenderNameTag() && (this.getCustomNameTag() == null || this.getCustomNameTag().length() == 0)) {
            var1.setBoolean("CustomNameVisible", this.getAlwaysRenderNameTag());
        }

        var1.setBoolean("Invisible", this.isInvisible());
        var1.setBoolean("Small", this.isSmall());
        var1.setBoolean("ShowArms", this.getShowArms());
        var1.setInteger("DisabledSlots", this.disabledSlots);
        var1.setBoolean("NoGravity", this.hasNoGravity());
        var1.setBoolean("NoBasePlate", this.hasNoBasePlate());
        var1.setTag("Pose", this.readPoseFromNBT());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        if (var1.hasKey("Equipment", 9)) {
            NBTTagList nbttaglist = var1.getTagList("Equipment", 10);

            for (int i = 0; i < this.contents.length; i++) {
                this.contents[i] = ItemStack.loadItemStackFromNBT(nbttaglist.getCompoundTagAt(i));
            }
        }

        this.setInvisible(var1.getBoolean("Invisible"));
        this.setSmall(var1.getBoolean("Small"));
        this.setShowArms(var1.getBoolean("ShowArms"));
        this.disabledSlots = var1.getInteger("DisabledSlots");
        this.setNoGravity(var1.getBoolean("NoGravity"));
        this.setNoBasePlate(var1.getBoolean("NoBasePlate"));
        this.noClip = this.hasNoGravity();
        NBTTagCompound nbttagcompound = var1.getCompoundTag("Pose");
        this.writePoseToNBT(nbttagcompound);
    }

    private void writePoseToNBT(NBTTagCompound var1) {
        NBTTagList nbttaglist = var1.getTagList("Head", 5);
        if (nbttaglist.tagCount() > 0) {
            this.setHeadRotation(new Rotations(nbttaglist));
        } else {
            this.setHeadRotation(DEFAULT_HEAD_ROTATION);
        }

        NBTTagList nbttaglist1 = var1.getTagList("Body", 5);
        if (nbttaglist1.tagCount() > 0) {
            this.setBodyRotation(new Rotations(nbttaglist1));
        } else {
            this.setBodyRotation(DEFAULT_BODY_ROTATION);
        }

        NBTTagList nbttaglist2 = var1.getTagList("LeftArm", 5);
        if (nbttaglist2.tagCount() > 0) {
            this.setLeftArmRotation(new Rotations(nbttaglist2));
        } else {
            this.setLeftArmRotation(DEFAULT_LEFTARM_ROTATION);
        }

        NBTTagList nbttaglist3 = var1.getTagList("RightArm", 5);
        if (nbttaglist3.tagCount() > 0) {
            this.setRightArmRotation(new Rotations(nbttaglist3));
        } else {
            this.setRightArmRotation(DEFAULT_RIGHTARM_ROTATION);
        }

        NBTTagList nbttaglist4 = var1.getTagList("LeftLeg", 5);
        if (nbttaglist4.tagCount() > 0) {
            this.setLeftLegRotation(new Rotations(nbttaglist4));
        } else {
            this.setLeftLegRotation(DEFAULT_LEFTLEG_ROTATION);
        }

        NBTTagList nbttaglist5 = var1.getTagList("RightLeg", 5);
        if (nbttaglist5.tagCount() > 0) {
            this.setRightLegRotation(new Rotations(nbttaglist5));
        } else {
            this.setRightLegRotation(DEFAULT_RIGHTLEG_ROTATION);
        }
    }

    private NBTTagCompound readPoseFromNBT() {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        if (!DEFAULT_HEAD_ROTATION.equals(this.headRotation)) {
            nbttagcompound.setTag("Head", this.headRotation.writeToNBT());
        }

        if (!DEFAULT_BODY_ROTATION.equals(this.bodyRotation)) {
            nbttagcompound.setTag("Body", this.bodyRotation.writeToNBT());
        }

        if (!DEFAULT_LEFTARM_ROTATION.equals(this.leftArmRotation)) {
            nbttagcompound.setTag("LeftArm", this.leftArmRotation.writeToNBT());
        }

        if (!DEFAULT_RIGHTARM_ROTATION.equals(this.rightArmRotation)) {
            nbttagcompound.setTag("RightArm", this.rightArmRotation.writeToNBT());
        }

        if (!DEFAULT_LEFTLEG_ROTATION.equals(this.leftLegRotation)) {
            nbttagcompound.setTag("LeftLeg", this.leftLegRotation.writeToNBT());
        }

        if (!DEFAULT_RIGHTLEG_ROTATION.equals(this.rightLegRotation)) {
            nbttagcompound.setTag("RightLeg", this.rightLegRotation.writeToNBT());
        }

        return nbttagcompound;
    }

    @Override
    public boolean canBePushed() {
        return false;
    }

    @Override
    protected void collideWithEntity(Entity var1) {
    }

    @Override
    protected void collideWithNearbyEntities() {
        List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox());
        if (list != null && !list.isEmpty()) {
            for (int i = 0; i < list.size(); i++) {
                Entity entity = (Entity)list.get(i);
                if (entity instanceof EntityMinecart
                    && ((EntityMinecart)entity).getMinecartType() == EntityMinecart.EnumMinecartType.RIDEABLE
                    && this.getDistanceSqToEntity(entity) <= 0.2) {
                    entity.applyEntityCollision(this);
                }
            }
        }
    }

    @Override
    public boolean interactAt(EntityPlayer var1, Vec3 var2) {
        if (!this.worldObj.isRemote && !var1.isSpectator()) {
            byte b0 = 0;
            ItemStack itemstack = var1.getCurrentEquippedItem();
            boolean flag = itemstack != null;
            if (flag && itemstack.getItem() instanceof ItemArmor) {
                ItemArmor itemarmor = (ItemArmor)itemstack.getItem();
                if (itemarmor.armorType == 3) {
                    b0 = 1;
                } else if (itemarmor.armorType == 2) {
                    b0 = 2;
                } else if (itemarmor.armorType == 1) {
                    b0 = 3;
                } else if (itemarmor.armorType == 0) {
                    b0 = 4;
                }
            }

            if (flag && (itemstack.getItem() == Items.skull || itemstack.getItem() == Item.getItemFromBlock(Blocks.pumpkin))) {
                b0 = 4;
            }

            double d4 = 0.1;
            double d0 = 0.9;
            double d1 = 0.4;
            double d2 = 1.6;
            byte b1 = 0;
            boolean flag1 = this.isSmall();
            double d3 = flag1 ? var2.yCoord * 2.0 : var2.yCoord;
            if (d3 >= 0.1 && d3 < 0.1 + (flag1 ? 0.8 : 0.45) && this.contents[1] != null) {
                b1 = 1;
            } else if (d3 >= 0.9 + (flag1 ? 0.3 : 0.0) && d3 < 0.9 + (flag1 ? 1.0 : 0.7) && this.contents[3] != null) {
                b1 = 3;
            } else if (d3 >= 0.4 && d3 < 0.4 + (flag1 ? 1.0 : 0.8) && this.contents[2] != null) {
                b1 = 2;
            } else if (d3 >= 1.6 && this.contents[4] != null) {
                b1 = 4;
            }

            boolean flag2 = this.contents[b1] != null;
            if ((this.disabledSlots & 1 << b1) != 0 || (this.disabledSlots & 1 << b0) != 0) {
                b1 = b0;
                if ((this.disabledSlots & 1 << b1) != 0) {
                    if ((this.disabledSlots & 1) != 0) {
                        return true;
                    }

                    b1 = 0;
                }
            }

            if (flag && b0 == 0 && !this.getShowArms()) {
                return true;
            }

            if (flag) {
                this.func_175422_a(var1, b0);
            } else if (flag2) {
                this.func_175422_a(var1, b1);
            }

            return true;
        } else {
            return true;
        }
    }

    private void func_175422_a(EntityPlayer var1, int var2) {
        ItemStack itemstack = this.contents[var2];
        if (itemstack == null || (this.disabledSlots & 1 << var2 + 8) == 0) {
            if (itemstack != null || (this.disabledSlots & 1 << var2 + 16) == 0) {
                int i = var1.inventory.currentItem;
                ItemStack itemstack1 = var1.inventory.getStackInSlot(i);
                if (var1.capabilities.isCreativeMode && (itemstack == null || itemstack.getItem() == Item.getItemFromBlock(Blocks.air)) && itemstack1 != null) {
                    ItemStack itemstack3 = itemstack1.copy();
                    itemstack3.stackSize = 1;
                    this.setCurrentItemOrArmor(var2, itemstack3);
                } else if (itemstack1 == null || itemstack1.stackSize <= 1) {
                    this.setCurrentItemOrArmor(var2, itemstack1);
                    var1.inventory.setInventorySlotContents(i, itemstack);
                } else if (itemstack == null) {
                    ItemStack itemstack2 = itemstack1.copy();
                    itemstack2.stackSize = 1;
                    this.setCurrentItemOrArmor(var2, itemstack2);
                    itemstack1.stackSize--;
                }
            }
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.worldObj.isRemote || this.canInteract) {
            return false;
        }

        if (DamageSource.outOfWorld.equals(var1)) {
            this.setDead();
            return false;
        }

        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        if (var1.isExplosion()) {
            this.dropContents();
            this.setDead();
            return false;
        }

        if (DamageSource.inFire.equals(var1)) {
            if (!this.isBurning()) {
                this.setFire(5);
            } else {
                this.damageArmorStand(0.15F);
            }

            return false;
        } else {
            if (DamageSource.onFire.equals(var1) && this.getHealth() > 0.5F) {
                this.damageArmorStand(4.0F);
                return false;
            }

            boolean flag = "arrow".equals(var1.getDamageType());
            boolean flag1 = "player".equals(var1.getDamageType());
            if (!flag1 && !flag) {
                return false;
            }

            if (var1.getSourceOfDamage() instanceof EntityArrow) {
                var1.getSourceOfDamage().setDead();
            }

            if (var1.getEntity() instanceof EntityPlayer && !((EntityPlayer)var1.getEntity()).capabilities.allowEdit) {
                return false;
            }

            if (var1.isCreativePlayer()) {
                this.playParticles();
                this.setDead();
                return false;
            }

            long i = this.worldObj.getTotalWorldTime();
            if (i - this.punchCooldown > 5L && !flag) {
                this.punchCooldown = i;
            } else {
                this.dropBlock();
                this.playParticles();
                this.setDead();
            }

            return false;
        }
    }

    private void playParticles() {
        if (this.worldObj instanceof WorldServer) {
            ((WorldServer)this.worldObj)
                .spawnParticle(
                    EnumParticleTypes.BLOCK_DUST,
                    this.posX,
                    this.posY + this.height / 1.5,
                    this.posZ,
                    10,
                    this.width / 4.0F,
                    this.height / 4.0F,
                    this.width / 4.0F,
                    0.05,
                    Block.getStateId(Blocks.planks.getDefaultState())
                );
        }
    }

    private void damageArmorStand(float var1) {
        float f = this.getHealth();
        f -= var1;
        if (f <= 0.5F) {
            this.dropContents();
            this.setDead();
        } else {
            this.setHealth(f);
        }
    }

    private void dropBlock() {
        Block.spawnAsEntity(this.worldObj, new BlockPos(this), new ItemStack(Items.armor_stand));
        this.dropContents();
    }

    private void dropContents() {
        for (int i = 0; i < this.contents.length; i++) {
            if (this.contents[i] != null && this.contents[i].stackSize > 0) {
                if (this.contents[i] != null) {
                    Block.spawnAsEntity(this.worldObj, new BlockPos(this).up(), this.contents[i]);
                }

                this.contents[i] = null;
            }
        }
    }

    @Override
    protected float func_110146_f(float var1, float var2) {
        this.prevRenderYawOffset = this.prevRotationYaw;
        this.renderYawOffset = this.rotationYaw;
        return 0.0F;
    }

    @Override
    public float getEyeHeight() {
        return this.isChild() ? this.height * 0.5F : this.height * 0.9F;
    }

    @Override
    public void moveEntityWithHeading(float var1, float var2) {
        if (!this.hasNoGravity()) {
            super.moveEntityWithHeading(var1, var2);
        }
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        Rotations rotations = this.dataWatcher.getWatchableObjectRotations(11);
        if (!this.headRotation.equals(rotations)) {
            this.setHeadRotation(rotations);
        }

        Rotations rotations1 = this.dataWatcher.getWatchableObjectRotations(12);
        if (!this.bodyRotation.equals(rotations1)) {
            this.setBodyRotation(rotations1);
        }

        Rotations rotations2 = this.dataWatcher.getWatchableObjectRotations(13);
        if (!this.leftArmRotation.equals(rotations2)) {
            this.setLeftArmRotation(rotations2);
        }

        Rotations rotations3 = this.dataWatcher.getWatchableObjectRotations(14);
        if (!this.rightArmRotation.equals(rotations3)) {
            this.setRightArmRotation(rotations3);
        }

        Rotations rotations4 = this.dataWatcher.getWatchableObjectRotations(15);
        if (!this.leftLegRotation.equals(rotations4)) {
            this.setLeftLegRotation(rotations4);
        }

        Rotations rotations5 = this.dataWatcher.getWatchableObjectRotations(16);
        if (!this.rightLegRotation.equals(rotations5)) {
            this.setRightLegRotation(rotations5);
        }
    }

    @Override
    protected void updatePotionMetadata() {
        this.setInvisible(this.canInteract);
    }

    @Override
    public void setInvisible(boolean var1) {
        this.canInteract = var1;
        super.setInvisible(var1);
    }

    @Override
    public boolean isChild() {
        return this.isSmall();
    }

    @Override
    public void onKillCommand() {
        this.setDead();
    }

    @Override
    public boolean isImmuneToExplosions() {
        return this.isInvisible();
    }

    private void setSmall(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(10);
        if (var1) {
            b0 = (byte)(b0 | 1);
        } else {
            b0 = (byte)(b0 & -2);
        }

        this.dataWatcher.updateObject(10, b0);
    }

    public boolean isSmall() {
        return (this.dataWatcher.getWatchableObjectByte(10) & 1) != 0;
    }

    private void setNoGravity(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(10);
        if (var1) {
            b0 = (byte)(b0 | 2);
        } else {
            b0 = (byte)(b0 & -3);
        }

        this.dataWatcher.updateObject(10, b0);
    }

    public boolean hasNoGravity() {
        return (this.dataWatcher.getWatchableObjectByte(10) & 2) != 0;
    }

    private void setShowArms(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(10);
        if (var1) {
            b0 = (byte)(b0 | 4);
        } else {
            b0 = (byte)(b0 & -5);
        }

        this.dataWatcher.updateObject(10, b0);
    }

    public boolean getShowArms() {
        return (this.dataWatcher.getWatchableObjectByte(10) & 4) != 0;
    }

    private void setNoBasePlate(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(10);
        if (var1) {
            b0 = (byte)(b0 | 8);
        } else {
            b0 = (byte)(b0 & -9);
        }

        this.dataWatcher.updateObject(10, b0);
    }

    public boolean hasNoBasePlate() {
        return (this.dataWatcher.getWatchableObjectByte(10) & 8) != 0;
    }

    public void setHeadRotation(Rotations var1) {
        this.headRotation = var1;
        this.dataWatcher.updateObject(11, var1);
    }

    public void setBodyRotation(Rotations var1) {
        this.bodyRotation = var1;
        this.dataWatcher.updateObject(12, var1);
    }

    public void setLeftArmRotation(Rotations var1) {
        this.leftArmRotation = var1;
        this.dataWatcher.updateObject(13, var1);
    }

    public void setRightArmRotation(Rotations var1) {
        this.rightArmRotation = var1;
        this.dataWatcher.updateObject(14, var1);
    }

    public void setLeftLegRotation(Rotations var1) {
        this.leftLegRotation = var1;
        this.dataWatcher.updateObject(15, var1);
    }

    public void setRightLegRotation(Rotations var1) {
        this.rightLegRotation = var1;
        this.dataWatcher.updateObject(16, var1);
    }

    public Rotations getHeadRotation() {
        return this.headRotation;
    }

    public Rotations getBodyRotation() {
        return this.bodyRotation;
    }

    public Rotations getLeftArmRotation() {
        return this.leftArmRotation;
    }

    public Rotations getRightArmRotation() {
        return this.rightArmRotation;
    }

    public Rotations getLeftLegRotation() {
        return this.leftLegRotation;
    }

    public Rotations getRightLegRotation() {
        return this.rightLegRotation;
    }
}
