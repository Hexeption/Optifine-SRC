package net.minecraft.entity.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityHanging;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapData;

public class EntityItemFrame extends EntityHanging {
    private float itemDropChance = 1.0F;

    public EntityItemFrame(World var1) {
        super(var1);
    }

    public EntityItemFrame(World var1, BlockPos var2, EnumFacing var3) {
        super(var1, var2);
        this.updateFacingWithBoundingBox(var3);
    }

    @Override
    protected void entityInit() {
        this.getDataWatcher().addObjectByDataType(8, 5);
        this.getDataWatcher().addObject(9, (byte)0);
    }

    @Override
    public float getCollisionBorderSize() {
        return 0.0F;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        if (!var1.isExplosion() && this.getDisplayedItem() != null) {
            if (!this.worldObj.isRemote) {
                this.dropItemOrSelf(var1.getEntity(), false);
                this.setDisplayedItem(null);
            }

            return true;
        } else {
            return super.attackEntityFrom(var1, var2);
        }
    }

    @Override
    public int getWidthPixels() {
        return 12;
    }

    @Override
    public int getHeightPixels() {
        return 12;
    }

    @Override
    public boolean isInRangeToRenderDist(double var1) {
        double d0 = 16.0;
        d0 *= 64.0 * this.renderDistanceWeight;
        return var1 < d0 * d0;
    }

    @Override
    public void onBroken(Entity var1) {
        this.dropItemOrSelf(var1, true);
    }

    public void dropItemOrSelf(Entity var1, boolean var2) {
        if (this.worldObj.getGameRules().getGameRuleBooleanValue("doTileDrops")) {
            ItemStack itemstack = this.getDisplayedItem();
            if (var1 instanceof EntityPlayer) {
                EntityPlayer entityplayer = (EntityPlayer)var1;
                if (entityplayer.capabilities.isCreativeMode) {
                    this.removeFrameFromMap(itemstack);
                    return;
                }
            }

            if (var2) {
                this.entityDropItem(new ItemStack(Items.item_frame), 0.0F);
            }

            if (itemstack != null && this.rand.nextFloat() < this.itemDropChance) {
                itemstack = itemstack.copy();
                this.removeFrameFromMap(itemstack);
                this.entityDropItem(itemstack, 0.0F);
            }
        }
    }

    private void removeFrameFromMap(ItemStack var1) {
        if (var1 != null) {
            if (var1.getItem() == Items.filled_map) {
                MapData mapdata = ((ItemMap)var1.getItem()).getMapData(var1, this.worldObj);
                mapdata.playersVisibleOnMap.remove("frame-" + this.getEntityId());
            }

            var1.setItemFrame(null);
        }
    }

    public ItemStack getDisplayedItem() {
        return this.getDataWatcher().getWatchableObjectItemStack(8);
    }

    public void setDisplayedItem(ItemStack var1) {
        this.setDisplayedItemWithUpdate(var1, true);
    }

    private void setDisplayedItemWithUpdate(ItemStack var1, boolean var2) {
        if (var1 != null) {
            var1 = var1.copy();
            var1.stackSize = 1;
            var1.setItemFrame(this);
        }

        this.getDataWatcher().updateObject(8, var1);
        this.getDataWatcher().setObjectWatched(8);
        if (var2 && this.hangingPosition != null) {
            this.worldObj.updateComparatorOutputLevel(this.hangingPosition, Blocks.air);
        }
    }

    public int getRotation() {
        return this.getDataWatcher().getWatchableObjectByte(9);
    }

    public void setItemRotation(int var1) {
        this.func_174865_a(var1, true);
    }

    private void func_174865_a(int var1, boolean var2) {
        this.getDataWatcher().updateObject(9, (byte)(var1 % 8));
        if (var2 && this.hangingPosition != null) {
            this.worldObj.updateComparatorOutputLevel(this.hangingPosition, Blocks.air);
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        if (this.getDisplayedItem() != null) {
            var1.setTag("Item", this.getDisplayedItem().writeToNBT(new NBTTagCompound()));
            var1.setByte("ItemRotation", (byte)this.getRotation());
            var1.setFloat("ItemDropChance", this.itemDropChance);
        }

        super.writeEntityToNBT(var1);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        NBTTagCompound nbttagcompound = var1.getCompoundTag("Item");
        if (nbttagcompound != null && !nbttagcompound.hasNoTags()) {
            this.setDisplayedItemWithUpdate(ItemStack.loadItemStackFromNBT(nbttagcompound), false);
            this.func_174865_a(var1.getByte("ItemRotation"), false);
            if (var1.hasKey("ItemDropChance", 99)) {
                this.itemDropChance = var1.getFloat("ItemDropChance");
            }

            if (var1.hasKey("Direction")) {
                this.func_174865_a(this.getRotation() * 2, false);
            }
        }

        super.readEntityFromNBT(var1);
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        if (this.getDisplayedItem() == null) {
            ItemStack itemstack = var1.getHeldItem();
            if (itemstack != null && !this.worldObj.isRemote) {
                this.setDisplayedItem(itemstack);
                if (!var1.capabilities.isCreativeMode && --itemstack.stackSize <= 0) {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
                }
            }
        } else if (!this.worldObj.isRemote) {
            this.setItemRotation(this.getRotation() + 1);
        }

        return true;
    }

    public int func_174866_q() {
        return this.getDisplayedItem() == null ? 0 : this.getRotation() % 8 + 1;
    }
}
