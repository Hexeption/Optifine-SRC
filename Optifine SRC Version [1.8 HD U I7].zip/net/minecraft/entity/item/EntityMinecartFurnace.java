package net.minecraft.entity.item;

import net.minecraft.block.BlockFurnace;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityMinecartFurnace extends EntityMinecart {
    private int fuel;
    public double pushX;
    public double pushZ;

    public EntityMinecartFurnace(World var1) {
        super(var1);
    }

    public EntityMinecartFurnace(World var1, double var2, double var4, double var6) {
        super(var1, var2, var4, var6);
    }

    @Override
    public EntityMinecart.EnumMinecartType getMinecartType() {
        return EntityMinecart.EnumMinecartType.FURNACE;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.fuel > 0) {
            this.fuel--;
        }

        if (this.fuel <= 0) {
            this.pushX = this.pushZ = 0.0;
        }

        this.setMinecartPowered(this.fuel > 0);
        if (this.isMinecartPowered() && this.rand.nextInt(4) == 0) {
            this.worldObj.spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX, this.posY + 0.8, this.posZ, 0.0, 0.0, 0.0);
        }
    }

    @Override
    protected double getMaximumSpeed() {
        return 0.2;
    }

    @Override
    public void killMinecart(DamageSource var1) {
        super.killMinecart(var1);
        if (!var1.isExplosion()) {
            this.entityDropItem(new ItemStack(Blocks.furnace, 1), 0.0F);
        }
    }

    @Override
    protected void func_180460_a(BlockPos var1, IBlockState var2) {
        super.func_180460_a(var1, var2);
        double d0 = this.pushX * this.pushX + this.pushZ * this.pushZ;
        if (d0 > 1.0E-4 && this.motionX * this.motionX + this.motionZ * this.motionZ > 0.001) {
            d0 = MathHelper.sqrt_double(d0);
            this.pushX /= d0;
            this.pushZ /= d0;
            if (this.pushX * this.motionX + this.pushZ * this.motionZ < 0.0) {
                this.pushX = 0.0;
                this.pushZ = 0.0;
            } else {
                double d1 = d0 / this.getMaximumSpeed();
                this.pushX *= d1;
                this.pushZ *= d1;
            }
        }
    }

    @Override
    protected void applyDrag() {
        double d0 = this.pushX * this.pushX + this.pushZ * this.pushZ;
        if (d0 > 1.0E-4) {
            d0 = MathHelper.sqrt_double(d0);
            this.pushX /= d0;
            this.pushZ /= d0;
            double d1 = 1.0;
            this.motionX *= 0.8F;
            this.motionY *= 0.0;
            this.motionZ *= 0.8F;
            this.motionX = this.motionX + this.pushX * d1;
            this.motionZ = this.motionZ + this.pushZ * d1;
        } else {
            this.motionX *= 0.98F;
            this.motionY *= 0.0;
            this.motionZ *= 0.98F;
        }

        super.applyDrag();
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        if (itemstack != null && itemstack.getItem() == Items.coal) {
            if (!var1.capabilities.isCreativeMode && --itemstack.stackSize == 0) {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
            }

            this.fuel += 3600;
        }

        this.pushX = this.posX - var1.posX;
        this.pushZ = this.posZ - var1.posZ;
        return true;
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setDouble("PushX", this.pushX);
        var1.setDouble("PushZ", this.pushZ);
        var1.setShort("Fuel", (short)this.fuel);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.pushX = var1.getDouble("PushX");
        this.pushZ = var1.getDouble("PushZ");
        this.fuel = var1.getShort("Fuel");
    }

    protected boolean isMinecartPowered() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
    }

    protected void setMinecartPowered(boolean var1) {
        if (var1) {
            this.dataWatcher.updateObject(16, (byte)(this.dataWatcher.getWatchableObjectByte(16) | 1));
        } else {
            this.dataWatcher.updateObject(16, (byte)(this.dataWatcher.getWatchableObjectByte(16) & -2));
        }
    }

    @Override
    public IBlockState getDefaultDisplayTile() {
        return (this.isMinecartPowered() ? Blocks.lit_furnace : Blocks.furnace).getDefaultState().withProperty(BlockFurnace.FACING, EnumFacing.NORTH);
    }
}
