package net.minecraft.entity.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.LockCode;
import net.minecraft.world.World;

public abstract class EntityMinecartContainer extends EntityMinecart implements ILockableContainer {
    private ItemStack[] minecartContainerItems = new ItemStack[36];
    private boolean dropContentsWhenDead = true;

    public EntityMinecartContainer(World var1) {
        super(var1);
    }

    public EntityMinecartContainer(World var1, double var2, double var4, double var6) {
        super(var1, var2, var4, var6);
    }

    @Override
    public void killMinecart(DamageSource var1) {
        super.killMinecart(var1);
        InventoryHelper.func_180176_a(this.worldObj, this, this);
    }

    @Override
    public ItemStack getStackInSlot(int var1) {
        return this.minecartContainerItems[var1];
    }

    @Override
    public ItemStack decrStackSize(int var1, int var2) {
        if (this.minecartContainerItems[var1] != null) {
            if (this.minecartContainerItems[var1].stackSize <= var2) {
                ItemStack itemstack1 = this.minecartContainerItems[var1];
                this.minecartContainerItems[var1] = null;
                return itemstack1;
            }

            ItemStack itemstack = this.minecartContainerItems[var1].splitStack(var2);
            if (this.minecartContainerItems[var1].stackSize == 0) {
                this.minecartContainerItems[var1] = null;
            }

            return itemstack;
        } else {
            return null;
        }
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int var1) {
        if (this.minecartContainerItems[var1] != null) {
            ItemStack itemstack = this.minecartContainerItems[var1];
            this.minecartContainerItems[var1] = null;
            return itemstack;
        } else {
            return null;
        }
    }

    @Override
    public void setInventorySlotContents(int var1, ItemStack var2) {
        this.minecartContainerItems[var1] = var2;
        if (var2 != null && var2.stackSize > this.getInventoryStackLimit()) {
            var2.stackSize = this.getInventoryStackLimit();
        }
    }

    @Override
    public void markDirty() {
    }

    @Override
    public boolean isUseableByPlayer(EntityPlayer var1) {
        return this.isDead ? false : !(var1.getDistanceSqToEntity(this) > 64.0);
    }

    @Override
    public void openInventory(EntityPlayer var1) {
    }

    @Override
    public void closeInventory(EntityPlayer var1) {
    }

    @Override
    public boolean isItemValidForSlot(int var1, ItemStack var2) {
        return true;
    }

    @Override
    public String getCommandSenderName() {
        return this.hasCustomName() ? this.getCustomNameTag() : "container.minecart";
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    @Override
    public void travelToDimension(int var1) {
        this.dropContentsWhenDead = false;
        super.travelToDimension(var1);
    }

    @Override
    public void setDead() {
        if (this.dropContentsWhenDead) {
            InventoryHelper.func_180176_a(this.worldObj, this, this);
        }

        super.setDead();
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        NBTTagList nbttaglist = new NBTTagList();

        for (int i = 0; i < this.minecartContainerItems.length; i++) {
            if (this.minecartContainerItems[i] != null) {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Slot", (byte)i);
                this.minecartContainerItems[i].writeToNBT(nbttagcompound);
                nbttaglist.appendTag(nbttagcompound);
            }
        }

        var1.setTag("Items", nbttaglist);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        NBTTagList nbttaglist = var1.getTagList("Items", 10);
        this.minecartContainerItems = new ItemStack[this.getSizeInventory()];

        for (int i = 0; i < nbttaglist.tagCount(); i++) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            int j = nbttagcompound.getByte("Slot") & 255;
            if (j >= 0 && j < this.minecartContainerItems.length) {
                this.minecartContainerItems[j] = ItemStack.loadItemStackFromNBT(nbttagcompound);
            }
        }
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        if (!this.worldObj.isRemote) {
            var1.displayGUIChest(this);
        }

        return true;
    }

    @Override
    protected void applyDrag() {
        int i = 15 - Container.calcRedstoneFromInventory(this);
        float f = 0.98F + i * 0.001F;
        this.motionX *= f;
        this.motionY *= 0.0;
        this.motionZ *= f;
    }

    @Override
    public int getField(int var1) {
        return 0;
    }

    @Override
    public void setField(int var1, int var2) {
    }

    @Override
    public int getFieldCount() {
        return 0;
    }

    @Override
    public boolean isLocked() {
        return false;
    }

    @Override
    public void setLockCode(LockCode var1) {
    }

    @Override
    public LockCode getLockCode() {
        return LockCode.EMPTY_CODE;
    }

    @Override
    public void clear() {
        for (int i = 0; i < this.minecartContainerItems.length; i++) {
            this.minecartContainerItems[i] = null;
        }
    }
}
