package net.minecraft.entity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public abstract class EntityAgeable extends EntityCreature {
    protected int growingAge;
    protected int field_175502_b;
    protected int field_175503_c;
    private float ageWidth = -1.0F;
    private float ageHeight;

    public EntityAgeable(World var1) {
        super(var1);
    }

    public abstract EntityAgeable createChild(EntityAgeable var1);

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        if (itemstack != null && itemstack.getItem() == Items.spawn_egg) {
            if (!this.worldObj.isRemote) {
                Class oclass = EntityList.getClassFromID(itemstack.getMetadata());
                if (oclass != null && this.getClass() == oclass) {
                    EntityAgeable entityageable = this.createChild(this);
                    if (entityageable != null) {
                        entityageable.setGrowingAge(-24000);
                        entityageable.setLocationAndAngles(this.posX, this.posY, this.posZ, 0.0F, 0.0F);
                        this.worldObj.spawnEntityInWorld(entityageable);
                        if (itemstack.hasDisplayName()) {
                            entityageable.setCustomNameTag(itemstack.getDisplayName());
                        }

                        if (!var1.capabilities.isCreativeMode) {
                            itemstack.stackSize--;
                            if (itemstack.stackSize <= 0) {
                                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
                            }
                        }
                    }
                }
            }

            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(12, (byte)0);
    }

    public int getGrowingAge() {
        return this.worldObj.isRemote ? this.dataWatcher.getWatchableObjectByte(12) : this.growingAge;
    }

    public void func_175501_a(int var1, boolean var2) {
        int i = this.getGrowingAge();
        int j = i;
        i += var1 * 20;
        if (i > 0) {
            i = 0;
            if (j < 0) {
                this.onGrowingAdult();
            }
        }

        int k = i - j;
        this.setGrowingAge(i);
        if (var2) {
            this.field_175502_b += k;
            if (this.field_175503_c == 0) {
                this.field_175503_c = 40;
            }
        }

        if (this.getGrowingAge() == 0) {
            this.setGrowingAge(this.field_175502_b);
        }
    }

    public void addGrowth(int var1) {
        this.func_175501_a(var1, false);
    }

    public void setGrowingAge(int var1) {
        this.dataWatcher.updateObject(12, (byte)MathHelper.clamp_int(var1, -1, 1));
        this.growingAge = var1;
        this.setScaleForAge(this.isChild());
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setInteger("Age", this.getGrowingAge());
        var1.setInteger("ForcedAge", this.field_175502_b);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.setGrowingAge(var1.getInteger("Age"));
        this.field_175502_b = var1.getInteger("ForcedAge");
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.worldObj.isRemote) {
            if (this.field_175503_c > 0) {
                if (this.field_175503_c % 4 == 0) {
                    this.worldObj
                        .spawnParticle(
                            EnumParticleTypes.VILLAGER_HAPPY,
                            this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                            this.posY + 0.5 + this.rand.nextFloat() * this.height,
                            this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                            0.0,
                            0.0,
                            0.0
                        );
                }

                this.field_175503_c--;
            }

            this.setScaleForAge(this.isChild());
        } else {
            int i = this.getGrowingAge();
            if (i < 0) {
                this.setGrowingAge(++i);
                if (i == 0) {
                    this.onGrowingAdult();
                }
            } else if (i > 0) {
                this.setGrowingAge(--i);
            }
        }
    }

    protected void onGrowingAdult() {
    }

    @Override
    public boolean isChild() {
        return this.getGrowingAge() < 0;
    }

    public void setScaleForAge(boolean var1) {
        this.setScale(var1 ? 0.5F : 1.0F);
    }

    @Override
    protected final void setSize(float var1, float var2) {
        boolean flag = this.ageWidth > 0.0F;
        this.ageWidth = var1;
        this.ageHeight = var2;
        if (!flag) {
            this.setScale(1.0F);
        }
    }

    protected final void setScale(float var1) {
        super.setSize(this.ageWidth * var1, this.ageHeight * var1);
    }
}
