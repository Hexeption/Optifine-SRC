package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityOwnable;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.apache.commons.lang3.StringUtils;

public abstract class EntityAITarget extends EntityAIBase {
    protected final EntityCreature taskOwner;
    protected boolean shouldCheckSight;
    private boolean nearbyOnly;
    private int targetSearchStatus;
    private int targetSearchDelay;
    private int targetUnseenTicks;

    public EntityAITarget(EntityCreature var1, boolean var2) {
        this(var1, var2, false);
    }

    public EntityAITarget(EntityCreature var1, boolean var2, boolean var3) {
        this.taskOwner = var1;
        this.shouldCheckSight = var2;
        this.nearbyOnly = var3;
    }

    @Override
    public boolean continueExecuting() {
        EntityLivingBase entitylivingbase = this.taskOwner.getAttackTarget();
        if (entitylivingbase == null) {
            return false;
        }

        if (!entitylivingbase.isEntityAlive()) {
            return false;
        }

        Team team = this.taskOwner.getTeam();
        Team team1 = entitylivingbase.getTeam();
        if (team != null && team1 == team) {
            return false;
        }

        double d0 = this.getTargetDistance();
        if (this.taskOwner.getDistanceSqToEntity(entitylivingbase) > d0 * d0) {
            return false;
        }

        if (this.shouldCheckSight) {
            if (this.taskOwner.getEntitySenses().canSee(entitylivingbase)) {
                this.targetUnseenTicks = 0;
            } else if (++this.targetUnseenTicks > 60) {
                return false;
            }
        }

        return !(entitylivingbase instanceof EntityPlayer) || !((EntityPlayer)entitylivingbase).capabilities.disableDamage;
    }

    protected double getTargetDistance() {
        IAttributeInstance iattributeinstance = this.taskOwner.getEntityAttribute(SharedMonsterAttributes.followRange);
        return iattributeinstance == null ? 16.0 : iattributeinstance.getAttributeValue();
    }

    @Override
    public void startExecuting() {
        this.targetSearchStatus = 0;
        this.targetSearchDelay = 0;
        this.targetUnseenTicks = 0;
    }

    @Override
    public void resetTask() {
        this.taskOwner.setAttackTarget(null);
    }

    public static boolean isSuitableTarget(EntityLiving var0, EntityLivingBase var1, boolean var2, boolean var3) {
        if (var1 == null) {
            return false;
        }

        if (var1 == var0) {
            return false;
        }

        if (!var1.isEntityAlive()) {
            return false;
        }

        if (!var0.canAttackClass(var1.getClass())) {
            return false;
        }

        Team team = var0.getTeam();
        Team team1 = var1.getTeam();
        if (team != null && team1 == team) {
            return false;
        }

        if (var0 instanceof IEntityOwnable && StringUtils.isNotEmpty(((IEntityOwnable)var0).getOwnerId())) {
            if (var1 instanceof IEntityOwnable && ((IEntityOwnable)var0).getOwnerId().equals(((IEntityOwnable)var1).getOwnerId())) {
                return false;
            }

            if (var1 == ((IEntityOwnable)var0).getOwner()) {
                return false;
            }
        } else if (var1 instanceof EntityPlayer && !var2 && ((EntityPlayer)var1).capabilities.disableDamage) {
            return false;
        }

        return !var3 || var0.getEntitySenses().canSee(var1);
    }

    protected boolean isSuitableTarget(EntityLivingBase var1, boolean var2) {
        if (!isSuitableTarget(this.taskOwner, var1, var2, this.shouldCheckSight)) {
            return false;
        }

        if (!this.taskOwner.isWithinHomeDistanceFromPosition(new BlockPos(var1))) {
            return false;
        }

        if (this.nearbyOnly) {
            if (--this.targetSearchDelay <= 0) {
                this.targetSearchStatus = 0;
            }

            if (this.targetSearchStatus == 0) {
                this.targetSearchStatus = this.canEasilyReach(var1) ? 1 : 2;
            }

            if (this.targetSearchStatus == 2) {
                return false;
            }
        }

        return true;
    }

    private boolean canEasilyReach(EntityLivingBase var1) {
        this.targetSearchDelay = 10 + this.taskOwner.getRNG().nextInt(5);
        PathEntity pathentity = this.taskOwner.getNavigator().getPathToEntityLiving(var1);
        if (pathentity == null) {
            return false;
        }

        PathPoint pathpoint = pathentity.getFinalPathPoint();
        if (pathpoint == null) {
            return false;
        }

        int i = pathpoint.xCoord - MathHelper.floor_double(var1.posX);
        int j = pathpoint.zCoord - MathHelper.floor_double(var1.posZ);
        return i * i + j * j <= 2.25;
    }
}
