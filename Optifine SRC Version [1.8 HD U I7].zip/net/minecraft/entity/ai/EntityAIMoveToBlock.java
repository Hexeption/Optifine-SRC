package net.minecraft.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public abstract class EntityAIMoveToBlock extends EntityAIBase {
    private final EntityCreature theEntity;
    private final double movementSpeed;
    protected int runDelay;
    private int timeoutCounter;
    private int field_179490_f;
    protected BlockPos destinationBlock = BlockPos.ORIGIN;
    private boolean isAboveDestination;
    private int searchLength;

    public EntityAIMoveToBlock(EntityCreature var1, double var2, int var4) {
        this.theEntity = var1;
        this.movementSpeed = var2;
        this.searchLength = var4;
        this.setMutexBits(5);
    }

    @Override
    public boolean shouldExecute() {
        if (this.runDelay > 0) {
            this.runDelay--;
            return false;
        } else {
            this.runDelay = 200 + this.theEntity.getRNG().nextInt(200);
            return this.searchForDestination();
        }
    }

    @Override
    public boolean continueExecuting() {
        return this.timeoutCounter >= -this.field_179490_f && this.timeoutCounter <= 1200 && this.shouldMoveTo(this.theEntity.worldObj, this.destinationBlock);
    }

    @Override
    public void startExecuting() {
        this.theEntity
            .getNavigator()
            .tryMoveToXYZ(this.destinationBlock.getX() + 0.5, this.destinationBlock.getY() + 1, this.destinationBlock.getZ() + 0.5, this.movementSpeed);
        this.timeoutCounter = 0;
        this.field_179490_f = this.theEntity.getRNG().nextInt(this.theEntity.getRNG().nextInt(1200) + 1200) + 1200;
    }

    @Override
    public void resetTask() {
    }

    @Override
    public void updateTask() {
        if (this.theEntity.getDistanceSqToCenter(this.destinationBlock.up()) > 1.0) {
            this.isAboveDestination = false;
            this.timeoutCounter++;
            if (this.timeoutCounter % 40 == 0) {
                this.theEntity
                    .getNavigator()
                    .tryMoveToXYZ(this.destinationBlock.getX() + 0.5, this.destinationBlock.getY() + 1, this.destinationBlock.getZ() + 0.5, this.movementSpeed);
            }
        } else {
            this.isAboveDestination = true;
            this.timeoutCounter--;
        }
    }

    protected boolean getIsAboveDestination() {
        return this.isAboveDestination;
    }

    private boolean searchForDestination() {
        int i = this.searchLength;
        boolean flag = true;
        BlockPos blockpos = new BlockPos(this.theEntity);

        for (byte b0 = 0; b0 <= 1; b0 = (byte)(b0 > 0 ? -b0 : 1 - b0)) {
            for (int j = 0; j < i; j++) {
                for (byte b1 = 0; b1 <= j; b1 = (byte)(b1 > 0 ? -b1 : 1 - b1)) {
                    for (byte b2 = (byte)(b1 < j && b1 > -j ? j : 0); b2 <= j; b2 = (byte)(b2 > 0 ? -b2 : 1 - b2)) {
                        BlockPos blockpos1 = blockpos.add(b1, b0 - 1, b2);
                        if (this.theEntity.isWithinHomeDistanceFromPosition(blockpos1) && this.shouldMoveTo(this.theEntity.worldObj, blockpos1)) {
                            this.destinationBlock = blockpos1;
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    protected abstract boolean shouldMoveTo(World var1, BlockPos var2);
}
