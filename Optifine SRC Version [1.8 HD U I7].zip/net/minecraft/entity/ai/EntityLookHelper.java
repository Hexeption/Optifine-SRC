package net.minecraft.entity.ai;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;

public class EntityLookHelper {
    private EntityLiving entity;
    private float deltaLookYaw;
    private float deltaLookPitch;
    private boolean isLooking;
    private double posX;
    private double posY;
    private double posZ;

    public EntityLookHelper(EntityLiving var1) {
        this.entity = var1;
    }

    public void setLookPositionWithEntity(Entity var1, float var2, float var3) {
        this.posX = var1.posX;
        if (var1 instanceof EntityLivingBase) {
            this.posY = var1.posY + var1.getEyeHeight();
        } else {
            this.posY = (var1.getEntityBoundingBox().minY + var1.getEntityBoundingBox().maxY) / 2.0;
        }

        this.posZ = var1.posZ;
        this.deltaLookYaw = var2;
        this.deltaLookPitch = var3;
        this.isLooking = true;
    }

    public void setLookPosition(double var1, double var3, double var5, float var7, float var8) {
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        this.deltaLookYaw = var7;
        this.deltaLookPitch = var8;
        this.isLooking = true;
    }

    public void onUpdateLook() {
        this.entity.rotationPitch = 0.0F;
        if (this.isLooking) {
            this.isLooking = false;
            double d0 = this.posX - this.entity.posX;
            double d1 = this.posY - (this.entity.posY + this.entity.getEyeHeight());
            double d2 = this.posZ - this.entity.posZ;
            double d3 = MathHelper.sqrt_double(d0 * d0 + d2 * d2);
            float f = (float)(Math.atan2(d2, d0) * 180.0 / (float)Math.PI) - 90.0F;
            float f1 = (float)(-(Math.atan2(d1, d3) * 180.0 / (float)Math.PI));
            this.entity.rotationPitch = this.updateRotation(this.entity.rotationPitch, f1, this.deltaLookPitch);
            this.entity.rotationYawHead = this.updateRotation(this.entity.rotationYawHead, f, this.deltaLookYaw);
        } else {
            this.entity.rotationYawHead = this.updateRotation(this.entity.rotationYawHead, this.entity.renderYawOffset, 10.0F);
        }

        float f2 = MathHelper.wrapAngleTo180_float(this.entity.rotationYawHead - this.entity.renderYawOffset);
        if (!this.entity.getNavigator().noPath()) {
            if (f2 < -75.0F) {
                this.entity.rotationYawHead = this.entity.renderYawOffset - 75.0F;
            }

            if (f2 > 75.0F) {
                this.entity.rotationYawHead = this.entity.renderYawOffset + 75.0F;
            }
        }
    }

    private float updateRotation(float var1, float var2, float var3) {
        float f = MathHelper.wrapAngleTo180_float(var2 - var1);
        if (f > var3) {
            f = var3;
        }

        if (f < -var3) {
            f = -var3;
        }

        return var1 + f;
    }

    public boolean getIsLooking() {
        return this.isLooking;
    }

    public double getLookPosX() {
        return this.posX;
    }

    public double getLookPosY() {
        return this.posY;
    }

    public double getLookPosZ() {
        return this.posZ;
    }
}
