package net.minecraft.entity.ai;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.village.Village;

public class EntityAIDefendVillage extends EntityAITarget {
    EntityIronGolem irongolem;
    EntityLivingBase villageAgressorTarget;

    public EntityAIDefendVillage(EntityIronGolem var1) {
        super(var1, false, true);
        this.irongolem = var1;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        Village village = this.irongolem.getVillage();
        if (village == null) {
            return false;
        }

        this.villageAgressorTarget = village.findNearestVillageAggressor(this.irongolem);
        if (!this.isSuitableTarget(this.villageAgressorTarget, false)) {
            if (this.taskOwner.getRNG().nextInt(20) == 0) {
                this.villageAgressorTarget = village.getNearestTargetPlayer(this.irongolem);
                return this.isSuitableTarget(this.villageAgressorTarget, false);
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    @Override
    public void startExecuting() {
        this.irongolem.setAttackTarget(this.villageAgressorTarget);
        super.startExecuting();
    }
}
