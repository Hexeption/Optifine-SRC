package net.minecraft.entity.ai;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class EntityAINearestAttackableTarget extends EntityAITarget {
    protected final Class targetClass;
    private final int targetChance;
    protected final EntityAINearestAttackableTarget.Sorter theNearestAttackableTargetSorter;
    protected Predicate targetEntitySelector;
    protected EntityLivingBase targetEntity;

    public EntityAINearestAttackableTarget(EntityCreature var1, Class var2, boolean var3) {
        this(var1, var2, var3, false);
    }

    public EntityAINearestAttackableTarget(EntityCreature var1, Class var2, boolean var3, boolean var4) {
        this(var1, var2, 10, var3, var4, null);
    }

    public EntityAINearestAttackableTarget(EntityCreature var1, Class var2, int var3, boolean var4, boolean var5, final Predicate var6) {
        super(var1, var4, var5);
        this.targetClass = var2;
        this.targetChance = var3;
        this.theNearestAttackableTargetSorter = new EntityAINearestAttackableTarget.Sorter(var1);
        this.setMutexBits(1);
        this.targetEntitySelector = new Predicate() {
            public boolean isApplicable(EntityLivingBase var1) {
                if (var6 != null && !var6.apply(var1)) {
                    return false;
                }

                if (var1 instanceof EntityPlayer) {
                    double d0 = EntityAINearestAttackableTarget.this.getTargetDistance();
                    if (var1.isSneaking()) {
                        d0 *= 0.8F;
                    }

                    if (var1.isInvisible()) {
                        float f = ((EntityPlayer)var1).getArmorVisibility();
                        if (f < 0.1F) {
                            f = 0.1F;
                        }

                        d0 *= 0.7F * f;
                    }

                    if (var1.getDistanceToEntity(EntityAINearestAttackableTarget.this.taskOwner) > d0) {
                        return false;
                    }
                }

                return EntityAINearestAttackableTarget.this.isSuitableTarget(var1, false);
            }

            @Override
            public boolean apply(Object var1) {
                return this.isApplicable((EntityLivingBase)var1);
            }
        };
    }

    @Override
    public boolean shouldExecute() {
        if (this.targetChance > 0 && this.taskOwner.getRNG().nextInt(this.targetChance) != 0) {
            return false;
        }

        double d0 = this.getTargetDistance();
        List list = this.taskOwner
            .worldObj
            .getEntitiesWithinAABB(
                this.targetClass,
                this.taskOwner.getEntityBoundingBox().expand(d0, 4.0, d0),
                Predicates.and(this.targetEntitySelector, IEntitySelector.NOT_SPECTATING)
            );
        Collections.sort(list, this.theNearestAttackableTargetSorter);
        if (list.isEmpty()) {
            return false;
        }

        this.targetEntity = (EntityLivingBase)list.get(0);
        return true;
    }

    @Override
    public void startExecuting() {
        this.taskOwner.setAttackTarget(this.targetEntity);
        super.startExecuting();
    }

    public static class Sorter implements Comparator {
        private final Entity theEntity;

        public Sorter(Entity var1) {
            this.theEntity = var1;
        }

        public int compare(Entity var1, Entity var2) {
            double d0 = this.theEntity.getDistanceSqToEntity(var1);
            double d1 = this.theEntity.getDistanceSqToEntity(var2);
            if (d0 < d1) {
                return -1;
            } else {
                return d0 > d1 ? 1 : 0;
            }
        }

        @Override
        public int compare(Object var1, Object var2) {
            return this.compare((Entity)var1, (Entity)var2);
        }
    }
}
