package net.minecraft.entity.ai;

import java.util.Random;
import net.minecraft.entity.EntityCreature;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class RandomPositionGenerator {
    private static Vec3 staticVector = new Vec3(0.0, 0.0, 0.0);

    public static Vec3 findRandomTarget(EntityCreature var0, int var1, int var2) {
        return findRandomTargetBlock(var0, var1, var2, null);
    }

    public static Vec3 findRandomTargetBlockTowards(EntityCreature var0, int var1, int var2, Vec3 var3) {
        staticVector = var3.subtract(var0.posX, var0.posY, var0.posZ);
        return findRandomTargetBlock(var0, var1, var2, staticVector);
    }

    public static Vec3 findRandomTargetBlockAwayFrom(EntityCreature var0, int var1, int var2, Vec3 var3) {
        staticVector = new Vec3(var0.posX, var0.posY, var0.posZ).subtract(var3);
        return findRandomTargetBlock(var0, var1, var2, staticVector);
    }

    private static Vec3 findRandomTargetBlock(EntityCreature var0, int var1, int var2, Vec3 var3) {
        Random random = var0.getRNG();
        boolean flag = false;
        int i = 0;
        int j = 0;
        int k = 0;
        float f = -99999.0F;
        boolean flag1;
        if (var0.hasHome()) {
            double d0 = var0.getHomePosition()
                    .distanceSq(MathHelper.floor_double(var0.posX), MathHelper.floor_double(var0.posY), MathHelper.floor_double(var0.posZ))
                + 4.0;
            double d1 = var0.getMaximumHomeDistance() + var1;
            flag1 = d0 < d1 * d1;
        } else {
            flag1 = false;
        }

        for (int j1 = 0; j1 < 10; j1++) {
            int l = random.nextInt(2 * var1 + 1) - var1;
            int k1 = random.nextInt(2 * var2 + 1) - var2;
            int i1 = random.nextInt(2 * var1 + 1) - var1;
            if (var3 == null || !(l * var3.xCoord + i1 * var3.zCoord < 0.0)) {
                if (var0.hasHome() && var1 > 1) {
                    BlockPos blockpos = var0.getHomePosition();
                    if (var0.posX > blockpos.getX()) {
                        l -= random.nextInt(var1 / 2);
                    } else {
                        l += random.nextInt(var1 / 2);
                    }

                    if (var0.posZ > blockpos.getZ()) {
                        i1 -= random.nextInt(var1 / 2);
                    } else {
                        i1 += random.nextInt(var1 / 2);
                    }
                }

                l += MathHelper.floor_double(var0.posX);
                k1 += MathHelper.floor_double(var0.posY);
                i1 += MathHelper.floor_double(var0.posZ);
                BlockPos blockpos1 = new BlockPos(l, k1, i1);
                if (!flag1 || var0.isWithinHomeDistanceFromPosition(blockpos1)) {
                    float f1 = var0.getBlockPathWeight(blockpos1);
                    if (f1 > f) {
                        f = f1;
                        i = l;
                        j = k1;
                        k = i1;
                        flag = true;
                    }
                }
            }
        }

        return flag ? new Vec3(i, j, k) : null;
    }
}
