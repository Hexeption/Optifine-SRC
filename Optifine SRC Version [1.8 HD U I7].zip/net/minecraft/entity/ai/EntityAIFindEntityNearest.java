package net.minecraft.entity.ai;

import com.google.common.base.Predicate;
import java.util.Collections;
import java.util.List;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayerMP;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityAIFindEntityNearest extends EntityAIBase {
    private static final Logger field_179444_a = LogManager.getLogger();
    private EntityLiving field_179442_b;
    private final Predicate field_179443_c;
    private final EntityAINearestAttackableTarget.Sorter field_179440_d;
    private EntityLivingBase field_179441_e;
    private Class field_179439_f;

    public EntityAIFindEntityNearest(EntityLiving var1, Class var2) {
        this.field_179442_b = var1;
        this.field_179439_f = var2;
        if (var1 instanceof EntityCreature) {
            field_179444_a.warn("Use NearestAttackableTargetGoal.class for PathfinerMob mobs!");
        }

        this.field_179443_c = new Predicate() {
            public boolean func_179876_a(EntityLivingBase var1) {
                double d0 = EntityAIFindEntityNearest.this.func_179438_f();
                if (var1.isSneaking()) {
                    d0 *= 0.8F;
                }

                if (var1.isInvisible()) {
                    return false;
                } else {
                    return var1.getDistanceToEntity(EntityAIFindEntityNearest.this.field_179442_b) > d0
                        ? false
                        : EntityAITarget.isSuitableTarget(EntityAIFindEntityNearest.this.field_179442_b, var1, false, true);
                }
            }

            @Override
            public boolean apply(Object var1) {
                return this.func_179876_a((EntityLivingBase)var1);
            }
        };
        this.field_179440_d = new EntityAINearestAttackableTarget.Sorter(var1);
    }

    @Override
    public boolean shouldExecute() {
        double d0 = this.func_179438_f();
        List list = this.field_179442_b
            .worldObj
            .getEntitiesWithinAABB(this.field_179439_f, this.field_179442_b.getEntityBoundingBox().expand(d0, 4.0, d0), this.field_179443_c);
        Collections.sort(list, this.field_179440_d);
        if (list.isEmpty()) {
            return false;
        }

        this.field_179441_e = (EntityLivingBase)list.get(0);
        return true;
    }

    @Override
    public boolean continueExecuting() {
        EntityLivingBase entitylivingbase = this.field_179442_b.getAttackTarget();
        if (entitylivingbase == null) {
            return false;
        }

        if (!entitylivingbase.isEntityAlive()) {
            return false;
        }

        double d0 = this.func_179438_f();
        return this.field_179442_b.getDistanceSqToEntity(entitylivingbase) > d0 * d0
            ? false
            : !(entitylivingbase instanceof EntityPlayerMP) || !((EntityPlayerMP)entitylivingbase).theItemInWorldManager.isCreative();
    }

    @Override
    public void startExecuting() {
        this.field_179442_b.setAttackTarget(this.field_179441_e);
        super.startExecuting();
    }

    @Override
    public void resetTask() {
        this.field_179442_b.setAttackTarget(null);
        super.startExecuting();
    }

    protected double func_179438_f() {
        IAttributeInstance iattributeinstance = this.field_179442_b.getEntityAttribute(SharedMonsterAttributes.followRange);
        return iattributeinstance == null ? 16.0 : iattributeinstance.getAttributeValue();
    }
}
