package net.minecraft.entity.ai;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityTameable;

public class EntityAIOwnerHurtTarget extends EntityAITarget {
    EntityTameable theEntityTameable;
    EntityLivingBase theTarget;
    private int field_142050_e;

    public EntityAIOwnerHurtTarget(EntityTameable var1) {
        super(var1, false);
        this.theEntityTameable = var1;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute() {
        if (!this.theEntityTameable.isTamed()) {
            return false;
        }

        EntityLivingBase entitylivingbase = this.theEntityTameable.getOwnerEntity();
        if (entitylivingbase == null) {
            return false;
        }

        this.theTarget = entitylivingbase.getLastAttacker();
        int i = entitylivingbase.getLastAttackerTime();
        return i != this.field_142050_e
            && this.isSuitableTarget(this.theTarget, false)
            && this.theEntityTameable.shouldAttackEntity(this.theTarget, entitylivingbase);
    }

    @Override
    public void startExecuting() {
        this.taskOwner.setAttackTarget(this.theTarget);
        EntityLivingBase entitylivingbase = this.theEntityTameable.getOwnerEntity();
        if (entitylivingbase != null) {
            this.field_142050_e = entitylivingbase.getLastAttackerTime();
        }

        super.startExecuting();
    }
}
