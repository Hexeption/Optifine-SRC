package net.minecraft.entity.ai.attributes;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.server.management.LowerStringMap;

public abstract class BaseAttributeMap {
    protected final Map attributes = Maps.newHashMap();
    protected final Map attributesByName = new LowerStringMap();
    protected final Multimap field_180377_c = HashMultimap.create();

    public IAttributeInstance getAttributeInstance(IAttribute var1) {
        return (IAttributeInstance)this.attributes.get(var1);
    }

    public IAttributeInstance getAttributeInstanceByName(String var1) {
        return (IAttributeInstance)this.attributesByName.get(var1);
    }

    public IAttributeInstance registerAttribute(IAttribute var1) {
        if (this.attributesByName.containsKey(var1.getAttributeUnlocalizedName())) {
            throw new IllegalArgumentException("Attribute is already registered!");
        }

        IAttributeInstance iattributeinstance = this.func_180376_c(var1);
        this.attributesByName.put(var1.getAttributeUnlocalizedName(), iattributeinstance);
        this.attributes.put(var1, iattributeinstance);

        for (IAttribute iattribute = var1.func_180372_d(); iattribute != null; iattribute = iattribute.func_180372_d()) {
            this.field_180377_c.put(iattribute, var1);
        }

        return iattributeinstance;
    }

    protected abstract IAttributeInstance func_180376_c(IAttribute var1);

    public Collection getAllAttributes() {
        return this.attributesByName.values();
    }

    public void func_180794_a(IAttributeInstance var1) {
    }

    public void removeAttributeModifiers(Multimap var1) {
        for (Entry entry : (Iterable<Entry>) (Iterable) var1.entries()) {
            IAttributeInstance iattributeinstance = this.getAttributeInstanceByName((String)entry.getKey());
            if (iattributeinstance != null) {
                iattributeinstance.removeModifier((AttributeModifier)entry.getValue());
            }
        }
    }

    public void applyAttributeModifiers(Multimap var1) {
        for (Entry entry : (Iterable<Entry>) (Iterable) var1.entries()) {
            IAttributeInstance iattributeinstance = this.getAttributeInstanceByName((String)entry.getKey());
            if (iattributeinstance != null) {
                iattributeinstance.removeModifier((AttributeModifier)entry.getValue());
                iattributeinstance.applyModifier((AttributeModifier)entry.getValue());
            }
        }
    }
}
