package net.minecraft.entity.ai.attributes;

import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.management.LowerStringMap;

public class ServersideAttributeMap extends BaseAttributeMap {
    private final Set attributeInstanceSet = Sets.newHashSet();
    protected final Map descriptionToAttributeInstanceMap = new LowerStringMap();

    public ModifiableAttributeInstance func_180795_e(IAttribute var1) {
        return (ModifiableAttributeInstance)super.getAttributeInstance(var1);
    }

    public ModifiableAttributeInstance func_180796_b(String var1) {
        IAttributeInstance iattributeinstance = super.getAttributeInstanceByName(var1);
        if (iattributeinstance == null) {
            iattributeinstance = (IAttributeInstance)this.descriptionToAttributeInstanceMap.get(var1);
        }

        return (ModifiableAttributeInstance)iattributeinstance;
    }

    @Override
    public IAttributeInstance registerAttribute(IAttribute var1) {
        IAttributeInstance iattributeinstance = super.registerAttribute(var1);
        if (var1 instanceof RangedAttribute && ((RangedAttribute)var1).getDescription() != null) {
            this.descriptionToAttributeInstanceMap.put(((RangedAttribute)var1).getDescription(), iattributeinstance);
        }

        return iattributeinstance;
    }

    @Override
    protected IAttributeInstance func_180376_c(IAttribute var1) {
        return new ModifiableAttributeInstance(this, var1);
    }

    @Override
    public void func_180794_a(IAttributeInstance var1) {
        if (var1.getAttribute().getShouldWatch()) {
            this.attributeInstanceSet.add(var1);
        }

        for (IAttribute iattribute : (Iterable<IAttribute>) (Iterable) this.field_180377_c.get(var1.getAttribute())) {
            ModifiableAttributeInstance modifiableattributeinstance = this.func_180795_e(iattribute);
            if (modifiableattributeinstance != null) {
                modifiableattributeinstance.flagForUpdate();
            }
        }
    }

    public Set getAttributeInstanceSet() {
        return this.attributeInstanceSet;
    }

    public Collection getWatchedAttributes() {
        HashSet hashset = Sets.newHashSet();

        for (IAttributeInstance iattributeinstance : (Iterable<IAttributeInstance>) (Iterable) this.getAllAttributes()) {
            if (iattributeinstance.getAttribute().getShouldWatch()) {
                hashset.add(iattributeinstance);
            }
        }

        return hashset;
    }

    @Override
    public IAttributeInstance getAttributeInstanceByName(String var1) {
        return this.func_180796_b(var1);
    }

    @Override
    public IAttributeInstance getAttributeInstance(IAttribute var1) {
        return this.func_180795_e(var1);
    }
}
