package net.minecraft.entity.projectile;

import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class EntityPotion extends EntityThrowable {
    private ItemStack potionDamage;

    public EntityPotion(World var1) {
        super(var1);
    }

    public EntityPotion(World var1, EntityLivingBase var2, int var3) {
        this(var1, var2, new ItemStack(Items.potionitem, 1, var3));
    }

    public EntityPotion(World var1, EntityLivingBase var2, ItemStack var3) {
        super(var1, var2);
        this.potionDamage = var3;
    }

    public EntityPotion(World var1, double var2, double var4, double var6, int var8) {
        this(var1, var2, var4, var6, new ItemStack(Items.potionitem, 1, var8));
    }

    public EntityPotion(World var1, double var2, double var4, double var6, ItemStack var8) {
        super(var1, var2, var4, var6);
        this.potionDamage = var8;
    }

    @Override
    protected float getGravityVelocity() {
        return 0.05F;
    }

    @Override
    protected float getVelocity() {
        return 0.5F;
    }

    @Override
    protected float getInaccuracy() {
        return -20.0F;
    }

    public void setPotionDamage(int var1) {
        if (this.potionDamage == null) {
            this.potionDamage = new ItemStack(Items.potionitem, 1, 0);
        }

        this.potionDamage.setItemDamage(var1);
    }

    public int getPotionDamage() {
        if (this.potionDamage == null) {
            this.potionDamage = new ItemStack(Items.potionitem, 1, 0);
        }

        return this.potionDamage.getMetadata();
    }

    @Override
    protected void onImpact(MovingObjectPosition var1) {
        if (!this.worldObj.isRemote) {
            List list = Items.potionitem.getEffects(this.potionDamage);
            if (list != null && !list.isEmpty()) {
                AxisAlignedBB axisalignedbb = this.getEntityBoundingBox().expand(4.0, 2.0, 4.0);
                List list1 = this.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb);
                if (!list1.isEmpty()) {
                    for (EntityLivingBase entitylivingbase : (Iterable<EntityLivingBase>) (Iterable) list1) {
                        double d0 = this.getDistanceSqToEntity(entitylivingbase);
                        if (d0 < 16.0) {
                            double d1 = 1.0 - Math.sqrt(d0) / 4.0;
                            if (entitylivingbase == var1.entityHit) {
                                d1 = 1.0;
                            }

                            for (PotionEffect potioneffect : (Iterable<PotionEffect>) (Iterable) list) {
                                int i = potioneffect.getPotionID();
                                if (Potion.potionTypes[i].isInstant()) {
                                    Potion.potionTypes[i].affectEntity(this, this.getThrower(), entitylivingbase, potioneffect.getAmplifier(), d1);
                                } else {
                                    int j = (int)(d1 * potioneffect.getDuration() + 0.5);
                                    if (j > 20) {
                                        entitylivingbase.addPotionEffect(new PotionEffect(i, j, potioneffect.getAmplifier()));
                                    }
                                }
                            }
                        }
                    }
                }
            }

            this.worldObj.playAuxSFX(2002, new BlockPos(this), this.getPotionDamage());
            this.setDead();
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        if (var1.hasKey("Potion", 10)) {
            this.potionDamage = ItemStack.loadItemStackFromNBT(var1.getCompoundTag("Potion"));
        } else {
            this.setPotionDamage(var1.getInteger("potionValue"));
        }

        if (this.potionDamage == null) {
            this.setDead();
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        if (this.potionDamage != null) {
            var1.setTag("Potion", this.potionDamage.writeToNBT(new NBTTagCompound()));
        }
    }
}
