package net.minecraft.entity.projectile;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class EntityEgg extends EntityThrowable {
    public EntityEgg(World var1) {
        super(var1);
    }

    public EntityEgg(World var1, EntityLivingBase var2) {
        super(var1, var2);
    }

    public EntityEgg(World var1, double var2, double var4, double var6) {
        super(var1, var2, var4, var6);
    }

    @Override
    protected void onImpact(MovingObjectPosition var1) {
        if (var1.entityHit != null) {
            var1.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, this.getThrower()), 0.0F);
        }

        if (!this.worldObj.isRemote && this.rand.nextInt(8) == 0) {
            byte b0 = 1;
            if (this.rand.nextInt(32) == 0) {
                b0 = 4;
            }

            for (int i = 0; i < b0; i++) {
                EntityChicken entitychicken = new EntityChicken(this.worldObj);
                entitychicken.setGrowingAge(-24000);
                entitychicken.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);
                this.worldObj.spawnEntityInWorld(entitychicken);
            }
        }

        double d0 = 0.08;

        for (int j = 0; j < 8; j++) {
            this.worldObj
                .spawnParticle(
                    EnumParticleTypes.ITEM_CRACK,
                    this.posX,
                    this.posY,
                    this.posZ,
                    (this.rand.nextFloat() - 0.5) * 0.08,
                    (this.rand.nextFloat() - 0.5) * 0.08,
                    (this.rand.nextFloat() - 0.5) * 0.08,
                    Item.getIdFromItem(Items.egg)
                );
        }

        if (!this.worldObj.isRemote) {
            this.setDead();
        }
    }
}
