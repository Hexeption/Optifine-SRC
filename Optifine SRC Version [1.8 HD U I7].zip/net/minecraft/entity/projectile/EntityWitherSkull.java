package net.minecraft.entity.projectile;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class EntityWitherSkull extends EntityFireball {
    public EntityWitherSkull(World var1) {
        super(var1);
        this.setSize(5.0F / 16.0F, 5.0F / 16.0F);
    }

    public EntityWitherSkull(World var1, EntityLivingBase var2, double var3, double var5, double var7) {
        super(var1, var2, var3, var5, var7);
        this.setSize(5.0F / 16.0F, 5.0F / 16.0F);
    }

    @Override
    protected float getMotionFactor() {
        return this.isInvulnerable() ? 0.73F : super.getMotionFactor();
    }

    public EntityWitherSkull(World var1, double var2, double var4, double var6, double var8, double var10, double var12) {
        super(var1, var2, var4, var6, var8, var10, var12);
        this.setSize(5.0F / 16.0F, 5.0F / 16.0F);
    }

    @Override
    public boolean isBurning() {
        return false;
    }

    @Override
    public float getExplosionResistance(Explosion var1, World var2, BlockPos var3, IBlockState var4) {
        float f = super.getExplosionResistance(var1, var2, var3, var4);
        if (this.isInvulnerable()
            && var4.getBlock() != Blocks.bedrock
            && var4.getBlock() != Blocks.end_portal
            && var4.getBlock() != Blocks.end_portal_frame
            && var4.getBlock() != Blocks.command_block) {
            f = Math.min(0.8F, f);
        }

        return f;
    }

    @Override
    protected void onImpact(MovingObjectPosition var1) {
        if (!this.worldObj.isRemote) {
            if (var1.entityHit != null) {
                if (this.shootingEntity != null) {
                    if (var1.entityHit.attackEntityFrom(DamageSource.causeMobDamage(this.shootingEntity), 8.0F)) {
                        if (!var1.entityHit.isEntityAlive()) {
                            this.shootingEntity.heal(5.0F);
                        } else {
                            this.applyEnchantments(this.shootingEntity, var1.entityHit);
                        }
                    }
                } else {
                    var1.entityHit.attackEntityFrom(DamageSource.magic, 5.0F);
                }

                if (var1.entityHit instanceof EntityLivingBase) {
                    byte b0 = 0;
                    if (this.worldObj.getDifficulty() == EnumDifficulty.NORMAL) {
                        b0 = 10;
                    } else if (this.worldObj.getDifficulty() == EnumDifficulty.HARD) {
                        b0 = 40;
                    }

                    if (b0 > 0) {
                        ((EntityLivingBase)var1.entityHit).addPotionEffect(new PotionEffect(Potion.wither.id, 20 * b0, 1));
                    }
                }
            }

            this.worldObj.newExplosion(this, this.posX, this.posY, this.posZ, 1.0F, false, this.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing"));
            this.setDead();
        }
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        return false;
    }

    @Override
    protected void entityInit() {
        this.dataWatcher.addObject(10, (byte)0);
    }

    public boolean isInvulnerable() {
        return this.dataWatcher.getWatchableObjectByte(10) == 1;
    }

    public void setInvulnerable(boolean var1) {
        this.dataWatcher.updateObject(10, Byte.valueOf((byte)(var1 ? 1 : 0)));
    }
}
