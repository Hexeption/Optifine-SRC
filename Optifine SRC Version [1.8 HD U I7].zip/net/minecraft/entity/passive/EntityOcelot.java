package net.minecraft.entity.passive;

import com.google.common.base.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAIOcelotAttack;
import net.minecraft.entity.ai.EntityAIOcelotSit;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITargetNonTamed;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.StatCollector;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;

public class EntityOcelot extends EntityTameable {
    private EntityAIAvoidEntity avoidEntity;
    private EntityAITempt aiTempt;

    public EntityOcelot(World var1) {
        super(var1);
        this.setSize(0.6F, 0.7F);
        ((PathNavigateGround)this.getNavigator()).setAvoidsWater(true);
        this.tasks.addTask(1, new EntityAISwimming(this));
        this.tasks.addTask(2, this.aiSit);
        this.tasks.addTask(3, this.aiTempt = new EntityAITempt(this, 0.6, Items.fish, true));
        this.tasks.addTask(5, new EntityAIFollowOwner(this, 1.0, 10.0F, 5.0F));
        this.tasks.addTask(6, new EntityAIOcelotSit(this, 0.8));
        this.tasks.addTask(7, new EntityAILeapAtTarget(this, 0.3F));
        this.tasks.addTask(8, new EntityAIOcelotAttack(this));
        this.tasks.addTask(9, new EntityAIMate(this, 0.8));
        this.tasks.addTask(10, new EntityAIWander(this, 0.8));
        this.tasks.addTask(11, new EntityAIWatchClosest(this, EntityPlayer.class, 10.0F));
        this.targetTasks.addTask(1, new EntityAITargetNonTamed(this, EntityChicken.class, false, null));
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(18, (byte)0);
    }

    @Override
    public void updateAITasks() {
        if (this.getMoveHelper().isUpdating()) {
            double d0 = this.getMoveHelper().getSpeed();
            if (d0 == 0.6) {
                this.setSneaking(true);
                this.setSprinting(false);
            } else if (d0 == 1.33) {
                this.setSneaking(false);
                this.setSprinting(true);
            } else {
                this.setSneaking(false);
                this.setSprinting(false);
            }
        } else {
            this.setSneaking(false);
            this.setSprinting(false);
        }
    }

    @Override
    protected boolean canDespawn() {
        return !this.isTamed() && this.ticksExisted > 2400;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(10.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.3F);
    }

    @Override
    public void fall(float var1, float var2) {
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setInteger("CatType", this.getTameSkin());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.setTameSkin(var1.getInteger("CatType"));
    }

    @Override
    protected String getLivingSound() {
        if (this.isTamed()) {
            if (this.isInLove()) {
                return "mob.cat.purr";
            } else {
                return this.rand.nextInt(4) == 0 ? "mob.cat.purreow" : "mob.cat.meow";
            }
        } else {
            return "";
        }
    }

    @Override
    protected String getHurtSound() {
        return "mob.cat.hitt";
    }

    @Override
    protected String getDeathSound() {
        return "mob.cat.hitt";
    }

    @Override
    protected float getSoundVolume() {
        return 0.4F;
    }

    @Override
    protected Item getDropItem() {
        return Items.leather;
    }

    @Override
    public boolean attackEntityAsMob(Entity var1) {
        return var1.attackEntityFrom(DamageSource.causeMobDamage(this), 3.0F);
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        this.aiSit.setSitting(false);
        return super.attackEntityFrom(var1, var2);
    }

    @Override
    protected void dropFewItems(boolean var1, int var2) {
    }

    @Override
    public boolean interact(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.getCurrentItem();
        if (this.isTamed()) {
            if (this.isOwner(var1) && !this.worldObj.isRemote && !this.isBreedingItem(itemstack)) {
                this.aiSit.setSitting(!this.isSitting());
            }
        } else if (this.aiTempt.isRunning() && itemstack != null && itemstack.getItem() == Items.fish && var1.getDistanceSqToEntity(this) < 9.0) {
            if (!var1.capabilities.isCreativeMode) {
                itemstack.stackSize--;
            }

            if (itemstack.stackSize <= 0) {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, null);
            }

            if (!this.worldObj.isRemote) {
                if (this.rand.nextInt(3) == 0) {
                    this.setTamed(true);
                    this.setTameSkin(1 + this.worldObj.rand.nextInt(3));
                    this.setOwnerId(var1.getUniqueID().toString());
                    this.playTameEffect(true);
                    this.aiSit.setSitting(true);
                    this.worldObj.setEntityState(this, (byte)7);
                } else {
                    this.playTameEffect(false);
                    this.worldObj.setEntityState(this, (byte)6);
                }
            }

            return true;
        }

        return super.interact(var1);
    }

    public EntityOcelot createBabyOcelot(EntityAgeable var1) {
        EntityOcelot entityocelot = new EntityOcelot(this.worldObj);
        if (this.isTamed()) {
            entityocelot.setOwnerId(this.getOwnerId());
            entityocelot.setTamed(true);
            entityocelot.setTameSkin(this.getTameSkin());
        }

        return entityocelot;
    }

    @Override
    public boolean isBreedingItem(ItemStack var1) {
        return var1 != null && var1.getItem() == Items.fish;
    }

    @Override
    public boolean canMateWith(EntityAnimal var1) {
        if (var1 == this) {
            return false;
        }

        if (!this.isTamed()) {
            return false;
        }

        if (!(var1 instanceof EntityOcelot)) {
            return false;
        }

        EntityOcelot entityocelot = (EntityOcelot)var1;
        return !entityocelot.isTamed() ? false : this.isInLove() && entityocelot.isInLove();
    }

    public int getTameSkin() {
        return this.dataWatcher.getWatchableObjectByte(18);
    }

    public void setTameSkin(int var1) {
        this.dataWatcher.updateObject(18, (byte)var1);
    }

    @Override
    public boolean getCanSpawnHere() {
        return this.worldObj.rand.nextInt(3) != 0;
    }

    @Override
    public boolean isNotColliding() {
        if (this.worldObj.checkNoEntityCollision(this.getEntityBoundingBox(), this)
            && this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox()).isEmpty()
            && !this.worldObj.isAnyLiquid(this.getEntityBoundingBox())) {
            BlockPos blockpos = new BlockPos(this.posX, this.getEntityBoundingBox().minY, this.posZ);
            if (blockpos.getY() < 63) {
                return false;
            }

            Block block = this.worldObj.getBlockState(blockpos.down()).getBlock();
            if (block == Blocks.grass || block.getMaterial() == Material.leaves) {
                return true;
            }
        }

        return false;
    }

    @Override
    public String getCommandSenderName() {
        if (this.hasCustomName()) {
            return this.getCustomNameTag();
        } else {
            return this.isTamed() ? StatCollector.translateToLocal("entity.Cat.name") : super.getCommandSenderName();
        }
    }

    @Override
    public void setTamed(boolean var1) {
        super.setTamed(var1);
    }

    @Override
    protected void setupTamedAI() {
        if (this.avoidEntity == null) {
            this.avoidEntity = new EntityAIAvoidEntity(this, new Predicate() {
                public boolean func_179874_a(Entity var1) {
                    return var1 instanceof EntityPlayer;
                }

                @Override
                public boolean apply(Object var1) {
                    return this.func_179874_a((Entity)var1);
                }
            }, 16.0F, 0.8, 1.33);
        }

        this.tasks.removeTask(this.avoidEntity);
        if (!this.isTamed()) {
            this.tasks.addTask(4, this.avoidEntity);
        }
    }

    @Override
    public IEntityLivingData onInitialSpawn(DifficultyInstance var1, IEntityLivingData var2) {
        var2 = super.onInitialSpawn(var1, var2);
        if (this.worldObj.rand.nextInt(7) == 0) {
            for (int i = 0; i < 2; i++) {
                EntityOcelot entityocelot = new EntityOcelot(this.worldObj);
                entityocelot.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);
                entityocelot.setGrowingAge(-24000);
                this.worldObj.spawnEntityInWorld(entityocelot);
            }
        }

        return var2;
    }

    @Override
    public EntityAgeable createChild(EntityAgeable var1) {
        return this.createBabyOcelot(var1);
    }
}
