package net.minecraft.entity.passive;

import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityOwnable;
import net.minecraft.entity.ai.EntityAISit;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.management.PreYggdrasilConverter;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public abstract class EntityTameable extends EntityAnimal implements IEntityOwnable {
    protected EntityAISit aiSit = new EntityAISit(this);

    public EntityTameable(World var1) {
        super(var1);
        this.setupTamedAI();
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, (byte)0);
        this.dataWatcher.addObject(17, "");
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        if (this.getOwnerId() == null) {
            var1.setString("OwnerUUID", "");
        } else {
            var1.setString("OwnerUUID", this.getOwnerId());
        }

        var1.setBoolean("Sitting", this.isSitting());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        String s = "";
        if (var1.hasKey("OwnerUUID", 8)) {
            s = var1.getString("OwnerUUID");
        } else {
            String s1 = var1.getString("Owner");
            s = PreYggdrasilConverter.getStringUUIDFromName(s1);
        }

        if (s.length() > 0) {
            this.setOwnerId(s);
            this.setTamed(true);
        }

        this.aiSit.setSitting(var1.getBoolean("Sitting"));
        this.setSitting(var1.getBoolean("Sitting"));
    }

    protected void playTameEffect(boolean var1) {
        EnumParticleTypes enumparticletypes = EnumParticleTypes.HEART;
        if (!var1) {
            enumparticletypes = EnumParticleTypes.SMOKE_NORMAL;
        }

        for (int i = 0; i < 7; i++) {
            double d0 = this.rand.nextGaussian() * 0.02;
            double d1 = this.rand.nextGaussian() * 0.02;
            double d2 = this.rand.nextGaussian() * 0.02;
            this.worldObj
                .spawnParticle(
                    enumparticletypes,
                    this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    this.posY + 0.5 + this.rand.nextFloat() * this.height,
                    this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width,
                    d0,
                    d1,
                    d2
                );
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 7) {
            this.playTameEffect(true);
        } else if (var1 == 6) {
            this.playTameEffect(false);
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    public boolean isTamed() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 4) != 0;
    }

    public void setTamed(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var1) {
            this.dataWatcher.updateObject(16, (byte)(b0 | 4));
        } else {
            this.dataWatcher.updateObject(16, (byte)(b0 & -5));
        }

        this.setupTamedAI();
    }

    protected void setupTamedAI() {
    }

    public boolean isSitting() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
    }

    public void setSitting(boolean var1) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(16);
        if (var1) {
            this.dataWatcher.updateObject(16, (byte)(b0 | 1));
        } else {
            this.dataWatcher.updateObject(16, (byte)(b0 & -2));
        }
    }

    @Override
    public String getOwnerId() {
        return this.dataWatcher.getWatchableObjectString(17);
    }

    public void setOwnerId(String var1) {
        this.dataWatcher.updateObject(17, var1);
    }

    public EntityLivingBase getOwnerEntity() {
        try {
            UUID uuid = UUID.fromString(this.getOwnerId());
            return uuid == null ? null : this.worldObj.getPlayerEntityByUUID(uuid);
        } catch (IllegalArgumentException illegalargumentexception) {
            return null;
        }
    }

    public boolean isOwner(EntityLivingBase var1) {
        return var1 == this.getOwnerEntity();
    }

    public EntityAISit getAISit() {
        return this.aiSit;
    }

    public boolean shouldAttackEntity(EntityLivingBase var1, EntityLivingBase var2) {
        return true;
    }

    @Override
    public Team getTeam() {
        if (this.isTamed()) {
            EntityLivingBase entitylivingbase = this.getOwnerEntity();
            if (entitylivingbase != null) {
                return entitylivingbase.getTeam();
            }
        }

        return super.getTeam();
    }

    @Override
    public boolean isOnSameTeam(EntityLivingBase var1) {
        if (this.isTamed()) {
            EntityLivingBase entitylivingbase = this.getOwnerEntity();
            if (var1 == entitylivingbase) {
                return true;
            }

            if (entitylivingbase != null) {
                return entitylivingbase.isOnSameTeam(var1);
            }
        }

        return super.isOnSameTeam(var1);
    }

    @Override
    public void onDeath(DamageSource var1) {
        if (!this.worldObj.isRemote
            && this.worldObj.getGameRules().getGameRuleBooleanValue("showDeathMessages")
            && this.hasCustomName()
            && this.getOwnerEntity() instanceof EntityPlayerMP) {
            ((EntityPlayerMP)this.getOwnerEntity()).addChatMessage(this.getCombatTracker().getDeathMessage());
        }

        super.onDeath(var1);
    }

    @Override
    public Entity getOwner() {
        return this.getOwnerEntity();
    }
}
