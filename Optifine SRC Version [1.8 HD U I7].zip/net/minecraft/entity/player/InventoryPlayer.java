package net.minecraft.entity.player;

import java.util.concurrent.Callable;
import net.minecraft.block.Block;
import net.minecraft.command.server.CommandTestForBlock;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ReportedException;

public class InventoryPlayer implements IInventory {
    public ItemStack[] mainInventory = new ItemStack[36];
    public ItemStack[] armorInventory = new ItemStack[4];
    public int currentItem;
    public EntityPlayer player;
    private ItemStack itemStack;
    public boolean inventoryChanged;

    public InventoryPlayer(EntityPlayer var1) {
        this.player = var1;
    }

    public ItemStack getCurrentItem() {
        return this.currentItem < 9 && this.currentItem >= 0 ? this.mainInventory[this.currentItem] : null;
    }

    public static int getHotbarSize() {
        return 9;
    }

    private int getInventorySlotContainItem(Item var1) {
        for (int i = 0; i < this.mainInventory.length; i++) {
            if (this.mainInventory[i] != null && this.mainInventory[i].getItem() == var1) {
                return i;
            }
        }

        return -1;
    }

    private int getInventorySlotContainItemAndDamage(Item var1, int var2) {
        for (int i = 0; i < this.mainInventory.length; i++) {
            if (this.mainInventory[i] != null && this.mainInventory[i].getItem() == var1 && this.mainInventory[i].getMetadata() == var2) {
                return i;
            }
        }

        return -1;
    }

    private int storeItemStack(ItemStack var1) {
        for (int i = 0; i < this.mainInventory.length; i++) {
            if (this.mainInventory[i] != null
                && this.mainInventory[i].getItem() == var1.getItem()
                && this.mainInventory[i].isStackable()
                && this.mainInventory[i].stackSize < this.mainInventory[i].getMaxStackSize()
                && this.mainInventory[i].stackSize < this.getInventoryStackLimit()
                && (!this.mainInventory[i].getHasSubtypes() || this.mainInventory[i].getMetadata() == var1.getMetadata())
                && ItemStack.areItemStackTagsEqual(this.mainInventory[i], var1)) {
                return i;
            }
        }

        return -1;
    }

    public int getFirstEmptyStack() {
        for (int i = 0; i < this.mainInventory.length; i++) {
            if (this.mainInventory[i] == null) {
                return i;
            }
        }

        return -1;
    }

    public void setCurrentItem(Item var1, int var2, boolean var3, boolean var4) {
        ItemStack itemstack = this.getCurrentItem();
        int i = var3 ? this.getInventorySlotContainItemAndDamage(var1, var2) : this.getInventorySlotContainItem(var1);
        if (i >= 0 && i < 9) {
            this.currentItem = i;
        } else if (var4 && var1 != null) {
            int j = this.getFirstEmptyStack();
            if (j >= 0 && j < 9) {
                this.currentItem = j;
            }

            if (itemstack == null
                || !itemstack.isItemEnchantable()
                || this.getInventorySlotContainItemAndDamage(itemstack.getItem(), itemstack.getItemDamage()) != this.currentItem) {
                int k = this.getInventorySlotContainItemAndDamage(var1, var2);
                int l;
                if (k >= 0) {
                    l = this.mainInventory[k].stackSize;
                    this.mainInventory[k] = this.mainInventory[this.currentItem];
                } else {
                    l = 1;
                }

                this.mainInventory[this.currentItem] = new ItemStack(var1, l, var2);
            }
        }
    }

    public void changeCurrentItem(int var1) {
        if (var1 > 0) {
            var1 = 1;
        }

        if (var1 < 0) {
            var1 = -1;
        }

        this.currentItem -= var1;

        while (this.currentItem < 0) {
            this.currentItem += 9;
        }

        while (this.currentItem >= 9) {
            this.currentItem -= 9;
        }
    }

    public int clearMatchingItems(Item var1, int var2, int var3, NBTTagCompound var4) {
        int i = 0;

        for (int j = 0; j < this.mainInventory.length; j++) {
            ItemStack itemstack = this.mainInventory[j];
            if (itemstack != null
                && (var1 == null || itemstack.getItem() == var1)
                && (var2 <= -1 || itemstack.getMetadata() == var2)
                && (var4 == null || CommandTestForBlock.func_175775_a(var4, itemstack.getTagCompound(), true))) {
                int k = var3 <= 0 ? itemstack.stackSize : Math.min(var3 - i, itemstack.stackSize);
                i += k;
                if (var3 != 0) {
                    this.mainInventory[j].stackSize -= k;
                    if (this.mainInventory[j].stackSize == 0) {
                        this.mainInventory[j] = null;
                    }

                    if (var3 > 0 && i >= var3) {
                        return i;
                    }
                }
            }
        }

        for (int l = 0; l < this.armorInventory.length; l++) {
            ItemStack itemstack1 = this.armorInventory[l];
            if (itemstack1 != null
                && (var1 == null || itemstack1.getItem() == var1)
                && (var2 <= -1 || itemstack1.getMetadata() == var2)
                && (var4 == null || CommandTestForBlock.func_175775_a(var4, itemstack1.getTagCompound(), false))) {
                int j1 = var3 <= 0 ? itemstack1.stackSize : Math.min(var3 - i, itemstack1.stackSize);
                i += j1;
                if (var3 != 0) {
                    this.armorInventory[l].stackSize -= j1;
                    if (this.armorInventory[l].stackSize == 0) {
                        this.armorInventory[l] = null;
                    }

                    if (var3 > 0 && i >= var3) {
                        return i;
                    }
                }
            }
        }

        if (this.itemStack != null) {
            if (var1 != null && this.itemStack.getItem() != var1) {
                return i;
            }

            if (var2 > -1 && this.itemStack.getMetadata() != var2) {
                return i;
            }

            if (var4 != null && !CommandTestForBlock.func_175775_a(var4, this.itemStack.getTagCompound(), false)) {
                return i;
            }

            int i1 = var3 <= 0 ? this.itemStack.stackSize : Math.min(var3 - i, this.itemStack.stackSize);
            i += i1;
            if (var3 != 0) {
                this.itemStack.stackSize -= i1;
                if (this.itemStack.stackSize == 0) {
                    this.itemStack = null;
                }

                if (var3 > 0 && i >= var3) {
                    return i;
                }
            }
        }

        return i;
    }

    private int storePartialItemStack(ItemStack var1) {
        Item item = var1.getItem();
        int i = var1.stackSize;
        int j = this.storeItemStack(var1);
        if (j < 0) {
            j = this.getFirstEmptyStack();
        }

        if (j < 0) {
            return i;
        }

        if (this.mainInventory[j] == null) {
            this.mainInventory[j] = new ItemStack(item, 0, var1.getMetadata());
            if (var1.hasTagCompound()) {
                this.mainInventory[j].setTagCompound((NBTTagCompound)var1.getTagCompound().copy());
            }
        }

        int k = i;
        if (k > this.mainInventory[j].getMaxStackSize() - this.mainInventory[j].stackSize) {
            k = this.mainInventory[j].getMaxStackSize() - this.mainInventory[j].stackSize;
        }

        if (k > this.getInventoryStackLimit() - this.mainInventory[j].stackSize) {
            k = this.getInventoryStackLimit() - this.mainInventory[j].stackSize;
        }

        if (k == 0) {
            return i;
        }

        i -= k;
        this.mainInventory[j].stackSize += k;
        this.mainInventory[j].animationsToGo = 5;
        return i;
    }

    public void decrementAnimations() {
        for (int i = 0; i < this.mainInventory.length; i++) {
            if (this.mainInventory[i] != null) {
                this.mainInventory[i].updateAnimation(this.player.worldObj, this.player, i, this.currentItem == i);
            }
        }
    }

    public boolean consumeInventoryItem(Item var1) {
        int i = this.getInventorySlotContainItem(var1);
        if (i < 0) {
            return false;
        }

        if (--this.mainInventory[i].stackSize <= 0) {
            this.mainInventory[i] = null;
        }

        return true;
    }

    public boolean hasItem(Item var1) {
        int i = this.getInventorySlotContainItem(var1);
        return i >= 0;
    }

    public boolean addItemStackToInventory(final ItemStack var1) {
        if (var1 != null && var1.stackSize != 0 && var1.getItem() != null) {
            try {
                if (var1.isItemDamaged()) {
                    int j = this.getFirstEmptyStack();
                    if (j >= 0) {
                        this.mainInventory[j] = ItemStack.copyItemStack(var1);
                        this.mainInventory[j].animationsToGo = 5;
                        var1.stackSize = 0;
                        return true;
                    } else if (this.player.capabilities.isCreativeMode) {
                        var1.stackSize = 0;
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    int i;
                    do {
                        i = var1.stackSize;
                        var1.stackSize = this.storePartialItemStack(var1);
                    } while (var1.stackSize > 0 && var1.stackSize < i);

                    if (var1.stackSize == i && this.player.capabilities.isCreativeMode) {
                        var1.stackSize = 0;
                        return true;
                    } else {
                        return var1.stackSize < i;
                    }
                }
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Adding item to inventory");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Item being added");
                crashreportcategory.addCrashSection("Item ID", Item.getIdFromItem(var1.getItem()));
                crashreportcategory.addCrashSection("Item data", var1.getMetadata());
                crashreportcategory.addCrashSectionCallable("Item name", new Callable() {
                    public String call() {
                        return var1.getDisplayName();
                    }
                });
                throw new ReportedException(crashreport);
            }
        } else {
            return false;
        }
    }

    @Override
    public ItemStack decrStackSize(int var1, int var2) {
        ItemStack[] aitemstack = this.mainInventory;
        if (var1 >= this.mainInventory.length) {
            aitemstack = this.armorInventory;
            var1 -= this.mainInventory.length;
        }

        if (aitemstack[var1] != null) {
            if (aitemstack[var1].stackSize <= var2) {
                ItemStack itemstack1 = aitemstack[var1];
                aitemstack[var1] = null;
                return itemstack1;
            }

            ItemStack itemstack = aitemstack[var1].splitStack(var2);
            if (aitemstack[var1].stackSize == 0) {
                aitemstack[var1] = null;
            }

            return itemstack;
        } else {
            return null;
        }
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int var1) {
        ItemStack[] aitemstack = this.mainInventory;
        if (var1 >= this.mainInventory.length) {
            aitemstack = this.armorInventory;
            var1 -= this.mainInventory.length;
        }

        if (aitemstack[var1] != null) {
            ItemStack itemstack = aitemstack[var1];
            aitemstack[var1] = null;
            return itemstack;
        } else {
            return null;
        }
    }

    @Override
    public void setInventorySlotContents(int var1, ItemStack var2) {
        ItemStack[] aitemstack = this.mainInventory;
        if (var1 >= aitemstack.length) {
            var1 -= aitemstack.length;
            aitemstack = this.armorInventory;
        }

        aitemstack[var1] = var2;
    }

    public float getStrVsBlock(Block var1) {
        float f = 1.0F;
        if (this.mainInventory[this.currentItem] != null) {
            f *= this.mainInventory[this.currentItem].getStrVsBlock(var1);
        }

        return f;
    }

    public NBTTagList writeToNBT(NBTTagList var1) {
        for (int i = 0; i < this.mainInventory.length; i++) {
            if (this.mainInventory[i] != null) {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Slot", (byte)i);
                this.mainInventory[i].writeToNBT(nbttagcompound);
                var1.appendTag(nbttagcompound);
            }
        }

        for (int j = 0; j < this.armorInventory.length; j++) {
            if (this.armorInventory[j] != null) {
                NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.setByte("Slot", (byte)(j + 100));
                this.armorInventory[j].writeToNBT(nbttagcompound1);
                var1.appendTag(nbttagcompound1);
            }
        }

        return var1;
    }

    public void readFromNBT(NBTTagList var1) {
        this.mainInventory = new ItemStack[36];
        this.armorInventory = new ItemStack[4];

        for (int i = 0; i < var1.tagCount(); i++) {
            NBTTagCompound nbttagcompound = var1.getCompoundTagAt(i);
            int j = nbttagcompound.getByte("Slot") & 255;
            ItemStack itemstack = ItemStack.loadItemStackFromNBT(nbttagcompound);
            if (itemstack != null) {
                if (j >= 0 && j < this.mainInventory.length) {
                    this.mainInventory[j] = itemstack;
                }

                if (j >= 100 && j < this.armorInventory.length + 100) {
                    this.armorInventory[j - 100] = itemstack;
                }
            }
        }
    }

    @Override
    public int getSizeInventory() {
        return this.mainInventory.length + 4;
    }

    @Override
    public ItemStack getStackInSlot(int var1) {
        ItemStack[] aitemstack = this.mainInventory;
        if (var1 >= aitemstack.length) {
            var1 -= aitemstack.length;
            aitemstack = this.armorInventory;
        }

        return aitemstack[var1];
    }

    @Override
    public String getCommandSenderName() {
        return "container.inventory";
    }

    @Override
    public boolean hasCustomName() {
        return false;
    }

    @Override
    public IChatComponent getDisplayName() {
        return this.hasCustomName() ? new ChatComponentText(this.getCommandSenderName()) : new ChatComponentTranslation(this.getCommandSenderName());
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    public boolean canHeldItemHarvest(Block var1) {
        if (var1.getMaterial().isToolNotRequired()) {
            return true;
        }

        ItemStack itemstack = this.getStackInSlot(this.currentItem);
        return itemstack != null ? itemstack.canHarvestBlock(var1) : false;
    }

    public ItemStack armorItemInSlot(int var1) {
        return this.armorInventory[var1];
    }

    public int getTotalArmorValue() {
        int i = 0;

        for (int j = 0; j < this.armorInventory.length; j++) {
            if (this.armorInventory[j] != null && this.armorInventory[j].getItem() instanceof ItemArmor) {
                int k = ((ItemArmor)this.armorInventory[j].getItem()).damageReduceAmount;
                i += k;
            }
        }

        return i;
    }

    public void damageArmor(float var1) {
        var1 /= 4.0F;
        if (var1 < 1.0F) {
            var1 = 1.0F;
        }

        for (int i = 0; i < this.armorInventory.length; i++) {
            if (this.armorInventory[i] != null && this.armorInventory[i].getItem() instanceof ItemArmor) {
                this.armorInventory[i].damageItem((int)var1, this.player);
                if (this.armorInventory[i].stackSize == 0) {
                    this.armorInventory[i] = null;
                }
            }
        }
    }

    public void dropAllItems() {
        for (int i = 0; i < this.mainInventory.length; i++) {
            if (this.mainInventory[i] != null) {
                this.player.dropItem(this.mainInventory[i], true, false);
                this.mainInventory[i] = null;
            }
        }

        for (int j = 0; j < this.armorInventory.length; j++) {
            if (this.armorInventory[j] != null) {
                this.player.dropItem(this.armorInventory[j], true, false);
                this.armorInventory[j] = null;
            }
        }
    }

    @Override
    public void markDirty() {
        this.inventoryChanged = true;
    }

    public void setItemStack(ItemStack var1) {
        this.itemStack = var1;
    }

    public ItemStack getItemStack() {
        return this.itemStack;
    }

    @Override
    public boolean isUseableByPlayer(EntityPlayer var1) {
        return this.player.isDead ? false : !(var1.getDistanceSqToEntity(this.player) > 64.0);
    }

    public boolean hasItemStack(ItemStack var1) {
        for (int i = 0; i < this.armorInventory.length; i++) {
            if (this.armorInventory[i] != null && this.armorInventory[i].isItemEqual(var1)) {
                return true;
            }
        }

        for (int j = 0; j < this.mainInventory.length; j++) {
            if (this.mainInventory[j] != null && this.mainInventory[j].isItemEqual(var1)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public void openInventory(EntityPlayer var1) {
    }

    @Override
    public void closeInventory(EntityPlayer var1) {
    }

    @Override
    public boolean isItemValidForSlot(int var1, ItemStack var2) {
        return true;
    }

    public void copyInventory(InventoryPlayer var1) {
        for (int i = 0; i < this.mainInventory.length; i++) {
            this.mainInventory[i] = ItemStack.copyItemStack(var1.mainInventory[i]);
        }

        for (int j = 0; j < this.armorInventory.length; j++) {
            this.armorInventory[j] = ItemStack.copyItemStack(var1.armorInventory[j]);
        }

        this.currentItem = var1.currentItem;
    }

    @Override
    public int getField(int var1) {
        return 0;
    }

    @Override
    public void setField(int var1, int var2) {
    }

    @Override
    public int getFieldCount() {
        return 0;
    }

    @Override
    public void clear() {
        for (int i = 0; i < this.mainInventory.length; i++) {
            this.mainInventory[i] = null;
        }

        for (int j = 0; j < this.armorInventory.length; j++) {
            this.armorInventory[j] = null;
        }
    }
}
