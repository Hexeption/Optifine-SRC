package net.minecraft.entity.player;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.event.ClickEvent;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryEnderChest;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.potion.Potion;
import net.minecraft.scoreboard.IScoreObjectiveCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.FoodStats;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.LockCode;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;

public abstract class EntityPlayer extends EntityLivingBase {
    public InventoryPlayer inventory = new InventoryPlayer(this);
    private InventoryEnderChest theInventoryEnderChest = new InventoryEnderChest();
    public Container inventoryContainer;
    public Container openContainer;
    protected FoodStats foodStats = new FoodStats();
    protected int flyToggleTimer;
    public float prevCameraYaw;
    public float cameraYaw;
    public int xpCooldown;
    public double prevChasingPosX;
    public double prevChasingPosY;
    public double prevChasingPosZ;
    public double chasingPosX;
    public double chasingPosY;
    public double chasingPosZ;
    protected boolean sleeping;
    public BlockPos playerLocation;
    private int sleepTimer;
    public float renderOffsetX;
    public float renderOffsetY;
    public float renderOffsetZ;
    private BlockPos spawnChunk;
    private boolean spawnForced;
    private BlockPos startMinecartRidingCoordinate;
    public PlayerCapabilities capabilities = new PlayerCapabilities();
    public int experienceLevel;
    public int experienceTotal;
    public float experience;
    private int xpSeed;
    private ItemStack itemInUse;
    private int itemInUseCount;
    protected float speedOnGround = 0.1F;
    protected float speedInAir = 0.02F;
    private int lastXPSound;
    private final GameProfile gameProfile;
    private boolean hasReducedDebug = false;
    public EntityFishHook fishEntity;

    public EntityPlayer(World var1, GameProfile var2) {
        super(var1);
        this.entityUniqueID = getUUID(var2);
        this.gameProfile = var2;
        this.inventoryContainer = new ContainerPlayer(this.inventory, !var1.isRemote, this);
        this.openContainer = this.inventoryContainer;
        BlockPos blockpos = var1.getSpawnPoint();
        this.setLocationAndAngles(blockpos.getX() + 0.5, blockpos.getY() + 1, blockpos.getZ() + 0.5, 0.0F, 0.0F);
        this.field_70741_aB = 180.0F;
        this.fireResistance = 20;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.1F);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, (byte)0);
        this.dataWatcher.addObject(17, 0.0F);
        this.dataWatcher.addObject(18, 0);
        this.dataWatcher.addObject(10, (byte)0);
    }

    public ItemStack getItemInUse() {
        return this.itemInUse;
    }

    public int getItemInUseCount() {
        return this.itemInUseCount;
    }

    public boolean isUsingItem() {
        return this.itemInUse != null;
    }

    public int getItemInUseDuration() {
        return this.isUsingItem() ? this.itemInUse.getMaxItemUseDuration() - this.itemInUseCount : 0;
    }

    public void stopUsingItem() {
        if (this.itemInUse != null) {
            this.itemInUse.onPlayerStoppedUsing(this.worldObj, this, this.itemInUseCount);
        }

        this.clearItemInUse();
    }

    public void clearItemInUse() {
        this.itemInUse = null;
        this.itemInUseCount = 0;
        if (!this.worldObj.isRemote) {
            this.setEating(false);
        }
    }

    public boolean isBlocking() {
        return this.isUsingItem() && this.itemInUse.getItem().getItemUseAction(this.itemInUse) == EnumAction.BLOCK;
    }

    @Override
    public void onUpdate() {
        this.noClip = this.isSpectator();
        if (this.isSpectator()) {
            this.onGround = false;
        }

        if (this.itemInUse != null) {
            ItemStack itemstack = this.inventory.getCurrentItem();
            if (itemstack == this.itemInUse) {
                if (this.itemInUseCount <= 25 && this.itemInUseCount % 4 == 0) {
                    this.updateItemUse(itemstack, 5);
                }

                if (--this.itemInUseCount == 0 && !this.worldObj.isRemote) {
                    this.onItemUseFinish();
                }
            } else {
                this.clearItemInUse();
            }
        }

        if (this.xpCooldown > 0) {
            this.xpCooldown--;
        }

        if (this.isPlayerSleeping()) {
            this.sleepTimer++;
            if (this.sleepTimer > 100) {
                this.sleepTimer = 100;
            }

            if (!this.worldObj.isRemote) {
                if (!this.isInBed()) {
                    this.wakeUpPlayer(true, true, false);
                } else if (this.worldObj.isDaytime()) {
                    this.wakeUpPlayer(false, true, true);
                }
            }
        } else if (this.sleepTimer > 0) {
            this.sleepTimer++;
            if (this.sleepTimer >= 110) {
                this.sleepTimer = 0;
            }
        }

        super.onUpdate();
        if (!this.worldObj.isRemote && this.openContainer != null && !this.openContainer.canInteractWith(this)) {
            this.closeScreen();
            this.openContainer = this.inventoryContainer;
        }

        if (this.isBurning() && this.capabilities.disableDamage) {
            this.extinguish();
        }

        this.prevChasingPosX = this.chasingPosX;
        this.prevChasingPosY = this.chasingPosY;
        this.prevChasingPosZ = this.chasingPosZ;
        double d5 = this.posX - this.chasingPosX;
        double d0 = this.posY - this.chasingPosY;
        double d1 = this.posZ - this.chasingPosZ;
        double d2 = 10.0;
        if (d5 > d2) {
            this.prevChasingPosX = this.chasingPosX = this.posX;
        }

        if (d1 > d2) {
            this.prevChasingPosZ = this.chasingPosZ = this.posZ;
        }

        if (d0 > d2) {
            this.prevChasingPosY = this.chasingPosY = this.posY;
        }

        if (d5 < -d2) {
            this.prevChasingPosX = this.chasingPosX = this.posX;
        }

        if (d1 < -d2) {
            this.prevChasingPosZ = this.chasingPosZ = this.posZ;
        }

        if (d0 < -d2) {
            this.prevChasingPosY = this.chasingPosY = this.posY;
        }

        this.chasingPosX += d5 * 0.25;
        this.chasingPosZ += d1 * 0.25;
        this.chasingPosY += d0 * 0.25;
        if (this.ridingEntity == null) {
            this.startMinecartRidingCoordinate = null;
        }

        if (!this.worldObj.isRemote) {
            this.foodStats.onUpdate(this);
            this.triggerAchievement(StatList.minutesPlayedStat);
            if (this.isEntityAlive()) {
                this.triggerAchievement(StatList.timeSinceDeathStat);
            }
        }

        int i = 29999999;
        double d3 = MathHelper.clamp_double(this.posX, -2.9999999E7, 2.9999999E7);
        double d4 = MathHelper.clamp_double(this.posZ, -2.9999999E7, 2.9999999E7);
        if (d3 != this.posX || d4 != this.posZ) {
            this.setPosition(d3, this.posY, d4);
        }
    }

    @Override
    public int getMaxInPortalTime() {
        return this.capabilities.disableDamage ? 0 : 80;
    }

    @Override
    protected String getSwimSound() {
        return "game.player.swim";
    }

    @Override
    protected String getSplashSound() {
        return "game.player.swim.splash";
    }

    @Override
    public int getPortalCooldown() {
        return 10;
    }

    @Override
    public void playSound(String var1, float var2, float var3) {
        this.worldObj.playSoundToNearExcept(this, var1, var2, var3);
    }

    protected void updateItemUse(ItemStack var1, int var2) {
        if (var1.getItemUseAction() == EnumAction.DRINK) {
            this.playSound("random.drink", 0.5F, this.worldObj.rand.nextFloat() * 0.1F + 0.9F);
        }

        if (var1.getItemUseAction() == EnumAction.EAT) {
            for (int i = 0; i < var2; i++) {
                Vec3 vec3 = new Vec3((this.rand.nextFloat() - 0.5) * 0.1, Math.random() * 0.1 + 0.1, 0.0);
                vec3 = vec3.rotatePitch(-this.rotationPitch * (float)Math.PI / 180.0F);
                vec3 = vec3.rotateYaw(-this.rotationYaw * (float)Math.PI / 180.0F);
                double d0 = -this.rand.nextFloat() * 0.6 - 0.3;
                Vec3 vec31 = new Vec3((this.rand.nextFloat() - 0.5) * 0.3, d0, 0.6);
                vec31 = vec31.rotatePitch(-this.rotationPitch * (float)Math.PI / 180.0F);
                vec31 = vec31.rotateYaw(-this.rotationYaw * (float)Math.PI / 180.0F);
                vec31 = vec31.addVector(this.posX, this.posY + this.getEyeHeight(), this.posZ);
                if (var1.getHasSubtypes()) {
                    this.worldObj
                        .spawnParticle(
                            EnumParticleTypes.ITEM_CRACK,
                            vec31.xCoord,
                            vec31.yCoord,
                            vec31.zCoord,
                            vec3.xCoord,
                            vec3.yCoord + 0.05,
                            vec3.zCoord,
                            Item.getIdFromItem(var1.getItem()),
                            var1.getMetadata()
                        );
                } else {
                    this.worldObj
                        .spawnParticle(
                            EnumParticleTypes.ITEM_CRACK,
                            vec31.xCoord,
                            vec31.yCoord,
                            vec31.zCoord,
                            vec3.xCoord,
                            vec3.yCoord + 0.05,
                            vec3.zCoord,
                            Item.getIdFromItem(var1.getItem())
                        );
                }
            }

            this.playSound("random.eat", 0.5F + 0.5F * this.rand.nextInt(2), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
        }
    }

    protected void onItemUseFinish() {
        if (this.itemInUse != null) {
            this.updateItemUse(this.itemInUse, 16);
            int i = this.itemInUse.stackSize;
            ItemStack itemstack = this.itemInUse.onItemUseFinish(this.worldObj, this);
            if (itemstack != this.itemInUse || itemstack != null && itemstack.stackSize != i) {
                this.inventory.mainInventory[this.inventory.currentItem] = itemstack;
                if (itemstack.stackSize == 0) {
                    this.inventory.mainInventory[this.inventory.currentItem] = null;
                }
            }

            this.clearItemInUse();
        }
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 9) {
            this.onItemUseFinish();
        } else if (var1 == 23) {
            this.hasReducedDebug = false;
        } else if (var1 == 22) {
            this.hasReducedDebug = true;
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    @Override
    protected boolean isMovementBlocked() {
        return this.getHealth() <= 0.0F || this.isPlayerSleeping();
    }

    protected void closeScreen() {
        this.openContainer = this.inventoryContainer;
    }

    @Override
    public void updateRidden() {
        if (!this.worldObj.isRemote && this.isSneaking()) {
            this.mountEntity(null);
            this.setSneaking(false);
        } else {
            double d0 = this.posX;
            double d1 = this.posY;
            double d2 = this.posZ;
            float f = this.rotationYaw;
            float f1 = this.rotationPitch;
            super.updateRidden();
            this.prevCameraYaw = this.cameraYaw;
            this.cameraYaw = 0.0F;
            this.addMountedMovementStat(this.posX - d0, this.posY - d1, this.posZ - d2);
            if (this.ridingEntity instanceof EntityPig) {
                this.rotationPitch = f1;
                this.rotationYaw = f;
                this.renderYawOffset = ((EntityPig)this.ridingEntity).renderYawOffset;
            }
        }
    }

    @Override
    public void preparePlayerToSpawn() {
        this.setSize(0.6F, 1.8F);
        super.preparePlayerToSpawn();
        this.setHealth(this.getMaxHealth());
        this.deathTime = 0;
    }

    @Override
    protected void updateEntityActionState() {
        super.updateEntityActionState();
        this.updateArmSwingProgress();
        this.rotationYawHead = this.rotationYaw;
    }

    @Override
    public void onLivingUpdate() {
        if (this.flyToggleTimer > 0) {
            this.flyToggleTimer--;
        }

        if (this.worldObj.getDifficulty() == EnumDifficulty.PEACEFUL && this.worldObj.getGameRules().getGameRuleBooleanValue("naturalRegeneration")) {
            if (this.getHealth() < this.getMaxHealth() && this.ticksExisted % 20 == 0) {
                this.heal(1.0F);
            }

            if (this.foodStats.needFood() && this.ticksExisted % 10 == 0) {
                this.foodStats.setFoodLevel(this.foodStats.getFoodLevel() + 1);
            }
        }

        this.inventory.decrementAnimations();
        this.prevCameraYaw = this.cameraYaw;
        super.onLivingUpdate();
        IAttributeInstance iattributeinstance = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
        if (!this.worldObj.isRemote) {
            iattributeinstance.setBaseValue(this.capabilities.getWalkSpeed());
        }

        this.jumpMovementFactor = this.speedInAir;
        if (this.isSprinting()) {
            this.jumpMovementFactor = (float)(this.jumpMovementFactor + this.speedInAir * 0.3);
        }

        this.setAIMoveSpeed((float)iattributeinstance.getAttributeValue());
        float f = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        float f1 = (float)(Math.atan(-this.motionY * 0.2F) * 15.0);
        if (f > 0.1F) {
            f = 0.1F;
        }

        if (!this.onGround || this.getHealth() <= 0.0F) {
            f = 0.0F;
        }

        if (this.onGround || this.getHealth() <= 0.0F) {
            f1 = 0.0F;
        }

        this.cameraYaw = this.cameraYaw + (f - this.cameraYaw) * 0.4F;
        this.cameraPitch = this.cameraPitch + (f1 - this.cameraPitch) * 0.8F;
        if (this.getHealth() > 0.0F && !this.isSpectator()) {
            AxisAlignedBB axisalignedbb = null;
            if (this.ridingEntity != null && !this.ridingEntity.isDead) {
                axisalignedbb = this.getEntityBoundingBox().union(this.ridingEntity.getEntityBoundingBox()).expand(1.0, 0.0, 1.0);
            } else {
                axisalignedbb = this.getEntityBoundingBox().expand(1.0, 0.5, 1.0);
            }

            List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, axisalignedbb);

            for (int i = 0; i < list.size(); i++) {
                Entity entity = (Entity)list.get(i);
                if (!entity.isDead) {
                    this.collideWithPlayer(entity);
                }
            }
        }
    }

    private void collideWithPlayer(Entity var1) {
        var1.onCollideWithPlayer(this);
    }

    public int getScore() {
        return this.dataWatcher.getWatchableObjectInt(18);
    }

    public void setScore(int var1) {
        this.dataWatcher.updateObject(18, var1);
    }

    public void addScore(int var1) {
        int i = this.getScore();
        this.dataWatcher.updateObject(18, i + var1);
    }

    @Override
    public void onDeath(DamageSource var1) {
        super.onDeath(var1);
        this.setSize(0.2F, 0.2F);
        this.setPosition(this.posX, this.posY, this.posZ);
        this.motionY = 0.1F;
        if (this.getCommandSenderName().equals("Notch")) {
            this.dropItem(new ItemStack(Items.apple, 1), true, false);
        }

        if (!this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            this.inventory.dropAllItems();
        }

        if (var1 != null) {
            this.motionX = -MathHelper.cos((this.attackedAtYaw + this.rotationYaw) * (float)Math.PI / 180.0F) * 0.1F;
            this.motionZ = -MathHelper.sin((this.attackedAtYaw + this.rotationYaw) * (float)Math.PI / 180.0F) * 0.1F;
        } else {
            this.motionX = this.motionZ = 0.0;
        }

        this.triggerAchievement(StatList.deathsStat);
        this.func_175145_a(StatList.timeSinceDeathStat);
    }

    @Override
    protected String getHurtSound() {
        return "game.player.hurt";
    }

    @Override
    protected String getDeathSound() {
        return "game.player.die";
    }

    @Override
    public void addToPlayerScore(Entity var1, int var2) {
        this.addScore(var2);
        Collection collection = this.getWorldScoreboard().getObjectivesFromCriteria(IScoreObjectiveCriteria.totalKillCount);
        if (var1 instanceof EntityPlayer) {
            this.triggerAchievement(StatList.playerKillsStat);
            collection.addAll(this.getWorldScoreboard().getObjectivesFromCriteria(IScoreObjectiveCriteria.playerKillCount));
            collection.addAll(this.func_175137_e(var1));
        } else {
            this.triggerAchievement(StatList.mobKillsStat);
        }

        for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) collection) {
            Score score = this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective);
            score.func_96648_a();
        }
    }

    private Collection func_175137_e(Entity var1) {
        ScorePlayerTeam scoreplayerteam = this.getWorldScoreboard().getPlayersTeam(this.getCommandSenderName());
        if (scoreplayerteam != null) {
            int i = scoreplayerteam.getChatFormat().getColorIndex();
            if (i >= 0 && i < IScoreObjectiveCriteria.field_178793_i.length) {
                for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.getWorldScoreboard().getObjectivesFromCriteria(IScoreObjectiveCriteria.field_178793_i[i])) {
                    Score score = this.getWorldScoreboard().getValueFromObjective(var1.getCommandSenderName(), scoreobjective);
                    score.func_96648_a();
                }
            }
        }

        ScorePlayerTeam scoreplayerteam1 = this.getWorldScoreboard().getPlayersTeam(var1.getCommandSenderName());
        if (scoreplayerteam1 != null) {
            int j = scoreplayerteam1.getChatFormat().getColorIndex();
            if (j >= 0 && j < IScoreObjectiveCriteria.field_178792_h.length) {
                return this.getWorldScoreboard().getObjectivesFromCriteria(IScoreObjectiveCriteria.field_178792_h[j]);
            }
        }

        return Lists.newArrayList();
    }

    public EntityItem dropOneItem(boolean var1) {
        return this.dropItem(
            this.inventory
                .decrStackSize(this.inventory.currentItem, var1 && this.inventory.getCurrentItem() != null ? this.inventory.getCurrentItem().stackSize : 1),
            false,
            true
        );
    }

    public EntityItem dropPlayerItemWithRandomChoice(ItemStack var1, boolean var2) {
        return this.dropItem(var1, false, false);
    }

    public EntityItem dropItem(ItemStack var1, boolean var2, boolean var3) {
        if (var1 == null) {
            return null;
        }

        if (var1.stackSize == 0) {
            return null;
        }

        double d0 = this.posY - 0.3F + this.getEyeHeight();
        EntityItem entityitem = new EntityItem(this.worldObj, this.posX, d0, this.posZ, var1);
        entityitem.setPickupDelay(40);
        if (var3) {
            entityitem.setThrower(this.getCommandSenderName());
        }

        if (var2) {
            float f = this.rand.nextFloat() * 0.5F;
            float f1 = this.rand.nextFloat() * (float)Math.PI * 2.0F;
            entityitem.motionX = -MathHelper.sin(f1) * f;
            entityitem.motionZ = MathHelper.cos(f1) * f;
            entityitem.motionY = 0.2F;
        } else {
            float f2 = 0.3F;
            entityitem.motionX = -MathHelper.sin(this.rotationYaw / 180.0F * (float)Math.PI)
                * MathHelper.cos(this.rotationPitch / 180.0F * (float)Math.PI)
                * f2;
            entityitem.motionZ = MathHelper.cos(this.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.rotationPitch / 180.0F * (float)Math.PI) * f2;
            entityitem.motionY = -MathHelper.sin(this.rotationPitch / 180.0F * (float)Math.PI) * f2 + 0.1F;
            float f3 = this.rand.nextFloat() * (float)Math.PI * 2.0F;
            f2 = 0.02F * this.rand.nextFloat();
            entityitem.motionX = entityitem.motionX + Math.cos(f3) * f2;
            entityitem.motionY = entityitem.motionY + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F;
            entityitem.motionZ = entityitem.motionZ + Math.sin(f3) * f2;
        }

        this.joinEntityItemWithWorld(entityitem);
        if (var3) {
            this.triggerAchievement(StatList.dropStat);
        }

        return entityitem;
    }

    protected void joinEntityItemWithWorld(EntityItem var1) {
        this.worldObj.spawnEntityInWorld(var1);
    }

    public float getToolDigEfficiency(Block var1) {
        float f = this.inventory.getStrVsBlock(var1);
        if (f > 1.0F) {
            int i = EnchantmentHelper.getEfficiencyModifier(this);
            ItemStack itemstack = this.inventory.getCurrentItem();
            if (i > 0 && itemstack != null) {
                f += i * i + 1;
            }
        }

        if (this.isPotionActive(Potion.digSpeed)) {
            f *= 1.0F + (this.getActivePotionEffect(Potion.digSpeed).getAmplifier() + 1) * 0.2F;
        }

        if (this.isPotionActive(Potion.digSlowdown)) {
            float f1 = 1.0F;
            switch (this.getActivePotionEffect(Potion.digSlowdown).getAmplifier()) {
                case 0:
                    f1 = 0.3F;
                    break;
                case 1:
                    f1 = 0.09F;
                    break;
                case 2:
                    f1 = 0.0027F;
                    break;
                case 3:
                default:
                    f1 = 8.1E-4F;
            }

            f *= f1;
        }

        if (this.isInsideOfMaterial(Material.water) && !EnchantmentHelper.getAquaAffinityModifier(this)) {
            f /= 5.0F;
        }

        if (!this.onGround) {
            f /= 5.0F;
        }

        return f;
    }

    public boolean canHarvestBlock(Block var1) {
        return this.inventory.canHeldItemHarvest(var1);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        this.entityUniqueID = getUUID(this.gameProfile);
        NBTTagList nbttaglist = var1.getTagList("Inventory", 10);
        this.inventory.readFromNBT(nbttaglist);
        this.inventory.currentItem = var1.getInteger("SelectedItemSlot");
        this.sleeping = var1.getBoolean("Sleeping");
        this.sleepTimer = var1.getShort("SleepTimer");
        this.experience = var1.getFloat("XpP");
        this.experienceLevel = var1.getInteger("XpLevel");
        this.experienceTotal = var1.getInteger("XpTotal");
        this.xpSeed = var1.getInteger("XpSeed");
        if (this.xpSeed == 0) {
            this.xpSeed = this.rand.nextInt();
        }

        this.setScore(var1.getInteger("Score"));
        if (this.sleeping) {
            this.playerLocation = new BlockPos(this);
            this.wakeUpPlayer(true, true, false);
        }

        if (var1.hasKey("SpawnX", 99) && var1.hasKey("SpawnY", 99) && var1.hasKey("SpawnZ", 99)) {
            this.spawnChunk = new BlockPos(var1.getInteger("SpawnX"), var1.getInteger("SpawnY"), var1.getInteger("SpawnZ"));
            this.spawnForced = var1.getBoolean("SpawnForced");
        }

        this.foodStats.readNBT(var1);
        this.capabilities.readCapabilitiesFromNBT(var1);
        if (var1.hasKey("EnderItems", 9)) {
            NBTTagList nbttaglist1 = var1.getTagList("EnderItems", 10);
            this.theInventoryEnderChest.loadInventoryFromNBT(nbttaglist1);
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setTag("Inventory", this.inventory.writeToNBT(new NBTTagList()));
        var1.setInteger("SelectedItemSlot", this.inventory.currentItem);
        var1.setBoolean("Sleeping", this.sleeping);
        var1.setShort("SleepTimer", (short)this.sleepTimer);
        var1.setFloat("XpP", this.experience);
        var1.setInteger("XpLevel", this.experienceLevel);
        var1.setInteger("XpTotal", this.experienceTotal);
        var1.setInteger("XpSeed", this.xpSeed);
        var1.setInteger("Score", this.getScore());
        if (this.spawnChunk != null) {
            var1.setInteger("SpawnX", this.spawnChunk.getX());
            var1.setInteger("SpawnY", this.spawnChunk.getY());
            var1.setInteger("SpawnZ", this.spawnChunk.getZ());
            var1.setBoolean("SpawnForced", this.spawnForced);
        }

        this.foodStats.writeNBT(var1);
        this.capabilities.writeCapabilitiesToNBT(var1);
        var1.setTag("EnderItems", this.theInventoryEnderChest.saveInventoryToNBT());
        ItemStack itemstack = this.inventory.getCurrentItem();
        if (itemstack != null && itemstack.getItem() != null) {
            var1.setTag("SelectedItem", itemstack.writeToNBT(new NBTTagCompound()));
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        if (this.capabilities.disableDamage && !var1.canHarmInCreative()) {
            return false;
        }

        this.entityAge = 0;
        if (this.getHealth() <= 0.0F) {
            return false;
        }

        if (this.isPlayerSleeping() && !this.worldObj.isRemote) {
            this.wakeUpPlayer(true, true, false);
        }

        if (var1.isDifficultyScaled()) {
            if (this.worldObj.getDifficulty() == EnumDifficulty.PEACEFUL) {
                var2 = 0.0F;
            }

            if (this.worldObj.getDifficulty() == EnumDifficulty.EASY) {
                var2 = var2 / 2.0F + 1.0F;
            }

            if (this.worldObj.getDifficulty() == EnumDifficulty.HARD) {
                var2 = var2 * 3.0F / 2.0F;
            }
        }

        if (var2 == 0.0F) {
            return false;
        }

        Entity entity = var1.getEntity();
        if (entity instanceof EntityArrow && ((EntityArrow)entity).shootingEntity != null) {
            entity = ((EntityArrow)entity).shootingEntity;
        }

        return super.attackEntityFrom(var1, var2);
    }

    public boolean canAttackPlayer(EntityPlayer var1) {
        Team team = this.getTeam();
        Team team1 = var1.getTeam();
        if (team == null) {
            return true;
        } else {
            return !team.isSameTeam(team1) ? true : team.getAllowFriendlyFire();
        }
    }

    @Override
    protected void damageArmor(float var1) {
        this.inventory.damageArmor(var1);
    }

    @Override
    public int getTotalArmorValue() {
        return this.inventory.getTotalArmorValue();
    }

    public float getArmorVisibility() {
        int i = 0;

        for (ItemStack itemstack : this.inventory.armorInventory) {
            if (itemstack != null) {
                i++;
            }
        }

        return (float)i / this.inventory.armorInventory.length;
    }

    @Override
    protected void damageEntity(DamageSource var1, float var2) {
        if (!this.isEntityInvulnerable(var1)) {
            if (!var1.isUnblockable() && this.isBlocking() && var2 > 0.0F) {
                var2 = (1.0F + var2) * 0.5F;
            }

            var2 = this.applyArmorCalculations(var1, var2);
            var2 = this.applyPotionDamageCalculations(var1, var2);
            float f = var2;
            var2 = Math.max(var2 - this.getAbsorptionAmount(), 0.0F);
            this.setAbsorptionAmount(this.getAbsorptionAmount() - (f - var2));
            if (var2 != 0.0F) {
                this.addExhaustion(var1.getHungerDamage());
                float f1 = this.getHealth();
                this.setHealth(this.getHealth() - var2);
                this.getCombatTracker().trackDamage(var1, f1, var2);
                if (var2 < 3.4028235E37F) {
                    this.addStat(StatList.damageTakenStat, Math.round(var2 * 10.0F));
                }
            }
        }
    }

    public void openEditSign(TileEntitySign var1) {
    }

    public void openEditCommandBlock(CommandBlockLogic var1) {
    }

    public void displayVillagerTradeGui(IMerchant var1) {
    }

    public void displayGUIChest(IInventory var1) {
    }

    public void displayGUIHorse(EntityHorse var1, IInventory var2) {
    }

    public void displayGui(IInteractionObject var1) {
    }

    public void displayGUIBook(ItemStack var1) {
    }

    public boolean interactWith(Entity var1) {
        if (this.isSpectator()) {
            if (var1 instanceof IInventory) {
                this.displayGUIChest((IInventory)var1);
            }

            return false;
        } else {
            ItemStack itemstack = this.getCurrentEquippedItem();
            ItemStack itemstack1 = itemstack != null ? itemstack.copy() : null;
            if (!var1.interactFirst(this)) {
                if (itemstack != null && var1 instanceof EntityLivingBase) {
                    if (this.capabilities.isCreativeMode) {
                        itemstack = itemstack1;
                    }

                    if (itemstack.interactWithEntity(this, (EntityLivingBase)var1)) {
                        if (itemstack.stackSize <= 0 && !this.capabilities.isCreativeMode) {
                            this.destroyCurrentEquippedItem();
                        }

                        return true;
                    }
                }

                return false;
            } else {
                if (itemstack != null && itemstack == this.getCurrentEquippedItem()) {
                    if (itemstack.stackSize <= 0 && !this.capabilities.isCreativeMode) {
                        this.destroyCurrentEquippedItem();
                    } else if (itemstack.stackSize < itemstack1.stackSize && this.capabilities.isCreativeMode) {
                        itemstack.stackSize = itemstack1.stackSize;
                    }
                }

                return true;
            }
        }
    }

    public ItemStack getCurrentEquippedItem() {
        return this.inventory.getCurrentItem();
    }

    public void destroyCurrentEquippedItem() {
        this.inventory.setInventorySlotContents(this.inventory.currentItem, null);
    }

    @Override
    public double getYOffset() {
        return -0.35;
    }

    public void attackTargetEntityWithCurrentItem(Entity var1) {
        if (var1.canAttackWithItem()) {
            if (!var1.hitByEntity(this)) {
                float f = (float)this.getEntityAttribute(SharedMonsterAttributes.attackDamage).getAttributeValue();
                int i = 0;
                float f1 = 0.0F;
                if (var1 instanceof EntityLivingBase) {
                    f1 = EnchantmentHelper.func_152377_a(this.getHeldItem(), ((EntityLivingBase)var1).getCreatureAttribute());
                } else {
                    f1 = EnchantmentHelper.func_152377_a(this.getHeldItem(), EnumCreatureAttribute.UNDEFINED);
                }

                i += EnchantmentHelper.getKnockbackModifier(this);
                if (this.isSprinting()) {
                    i++;
                }

                if (f > 0.0F || f1 > 0.0F) {
                    boolean flag = this.fallDistance > 0.0F
                        && !this.onGround
                        && !this.isOnLadder()
                        && !this.isInWater()
                        && !this.isPotionActive(Potion.blindness)
                        && this.ridingEntity == null
                        && var1 instanceof EntityLivingBase;
                    if (flag && f > 0.0F) {
                        f *= 1.5F;
                    }

                    f += f1;
                    boolean flag1 = false;
                    int j = EnchantmentHelper.getFireAspectModifier(this);
                    if (var1 instanceof EntityLivingBase && j > 0 && !var1.isBurning()) {
                        flag1 = true;
                        var1.setFire(1);
                    }

                    double d0 = var1.motionX;
                    double d1 = var1.motionY;
                    double d2 = var1.motionZ;
                    boolean flag2 = var1.attackEntityFrom(DamageSource.causePlayerDamage(this), f);
                    if (flag2) {
                        if (i > 0) {
                            var1.addVelocity(
                                -MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F) * i * 0.5F,
                                0.1,
                                MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F) * i * 0.5F
                            );
                            this.motionX *= 0.6;
                            this.motionZ *= 0.6;
                            this.setSprinting(false);
                        }

                        if (var1 instanceof EntityPlayerMP && var1.velocityChanged) {
                            ((EntityPlayerMP)var1).playerNetServerHandler.sendPacket(new S12PacketEntityVelocity(var1));
                            var1.velocityChanged = false;
                            var1.motionX = d0;
                            var1.motionY = d1;
                            var1.motionZ = d2;
                        }

                        if (flag) {
                            this.onCriticalHit(var1);
                        }

                        if (f1 > 0.0F) {
                            this.onEnchantmentCritical(var1);
                        }

                        if (f >= 18.0F) {
                            this.triggerAchievement(AchievementList.overkill);
                        }

                        this.setLastAttacker(var1);
                        if (var1 instanceof EntityLivingBase) {
                            EnchantmentHelper.applyThornEnchantments((EntityLivingBase)var1, this);
                        }

                        EnchantmentHelper.applyArthropodEnchantments(this, var1);
                        ItemStack itemstack = this.getCurrentEquippedItem();
                        Entity entity = var1;
                        if (var1 instanceof EntityDragonPart) {
                            IEntityMultiPart ientitymultipart = ((EntityDragonPart)var1).entityDragonObj;
                            if (ientitymultipart instanceof EntityLivingBase) {
                                entity = (EntityLivingBase)ientitymultipart;
                            }
                        }

                        if (itemstack != null && entity instanceof EntityLivingBase) {
                            itemstack.hitEntity((EntityLivingBase)entity, this);
                            if (itemstack.stackSize <= 0) {
                                this.destroyCurrentEquippedItem();
                            }
                        }

                        if (var1 instanceof EntityLivingBase) {
                            this.addStat(StatList.damageDealtStat, Math.round(f * 10.0F));
                            if (j > 0) {
                                var1.setFire(j * 4);
                            }
                        }

                        this.addExhaustion(0.3F);
                    } else if (flag1) {
                        var1.extinguish();
                    }
                }
            }
        }
    }

    public void onCriticalHit(Entity var1) {
    }

    public void onEnchantmentCritical(Entity var1) {
    }

    public void respawnPlayer() {
    }

    @Override
    public void setDead() {
        super.setDead();
        this.inventoryContainer.onContainerClosed(this);
        if (this.openContainer != null) {
            this.openContainer.onContainerClosed(this);
        }
    }

    @Override
    public boolean isEntityInsideOpaqueBlock() {
        return !this.sleeping && super.isEntityInsideOpaqueBlock();
    }

    public boolean isUser() {
        return false;
    }

    public GameProfile getGameProfile() {
        return this.gameProfile;
    }

    public EntityPlayer.EnumStatus trySleep(BlockPos var1) {
        if (!this.worldObj.isRemote) {
            if (this.isPlayerSleeping() || !this.isEntityAlive()) {
                return EntityPlayer.EnumStatus.OTHER_PROBLEM;
            }

            if (!this.worldObj.provider.isSurfaceWorld()) {
                return EntityPlayer.EnumStatus.NOT_POSSIBLE_HERE;
            }

            if (this.worldObj.isDaytime()) {
                return EntityPlayer.EnumStatus.NOT_POSSIBLE_NOW;
            }

            if (Math.abs(this.posX - var1.getX()) > 3.0 || Math.abs(this.posY - var1.getY()) > 2.0 || Math.abs(this.posZ - var1.getZ()) > 3.0) {
                return EntityPlayer.EnumStatus.TOO_FAR_AWAY;
            }

            double d0 = 8.0;
            double d1 = 5.0;
            List list = this.worldObj
                .getEntitiesWithinAABB(
                    EntityMob.class,
                    new AxisAlignedBB(var1.getX() - d0, var1.getY() - d1, var1.getZ() - d0, var1.getX() + d0, var1.getY() + d1, var1.getZ() + d0)
                );
            if (!list.isEmpty()) {
                return EntityPlayer.EnumStatus.NOT_SAFE;
            }
        }

        if (this.isRiding()) {
            this.mountEntity(null);
        }

        this.setSize(0.2F, 0.2F);
        if (this.worldObj.isBlockLoaded(var1)) {
            EnumFacing enumfacing = (EnumFacing)this.worldObj.getBlockState(var1).getValue(BlockDirectional.FACING);
            float f = 0.5F;
            float f1 = 0.5F;
            switch (enumfacing) {
                case SOUTH:
                    f1 = 0.9F;
                    break;
                case NORTH:
                    f1 = 0.1F;
                    break;
                case WEST:
                    f = 0.1F;
                    break;
                case EAST:
                    f = 0.9F;
            }

            this.func_175139_a(enumfacing);
            this.setPosition(var1.getX() + f, var1.getY() + 11.0F / 16.0F, var1.getZ() + f1);
        } else {
            this.setPosition(var1.getX() + 0.5F, var1.getY() + 11.0F / 16.0F, var1.getZ() + 0.5F);
        }

        this.sleeping = true;
        this.sleepTimer = 0;
        this.playerLocation = var1;
        this.motionX = this.motionZ = this.motionY = 0.0;
        if (!this.worldObj.isRemote) {
            this.worldObj.updateAllPlayersSleepingFlag();
        }

        return EntityPlayer.EnumStatus.OK;
    }

    private void func_175139_a(EnumFacing var1) {
        this.renderOffsetX = 0.0F;
        this.renderOffsetZ = 0.0F;
        switch (var1) {
            case SOUTH:
                this.renderOffsetZ = -1.8F;
                break;
            case NORTH:
                this.renderOffsetZ = 1.8F;
                break;
            case WEST:
                this.renderOffsetX = 1.8F;
                break;
            case EAST:
                this.renderOffsetX = -1.8F;
        }
    }

    public void wakeUpPlayer(boolean var1, boolean var2, boolean var3) {
        this.setSize(0.6F, 1.8F);
        IBlockState iblockstate = this.worldObj.getBlockState(this.playerLocation);
        if (this.playerLocation != null && iblockstate.getBlock() == Blocks.bed) {
            this.worldObj.setBlockState(this.playerLocation, iblockstate.withProperty(BlockBed.OCCUPIED, false), 4);
            BlockPos blockpos = BlockBed.getSafeExitLocation(this.worldObj, this.playerLocation, 0);
            if (blockpos == null) {
                blockpos = this.playerLocation.up();
            }

            this.setPosition(blockpos.getX() + 0.5F, blockpos.getY() + 0.1F, blockpos.getZ() + 0.5F);
        }

        this.sleeping = false;
        if (!this.worldObj.isRemote && var2) {
            this.worldObj.updateAllPlayersSleepingFlag();
        }

        this.sleepTimer = var1 ? 0 : 100;
        if (var3) {
            this.setSpawnPoint(this.playerLocation, false);
        }
    }

    private boolean isInBed() {
        return this.worldObj.getBlockState(this.playerLocation).getBlock() == Blocks.bed;
    }

    public static BlockPos getBedSpawnLocation(World var0, BlockPos var1, boolean var2) {
        if (var0.getBlockState(var1).getBlock() != Blocks.bed) {
            if (!var2) {
                return null;
            }

            Material material = var0.getBlockState(var1).getBlock().getMaterial();
            Material material1 = var0.getBlockState(var1.up()).getBlock().getMaterial();
            boolean flag = !material.isSolid() && !material.isLiquid();
            boolean flag1 = !material1.isSolid() && !material1.isLiquid();
            return flag && flag1 ? var1 : null;
        } else {
            return BlockBed.getSafeExitLocation(var0, var1, 0);
        }
    }

    public float getBedOrientationInDegrees() {
        if (this.playerLocation != null) {
            EnumFacing enumfacing = (EnumFacing)this.worldObj.getBlockState(this.playerLocation).getValue(BlockDirectional.FACING);
            switch (enumfacing) {
                case SOUTH:
                    return 90.0F;
                case NORTH:
                    return 270.0F;
                case WEST:
                    return 0.0F;
                case EAST:
                    return 180.0F;
            }
        }

        return 0.0F;
    }

    @Override
    public boolean isPlayerSleeping() {
        return this.sleeping;
    }

    public boolean isPlayerFullyAsleep() {
        return this.sleeping && this.sleepTimer >= 100;
    }

    public int getSleepTimer() {
        return this.sleepTimer;
    }

    public void addChatComponentMessage(IChatComponent var1) {
    }

    public BlockPos getBedLocation() {
        return this.spawnChunk;
    }

    public boolean isSpawnForced() {
        return this.spawnForced;
    }

    public void setSpawnPoint(BlockPos var1, boolean var2) {
        if (var1 != null) {
            this.spawnChunk = var1;
            this.spawnForced = var2;
        } else {
            this.spawnChunk = null;
            this.spawnForced = false;
        }
    }

    public void triggerAchievement(StatBase var1) {
        this.addStat(var1, 1);
    }

    public void addStat(StatBase var1, int var2) {
    }

    public void func_175145_a(StatBase var1) {
    }

    @Override
    public void jump() {
        super.jump();
        this.triggerAchievement(StatList.jumpStat);
        if (this.isSprinting()) {
            this.addExhaustion(0.8F);
        } else {
            this.addExhaustion(0.2F);
        }
    }

    @Override
    public void moveEntityWithHeading(float var1, float var2) {
        double d0 = this.posX;
        double d1 = this.posY;
        double d2 = this.posZ;
        if (this.capabilities.isFlying && this.ridingEntity == null) {
            double d3 = this.motionY;
            float f = this.jumpMovementFactor;
            this.jumpMovementFactor = this.capabilities.getFlySpeed() * (this.isSprinting() ? 2 : 1);
            super.moveEntityWithHeading(var1, var2);
            this.motionY = d3 * 0.6;
            this.jumpMovementFactor = f;
        } else {
            super.moveEntityWithHeading(var1, var2);
        }

        this.addMovementStat(this.posX - d0, this.posY - d1, this.posZ - d2);
    }

    @Override
    public float getAIMoveSpeed() {
        return (float)this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue();
    }

    public void addMovementStat(double var1, double var3, double var5) {
        if (this.ridingEntity == null) {
            if (this.isInsideOfMaterial(Material.water)) {
                int i = Math.round(MathHelper.sqrt_double(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
                if (i > 0) {
                    this.addStat(StatList.distanceDoveStat, i);
                    this.addExhaustion(0.015F * i * 0.01F);
                }
            } else if (this.isInWater()) {
                int j = Math.round(MathHelper.sqrt_double(var1 * var1 + var5 * var5) * 100.0F);
                if (j > 0) {
                    this.addStat(StatList.distanceSwumStat, j);
                    this.addExhaustion(0.015F * j * 0.01F);
                }
            } else if (this.isOnLadder()) {
                if (var3 > 0.0) {
                    this.addStat(StatList.distanceClimbedStat, (int)Math.round(var3 * 100.0));
                }
            } else if (this.onGround) {
                int k = Math.round(MathHelper.sqrt_double(var1 * var1 + var5 * var5) * 100.0F);
                if (k > 0) {
                    this.addStat(StatList.distanceWalkedStat, k);
                    if (this.isSprinting()) {
                        this.addStat(StatList.distanceSprintedStat, k);
                        this.addExhaustion(10.0F * 0.01F * k * 0.01F);
                    } else {
                        if (this.isSneaking()) {
                            this.addStat(StatList.distanceCrouchedStat, k);
                        }

                        this.addExhaustion(0.01F * k * 0.01F);
                    }
                }
            } else {
                int l = Math.round(MathHelper.sqrt_double(var1 * var1 + var5 * var5) * 100.0F);
                if (l > 25) {
                    this.addStat(StatList.distanceFlownStat, l);
                }
            }
        }
    }

    private void addMountedMovementStat(double var1, double var3, double var5) {
        if (this.ridingEntity != null) {
            int i = Math.round(MathHelper.sqrt_double(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
            if (i > 0) {
                if (this.ridingEntity instanceof EntityMinecart) {
                    this.addStat(StatList.distanceByMinecartStat, i);
                    if (this.startMinecartRidingCoordinate == null) {
                        this.startMinecartRidingCoordinate = new BlockPos(this);
                    } else if (this.startMinecartRidingCoordinate
                            .distanceSq(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))
                        >= 1000000.0) {
                        this.triggerAchievement(AchievementList.onARail);
                    }
                } else if (this.ridingEntity instanceof EntityBoat) {
                    this.addStat(StatList.distanceByBoatStat, i);
                } else if (this.ridingEntity instanceof EntityPig) {
                    this.addStat(StatList.distanceByPigStat, i);
                } else if (this.ridingEntity instanceof EntityHorse) {
                    this.addStat(StatList.distanceByHorseStat, i);
                }
            }
        }
    }

    @Override
    public void fall(float var1, float var2) {
        if (!this.capabilities.allowFlying) {
            if (var1 >= 2.0F) {
                this.addStat(StatList.distanceFallenStat, (int)Math.round(var1 * 100.0));
            }

            super.fall(var1, var2);
        }
    }

    @Override
    protected void resetHeight() {
        if (!this.isSpectator()) {
            super.resetHeight();
        }
    }

    @Override
    protected String getFallSoundString(int var1) {
        return var1 > 4 ? "game.player.hurt.fall.big" : "game.player.hurt.fall.small";
    }

    @Override
    public void onKillEntity(EntityLivingBase var1) {
        if (var1 instanceof IMob) {
            this.triggerAchievement(AchievementList.killEnemy);
        }

        EntityList.EntityEggInfo entitylist$entityegginfo = (EntityList.EntityEggInfo)EntityList.entityEggs.get(EntityList.getEntityID(var1));
        if (entitylist$entityegginfo != null) {
            this.triggerAchievement(entitylist$entityegginfo.field_151512_d);
        }
    }

    @Override
    public void setInWeb() {
        if (!this.capabilities.isFlying) {
            super.setInWeb();
        }
    }

    @Override
    public ItemStack getCurrentArmor(int var1) {
        return this.inventory.armorItemInSlot(var1);
    }

    public void addExperience(int var1) {
        this.addScore(var1);
        int i = Integer.MAX_VALUE - this.experienceTotal;
        if (var1 > i) {
            var1 = i;
        }

        this.experience = this.experience + (float)var1 / this.xpBarCap();

        for (this.experienceTotal += var1; this.experience >= 1.0F; this.experience = this.experience / this.xpBarCap()) {
            this.experience = (this.experience - 1.0F) * this.xpBarCap();
            this.addExperienceLevel(1);
        }
    }

    public int getXPSeed() {
        return this.xpSeed;
    }

    public void removeExperienceLevel(int var1) {
        this.experienceLevel -= var1;
        if (this.experienceLevel < 0) {
            this.experienceLevel = 0;
            this.experience = 0.0F;
            this.experienceTotal = 0;
        }

        this.xpSeed = this.rand.nextInt();
    }

    public void addExperienceLevel(int var1) {
        this.experienceLevel += var1;
        if (this.experienceLevel < 0) {
            this.experienceLevel = 0;
            this.experience = 0.0F;
            this.experienceTotal = 0;
        }

        if (var1 > 0 && this.experienceLevel % 5 == 0 && this.lastXPSound < this.ticksExisted - 100.0F) {
            float f = this.experienceLevel > 30 ? 1.0F : this.experienceLevel / 30.0F;
            this.worldObj.playSoundAtEntity(this, "random.levelup", f * (12.0F / 16.0F), 1.0F);
            this.lastXPSound = this.ticksExisted;
        }
    }

    public int xpBarCap() {
        if (this.experienceLevel >= 30) {
            return 112 + (this.experienceLevel - 30) * 9;
        } else {
            return this.experienceLevel >= 15 ? 37 + (this.experienceLevel - 15) * 5 : 7 + this.experienceLevel * 2;
        }
    }

    public void addExhaustion(float var1) {
        if (!this.capabilities.disableDamage) {
            if (!this.worldObj.isRemote) {
                this.foodStats.addExhaustion(var1);
            }
        }
    }

    public FoodStats getFoodStats() {
        return this.foodStats;
    }

    public boolean canEat(boolean var1) {
        return (var1 || this.foodStats.needFood()) && !this.capabilities.disableDamage;
    }

    public boolean shouldHeal() {
        return this.getHealth() > 0.0F && this.getHealth() < this.getMaxHealth();
    }

    public void setItemInUse(ItemStack var1, int var2) {
        if (var1 != this.itemInUse) {
            this.itemInUse = var1;
            this.itemInUseCount = var2;
            if (!this.worldObj.isRemote) {
                this.setEating(true);
            }
        }
    }

    public boolean isAllowEdit() {
        return this.capabilities.allowEdit;
    }

    public boolean canPlayerEdit(BlockPos var1, EnumFacing var2, ItemStack var3) {
        if (this.capabilities.allowEdit) {
            return true;
        }

        if (var3 == null) {
            return false;
        }

        BlockPos blockpos = var1.offset(var2.getOpposite());
        Block block = this.worldObj.getBlockState(blockpos).getBlock();
        return var3.canPlaceOn(block) || var3.canEditBlocks();
    }

    @Override
    protected int getExperiencePoints(EntityPlayer var1) {
        if (this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            return 0;
        }

        int i = this.experienceLevel * 7;
        return i > 100 ? 100 : i;
    }

    @Override
    protected boolean isPlayer() {
        return true;
    }

    @Override
    public boolean getAlwaysRenderNameTagForRender() {
        return true;
    }

    public void clonePlayer(EntityPlayer var1, boolean var2) {
        if (var2) {
            this.inventory.copyInventory(var1.inventory);
            this.setHealth(var1.getHealth());
            this.foodStats = var1.foodStats;
            this.experienceLevel = var1.experienceLevel;
            this.experienceTotal = var1.experienceTotal;
            this.experience = var1.experience;
            this.setScore(var1.getScore());
            this.teleportDirection = var1.teleportDirection;
        } else if (this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            this.inventory.copyInventory(var1.inventory);
            this.experienceLevel = var1.experienceLevel;
            this.experienceTotal = var1.experienceTotal;
            this.experience = var1.experience;
            this.setScore(var1.getScore());
        }

        this.theInventoryEnderChest = var1.theInventoryEnderChest;
        this.getDataWatcher().updateObject(10, var1.getDataWatcher().getWatchableObjectByte(10));
    }

    @Override
    protected boolean canTriggerWalking() {
        return !this.capabilities.isFlying;
    }

    public void sendPlayerAbilities() {
    }

    public void setGameType(WorldSettings.GameType var1) {
    }

    @Override
    public String getCommandSenderName() {
        return this.gameProfile.getName();
    }

    public InventoryEnderChest getInventoryEnderChest() {
        return this.theInventoryEnderChest;
    }

    @Override
    public ItemStack getEquipmentInSlot(int var1) {
        return var1 == 0 ? this.inventory.getCurrentItem() : this.inventory.armorInventory[var1 - 1];
    }

    @Override
    public ItemStack getHeldItem() {
        return this.inventory.getCurrentItem();
    }

    @Override
    public void setCurrentItemOrArmor(int var1, ItemStack var2) {
        this.inventory.armorInventory[var1] = var2;
    }

    @Override
    public boolean isInvisibleToPlayer(EntityPlayer var1) {
        if (!this.isInvisible()) {
            return false;
        }

        if (var1.isSpectator()) {
            return false;
        }

        Team team = this.getTeam();
        return team == null || var1 == null || var1.getTeam() != team || !team.getSeeFriendlyInvisiblesEnabled();
    }

    public abstract boolean isSpectator();

    @Override
    public ItemStack[] getInventory() {
        return this.inventory.armorInventory;
    }

    @Override
    public boolean isPushedByWater() {
        return !this.capabilities.isFlying;
    }

    public Scoreboard getWorldScoreboard() {
        return this.worldObj.getScoreboard();
    }

    @Override
    public Team getTeam() {
        return this.getWorldScoreboard().getPlayersTeam(this.getCommandSenderName());
    }

    @Override
    public IChatComponent getDisplayName() {
        ChatComponentText chatcomponenttext = new ChatComponentText(ScorePlayerTeam.formatPlayerName(this.getTeam(), this.getCommandSenderName()));
        chatcomponenttext.getChatStyle().setChatClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/msg " + this.getCommandSenderName() + " "));
        chatcomponenttext.getChatStyle().setChatHoverEvent(this.getHoverEvent());
        chatcomponenttext.getChatStyle().setInsertion(this.getCommandSenderName());
        return chatcomponenttext;
    }

    @Override
    public float getEyeHeight() {
        float f = 1.62F;
        if (this.isPlayerSleeping()) {
            f = 0.2F;
        }

        if (this.isSneaking()) {
            f -= 0.08F;
        }

        return f;
    }

    @Override
    public void setAbsorptionAmount(float var1) {
        if (var1 < 0.0F) {
            var1 = 0.0F;
        }

        this.getDataWatcher().updateObject(17, var1);
    }

    @Override
    public float getAbsorptionAmount() {
        return this.getDataWatcher().getWatchableObjectFloat(17);
    }

    public static UUID getUUID(GameProfile var0) {
        UUID uuid = var0.getId();
        if (uuid == null) {
            uuid = getOfflineUUID(var0.getName());
        }

        return uuid;
    }

    public static UUID getOfflineUUID(String var0) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + var0).getBytes(Charsets.UTF_8));
    }

    public boolean canOpen(LockCode var1) {
        if (var1.isEmpty()) {
            return true;
        }

        ItemStack itemstack = this.getCurrentEquippedItem();
        return itemstack != null && itemstack.hasDisplayName() ? itemstack.getDisplayName().equals(var1.getLock()) : false;
    }

    public boolean isWearing(EnumPlayerModelParts var1) {
        return (this.getDataWatcher().getWatchableObjectByte(10) & var1.getPartMask()) == var1.getPartMask();
    }

    @Override
    public boolean sendCommandFeedback() {
        return MinecraftServer.getServer().worldServers[0].getGameRules().getGameRuleBooleanValue("sendCommandFeedback");
    }

    @Override
    public boolean replaceItemInInventory(int var1, ItemStack var2) {
        if (var1 >= 0 && var1 < this.inventory.mainInventory.length) {
            this.inventory.setInventorySlotContents(var1, var2);
            return true;
        }

        int i = var1 - 100;
        if (i >= 0 && i < this.inventory.armorInventory.length) {
            int k = i + 1;
            if (var2 != null && var2.getItem() != null) {
                if (var2.getItem() instanceof ItemArmor) {
                    if (EntityLiving.getArmorPosition(var2) != k) {
                        return false;
                    }
                } else if (k != 4 || var2.getItem() != Items.skull && !(var2.getItem() instanceof ItemBlock)) {
                    return false;
                }
            }

            this.inventory.setInventorySlotContents(i + this.inventory.mainInventory.length, var2);
            return true;
        } else {
            int j = var1 - 200;
            if (j >= 0 && j < this.theInventoryEnderChest.getSizeInventory()) {
                this.theInventoryEnderChest.setInventorySlotContents(j, var2);
                return true;
            } else {
                return false;
            }
        }
    }

    public boolean hasReducedDebug() {
        return this.hasReducedDebug;
    }

    public void setReducedDebug(boolean var1) {
        this.hasReducedDebug = var1;
    }

    public enum EnumChatVisibility {
        FULL(0, "options.chat.visibility.full"),
        SYSTEM(1, "options.chat.visibility.system"),
        HIDDEN(2, "options.chat.visibility.hidden");

        private static final EntityPlayer.EnumChatVisibility[] ID_LOOKUP = new EntityPlayer.EnumChatVisibility[values().length];
        private final int chatVisibility;
        private final String resourceKey;

        EnumChatVisibility(int var3, String var4) {
            this.chatVisibility = var3;
            this.resourceKey = var4;
        }

        public int getChatVisibility() {
            return this.chatVisibility;
        }

        public static EntityPlayer.EnumChatVisibility getEnumChatVisibility(int var0) {
            return ID_LOOKUP[var0 % ID_LOOKUP.length];
        }

        public String getResourceKey() {
            return this.resourceKey;
        }

        static {
            for (EntityPlayer.EnumChatVisibility entityplayer$enumchatvisibility : values()) {
                ID_LOOKUP[entityplayer$enumchatvisibility.chatVisibility] = entityplayer$enumchatvisibility;
            }
        }
    }

    public enum EnumStatus {
        OK,
        NOT_POSSIBLE_HERE,
        NOT_POSSIBLE_NOW,
        TOO_FAR_AWAY,
        OTHER_PROBLEM,
        NOT_SAFE;
    }
}
