package net.minecraft.entity.player;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockWall;
import net.minecraft.block.material.Material;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.ContainerHorseInventory;
import net.minecraft.inventory.ContainerMerchant;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryMerchant;
import net.minecraft.inventory.SlotCrafting;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemMapBase;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C15PacketClientSettings;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S06PacketUpdateHealth;
import net.minecraft.network.play.server.S0APacketUseBed;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.network.play.server.S13PacketDestroyEntities;
import net.minecraft.network.play.server.S19PacketEntityStatus;
import net.minecraft.network.play.server.S1BPacketEntityAttach;
import net.minecraft.network.play.server.S1DPacketEntityEffect;
import net.minecraft.network.play.server.S1EPacketRemoveEntityEffect;
import net.minecraft.network.play.server.S1FPacketSetExperience;
import net.minecraft.network.play.server.S21PacketChunkData;
import net.minecraft.network.play.server.S26PacketMapChunkBulk;
import net.minecraft.network.play.server.S29PacketSoundEffect;
import net.minecraft.network.play.server.S2BPacketChangeGameState;
import net.minecraft.network.play.server.S2DPacketOpenWindow;
import net.minecraft.network.play.server.S2EPacketCloseWindow;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.network.play.server.S30PacketWindowItems;
import net.minecraft.network.play.server.S31PacketWindowProperty;
import net.minecraft.network.play.server.S36PacketSignEditorOpen;
import net.minecraft.network.play.server.S39PacketPlayerAbilities;
import net.minecraft.network.play.server.S3FPacketCustomPayload;
import net.minecraft.network.play.server.S42PacketCombatEvent;
import net.minecraft.network.play.server.S43PacketCamera;
import net.minecraft.network.play.server.S48PacketResourcePackSend;
import net.minecraft.potion.PotionEffect;
import net.minecraft.scoreboard.IScoreObjectiveCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.ItemInWorldManager;
import net.minecraft.server.management.UserListOpsEntry;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.stats.StatisticsFile;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.JsonSerializableSet;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.WorldServer;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EntityPlayerMP extends EntityPlayer implements ICrafting {
    private static final Logger logger = LogManager.getLogger();
    private String translator = "en_US";
    public NetHandlerPlayServer playerNetServerHandler;
    public final MinecraftServer mcServer;
    public final ItemInWorldManager theItemInWorldManager;
    public double managedPosX;
    public double managedPosZ;
    public final List loadedChunks = Lists.newLinkedList();
    private final List destroyedItemsNetCache = Lists.newLinkedList();
    private final StatisticsFile statsFile;
    private float combinedHealth = Float.MIN_VALUE;
    private float lastHealth = -1.0E8F;
    private int lastFoodLevel = -99999999;
    private boolean wasHungry = true;
    private int lastExperience = -99999999;
    private int respawnInvulnerabilityTicks = 60;
    private EntityPlayer.EnumChatVisibility chatVisibility;
    private boolean chatColours = true;
    private long playerLastActiveTime = System.currentTimeMillis();
    private Entity spectatingEntity = null;
    private int currentWindowId;
    public boolean isChangingQuantityOnly;
    public int ping;
    public boolean playerConqueredTheEnd;

    public EntityPlayerMP(MinecraftServer var1, WorldServer var2, GameProfile var3, ItemInWorldManager var4) {
        super(var2, var3);
        var4.thisPlayerMP = this;
        this.theItemInWorldManager = var4;
        BlockPos blockpos = var2.getSpawnPoint();
        if (!var2.provider.getHasNoSky() && var2.getWorldInfo().getGameType() != WorldSettings.GameType.ADVENTURE) {
            int i = Math.max(5, var1.getSpawnProtectionSize() - 6);
            int j = MathHelper.floor_double(var2.getWorldBorder().getClosestDistance(blockpos.getX(), blockpos.getZ()));
            if (j < i) {
                i = j;
            }

            if (j <= 1) {
                i = 1;
            }

            blockpos = var2.getTopSolidOrLiquidBlock(blockpos.add(this.rand.nextInt(i * 2) - i, 0, this.rand.nextInt(i * 2) - i));
        }

        this.mcServer = var1;
        this.statsFile = var1.getConfigurationManager().getPlayerStatsFile(this);
        this.stepHeight = 0.0F;
        this.moveToBlockPosAndAngles(blockpos, 0.0F, 0.0F);

        while (!var2.getCollidingBoundingBoxes(this, this.getEntityBoundingBox()).isEmpty() && this.posY < 255.0) {
            this.setPosition(this.posX, this.posY + 1.0, this.posZ);
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        if (var1.hasKey("playerGameType", 99)) {
            if (MinecraftServer.getServer().getForceGamemode()) {
                this.theItemInWorldManager.setGameType(MinecraftServer.getServer().getGameType());
            } else {
                this.theItemInWorldManager.setGameType(WorldSettings.GameType.getByID(var1.getInteger("playerGameType")));
            }
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        var1.setInteger("playerGameType", this.theItemInWorldManager.getGameType().getID());
    }

    @Override
    public void addExperienceLevel(int var1) {
        super.addExperienceLevel(var1);
        this.lastExperience = -1;
    }

    @Override
    public void removeExperienceLevel(int var1) {
        super.removeExperienceLevel(var1);
        this.lastExperience = -1;
    }

    public void addSelfToInternalCraftingInventory() {
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void sendEnterCombat() {
        super.sendEnterCombat();
        this.playerNetServerHandler.sendPacket(new S42PacketCombatEvent(this.getCombatTracker(), S42PacketCombatEvent.Event.ENTER_COMBAT));
    }

    @Override
    public void sendEndCombat() {
        super.sendEndCombat();
        this.playerNetServerHandler.sendPacket(new S42PacketCombatEvent(this.getCombatTracker(), S42PacketCombatEvent.Event.END_COMBAT));
    }

    @Override
    public void onUpdate() {
        this.theItemInWorldManager.updateBlockRemoving();
        this.respawnInvulnerabilityTicks--;
        if (this.hurtResistantTime > 0) {
            this.hurtResistantTime--;
        }

        this.openContainer.detectAndSendChanges();
        if (!this.worldObj.isRemote && !this.openContainer.canInteractWith(this)) {
            this.closeScreen();
            this.openContainer = this.inventoryContainer;
        }

        while (!this.destroyedItemsNetCache.isEmpty()) {
            int i = Math.min(this.destroyedItemsNetCache.size(), Integer.MAX_VALUE);
            int[] aint = new int[i];
            Iterator iterator = this.destroyedItemsNetCache.iterator();
            int j = 0;

            while (iterator.hasNext() && j < i) {
                aint[j++] = (Integer)iterator.next();
                iterator.remove();
            }

            this.playerNetServerHandler.sendPacket(new S13PacketDestroyEntities(aint));
        }

        if (!this.loadedChunks.isEmpty()) {
            ArrayList arraylist = Lists.newArrayList();
            Iterator iterator1 = this.loadedChunks.iterator();
            ArrayList arraylist1 = Lists.newArrayList();

            while (iterator1.hasNext() && arraylist.size() < 10) {
                ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)iterator1.next();
                if (chunkcoordintpair != null) {
                    if (this.worldObj.isBlockLoaded(new BlockPos(chunkcoordintpair.chunkXPos << 4, 0, chunkcoordintpair.chunkZPos << 4))) {
                        Chunk chunk = this.worldObj.getChunkFromChunkCoords(chunkcoordintpair.chunkXPos, chunkcoordintpair.chunkZPos);
                        if (chunk.isPopulated()) {
                            arraylist.add(chunk);
                            arraylist1.addAll(
                                ((WorldServer)this.worldObj)
                                    .getTileEntitiesIn(
                                        chunkcoordintpair.chunkXPos * 16,
                                        0,
                                        chunkcoordintpair.chunkZPos * 16,
                                        chunkcoordintpair.chunkXPos * 16 + 16,
                                        256,
                                        chunkcoordintpair.chunkZPos * 16 + 16
                                    )
                            );
                            iterator1.remove();
                        }
                    }
                } else {
                    iterator1.remove();
                }
            }

            if (!arraylist.isEmpty()) {
                if (arraylist.size() == 1) {
                    this.playerNetServerHandler.sendPacket(new S21PacketChunkData((Chunk)arraylist.get(0), true, 65535));
                } else {
                    this.playerNetServerHandler.sendPacket(new S26PacketMapChunkBulk(arraylist));
                }

                for (TileEntity tileentity : (Iterable<TileEntity>) (Iterable) arraylist1) {
                    this.sendTileEntityUpdate(tileentity);
                }

                for (Chunk chunk1 : (Iterable<Chunk>) (Iterable) arraylist) {
                    this.getServerForPlayer().getEntityTracker().func_85172_a(this, chunk1);
                }
            }
        }

        Entity entity = this.getSpectatingEntity();
        if (entity != this) {
            if (!entity.isEntityAlive()) {
                this.setSpectatingEntity(this);
            } else {
                this.setPositionAndRotation(entity.posX, entity.posY, entity.posZ, entity.rotationYaw, entity.rotationPitch);
                this.mcServer.getConfigurationManager().serverUpdateMountedMovingPlayer(this);
                if (this.isSneaking()) {
                    this.setSpectatingEntity(this);
                }
            }
        }
    }

    public void onUpdateEntity() {
        try {
            super.onUpdate();

            for (int i = 0; i < this.inventory.getSizeInventory(); i++) {
                ItemStack itemstack = this.inventory.getStackInSlot(i);
                if (itemstack != null && itemstack.getItem().isMap()) {
                    Packet packet = ((ItemMapBase)itemstack.getItem()).createMapDataPacket(itemstack, this.worldObj, this);
                    if (packet != null) {
                        this.playerNetServerHandler.sendPacket(packet);
                    }
                }
            }

            if (this.getHealth() != this.lastHealth
                || this.lastFoodLevel != this.foodStats.getFoodLevel()
                || this.foodStats.getSaturationLevel() == 0.0F != this.wasHungry) {
                this.playerNetServerHandler
                    .sendPacket(new S06PacketUpdateHealth(this.getHealth(), this.foodStats.getFoodLevel(), this.foodStats.getSaturationLevel()));
                this.lastHealth = this.getHealth();
                this.lastFoodLevel = this.foodStats.getFoodLevel();
                this.wasHungry = this.foodStats.getSaturationLevel() == 0.0F;
            }

            if (this.getHealth() + this.getAbsorptionAmount() != this.combinedHealth) {
                this.combinedHealth = this.getHealth() + this.getAbsorptionAmount();

                for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.getWorldScoreboard().getObjectivesFromCriteria(IScoreObjectiveCriteria.health)) {
                    this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective).func_96651_a(Arrays.asList(this));
                }
            }

            if (this.experienceTotal != this.lastExperience) {
                this.lastExperience = this.experienceTotal;
                this.playerNetServerHandler.sendPacket(new S1FPacketSetExperience(this.experience, this.experienceTotal, this.experienceLevel));
            }

            if (this.ticksExisted % 20 * 5 == 0 && !this.getStatFile().hasAchievementUnlocked(AchievementList.exploreAllBiomes)) {
                this.updateBiomesExplored();
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Ticking player");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Player being ticked");
            this.addEntityCrashInfo(crashreportcategory);
            throw new ReportedException(crashreport);
        }
    }

    protected void updateBiomesExplored() {
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(new BlockPos(MathHelper.floor_double(this.posX), 0, MathHelper.floor_double(this.posZ)));
        String s = biomegenbase.biomeName;
        JsonSerializableSet jsonserializableset = (JsonSerializableSet)this.getStatFile().func_150870_b(AchievementList.exploreAllBiomes);
        if (jsonserializableset == null) {
            jsonserializableset = (JsonSerializableSet)this.getStatFile().func_150872_a(AchievementList.exploreAllBiomes, new JsonSerializableSet());
        }

        jsonserializableset.add(s);
        if (this.getStatFile().canUnlockAchievement(AchievementList.exploreAllBiomes)
            && jsonserializableset.size() >= BiomeGenBase.explorationBiomesList.size()) {
            HashSet hashset = Sets.newHashSet(BiomeGenBase.explorationBiomesList);

            for (String s1 : (Iterable<String>) (Iterable) jsonserializableset) {
                Iterator iterator = hashset.iterator();

                while (iterator.hasNext()) {
                    BiomeGenBase biomegenbase1 = (BiomeGenBase)iterator.next();
                    if (biomegenbase1.biomeName.equals(s1)) {
                        iterator.remove();
                    }
                }

                if (hashset.isEmpty()) {
                    break;
                }
            }

            if (hashset.isEmpty()) {
                this.triggerAchievement(AchievementList.exploreAllBiomes);
            }
        }
    }

    @Override
    public void onDeath(DamageSource var1) {
        if (this.worldObj.getGameRules().getGameRuleBooleanValue("showDeathMessages")) {
            Team team = this.getTeam();
            if (team == null || team.getDeathMessageVisibility() == Team.EnumVisible.ALWAYS) {
                this.mcServer.getConfigurationManager().sendChatMsg(this.getCombatTracker().getDeathMessage());
            } else if (team.getDeathMessageVisibility() == Team.EnumVisible.HIDE_FOR_OTHER_TEAMS) {
                this.mcServer.getConfigurationManager().sendMessageToAllTeamMembers(this, this.getCombatTracker().getDeathMessage());
            } else if (team.getDeathMessageVisibility() == Team.EnumVisible.HIDE_FOR_OWN_TEAM) {
                this.mcServer.getConfigurationManager().sendMessageToTeamOrEvryPlayer(this, this.getCombatTracker().getDeathMessage());
            }
        }

        if (!this.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory")) {
            this.inventory.dropAllItems();
        }

        for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.worldObj.getScoreboard().getObjectivesFromCriteria(IScoreObjectiveCriteria.deathCount)) {
            Score score = this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective);
            score.func_96648_a();
        }

        EntityLivingBase entitylivingbase = this.func_94060_bK();
        if (entitylivingbase != null) {
            EntityList.EntityEggInfo entitylist$entityegginfo = (EntityList.EntityEggInfo)EntityList.entityEggs.get(EntityList.getEntityID(entitylivingbase));
            if (entitylist$entityegginfo != null) {
                this.triggerAchievement(entitylist$entityegginfo.field_151513_e);
            }

            entitylivingbase.addToPlayerScore(this, this.scoreValue);
        }

        this.triggerAchievement(StatList.deathsStat);
        this.func_175145_a(StatList.timeSinceDeathStat);
        this.getCombatTracker().reset();
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        boolean flag = this.mcServer.isDedicatedServer() && this.canPlayersAttack() && "fall".equals(var1.damageType);
        if (!flag && this.respawnInvulnerabilityTicks > 0 && var1 != DamageSource.outOfWorld) {
            return false;
        }

        if (var1 instanceof EntityDamageSource) {
            Entity entity = var1.getEntity();
            if (entity instanceof EntityPlayer && !this.canAttackPlayer((EntityPlayer)entity)) {
                return false;
            }

            if (entity instanceof EntityArrow) {
                EntityArrow entityarrow = (EntityArrow)entity;
                if (entityarrow.shootingEntity instanceof EntityPlayer && !this.canAttackPlayer((EntityPlayer)entityarrow.shootingEntity)) {
                    return false;
                }
            }
        }

        return super.attackEntityFrom(var1, var2);
    }

    @Override
    public boolean canAttackPlayer(EntityPlayer var1) {
        return !this.canPlayersAttack() ? false : super.canAttackPlayer(var1);
    }

    private boolean canPlayersAttack() {
        return this.mcServer.isPVPEnabled();
    }

    @Override
    public void travelToDimension(int var1) {
        if (this.dimension == 1 && var1 == 1) {
            this.triggerAchievement(AchievementList.theEnd2);
            this.worldObj.removeEntity(this);
            this.playerConqueredTheEnd = true;
            this.playerNetServerHandler.sendPacket(new S2BPacketChangeGameState(4, 0.0F));
        } else {
            if (this.dimension == 0 && var1 == 1) {
                this.triggerAchievement(AchievementList.theEnd);
                BlockPos blockpos = this.mcServer.worldServerForDimension(var1).getSpawnCoordinate();
                if (blockpos != null) {
                    this.playerNetServerHandler.setPlayerLocation(blockpos.getX(), blockpos.getY(), blockpos.getZ(), 0.0F, 0.0F);
                }

                var1 = 1;
            } else {
                this.triggerAchievement(AchievementList.portal);
            }

            this.mcServer.getConfigurationManager().transferPlayerToDimension(this, var1);
            this.lastExperience = -1;
            this.lastHealth = -1.0F;
            this.lastFoodLevel = -1;
        }
    }

    @Override
    public boolean isSpectatedByPlayer(EntityPlayerMP var1) {
        if (var1.isSpectator()) {
            return this.getSpectatingEntity() == this;
        } else {
            return this.isSpectator() ? false : super.isSpectatedByPlayer(var1);
        }
    }

    private void sendTileEntityUpdate(TileEntity var1) {
        if (var1 != null) {
            Packet packet = var1.getDescriptionPacket();
            if (packet != null) {
                this.playerNetServerHandler.sendPacket(packet);
            }
        }
    }

    @Override
    public void onItemPickup(Entity var1, int var2) {
        super.onItemPickup(var1, var2);
        this.openContainer.detectAndSendChanges();
    }

    @Override
    public EntityPlayer.EnumStatus trySleep(BlockPos var1) {
        EntityPlayer.EnumStatus entityplayer$enumstatus = super.trySleep(var1);
        if (entityplayer$enumstatus == EntityPlayer.EnumStatus.OK) {
            S0APacketUseBed s0apacketusebed = new S0APacketUseBed(this, var1);
            this.getServerForPlayer().getEntityTracker().sendToAllTrackingEntity(this, s0apacketusebed);
            this.playerNetServerHandler.setPlayerLocation(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
            this.playerNetServerHandler.sendPacket(s0apacketusebed);
        }

        return entityplayer$enumstatus;
    }

    @Override
    public void wakeUpPlayer(boolean var1, boolean var2, boolean var3) {
        if (this.isPlayerSleeping()) {
            this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(this, 2));
        }

        super.wakeUpPlayer(var1, var2, var3);
        if (this.playerNetServerHandler != null) {
            this.playerNetServerHandler.setPlayerLocation(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
        }
    }

    @Override
    public void mountEntity(Entity var1) {
        Entity entity = this.ridingEntity;
        super.mountEntity(var1);
        if (var1 != entity) {
            this.playerNetServerHandler.sendPacket(new S1BPacketEntityAttach(0, this, this.ridingEntity));
            this.playerNetServerHandler.setPlayerLocation(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
        }
    }

    @Override
    protected void updateFallState(double var1, boolean var3, Block var4, BlockPos var5) {
    }

    public void handleFalling(double var1, boolean var3) {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posY - 0.2F);
        int k = MathHelper.floor_double(this.posZ);
        BlockPos blockpos = new BlockPos(i, j, k);
        Block block = this.worldObj.getBlockState(blockpos).getBlock();
        if (block.getMaterial() == Material.air) {
            Block block1 = this.worldObj.getBlockState(blockpos.down()).getBlock();
            if (block1 instanceof BlockFence || block1 instanceof BlockWall || block1 instanceof BlockFenceGate) {
                blockpos = blockpos.down();
                block = this.worldObj.getBlockState(blockpos).getBlock();
            }
        }

        super.updateFallState(var1, var3, block, blockpos);
    }

    @Override
    public void openEditSign(TileEntitySign var1) {
        var1.setPlayer(this);
        this.playerNetServerHandler.sendPacket(new S36PacketSignEditorOpen(var1.getPos()));
    }

    private void getNextWindowId() {
        this.currentWindowId = this.currentWindowId % 100 + 1;
    }

    @Override
    public void displayGui(IInteractionObject var1) {
        this.getNextWindowId();
        this.playerNetServerHandler.sendPacket(new S2DPacketOpenWindow(this.currentWindowId, var1.getGuiID(), var1.getDisplayName()));
        this.openContainer = var1.createContainer(this.inventory, this);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayGUIChest(IInventory var1) {
        if (this.openContainer != this.inventoryContainer) {
            this.closeScreen();
        }

        if (var1 instanceof ILockableContainer) {
            ILockableContainer ilockablecontainer = (ILockableContainer)var1;
            if (ilockablecontainer.isLocked() && !this.canOpen(ilockablecontainer.getLockCode()) && !this.isSpectator()) {
                this.playerNetServerHandler.sendPacket(new S02PacketChat(new ChatComponentTranslation("container.isLocked", var1.getDisplayName()), (byte)2));
                this.playerNetServerHandler.sendPacket(new S29PacketSoundEffect("random.door_close", this.posX, this.posY, this.posZ, 1.0F, 1.0F));
                return;
            }
        }

        this.getNextWindowId();
        if (var1 instanceof IInteractionObject) {
            this.playerNetServerHandler
                .sendPacket(
                    new S2DPacketOpenWindow(this.currentWindowId, ((IInteractionObject)var1).getGuiID(), var1.getDisplayName(), var1.getSizeInventory())
                );
            this.openContainer = ((IInteractionObject)var1).createContainer(this.inventory, this);
        } else {
            this.playerNetServerHandler
                .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, "minecraft:container", var1.getDisplayName(), var1.getSizeInventory()));
            this.openContainer = new ContainerChest(this.inventory, var1, this);
        }

        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayVillagerTradeGui(IMerchant var1) {
        this.getNextWindowId();
        this.openContainer = new ContainerMerchant(this.inventory, var1, this.worldObj);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
        InventoryMerchant inventorymerchant = ((ContainerMerchant)this.openContainer).getMerchantInventory();
        IChatComponent ichatcomponent = var1.getDisplayName();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, "minecraft:villager", ichatcomponent, inventorymerchant.getSizeInventory()));
        MerchantRecipeList merchantrecipelist = var1.getRecipes(this);
        if (merchantrecipelist != null) {
            PacketBuffer packetbuffer = new PacketBuffer(Unpooled.buffer());
            packetbuffer.writeInt(this.currentWindowId);
            merchantrecipelist.writeToBuf(packetbuffer);
            this.playerNetServerHandler.sendPacket(new S3FPacketCustomPayload("MC|TrList", packetbuffer));
        }
    }

    @Override
    public void displayGUIHorse(EntityHorse var1, IInventory var2) {
        if (this.openContainer != this.inventoryContainer) {
            this.closeScreen();
        }

        this.getNextWindowId();
        this.playerNetServerHandler
            .sendPacket(new S2DPacketOpenWindow(this.currentWindowId, "EntityHorse", var2.getDisplayName(), var2.getSizeInventory(), var1.getEntityId()));
        this.openContainer = new ContainerHorseInventory(this.inventory, var2, var1, this);
        this.openContainer.windowId = this.currentWindowId;
        this.openContainer.onCraftGuiOpened(this);
    }

    @Override
    public void displayGUIBook(ItemStack var1) {
        Item item = var1.getItem();
        if (item == Items.written_book) {
            this.playerNetServerHandler.sendPacket(new S3FPacketCustomPayload("MC|BOpen", new PacketBuffer(Unpooled.buffer())));
        }
    }

    @Override
    public void sendSlotContents(Container var1, int var2, ItemStack var3) {
        if (!(var1.getSlot(var2) instanceof SlotCrafting)) {
            if (!this.isChangingQuantityOnly) {
                this.playerNetServerHandler.sendPacket(new S2FPacketSetSlot(var1.windowId, var2, var3));
            }
        }
    }

    public void sendContainerToPlayer(Container var1) {
        this.updateCraftingInventory(var1, var1.getInventory());
    }

    @Override
    public void updateCraftingInventory(Container var1, List var2) {
        this.playerNetServerHandler.sendPacket(new S30PacketWindowItems(var1.windowId, var2));
        this.playerNetServerHandler.sendPacket(new S2FPacketSetSlot(-1, -1, this.inventory.getItemStack()));
    }

    @Override
    public void sendProgressBarUpdate(Container var1, int var2, int var3) {
        this.playerNetServerHandler.sendPacket(new S31PacketWindowProperty(var1.windowId, var2, var3));
    }

    @Override
    public void func_175173_a(Container var1, IInventory var2) {
        for (int i = 0; i < var2.getFieldCount(); i++) {
            this.playerNetServerHandler.sendPacket(new S31PacketWindowProperty(var1.windowId, i, var2.getField(i)));
        }
    }

    @Override
    public void closeScreen() {
        this.playerNetServerHandler.sendPacket(new S2EPacketCloseWindow(this.openContainer.windowId));
        this.closeContainer();
    }

    public void updateHeldItem() {
        if (!this.isChangingQuantityOnly) {
            this.playerNetServerHandler.sendPacket(new S2FPacketSetSlot(-1, -1, this.inventory.getItemStack()));
        }
    }

    public void closeContainer() {
        this.openContainer.onContainerClosed(this);
        this.openContainer = this.inventoryContainer;
    }

    public void setEntityActionState(float var1, float var2, boolean var3, boolean var4) {
        if (this.ridingEntity != null) {
            if (var1 >= -1.0F && var1 <= 1.0F) {
                this.moveStrafing = var1;
            }

            if (var2 >= -1.0F && var2 <= 1.0F) {
                this.moveForward = var2;
            }

            this.isJumping = var3;
            this.setSneaking(var4);
        }
    }

    @Override
    public void addStat(StatBase var1, int var2) {
        if (var1 != null) {
            this.statsFile.increaseStat(this, var1, var2);

            for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.getWorldScoreboard().getObjectivesFromCriteria(var1.func_150952_k())) {
                this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective).increseScore(var2);
            }

            if (this.statsFile.func_150879_e()) {
                this.statsFile.func_150876_a(this);
            }
        }
    }

    @Override
    public void func_175145_a(StatBase var1) {
        if (var1 != null) {
            this.statsFile.unlockAchievement(this, var1, 0);

            for (ScoreObjective scoreobjective : (Iterable<ScoreObjective>) (Iterable) this.getWorldScoreboard().getObjectivesFromCriteria(var1.func_150952_k())) {
                this.getWorldScoreboard().getValueFromObjective(this.getCommandSenderName(), scoreobjective).setScorePoints(0);
            }

            if (this.statsFile.func_150879_e()) {
                this.statsFile.func_150876_a(this);
            }
        }
    }

    public void mountEntityAndWakeUp() {
        if (this.riddenByEntity != null) {
            this.riddenByEntity.mountEntity(this);
        }

        if (this.sleeping) {
            this.wakeUpPlayer(true, false, false);
        }
    }

    public void setPlayerHealthUpdated() {
        this.lastHealth = -1.0E8F;
    }

    @Override
    public void addChatComponentMessage(IChatComponent var1) {
        this.playerNetServerHandler.sendPacket(new S02PacketChat(var1));
    }

    @Override
    protected void onItemUseFinish() {
        this.playerNetServerHandler.sendPacket(new S19PacketEntityStatus(this, (byte)9));
        super.onItemUseFinish();
    }

    @Override
    public void setItemInUse(ItemStack var1, int var2) {
        super.setItemInUse(var1, var2);
        if (var1 != null && var1.getItem() != null && var1.getItem().getItemUseAction(var1) == EnumAction.EAT) {
            this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(this, 3));
        }
    }

    @Override
    public void clonePlayer(EntityPlayer var1, boolean var2) {
        super.clonePlayer(var1, var2);
        this.lastExperience = -1;
        this.lastHealth = -1.0F;
        this.lastFoodLevel = -1;
        this.destroyedItemsNetCache.addAll(((EntityPlayerMP)var1).destroyedItemsNetCache);
    }

    @Override
    protected void onNewPotionEffect(PotionEffect var1) {
        super.onNewPotionEffect(var1);
        this.playerNetServerHandler.sendPacket(new S1DPacketEntityEffect(this.getEntityId(), var1));
    }

    @Override
    protected void onChangedPotionEffect(PotionEffect var1, boolean var2) {
        super.onChangedPotionEffect(var1, var2);
        this.playerNetServerHandler.sendPacket(new S1DPacketEntityEffect(this.getEntityId(), var1));
    }

    @Override
    protected void onFinishedPotionEffect(PotionEffect var1) {
        super.onFinishedPotionEffect(var1);
        this.playerNetServerHandler.sendPacket(new S1EPacketRemoveEntityEffect(this.getEntityId(), var1));
    }

    @Override
    public void setPositionAndUpdate(double var1, double var3, double var5) {
        this.playerNetServerHandler.setPlayerLocation(var1, var3, var5, this.rotationYaw, this.rotationPitch);
    }

    @Override
    public void onCriticalHit(Entity var1) {
        this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(var1, 4));
    }

    @Override
    public void onEnchantmentCritical(Entity var1) {
        this.getServerForPlayer().getEntityTracker().func_151248_b(this, new S0BPacketAnimation(var1, 5));
    }

    @Override
    public void sendPlayerAbilities() {
        if (this.playerNetServerHandler != null) {
            this.playerNetServerHandler.sendPacket(new S39PacketPlayerAbilities(this.capabilities));
            this.updatePotionMetadata();
        }
    }

    public WorldServer getServerForPlayer() {
        return (WorldServer)this.worldObj;
    }

    @Override
    public void setGameType(WorldSettings.GameType var1) {
        this.theItemInWorldManager.setGameType(var1);
        this.playerNetServerHandler.sendPacket(new S2BPacketChangeGameState(3, var1.getID()));
        if (var1 == WorldSettings.GameType.SPECTATOR) {
            this.mountEntity(null);
        } else {
            this.setSpectatingEntity(this);
        }

        this.sendPlayerAbilities();
        this.markPotionsDirty();
    }

    @Override
    public boolean isSpectator() {
        return this.theItemInWorldManager.getGameType() == WorldSettings.GameType.SPECTATOR;
    }

    @Override
    public void addChatMessage(IChatComponent var1) {
        this.playerNetServerHandler.sendPacket(new S02PacketChat(var1));
    }

    @Override
    public boolean canCommandSenderUseCommand(int var1, String var2) {
        if ("seed".equals(var2) && !this.mcServer.isDedicatedServer()) {
            return true;
        }

        if (!"tell".equals(var2) && !"help".equals(var2) && !"me".equals(var2) && !"trigger".equals(var2)) {
            if (this.mcServer.getConfigurationManager().canSendCommands(this.getGameProfile())) {
                UserListOpsEntry userlistopsentry = (UserListOpsEntry)this.mcServer.getConfigurationManager().getOppedPlayers().getEntry(this.getGameProfile());
                return userlistopsentry != null ? userlistopsentry.getPermissionLevel() >= var1 : this.mcServer.getOpPermissionLevel() >= var1;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    public String getPlayerIP() {
        String s = this.playerNetServerHandler.netManager.getRemoteAddress().toString();
        s = s.substring(s.indexOf("/") + 1);
        return s.substring(0, s.indexOf(":"));
    }

    public void handleClientSettings(C15PacketClientSettings var1) {
        this.translator = var1.getLang();
        this.chatVisibility = var1.getChatVisibility();
        this.chatColours = var1.isColorsEnabled();
        this.getDataWatcher().updateObject(10, (byte)var1.getModelPartFlags());
    }

    public EntityPlayer.EnumChatVisibility getChatVisibility() {
        return this.chatVisibility;
    }

    public void loadResourcePack(String var1, String var2) {
        this.playerNetServerHandler.sendPacket(new S48PacketResourcePackSend(var1, var2));
    }

    @Override
    public BlockPos getPosition() {
        return new BlockPos(this.posX, this.posY + 0.5, this.posZ);
    }

    public void markPlayerActive() {
        this.playerLastActiveTime = MinecraftServer.getCurrentTimeMillis();
    }

    public StatisticsFile getStatFile() {
        return this.statsFile;
    }

    public void removeEntity(Entity var1) {
        if (var1 instanceof EntityPlayer) {
            this.playerNetServerHandler.sendPacket(new S13PacketDestroyEntities(var1.getEntityId()));
        } else {
            this.destroyedItemsNetCache.add(var1.getEntityId());
        }
    }

    @Override
    protected void updatePotionMetadata() {
        if (this.isSpectator()) {
            this.resetPotionEffectMetadata();
            this.setInvisible(true);
        } else {
            super.updatePotionMetadata();
        }

        this.getServerForPlayer().getEntityTracker().func_180245_a(this);
    }

    public Entity getSpectatingEntity() {
        return this.spectatingEntity == null ? this : this.spectatingEntity;
    }

    public void setSpectatingEntity(Entity var1) {
        Entity entity = this.getSpectatingEntity();
        this.spectatingEntity = var1 == null ? this : var1;
        if (entity != this.spectatingEntity) {
            this.playerNetServerHandler.sendPacket(new S43PacketCamera(this.spectatingEntity));
            this.setPositionAndUpdate(this.spectatingEntity.posX, this.spectatingEntity.posY, this.spectatingEntity.posZ);
        }
    }

    @Override
    public void attackTargetEntityWithCurrentItem(Entity var1) {
        if (this.theItemInWorldManager.getGameType() == WorldSettings.GameType.SPECTATOR) {
            this.setSpectatingEntity(var1);
        } else {
            super.attackTargetEntityWithCurrentItem(var1);
        }
    }

    public long getLastActiveTime() {
        return this.playerLastActiveTime;
    }

    public IChatComponent getTabListDisplayName() {
        return null;
    }
}
