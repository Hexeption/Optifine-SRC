package net.minecraft.entity;

import net.minecraft.block.Block;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public abstract class EntityFlying extends EntityLiving {
    public EntityFlying(World var1) {
        super(var1);
    }

    @Override
    public void fall(float var1, float var2) {
    }

    @Override
    protected void updateFallState(double var1, boolean var3, Block var4, BlockPos var5) {
    }

    @Override
    public void moveEntityWithHeading(float var1, float var2) {
        if (this.isInWater()) {
            this.moveFlying(var1, var2, 0.02F);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.8F;
            this.motionY *= 0.8F;
            this.motionZ *= 0.8F;
        } else if (this.isInLava()) {
            this.moveFlying(var1, var2, 0.02F);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.5;
            this.motionY *= 0.5;
            this.motionZ *= 0.5;
        } else {
            float f = 0.91F;
            if (this.onGround) {
                f = this.worldObj
                        .getBlockState(
                            new BlockPos(
                                MathHelper.floor_double(this.posX),
                                MathHelper.floor_double(this.getEntityBoundingBox().minY) - 1,
                                MathHelper.floor_double(this.posZ)
                            )
                        )
                        .getBlock()
                        .slipperiness
                    * 0.91F;
            }

            float f1 = 0.16277136F / (f * f * f);
            this.moveFlying(var1, var2, this.onGround ? 0.1F * f1 : 0.02F);
            f = 0.91F;
            if (this.onGround) {
                f = this.worldObj
                        .getBlockState(
                            new BlockPos(
                                MathHelper.floor_double(this.posX),
                                MathHelper.floor_double(this.getEntityBoundingBox().minY) - 1,
                                MathHelper.floor_double(this.posZ)
                            )
                        )
                        .getBlock()
                        .slipperiness
                    * 0.91F;
            }

            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= f;
            this.motionY *= f;
            this.motionZ *= f;
        }

        this.prevLimbSwingAmount = this.limbSwingAmount;
        double d1 = this.posX - this.prevPosX;
        double d0 = this.posZ - this.prevPosZ;
        float f2 = MathHelper.sqrt_double(d1 * d1 + d0 * d0) * 4.0F;
        if (f2 > 1.0F) {
            f2 = 1.0F;
        }

        this.limbSwingAmount = this.limbSwingAmount + (f2 - this.limbSwingAmount) * 0.4F;
        this.limbSwing = this.limbSwing + this.limbSwingAmount;
    }

    @Override
    public boolean isOnLadder() {
        return false;
    }
}
