package net.minecraft.entity;

import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Callable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockWall;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.CommandResultStats;
import net.minecraft.command.ICommandSender;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentProtection;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.event.HoverEvent;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ReportedException;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Vec3;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public abstract class Entity implements ICommandSender {
    private static final AxisAlignedBB ZERO_AABB = new AxisAlignedBB(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
    private static int nextEntityID;
    private int entityId;
    public double renderDistanceWeight;
    public boolean preventEntitySpawning;
    public Entity riddenByEntity;
    public Entity ridingEntity;
    public boolean forceSpawn;
    public World worldObj;
    public double prevPosX;
    public double prevPosY;
    public double prevPosZ;
    public double posX;
    public double posY;
    public double posZ;
    public double motionX;
    public double motionY;
    public double motionZ;
    public float rotationYaw;
    public float rotationPitch;
    public float prevRotationYaw;
    public float prevRotationPitch;
    private AxisAlignedBB boundingBox;
    public boolean onGround;
    public boolean isCollidedHorizontally;
    public boolean isCollidedVertically;
    public boolean isCollided;
    public boolean velocityChanged;
    protected boolean isInWeb;
    private boolean isOutsideBorder;
    public boolean isDead;
    public float width;
    public float height;
    public float prevDistanceWalkedModified;
    public float distanceWalkedModified;
    public float distanceWalkedOnStepModified;
    public float fallDistance;
    private int nextStepDistance;
    public double lastTickPosX;
    public double lastTickPosY;
    public double lastTickPosZ;
    public float stepHeight;
    public boolean noClip;
    public float entityCollisionReduction;
    protected Random rand;
    public int ticksExisted;
    public int fireResistance;
    private int fire;
    protected boolean inWater;
    public int hurtResistantTime;
    protected boolean firstUpdate;
    protected boolean isImmuneToFire;
    protected DataWatcher dataWatcher;
    private double entityRiderPitchDelta;
    private double entityRiderYawDelta;
    public boolean addedToChunk;
    public int chunkCoordX;
    public int chunkCoordY;
    public int chunkCoordZ;
    public int serverPosX;
    public int serverPosY;
    public int serverPosZ;
    public boolean ignoreFrustumCheck;
    public boolean isAirBorne;
    public int timeUntilPortal;
    protected boolean inPortal;
    protected int portalCounter;
    public int dimension;
    protected int teleportDirection;
    private boolean invulnerable;
    protected UUID entityUniqueID;
    private final CommandResultStats cmdResultStats;

    public int getEntityId() {
        return this.entityId;
    }

    public void setEntityId(int var1) {
        this.entityId = var1;
    }

    public void onKillCommand() {
        this.setDead();
    }

    public Entity(World var1) {
        this.entityId = nextEntityID++;
        this.renderDistanceWeight = 1.0;
        this.boundingBox = ZERO_AABB;
        this.width = 0.6F;
        this.height = 1.8F;
        this.nextStepDistance = 1;
        this.rand = new Random();
        this.fireResistance = 1;
        this.firstUpdate = true;
        this.entityUniqueID = MathHelper.getRandomUuid(this.rand);
        this.cmdResultStats = new CommandResultStats();
        this.worldObj = var1;
        this.setPosition(0.0, 0.0, 0.0);
        if (var1 != null) {
            this.dimension = var1.provider.getDimensionId();
        }

        this.dataWatcher = new DataWatcher(this);
        this.dataWatcher.addObject(0, (byte)0);
        this.dataWatcher.addObject(1, (short)300);
        this.dataWatcher.addObject(3, (byte)0);
        this.dataWatcher.addObject(2, "");
        this.dataWatcher.addObject(4, (byte)0);
        this.entityInit();
    }

    protected abstract void entityInit();

    public DataWatcher getDataWatcher() {
        return this.dataWatcher;
    }

    @Override
    public boolean equals(Object var1) {
        return var1 instanceof Entity ? ((Entity)var1).entityId == this.entityId : false;
    }

    @Override
    public int hashCode() {
        return this.entityId;
    }

    protected void preparePlayerToSpawn() {
        if (this.worldObj != null) {
            while (this.posY > 0.0 && this.posY < 256.0) {
                this.setPosition(this.posX, this.posY, this.posZ);
                if (this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox()).isEmpty()) {
                    break;
                }

                this.posY++;
            }

            this.motionX = this.motionY = this.motionZ = 0.0;
            this.rotationPitch = 0.0F;
        }
    }

    public void setDead() {
        this.isDead = true;
    }

    protected void setSize(float var1, float var2) {
        if (var1 != this.width || var2 != this.height) {
            float f = this.width;
            this.width = var1;
            this.height = var2;
            this.setEntityBoundingBox(
                new AxisAlignedBB(
                    this.getEntityBoundingBox().minX,
                    this.getEntityBoundingBox().minY,
                    this.getEntityBoundingBox().minZ,
                    this.getEntityBoundingBox().minX + this.width,
                    this.getEntityBoundingBox().minY + this.height,
                    this.getEntityBoundingBox().minZ + this.width
                )
            );
            if (this.width > f && !this.firstUpdate && !this.worldObj.isRemote) {
                this.moveEntity(f - this.width, 0.0, f - this.width);
            }
        }
    }

    protected void setRotation(float var1, float var2) {
        this.rotationYaw = var1 % 360.0F;
        this.rotationPitch = var2 % 360.0F;
    }

    public void setPosition(double var1, double var3, double var5) {
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        float f = this.width / 2.0F;
        float f1 = this.height;
        this.setEntityBoundingBox(new AxisAlignedBB(var1 - f, var3, var5 - f, var1 + f, var3 + f1, var5 + f));
    }

    public void setAngles(float var1, float var2) {
        float f = this.rotationPitch;
        float f1 = this.rotationYaw;
        this.rotationYaw = (float)(this.rotationYaw + var1 * 0.15);
        this.rotationPitch = (float)(this.rotationPitch - var2 * 0.15);
        this.rotationPitch = MathHelper.clamp_float(this.rotationPitch, -90.0F, 90.0F);
        this.prevRotationPitch = this.prevRotationPitch + (this.rotationPitch - f);
        this.prevRotationYaw = this.prevRotationYaw + (this.rotationYaw - f1);
    }

    public void onUpdate() {
        this.onEntityUpdate();
    }

    public void onEntityUpdate() {
        this.worldObj.theProfiler.startSection("entityBaseTick");
        if (this.ridingEntity != null && this.ridingEntity.isDead) {
            this.ridingEntity = null;
        }

        this.prevDistanceWalkedModified = this.distanceWalkedModified;
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.prevRotationPitch = this.rotationPitch;
        this.prevRotationYaw = this.rotationYaw;
        if (!this.worldObj.isRemote && this.worldObj instanceof WorldServer) {
            this.worldObj.theProfiler.startSection("portal");
            MinecraftServer minecraftserver = ((WorldServer)this.worldObj).getMinecraftServer();
            int i = this.getMaxInPortalTime();
            if (this.inPortal) {
                if (minecraftserver.getAllowNether()) {
                    if (this.ridingEntity == null && this.portalCounter++ >= i) {
                        this.portalCounter = i;
                        this.timeUntilPortal = this.getPortalCooldown();
                        byte b0;
                        if (this.worldObj.provider.getDimensionId() == -1) {
                            b0 = 0;
                        } else {
                            b0 = -1;
                        }

                        this.travelToDimension(b0);
                    }

                    this.inPortal = false;
                }
            } else {
                if (this.portalCounter > 0) {
                    this.portalCounter -= 4;
                }

                if (this.portalCounter < 0) {
                    this.portalCounter = 0;
                }
            }

            if (this.timeUntilPortal > 0) {
                this.timeUntilPortal--;
            }

            this.worldObj.theProfiler.endSection();
        }

        this.spawnRunningParticles();
        this.handleWaterMovement();
        if (this.worldObj.isRemote) {
            this.fire = 0;
        } else if (this.fire > 0) {
            if (this.isImmuneToFire) {
                this.fire -= 4;
                if (this.fire < 0) {
                    this.fire = 0;
                }
            } else {
                if (this.fire % 20 == 0) {
                    this.attackEntityFrom(DamageSource.onFire, 1.0F);
                }

                this.fire--;
            }
        }

        if (this.isInLava()) {
            this.setOnFireFromLava();
            this.fallDistance *= 0.5F;
        }

        if (this.posY < -64.0) {
            this.kill();
        }

        if (!this.worldObj.isRemote) {
            this.setFlag(0, this.fire > 0);
        }

        this.firstUpdate = false;
        this.worldObj.theProfiler.endSection();
    }

    public int getMaxInPortalTime() {
        return 0;
    }

    protected void setOnFireFromLava() {
        if (!this.isImmuneToFire) {
            this.attackEntityFrom(DamageSource.lava, 4.0F);
            this.setFire(15);
        }
    }

    public void setFire(int var1) {
        int i = var1 * 20;
        i = EnchantmentProtection.getFireTimeForEntity(this, i);
        if (this.fire < i) {
            this.fire = i;
        }
    }

    public void extinguish() {
        this.fire = 0;
    }

    protected void kill() {
        this.setDead();
    }

    public boolean isOffsetPositionInLiquid(double var1, double var3, double var5) {
        AxisAlignedBB axisalignedbb = this.getEntityBoundingBox().offset(var1, var3, var5);
        return this.isLiquidPresentInAABB(axisalignedbb);
    }

    private boolean isLiquidPresentInAABB(AxisAlignedBB var1) {
        return this.worldObj.getCollidingBoundingBoxes(this, var1).isEmpty() && !this.worldObj.isAnyLiquid(var1);
    }

    public void moveEntity(double var1, double var3, double var5) {
        if (this.noClip) {
            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(var1, var3, var5));
            this.resetPositionToBB();
        } else {
            this.worldObj.theProfiler.startSection("move");
            double d0 = this.posX;
            double d1 = this.posY;
            double d2 = this.posZ;
            if (this.isInWeb) {
                this.isInWeb = false;
                var1 *= 0.25;
                var3 *= 0.05F;
                var5 *= 0.25;
                this.motionX = 0.0;
                this.motionY = 0.0;
                this.motionZ = 0.0;
            }

            double d3 = var1;
            double d4 = var3;
            double d5 = var5;
            boolean flag = this.onGround && this.isSneaking() && this instanceof EntityPlayer;
            if (flag) {
                double d6 = 0.05;

                while (var1 != 0.0 && this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().offset(var1, -1.0, 0.0)).isEmpty()) {
                    if (var1 < d6 && var1 >= -d6) {
                        var1 = 0.0;
                    } else if (var1 > 0.0) {
                        var1 -= d6;
                    } else {
                        var1 += d6;
                    }

                    d3 = var1;
                }

                for (; var5 != 0.0 && this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().offset(0.0, -1.0, var5)).isEmpty(); d5 = var5) {
                    if (var5 < d6 && var5 >= -d6) {
                        var5 = 0.0;
                    } else if (var5 > 0.0) {
                        var5 -= d6;
                    } else {
                        var5 += d6;
                    }
                }

                for (;
                    var1 != 0.0 && var5 != 0.0 && this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().offset(var1, -1.0, var5)).isEmpty();
                    d5 = var5
                ) {
                    if (var1 < d6 && var1 >= -d6) {
                        var1 = 0.0;
                    } else if (var1 > 0.0) {
                        var1 -= d6;
                    } else {
                        var1 += d6;
                    }

                    d3 = var1;
                    if (var5 < d6 && var5 >= -d6) {
                        var5 = 0.0;
                    } else if (var5 > 0.0) {
                        var5 -= d6;
                    } else {
                        var5 += d6;
                    }
                }
            }

            List list1 = this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().addCoord(var1, var3, var5));
            AxisAlignedBB axisalignedbb = this.getEntityBoundingBox();

            for (AxisAlignedBB axisalignedbb1 : (Iterable<AxisAlignedBB>) (Iterable) list1) {
                var3 = axisalignedbb1.calculateYOffset(this.getEntityBoundingBox(), var3);
            }

            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(0.0, var3, 0.0));
            boolean flag1 = this.onGround || d4 != var3 && d4 < 0.0;

            for (AxisAlignedBB axisalignedbb2 : (Iterable<AxisAlignedBB>) (Iterable) list1) {
                var1 = axisalignedbb2.calculateXOffset(this.getEntityBoundingBox(), var1);
            }

            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(var1, 0.0, 0.0));

            for (AxisAlignedBB axisalignedbb13 : (Iterable<AxisAlignedBB>) (Iterable) list1) {
                var5 = axisalignedbb13.calculateZOffset(this.getEntityBoundingBox(), var5);
            }

            this.setEntityBoundingBox(this.getEntityBoundingBox().offset(0.0, 0.0, var5));
            if (this.stepHeight > 0.0F && flag1 && (d3 != var1 || d5 != var5)) {
                double d11 = var1;
                double d7 = var3;
                double d8 = var5;
                AxisAlignedBB axisalignedbb3 = this.getEntityBoundingBox();
                this.setEntityBoundingBox(axisalignedbb);
                var1 = d3;
                var3 = this.stepHeight;
                var5 = d5;
                List list = this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().addCoord(var1, var3, var5));
                AxisAlignedBB axisalignedbb4 = this.getEntityBoundingBox();
                AxisAlignedBB axisalignedbb5 = axisalignedbb4.addCoord(var1, 0.0, var5);
                double d9 = var3;

                for (AxisAlignedBB axisalignedbb6 : (Iterable<AxisAlignedBB>) (Iterable) list) {
                    d9 = axisalignedbb6.calculateYOffset(axisalignedbb5, d9);
                }

                axisalignedbb4 = axisalignedbb4.offset(0.0, d9, 0.0);
                double d15 = var1;

                for (AxisAlignedBB axisalignedbb7 : (Iterable<AxisAlignedBB>) (Iterable) list) {
                    d15 = axisalignedbb7.calculateXOffset(axisalignedbb4, d15);
                }

                axisalignedbb4 = axisalignedbb4.offset(d15, 0.0, 0.0);
                double d16 = var5;

                for (AxisAlignedBB axisalignedbb8 : (Iterable<AxisAlignedBB>) (Iterable) list) {
                    d16 = axisalignedbb8.calculateZOffset(axisalignedbb4, d16);
                }

                axisalignedbb4 = axisalignedbb4.offset(0.0, 0.0, d16);
                AxisAlignedBB axisalignedbb14 = this.getEntityBoundingBox();
                double d17 = var3;

                for (AxisAlignedBB axisalignedbb9 : (Iterable<AxisAlignedBB>) (Iterable) list) {
                    d17 = axisalignedbb9.calculateYOffset(axisalignedbb14, d17);
                }

                axisalignedbb14 = axisalignedbb14.offset(0.0, d17, 0.0);
                double d18 = var1;

                for (AxisAlignedBB axisalignedbb10 : (Iterable<AxisAlignedBB>) (Iterable) list) {
                    d18 = axisalignedbb10.calculateXOffset(axisalignedbb14, d18);
                }

                axisalignedbb14 = axisalignedbb14.offset(d18, 0.0, 0.0);
                double d19 = var5;

                for (AxisAlignedBB axisalignedbb11 : (Iterable<AxisAlignedBB>) (Iterable) list) {
                    d19 = axisalignedbb11.calculateZOffset(axisalignedbb14, d19);
                }

                axisalignedbb14 = axisalignedbb14.offset(0.0, 0.0, d19);
                double d20 = d15 * d15 + d16 * d16;
                double d10 = d18 * d18 + d19 * d19;
                if (d20 > d10) {
                    var1 = d15;
                    var5 = d16;
                    this.setEntityBoundingBox(axisalignedbb4);
                } else {
                    var1 = d18;
                    var5 = d19;
                    this.setEntityBoundingBox(axisalignedbb14);
                }

                var3 = -this.stepHeight;

                for (AxisAlignedBB axisalignedbb12 : (Iterable<AxisAlignedBB>) (Iterable) list) {
                    var3 = axisalignedbb12.calculateYOffset(this.getEntityBoundingBox(), var3);
                }

                this.setEntityBoundingBox(this.getEntityBoundingBox().offset(0.0, var3, 0.0));
                if (d11 * d11 + d8 * d8 >= var1 * var1 + var5 * var5) {
                    var1 = d11;
                    var3 = d7;
                    var5 = d8;
                    this.setEntityBoundingBox(axisalignedbb3);
                }
            }

            this.worldObj.theProfiler.endSection();
            this.worldObj.theProfiler.startSection("rest");
            this.resetPositionToBB();
            this.isCollidedHorizontally = d3 != var1 || d5 != var5;
            this.isCollidedVertically = d4 != var3;
            this.onGround = this.isCollidedVertically && d4 < 0.0;
            this.isCollided = this.isCollidedHorizontally || this.isCollidedVertically;
            int i = MathHelper.floor_double(this.posX);
            int j = MathHelper.floor_double(this.posY - 0.2F);
            int k = MathHelper.floor_double(this.posZ);
            BlockPos blockpos = new BlockPos(i, j, k);
            Block block1 = this.worldObj.getBlockState(blockpos).getBlock();
            if (block1.getMaterial() == Material.air) {
                Block block = this.worldObj.getBlockState(blockpos.down()).getBlock();
                if (block instanceof BlockFence || block instanceof BlockWall || block instanceof BlockFenceGate) {
                    block1 = block;
                    blockpos = blockpos.down();
                }
            }

            this.updateFallState(var3, this.onGround, block1, blockpos);
            if (d3 != var1) {
                this.motionX = 0.0;
            }

            if (d5 != var5) {
                this.motionZ = 0.0;
            }

            if (d4 != var3) {
                block1.onLanded(this.worldObj, this);
            }

            if (this.canTriggerWalking() && !flag && this.ridingEntity == null) {
                double d12 = this.posX - d0;
                double d13 = this.posY - d1;
                double d14 = this.posZ - d2;
                if (block1 != Blocks.ladder) {
                    d13 = 0.0;
                }

                if (block1 != null && this.onGround) {
                    block1.onEntityCollidedWithBlock(this.worldObj, blockpos, this);
                }

                this.distanceWalkedModified = (float)(this.distanceWalkedModified + MathHelper.sqrt_double(d12 * d12 + d14 * d14) * 0.6);
                this.distanceWalkedOnStepModified = (float)(this.distanceWalkedOnStepModified + MathHelper.sqrt_double(d12 * d12 + d13 * d13 + d14 * d14) * 0.6);
                if (this.distanceWalkedOnStepModified > this.nextStepDistance && block1.getMaterial() != Material.air) {
                    this.nextStepDistance = (int)this.distanceWalkedOnStepModified + 1;
                    if (this.isInWater()) {
                        float f = MathHelper.sqrt_double(this.motionX * this.motionX * 0.2F + this.motionY * this.motionY + this.motionZ * this.motionZ * 0.2F)
                            * 0.35F;
                        if (f > 1.0F) {
                            f = 1.0F;
                        }

                        this.playSound(this.getSwimSound(), f, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
                    }

                    this.playStepSound(blockpos, block1);
                }
            }

            try {
                this.doBlockCollisions();
            } catch (Throwable throwable) {
                CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Checking entity block collision");
                CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being checked for collision");
                this.addEntityCrashInfo(crashreportcategory);
                throw new ReportedException(crashreport);
            }

            boolean flag2 = this.isWet();
            if (this.worldObj.isFlammableWithin(this.getEntityBoundingBox().contract(0.001, 0.001, 0.001))) {
                this.dealFireDamage(1);
                if (!flag2) {
                    this.fire++;
                    if (this.fire == 0) {
                        this.setFire(8);
                    }
                }
            } else if (this.fire <= 0) {
                this.fire = -this.fireResistance;
            }

            if (flag2 && this.fire > 0) {
                this.playSound("random.fizz", 0.7F, 1.6F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
                this.fire = -this.fireResistance;
            }

            this.worldObj.theProfiler.endSection();
        }
    }

    private void resetPositionToBB() {
        this.posX = (this.getEntityBoundingBox().minX + this.getEntityBoundingBox().maxX) / 2.0;
        this.posY = this.getEntityBoundingBox().minY;
        this.posZ = (this.getEntityBoundingBox().minZ + this.getEntityBoundingBox().maxZ) / 2.0;
    }

    protected String getSwimSound() {
        return "game.neutral.swim";
    }

    protected void doBlockCollisions() {
        BlockPos blockpos = new BlockPos(
            this.getEntityBoundingBox().minX + 0.001, this.getEntityBoundingBox().minY + 0.001, this.getEntityBoundingBox().minZ + 0.001
        );
        BlockPos blockpos1 = new BlockPos(
            this.getEntityBoundingBox().maxX - 0.001, this.getEntityBoundingBox().maxY - 0.001, this.getEntityBoundingBox().maxZ - 0.001
        );
        if (this.worldObj.isAreaLoaded(blockpos, blockpos1)) {
            for (int i = blockpos.getX(); i <= blockpos1.getX(); i++) {
                for (int j = blockpos.getY(); j <= blockpos1.getY(); j++) {
                    for (int k = blockpos.getZ(); k <= blockpos1.getZ(); k++) {
                        BlockPos blockpos2 = new BlockPos(i, j, k);
                        IBlockState iblockstate = this.worldObj.getBlockState(blockpos2);

                        try {
                            iblockstate.getBlock().onEntityCollidedWithBlock(this.worldObj, blockpos2, iblockstate, this);
                        } catch (Throwable throwable) {
                            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Colliding entity with block");
                            CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being collided with");
                            CrashReportCategory.addBlockInfo(crashreportcategory, blockpos2, iblockstate);
                            throw new ReportedException(crashreport);
                        }
                    }
                }
            }
        }
    }

    protected void playStepSound(BlockPos var1, Block var2) {
        Block.SoundType block$soundtype = var2.stepSound;
        if (this.worldObj.getBlockState(var1.up()).getBlock() == Blocks.snow_layer) {
            block$soundtype = Blocks.snow_layer.stepSound;
            this.playSound(block$soundtype.getStepSound(), block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
        } else if (!var2.getMaterial().isLiquid()) {
            this.playSound(block$soundtype.getStepSound(), block$soundtype.getVolume() * 0.15F, block$soundtype.getFrequency());
        }
    }

    public void playSound(String var1, float var2, float var3) {
        if (!this.isSilent()) {
            this.worldObj.playSoundAtEntity(this, var1, var2, var3);
        }
    }

    public boolean isSilent() {
        return this.dataWatcher.getWatchableObjectByte(4) == 1;
    }

    public void setSilent(boolean var1) {
        this.dataWatcher.updateObject(4, Byte.valueOf((byte)(var1 ? 1 : 0)));
    }

    protected boolean canTriggerWalking() {
        return true;
    }

    protected void updateFallState(double var1, boolean var3, Block var4, BlockPos var5) {
        if (var3) {
            if (this.fallDistance > 0.0F) {
                if (var4 != null) {
                    var4.onFallenUpon(this.worldObj, var5, this, this.fallDistance);
                } else {
                    this.fall(this.fallDistance, 1.0F);
                }

                this.fallDistance = 0.0F;
            }
        } else if (var1 < 0.0) {
            this.fallDistance = (float)(this.fallDistance - var1);
        }
    }

    public AxisAlignedBB getCollisionBoundingBox() {
        return null;
    }

    protected void dealFireDamage(int var1) {
        if (!this.isImmuneToFire) {
            this.attackEntityFrom(DamageSource.inFire, var1);
        }
    }

    public final boolean isImmuneToFire() {
        return this.isImmuneToFire;
    }

    public void fall(float var1, float var2) {
        if (this.riddenByEntity != null) {
            this.riddenByEntity.fall(var1, var2);
        }
    }

    public boolean isWet() {
        return this.inWater
            || this.worldObj.canLightningStrike(new BlockPos(this.posX, this.posY, this.posZ))
            || this.worldObj.canLightningStrike(new BlockPos(this.posX, this.posY + this.height, this.posZ));
    }

    public boolean isInWater() {
        return this.inWater;
    }

    public boolean handleWaterMovement() {
        if (this.worldObj.handleMaterialAcceleration(this.getEntityBoundingBox().expand(0.0, -0.4F, 0.0).contract(0.001, 0.001, 0.001), Material.water, this)) {
            if (!this.inWater && !this.firstUpdate) {
                this.resetHeight();
            }

            this.fallDistance = 0.0F;
            this.inWater = true;
            this.fire = 0;
        } else {
            this.inWater = false;
        }

        return this.inWater;
    }

    protected void resetHeight() {
        float f = MathHelper.sqrt_double(this.motionX * this.motionX * 0.2F + this.motionY * this.motionY + this.motionZ * this.motionZ * 0.2F) * 0.2F;
        if (f > 1.0F) {
            f = 1.0F;
        }

        this.playSound(this.getSplashSound(), f, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
        float f1 = MathHelper.floor_double(this.getEntityBoundingBox().minY);

        for (int i = 0; i < 1.0F + this.width * 20.0F; i++) {
            float f2 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
            float f3 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
            this.worldObj
                .spawnParticle(
                    EnumParticleTypes.WATER_BUBBLE,
                    this.posX + f2,
                    f1 + 1.0F,
                    this.posZ + f3,
                    this.motionX,
                    this.motionY - this.rand.nextFloat() * 0.2F,
                    this.motionZ
                );
        }

        for (int j = 0; j < 1.0F + this.width * 20.0F; j++) {
            float f4 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
            float f5 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
            this.worldObj.spawnParticle(EnumParticleTypes.WATER_SPLASH, this.posX + f4, f1 + 1.0F, this.posZ + f5, this.motionX, this.motionY, this.motionZ);
        }
    }

    public void spawnRunningParticles() {
        if (this.isSprinting() && !this.isInWater()) {
            this.createRunningParticles();
        }
    }

    protected void createRunningParticles() {
        int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posY - 0.2F);
        int k = MathHelper.floor_double(this.posZ);
        BlockPos blockpos = new BlockPos(i, j, k);
        IBlockState iblockstate = this.worldObj.getBlockState(blockpos);
        Block block = iblockstate.getBlock();
        if (block.getRenderType() != -1) {
            this.worldObj
                .spawnParticle(
                    EnumParticleTypes.BLOCK_CRACK,
                    this.posX + (this.rand.nextFloat() - 0.5) * this.width,
                    this.getEntityBoundingBox().minY + 0.1,
                    this.posZ + (this.rand.nextFloat() - 0.5) * this.width,
                    -this.motionX * 4.0,
                    1.5,
                    -this.motionZ * 4.0,
                    Block.getStateId(iblockstate)
                );
        }
    }

    protected String getSplashSound() {
        return "game.neutral.swim.splash";
    }

    public boolean isInsideOfMaterial(Material var1) {
        double d0 = this.posY + this.getEyeHeight();
        BlockPos blockpos = new BlockPos(this.posX, d0, this.posZ);
        IBlockState iblockstate = this.worldObj.getBlockState(blockpos);
        Block block = iblockstate.getBlock();
        if (block.getMaterial() == var1) {
            float f = BlockLiquid.getLiquidHeightPercent(iblockstate.getBlock().getMetaFromState(iblockstate)) - 1.0F / 9.0F;
            float f1 = blockpos.getY() + 1 - f;
            boolean flag = d0 < f1;
            return !flag && this instanceof EntityPlayer ? false : flag;
        } else {
            return false;
        }
    }

    public boolean isInLava() {
        return this.worldObj.isMaterialInBB(this.getEntityBoundingBox().expand(-0.1F, -0.4F, -0.1F), Material.lava);
    }

    public void moveFlying(float var1, float var2, float var3) {
        float f = var1 * var1 + var2 * var2;
        if (!(f < 1.0E-4F)) {
            f = MathHelper.sqrt_float(f);
            if (f < 1.0F) {
                f = 1.0F;
            }

            f = var3 / f;
            var1 *= f;
            var2 *= f;
            float f1 = MathHelper.sin(this.rotationYaw * (float)Math.PI / 180.0F);
            float f2 = MathHelper.cos(this.rotationYaw * (float)Math.PI / 180.0F);
            this.motionX += var1 * f2 - var2 * f1;
            this.motionZ += var2 * f2 + var1 * f1;
        }
    }

    public int getBrightnessForRender(float var1) {
        BlockPos blockpos = new BlockPos(this.posX, 0.0, this.posZ);
        if (this.worldObj.isBlockLoaded(blockpos)) {
            double d0 = (this.getEntityBoundingBox().maxY - this.getEntityBoundingBox().minY) * 0.66;
            int i = MathHelper.floor_double(this.posY + d0);
            return this.worldObj.getCombinedLight(blockpos.up(i), 0);
        } else {
            return 0;
        }
    }

    public float getBrightness(float var1) {
        BlockPos blockpos = new BlockPos(this.posX, 0.0, this.posZ);
        if (this.worldObj.isBlockLoaded(blockpos)) {
            double d0 = (this.getEntityBoundingBox().maxY - this.getEntityBoundingBox().minY) * 0.66;
            int i = MathHelper.floor_double(this.posY + d0);
            return this.worldObj.getLightBrightness(blockpos.up(i));
        } else {
            return 0.0F;
        }
    }

    public void setWorld(World var1) {
        this.worldObj = var1;
    }

    public void setPositionAndRotation(double var1, double var3, double var5, float var7, float var8) {
        this.prevPosX = this.posX = var1;
        this.prevPosY = this.posY = var3;
        this.prevPosZ = this.posZ = var5;
        this.prevRotationYaw = this.rotationYaw = var7;
        this.prevRotationPitch = this.rotationPitch = var8;
        double d0 = this.prevRotationYaw - var7;
        if (d0 < -180.0) {
            this.prevRotationYaw += 360.0F;
        }

        if (d0 >= 180.0) {
            this.prevRotationYaw -= 360.0F;
        }

        this.setPosition(this.posX, this.posY, this.posZ);
        this.setRotation(var7, var8);
    }

    public void moveToBlockPosAndAngles(BlockPos var1, float var2, float var3) {
        this.setLocationAndAngles(var1.getX() + 0.5, var1.getY(), var1.getZ() + 0.5, var2, var3);
    }

    public void setLocationAndAngles(double var1, double var3, double var5, float var7, float var8) {
        this.lastTickPosX = this.prevPosX = this.posX = var1;
        this.lastTickPosY = this.prevPosY = this.posY = var3;
        this.lastTickPosZ = this.prevPosZ = this.posZ = var5;
        this.rotationYaw = var7;
        this.rotationPitch = var8;
        this.setPosition(this.posX, this.posY, this.posZ);
    }

    public float getDistanceToEntity(Entity var1) {
        float f = (float)(this.posX - var1.posX);
        float f1 = (float)(this.posY - var1.posY);
        float f2 = (float)(this.posZ - var1.posZ);
        return MathHelper.sqrt_float(f * f + f1 * f1 + f2 * f2);
    }

    public double getDistanceSq(double var1, double var3, double var5) {
        double d0 = this.posX - var1;
        double d1 = this.posY - var3;
        double d2 = this.posZ - var5;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public double getDistanceSq(BlockPos var1) {
        return var1.distanceSq(this.posX, this.posY, this.posZ);
    }

    public double getDistanceSqToCenter(BlockPos var1) {
        return var1.distanceSqToCenter(this.posX, this.posY, this.posZ);
    }

    public double getDistance(double var1, double var3, double var5) {
        double d0 = this.posX - var1;
        double d1 = this.posY - var3;
        double d2 = this.posZ - var5;
        return MathHelper.sqrt_double(d0 * d0 + d1 * d1 + d2 * d2);
    }

    public double getDistanceSqToEntity(Entity var1) {
        double d0 = this.posX - var1.posX;
        double d1 = this.posY - var1.posY;
        double d2 = this.posZ - var1.posZ;
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    public void onCollideWithPlayer(EntityPlayer var1) {
    }

    public void applyEntityCollision(Entity var1) {
        if (var1.riddenByEntity != this && var1.ridingEntity != this) {
            if (!var1.noClip && !this.noClip) {
                double d0 = var1.posX - this.posX;
                double d1 = var1.posZ - this.posZ;
                double d2 = MathHelper.abs_max(d0, d1);
                if (d2 >= 0.01F) {
                    d2 = MathHelper.sqrt_double(d2);
                    d0 /= d2;
                    d1 /= d2;
                    double d3 = 1.0 / d2;
                    if (d3 > 1.0) {
                        d3 = 1.0;
                    }

                    d0 *= d3;
                    d1 *= d3;
                    d0 *= 0.05F;
                    d1 *= 0.05F;
                    d0 *= 1.0F - this.entityCollisionReduction;
                    d1 *= 1.0F - this.entityCollisionReduction;
                    if (this.riddenByEntity == null) {
                        this.addVelocity(-d0, 0.0, -d1);
                    }

                    if (var1.riddenByEntity == null) {
                        var1.addVelocity(d0, 0.0, d1);
                    }
                }
            }
        }
    }

    public void addVelocity(double var1, double var3, double var5) {
        this.motionX += var1;
        this.motionY += var3;
        this.motionZ += var5;
        this.isAirBorne = true;
    }

    protected void setBeenAttacked() {
        this.velocityChanged = true;
    }

    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        this.setBeenAttacked();
        return false;
    }

    public Vec3 getLook(float var1) {
        if (var1 == 1.0F) {
            return this.getVectorForRotation(this.rotationPitch, this.rotationYaw);
        }

        float f = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * var1;
        float f1 = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * var1;
        return this.getVectorForRotation(f, f1);
    }

    protected final Vec3 getVectorForRotation(float var1, float var2) {
        float f = MathHelper.cos(-var2 * ((float)Math.PI / 180.0F) - (float)Math.PI);
        float f1 = MathHelper.sin(-var2 * ((float)Math.PI / 180.0F) - (float)Math.PI);
        float f2 = -MathHelper.cos(-var1 * ((float)Math.PI / 180.0F));
        float f3 = MathHelper.sin(-var1 * ((float)Math.PI / 180.0F));
        return new Vec3(f1 * f2, f3, f * f2);
    }

    public Vec3 getPositionEyes(float var1) {
        if (var1 == 1.0F) {
            return new Vec3(this.posX, this.posY + this.getEyeHeight(), this.posZ);
        }

        double d0 = this.prevPosX + (this.posX - this.prevPosX) * var1;
        double d1 = this.prevPosY + (this.posY - this.prevPosY) * var1 + this.getEyeHeight();
        double d2 = this.prevPosZ + (this.posZ - this.prevPosZ) * var1;
        return new Vec3(d0, d1, d2);
    }

    public MovingObjectPosition rayTrace(double var1, float var3) {
        Vec3 vec3 = this.getPositionEyes(var3);
        Vec3 vec31 = this.getLook(var3);
        Vec3 vec32 = vec3.addVector(vec31.xCoord * var1, vec31.yCoord * var1, vec31.zCoord * var1);
        return this.worldObj.rayTraceBlocks(vec3, vec32, false, false, true);
    }

    public boolean canBeCollidedWith() {
        return false;
    }

    public boolean canBePushed() {
        return false;
    }

    public void addToPlayerScore(Entity var1, int var2) {
    }

    public boolean isInRangeToRender3d(double var1, double var3, double var5) {
        double d0 = this.posX - var1;
        double d1 = this.posY - var3;
        double d2 = this.posZ - var5;
        double d3 = d0 * d0 + d1 * d1 + d2 * d2;
        return this.isInRangeToRenderDist(d3);
    }

    public boolean isInRangeToRenderDist(double var1) {
        double d0 = this.getEntityBoundingBox().getAverageEdgeLength();
        d0 *= 64.0 * this.renderDistanceWeight;
        return var1 < d0 * d0;
    }

    public boolean writeMountToNBT(NBTTagCompound var1) {
        String s = this.getEntityString();
        if (!this.isDead && s != null) {
            var1.setString("id", s);
            this.writeToNBT(var1);
            return true;
        } else {
            return false;
        }
    }

    public boolean writeToNBTOptional(NBTTagCompound var1) {
        String s = this.getEntityString();
        if (!this.isDead && s != null && this.riddenByEntity == null) {
            var1.setString("id", s);
            this.writeToNBT(var1);
            return true;
        } else {
            return false;
        }
    }

    public void writeToNBT(NBTTagCompound var1) {
        try {
            var1.setTag("Pos", this.newDoubleNBTList(this.posX, this.posY, this.posZ));
            var1.setTag("Motion", this.newDoubleNBTList(this.motionX, this.motionY, this.motionZ));
            var1.setTag("Rotation", this.newFloatNBTList(this.rotationYaw, this.rotationPitch));
            var1.setFloat("FallDistance", this.fallDistance);
            var1.setShort("Fire", (short)this.fire);
            var1.setShort("Air", (short)this.getAir());
            var1.setBoolean("OnGround", this.onGround);
            var1.setInteger("Dimension", this.dimension);
            var1.setBoolean("Invulnerable", this.invulnerable);
            var1.setInteger("PortalCooldown", this.timeUntilPortal);
            var1.setLong("UUIDMost", this.getUniqueID().getMostSignificantBits());
            var1.setLong("UUIDLeast", this.getUniqueID().getLeastSignificantBits());
            if (this.getCustomNameTag() != null && this.getCustomNameTag().length() > 0) {
                var1.setString("CustomName", this.getCustomNameTag());
                var1.setBoolean("CustomNameVisible", this.getAlwaysRenderNameTag());
            }

            this.cmdResultStats.writeStatsToNBT(var1);
            if (this.isSilent()) {
                var1.setBoolean("Silent", this.isSilent());
            }

            this.writeEntityToNBT(var1);
            if (this.ridingEntity != null) {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                if (this.ridingEntity.writeMountToNBT(nbttagcompound)) {
                    var1.setTag("Riding", nbttagcompound);
                }
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Saving entity NBT");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being saved");
            this.addEntityCrashInfo(crashreportcategory);
            throw new ReportedException(crashreport);
        }
    }

    public void readFromNBT(NBTTagCompound var1) {
        try {
            NBTTagList nbttaglist = var1.getTagList("Pos", 6);
            NBTTagList nbttaglist1 = var1.getTagList("Motion", 6);
            NBTTagList nbttaglist2 = var1.getTagList("Rotation", 5);
            this.motionX = nbttaglist1.getDoubleAt(0);
            this.motionY = nbttaglist1.getDoubleAt(1);
            this.motionZ = nbttaglist1.getDoubleAt(2);
            if (Math.abs(this.motionX) > 10.0) {
                this.motionX = 0.0;
            }

            if (Math.abs(this.motionY) > 10.0) {
                this.motionY = 0.0;
            }

            if (Math.abs(this.motionZ) > 10.0) {
                this.motionZ = 0.0;
            }

            this.prevPosX = this.lastTickPosX = this.posX = nbttaglist.getDoubleAt(0);
            this.prevPosY = this.lastTickPosY = this.posY = nbttaglist.getDoubleAt(1);
            this.prevPosZ = this.lastTickPosZ = this.posZ = nbttaglist.getDoubleAt(2);
            this.prevRotationYaw = this.rotationYaw = nbttaglist2.getFloatAt(0);
            this.prevRotationPitch = this.rotationPitch = nbttaglist2.getFloatAt(1);
            this.fallDistance = var1.getFloat("FallDistance");
            this.fire = var1.getShort("Fire");
            this.setAir(var1.getShort("Air"));
            this.onGround = var1.getBoolean("OnGround");
            this.dimension = var1.getInteger("Dimension");
            this.invulnerable = var1.getBoolean("Invulnerable");
            this.timeUntilPortal = var1.getInteger("PortalCooldown");
            if (var1.hasKey("UUIDMost", 4) && var1.hasKey("UUIDLeast", 4)) {
                this.entityUniqueID = new UUID(var1.getLong("UUIDMost"), var1.getLong("UUIDLeast"));
            } else if (var1.hasKey("UUID", 8)) {
                this.entityUniqueID = UUID.fromString(var1.getString("UUID"));
            }

            this.setPosition(this.posX, this.posY, this.posZ);
            this.setRotation(this.rotationYaw, this.rotationPitch);
            if (var1.hasKey("CustomName", 8) && var1.getString("CustomName").length() > 0) {
                this.setCustomNameTag(var1.getString("CustomName"));
            }

            this.setAlwaysRenderNameTag(var1.getBoolean("CustomNameVisible"));
            this.cmdResultStats.readStatsFromNBT(var1);
            this.setSilent(var1.getBoolean("Silent"));
            this.readEntityFromNBT(var1);
            if (this.shouldSetPosAfterLoading()) {
                this.setPosition(this.posX, this.posY, this.posZ);
            }
        } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Loading entity NBT");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Entity being loaded");
            this.addEntityCrashInfo(crashreportcategory);
            throw new ReportedException(crashreport);
        }
    }

    protected boolean shouldSetPosAfterLoading() {
        return true;
    }

    protected final String getEntityString() {
        return EntityList.getEntityString(this);
    }

    protected abstract void readEntityFromNBT(NBTTagCompound var1);

    protected abstract void writeEntityToNBT(NBTTagCompound var1);

    public void onChunkLoad() {
    }

    protected NBTTagList newDoubleNBTList(double... var1) {
        NBTTagList nbttaglist = new NBTTagList();

        for (double d0 : var1) {
            nbttaglist.appendTag(new NBTTagDouble(d0));
        }

        return nbttaglist;
    }

    protected NBTTagList newFloatNBTList(float... var1) {
        NBTTagList nbttaglist = new NBTTagList();

        for (float f : var1) {
            nbttaglist.appendTag(new NBTTagFloat(f));
        }

        return nbttaglist;
    }

    public EntityItem dropItem(Item var1, int var2) {
        return this.dropItemWithOffset(var1, var2, 0.0F);
    }

    public EntityItem dropItemWithOffset(Item var1, int var2, float var3) {
        return this.entityDropItem(new ItemStack(var1, var2, 0), var3);
    }

    public EntityItem entityDropItem(ItemStack var1, float var2) {
        if (var1.stackSize != 0 && var1.getItem() != null) {
            EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY + var2, this.posZ, var1);
            entityitem.setDefaultPickupDelay();
            this.worldObj.spawnEntityInWorld(entityitem);
            return entityitem;
        } else {
            return null;
        }
    }

    public boolean isEntityAlive() {
        return !this.isDead;
    }

    public boolean isEntityInsideOpaqueBlock() {
        if (this.noClip) {
            return false;
        }

        for (int i = 0; i < 8; i++) {
            double d0 = this.posX + ((i >> 0) % 2 - 0.5F) * this.width * 0.8F;
            double d1 = this.posY + ((i >> 1) % 2 - 0.5F) * 0.1F;
            double d2 = this.posZ + ((i >> 2) % 2 - 0.5F) * this.width * 0.8F;
            if (this.worldObj.getBlockState(new BlockPos(d0, d1 + this.getEyeHeight(), d2)).getBlock().isVisuallyOpaque()) {
                return true;
            }
        }

        return false;
    }

    public boolean interactFirst(EntityPlayer var1) {
        return false;
    }

    public AxisAlignedBB getCollisionBox(Entity var1) {
        return null;
    }

    public void updateRidden() {
        if (this.ridingEntity.isDead) {
            this.ridingEntity = null;
        } else {
            this.motionX = 0.0;
            this.motionY = 0.0;
            this.motionZ = 0.0;
            this.onUpdate();
            if (this.ridingEntity != null) {
                this.ridingEntity.updateRiderPosition();
                this.entityRiderYawDelta = this.entityRiderYawDelta + (this.ridingEntity.rotationYaw - this.ridingEntity.prevRotationYaw);
                this.entityRiderPitchDelta = this.entityRiderPitchDelta + (this.ridingEntity.rotationPitch - this.ridingEntity.prevRotationPitch);

                while (this.entityRiderYawDelta >= 180.0) {
                    this.entityRiderYawDelta -= 360.0;
                }

                while (this.entityRiderYawDelta < -180.0) {
                    this.entityRiderYawDelta += 360.0;
                }

                while (this.entityRiderPitchDelta >= 180.0) {
                    this.entityRiderPitchDelta -= 360.0;
                }

                while (this.entityRiderPitchDelta < -180.0) {
                    this.entityRiderPitchDelta += 360.0;
                }

                double d0 = this.entityRiderYawDelta * 0.5;
                double d1 = this.entityRiderPitchDelta * 0.5;
                float f = 10.0F;
                if (d0 > f) {
                    d0 = f;
                }

                if (d0 < -f) {
                    d0 = -f;
                }

                if (d1 > f) {
                    d1 = f;
                }

                if (d1 < -f) {
                    d1 = -f;
                }

                this.entityRiderYawDelta -= d0;
                this.entityRiderPitchDelta -= d1;
            }
        }
    }

    public void updateRiderPosition() {
        if (this.riddenByEntity != null) {
            this.riddenByEntity.setPosition(this.posX, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ);
        }
    }

    public double getYOffset() {
        return 0.0;
    }

    public double getMountedYOffset() {
        return this.height * 0.75;
    }

    public void mountEntity(Entity var1) {
        this.entityRiderPitchDelta = 0.0;
        this.entityRiderYawDelta = 0.0;
        if (var1 == null) {
            if (this.ridingEntity != null) {
                this.setLocationAndAngles(
                    this.ridingEntity.posX,
                    this.ridingEntity.getEntityBoundingBox().minY + this.ridingEntity.height,
                    this.ridingEntity.posZ,
                    this.rotationYaw,
                    this.rotationPitch
                );
                this.ridingEntity.riddenByEntity = null;
            }

            this.ridingEntity = null;
        } else {
            if (this.ridingEntity != null) {
                this.ridingEntity.riddenByEntity = null;
            }

            if (var1 != null) {
                for (Entity entity = var1.ridingEntity; entity != null; entity = entity.ridingEntity) {
                    if (entity == this) {
                        return;
                    }
                }
            }

            this.ridingEntity = var1;
            var1.riddenByEntity = this;
        }
    }

    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
        this.setPosition(var1, var3, var5);
        this.setRotation(var7, var8);
        List list = this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox().contract(1.0 / 32.0, 0.0, 1.0 / 32.0));
        if (!list.isEmpty()) {
            double d0 = 0.0;

            for (AxisAlignedBB axisalignedbb : (Iterable<AxisAlignedBB>) (Iterable) list) {
                if (axisalignedbb.maxY > d0) {
                    d0 = axisalignedbb.maxY;
                }
            }

            var3 += d0 - this.getEntityBoundingBox().minY;
            this.setPosition(var1, var3, var5);
        }
    }

    public float getCollisionBorderSize() {
        return 0.1F;
    }

    public Vec3 getLookVec() {
        return null;
    }

    public void setInPortal() {
        if (this.timeUntilPortal > 0) {
            this.timeUntilPortal = this.getPortalCooldown();
        } else {
            double d0 = this.prevPosX - this.posX;
            double d1 = this.prevPosZ - this.posZ;
            if (!this.worldObj.isRemote && !this.inPortal) {
                int i;
                if (MathHelper.abs((float)d0) > MathHelper.abs((float)d1)) {
                    i = d0 > 0.0 ? EnumFacing.WEST.getHorizontalIndex() : EnumFacing.EAST.getHorizontalIndex();
                } else {
                    i = d1 > 0.0 ? EnumFacing.NORTH.getHorizontalIndex() : EnumFacing.SOUTH.getHorizontalIndex();
                }

                this.teleportDirection = i;
            }

            this.inPortal = true;
        }
    }

    public int getPortalCooldown() {
        return 300;
    }

    public void setVelocity(double var1, double var3, double var5) {
        this.motionX = var1;
        this.motionY = var3;
        this.motionZ = var5;
    }

    public void handleHealthUpdate(byte var1) {
    }

    public void performHurtAnimation() {
    }

    public ItemStack[] getInventory() {
        return null;
    }

    public void setCurrentItemOrArmor(int var1, ItemStack var2) {
    }

    public boolean isBurning() {
        boolean flag = this.worldObj != null && this.worldObj.isRemote;
        return !this.isImmuneToFire && (this.fire > 0 || flag && this.getFlag(0));
    }

    public boolean isRiding() {
        return this.ridingEntity != null;
    }

    public boolean isSneaking() {
        return this.getFlag(1);
    }

    public void setSneaking(boolean var1) {
        this.setFlag(1, var1);
    }

    public boolean isSprinting() {
        return this.getFlag(3);
    }

    public void setSprinting(boolean var1) {
        this.setFlag(3, var1);
    }

    public boolean isInvisible() {
        return this.getFlag(5);
    }

    public boolean isInvisibleToPlayer(EntityPlayer var1) {
        return var1.isSpectator() ? false : this.isInvisible();
    }

    public void setInvisible(boolean var1) {
        this.setFlag(5, var1);
    }

    public boolean isEating() {
        return this.getFlag(4);
    }

    public void setEating(boolean var1) {
        this.setFlag(4, var1);
    }

    protected boolean getFlag(int var1) {
        return (this.dataWatcher.getWatchableObjectByte(0) & 1 << var1) != 0;
    }

    protected void setFlag(int var1, boolean var2) {
        byte b0 = this.dataWatcher.getWatchableObjectByte(0);
        if (var2) {
            this.dataWatcher.updateObject(0, (byte)(b0 | 1 << var1));
        } else {
            this.dataWatcher.updateObject(0, (byte)(b0 & ~(1 << var1)));
        }
    }

    public int getAir() {
        return this.dataWatcher.getWatchableObjectShort(1);
    }

    public void setAir(int var1) {
        this.dataWatcher.updateObject(1, (short)var1);
    }

    public void onStruckByLightning(EntityLightningBolt var1) {
        this.attackEntityFrom(DamageSource.lightningBolt, 5.0F);
        this.fire++;
        if (this.fire == 0) {
            this.setFire(8);
        }
    }

    public void onKillEntity(EntityLivingBase var1) {
    }

    protected boolean pushOutOfBlocks(double var1, double var3, double var5) {
        BlockPos blockpos = new BlockPos(var1, var3, var5);
        double d0 = var1 - blockpos.getX();
        double d1 = var3 - blockpos.getY();
        double d2 = var5 - blockpos.getZ();
        List list = this.worldObj.func_147461_a(this.getEntityBoundingBox());
        if (list.isEmpty() && !this.worldObj.isBlockFullCube(blockpos)) {
            return false;
        }

        byte b0 = 3;
        double d3 = 9999.0;
        if (!this.worldObj.isBlockFullCube(blockpos.west()) && d0 < d3) {
            d3 = d0;
            b0 = 0;
        }

        if (!this.worldObj.isBlockFullCube(blockpos.east()) && 1.0 - d0 < d3) {
            d3 = 1.0 - d0;
            b0 = 1;
        }

        if (!this.worldObj.isBlockFullCube(blockpos.up()) && 1.0 - d1 < d3) {
            d3 = 1.0 - d1;
            b0 = 3;
        }

        if (!this.worldObj.isBlockFullCube(blockpos.north()) && d2 < d3) {
            d3 = d2;
            b0 = 4;
        }

        if (!this.worldObj.isBlockFullCube(blockpos.south()) && 1.0 - d2 < d3) {
            d3 = 1.0 - d2;
            b0 = 5;
        }

        float f = this.rand.nextFloat() * 0.2F + 0.1F;
        if (b0 == 0) {
            this.motionX = -f;
        }

        if (b0 == 1) {
            this.motionX = f;
        }

        if (b0 == 3) {
            this.motionY = f;
        }

        if (b0 == 4) {
            this.motionZ = -f;
        }

        if (b0 == 5) {
            this.motionZ = f;
        }

        return true;
    }

    public void setInWeb() {
        this.isInWeb = true;
        this.fallDistance = 0.0F;
    }

    @Override
    public String getCommandSenderName() {
        if (this.hasCustomName()) {
            return this.getCustomNameTag();
        }

        String s = EntityList.getEntityString(this);
        if (s == null) {
            s = "generic";
        }

        return StatCollector.translateToLocal("entity." + s + ".name");
    }

    public Entity[] getParts() {
        return null;
    }

    public boolean isEntityEqual(Entity var1) {
        return this == var1;
    }

    public float getRotationYawHead() {
        return 0.0F;
    }

    public void setRotationYawHead(float var1) {
    }

    public boolean canAttackWithItem() {
        return true;
    }

    public boolean hitByEntity(Entity var1) {
        return false;
    }

    @Override
    public String toString() {
        return String.format(
            "%s['%s'/%d, l='%s', x=%.2f, y=%.2f, z=%.2f]",
            this.getClass().getSimpleName(),
            this.getCommandSenderName(),
            this.entityId,
            this.worldObj == null ? "~NULL~" : this.worldObj.getWorldInfo().getWorldName(),
            this.posX,
            this.posY,
            this.posZ
        );
    }

    public boolean isEntityInvulnerable(DamageSource var1) {
        return this.invulnerable && var1 != DamageSource.outOfWorld && !var1.isCreativePlayer();
    }

    public void copyLocationAndAnglesFrom(Entity var1) {
        this.setLocationAndAngles(var1.posX, var1.posY, var1.posZ, var1.rotationYaw, var1.rotationPitch);
    }

    public void copyDataFromOld(Entity var1) {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        var1.writeToNBT(nbttagcompound);
        this.readFromNBT(nbttagcompound);
        this.timeUntilPortal = var1.timeUntilPortal;
        this.teleportDirection = var1.teleportDirection;
    }

    public void travelToDimension(int var1) {
        if (!this.worldObj.isRemote && !this.isDead) {
            this.worldObj.theProfiler.startSection("changeDimension");
            MinecraftServer minecraftserver = MinecraftServer.getServer();
            int i = this.dimension;
            WorldServer worldserver = minecraftserver.worldServerForDimension(i);
            WorldServer worldserver1 = minecraftserver.worldServerForDimension(var1);
            this.dimension = var1;
            if (i == 1 && var1 == 1) {
                worldserver1 = minecraftserver.worldServerForDimension(0);
                this.dimension = 0;
            }

            this.worldObj.removeEntity(this);
            this.isDead = false;
            this.worldObj.theProfiler.startSection("reposition");
            minecraftserver.getConfigurationManager().transferEntityToWorld(this, i, worldserver, worldserver1);
            this.worldObj.theProfiler.endStartSection("reloading");
            Entity entity = EntityList.createEntityByName(EntityList.getEntityString(this), worldserver1);
            if (entity != null) {
                entity.copyDataFromOld(this);
                if (i == 1 && var1 == 1) {
                    BlockPos blockpos = this.worldObj.getTopSolidOrLiquidBlock(worldserver1.getSpawnPoint());
                    entity.moveToBlockPosAndAngles(blockpos, entity.rotationYaw, entity.rotationPitch);
                }

                worldserver1.spawnEntityInWorld(entity);
            }

            this.isDead = true;
            this.worldObj.theProfiler.endSection();
            worldserver.resetUpdateEntityTick();
            worldserver1.resetUpdateEntityTick();
            this.worldObj.theProfiler.endSection();
        }
    }

    public float getExplosionResistance(Explosion var1, World var2, BlockPos var3, IBlockState var4) {
        return var4.getBlock().getExplosionResistance(this);
    }

    public boolean verifyExplosion(Explosion var1, World var2, BlockPos var3, IBlockState var4, float var5) {
        return true;
    }

    public int getMaxFallHeight() {
        return 3;
    }

    public int getTeleportDirection() {
        return this.teleportDirection;
    }

    public boolean doesEntityNotTriggerPressurePlate() {
        return false;
    }

    public void addEntityCrashInfo(CrashReportCategory var1) {
        var1.addCrashSectionCallable("Entity Type", new Callable() {
            public String call() {
                return EntityList.getEntityString(Entity.this) + " (" + Entity.this.getClass().getCanonicalName() + ")";
            }
        });
        var1.addCrashSection("Entity ID", this.entityId);
        var1.addCrashSectionCallable("Entity Name", new Callable() {
            public String call() {
                return Entity.this.getCommandSenderName();
            }
        });
        var1.addCrashSection("Entity's Exact location", String.format("%.2f, %.2f, %.2f", this.posX, this.posY, this.posZ));
        var1.addCrashSection(
            "Entity's Block location",
            CrashReportCategory.getCoordinateInfo(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))
        );
        var1.addCrashSection("Entity's Momentum", String.format("%.2f, %.2f, %.2f", this.motionX, this.motionY, this.motionZ));
        var1.addCrashSectionCallable("Entity's Rider", new Callable() {
            public String call() {
                return Entity.this.riddenByEntity.toString();
            }
        });
        var1.addCrashSectionCallable("Entity's Vehicle", new Callable() {
            public String call() {
                return Entity.this.ridingEntity.toString();
            }
        });
    }

    public boolean canRenderOnFire() {
        return this.isBurning();
    }

    public UUID getUniqueID() {
        return this.entityUniqueID;
    }

    public boolean isPushedByWater() {
        return true;
    }

    @Override
    public IChatComponent getDisplayName() {
        ChatComponentText chatcomponenttext = new ChatComponentText(this.getCommandSenderName());
        chatcomponenttext.getChatStyle().setChatHoverEvent(this.getHoverEvent());
        chatcomponenttext.getChatStyle().setInsertion(this.getUniqueID().toString());
        return chatcomponenttext;
    }

    public void setCustomNameTag(String var1) {
        this.dataWatcher.updateObject(2, var1);
    }

    public String getCustomNameTag() {
        return this.dataWatcher.getWatchableObjectString(2);
    }

    public boolean hasCustomName() {
        return this.dataWatcher.getWatchableObjectString(2).length() > 0;
    }

    public void setAlwaysRenderNameTag(boolean var1) {
        this.dataWatcher.updateObject(3, Byte.valueOf((byte)(var1 ? 1 : 0)));
    }

    public boolean getAlwaysRenderNameTag() {
        return this.dataWatcher.getWatchableObjectByte(3) == 1;
    }

    public void setPositionAndUpdate(double var1, double var3, double var5) {
        this.setLocationAndAngles(var1, var3, var5, this.rotationYaw, this.rotationPitch);
    }

    public boolean getAlwaysRenderNameTagForRender() {
        return this.getAlwaysRenderNameTag();
    }

    public void onDataWatcherUpdate(int var1) {
    }

    public EnumFacing getHorizontalFacing() {
        return EnumFacing.getHorizontal(MathHelper.floor_double(this.rotationYaw * 4.0F / 360.0F + 0.5) & 3);
    }

    protected HoverEvent getHoverEvent() {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        String s = EntityList.getEntityString(this);
        nbttagcompound.setString("id", this.getUniqueID().toString());
        if (s != null) {
            nbttagcompound.setString("type", s);
        }

        nbttagcompound.setString("name", this.getCommandSenderName());
        return new HoverEvent(HoverEvent.Action.SHOW_ENTITY, new ChatComponentText(nbttagcompound.toString()));
    }

    public boolean isSpectatedByPlayer(EntityPlayerMP var1) {
        return true;
    }

    public AxisAlignedBB getEntityBoundingBox() {
        return this.boundingBox;
    }

    public void setEntityBoundingBox(AxisAlignedBB var1) {
        this.boundingBox = var1;
    }

    public float getEyeHeight() {
        return this.height * 0.85F;
    }

    public boolean isOutsideBorder() {
        return this.isOutsideBorder;
    }

    public void setOutsideBorder(boolean var1) {
        this.isOutsideBorder = var1;
    }

    public boolean replaceItemInInventory(int var1, ItemStack var2) {
        return false;
    }

    @Override
    public void addChatMessage(IChatComponent var1) {
    }

    @Override
    public boolean canCommandSenderUseCommand(int var1, String var2) {
        return true;
    }

    @Override
    public BlockPos getPosition() {
        return new BlockPos(this.posX, this.posY + 0.5, this.posZ);
    }

    @Override
    public Vec3 getPositionVector() {
        return new Vec3(this.posX, this.posY, this.posZ);
    }

    @Override
    public World getEntityWorld() {
        return this.worldObj;
    }

    @Override
    public Entity getCommandSenderEntity() {
        return this;
    }

    @Override
    public boolean sendCommandFeedback() {
        return false;
    }

    @Override
    public void setCommandStat(CommandResultStats.Type var1, int var2) {
        this.cmdResultStats.func_179672_a(this, var1, var2);
    }

    public CommandResultStats getCommandStats() {
        return this.cmdResultStats;
    }

    public void func_174817_o(Entity var1) {
        this.cmdResultStats.func_179671_a(var1.getCommandStats());
    }

    public NBTTagCompound getNBTTagCompound() {
        return null;
    }

    public void clientUpdateEntityNBT(NBTTagCompound var1) {
    }

    public boolean interactAt(EntityPlayer var1, Vec3 var2) {
        return false;
    }

    public boolean isImmuneToExplosions() {
        return false;
    }

    protected void applyEnchantments(EntityLivingBase var1, Entity var2) {
        if (var2 instanceof EntityLivingBase) {
            EnchantmentHelper.applyThornEnchantments((EntityLivingBase)var2, var1);
        }

        EnchantmentHelper.applyArthropodEnchantments(var1, var2);
    }
}
