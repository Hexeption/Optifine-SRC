package net.minecraft.entity.monster;

import com.google.common.base.Predicate;
import com.google.common.collect.Sets;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EntityEnderman extends EntityMob {
    private static final UUID attackingSpeedBoostModifierUUID = UUID.fromString("020E0DFB-87AE-4653-9556-831010E291A0");
    private static final AttributeModifier attackingSpeedBoostModifier = new AttributeModifier(
            attackingSpeedBoostModifierUUID, "Attacking speed boost", 0.15F, 0
        )
        .setSaved(false);
    private static final Set carriableBlocks = Sets.newIdentityHashSet();
    private boolean isAggressive;

    public EntityEnderman(World var1) {
        super(var1);
        this.setSize(0.6F, 2.9F);
        this.stepHeight = 1.0F;
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIAttackOnCollide(this, 1.0, false));
        this.tasks.addTask(7, new EntityAIWander(this, 1.0));
        this.tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(8, new EntityAILookIdle(this));
        this.tasks.addTask(10, new EntityEnderman.AIPlaceBlock(this));
        this.tasks.addTask(11, new EntityEnderman.AITakeBlock(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        this.targetTasks.addTask(2, new EntityEnderman.AIFindPlayer(this));
        this.targetTasks.addTask(3, new EntityAINearestAttackableTarget(this, EntityEndermite.class, 10, true, false, new Predicate() {
            public boolean func_179948_a(EntityEndermite var1) {
                return var1.isSpawnedByPlayer();
            }

            @Override
            public boolean apply(Object var1) {
                return this.func_179948_a((EntityEndermite)var1);
            }
        }));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.3F);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(7.0);
        this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(64.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, new Short((short)0));
        this.dataWatcher.addObject(17, new Byte((byte)0));
        this.dataWatcher.addObject(18, new Byte((byte)0));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
        super.writeEntityToNBT(var1);
        IBlockState iblockstate = this.getHeldBlockState();
        var1.setShort("carried", (short)Block.getIdFromBlock(iblockstate.getBlock()));
        var1.setShort("carriedData", (short)iblockstate.getBlock().getMetaFromState(iblockstate));
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
        super.readEntityFromNBT(var1);
        IBlockState iblockstate;
        if (var1.hasKey("carried", 8)) {
            iblockstate = Block.getBlockFromName(var1.getString("carried")).getStateFromMeta(var1.getShort("carriedData") & 65535);
        } else {
            iblockstate = Block.getBlockById(var1.getShort("carried")).getStateFromMeta(var1.getShort("carriedData") & 65535);
        }

        this.setHeldBlockState(iblockstate);
    }

    private boolean shouldAttackPlayer(EntityPlayer var1) {
        ItemStack itemstack = var1.inventory.armorInventory[3];
        if (itemstack != null && itemstack.getItem() == Item.getItemFromBlock(Blocks.pumpkin)) {
            return false;
        }

        Vec3 vec3 = var1.getLook(1.0F).normalize();
        Vec3 vec31 = new Vec3(
            this.posX - var1.posX, this.getEntityBoundingBox().minY + this.height / 2.0F - (var1.posY + var1.getEyeHeight()), this.posZ - var1.posZ
        );
        double d0 = vec31.lengthVector();
        vec31 = vec31.normalize();
        double d1 = vec3.dotProduct(vec31);
        return d1 > 1.0 - 0.025 / d0 ? var1.canEntityBeSeen(this) : false;
    }

    @Override
    public float getEyeHeight() {
        return 2.55F;
    }

    @Override
    public void onLivingUpdate() {
        if (this.worldObj.isRemote) {
            for (int i = 0; i < 2; i++) {
                this.worldObj
                    .spawnParticle(
                        EnumParticleTypes.PORTAL,
                        this.posX + (this.rand.nextDouble() - 0.5) * this.width,
                        this.posY + this.rand.nextDouble() * this.height - 0.25,
                        this.posZ + (this.rand.nextDouble() - 0.5) * this.width,
                        (this.rand.nextDouble() - 0.5) * 2.0,
                        -this.rand.nextDouble(),
                        (this.rand.nextDouble() - 0.5) * 2.0
                    );
            }
        }

        this.isJumping = false;
        super.onLivingUpdate();
    }

    @Override
    protected void updateAITasks() {
        if (this.isWet()) {
            this.attackEntityFrom(DamageSource.drown, 1.0F);
        }

        if (this.isScreaming() && !this.isAggressive && this.rand.nextInt(100) == 0) {
            this.setScreaming(false);
        }

        if (this.worldObj.isDaytime()) {
            float f = this.getBrightness(1.0F);
            if (f > 0.5F && this.worldObj.canSeeSky(new BlockPos(this)) && this.rand.nextFloat() * 30.0F < (f - 0.4F) * 2.0F) {
                this.setAttackTarget(null);
                this.setScreaming(false);
                this.isAggressive = false;
                this.teleportRandomly();
            }
        }

        super.updateAITasks();
    }

    protected boolean teleportRandomly() {
        double d0 = this.posX + (this.rand.nextDouble() - 0.5) * 64.0;
        double d1 = this.posY + (this.rand.nextInt(64) - 32);
        double d2 = this.posZ + (this.rand.nextDouble() - 0.5) * 64.0;
        return this.teleportTo(d0, d1, d2);
    }

    protected boolean teleportToEntity(Entity var1) {
        Vec3 vec3 = new Vec3(
            this.posX - var1.posX, this.getEntityBoundingBox().minY + this.height / 2.0F - var1.posY + var1.getEyeHeight(), this.posZ - var1.posZ
        );
        vec3 = vec3.normalize();
        double d0 = 16.0;
        double d1 = this.posX + (this.rand.nextDouble() - 0.5) * 8.0 - vec3.xCoord * d0;
        double d2 = this.posY + (this.rand.nextInt(16) - 8) - vec3.yCoord * d0;
        double d3 = this.posZ + (this.rand.nextDouble() - 0.5) * 8.0 - vec3.zCoord * d0;
        return this.teleportTo(d1, d2, d3);
    }

    protected boolean teleportTo(double var1, double var3, double var5) {
        double d0 = this.posX;
        double d1 = this.posY;
        double d2 = this.posZ;
        this.posX = var1;
        this.posY = var3;
        this.posZ = var5;
        boolean flag = false;
        BlockPos blockpos = new BlockPos(this.posX, this.posY, this.posZ);
        if (this.worldObj.isBlockLoaded(blockpos)) {
            boolean flag1 = false;

            while (!flag1 && blockpos.getY() > 0) {
                BlockPos blockpos1 = blockpos.down();
                Block block = this.worldObj.getBlockState(blockpos1).getBlock();
                if (block.getMaterial().blocksMovement()) {
                    flag1 = true;
                } else {
                    this.posY--;
                    blockpos = blockpos1;
                }
            }

            if (flag1) {
                super.setPositionAndUpdate(this.posX, this.posY, this.posZ);
                if (this.worldObj.getCollidingBoundingBoxes(this, this.getEntityBoundingBox()).isEmpty()
                    && !this.worldObj.isAnyLiquid(this.getEntityBoundingBox())) {
                    flag = true;
                }
            }
        }

        if (!flag) {
            this.setPosition(d0, d1, d2);
            return false;
        }

        short short1 = 128;

        for (int i = 0; i < short1; i++) {
            double d6 = i / (short1 - 1.0);
            float f = (this.rand.nextFloat() - 0.5F) * 0.2F;
            float f1 = (this.rand.nextFloat() - 0.5F) * 0.2F;
            float f2 = (this.rand.nextFloat() - 0.5F) * 0.2F;
            double d3 = d0 + (this.posX - d0) * d6 + (this.rand.nextDouble() - 0.5) * this.width * 2.0;
            double d4 = d1 + (this.posY - d1) * d6 + this.rand.nextDouble() * this.height;
            double d5 = d2 + (this.posZ - d2) * d6 + (this.rand.nextDouble() - 0.5) * this.width * 2.0;
            this.worldObj.spawnParticle(EnumParticleTypes.PORTAL, d3, d4, d5, f, f1, f2);
        }

        this.worldObj.playSoundEffect(d0, d1, d2, "mob.endermen.portal", 1.0F, 1.0F);
        this.playSound("mob.endermen.portal", 1.0F, 1.0F);
        return true;
    }

    @Override
    protected String getLivingSound() {
        return this.isScreaming() ? "mob.endermen.scream" : "mob.endermen.idle";
    }

    @Override
    protected String getHurtSound() {
        return "mob.endermen.hit";
    }

    @Override
    protected String getDeathSound() {
        return "mob.endermen.death";
    }

    @Override
    protected Item getDropItem() {
        return Items.ender_pearl;
    }

    @Override
    protected void dropFewItems(boolean var1, int var2) {
        Item item = this.getDropItem();
        if (item != null) {
            int i = this.rand.nextInt(2 + var2);

            for (int j = 0; j < i; j++) {
                this.dropItem(item, 1);
            }
        }
    }

    public void setHeldBlockState(IBlockState var1) {
        this.dataWatcher.updateObject(16, (short)(Block.getStateId(var1) & 65535));
    }

    public IBlockState getHeldBlockState() {
        return Block.getStateById(this.dataWatcher.getWatchableObjectShort(16) & 65535);
    }

    @Override
    public boolean attackEntityFrom(DamageSource var1, float var2) {
        if (this.isEntityInvulnerable(var1)) {
            return false;
        }

        if (var1.getEntity() == null || !(var1.getEntity() instanceof EntityEndermite)) {
            if (!this.worldObj.isRemote) {
                this.setScreaming(true);
            }

            if (var1 instanceof EntityDamageSource && var1.getEntity() instanceof EntityPlayer) {
                if (var1.getEntity() instanceof EntityPlayerMP && ((EntityPlayerMP)var1.getEntity()).theItemInWorldManager.isCreative()) {
                    this.setScreaming(false);
                } else {
                    this.isAggressive = true;
                }
            }

            if (var1 instanceof EntityDamageSourceIndirect) {
                this.isAggressive = false;

                for (int i = 0; i < 64; i++) {
                    if (this.teleportRandomly()) {
                        return true;
                    }
                }

                return false;
            }
        }

        boolean flag = super.attackEntityFrom(var1, var2);
        if (var1.isUnblockable() && this.rand.nextInt(10) != 0) {
            this.teleportRandomly();
        }

        return flag;
    }

    public boolean isScreaming() {
        return this.dataWatcher.getWatchableObjectByte(18) > 0;
    }

    public void setScreaming(boolean var1) {
        this.dataWatcher.updateObject(18, (byte)(var1 ? 1 : 0));
    }

    static {
        carriableBlocks.add(Blocks.grass);
        carriableBlocks.add(Blocks.dirt);
        carriableBlocks.add(Blocks.sand);
        carriableBlocks.add(Blocks.gravel);
        carriableBlocks.add(Blocks.yellow_flower);
        carriableBlocks.add(Blocks.red_flower);
        carriableBlocks.add(Blocks.brown_mushroom);
        carriableBlocks.add(Blocks.red_mushroom);
        carriableBlocks.add(Blocks.tnt);
        carriableBlocks.add(Blocks.cactus);
        carriableBlocks.add(Blocks.clay);
        carriableBlocks.add(Blocks.pumpkin);
        carriableBlocks.add(Blocks.melon_block);
        carriableBlocks.add(Blocks.mycelium);
    }

    class AIFindPlayer extends EntityAINearestAttackableTarget {
        private EntityPlayer player;
        private int field_179450_h;
        private int field_179451_i;
        private EntityEnderman enderman;

        public AIFindPlayer(EntityEnderman var1) {
            super(var1, EntityPlayer.class, true);
            this.enderman = var1;
        }

        @Override
        public boolean shouldExecute() {
            double d0 = this.getTargetDistance();
            List list = this.taskOwner
                .worldObj
                .getEntitiesWithinAABB(EntityPlayer.class, this.taskOwner.getEntityBoundingBox().expand(d0, 4.0, d0), this.targetEntitySelector);
            Collections.sort(list, this.theNearestAttackableTargetSorter);
            if (list.isEmpty()) {
                return false;
            }

            this.player = (EntityPlayer)list.get(0);
            return true;
        }

        @Override
        public void startExecuting() {
            this.field_179450_h = 5;
            this.field_179451_i = 0;
        }

        @Override
        public void resetTask() {
            this.player = null;
            this.enderman.setScreaming(false);
            IAttributeInstance iattributeinstance = this.enderman.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
            iattributeinstance.removeModifier(EntityEnderman.attackingSpeedBoostModifier);
            super.resetTask();
        }

        @Override
        public boolean continueExecuting() {
            if (this.player != null) {
                if (!this.enderman.shouldAttackPlayer(this.player)) {
                    return false;
                }

                this.enderman.isAggressive = true;
                this.enderman.faceEntity(this.player, 10.0F, 10.0F);
                return true;
            } else {
                return super.continueExecuting();
            }
        }

        @Override
        public void updateTask() {
            if (this.player != null) {
                if (--this.field_179450_h <= 0) {
                    this.targetEntity = this.player;
                    this.player = null;
                    super.startExecuting();
                    this.enderman.playSound("mob.endermen.stare", 1.0F, 1.0F);
                    this.enderman.setScreaming(true);
                    IAttributeInstance iattributeinstance = this.enderman.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
                    iattributeinstance.applyModifier(EntityEnderman.attackingSpeedBoostModifier);
                }
            } else {
                if (this.targetEntity != null) {
                    if (this.targetEntity instanceof EntityPlayer && this.enderman.shouldAttackPlayer((EntityPlayer)this.targetEntity)) {
                        if (this.targetEntity.getDistanceSqToEntity(this.enderman) < 16.0) {
                            this.enderman.teleportRandomly();
                        }

                        this.field_179451_i = 0;
                    } else if (this.targetEntity.getDistanceSqToEntity(this.enderman) > 256.0
                        && this.field_179451_i++ >= 30
                        && this.enderman.teleportToEntity(this.targetEntity)) {
                        this.field_179451_i = 0;
                    }
                }

                super.updateTask();
            }
        }
    }

    class AIPlaceBlock extends EntityAIBase {
        private EntityEnderman enderman;

        public AIPlaceBlock(EntityEnderman var1) {
            this.enderman = var1;
        }

        @Override
        public boolean shouldExecute() {
            if (!this.enderman.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) {
                return false;
            } else {
                return this.enderman.getHeldBlockState().getBlock().getMaterial() == Material.air ? false : this.enderman.getRNG().nextInt(2000) == 0;
            }
        }

        @Override
        public void updateTask() {
            Random random = this.enderman.getRNG();
            World world = this.enderman.worldObj;
            int i = MathHelper.floor_double(this.enderman.posX - 1.0 + random.nextDouble() * 2.0);
            int j = MathHelper.floor_double(this.enderman.posY + random.nextDouble() * 2.0);
            int k = MathHelper.floor_double(this.enderman.posZ - 1.0 + random.nextDouble() * 2.0);
            BlockPos blockpos = new BlockPos(i, j, k);
            Block block = world.getBlockState(blockpos).getBlock();
            Block block1 = world.getBlockState(blockpos.down()).getBlock();
            if (this.func_179474_a(world, blockpos, this.enderman.getHeldBlockState().getBlock(), block, block1)) {
                world.setBlockState(blockpos, this.enderman.getHeldBlockState(), 3);
                this.enderman.setHeldBlockState(Blocks.air.getDefaultState());
            }
        }

        private boolean func_179474_a(World var1, BlockPos var2, Block var3, Block var4, Block var5) {
            if (!var3.canPlaceBlockAt(var1, var2)) {
                return false;
            } else if (var4.getMaterial() != Material.air) {
                return false;
            } else {
                return var5.getMaterial() == Material.air ? false : var5.isFullCube();
            }
        }
    }

    class AITakeBlock extends EntityAIBase {
        private EntityEnderman enderman;

        public AITakeBlock(EntityEnderman var1) {
            this.enderman = var1;
        }

        @Override
        public boolean shouldExecute() {
            if (!this.enderman.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing")) {
                return false;
            } else {
                return this.enderman.getHeldBlockState().getBlock().getMaterial() != Material.air ? false : this.enderman.getRNG().nextInt(20) == 0;
            }
        }

        @Override
        public void updateTask() {
            Random random = this.enderman.getRNG();
            World world = this.enderman.worldObj;
            int i = MathHelper.floor_double(this.enderman.posX - 2.0 + random.nextDouble() * 4.0);
            int j = MathHelper.floor_double(this.enderman.posY + random.nextDouble() * 3.0);
            int k = MathHelper.floor_double(this.enderman.posZ - 2.0 + random.nextDouble() * 4.0);
            BlockPos blockpos = new BlockPos(i, j, k);
            IBlockState iblockstate = world.getBlockState(blockpos);
            Block block = iblockstate.getBlock();
            if (EntityEnderman.carriableBlocks.contains(block)) {
                this.enderman.setHeldBlockState(iblockstate);
                world.setBlockState(blockpos, Blocks.air.getDefaultState());
            }
        }
    }
}
