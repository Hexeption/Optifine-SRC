package net.minecraft.entity.monster;

import com.google.common.base.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.IAnimals;

public interface IMob extends IAnimals {
    Predicate mobSelector = new Predicate() {
        public boolean isApplicable(Entity var1) {
            return var1 instanceof IMob;
        }

        @Override
        public boolean apply(Object var1) {
            return this.isApplicable((Entity)var1);
        }
    };
    Predicate VISIBLE_MOB_SELECTOR = new Predicate() {
        public boolean isApplicable(Entity var1) {
            return var1 instanceof IMob && !var1.isInvisible();
        }

        @Override
        public boolean apply(Object var1) {
            return this.isApplicable((Entity)var1);
        }
    };
}
