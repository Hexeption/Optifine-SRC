package net.minecraft.entity.monster;

import java.util.List;
import java.util.UUID;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIArrowAttack;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityWitch extends EntityMob implements IRangedAttackMob {
    private static final UUID MODIFIER_UUID = UUID.fromString("5CD17E52-A79A-43D3-A529-90FDE04B181E");
    private static final AttributeModifier MODIFIER = new AttributeModifier(MODIFIER_UUID, "Drinking speed penalty", -0.25, 0).setSaved(false);
    private static final Item[] witchDrops = new Item[]{
        Items.glowstone_dust, Items.sugar, Items.redstone, Items.spider_eye, Items.glass_bottle, Items.gunpowder, Items.stick, Items.stick
    };
    private int witchAttackTimer;

    public EntityWitch(World var1) {
        super(var1);
        this.setSize(0.6F, 1.95F);
        this.tasks.addTask(1, new EntityAISwimming(this));
        this.tasks.addTask(2, new EntityAIArrowAttack(this, 1.0, 60, 10.0F));
        this.tasks.addTask(2, new EntityAIWander(this, 1.0));
        this.tasks.addTask(2, this.aiAvoidExplodingCreepers);
        this.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(3, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, true));
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.getDataWatcher().addObject(21, (byte)0);
    }

    @Override
    protected String getLivingSound() {
        return null;
    }

    @Override
    protected String getHurtSound() {
        return null;
    }

    @Override
    protected String getDeathSound() {
        return null;
    }

    public void setAggressive(boolean var1) {
        this.getDataWatcher().updateObject(21, Byte.valueOf((byte)(var1 ? 1 : 0)));
    }

    public boolean getAggressive() {
        return this.getDataWatcher().getWatchableObjectByte(21) == 1;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(26.0);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25);
    }

    @Override
    public void onLivingUpdate() {
        if (!this.worldObj.isRemote) {
            if (this.getAggressive()) {
                if (this.witchAttackTimer-- <= 0) {
                    this.setAggressive(false);
                    ItemStack itemstack = this.getHeldItem();
                    this.setCurrentItemOrArmor(0, null);
                    if (itemstack != null && itemstack.getItem() == Items.potionitem) {
                        List list = Items.potionitem.getEffects(itemstack);
                        if (list != null) {
                            for (PotionEffect potioneffect : (Iterable<PotionEffect>) (Iterable) list) {
                                this.addPotionEffect(new PotionEffect(potioneffect));
                            }
                        }
                    }

                    this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).removeModifier(MODIFIER);
                }
            } else {
                short short1 = -1;
                if (this.rand.nextFloat() < 0.15F && this.isInsideOfMaterial(Material.water) && !this.isPotionActive(Potion.waterBreathing)) {
                    short1 = 8237;
                } else if (this.rand.nextFloat() < 0.15F && this.isBurning() && !this.isPotionActive(Potion.fireResistance)) {
                    short1 = 16307;
                } else if (this.rand.nextFloat() < 0.05F && this.getHealth() < this.getMaxHealth()) {
                    short1 = 16341;
                } else if (this.rand.nextFloat() < 0.25F
                    && this.getAttackTarget() != null
                    && !this.isPotionActive(Potion.moveSpeed)
                    && this.getAttackTarget().getDistanceSqToEntity(this) > 121.0) {
                    short1 = 16274;
                } else if (this.rand.nextFloat() < 0.25F
                    && this.getAttackTarget() != null
                    && !this.isPotionActive(Potion.moveSpeed)
                    && this.getAttackTarget().getDistanceSqToEntity(this) > 121.0) {
                    short1 = 16274;
                }

                if (short1 > -1) {
                    this.setCurrentItemOrArmor(0, new ItemStack(Items.potionitem, 1, short1));
                    this.witchAttackTimer = this.getHeldItem().getMaxItemUseDuration();
                    this.setAggressive(true);
                    IAttributeInstance iattributeinstance = this.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
                    iattributeinstance.removeModifier(MODIFIER);
                    iattributeinstance.applyModifier(MODIFIER);
                }
            }

            if (this.rand.nextFloat() < 7.5E-4F) {
                this.worldObj.setEntityState(this, (byte)15);
            }
        }

        super.onLivingUpdate();
    }

    @Override
    public void handleHealthUpdate(byte var1) {
        if (var1 == 15) {
            for (int i = 0; i < this.rand.nextInt(35) + 10; i++) {
                this.worldObj
                    .spawnParticle(
                        EnumParticleTypes.SPELL_WITCH,
                        this.posX + this.rand.nextGaussian() * 0.13F,
                        this.getEntityBoundingBox().maxY + 0.5 + this.rand.nextGaussian() * 0.13F,
                        this.posZ + this.rand.nextGaussian() * 0.13F,
                        0.0,
                        0.0,
                        0.0
                    );
            }
        } else {
            super.handleHealthUpdate(var1);
        }
    }

    @Override
    protected float applyPotionDamageCalculations(DamageSource var1, float var2) {
        var2 = super.applyPotionDamageCalculations(var1, var2);
        if (var1.getEntity() == this) {
            var2 = 0.0F;
        }

        if (var1.isMagicDamage()) {
            var2 = (float)(var2 * 0.15);
        }

        return var2;
    }

    @Override
    protected void dropFewItems(boolean var1, int var2) {
        int i = this.rand.nextInt(3) + 1;

        for (int j = 0; j < i; j++) {
            int k = this.rand.nextInt(3);
            Item item = witchDrops[this.rand.nextInt(witchDrops.length)];
            if (var2 > 0) {
                k += this.rand.nextInt(var2 + 1);
            }

            for (int l = 0; l < k; l++) {
                this.dropItem(item, 1);
            }
        }
    }

    @Override
    public void attackEntityWithRangedAttack(EntityLivingBase var1, float var2) {
        if (!this.getAggressive()) {
            EntityPotion entitypotion = new EntityPotion(this.worldObj, this, 32732);
            double d0 = var1.posY + var1.getEyeHeight() - 1.1F;
            entitypotion.rotationPitch -= -20.0F;
            double d1 = var1.posX + var1.motionX - this.posX;
            double d2 = d0 - this.posY;
            double d3 = var1.posZ + var1.motionZ - this.posZ;
            float f = MathHelper.sqrt_double(d1 * d1 + d3 * d3);
            if (f >= 8.0F && !var1.isPotionActive(Potion.moveSlowdown)) {
                entitypotion.setPotionDamage(32698);
            } else if (var1.getHealth() >= 8.0F && !var1.isPotionActive(Potion.poison)) {
                entitypotion.setPotionDamage(32660);
            } else if (f <= 3.0F && !var1.isPotionActive(Potion.weakness) && this.rand.nextFloat() < 0.25F) {
                entitypotion.setPotionDamage(32696);
            }

            entitypotion.setThrowableHeading(d1, d2 + f * 0.2F, d3, 12.0F / 16.0F, 8.0F);
            this.worldObj.spawnEntityInWorld(entitypotion);
        }
    }

    @Override
    public float getEyeHeight() {
        return 1.62F;
    }
}
