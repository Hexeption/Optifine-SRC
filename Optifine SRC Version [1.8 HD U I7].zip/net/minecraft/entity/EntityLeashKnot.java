package net.minecraft.entity;

import net.minecraft.block.BlockFence;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class EntityLeashKnot extends EntityHanging {
    public EntityLeashKnot(World var1) {
        super(var1);
    }

    public EntityLeashKnot(World var1, BlockPos var2) {
        super(var1, var2);
        this.setPosition(var2.getX() + 0.5, var2.getY() + 0.5, var2.getZ() + 0.5);
        float f = 2.0F / 16.0F;
        float f1 = 3.0F / 16.0F;
        float f2 = 0.25F;
        this.setEntityBoundingBox(
            new AxisAlignedBB(
                this.posX - 0.1875, this.posY - 0.25 + 0.125, this.posZ - 0.1875, this.posX + 0.1875, this.posY + 0.25 + 0.125, this.posZ + 0.1875
            )
        );
    }

    @Override
    protected void entityInit() {
        super.entityInit();
    }

    @Override
    public void updateFacingWithBoundingBox(EnumFacing var1) {
    }

    @Override
    public int getWidthPixels() {
        return 9;
    }

    @Override
    public int getHeightPixels() {
        return 9;
    }

    @Override
    public float getEyeHeight() {
        return -(1.0F / 16.0F);
    }

    @Override
    public boolean isInRangeToRenderDist(double var1) {
        return var1 < 1024.0;
    }

    @Override
    public void onBroken(Entity var1) {
    }

    @Override
    public boolean writeToNBTOptional(NBTTagCompound var1) {
        return false;
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
    }

    @Override
    public boolean interactFirst(EntityPlayer var1) {
        ItemStack itemstack = var1.getHeldItem();
        boolean flag = false;
        if (itemstack != null && itemstack.getItem() == Items.lead && !this.worldObj.isRemote) {
            double d0 = 7.0;

            for (EntityLiving entityliving : this.worldObj
                .getEntitiesWithinAABB(
                    EntityLiving.class, new AxisAlignedBB(this.posX - d0, this.posY - d0, this.posZ - d0, this.posX + d0, this.posY + d0, this.posZ + d0)
                )) {
                if (entityliving.getLeashed() && entityliving.getLeashedToEntity() == var1) {
                    entityliving.setLeashedToEntity(this, true);
                    flag = true;
                }
            }
        }

        if (!this.worldObj.isRemote && !flag) {
            this.setDead();
            if (var1.capabilities.isCreativeMode) {
                double d1 = 7.0;

                for (EntityLiving entityliving1 : this.worldObj
                    .getEntitiesWithinAABB(
                        EntityLiving.class, new AxisAlignedBB(this.posX - d1, this.posY - d1, this.posZ - d1, this.posX + d1, this.posY + d1, this.posZ + d1)
                    )) {
                    if (entityliving1.getLeashed() && entityliving1.getLeashedToEntity() == this) {
                        entityliving1.clearLeashed(true, false);
                    }
                }
            }
        }

        return true;
    }

    @Override
    public boolean onValidSurface() {
        return this.worldObj.getBlockState(this.hangingPosition).getBlock() instanceof BlockFence;
    }

    public static EntityLeashKnot createKnot(World var0, BlockPos var1) {
        EntityLeashKnot entityleashknot = new EntityLeashKnot(var0, var1);
        entityleashknot.forceSpawn = true;
        var0.spawnEntityInWorld(entityleashknot);
        return entityleashknot;
    }

    public static EntityLeashKnot getKnotForPosition(World var0, BlockPos var1) {
        int i = var1.getX();
        int j = var1.getY();
        int k = var1.getZ();

        for (EntityLeashKnot entityleashknot : var0.getEntitiesWithinAABB(
            EntityLeashKnot.class, new AxisAlignedBB(i - 1.0, j - 1.0, k - 1.0, i + 1.0, j + 1.0, k + 1.0)
        )) {
            if (entityleashknot.getHangingPosition().equals(var1)) {
                return entityleashknot;
            }
        }

        return null;
    }
}
