package net.minecraft.util;

import com.google.common.collect.Iterators;
import it.unimi.dsi.fastutil.Hash.Strategy;
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.AccessController;
import java.time.Instant;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.function.Consumer;
import java.util.function.LongSupplier;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.state.IProperty;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Util {
    public static LongSupplier nanoTimeSupplier = System::nanoTime;
    private static final Logger LOGGER = LogManager.getLogger();
    private static final Pattern RESERVED_WINDOWS_NAMES = Pattern.compile(
        ".*\\.|(?:CON|PRN|AUX|NUL|COM1|COM2|COM3|COM4|COM5|COM6|COM7|COM8|COM9|LPT1|LPT2|LPT3|LPT4|LPT5|LPT6|LPT7|LPT8|LPT9)(?:\\..*)?", 2
    );

    public static <K, V> Collector<Entry<? extends K, ? extends V>, ?, Map<K, V>> toMapCollector() {
        return Collectors.toMap(Entry::getKey, Entry::getValue);
    }

    public static <T extends Comparable<T>> String getValueName(IProperty<T> property, Object value) {
        return property.getName((T)value);
    }

    public static String makeTranslationKey(String type, @Nullable ResourceLocation id) {
        return id == null
            ? type + ".unregistered_sadface"
            : type + '.' + id.getNamespace() + '.' + id.getPath().replace('/', '.');
    }

    public static long milliTime() {
        return nanoTime() / 1000000L;
    }

    public static long nanoTime() {
        return nanoTimeSupplier.getAsLong();
    }

    public static long millisecondsSinceEpoch() {
        return Instant.now().toEpochMilli();
    }

    public static Util.EnumOS getOSType() {
        String s = System.getProperty("os.name").toLowerCase(Locale.ROOT);
        if (s.contains("win")) {
            return Util.EnumOS.WINDOWS;
        } else if (s.contains("mac")) {
            return Util.EnumOS.OSX;
        } else if (s.contains("solaris")) {
            return Util.EnumOS.SOLARIS;
        } else if (s.contains("sunos")) {
            return Util.EnumOS.SOLARIS;
        } else if (s.contains("linux")) {
            return Util.EnumOS.LINUX;
        } else {
            return s.contains("unix") ? Util.EnumOS.LINUX : Util.EnumOS.UNKNOWN;
        }
    }

    public static Stream<String> getJvmFlags() {
        RuntimeMXBean runtimemxbean = ManagementFactory.getRuntimeMXBean();
        return runtimemxbean.getInputArguments().stream().filter(p_lambda$getJvmFlags$0_0_ -> p_lambda$getJvmFlags$0_0_.startsWith("-X"));
    }

    public static boolean isPathNormal(Path pathIn) {
        Path path = pathIn.normalize();
        return path.equals(pathIn);
    }

    public static boolean isPathValidForWindows(Path pathIn) {
        for (Path path : pathIn) {
            if (RESERVED_WINDOWS_NAMES.matcher(path.toString()).matches()) {
                return false;
            }
        }

        return true;
    }

    public static Path resolvePath(Path pathIn, String nameIn, String extIn) {
        String s = nameIn + extIn;
        Path path = Paths.get(s);
        if (path.endsWith(extIn)) {
            throw new InvalidPathException(s, "empty resource name");
        } else {
            return pathIn.resolve(path);
        }
    }

    @Nullable
    public static <V> V runTask(FutureTask<V> task, Logger logger) {
        try {
            task.run();
            return task.get();
        } catch (ExecutionException executionexception) {
            logger.fatal("Error executing task", executionexception);
            if (executionexception.getCause() instanceof OutOfMemoryError) {
                OutOfMemoryError outofmemoryerror = (OutOfMemoryError)executionexception.getCause();
                throw outofmemoryerror;
            }
        } catch (InterruptedException interruptedexception) {
            logger.fatal("Error executing task", interruptedexception);
        }

        return null;
    }

    public static <T> T getLastElement(List<T> list) {
        return list.get(list.size() - 1);
    }

    public static <T> T getElementAfter(Iterable<T> iterable, @Nullable T element) {
        Iterator<T> iterator = iterable.iterator();
        T t = iterator.next();
        if (element != null) {
            T t1 = t;

            while (t1 != element) {
                if (iterator.hasNext()) {
                    t1 = iterator.next();
                }
            }

            if (iterator.hasNext()) {
                return iterator.next();
            }
        }

        return t;
    }

    public static <T> T getElementBefore(Iterable<T> iterable, @Nullable T current) {
        Iterator<T> iterator = iterable.iterator();
        T t = null;

        while (iterator.hasNext()) {
            T t1 = iterator.next();
            if (t1 == current) {
                if (t == null) {
                    t = iterator.hasNext() ? Iterators.getLast(iterator) : current;
                }
                break;
            }

            t = t1;
        }

        return t;
    }

    public static <T> T make(Supplier<T> supplier) {
        return supplier.get();
    }

    public static <T> T make(T object, Consumer<T> consumer) {
        consumer.accept(object);
        return object;
    }

    public static <K> Strategy<K> identityHashStrategy() {
        return ((Strategy<K>) (Strategy) Util.IdentityStrategy.INSTANCE);
    }

    public enum EnumOS {
        LINUX,
        SOLARIS,
        WINDOWS {
            @Override
            protected String[] getOpenCommandLine(URL url) {
                return new String[]{"rundll32", "url.dll,FileProtocolHandler", url.toString()};
            }
        },
        OSX {
            @Override
            protected String[] getOpenCommandLine(URL url) {
                return new String[]{"open", url.toString()};
            }
        },
        UNKNOWN;

        EnumOS() {
        }

        public void openURL(URL url) {
            try {
                Process process = AccessController.doPrivileged((java.security.PrivilegedExceptionAction<Process>) () -> {
                    try {
                        return Runtime.getRuntime().exec(this.getOpenCommandLine(url));
                    } catch (IOException ioexception) {
                        throw new RuntimeException(ioexception.getMessage(), ioexception);
                    }
                });

                for (String s : IOUtils.readLines(process.getErrorStream())) {
                    Util.LOGGER.error(s);
                }

                process.getInputStream().close();
                process.getErrorStream().close();
                process.getOutputStream().close();
            } catch (Exception exception) {
                Util.LOGGER.error("Couldn't open url '{}'", url, exception);
            }
        }

        public void openURI(URI uri) {
            try {
                this.openURL(uri.toURL());
            } catch (MalformedURLException malformedurlexception) {
                Util.LOGGER.error("Couldn't open uri '{}'", uri, malformedurlexception);
            }
        }

        public void openFile(File fileIn) {
            try {
                this.openURL(fileIn.toURI().toURL());
            } catch (MalformedURLException malformedurlexception) {
                Util.LOGGER.error("Couldn't open file '{}'", fileIn, malformedurlexception);
            }
        }

        protected String[] getOpenCommandLine(URL url) {
            String s = url.toString();
            if ("file".equals(url.getProtocol())) {
                s = s.replace("file:", "file://");
            }

            return new String[]{"xdg-open", s};
        }

        public void openURI(String uri) {
            try {
                this.openURL(new URI(uri).toURL());
            } catch (MalformedURLException | IllegalArgumentException | URISyntaxException exception) {
                Util.LOGGER.error("Couldn't open uri '{}'", uri, exception);
            }
        }
    }

    enum IdentityStrategy implements Strategy<Object> {
        INSTANCE;

        @Override
        public int hashCode(Object p_hashCode_1_) {
            return System.identityHashCode(p_hashCode_1_);
        }

        @Override
        public boolean equals(Object p_equals_1_, Object p_equals_2_) {
            return p_equals_1_ == p_equals_2_;
        }
    }
}
