package net.minecraft.util.datafix.fixes;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.Dynamic;
import com.mojang.datafixers.OpticFinder;
import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.util.Pair;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.util.datafix.TypeReferences;

public class ItemFilledMapMetadata extends DataFix {
   public ItemFilledMapMetadata(Schema outputSchema, boolean changesType) {
      super(outputSchema, changesType);
   }

   public TypeRewriteRule makeRule() {
      Type<?> type = this.getInputSchema().getType(TypeReferences.ITEM_STACK);
      OpticFinder<Pair<String, String>> opticfinder = DSL.<Pair<String, String>>fieldFinder("id", DSL.named(TypeReferences.ITEM_NAME.typeName(), DSL.namespacedString()));
      OpticFinder<?> opticfinder1 = type.findField("tag");
      return this.fixTypeEverywhereTyped("ItemInstanceMapIdFix", type, (p_206360_2_) -> {
         Optional<Pair<String, String>> optional = p_206360_2_.<Pair<String, String>>getOptional(opticfinder);
         if (optional.isPresent() && Objects.equals((optional.get()).getSecond(), "minecraft:filled_map")) {
            Dynamic<?> dynamic = (Dynamic)p_206360_2_.get(DSL.remainderFinder());
            Typed<?> typed = p_206360_2_.getOrCreateTyped(opticfinder1);
            Dynamic<?> dynamic1 = (Dynamic)typed.get(DSL.remainderFinder());
            dynamic1 = dynamic1.set("map", dynamic1.createInt(dynamic.getInt("Damage")));
            return p_206360_2_.set(opticfinder1, typed.set(DSL.remainderFinder(), dynamic1));
         } else {
            return p_206360_2_;
         }
      });
   }
}
