package net.minecraft.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.bridge.game.GameVersion;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MinecraftVersion implements GameVersion {
   private static final Logger LOGGER = LogManager.getLogger();
   private final String id;
   private final String name;
   private final boolean stable;
   private final int worldVersion;
   private final int protocolVersion;
   private final int packVersion;
   private final Date buildTime;
   private final String releaseTarget;

   public MinecraftVersion() {
      this.id = UUID.randomUUID().toString().replaceAll("-", "");
      this.name = "1.14.2";
      this.stable = true;
      this.worldVersion = 1963;
      this.protocolVersion = 485;
      this.packVersion = 4;
      this.buildTime = new Date();
      this.releaseTarget = "1.14.2";
   }

   protected MinecraftVersion(JsonObject p_i51407_1_) {
      this.id = JSONUtils.getString(p_i51407_1_, "id");
      this.name = JSONUtils.getString(p_i51407_1_, "name");
      this.releaseTarget = JSONUtils.getString(p_i51407_1_, "release_target");
      this.stable = JSONUtils.getBoolean(p_i51407_1_, "stable");
      this.worldVersion = JSONUtils.getInt(p_i51407_1_, "world_version");
      this.protocolVersion = JSONUtils.getInt(p_i51407_1_, "protocol_version");
      this.packVersion = JSONUtils.getInt(p_i51407_1_, "pack_version");
      this.buildTime = Date.from(ZonedDateTime.parse(JSONUtils.getString(p_i51407_1_, "build_time")).toInstant());
   }

   public static GameVersion load() {
      try (InputStream inputstream = MinecraftVersion.class.getResourceAsStream("/version.json")) {
         if (inputstream == null) {
            LOGGER.warn("Missing version information!");
            MinecraftVersion minecraftversion = new MinecraftVersion();
            return minecraftversion;
         } else {
            Object object;
            try (InputStreamReader inputstreamreader = new InputStreamReader(inputstream)) {
               object = new MinecraftVersion(JSONUtils.fromJson(inputstreamreader));
            }

            return (GameVersion)object;
         }
      } catch (JsonParseException | IOException ioexception) {
         throw new IllegalStateException("Game version information is corrupt", ioexception);
      }
   }

   public String getId() {
      return this.id;
   }

   public String getName() {
      return this.name;
   }

   public String getReleaseTarget() {
      return this.releaseTarget;
   }

   public int getWorldVersion() {
      return this.worldVersion;
   }

   public int getProtocolVersion() {
      return this.protocolVersion;
   }

   public int getPackVersion() {
      return this.packVersion;
   }

   public Date getBuildTime() {
      return this.buildTime;
   }

   public boolean isStable() {
      return this.stable;
   }
}
