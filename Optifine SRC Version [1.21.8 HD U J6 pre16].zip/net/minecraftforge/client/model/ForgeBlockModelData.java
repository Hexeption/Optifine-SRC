package net.minecraftforge.client.model;

import com.mojang.math.Transformation;
import java.util.Map;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

public record ForgeBlockModelData(
    Optional<Transformation> transform,
    Optional<ResourceLocation> renderType,
    Optional<ResourceLocation> renderTypeFast,
    Optional<Map<String, Boolean>> visibility
) {
}
