package net.minecraftforge.client.extensions;

import net.minecraft.client.renderer.chunk.RenderChunkCache;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public interface IForgeRenderChunk {
    default RenderChunkCache createRegionRenderCache(World world, BlockPos from, BlockPos to, int subtract) {
        return RenderChunkCache.generateCache(world, from, to, subtract);
    }
}
