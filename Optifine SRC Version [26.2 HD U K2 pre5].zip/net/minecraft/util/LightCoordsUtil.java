package net.minecraft.util;

import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.Lightmap;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndLightGetter;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.optifine.Config;
import net.optifine.DynamicLights;
import net.optifine.EmissiveTextures;

public class LightCoordsUtil {
    public static final int FULL_BRIGHT = 15728880;
    public static final int FULL_SKY = 15728640;
    private static final int MAX_SMOOTH_LIGHT_LEVEL = 240;

    public static int pack(int block, int sky) {
        return block << 4 | sky << 20;
    }

    public static int block(int packed) {
        return (packed & 65535) >> 4;
    }

    public static int sky(int packed) {
        return packed >> 20 & 15;
    }

    public static int withBlock(int coords, int block) {
        return coords & 0xFF0000 | block << 4;
    }

    public static int smoothPack(int block, int sky) {
        return block & 0xFF | (sky & 0xFF) << 16;
    }

    public static int smoothBlock(int packed) {
        return packed & 0xFF;
    }

    public static int smoothSky(int packed) {
        return packed >> 16 & 0xFF;
    }

    public static int addSmoothBlockEmission(int lightCoords, float blockLightEmission) {
        blockLightEmission = Mth.clamp(blockLightEmission, 0.0F, 1.0F);
        int emittedBlock = (int)(Mth.clamp(blockLightEmission, 0.0F, 1.0F) * 240.0F);
        int block = Math.min(smoothBlock(lightCoords) + emittedBlock, 240);
        return smoothPack(block, smoothSky(lightCoords));
    }

    public static int max(int coords1, int coords2) {
        int block1 = block(coords1);
        int block2 = block(coords2);
        int sky1 = sky(coords1);
        int sky2 = sky(coords2);
        return pack(Math.max(block1, block2), Math.max(sky1, sky2));
    }

    public static int lightCoordsWithEmission(int lightCoords, int emission) {
        if (emission == 0) {
            return lightCoords;
        }

        int sky = Math.max(sky(lightCoords), emission);
        int block = Math.max(block(lightCoords), emission);
        return pack(block, sky);
    }

    public static int smoothBlend(int neighbor1, int neighbor2, int neighbor3, int center) {
        if (sky(center) > 2 || block(center) > 2) {
            if (neighbor1 == 0) {
                neighbor1 = center;
            } else if (sky(neighbor1) == 0) {
                neighbor1 |= center & 0xFF0000;
            }

            if (neighbor2 == 0) {
                neighbor2 = center;
            } else if (sky(neighbor2) == 0) {
                neighbor2 |= center & 0xFF0000;
            }

            if (neighbor3 == 0) {
                neighbor3 = center;
            } else if (sky(neighbor3) == 0) {
                neighbor3 |= center & 0xFF0000;
            }
        }

        return neighbor1 + neighbor2 + neighbor3 + center >> 2 & 16711935;
    }

    public static int smoothWeightedBlend(int coords1, int coords2, int coords3, int coords4, float weight1, float weight2, float weight3, float weight4) {
        int sky = (int)(smoothSky(coords1) * weight1 + smoothSky(coords2) * weight2 + smoothSky(coords3) * weight3 + smoothSky(coords4) * weight4);
        int block = (int)(smoothBlock(coords1) * weight1 + smoothBlock(coords2) * weight2 + smoothBlock(coords3) * weight3 + smoothBlock(coords4) * weight4);
        return smoothPack(block, sky);
    }

    public static int getLightCoords(BlockAndLightGetter level, BlockPos pos) {
        return getLightCoords(LightCoordsUtil.BrightnessGetter.DEFAULT, level, level.getBlockState(pos), pos);
    }

    public static int getLightCoords(LightCoordsUtil.BrightnessGetter brightnessGetter, BlockAndLightGetter level, BlockState state, BlockPos pos) {
        return getLightCoords(brightnessGetter, level, state, pos, LevelRenderer.isAmbientOcclusion());
    }

    public static int getLightCoords(
        LightCoordsUtil.BrightnessGetter brightnessGetter, BlockAndLightGetter level, BlockState state, BlockPos pos, boolean ambientOcclusionIn
    ) {
        if (EmissiveTextures.isRenderEmissive() && Config.isMinecraftThread()) {
            return Lightmap.MAX_BRIGHTNESS;
        }

        if (state.emissiveRendering()) {
            return 15794417;
        }

        int packedBrightness = brightnessGetter.packedBrightness(level, pos);
        int block = block(packedBrightness);
        int blockSelfEmission = state.getLightEmission(level, pos);
        if (block < blockSelfEmission) {
            packedBrightness = withBlock(packedBrightness, blockSelfEmission);
        }

        if (Config.isDynamicLights() && (!ambientOcclusionIn || !state.isSolidRender())) {
            packedBrightness = DynamicLights.getCombinedLight(pos, packedBrightness);
        }

        return packedBrightness;
    }

    @FunctionalInterface
    public interface BrightnessGetter {
        LightCoordsUtil.BrightnessGetter DEFAULT = (level, pos) -> {
            int sky = level.getBrightness(LightLayer.SKY, pos);
            int block = level.getBrightness(LightLayer.BLOCK, pos);
            return LightCoordsUtil.pack(block, sky);
        };

        int packedBrightness(BlockAndLightGetter var1, BlockPos var2);
    }
}
