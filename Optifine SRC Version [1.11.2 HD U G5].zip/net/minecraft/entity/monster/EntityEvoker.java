package net.minecraft.entity.monster;

import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityEvokerFangs;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityEvoker extends EntityMob {
    protected static final DataParameter<Byte> DATA_SPELL_CASTING_ID = EntityDataManager.createKey(EntityEvoker.class, DataSerializers.BYTE);
    private int spellCastingTickCount;
    private int spellCastId;
    private EntitySheep wololoTarget;

    public EntityEvoker(World worldIn) {
        super(worldIn);
        this.setSize(0.6F, 1.95F);
        this.experienceValue = 10;
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityEvoker.AICastingSpell());
        this.tasks.addTask(2, new EntityAIAvoidEntity<>(this, EntityPlayer.class, 8.0F, 0.6, 1.0));
        this.tasks.addTask(4, new EntityEvoker.AISummonSpell());
        this.tasks.addTask(5, new EntityEvoker.AIAttackSpell());
        this.tasks.addTask(6, new EntityEvoker.AIWololoSpell());
        this.tasks.addTask(8, new EntityAIWander(this, 0.6));
        this.tasks.addTask(9, new EntityAIWatchClosest(this, EntityPlayer.class, 3.0F, 1.0F));
        this.tasks.addTask(10, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, EntityEvoker.class));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<>(this, EntityPlayer.class, true).setUnseenMemoryTicks(300));
        this.targetTasks.addTask(3, new EntityAINearestAttackableTarget<>(this, EntityVillager.class, false).setUnseenMemoryTicks(300));
        this.targetTasks.addTask(3, new EntityAINearestAttackableTarget<>(this, EntityIronGolem.class, false));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.5);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(12.0);
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(24.0);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(DATA_SPELL_CASTING_ID, (byte)0);
    }

    public static void registerFixesEvoker(DataFixer fixer) {
        EntityLiving.registerFixesMob(fixer, EntityEvoker.class);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        this.spellCastingTickCount = compound.getInteger("SpellTicks");
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        compound.setInteger("SpellTicks", this.spellCastingTickCount);
    }

    @Override
    public EnumCreatureAttribute getCreatureAttribute() {
        return EnumCreatureAttribute.ILLAGER;
    }

    @Override
    protected ResourceLocation getLootTable() {
        return LootTableList.ENTITIES_EVOCATION_ILLAGER;
    }

    public boolean isCastingSpell() {
        return this.world.isRemote ? this.dataManager.get(DATA_SPELL_CASTING_ID) > 0 : this.spellCastingTickCount > 0;
    }

    public void setIsCastingSpell(int p_190753_1_) {
        this.dataManager.set(DATA_SPELL_CASTING_ID, (byte)p_190753_1_);
    }

    private int getSpellCastingTime() {
        return this.spellCastingTickCount;
    }

    @Override
    protected void updateAITasks() {
        super.updateAITasks();
        if (this.spellCastingTickCount > 0) {
            this.spellCastingTickCount--;
        }
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote && this.isCastingSpell()) {
            int i = this.dataManager.get(DATA_SPELL_CASTING_ID);
            double d0 = 0.7;
            double d1 = 0.5;
            double d2 = 0.2;
            if (i == 2) {
                d0 = 0.4;
                d1 = 0.3;
                d2 = 0.35;
            } else if (i == 1) {
                d0 = 0.7;
                d1 = 0.7;
                d2 = 0.8;
            }

            float f = this.renderYawOffset * ((float)Math.PI / 180.0F) + MathHelper.cos(this.ticksExisted * 0.6662F) * 0.25F;
            float f1 = MathHelper.cos(f);
            float f2 = MathHelper.sin(f);
            this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX + f1 * 0.6, this.posY + 1.8, this.posZ + f2 * 0.6, d0, d1, d2);
            this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX - f1 * 0.6, this.posY + 1.8, this.posZ - f2 * 0.6, d0, d1, d2);
        }
    }

    @Override
    public boolean isOnSameTeam(Entity entityIn) {
        if (entityIn == null) {
            return false;
        } else if (entityIn == this) {
            return true;
        } else if (super.isOnSameTeam(entityIn)) {
            return true;
        } else if (entityIn instanceof EntityVex) {
            return this.isOnSameTeam(((EntityVex)entityIn).getOwner());
        } else {
            return entityIn instanceof EntityLivingBase && ((EntityLivingBase)entityIn).getCreatureAttribute() == EnumCreatureAttribute.ILLAGER
                ? this.getTeam() == null && entityIn.getTeam() == null
                : false;
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_EVOCATION_ILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.EVOCATION_ILLAGER_DEATH;
    }

    @Override
    protected SoundEvent getHurtSound() {
        return SoundEvents.ENTITY_EVOCATION_ILLAGER_HURT;
    }

    private void setWololoTarget(@Nullable EntitySheep p_190748_1_) {
        this.wololoTarget = p_190748_1_;
    }

    @Nullable
    private EntitySheep getWololoTarget() {
        return this.wololoTarget;
    }

    class AIAttackSpell extends EntityEvoker.AIUseSpell {
        private AIAttackSpell() {
            super();
        }

        @Override
        protected int getCastingTime() {
            return 40;
        }

        @Override
        protected int getCastingInterval() {
            return 100;
        }

        @Override
        protected void castSpell() {
            EntityLivingBase entitylivingbase = EntityEvoker.this.getAttackTarget();
            double d0 = Math.min(entitylivingbase.posY, EntityEvoker.this.posY);
            double d1 = Math.max(entitylivingbase.posY, EntityEvoker.this.posY) + 1.0;
            float f = (float)MathHelper.atan2(entitylivingbase.posZ - EntityEvoker.this.posZ, entitylivingbase.posX - EntityEvoker.this.posX);
            if (EntityEvoker.this.getDistanceSqToEntity(entitylivingbase) < 9.0) {
                for (int i = 0; i < 5; i++) {
                    float f1 = f + i * (float)Math.PI * 0.4F;
                    this.spawnFangs(EntityEvoker.this.posX + MathHelper.cos(f1) * 1.5, EntityEvoker.this.posZ + MathHelper.sin(f1) * 1.5, d0, d1, f1, 0);
                }

                for (int k = 0; k < 8; k++) {
                    float f2 = f + k * (float)Math.PI * 2.0F / 8.0F + (float)Math.PI * 0.4F;
                    this.spawnFangs(EntityEvoker.this.posX + MathHelper.cos(f2) * 2.5, EntityEvoker.this.posZ + MathHelper.sin(f2) * 2.5, d0, d1, f2, 3);
                }
            } else {
                for (int l = 0; l < 16; l++) {
                    double d2 = 1.25 * (l + 1);
                    int j = 1 * l;
                    this.spawnFangs(EntityEvoker.this.posX + MathHelper.cos(f) * d2, EntityEvoker.this.posZ + MathHelper.sin(f) * d2, d0, d1, f, j);
                }
            }
        }

        private void spawnFangs(double p_190876_1_, double p_190876_3_, double p_190876_5_, double p_190876_7_, float p_190876_9_, int p_190876_10_) {
            BlockPos blockpos = new BlockPos(p_190876_1_, p_190876_7_, p_190876_3_);
            boolean flag = false;
            double d0 = 0.0;

            do {
                if (!EntityEvoker.this.world.isBlockNormalCube(blockpos, true) && EntityEvoker.this.world.isBlockNormalCube(blockpos.down(), true)) {
                    if (!EntityEvoker.this.world.isAirBlock(blockpos)) {
                        IBlockState iblockstate = EntityEvoker.this.world.getBlockState(blockpos);
                        AxisAlignedBB axisalignedbb = iblockstate.getCollisionBoundingBox(EntityEvoker.this.world, blockpos);
                        if (axisalignedbb != null) {
                            d0 = axisalignedbb.maxY;
                        }
                    }

                    flag = true;
                    break;
                }

                blockpos = blockpos.down();
            } while (blockpos.getY() >= MathHelper.floor(p_190876_5_) - 1);

            if (flag) {
                EntityEvokerFangs entityevokerfangs = new EntityEvokerFangs(
                    EntityEvoker.this.world, p_190876_1_, blockpos.getY() + d0, p_190876_3_, p_190876_9_, p_190876_10_, EntityEvoker.this
                );
                EntityEvoker.this.world.spawnEntity(entityevokerfangs);
            }
        }

        @Override
        protected SoundEvent getSpellPrepareSound() {
            return SoundEvents.EVOCATION_ILLAGER_PREPARE_ATTACK;
        }

        @Override
        protected int getSpellId() {
            return 2;
        }
    }

    class AICastingSpell extends EntityAIBase {
        public AICastingSpell() {
            this.setMutexBits(3);
        }

        @Override
        public boolean shouldExecute() {
            return EntityEvoker.this.getSpellCastingTime() > 0;
        }

        @Override
        public void startExecuting() {
            super.startExecuting();
            EntityEvoker.this.setIsCastingSpell(EntityEvoker.this.spellCastId);
            EntityEvoker.this.navigator.clearPathEntity();
        }

        @Override
        public void resetTask() {
            super.resetTask();
            EntityEvoker.this.setIsCastingSpell(0);
        }

        @Override
        public void updateTask() {
            if (EntityEvoker.this.getAttackTarget() != null) {
                EntityEvoker.this.getLookHelper()
                    .setLookPositionWithEntity(
                        EntityEvoker.this.getAttackTarget(), EntityEvoker.this.getHorizontalFaceSpeed(), EntityEvoker.this.getVerticalFaceSpeed()
                    );
            } else if (EntityEvoker.this.getWololoTarget() != null) {
                EntityEvoker.this.getLookHelper()
                    .setLookPositionWithEntity(
                        EntityEvoker.this.getWololoTarget(), EntityEvoker.this.getHorizontalFaceSpeed(), EntityEvoker.this.getVerticalFaceSpeed()
                    );
            }
        }
    }

    class AISummonSpell extends EntityEvoker.AIUseSpell {
        private AISummonSpell() {
            super();
        }

        @Override
        public boolean shouldExecute() {
            if (!super.shouldExecute()) {
                return false;
            }

            int i = EntityEvoker.this.world.getEntitiesWithinAABB(EntityVex.class, EntityEvoker.this.getEntityBoundingBox().grow(16.0)).size();
            return EntityEvoker.this.rand.nextInt(8) + 1 > i;
        }

        @Override
        protected int getCastingTime() {
            return 100;
        }

        @Override
        protected int getCastingInterval() {
            return 340;
        }

        @Override
        protected void castSpell() {
            for (int i = 0; i < 3; i++) {
                BlockPos blockpos = new BlockPos(EntityEvoker.this).add(-2 + EntityEvoker.this.rand.nextInt(5), 1, -2 + EntityEvoker.this.rand.nextInt(5));
                EntityVex entityvex = new EntityVex(EntityEvoker.this.world);
                entityvex.moveToBlockPosAndAngles(blockpos, 0.0F, 0.0F);
                entityvex.onInitialSpawn(EntityEvoker.this.world.getDifficultyForLocation(blockpos), null);
                entityvex.setOwner(EntityEvoker.this);
                entityvex.setBoundOrigin(blockpos);
                entityvex.setLimitedLife(20 * (30 + EntityEvoker.this.rand.nextInt(90)));
                EntityEvoker.this.world.spawnEntity(entityvex);
            }
        }

        @Override
        protected SoundEvent getSpellPrepareSound() {
            return SoundEvents.EVOCATION_ILLAGER_PREPARE_SUMMON;
        }

        @Override
        protected int getSpellId() {
            return 1;
        }
    }

    abstract class AIUseSpell extends EntityAIBase {
        protected int spellWarmup;
        protected int nextCastTime;

        private AIUseSpell() {
        }

        @Override
        public boolean shouldExecute() {
            if (EntityEvoker.this.getAttackTarget() == null) {
                return false;
            } else {
                return EntityEvoker.this.isCastingSpell() ? false : EntityEvoker.this.ticksExisted >= this.nextCastTime;
            }
        }

        @Override
        public boolean shouldContinueExecuting() {
            return EntityEvoker.this.getAttackTarget() != null && this.spellWarmup > 0;
        }

        @Override
        public void startExecuting() {
            this.spellWarmup = this.getCastWarmupTime();
            EntityEvoker.this.spellCastingTickCount = this.getCastingTime();
            this.nextCastTime = EntityEvoker.this.ticksExisted + this.getCastingInterval();
            EntityEvoker.this.playSound(this.getSpellPrepareSound(), 1.0F, 1.0F);
            EntityEvoker.this.spellCastId = this.getSpellId();
        }

        @Override
        public void updateTask() {
            this.spellWarmup--;
            if (this.spellWarmup == 0) {
                this.castSpell();
                EntityEvoker.this.playSound(SoundEvents.EVOCATION_ILLAGER_CAST_SPELL, 1.0F, 1.0F);
            }
        }

        protected abstract void castSpell();

        protected int getCastWarmupTime() {
            return 20;
        }

        protected abstract int getCastingTime();

        protected abstract int getCastingInterval();

        protected abstract SoundEvent getSpellPrepareSound();

        protected abstract int getSpellId();
    }

    public class AIWololoSpell extends EntityEvoker.AIUseSpell {
        final Predicate<EntitySheep> wololoSelector = new Predicate<EntitySheep>() {
            public boolean apply(EntitySheep p_1) {
                return p_1.getFleeceColor() == EnumDyeColor.BLUE;
            }
        };

        public AIWololoSpell() {
            super();
        }

        @Override
        public boolean shouldExecute() {
            if (EntityEvoker.this.getAttackTarget() != null) {
                return false;
            }

            if (EntityEvoker.this.isCastingSpell()) {
                return false;
            }

            if (EntityEvoker.this.ticksExisted < this.nextCastTime) {
                return false;
            }

            if (!EntityEvoker.this.world.getGameRules().getBoolean("mobGriefing")) {
                return false;
            }

            List<EntitySheep> list = EntityEvoker.this.world
                .getEntitiesWithinAABB(EntitySheep.class, EntityEvoker.this.getEntityBoundingBox().grow(16.0, 4.0, 16.0), this.wololoSelector);
            if (list.isEmpty()) {
                return false;
            }

            EntityEvoker.this.setWololoTarget(list.get(EntityEvoker.this.rand.nextInt(list.size())));
            return true;
        }

        @Override
        public boolean shouldContinueExecuting() {
            return EntityEvoker.this.getWololoTarget() != null && this.spellWarmup > 0;
        }

        @Override
        public void resetTask() {
            super.resetTask();
            EntityEvoker.this.setWololoTarget(null);
        }

        @Override
        protected void castSpell() {
            EntitySheep entitysheep = EntityEvoker.this.getWololoTarget();
            if (entitysheep != null && entitysheep.isEntityAlive()) {
                entitysheep.setFleeceColor(EnumDyeColor.RED);
            }
        }

        @Override
        protected int getCastWarmupTime() {
            return 40;
        }

        @Override
        protected int getCastingTime() {
            return 60;
        }

        @Override
        protected int getCastingInterval() {
            return 140;
        }

        @Override
        protected SoundEvent getSpellPrepareSound() {
            return SoundEvents.EVOCATION_ILLAGER_PREPARE_WOLOLO;
        }

        @Override
        protected int getSpellId() {
            return 3;
        }
    }
}
