package net.minecraft.util;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.Team;

public final class EntitySelectors {
    public static final Predicate<Entity> IS_ALIVE = new Predicate<Entity>() {
        public boolean apply(@Nullable Entity p_1) {
            return p_1.isEntityAlive();
        }
    };
    public static final Predicate<Entity> IS_STANDALONE = new Predicate<Entity>() {
        public boolean apply(@Nullable Entity p_1) {
            return p_1.isEntityAlive() && !p_1.isBeingRidden() && !p_1.isRiding();
        }
    };
    public static final Predicate<Entity> HAS_INVENTORY = new Predicate<Entity>() {
        public boolean apply(@Nullable Entity p_1) {
            return p_1 instanceof IInventory && p_1.isEntityAlive();
        }
    };
    public static final Predicate<Entity> CAN_AI_TARGET = new Predicate<Entity>() {
        public boolean apply(@Nullable Entity p_1) {
            return !(p_1 instanceof EntityPlayer) || !((EntityPlayer)p_1).isSpectator() && !((EntityPlayer)p_1).isCreative();
        }
    };
    public static final Predicate<Entity> NOT_SPECTATING = new Predicate<Entity>() {
        public boolean apply(@Nullable Entity p_1) {
            return !(p_1 instanceof EntityPlayer) || !((EntityPlayer)p_1).isSpectator();
        }
    };

    public static <T extends Entity> Predicate<T> withinRange(final double x, final double y, final double z, double range) {
        final double d0 = range * range;
        return new Predicate<T>() {
            public boolean apply(@Nullable T p_1) {
                return p_1 != null && p_1.getDistanceSq(x, y, z) <= d0;
            }
        };
    }

    public static <T extends Entity> Predicate<T> getTeamCollisionPredicate(final Entity entityIn) {
        final Team team = entityIn.getTeam();
        final Team.CollisionRule team$collisionrule = team == null ? Team.CollisionRule.ALWAYS : team.getCollisionRule();
        return team$collisionrule == Team.CollisionRule.NEVER
            ? Predicates.alwaysFalse()
            : Predicates.and(
                NOT_SPECTATING,
                new Predicate<Entity>() {
                    public boolean apply(@Nullable Entity p_1) {
                        if (!p_1.canBePushed()) {
                            return false;
                        }

                        if (!entityIn.world.isRemote || p_1 instanceof EntityPlayer && ((EntityPlayer)p_1).isUser()) {
                            Team team1 = p_1.getTeam();
                            Team.CollisionRule team$collisionrule1 = team1 == null ? Team.CollisionRule.ALWAYS : team1.getCollisionRule();
                            if (team$collisionrule1 == Team.CollisionRule.NEVER) {
                                return false;
                            }

                            boolean flag = team != null && team.isSameTeam(team1);
                            return (team$collisionrule == Team.CollisionRule.HIDE_FOR_OWN_TEAM || team$collisionrule1 == Team.CollisionRule.HIDE_FOR_OWN_TEAM)
                                    && flag
                                ? false
                                : team$collisionrule != Team.CollisionRule.HIDE_FOR_OTHER_TEAMS
                                        && team$collisionrule1 != Team.CollisionRule.HIDE_FOR_OTHER_TEAMS
                                    || flag;
                        } else {
                            return false;
                        }
                    }
                }
            );
    }

    public static Predicate<Entity> notRiding(final Entity p_191324_0_) {
        return new Predicate<Entity>() {
            public boolean apply(@Nullable Entity p_1) {
                while (p_1.isRiding()) {
                    p_1 = p_1.getRidingEntity();
                    if (p_1 == p_191324_0_) {
                        return false;
                    }
                }

                return true;
            }
        };
    }

    public static class ArmoredMob implements Predicate<Entity> {
        private final ItemStack armor;

        public ArmoredMob(ItemStack armor) {
            this.armor = armor;
        }

        public boolean apply(@Nullable Entity p_1) {
            if (!p_1.isEntityAlive()) {
                return false;
            } else if (!(p_1 instanceof EntityLivingBase)) {
                return false;
            } else {
                EntityLivingBase entitylivingbase = (EntityLivingBase)p_1;
                if (!entitylivingbase.getItemStackFromSlot(EntityLiving.getSlotForItemStack(this.armor)).isEmpty()) {
                    return false;
                } else if (entitylivingbase instanceof EntityLiving) {
                    return ((EntityLiving)entitylivingbase).canPickUpLoot();
                } else {
                    return entitylivingbase instanceof EntityArmorStand ? true : entitylivingbase instanceof EntityPlayer;
                }
            }
        }
    }
}
