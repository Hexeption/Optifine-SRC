package net.minecraft.util;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nullable;

public class EnumTypeAdapterFactory implements TypeAdapterFactory {
    @Nullable
    @Override
    public <T> TypeAdapter<T> create(Gson p_1, TypeToken<T> p_2) {
        Class<T> oclass = (Class<T>)p_2.getRawType();
        if (!oclass.isEnum()) {
            return null;
        }

        final Map<String, T> map = Maps.newHashMap();

        for (T t : oclass.getEnumConstants()) {
            map.put(this.getName(t), t);
        }

        return new TypeAdapter<T>() {
            @Override
            public void write(JsonWriter p_1, T p_2x) throws IOException {
                if (p_2x == null) {
                    p_1.nullValue();
                } else {
                    p_1.value(EnumTypeAdapterFactory.this.getName(p_2x));
                }
            }

            @Nullable
            @Override
            public T read(JsonReader p_1) throws IOException {
                if (p_1.peek() == JsonToken.NULL) {
                    p_1.nextNull();
                    return null;
                } else {
                    return map.get(p_1.nextString());
                }
            }
        };
    }

    private String getName(Object objectIn) {
        return objectIn instanceof Enum ? ((Enum)objectIn).name().toLowerCase(Locale.ROOT) : objectIn.toString().toLowerCase(Locale.ROOT);
    }
}
