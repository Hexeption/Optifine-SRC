package net.minecraft.util;

import com.google.common.collect.Maps;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class LowerStringMap<V> implements Map<String, V> {
    private final Map<String, V> internalMap = Maps.newLinkedHashMap();

    @Override
    public int size() {
        return this.internalMap.size();
    }

    @Override
    public boolean isEmpty() {
        return this.internalMap.isEmpty();
    }

    @Override
    public boolean containsKey(Object p_1) {
        return this.internalMap.containsKey(p_1.toString().toLowerCase(Locale.ROOT));
    }

    @Override
    public boolean containsValue(Object p_1) {
        return this.internalMap.containsKey(p_1);
    }

    @Override
    public V get(Object p_1) {
        return this.internalMap.get(p_1.toString().toLowerCase(Locale.ROOT));
    }

    public V put(String p_1, V p_2) {
        return this.internalMap.put(p_1.toLowerCase(Locale.ROOT), p_2);
    }

    @Override
    public V remove(Object p_1) {
        return this.internalMap.remove(p_1.toString().toLowerCase(Locale.ROOT));
    }

    @Override
    public void putAll(Map<? extends String, ? extends V> p_1) {
        for (Entry<? extends String, ? extends V> entry : p_1.entrySet()) {
            this.put(entry.getKey(), (V)entry.getValue());
        }
    }

    @Override
    public void clear() {
        this.internalMap.clear();
    }

    @Override
    public Set<String> keySet() {
        return this.internalMap.keySet();
    }

    @Override
    public Collection<V> values() {
        return this.internalMap.values();
    }

    @Override
    public Set<Entry<String, V>> entrySet() {
        return this.internalMap.entrySet();
    }
}
