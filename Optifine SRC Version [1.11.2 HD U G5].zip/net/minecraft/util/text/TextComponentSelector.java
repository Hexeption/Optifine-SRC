package net.minecraft.util.text;

public class TextComponentSelector extends TextComponentBase {
    private final String selector;

    public TextComponentSelector(String selectorIn) {
        this.selector = selectorIn;
    }

    public String getSelector() {
        return this.selector;
    }

    @Override
    public String getUnformattedComponentText() {
        return this.selector;
    }

    public TextComponentSelector createCopy() {
        TextComponentSelector textcomponentselector = new TextComponentSelector(this.selector);
        textcomponentselector.setStyle(this.getStyle().createShallowCopy());

        for (ITextComponent itextcomponent : this.getSiblings()) {
            textcomponentselector.appendSibling(itextcomponent.createCopy());
        }

        return textcomponentselector;
    }

    @Override
    public boolean equals(Object p_1) {
        if (this == p_1) {
            return true;
        }

        if (!(p_1 instanceof TextComponentSelector)) {
            return false;
        }

        TextComponentSelector textcomponentselector = (TextComponentSelector)p_1;
        return this.selector.equals(textcomponentselector.selector) && super.equals(p_1);
    }

    @Override
    public String toString() {
        return "SelectorComponent{pattern='" + this.selector + '\'' + ", siblings=" + this.siblings + ", style=" + this.getStyle() + '}';
    }
}
