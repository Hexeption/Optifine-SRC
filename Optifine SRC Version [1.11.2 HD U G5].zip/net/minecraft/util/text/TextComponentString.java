package net.minecraft.util.text;

public class TextComponentString extends TextComponentBase {
    private final String text;

    public TextComponentString(String msg) {
        this.text = msg;
    }

    public String getText() {
        return this.text;
    }

    @Override
    public String getUnformattedComponentText() {
        return this.text;
    }

    public TextComponentString createCopy() {
        TextComponentString textcomponentstring = new TextComponentString(this.text);
        textcomponentstring.setStyle(this.getStyle().createShallowCopy());

        for (ITextComponent itextcomponent : this.getSiblings()) {
            textcomponentstring.appendSibling(itextcomponent.createCopy());
        }

        return textcomponentstring;
    }

    @Override
    public boolean equals(Object p_1) {
        if (this == p_1) {
            return true;
        }

        if (!(p_1 instanceof TextComponentString)) {
            return false;
        }

        TextComponentString textcomponentstring = (TextComponentString)p_1;
        return this.text.equals(textcomponentstring.getText()) && super.equals(p_1);
    }

    @Override
    public String toString() {
        return "TextComponent{text='" + this.text + '\'' + ", siblings=" + this.siblings + ", style=" + this.getStyle() + '}';
    }
}
