package net.minecraft.network;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.mojang.authlib.GameProfile;
import java.lang.reflect.Type;
import java.util.UUID;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.text.ITextComponent;

public class ServerStatusResponse {
    private ITextComponent description;
    private ServerStatusResponse.Players players;
    private ServerStatusResponse.Version version;
    private String favicon;

    public ITextComponent getServerDescription() {
        return this.description;
    }

    public void setServerDescription(ITextComponent descriptionIn) {
        this.description = descriptionIn;
    }

    public ServerStatusResponse.Players getPlayers() {
        return this.players;
    }

    public void setPlayers(ServerStatusResponse.Players playersIn) {
        this.players = playersIn;
    }

    public ServerStatusResponse.Version getVersion() {
        return this.version;
    }

    public void setVersion(ServerStatusResponse.Version versionIn) {
        this.version = versionIn;
    }

    public void setFavicon(String faviconBlob) {
        this.favicon = faviconBlob;
    }

    public String getFavicon() {
        return this.favicon;
    }

    public static class Players {
        private final int maxPlayers;
        private final int onlinePlayerCount;
        private GameProfile[] players;

        public Players(int maxOnlinePlayers, int onlinePlayers) {
            this.maxPlayers = maxOnlinePlayers;
            this.onlinePlayerCount = onlinePlayers;
        }

        public int getMaxPlayers() {
            return this.maxPlayers;
        }

        public int getOnlinePlayerCount() {
            return this.onlinePlayerCount;
        }

        public GameProfile[] getPlayers() {
            return this.players;
        }

        public void setPlayers(GameProfile[] playersIn) {
            this.players = playersIn;
        }

        public static class Serializer implements JsonDeserializer<ServerStatusResponse.Players>, JsonSerializer<ServerStatusResponse.Players> {
            public ServerStatusResponse.Players deserialize(JsonElement p_1, Type p_2, JsonDeserializationContext p_3) throws JsonParseException {
                JsonObject jsonobject = JsonUtils.getJsonObject(p_1, "players");
                ServerStatusResponse.Players serverstatusresponse$players = new ServerStatusResponse.Players(
                    JsonUtils.getInt(jsonobject, "max"), JsonUtils.getInt(jsonobject, "online")
                );
                if (JsonUtils.isJsonArray(jsonobject, "sample")) {
                    JsonArray jsonarray = JsonUtils.getJsonArray(jsonobject, "sample");
                    if (jsonarray.size() > 0) {
                        GameProfile[] agameprofile = new GameProfile[jsonarray.size()];

                        for (int i = 0; i < agameprofile.length; i++) {
                            JsonObject jsonobject1 = JsonUtils.getJsonObject(jsonarray.get(i), "player[" + i + "]");
                            String s = JsonUtils.getString(jsonobject1, "id");
                            agameprofile[i] = new GameProfile(UUID.fromString(s), JsonUtils.getString(jsonobject1, "name"));
                        }

                        serverstatusresponse$players.setPlayers(agameprofile);
                    }
                }

                return serverstatusresponse$players;
            }

            public JsonElement serialize(ServerStatusResponse.Players p_1, Type p_2, JsonSerializationContext p_3) {
                JsonObject jsonobject = new JsonObject();
                jsonobject.addProperty("max", p_1.getMaxPlayers());
                jsonobject.addProperty("online", p_1.getOnlinePlayerCount());
                if (p_1.getPlayers() != null && p_1.getPlayers().length > 0) {
                    JsonArray jsonarray = new JsonArray();

                    for (int i = 0; i < p_1.getPlayers().length; i++) {
                        JsonObject jsonobject1 = new JsonObject();
                        UUID uuid = p_1.getPlayers()[i].getId();
                        jsonobject1.addProperty("id", uuid == null ? "" : uuid.toString());
                        jsonobject1.addProperty("name", p_1.getPlayers()[i].getName());
                        jsonarray.add(jsonobject1);
                    }

                    jsonobject.add("sample", jsonarray);
                }

                return jsonobject;
            }
        }
    }

    public static class Serializer implements JsonDeserializer<ServerStatusResponse>, JsonSerializer<ServerStatusResponse> {
        public ServerStatusResponse deserialize(JsonElement p_1, Type p_2, JsonDeserializationContext p_3) throws JsonParseException {
            JsonObject jsonobject = JsonUtils.getJsonObject(p_1, "status");
            ServerStatusResponse serverstatusresponse = new ServerStatusResponse();
            if (jsonobject.has("description")) {
                serverstatusresponse.setServerDescription(p_3.deserialize(jsonobject.get("description"), ITextComponent.class));
            }

            if (jsonobject.has("players")) {
                serverstatusresponse.setPlayers(p_3.deserialize(jsonobject.get("players"), ServerStatusResponse.Players.class));
            }

            if (jsonobject.has("version")) {
                serverstatusresponse.setVersion(p_3.deserialize(jsonobject.get("version"), ServerStatusResponse.Version.class));
            }

            if (jsonobject.has("favicon")) {
                serverstatusresponse.setFavicon(JsonUtils.getString(jsonobject, "favicon"));
            }

            return serverstatusresponse;
        }

        public JsonElement serialize(ServerStatusResponse p_1, Type p_2, JsonSerializationContext p_3) {
            JsonObject jsonobject = new JsonObject();
            if (p_1.getServerDescription() != null) {
                jsonobject.add("description", p_3.serialize(p_1.getServerDescription()));
            }

            if (p_1.getPlayers() != null) {
                jsonobject.add("players", p_3.serialize(p_1.getPlayers()));
            }

            if (p_1.getVersion() != null) {
                jsonobject.add("version", p_3.serialize(p_1.getVersion()));
            }

            if (p_1.getFavicon() != null) {
                jsonobject.addProperty("favicon", p_1.getFavicon());
            }

            return jsonobject;
        }
    }

    public static class Version {
        private final String name;
        private final int protocol;

        public Version(String nameIn, int protocolIn) {
            this.name = nameIn;
            this.protocol = protocolIn;
        }

        public String getName() {
            return this.name;
        }

        public int getProtocol() {
            return this.protocol;
        }

        public static class Serializer implements JsonDeserializer<ServerStatusResponse.Version>, JsonSerializer<ServerStatusResponse.Version> {
            public ServerStatusResponse.Version deserialize(JsonElement p_1, Type p_2, JsonDeserializationContext p_3) throws JsonParseException {
                JsonObject jsonobject = JsonUtils.getJsonObject(p_1, "version");
                return new ServerStatusResponse.Version(JsonUtils.getString(jsonobject, "name"), JsonUtils.getInt(jsonobject, "protocol"));
            }

            public JsonElement serialize(ServerStatusResponse.Version p_1, Type p_2, JsonSerializationContext p_3) {
                JsonObject jsonobject = new JsonObject();
                jsonobject.addProperty("name", p_1.getName());
                jsonobject.addProperty("protocol", p_1.getProtocol());
                return jsonobject;
            }
        }
    }
}
