package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.handler.codec.MessageToByteEncoder;

@Sharable
public class NettyVarint21FrameEncoder extends MessageToByteEncoder<ByteBuf> {
    protected void encode(ChannelHandlerContext p_1, ByteBuf p_2, ByteBuf p_3) throws Exception {
        int i = p_2.readableBytes();
        int j = PacketBuffer.getVarIntSize(i);
        if (j > 3) {
            throw new IllegalArgumentException("unable to fit " + i + " into " + 3);
        }

        PacketBuffer packetbuffer = new PacketBuffer(p_3);
        packetbuffer.ensureWritable(j + i);
        packetbuffer.writeVarInt(i);
        packetbuffer.writeBytes(p_2, p_2.readerIndex(), i);
    }
}
