package net.minecraft.network.datasync;

public class DataParameter<T> {
    private final int id;
    private final DataSerializer<T> serializer;

    public DataParameter(int idIn, DataSerializer<T> serializerIn) {
        this.id = idIn;
        this.serializer = serializerIn;
    }

    public int getId() {
        return this.id;
    }

    public DataSerializer<T> getSerializer() {
        return this.serializer;
    }

    @Override
    public boolean equals(Object p_1) {
        if (this == p_1) {
            return true;
        } else if (p_1 != null && this.getClass() == p_1.getClass()) {
            DataParameter<?> dataparameter = (DataParameter<?>)p_1;
            return this.id == dataparameter.id;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return this.id;
    }
}
