package net.minecraft.network;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.CorruptedFrameException;
import java.util.List;

public class NettyVarint21FrameDecoder extends ByteToMessageDecoder {
    @Override
    protected void decode(ChannelHandlerContext p_1, ByteBuf p_2, List<Object> p_3) throws Exception {
        p_2.markReaderIndex();
        byte[] abyte = new byte[3];

        for (int i = 0; i < abyte.length; i++) {
            if (!p_2.isReadable()) {
                p_2.resetReaderIndex();
                return;
            }

            abyte[i] = p_2.readByte();
            if (abyte[i] >= 0) {
                PacketBuffer packetbuffer = new PacketBuffer(Unpooled.wrappedBuffer(abyte));

                try {
                    int j = packetbuffer.readVarInt();
                    if (p_2.readableBytes() >= j) {
                        p_3.add(p_2.readBytes(j));
                        return;
                    }

                    p_2.resetReaderIndex();
                } finally {
                    packetbuffer.release();
                }

                return;
            }
        }

        throw new CorruptedFrameException("length wider than 21-bit");
    }
}
