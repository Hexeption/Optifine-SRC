package net.minecraft.util.text;

import java.util.function.Function;
import java.util.function.Supplier;

public class TextComponentKeybind extends TextComponentBase {
    public static Function<String, Supplier<String>> displaySupplierFunction = p_193635_0_ -> () -> p_193635_0_;
    private final String keybind;
    private Supplier<String> displaySupplier;

    public TextComponentKeybind(String keybind) {
        this.keybind = keybind;
    }

    @Override
    public String getUnformattedComponentText() {
        if (this.displaySupplier == null) {
            this.displaySupplier = displaySupplierFunction.apply(this.keybind);
        }

        return this.displaySupplier.get();
    }

    public TextComponentKeybind createCopy() {
        TextComponentKeybind textcomponentkeybind = new TextComponentKeybind(this.keybind);
        textcomponentkeybind.setStyle(this.getStyle().createShallowCopy());

        for (ITextComponent itextcomponent : this.getSiblings()) {
            textcomponentkeybind.appendSibling(itextcomponent.createCopy());
        }

        return textcomponentkeybind;
    }

    @Override
    public boolean equals(Object p_1) {
        if (this == p_1) {
            return true;
        }

        if (!(p_1 instanceof TextComponentKeybind)) {
            return false;
        }

        TextComponentKeybind textcomponentkeybind = (TextComponentKeybind)p_1;
        return this.keybind.equals(textcomponentkeybind.keybind) && super.equals(p_1);
    }

    @Override
    public String toString() {
        return "KeybindComponent{keybind='" + this.keybind + '\'' + ", siblings=" + this.siblings + ", style=" + this.getStyle() + '}';
    }

    public String getKeybind() {
        return this.keybind;
    }
}
