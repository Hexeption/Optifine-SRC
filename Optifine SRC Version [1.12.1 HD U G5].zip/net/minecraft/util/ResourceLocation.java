package net.minecraft.util;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Locale;
import org.apache.commons.lang3.Validate;

public class ResourceLocation implements Comparable<ResourceLocation> {
    protected final String namespace;
    protected final String path;

    protected ResourceLocation(int unused, String... resourceName) {
        this.namespace = org.apache.commons.lang3.StringUtils.isEmpty(resourceName[0]) ? "minecraft" : resourceName[0].toLowerCase(Locale.ROOT);
        this.path = resourceName[1].toLowerCase(Locale.ROOT);
        Validate.notNull(this.path);
    }

    public ResourceLocation(String resourceName) {
        this(0, splitObjectName(resourceName));
    }

    public ResourceLocation(String namespaceIn, String pathIn) {
        this(0, namespaceIn, pathIn);
    }

    protected static String[] splitObjectName(String toSplit) {
        String[] astring = new String[]{"minecraft", toSplit};
        int i = toSplit.indexOf(58);
        if (i >= 0) {
            astring[1] = toSplit.substring(i + 1, toSplit.length());
            if (i > 1) {
                astring[0] = toSplit.substring(0, i);
            }
        }

        return astring;
    }

    public String getPath() {
        return this.path;
    }

    public String getNamespace() {
        return this.namespace;
    }

    @Override
    public String toString() {
        return this.namespace + ':' + this.path;
    }

    @Override
    public boolean equals(Object p_1) {
        if (this == p_1) {
            return true;
        }

        if (!(p_1 instanceof ResourceLocation)) {
            return false;
        }

        ResourceLocation resourcelocation = (ResourceLocation)p_1;
        return this.namespace.equals(resourcelocation.namespace) && this.path.equals(resourcelocation.path);
    }

    @Override
    public int hashCode() {
        return 31 * this.namespace.hashCode() + this.path.hashCode();
    }

    public int compareTo(ResourceLocation p_1) {
        int i = this.namespace.compareTo(p_1.namespace);
        if (i == 0) {
            i = this.path.compareTo(p_1.path);
        }

        return i;
    }

    public static class Serializer implements JsonDeserializer<ResourceLocation>, JsonSerializer<ResourceLocation> {
        public ResourceLocation deserialize(JsonElement p_1, Type p_2, JsonDeserializationContext p_3) throws JsonParseException {
            return new ResourceLocation(JsonUtils.getString(p_1, "location"));
        }

        public JsonElement serialize(ResourceLocation p_1, Type p_2, JsonSerializationContext p_3) {
            return new JsonPrimitive(p_1.toString());
        }
    }
}
