package net.minecraft.util;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.commons.lang3.Validate;

public class NonNullList<E> extends AbstractList<E> {
    private final List<E> delegate;
    private final E defaultElement;

    public static <E> NonNullList<E> create() {
        return new NonNullList<>();
    }

    public static <E> NonNullList<E> withSize(int size, E fill) {
        Validate.notNull(fill);
        Object[] aobject = new Object[size];
        Arrays.fill(aobject, fill);
        return new NonNullList<>(Arrays.asList((E[])aobject), fill);
    }

    public static <E> NonNullList<E> from(E defaultElementIn, E... elements) {
        return new NonNullList<>(Arrays.asList(elements), defaultElementIn);
    }

    protected NonNullList() {
        this(new ArrayList<>(), null);
    }

    protected NonNullList(List<E> delegateIn, @Nullable E listType) {
        this.delegate = delegateIn;
        this.defaultElement = listType;
    }

    @Nonnull
    @Override
    public E get(int p_1) {
        return this.delegate.get(p_1);
    }

    @Override
    public E set(int p_1, E p_2) {
        Validate.notNull(p_2);
        return this.delegate.set(p_1, p_2);
    }

    @Override
    public void add(int p_1, E p_2) {
        Validate.notNull(p_2);
        this.delegate.add(p_1, p_2);
    }

    @Override
    public E remove(int p_1) {
        return this.delegate.remove(p_1);
    }

    @Override
    public int size() {
        return this.delegate.size();
    }

    @Override
    public void clear() {
        if (this.defaultElement == null) {
            super.clear();
        } else {
            for (int i = 0; i < this.size(); i++) {
                this.set(i, this.defaultElement);
            }
        }
    }
}
