package net.minecraft.entity.ai;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.MathHelper;

public class EntityAILeapAtTarget extends EntityAIBase {
    EntityLiving leaper;
    EntityLivingBase leapTarget;
    float leapMotionY;

    public EntityAILeapAtTarget(EntityLiving leapingEntity, float leapMotionYIn) {
        this.leaper = leapingEntity;
        this.leapMotionY = leapMotionYIn;
        this.setMutexBits(5);
    }

    @Override
    public boolean shouldExecute() {
        this.leapTarget = this.leaper.getAttackTarget();
        if (this.leapTarget == null) {
            return false;
        } else {
            double d0 = this.leaper.getDistanceSq(this.leapTarget);
            if (d0 < 4.0 || d0 > 16.0) {
                return false;
            } else {
                return !this.leaper.onGround ? false : this.leaper.getRNG().nextInt(5) == 0;
            }
        }
    }

    @Override
    public boolean shouldContinueExecuting() {
        return !this.leaper.onGround;
    }

    @Override
    public void startExecuting() {
        double d0 = this.leapTarget.posX - this.leaper.posX;
        double d1 = this.leapTarget.posZ - this.leaper.posZ;
        float f = MathHelper.sqrt(d0 * d0 + d1 * d1);
        if (f >= 1.0E-4) {
            this.leaper.motionX = this.leaper.motionX + (d0 / f * 0.5 * 0.8F + this.leaper.motionX * 0.2F);
            this.leaper.motionZ = this.leaper.motionZ + (d1 / f * 0.5 * 0.8F + this.leaper.motionZ * 0.2F);
        }

        this.leaper.motionY = this.leapMotionY;
    }
}
