package net.minecraftforge.client.extensions;

import java.util.List;
import java.util.Random;
import javax.vecmath.Matrix4f;
import net.minecraft.block.BlockState;
import net.minecraft.client.renderer.model.BakedQuad;
import net.minecraft.client.renderer.model.IBakedModel;
import net.minecraft.client.renderer.model.ItemCameraTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IEnviromentBlockReader;
import net.minecraftforge.client.model.data.IModelData;
import net.optifine.reflect.Reflector;
import org.apache.commons.lang3.tuple.Pair;

public interface IForgeBakedModel {
    default IBakedModel getBakedModel() {
        return (IBakedModel)this;
    }

    default List<BakedQuad> getQuads(BlockState state, Direction side, Random rand, IModelData extraData) {
        return this.getBakedModel().getQuads(state, side, rand);
    }

    default boolean isAmbientOcclusion(BlockState state) {
        return this.getBakedModel().isAmbientOcclusion();
    }

    default Pair<? extends IBakedModel, Matrix4f> handlePerspective(ItemCameraTransforms.TransformType cameraTransformType) {
        return (Pair<? extends IBakedModel, Matrix4f>)Reflector.ForgeHooksClient_handlePerspective.call(this.getBakedModel(), cameraTransformType);
    }

    default IModelData getModelData(IEnviromentBlockReader world, BlockPos pos, BlockState state, IModelData tileData) {
        return tileData;
    }

    default TextureAtlasSprite getParticleTexture(IModelData data) {
        return this.getBakedModel().getParticleTexture();
    }
}
