package net.minecraft.util.math.shapes;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;

public class EntitySelectionContext implements ISelectionContext {
   protected static final ISelectionContext DUMMY = new EntitySelectionContext(false, -Double.MAX_VALUE, Items.AIR) {
      public boolean func_216378_a(VoxelShape shape, BlockPos pos, boolean p_216378_3_) {
         return p_216378_3_;
      }
   };
   private final boolean sneaking;
   private final double field_216381_c;
   private final Item item;

   protected EntitySelectionContext(boolean sneaking, double p_i51181_2_, Item itemIn) {
      this.sneaking = sneaking;
      this.field_216381_c = p_i51181_2_;
      this.item = itemIn;
   }

   @Deprecated
   protected EntitySelectionContext(Entity entityIn) {
      this(entityIn.isSneaking(), entityIn.getBoundingBox().minY, entityIn instanceof LivingEntity ? ((LivingEntity)entityIn).getHeldItemMainhand().getItem() : Items.AIR);
   }

   public boolean hasItem(Item itemIn) {
      return this.item == itemIn;
   }

   public boolean isSneaking() {
      return this.sneaking;
   }

   public boolean func_216378_a(VoxelShape shape, BlockPos pos, boolean p_216378_3_) {
      return this.field_216381_c > (double)pos.getY() + shape.getEnd(Direction.Axis.Y) - (double)1.0E-5F;
   }
}
