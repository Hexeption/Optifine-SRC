package net.minecraft.util.math.shapes;

import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;

public interface ISelectionContext {
   static ISelectionContext dummy() {
      return EntitySelectionContext.DUMMY;
   }

   static ISelectionContext forEntity(Entity entityIn) {
      return new EntitySelectionContext(entityIn);
   }

   boolean isSneaking();

   boolean func_216378_a(VoxelShape shape, BlockPos pos, boolean p_216378_3_);

   boolean hasItem(Item itemIn);
}
